# 削除可能な優先度付きキュー

`ErasablePriorityQueue<T, Minimize>`はC++20以降で利用でき、追加・先頭削除に加えて、指定した値を1個削除できます。`Minimize=true`なら最小値、`false`なら最大値を先頭にします。

## APIと前提

- `ErasablePriorityQueue()`：空で構築します。`ErasablePriorityQueue(values)`はvectorを受け取り、線形時間で一括構築します。
- `push(value)` / `push(T&&)` / `emplace(args...)`：1要素を追加します。
- `top()` / `pop()`：先頭の値を返す／先頭を1個削除します。空でないことが前提です。
- `erase(value)`：存在する値を1個削除します。重複があれば1個分だけです。存在と個数の検査は行いません。
- `size()` / `empty()`：有効な要素数／空かどうかを返します。遅延削除の回収は行いません。
- `try_top()`：空なら`nullopt`、そうでなければ先頭の値を返します。
- `extract_top()`：空なら`nullopt`、そうでなければ先頭を1個削除して値を返します。
- `swap(other)`：有効な要素と遅延削除を定数時間で交換します。
- `clear()`：要素と遅延削除を破棄し、容量を解放します。

`T`は比較・コピーが可能な型を使います。比較は厳密弱順序を満たし、`==`はその同値関係と一致する必要があります。浮動小数点のNaNはこの条件を満たしません。move元は空になり、再利用できます。

既定では空の`top()`・`pop()`・`erase()`を例外で検出します。`SKIP_RUNTIME_CHECKS`を定義すると、この検査を除きます。空でない場合も、存在しない値の`erase()`は利用側の前提違反です。

## 方式と計算量

値を保持するヒープと、削除する値を保持するヒープを使います。先頭の取得・削除時に両方の先頭が一致していれば、両方から取り除きます。削除の記録は、対象が先頭に来るまで残ります。

GCC（Clangを除く）の64bit整数型では、1つの親に最大4個の子を持つ4分岐ヒープを使います。子の比較を明示し、木の段数と依存する読み取りを減らします。一括構築では葉に近い親から順に処理し、線形時間でヒープを作ります。

先頭削除では穴を葉まで下げ、末尾の値を親と比較しながら戻します。相殺する2つのヒープは交互に降り、各配列を独立に復元します。子が存在する親かを確認してから子の添字を計算し、容量や添字のオーバーフローを避けます。

GCCの32bit以下の整数型と、Clangなどの整数型では二分ヒープを使い、相殺時だけ2つの配列を交互に降ります。GCCでは通常の削除も配列上で下降・復元し、Clangなどは`std::priority_queue`を使います。整数以外と`bool`は保持型も処理も`std::priority_queue`です。追加の所有領域やCPU固有の命令は使わず、いずれも標準C++の処理です。

GCCの整数型では、削除待ちがなければ先頭照会の正規化を省きます。4分岐版では相殺処理の展開位置を調整し、その経路の呼出し費用を抑えます。

未回収の削除済み要素を含む保存数を`H`とすると、追加と削除予約は`O(log(H+1))`です。先頭取得・削除は回収を含めて償却`O(log(H+1))`ですが、1回の操作で多数の削除を回収することがあります。`size()`・`empty()`は`O(1)`、一括構築は`O(n)`、使用領域は`O(H)`です。

要素型や比較演算が例外を投げる場合の保証は、内部の`std::priority_queue`の操作に依存します。

## 使用例とVerify

- [使用例](../Examples/erasable_priority_queue_example.cpp)
- [Library Checker提出コード](../Verify/current/submissions/erasable_priority_queue_double.cpp)：Double-Ended Priority Queue。最小値・最大値優先の2表を同期し、入力を逐次処理します。
- [ローカル補足（通常版の補足・元リポジトリ）](https://github.com/reinsirk/sirkit-cpp-library/blob/main/Verify/current/tests/erasable_priority_queue_test.cpp)：`std::multiset`との照合で、整数端・重複・補助API・コピーとmoveを確認します。
- [ヒープ境界の補足（通常版の補足・元リポジトリ）](https://github.com/reinsirk/sirkit-cpp-library/blob/main/Verify/current/tests/erasable_priority_queue_boundary_test.cpp)：整数各幅の小サイズと4冪前後で、一括構築・逐次追加・遅延削除・コピーを独立照合します。

A+Bへの提出は、このライブラリのオンラインVerifyには使用しません。原典のunit testは方式の参考とし、独立照合はローカルで実行します。
