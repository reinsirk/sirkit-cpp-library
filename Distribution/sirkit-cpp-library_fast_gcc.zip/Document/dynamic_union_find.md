# 動的Union Find

`int`全域のキーを、使った時点で登録するUnion Findです。負の値や`INT_MIN`・`INT_MAX`も使えます。連続した添字への変換は利用側で用意する必要がありません。

## APIと前提

- `DynamicUnionFind()`：空で構築します。`DynamicUnionFind(n)`は空のままn要素分を予約します。
- `add(k)`：単独成分として登録し、新規登録ならtrueを返します。
- `find(k)`：代表キーを返します。`same(x, y)`は同じ成分かを返します。
- `unite(x, y)`：サイズで併合し、併合したとき1、既に同じ成分なら0を返します。
- `unite(x, y, f)`：併合したときだけ`f(新しい代表キー, 吸収した代表キー)`を呼びます。コールバックの例外でも併合は完了したままです。
- `size(k)`：所属成分の要素数を返します。
- `data(k)`：根なら負のサイズ、非根なら親のキーを返します。負の親キーと区別する判定には使えません。
- `contains(k)`：登録済みかを返します。要素を追加しません。
- `node_count()` / `component_count()` / `empty()`：登録数・成分数・空かどうかを返します。
- `groups()`：全成分のキー一覧を返します。成分間の順序は未規定です。
- `reserve(n)`：登録状態を変えずに容量を予約します。`clear()`は登録を消し、確保済み容量を再利用します。

`find`・`same`・`size`・`data`・`unite`は、未知のキーを単独成分として自動登録します。登録数は`INT_MAX`以下です。内部の容量上限は`SKIP_RUNTIME_CHECKS`でも維持します。

## 方式と計算量

ハッシュ表でキーを連続した内部添字へ変換し、キーと親・サイズを連続配列に保持します。親はキーではなく添字なので、負のキーを根のサイズと取り違えません。サイズによる併合と経路の短縮を使います。

GCCでは、未登録のときだけ値を生成する共通ハッシュ表の`find_or_emplace`を使い、登録時の探索の重複を減らします。成分の比較にも内部添字を使います。`groups()`の成分番号は内部添字と同じ幅で持ち、必ず代入してから読む領域のゼロ初期化を省きます。32要素以下では固定長の作業領域を使い、一時的なヒープ確保も省きます。Clangなどは従来の探索・作業領域を使います。どちらも標準C++23で実装しています。

`groups()`は、全要素が別成分なら各キーの単独一覧を直接作ります。全要素が1成分なら登録順のキー一覧を作り、戻り値の領域を全て予約してから代表を1回取得し、全ての非根を代表へ直結します。代表キーと成分サイズは保ちます。一般の成分構成では上記の作業領域を使う方式を維持します。

ハッシュ検索は期待`O(1)`、併合・探索は償却`O(α(N))`です。`contains`は期待`O(1)`、件数取得は`O(1)`、`groups`は`O(N α(N))`、全独立または全連結なら`O(N+1)`です。使用領域は登録数と予約容量に比例します。

コピーは独立した複製を作り、コピー代入の確保失敗時は元の内容を維持します。move元は空になり、再利用できます。1キーの登録に失敗したとき、そのキーは登録されず、既存の連結関係は保ちます。複数キーを扱う操作では、それまでに成功した登録は残ります。`groups`の確保失敗時も登録と連結関係は保ちます。成功した`groups`は親を短縮するため、`data(k)`の返す親キーが変わる場合があります。

## 使用例とVerify

- [使用例](../Examples/dynamic_union_find_example.cpp)
- [Library Checker提出コード](../Verify/current/submissions/dynamic_union_find.cpp)：Unionfind。通常のAPIを逐次呼び出します。

負のキー・整数端・各補助API・コールバック・所有権・確保失敗は、成分ラベルを全走査する独立参照でも照合します。[検証（元リポジトリ）](https://github.com/reinsirk/sirkit-cpp-library/blob/main/Audit/verify-dynamic-union-find-second-pass-2026-10-22.json)・[測定（元リポジトリ）](https://github.com/reinsirk/sirkit-cpp-library/blob/main/Audit/performance-dynamic-union-find-second-pass-2026-10-22.json)・[出典（元リポジトリ）](https://github.com/reinsirk/sirkit-cpp-library/blob/main/Audit/provenance-dynamic-union-find-second-pass-2026-10-22.json)をそれぞれ記録しています。
