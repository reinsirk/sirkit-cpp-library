# 整数の基数ソート

`Algorithm/Radix_sort.cpp` は、`bool` を除く8・16・32・64ビットの標準整数型を安定な昇順に整列する。符号付き整数の最小値・最大値も扱う。符号付きの値は符号ビットを反転した符号なしキーで比較し、元の整数演算でオーバーフローさせない。

| 操作 | 結果 |
|---|---|
| `RadixSort(values)` | 配列を昇順に整列 |
| `RadixSort(values, maximum)` | 同じ整列。すべての値がmaximum以下という前提を確認 |
| `RadixSortOrder(values)` | 安定昇順の元添字列。入力は不変 |
| `RadixSortWorkspace<T>::sort(values)` | 作業領域を再利用して整列 |
| `workspace.sort(values, maximum)` | 上限付きの同じ処理 |
| `workspace.reserve(n)` / `capacity()` / `release()` | 作業領域の予約 / 予約要素数 / 解放 |

Bを整数型のバイト数としてO(Bn)時間・O(n)追加領域。小配列は確保せず挿入ソートを使う。変化しないバイトの散布は省く。64ビット型は順序と変動するバイトの幅を先に求め、整列済み・逆順ならヒストグラムの初期化・集計をせず終了する。変動が下位32ビット内なら必要なバイトだけを集計する。それ以外の整数幅は一走査の集計を使う。GCCでは32ビット型の4バイト集計を展開し、要素ごとのループを省く。

64ビット型の128要素以上では、GCC/Clangのx86向け拡張とCPUのAVX2対応を確認し、順序・変動ビットの集計を4要素ずつ行う。符号なしの大小比較は符号ビットを反転して処理し、端数は標準の整数演算で扱う。追加の確保は行わず、ヒストグラムと安定な散布は共通の処理を使う。これ以外の環境では標準C++の経路を使う。

`SIRKIT_DISABLE_SIMD`をインクルード前に定義すると、この専用実装とCPU判定を除外する。`-march=native`などによるコンパイラ自身の自動ベクトル化は、このマクロの対象に含めない。切り替え費用・自動ベクトル化した経路との比較は[測定資料（元リポジトリ）](https://github.com/reinsirk/sirkit-cpp-library/blob/main/Audit/performance-radix-sort-second-round-four-hours-2026-10-22.json)を参照。

`sort` は元の配列の容量・要素の保管先を変えない。作業領域のコピーは独立し、ムーブ後も再利用できる。同値の元添字は元の順に並ぶ。逆順の入力でも、添字列は同値の区間内の順を保つ。

上限指定は負の値・負の上限にも対応する。検査は通常処理中に組み込み、`SKIP_RUNTIME_CHECKS` で除外する。上限違反の例外が出るまでに、配列が部分的に整列されている場合がある。容量限界など標準コンテナの保護は検査省略時も残る。

[使用例](../Examples/radix_sort_example.cpp)と[整数全幅・安定順テスト（通常版の補足・元リポジトリ）](https://github.com/reinsirk/sirkit-cpp-library/blob/main/Verify/current/tests/radix_reference_test.cpp)、[例外・所有権テスト（通常版の補足・元リポジトリ）](https://github.com/reinsirk/sirkit-cpp-library/blob/main/Verify/current/tests/radix_exception_test.cpp)を参照。

## Verify

提出先は[ABC331 C — Sum of Numbers Greater Than Me](https://atcoder.jp/contests/abc331/tasks/abc331_c)。int64_t版とuint32_t版は、同じ手順で整列結果から各要素より大きい値の和を求める。問題の値域は両型に収まる。提出全体の時間には累積和・二分探索・入出力も含まれる。符号付き全域、8整数幅、安定な添字順、作業領域と例外はローカル補足で確認する。
