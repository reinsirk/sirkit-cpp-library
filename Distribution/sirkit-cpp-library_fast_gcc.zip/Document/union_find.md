# Union Find

頂点を互いに重ならない連結成分に分け、成分の結合と同一成分の照会を行います。[使用例](../Examples/union_find_example.cpp)を参照してください。

各頂点に親の添字を持ち、根には成分サイズの負数を保存します。小さい成分を大きい成分へ接続するため、木の高さはO(log(n+1))以下です。代表探索では1つおきの頂点を祖父へつなぐpath halvingで経路を短くし、繰り返す操作の計算量を抑えます。

GCCの結合処理は、代表探索で読み出した根の負サイズを保持して再利用します。2本目の探索で経路を短くしても、最初の根とサイズは変わりません。第二引数がその根自身、または探索中の親がその根であれば、それ以上の書戻しは必要ないため結合不要として終了します。それ以外はpath halvingで探索し、最後にも同じ根かを確認します。同じ根のサイズを加算することはありません。Clangなどでは代表探索後に根のサイズを読み出します。

## API

| API | 動作 |
| --- | --- |
| `UnionFind(n=0)` | `n`頂点を別々の成分として構築する。`n<=INT_MAX`。 |
| `root(i)`、`leader(i)` | 頂点の代表を返す。 |
| `merge(a,b)` | 成分を結合し、新しく結合したときだけ`true`を返す。 |
| `unite(a,b)` | 同じ結合を行う。戻り値は`void`。 |
| `same(a,b)`、`issame(a,b)` | 同じ成分かを返す。 |
| `size(i)` | 指定頂点の成分サイズ。 |
| `size()`、`empty()`、`component_count()` | 全頂点数、空か、成分数。 |
| `groups()` | 成分ごとの頂点一覧。各一覧の頂点は昇順。 |
| `reset(n)`、`reset()` | 新しい`n`頂点、または現在の頂点数で全成分を独立にする。容量は再利用する。 |
| `clear()` | 空に戻し、確保済み容量を保持する。`noexcept`。 |
| `swap(other)`、`swap(left,right)` | 内容を交換する。`noexcept`。 |

頂点は`0<=i<size()`です。代表はその成分の最小頂点とは限りません。結合の順序に依存し、サイズが同じ成分同士では最初の引数が属する成分の代表を残します。`groups`の成分順は代表番号の昇順です。

```cpp
UnionFind uf(5);
uf.unite(0, 1);
assert(uf.merge(1, 2));
assert(!uf.merge(0, 2));
assert(uf.same(0, 2) && uf.size(1) == 3);
assert(uf.component_count() == 3);
auto copy = uf;
copy.merge(3, 4);
assert(!uf.same(3, 4));
uf.reset(3);
assert(uf.component_count() == 3 && !uf.same(0, 1));
uf.merge(0, 1);
uf.reset(); // 頂点数3のまま結合を消す。
assert(uf.component_count() == 3);
uf.clear();
assert(uf.empty());
swap(uf, copy);
assert(copy.empty() && uf.same(3, 4));
```

## 経路圧縮と計算量

代表を使う操作は内部の親のつながりを短くする場合があります。連結成分・代表・サイズは変わりません。`groups()`も内部の探索を行う場合がありますが、返した一覧は独立した値です。後からUnion Findを変更しても、既に返した一覧は変わりません。

頂点数を`n`、確保済み容量を`C`とします。構築とコピー構築はO(n+1)時間・領域、保持領域はO(C+1)です。`root`、`leader`、`merge`、`unite`、`same`、`issame`、`size(i)`は償却O(α(n+1))、単独の操作ではO(log(n+1))の上界です。αは逆Ackermann関数です。

`groups`は償却O(1+n α(n+1))時間、O(n+1)追加領域です。全頂点が別成分なら一覧を直接作り、全頂点が1成分なら代表を一度求め、親配列の連続書込みで全頂点をその直下へつなぎます。根の負サイズを保存・復元し、連番生成で結果を作ります。この2場合はO(n+1)時間です。その他は根に保持した負サイズから各成分の容量を確保し、代表から出力位置への作業配列1本で頂点を並べます。Clangでは代表・件数の2配列を使い、件数配列を出力位置へ再利用します。いずれも成分は代表頂点の昇順、成分内は頂点の昇順です。

`size()`、`empty`、`component_count`、`swap`とムーブ構築はO(1)です。`reset(m)`は旧長`n`も含めO(n+m+1)、`clear`とムーブ代入は旧状態の破棄を含めO(n+1)の上界です。コピー代入は旧長・新長を合わせた線形時間の上界です。

## 所有権と例外

親配列は`vector<int>`で所有します。コピーは独立し、一方の結合はもう一方へ影響しません。ムーブ後の移動元は空です。自己代入・自己ムーブでは内容を保ちます。

`reset`は先に必要な容量を確保し、成功後に内容を初期化します。確保に失敗しても、既存の連結状態と成分数は保たれます。`clear`は領域を解放せず、後の`reset`で再利用できます。コピー代入も、確保失敗時には代入先の連結状態を保ちます。

`groups`が結果の確保に失敗した場合も連結成分・代表・サイズは保たれますが、途中まで行った経路圧縮は残る場合があります。内部の親配列が一切変更されないという保証ではありません。

## 入力検査

既定では指定した頂点を検査し、範囲外なら`out_of_range`を送出します。検査のためだけに全頂点を走査しません。`SKIP_RUNTIME_CHECKS`を定義した場合は、利用側で頂点の前提を満たしてください。

頂点数が`int`で表せる上限を超える場合の`length_error`は、検査省略時も維持します。配列容量の確保にも標準コンテナの上限が適用されます。

[代表・サイズの独立モデル（通常版の補足・元リポジトリ）](https://github.com/reinsirk/sirkit-cpp-library/blob/main/Verify/current/tests/uf_merge_reference_test.cpp)でサイズ同値時の代表も照合します。[深い経路への失敗結合の試験（通常版の補足・元リポジトリ）](https://github.com/reinsirk/sirkit-cpp-library/blob/main/Verify/current/tests/uf_failed_merge_reference_test.cpp)では、先に照会で圧縮せず、同頂点・根自身・根直下を含む両方向の結合と`unite`を確認します。

Reputelessの省メモリ版から、負サイズを持つ1配列とサイズによる併合を引き継いでいます。[来歴とライセンスの監査（元リポジトリ）](https://github.com/reinsirk/sirkit-cpp-library/blob/main/Audit/provenance-union-find-second-pass-2026-10-22.json)に原典とローカル改修の区別を記録しています。
