// SPDX-License-Identifier: CC0-1.0
// SPDX-License-Identifier: CC0-1.0
// 生成版: GCC・速度優先（入力検査を除外）。 所有・解放の省略は各APIの前提を参照。
// 生成元: Math/Gaussian_Elimination.cpp
// 参考（用途・Verify問題）: https://nyaannyaan.github.io/library/matrix/matrix.hpp
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/matrix.md
//
// API一覧
// 以下の消去は正確な体Tが前提。Mint等は利用側が用意する。整数型・一般の合成数法・浮動小数点は対象外。
// GaussianElimination(a,reduced=false): 値で受け取った行列を行基本変形。元のlvalueは変更せず結果を返す。
// GaussianEliminationResult<T>: matrixはピボット1の階段形、pivot_columns/pivotsは列と正規化前の値、row_swapsは交換数。
// reduced=trueなら各ピボットの上も消去する。rank()はピボット数をO(1)で返す。
// rows=m,cols=nとし消去はO(m*n*min(m,n))時間・O(m*n)所有領域。0行・0列・矩形・特異も可。
// MatrixRank(a): 体上の階数。MatrixDeterminant(a): 正方行列の行列式、0x0はT{1}。消去と同計算量。
// MatrixInverse(a): 正方行列の逆行列をoptionalで返す。特異はnullopt、0x0は空の単位行列。O(n³)時間・O(n²)領域。
// SolveLinearSystem(a,b): a*x=bの一解と核の基底をoptionalで返す。不能ならnullopt、b.size()==a.rows()が前提。
// LinearSystemResult<T>: particularは長さnの一解、kernelは各行が核基底（列数n）、pivot_columnsはピボット列。
// SolveはO(m*(n+1)*(1+min(m,n))+n²)時間・O(m*(n+1)+n²)領域。0行では全空間、0列ではbが零のときだけ空の一解。
// 非零ピボットの逆数が1を作らなければdomain_error。これは係数型が体であること全体を検証するものではない。
// 0判定・非可逆ピボットの保護・内部容量上限はSKIP_RUNTIME_CHECKSでも維持する。
//
// [同梱Matrix]
// Matrix<T>: 行優先の連続vectorで所有する行列。Tはコピー可能で0/1構築・必要な環演算を提供する。
// 計算量はTの演算・コピーをO(1)として数える。
// Matrix()/Matrix(r,c,value=T{0}): 0x0/指定形状の一様行列。O(1)/O(r*c)時間・領域。
// Matrix(r,c,vector<T>): 値で受け取ったvectorを所有。move時O(1)、copy時O(r*c)。行リスト{{...},...}はO(r*c)でコピー。
// 行リストは全行同じ長さ、flat vectorはr*c要素。0行・0列も可。内部容量上限は検査省略時も維持。
// rows()/cols()/size()/empty(): 行数/列数/全要素数/要素数0かをO(1)で返す。
// operator()(r,c): 要素の参照。row(r): 行の非所有span。values(): 全値の非所有span。各O(1)。
// rowの列添字はspanと同じく範囲内を渡す。行列の代入・swap・破棄で非所有参照は無効になる。
// copy/move/代入/swap: 独立コピー/所有移譲。コピーO(r*c)、move/swapはO(1)、移動元は0x0。
// +=/-=/+/-: 同形行列の加減。O(r*c)。==/!=は形状と値を比較する。
// */*=: (r,k)*(k,c)の行列積。O(r*c*(1+k))時間・O(r*c)追加領域。入力は変更しない（*=は左辺を更新）。
// transposed(): 転置の独立コピー。O(r*c)時間・領域。assign(r,c,value): 新しい一様行列へ置換する。
// MatrixIdentity<T>(n): nxn単位行列。O(n²)。MatrixPower(a,k): 正方行列の非負整数乗、O(n³ log(k+2))。
// MatrixApply(a,x): a*xの列ベクトルを返す。O(rows*(1+cols))時間・O(rows)領域。
// boolには専用のGF2係数型等を用意する。係数演算は正確な環の演算が前提。固定幅整数の演算オーバーフローや浮動小数点誤差は利用側で管理する。

// GCC/x86のuint32_t行列積は、対応CPUでAVX2を使う。unsignedの積と加算は通常版と同じmod 2^32。
// SIRKIT_DISABLE_SIMDで専用実装とCPU判定を除外する。小さい行列・他の型・非対応CPU/コンパイラは標準ループ。

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <initializer_list>
#include <span>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>
#include <bit>
#if (!defined(SIRKIT_DISABLE_SIMD)) && ((defined(__x86_64__)) || (defined(__i386__)))
#include <immintrin.h>
#ifndef SIRKIT_MATRIX_U32_SIMD_DETAIL_DEFINED
#define SIRKIT_MATRIX_U32_SIMD_DETAIL_DEFINED
namespace reinsirk::detail {
inline bool matrix_u32_avx2_available() noexcept { return __builtin_cpu_supports("avx2")!=0; }
__attribute__((target("avx2"))) inline void matrix_u32_tiled_avx2(
    const std::uint32_t* left,const std::uint32_t* right,std::uint32_t* output,
    std::size_t rows,std::size_t inner,std::size_t columns) noexcept {
    constexpr std::size_t tile=32;
    const auto vector_end=columns-columns%8;
    for(std::size_t row_begin=0;row_begin<rows;) {
        const auto row_end=row_begin+std::min(std::size_t{4},rows-row_begin);
        for(std::size_t begin=0;begin<inner;) {
            const auto end=begin+std::min(tile,inner-begin);
            for(std::size_t i=row_begin;i<row_end;++i) {
            auto* destination=output+i*columns;
            std::size_t j=0;
            for(;vector_end-j>=32;j+=32) {
                __m256i s0,s1,s2,s3;
                if(begin==0) {s0=_mm256_setzero_si256();s1=s0;s2=s0;s3=s0;}
                else {
                    s0=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(destination+j));
                    s1=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(destination+j+8));
                    s2=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(destination+j+16));
                    s3=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(destination+j+24));
                }
                for(std::size_t k=begin;k<end;++k) {
                    const auto coefficient=_mm256_set1_epi32(std::bit_cast<std::int32_t>(left[i*inner+k]));
                    const auto* input=right+k*columns+j;
                    s0=_mm256_add_epi32(s0,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(input))));
                    s1=_mm256_add_epi32(s1,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(input+8))));
                    s2=_mm256_add_epi32(s2,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(input+16))));
                    s3=_mm256_add_epi32(s3,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(input+24))));
                }
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j),s0);
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j+8),s1);
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j+16),s2);
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j+24),s3);
            }
            for(;j<vector_end;j+=8) {
                auto sum=begin==0?_mm256_setzero_si256():_mm256_loadu_si256(reinterpret_cast<const __m256i*>(destination+j));
                for(std::size_t k=begin;k<end;++k) {
                    const auto coefficient=_mm256_set1_epi32(std::bit_cast<std::int32_t>(left[i*inner+k]));
                    sum=_mm256_add_epi32(sum,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(right+k*columns+j))));
                }
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j),sum);
            }
            for(;j<columns;++j) {
                std::uint32_t sum=begin==0?0:destination[j];
                for(std::size_t k=begin;k<end;++k)sum+=left[i*inner+k]*right[k*columns+j];
                destination[j]=sum;
            }
            }
            begin=end;
        }
        row_begin=row_end;
    }
}
__attribute__((target("avx2"))) inline void matrix_u32_accumulate_avx2(
    const std::uint32_t* left,const std::uint32_t* right,std::uint32_t* output,
    std::size_t rows,std::size_t inner,std::size_t columns) noexcept {
    const auto vector_end=columns-columns%8;
    for(std::size_t i=0;i<rows;++i) {
        auto* destination=output+i*columns;
        std::size_t j=0;
        for(;vector_end-j>=32;j+=32) {
            auto s0=_mm256_setzero_si256(),s1=s0,s2=s0,s3=s0;
            for(std::size_t k=0;k<inner;++k) {
                const auto coefficient=_mm256_set1_epi32(std::bit_cast<std::int32_t>(left[i*inner+k]));
                const auto* source=right+k*columns+j;
                s0=_mm256_add_epi32(s0,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(source))));
                s1=_mm256_add_epi32(s1,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(source+8))));
                s2=_mm256_add_epi32(s2,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(source+16))));
                s3=_mm256_add_epi32(s3,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(source+24))));
            }
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j),s0);
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j+8),s1);
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j+16),s2);
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j+24),s3);
        }
        for(;j<vector_end;j+=8) {
            auto sum=_mm256_setzero_si256();
            for(std::size_t k=0;k<inner;++k) {
                const auto coefficient=_mm256_set1_epi32(std::bit_cast<std::int32_t>(left[i*inner+k]));
                const auto values=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(right+k*columns+j));
                sum=_mm256_add_epi32(sum,_mm256_mullo_epi32(coefficient,values));
            }
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j),sum);
        }
        for(;j<columns;++j) {
            std::uint32_t sum=0;
            for(std::size_t k=0;k<inner;++k)sum+=left[i*inner+k]*right[k*columns+j];
            destination[j]=sum;
        }
    }
}
}
#endif
#endif

#ifndef SIRKIT_MATRIX_DEFINED
#define SIRKIT_MATRIX_DEFINED
template<class T>
class Matrix {
    static_assert(!std::is_same_v<T,bool>,"Matrix<bool>: provide a coefficient type instead of vector<bool>");
    std::size_t rows_=0,columns_=0;
    std::vector<T> values_;
    static std::size_t area(std::size_t rows,std::size_t columns) {
        if(columns&&rows>std::vector<T>{}.max_size()/columns)
            throw std::length_error("Matrix: dimensions overflow");
        return rows*columns;
    }
public:
    using value_type=T;
    using size_type=std::size_t;
    Matrix()=default;
    Matrix(size_type rows,size_type columns,const T& value=T{0})
        :rows_(rows),columns_(columns),values_(area(rows,columns),value){}
    Matrix(size_type rows,size_type columns,std::vector<T> values)
        :rows_(rows),columns_(columns),values_(std::move(values)) {
        const auto expected=area(rows,columns);
        (void)expected;
    }
    Matrix(std::initializer_list<std::initializer_list<T>> rows)
        :rows_(rows.size()),columns_(rows.size()?rows.begin()->size():0) {
        values_.reserve(area(rows_,columns_));
        for(const auto& row:rows) {
            values_.insert(values_.end(),row.begin(),row.end());
        }
    }
    Matrix(const Matrix&)=default;
    Matrix(Matrix&& other) noexcept
        :rows_(std::exchange(other.rows_,0)),columns_(std::exchange(other.columns_,0)),
         values_(std::move(other.values_)) { other.values_.clear(); }
    Matrix& operator=(Matrix other) noexcept { swap(other);return *this; }
    void swap(Matrix& other) noexcept {
        std::swap(rows_,other.rows_);std::swap(columns_,other.columns_);values_.swap(other.values_);
    }
    friend void swap(Matrix& a,Matrix& b) noexcept { a.swap(b); }
    size_type rows()const noexcept{return rows_;}
    size_type cols()const noexcept{return columns_;}
    size_type size()const noexcept{return values_.size();}
    bool empty()const noexcept{return values_.empty();}
    std::span<T> values()noexcept{return {values_.data(),values_.size()};}
    std::span<const T> values()const noexcept{return {values_.data(),values_.size()};}
    std::span<T> row(size_type index) {
        const auto offset=index*columns_;
        return {offset?values_.data()+offset:values_.data(),columns_};
    }
    std::span<const T> row(size_type index)const {
        const auto offset=index*columns_;
        return {offset?values_.data()+offset:values_.data(),columns_};
    }
    T& operator()(size_type row_index,size_type column_index) {
        return values_[row_index*columns_+column_index];
    }
    const T& operator()(size_type row_index,size_type column_index)const {
        return values_[row_index*columns_+column_index];
    }
    void assign(size_type rows,size_type columns,const T& value=T{0}) {
        Matrix next(rows,columns,value);swap(next);
    }
    Matrix transposed()const {
        Matrix result(columns_,rows_);
        if(values_.empty())return result;
        for(size_type i=0;i<rows_;++i)
            for(size_type j=0;j<columns_;++j)result.values_[j*rows_+i]=values_[i*columns_+j];
        return result;
    }
    Matrix& operator+=(const Matrix& other) {
        for(size_type i=0;i<values_.size();++i)values_[i]+=other.values_[i];
        return *this;
    }
    Matrix& operator-=(const Matrix& other) {
        for(size_type i=0;i<values_.size();++i)values_[i]-=other.values_[i];
        return *this;
    }
    Matrix& operator*=(const Matrix& other);
    friend Matrix operator+(Matrix a,const Matrix& b){a+=b;return a;}
    friend Matrix operator-(Matrix a,const Matrix& b){a-=b;return a;}
    bool operator==(const Matrix&)const=default;
};
#endif
#ifndef SIRKIT_MATRIX_ARITHMETIC_DEFINED
#define SIRKIT_MATRIX_ARITHMETIC_DEFINED
template<class T>
Matrix<T> operator*(const Matrix<T>& a,const Matrix<T>& b) {
    Matrix<T> result(a.rows(),b.cols());
    if(result.empty()||a.cols()==0)return result;
#if (!defined(SIRKIT_DISABLE_SIMD)) && ((defined(__x86_64__)) || (defined(__i386__)))
    if constexpr(std::is_same_v<T,std::uint32_t>) {
        if(b.cols()>=16&&a.size()>=64&&reinsirk::detail::matrix_u32_avx2_available()) {
            // 小さい右行列と短い内積は従来の全内積累積を維持する。
            if(a.cols()>64 && b.size()>262144)
                reinsirk::detail::matrix_u32_tiled_avx2(a.values().data(),b.values().data(),result.values().data(),a.rows(),a.cols(),b.cols());
            else
            reinsirk::detail::matrix_u32_accumulate_avx2(a.values().data(),b.values().data(),result.values().data(),a.rows(),a.cols(),b.cols());
            return result;
        }
    }
#endif

    for(std::size_t i=0;i<a.rows();++i) {
        auto destination=result.row(i);const auto left=a.row(i);
        for(std::size_t k=0;k<a.cols();++k) {
            const T multiplier=left[k];const auto right=b.row(k);
            for(std::size_t j=0;j<b.cols();++j)destination[j]+=multiplier*right[j];
        }
    }
    return result;
}
template<class T>Matrix<T>& Matrix<T>::operator*=(const Matrix& other) {
    auto result=*this*other;swap(result);return *this;
}
template<class T>Matrix<T> MatrixIdentity(std::size_t n) {
    Matrix<T> result(n,n);for(std::size_t i=0;i<n;++i)result.row(i)[i]=T{1};return result;
}
template<class T>Matrix<T> MatrixPower(Matrix<T> base,std::uint64_t exponent) {
    auto result=MatrixIdentity<T>(base.rows());
    while(exponent){if(exponent&1)result*=base;exponent>>=1;if(exponent)base*=base;}
    return result;
}
template<class T>std::vector<T> MatrixApply(const Matrix<T>& matrix,const std::vector<T>& vector) {
    std::vector<T> result(matrix.rows(),T{0});
    for(std::size_t i=0;i<matrix.rows();++i){const auto row=matrix.row(i);for(std::size_t j=0;j<matrix.cols();++j)result[i]+=row[j]*vector[j];}
    return result;
}
#endif

#include <cstddef>
#include <limits>
#include <optional>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>
#ifndef SIRKIT_GAUSSIAN_RESULT_DEFINED
#define SIRKIT_GAUSSIAN_RESULT_DEFINED
template<class T>struct GaussianEliminationResult {
    Matrix<T> matrix;
    std::vector<std::size_t> pivot_columns;
    std::vector<T> pivots;
    std::size_t row_swaps=0;
    std::size_t rank()const noexcept{return pivot_columns.size();}
};
template<class T>struct LinearSystemResult {
    std::vector<T> particular;
    Matrix<T> kernel;
    std::vector<std::size_t> pivot_columns;
};
#endif
#ifndef SIRKIT_GAUSSIAN_DETAIL_DEFINED
#define SIRKIT_GAUSSIAN_DETAIL_DEFINED
namespace reinsirk::detail {
template<class T>
GaussianEliminationResult<T> field_eliminate(Matrix<T> matrix,std::size_t pivot_end,bool reduced) {
    static_assert(!std::is_integral_v<T>,"Gaussian elimination requires an exact field type, not an integer type");
    GaussianEliminationResult<T> result{std::move(matrix),{},{},0};
    auto& work=result.matrix;
    result.pivot_columns.reserve(std::min(work.rows(),pivot_end));
    result.pivots.reserve(std::min(work.rows(),pivot_end));
    for(std::size_t column=0;column<pivot_end&&result.rank()<work.rows();++column) {
        const auto rank=result.rank();std::size_t candidate=rank;
        while(candidate<work.rows()&&work.row(candidate)[column]==T{0})++candidate;
        if(candidate==work.rows())continue;
        auto pivot_row=work.row(rank);
        if(candidate!=rank) {
            auto other=work.row(candidate);
            for(std::size_t j=column;j<work.cols();++j)std::swap(pivot_row[j],other[j]);
            ++result.row_swaps;
        }
        const T pivot=pivot_row[column];
        result.pivot_columns.push_back(column);result.pivots.push_back(pivot);
        if(pivot!=T{1}) {
            const T inverse=T{1}/pivot;
            if(pivot*inverse!=T{1})throw std::domain_error("Gaussian elimination: non-invertible pivot");
            for(std::size_t j=column+1;j<work.cols();++j)pivot_row[j]*=inverse;
            pivot_row[column]=T{1};
        }
        const auto begin=reduced?std::size_t{0}:rank+1;
        for(std::size_t i=begin;i<work.rows();++i) {
            if(i==rank)continue;
            auto destination=work.row(i);const T factor=destination[column];
            if(factor==T{0})continue;
            for(std::size_t j=column+1;j<work.cols();++j)destination[j]-=factor*pivot_row[j];
            destination[column]=T{0};
        }
    }
    return result;
}
}
#endif
#ifndef SIRKIT_FIELD_GAUSSIAN_DEFINED
#define SIRKIT_FIELD_GAUSSIAN_DEFINED
template<class T>GaussianEliminationResult<T> GaussianElimination(Matrix<T> matrix,bool reduced=false) {
    const auto columns=matrix.cols();
    return reinsirk::detail::field_eliminate(std::move(matrix),columns,reduced);
}
template<class T>std::size_t MatrixRank(const Matrix<T>& matrix) {
    return GaussianElimination(matrix).rank();
}
template<class T>T MatrixDeterminant(const Matrix<T>& matrix) {
    auto result=GaussianElimination(matrix);
    if(result.rank()!=matrix.rows())return T{0};
    T determinant{1};for(const auto& pivot:result.pivots)determinant*=pivot;
    return (result.row_swaps&1)?T{0}-determinant:determinant;
}
template<class T>std::optional<Matrix<T>> MatrixInverse(const Matrix<T>& matrix) {
    const auto n=matrix.rows();
    if(n>std::numeric_limits<std::size_t>::max()/2)throw std::length_error("MatrixInverse: dimensions overflow");
    Matrix<T> augmented(n,n*2);
    for(std::size_t i=0;i<n;++i){auto row=augmented.row(i);const auto source=matrix.row(i);std::copy(source.begin(),source.end(),row.begin());row[n+i]=T{1};}
    auto elimination=reinsirk::detail::field_eliminate(std::move(augmented),n,true);
    if(elimination.rank()!=n)return std::nullopt;
    Matrix<T> inverse(n,n);
    for(std::size_t i=0;i<n;++i){const auto row=elimination.matrix.row(i);std::copy(row.begin()+static_cast<std::ptrdiff_t>(n),row.end(),inverse.row(i).begin());}
    return inverse;
}
template<class T>
std::optional<LinearSystemResult<T>> SolveLinearSystem(const Matrix<T>& matrix,const std::vector<T>& rhs) {
    const auto m=matrix.rows(),n=matrix.cols();
    if(n==std::numeric_limits<std::size_t>::max())throw std::length_error("SolveLinearSystem: dimensions overflow");
    Matrix<T> augmented(m,n+1);
    for(std::size_t i=0;i<m;++i){auto row=augmented.row(i);const auto source=matrix.row(i);std::copy(source.begin(),source.end(),row.begin());row[n]=rhs[i];}
    auto elimination=reinsirk::detail::field_eliminate(std::move(augmented),n,true);
    const auto rank=elimination.rank();
    for(std::size_t i=rank;i<m;++i)if(elimination.matrix.row(i)[n]!=T{0})return std::nullopt;
    LinearSystemResult<T> result{std::vector<T>(n,T{0}),Matrix<T>(n-rank,n),std::move(elimination.pivot_columns)};
    std::vector<std::uint8_t> pivot(n,0);
    for(std::size_t i=0;i<rank;++i){const auto column=result.pivot_columns[i];pivot[column]=1;result.particular[column]=elimination.matrix.row(i)[n];}
    std::size_t basis=0;
    for(std::size_t column=0;column<n;++column) {
        if(pivot[column])continue;
        auto vector=result.kernel.row(basis++);vector[column]=T{1};
        for(std::size_t i=0;i<rank;++i)vector[result.pivot_columns[i]]=T{0}-elimination.matrix.row(i)[column];
    }
    return result;
}
#endif

// SPDX-License-Identifier: CC0-1.0
// 生成版: GCC・速度優先（入力検査を除外）。 所有・解放の省略は各APIの前提を参照。
// 生成元: Math/Fraction.cpp
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/fraction.md
//
// API一覧
// [Fraction]
// Fraction(n=0,d=1): int64_tの分子・分母から既約分数を作る。分母は正、0は0/1。O(log M)。
// numerator()/denominator()/sign()/is_integer(): 正規化済みの分子・分母・符号・整数判定。O(1)。
// 四則演算・複合代入・単項+/-: 厳密な既約結果を返す。整数との演算も可。O(log M)。
// ==, <=>: 厳密な等値・大小比較。O(1)。最終結果が表現できても中間積が大きい場合に対応。
// inverse()/abs(): 逆数・絶対値を返す。O(1)。0の逆数はdomain_error。
// floor()/ceil()/trunc(): 床・天井・0方向への整数丸めをint64_tで返す。O(1)。
// explicit浮動小数点変換: 分子/分母を対象の浮動小数点型で計算する。O(1)。
// <<, >>: n/dを出力。入力は整数またはn/d（/は分子の直後）。失敗時は値を保持。
// 0分母・0除算はdomain_error、既約結果の分子/正分母がint64_t範囲外ならoverflow_error。
// これらの数学的・表現上の保護はSKIP_RUNTIME_CHECKS時も有効。Mは整数の絶対値の上限。
// SIRKIT_FRACTION_DISABLE_INT128: GCC/Clangの128ビット拡張を使わず標準C++経路を選ぶ。

#include <bit>
#include <compare>
#include <concepts>
#include <cstdint>
#include <istream>
#include <limits>
#include <ostream>
#include <stdexcept>
#include <utility>

#ifndef SIRKIT_FRACTION_DETAIL_DEFINED
#define SIRKIT_FRACTION_DETAIL_DEFINED
namespace reinsirk::detail {

// 引数は0以上2^63以下。奇数化した正の値の差は絶対値が2^63未満。
constexpr std::uint64_t fraction_gcd(std::uint64_t a, std::uint64_t b) {
    if (a == 1 || b == 1) return 1;
    if (a == 0) return b;
    if (b == 0) return a;
    const auto common = std::countr_zero(a | b);
    a >>= std::countr_zero(a);
    b >>= std::countr_zero(b);
    while (a != b) {
        const auto diff = a - b;
        const auto shift = std::countr_zero(diff);
        const auto low = a < b ? a : b;
        const auto mag = diff < (std::uint64_t{1} << 63) ? diff : 0 - diff;
        a = mag >> shift;
        b = low;
    }
    return a << common;
}

struct FractionWide {
#if defined(__SIZEOF_INT128__) && !defined(SIRKIT_FRACTION_DISABLE_INT128)
    __extension__ using Storage = unsigned __int128;
    Storage value = 0;
    constexpr FractionWide(std::uint64_t x = 0) : value(x) {}
    static constexpr FractionWide product(std::uint64_t a, std::uint64_t b) {
        FractionWide r;
        r.value = Storage(a) * b;
        return r;
    }
    friend constexpr FractionWide operator+(FractionWide a, FractionWide b) {
        a.value += b.value;
        return a;
    }
    friend constexpr FractionWide operator-(FractionWide a, FractionWide b) {
        a.value -= b.value;
        return a;
    }
    constexpr auto operator<=>(const FractionWide&) const = default;
    constexpr std::uint64_t low() const { return static_cast<std::uint64_t>(value); }
    constexpr bool fits(std::uint64_t bound) const { return value <= bound; }
    constexpr std::pair<FractionWide, std::uint64_t> divmod(std::uint64_t d) const {
        FractionWide q;
        q.value = value / d;
        return {q, static_cast<std::uint64_t>(value % d)};
    }
#else
    std::uint64_t hi = 0, lo = 0;
    constexpr FractionWide(std::uint64_t x = 0) : lo(x) {}
    static constexpr FractionWide product(std::uint64_t a, std::uint64_t b) {
        constexpr std::uint64_t mask = 0xffffffff;
        const auto a0 = a & mask, a1 = a >> 32;
        const auto b0 = b & mask, b1 = b >> 32;
        const auto t0 = a0 * b0;
        const auto t1 = a1 * b0 + (t0 >> 32);
        const auto t2 = a0 * b1 + (t1 & mask);
        FractionWide r;
        r.hi = a1 * b1 + (t1 >> 32) + (t2 >> 32);
        r.lo = (t2 << 32) | (t0 & mask);
        return r;
    }
    friend constexpr FractionWide operator+(FractionWide a, FractionWide b) {
        const auto old = a.lo;
        a.lo += b.lo;
        a.hi += b.hi + (a.lo < old);
        return a;
    }
    friend constexpr FractionWide operator-(FractionWide a, FractionWide b) {
        const auto old = a.lo;
        a.lo -= b.lo;
        a.hi -= b.hi + (old < b.lo);
        return a;
    }
    constexpr auto operator<=>(const FractionWide&) const = default;
    constexpr std::uint64_t low() const { return lo; }
    constexpr bool fits(std::uint64_t bound) const { return hi == 0 && lo <= bound; }
    constexpr std::pair<FractionWide, std::uint64_t> divmod(std::uint64_t d) const {
        if (hi == 0) return {FractionWide(lo / d), lo % d};
        FractionWide q;
        q.hi = hi / d;
        auto rem = hi % d;
        // 呼び出し側では1 <= d <= 2^63。余りを1bit伸ばしてもuint64_tに収まる。
        for (int bit = 63; bit >= 0; --bit) {
            rem = (rem << 1) | ((lo >> bit) & 1);
            if (rem >= d) {
                rem -= d;
                q.lo |= std::uint64_t{1} << bit;
            }
        }
        return {q, rem};
    }
#endif
};

constexpr std::uint64_t fraction_magnitude(std::int64_t x) {
    const auto u = static_cast<std::uint64_t>(x);
    return x < 0 ? std::uint64_t{0} - u : u;
}

} // namespace reinsirk::detail
#endif

#ifndef SIRKIT_FRACTION_DEFINED
#define SIRKIT_FRACTION_DEFINED
class Fraction {
    using Wide = reinsirk::detail::FractionWide;
    std::int64_t num_ = 0, den_ = 1;
    static constexpr auto max_ = static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max());

    static constexpr std::uint64_t magnitude(std::int64_t n) {
        return reinsirk::detail::fraction_magnitude(n);
    }
    static constexpr Fraction result(Wide n, Wide d, bool negative) {
        if (!n.fits(max_ + static_cast<unsigned>(negative)) || !d.fits(max_))
            throw std::overflow_error("Fraction: result out of int64_t range");
        Fraction r;
        const auto u = n.low();
        r.num_ = negative && u != 0 ? -static_cast<std::int64_t>(u - 1) - 1
                                    : static_cast<std::int64_t>(u);
        r.den_ = static_cast<std::int64_t>(d.low());
        return r;
    }
    static constexpr Fraction combine(const Fraction& a, const Fraction& b, bool subtract) {
        const auto da = static_cast<std::uint64_t>(a.den_);
        const auto db = static_cast<std::uint64_t>(b.den_);
        std::uint64_t g;
        Wide left, right;
        if (da == db) {
            g = da;
            left = Wide(magnitude(a.num_));
            right = Wide(magnitude(b.num_));
        } else {
            g = reinsirk::detail::fraction_gcd(da, db);
            left = Wide::product(magnitude(a.num_), db / g);
            right = Wide::product(magnitude(b.num_), da / g);
        }
        bool negative = a.num_ < 0;
        const bool right_negative = (b.num_ < 0) != subtract;
        Wide n;
        if (negative == right_negative) n = left + right;
        else if (left >= right) n = left - right;
        else { n = right - left; negative = right_negative; }
        if (n == Wide{}) return {};
        // 各分数は既約なので、和の分子との追加の共通因子はgの約数だけ。
        const auto h = g == 1 ? 1 : reinsirk::detail::fraction_gcd(n.divmod(g).second, g);
        if (h != 1) n = n.divmod(h).first;
        return result(n, Wide::product(da / g, db / h), negative);
    }

public:
    constexpr Fraction() = default;
    constexpr Fraction(std::int64_t n, std::int64_t d = 1) {
        if (d == 0) throw std::domain_error("Fraction: zero denominator");
        if (d == 1) { num_ = n; return; }
        if (n == 0) return;
        auto u = magnitude(n), v = magnitude(d);
        const auto g = reinsirk::detail::fraction_gcd(u, v);
        if (g == 1 && d > 0) { num_ = n; den_ = d; return; }
        if (g != 1) { u /= g; v /= g; }
        *this = result(Wide(u), Wide(v), (n < 0) != (d < 0));
    }
    constexpr std::int64_t numerator() const noexcept { return num_; }
    constexpr std::int64_t denominator() const noexcept { return den_; }
    constexpr int sign() const noexcept { return (num_ > 0) - (num_ < 0); }
    constexpr bool is_integer() const noexcept { return den_ == 1; }
    constexpr std::int64_t trunc() const noexcept { return num_ / den_; }
    constexpr std::int64_t floor() const noexcept { return trunc() - (num_ % den_ < 0); }
    constexpr std::int64_t ceil() const noexcept { return trunc() + (num_ % den_ > 0); }
    constexpr Fraction inverse() const {
        if (num_ == 0) throw std::domain_error("Fraction: inverse of zero");
        return result(Wide(static_cast<std::uint64_t>(den_)), Wide(magnitude(num_)), num_ < 0);
    }
    constexpr Fraction abs() const {
        return result(Wide(magnitude(num_)), Wide(static_cast<std::uint64_t>(den_)), false);
    }
    template<std::floating_point T>
    explicit constexpr operator T() const noexcept { return static_cast<T>(num_) / static_cast<T>(den_); }
    constexpr Fraction operator+() const noexcept { return *this; }
    constexpr Fraction operator-() const {
        return result(Wide(magnitude(num_)), Wide(static_cast<std::uint64_t>(den_)), num_ > 0);
    }
    friend constexpr Fraction operator+(const Fraction& a, const Fraction& b) { return combine(a, b, false); }
    friend constexpr Fraction operator-(const Fraction& a, const Fraction& b) { return combine(a, b, true); }
    friend constexpr Fraction operator*(const Fraction& a, const Fraction& b) {
        if (a.num_ == 0 || b.num_ == 0) return {};
        const auto na = magnitude(a.num_), nb = magnitude(b.num_);
        const auto da = static_cast<std::uint64_t>(a.den_), db = static_cast<std::uint64_t>(b.den_);
        const auto g = reinsirk::detail::fraction_gcd(na, db), h = reinsirk::detail::fraction_gcd(nb, da);
        return result(Wide::product(na / g, nb / h), Wide::product(da / h, db / g), (a.num_ < 0) != (b.num_ < 0));
    }
    friend constexpr Fraction operator/(const Fraction& a, const Fraction& b) {
        if (b.num_ == 0) throw std::domain_error("Fraction: division by zero");
        if (a.num_ == 0) return {};
        const auto na = magnitude(a.num_), nb = magnitude(b.num_);
        const auto da = static_cast<std::uint64_t>(a.den_), db = static_cast<std::uint64_t>(b.den_);
        const auto g = reinsirk::detail::fraction_gcd(na, nb), h = reinsirk::detail::fraction_gcd(da, db);
        return result(Wide::product(na / g, db / h), Wide::product(da / h, nb / g), (a.num_ < 0) != (b.num_ < 0));
    }
    constexpr Fraction& operator+=(const Fraction& b) { return *this = *this + b; }
    constexpr Fraction& operator-=(const Fraction& b) { return *this = *this - b; }
    constexpr Fraction& operator*=(const Fraction& b) { return *this = *this * b; }
    constexpr Fraction& operator/=(const Fraction& b) { return *this = *this / b; }
    constexpr bool operator==(const Fraction&) const = default;
    constexpr std::strong_ordering operator<=>(const Fraction& b) const {
#if defined(__SIZEOF_INT128__) && !defined(SIRKIT_FRACTION_DISABLE_INT128)
        if (den_ == b.den_) return num_ <=> b.num_;
        __extension__ using SignedWide = __int128;
        const auto left = static_cast<SignedWide>(num_) * b.den_;
        const auto right = static_cast<SignedWide>(b.num_) * den_;
        return left <=> right;
#else
        if (den_ == b.den_) return num_ <=> b.num_;
        if ((num_ < 0) != (b.num_ < 0)) return num_ <=> b.num_;
        const auto left = Wide::product(magnitude(num_), static_cast<std::uint64_t>(b.den_));
        const auto right = Wide::product(magnitude(b.num_), static_cast<std::uint64_t>(den_));
        return num_ < 0 ? right <=> left : left <=> right;
#endif
    }
    friend std::ostream& operator<<(std::ostream& out, const Fraction& x) {
        return out << x.num_ << '/' << x.den_;
    }
    friend std::istream& operator>>(std::istream& in, Fraction& x) {
        std::int64_t n = 0, d = 1;
        if (!(in >> n)) return in;
        if (!in.eof() && in.peek() == '/') {
            in.get();
            if (!(in >> d)) return in;
        }
        try { x = Fraction(n, d); }
        catch (const std::domain_error&) { in.setstate(std::ios::failbit); }
        catch (const std::overflow_error&) { in.setstate(std::ios::failbit); }
        return in;
    }
};
#endif

#include <iostream>
#include <vector>
int main(){
    const Matrix<Fraction> a{{1,2},{3,5}};
    const auto reduced=GaussianElimination(a,true);
    std::cout<<reduced.rank()<<' '<<MatrixDeterminant(a)<<'\n'; // 2 -1/1
    const auto inverse=MatrixInverse(a);
    std::cout<<(inverse.has_value()&&a*(*inverse)==MatrixIdentity<Fraction>(2))<<'\n'; // 1
    const Matrix<Fraction> equation{{1,2,3}};
    const std::vector<Fraction> rhs{4};
    const auto solution=SolveLinearSystem(equation,rhs);
    std::cout<<solution->kernel.rows()<<' '<<(MatrixApply(equation,solution->particular)==rhs)<<'\n'; // 2 1
    for(const auto&x:solution->particular)std::cout<<x<<' '; // 4/1 0/1 0/1
    std::cout<<'\n';
    for(std::size_t i=0;i<solution->kernel.rows();++i){for(const auto&x:solution->kernel.row(i))std::cout<<x<<' ';std::cout<<'\n';}
    // -2/1 1/1 0/1 / -3/1 0/1 1/1
    std::cout<<MatrixRank(Matrix<Fraction>(0,3))<<' '<<MatrixDeterminant(Matrix<Fraction>(0,0))<<'\n'; // 0 1/1
}
