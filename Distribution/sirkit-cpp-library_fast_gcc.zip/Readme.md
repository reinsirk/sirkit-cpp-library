# sirkit-cpp-library / GCC / Fast

入力検査を除き、専用の高速実装は領域/格納値の破棄・解放も省きます。各ファイル冒頭の前提を確認してください。

[使い方と通常版との違い](Document/fast_variants.md)・[資料一覧](Document/README.md)・[使用例](Examples)を参照。

提出用コードはVerify/current/submissionsにあります。この配布版へ通常版のオンラインACは転記していません。
