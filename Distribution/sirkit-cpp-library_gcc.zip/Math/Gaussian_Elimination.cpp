// SPDX-License-Identifier: CC0-1.0
// 生成版: GCC用。
// 生成元: Math/Gaussian_Elimination.cpp
// 参考（用途・Verify問題）: https://nyaannyaan.github.io/library/matrix/matrix.hpp
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/matrix.md
//
// API一覧
// 以下の消去は正確な体Tが前提。Mint等は利用側が用意する。整数型・一般の合成数法・浮動小数点は対象外。
// GaussianElimination(a,reduced=false): 値で受け取った行列を行基本変形。元のlvalueは変更せず結果を返す。
// GaussianEliminationResult<T>: matrixはピボット1の階段形、pivot_columns/pivotsは列と正規化前の値、row_swapsは交換数。
// reduced=trueなら各ピボットの上も消去する。rank()はピボット数をO(1)で返す。
// rows=m,cols=nとし消去はO(m*n*min(m,n))時間・O(m*n)所有領域。0行・0列・矩形・特異も可。
// MatrixRank(a): 体上の階数。MatrixDeterminant(a): 正方行列の行列式、0x0はT{1}。消去と同計算量。
// MatrixInverse(a): 正方行列の逆行列をoptionalで返す。特異はnullopt、0x0は空の単位行列。O(n³)時間・O(n²)領域。
// SolveLinearSystem(a,b): a*x=bの一解と核の基底をoptionalで返す。不能ならnullopt、b.size()==a.rows()が前提。
// LinearSystemResult<T>: particularは長さnの一解、kernelは各行が核基底（列数n）、pivot_columnsはピボット列。
// SolveはO(m*(n+1)*(1+min(m,n))+n²)時間・O(m*(n+1)+n²)領域。0行では全空間、0列ではbが零のときだけ空の一解。
// 非零ピボットの逆数が1を作らなければdomain_error。これは係数型が体であること全体を検証するものではない。
// 0判定・非可逆ピボットの保護・内部容量上限はSKIP_RUNTIME_CHECKSでも維持する。
//
// [同梱Matrix]
// Matrix<T>: 行優先の連続vectorで所有する行列。Tはコピー可能で0/1構築・必要な環演算を提供する。
// 計算量はTの演算・コピーをO(1)として数える。
// Matrix()/Matrix(r,c,value=T{0}): 0x0/指定形状の一様行列。O(1)/O(r*c)時間・領域。
// Matrix(r,c,vector<T>): 値で受け取ったvectorを所有。move時O(1)、copy時O(r*c)。行リスト{{...},...}はO(r*c)でコピー。
// 行リストは全行同じ長さ、flat vectorはr*c要素。0行・0列も可。内部容量上限は検査省略時も維持。
// rows()/cols()/size()/empty(): 行数/列数/全要素数/要素数0かをO(1)で返す。
// operator()(r,c): 要素の参照。row(r): 行の非所有span。values(): 全値の非所有span。各O(1)。
// rowの列添字はspanと同じく範囲内を渡す。行列の代入・swap・破棄で非所有参照は無効になる。
// copy/move/代入/swap: 独立コピー/所有移譲。コピーO(r*c)、move/swapはO(1)、移動元は0x0。
// +=/-=/+/-: 同形行列の加減。O(r*c)。==/!=は形状と値を比較する。
// */*=: (r,k)*(k,c)の行列積。O(r*c*(1+k))時間・O(r*c)追加領域。入力は変更しない（*=は左辺を更新）。
// transposed(): 転置の独立コピー。O(r*c)時間・領域。assign(r,c,value): 新しい一様行列へ置換する。
// MatrixIdentity<T>(n): nxn単位行列。O(n²)。MatrixPower(a,k): 正方行列の非負整数乗、O(n³ log(k+2))。
// MatrixApply(a,x): a*xの列ベクトルを返す。O(rows*(1+cols))時間・O(rows)領域。
// boolには専用のGF2係数型等を用意する。係数演算は正確な環の演算が前提。固定幅整数の演算オーバーフローや浮動小数点誤差は利用側で管理する。

// GCC/x86のuint32_t行列積は、対応CPUでAVX2を使う。unsignedの積と加算は通常版と同じmod 2^32。
// SIRKIT_DISABLE_SIMDで専用実装とCPU判定を除外する。小さい行列・他の型・非対応CPU/コンパイラは標準ループ。

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <initializer_list>
#include <span>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>
#include <bit>
#if (!defined(SIRKIT_DISABLE_SIMD)) && ((defined(__x86_64__)) || (defined(__i386__)))
#include <immintrin.h>
#ifndef SIRKIT_MATRIX_U32_SIMD_DETAIL_DEFINED
#define SIRKIT_MATRIX_U32_SIMD_DETAIL_DEFINED
namespace reinsirk::detail {
inline bool matrix_u32_avx2_available() noexcept { return __builtin_cpu_supports("avx2")!=0; }
__attribute__((target("avx2"))) inline void matrix_u32_tiled_avx2(
    const std::uint32_t* left,const std::uint32_t* right,std::uint32_t* output,
    std::size_t rows,std::size_t inner,std::size_t columns) noexcept {
    constexpr std::size_t tile=32;
    const auto vector_end=columns-columns%8;
    for(std::size_t row_begin=0;row_begin<rows;) {
        const auto row_end=row_begin+std::min(std::size_t{4},rows-row_begin);
        for(std::size_t begin=0;begin<inner;) {
            const auto end=begin+std::min(tile,inner-begin);
            for(std::size_t i=row_begin;i<row_end;++i) {
            auto* destination=output+i*columns;
            std::size_t j=0;
            for(;vector_end-j>=32;j+=32) {
                __m256i s0,s1,s2,s3;
                if(begin==0) {s0=_mm256_setzero_si256();s1=s0;s2=s0;s3=s0;}
                else {
                    s0=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(destination+j));
                    s1=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(destination+j+8));
                    s2=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(destination+j+16));
                    s3=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(destination+j+24));
                }
                for(std::size_t k=begin;k<end;++k) {
                    const auto coefficient=_mm256_set1_epi32(std::bit_cast<std::int32_t>(left[i*inner+k]));
                    const auto* input=right+k*columns+j;
                    s0=_mm256_add_epi32(s0,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(input))));
                    s1=_mm256_add_epi32(s1,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(input+8))));
                    s2=_mm256_add_epi32(s2,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(input+16))));
                    s3=_mm256_add_epi32(s3,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(input+24))));
                }
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j),s0);
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j+8),s1);
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j+16),s2);
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j+24),s3);
            }
            for(;j<vector_end;j+=8) {
                auto sum=begin==0?_mm256_setzero_si256():_mm256_loadu_si256(reinterpret_cast<const __m256i*>(destination+j));
                for(std::size_t k=begin;k<end;++k) {
                    const auto coefficient=_mm256_set1_epi32(std::bit_cast<std::int32_t>(left[i*inner+k]));
                    sum=_mm256_add_epi32(sum,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(right+k*columns+j))));
                }
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j),sum);
            }
            for(;j<columns;++j) {
                std::uint32_t sum=begin==0?0:destination[j];
                for(std::size_t k=begin;k<end;++k)sum+=left[i*inner+k]*right[k*columns+j];
                destination[j]=sum;
            }
            }
            begin=end;
        }
        row_begin=row_end;
    }
}
__attribute__((target("avx2"))) inline void matrix_u32_accumulate_avx2(
    const std::uint32_t* left,const std::uint32_t* right,std::uint32_t* output,
    std::size_t rows,std::size_t inner,std::size_t columns) noexcept {
    const auto vector_end=columns-columns%8;
    for(std::size_t i=0;i<rows;++i) {
        auto* destination=output+i*columns;
        std::size_t j=0;
        for(;vector_end-j>=32;j+=32) {
            auto s0=_mm256_setzero_si256(),s1=s0,s2=s0,s3=s0;
            for(std::size_t k=0;k<inner;++k) {
                const auto coefficient=_mm256_set1_epi32(std::bit_cast<std::int32_t>(left[i*inner+k]));
                const auto* source=right+k*columns+j;
                s0=_mm256_add_epi32(s0,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(source))));
                s1=_mm256_add_epi32(s1,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(source+8))));
                s2=_mm256_add_epi32(s2,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(source+16))));
                s3=_mm256_add_epi32(s3,_mm256_mullo_epi32(coefficient,_mm256_loadu_si256(reinterpret_cast<const __m256i*>(source+24))));
            }
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j),s0);
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j+8),s1);
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j+16),s2);
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j+24),s3);
        }
        for(;j<vector_end;j+=8) {
            auto sum=_mm256_setzero_si256();
            for(std::size_t k=0;k<inner;++k) {
                const auto coefficient=_mm256_set1_epi32(std::bit_cast<std::int32_t>(left[i*inner+k]));
                const auto values=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(right+k*columns+j));
                sum=_mm256_add_epi32(sum,_mm256_mullo_epi32(coefficient,values));
            }
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(destination+j),sum);
        }
        for(;j<columns;++j) {
            std::uint32_t sum=0;
            for(std::size_t k=0;k<inner;++k)sum+=left[i*inner+k]*right[k*columns+j];
            destination[j]=sum;
        }
    }
}
}
#endif
#endif

#ifndef SIRKIT_MATRIX_DEFINED
#define SIRKIT_MATRIX_DEFINED
template<class T>
class Matrix {
    static_assert(!std::is_same_v<T,bool>,"Matrix<bool>: provide a coefficient type instead of vector<bool>");
    std::size_t rows_=0,columns_=0;
    std::vector<T> values_;
    static std::size_t area(std::size_t rows,std::size_t columns) {
        if(columns&&rows>std::vector<T>{}.max_size()/columns)
            throw std::length_error("Matrix: dimensions overflow");
        return rows*columns;
    }
public:
    using value_type=T;
    using size_type=std::size_t;
    Matrix()=default;
    Matrix(size_type rows,size_type columns,const T& value=T{0})
        :rows_(rows),columns_(columns),values_(area(rows,columns),value){}
    Matrix(size_type rows,size_type columns,std::vector<T> values)
        :rows_(rows),columns_(columns),values_(std::move(values)) {
        const auto expected=area(rows,columns);
#ifndef SKIP_RUNTIME_CHECKS
        if(values_.size()!=expected)throw std::invalid_argument("Matrix: flat size mismatch");
#else
        (void)expected;
#endif
    }
    Matrix(std::initializer_list<std::initializer_list<T>> rows)
        :rows_(rows.size()),columns_(rows.size()?rows.begin()->size():0) {
        values_.reserve(area(rows_,columns_));
        for(const auto& row:rows) {
#ifndef SKIP_RUNTIME_CHECKS
            if(row.size()!=columns_)throw std::invalid_argument("Matrix: ragged rows");
#endif
            values_.insert(values_.end(),row.begin(),row.end());
        }
    }
    Matrix(const Matrix&)=default;
    Matrix(Matrix&& other) noexcept
        :rows_(std::exchange(other.rows_,0)),columns_(std::exchange(other.columns_,0)),
         values_(std::move(other.values_)) { other.values_.clear(); }
    Matrix& operator=(Matrix other) noexcept { swap(other);return *this; }
    void swap(Matrix& other) noexcept {
        std::swap(rows_,other.rows_);std::swap(columns_,other.columns_);values_.swap(other.values_);
    }
    friend void swap(Matrix& a,Matrix& b) noexcept { a.swap(b); }
    size_type rows()const noexcept{return rows_;}
    size_type cols()const noexcept{return columns_;}
    size_type size()const noexcept{return values_.size();}
    bool empty()const noexcept{return values_.empty();}
    std::span<T> values()noexcept{return {values_.data(),values_.size()};}
    std::span<const T> values()const noexcept{return {values_.data(),values_.size()};}
    std::span<T> row(size_type index) {
#ifndef SKIP_RUNTIME_CHECKS
        if(index>=rows_)throw std::out_of_range("Matrix::row: index");
#endif
        const auto offset=index*columns_;
        return {offset?values_.data()+offset:values_.data(),columns_};
    }
    std::span<const T> row(size_type index)const {
#ifndef SKIP_RUNTIME_CHECKS
        if(index>=rows_)throw std::out_of_range("Matrix::row: index");
#endif
        const auto offset=index*columns_;
        return {offset?values_.data()+offset:values_.data(),columns_};
    }
    T& operator()(size_type row_index,size_type column_index) {
#ifndef SKIP_RUNTIME_CHECKS
        if(row_index>=rows_||column_index>=columns_)throw std::out_of_range("Matrix: index");
#endif
        return values_[row_index*columns_+column_index];
    }
    const T& operator()(size_type row_index,size_type column_index)const {
#ifndef SKIP_RUNTIME_CHECKS
        if(row_index>=rows_||column_index>=columns_)throw std::out_of_range("Matrix: index");
#endif
        return values_[row_index*columns_+column_index];
    }
    void assign(size_type rows,size_type columns,const T& value=T{0}) {
        Matrix next(rows,columns,value);swap(next);
    }
    Matrix transposed()const {
        Matrix result(columns_,rows_);
        if(values_.empty())return result;
        for(size_type i=0;i<rows_;++i)
            for(size_type j=0;j<columns_;++j)result.values_[j*rows_+i]=values_[i*columns_+j];
        return result;
    }
    Matrix& operator+=(const Matrix& other) {
#ifndef SKIP_RUNTIME_CHECKS
        if(rows_!=other.rows_||columns_!=other.columns_)throw std::invalid_argument("Matrix: shape mismatch");
#endif
        for(size_type i=0;i<values_.size();++i)values_[i]+=other.values_[i];
        return *this;
    }
    Matrix& operator-=(const Matrix& other) {
#ifndef SKIP_RUNTIME_CHECKS
        if(rows_!=other.rows_||columns_!=other.columns_)throw std::invalid_argument("Matrix: shape mismatch");
#endif
        for(size_type i=0;i<values_.size();++i)values_[i]-=other.values_[i];
        return *this;
    }
    Matrix& operator*=(const Matrix& other);
    friend Matrix operator+(Matrix a,const Matrix& b){a+=b;return a;}
    friend Matrix operator-(Matrix a,const Matrix& b){a-=b;return a;}
    bool operator==(const Matrix&)const=default;
};
#endif
#ifndef SIRKIT_MATRIX_ARITHMETIC_DEFINED
#define SIRKIT_MATRIX_ARITHMETIC_DEFINED
template<class T>
Matrix<T> operator*(const Matrix<T>& a,const Matrix<T>& b) {
#ifndef SKIP_RUNTIME_CHECKS
    if(a.cols()!=b.rows())throw std::invalid_argument("Matrix product: shape mismatch");
#endif
    Matrix<T> result(a.rows(),b.cols());
    if(result.empty()||a.cols()==0)return result;
#if (!defined(SIRKIT_DISABLE_SIMD)) && ((defined(__x86_64__)) || (defined(__i386__)))
    if constexpr(std::is_same_v<T,std::uint32_t>) {
        if(b.cols()>=16&&a.size()>=64&&reinsirk::detail::matrix_u32_avx2_available()) {
            // 小さい右行列と短い内積は従来の全内積累積を維持する。
            if(a.cols()>64 && b.size()>262144)
                reinsirk::detail::matrix_u32_tiled_avx2(a.values().data(),b.values().data(),result.values().data(),a.rows(),a.cols(),b.cols());
            else
            reinsirk::detail::matrix_u32_accumulate_avx2(a.values().data(),b.values().data(),result.values().data(),a.rows(),a.cols(),b.cols());
            return result;
        }
    }
#endif

    for(std::size_t i=0;i<a.rows();++i) {
        auto destination=result.row(i);const auto left=a.row(i);
        for(std::size_t k=0;k<a.cols();++k) {
            const T multiplier=left[k];const auto right=b.row(k);
            for(std::size_t j=0;j<b.cols();++j)destination[j]+=multiplier*right[j];
        }
    }
    return result;
}
template<class T>Matrix<T>& Matrix<T>::operator*=(const Matrix& other) {
    auto result=*this*other;swap(result);return *this;
}
template<class T>Matrix<T> MatrixIdentity(std::size_t n) {
    Matrix<T> result(n,n);for(std::size_t i=0;i<n;++i)result.row(i)[i]=T{1};return result;
}
template<class T>Matrix<T> MatrixPower(Matrix<T> base,std::uint64_t exponent) {
#ifndef SKIP_RUNTIME_CHECKS
    if(base.rows()!=base.cols())throw std::invalid_argument("MatrixPower: non-square");
#endif
    auto result=MatrixIdentity<T>(base.rows());
    while(exponent){if(exponent&1)result*=base;exponent>>=1;if(exponent)base*=base;}
    return result;
}
template<class T>std::vector<T> MatrixApply(const Matrix<T>& matrix,const std::vector<T>& vector) {
#ifndef SKIP_RUNTIME_CHECKS
    if(matrix.cols()!=vector.size())throw std::invalid_argument("MatrixApply: shape mismatch");
#endif
    std::vector<T> result(matrix.rows(),T{0});
    for(std::size_t i=0;i<matrix.rows();++i){const auto row=matrix.row(i);for(std::size_t j=0;j<matrix.cols();++j)result[i]+=row[j]*vector[j];}
    return result;
}
#endif

#include <cstddef>
#include <limits>
#include <optional>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>
#ifndef SIRKIT_GAUSSIAN_RESULT_DEFINED
#define SIRKIT_GAUSSIAN_RESULT_DEFINED
template<class T>struct GaussianEliminationResult {
    Matrix<T> matrix;
    std::vector<std::size_t> pivot_columns;
    std::vector<T> pivots;
    std::size_t row_swaps=0;
    std::size_t rank()const noexcept{return pivot_columns.size();}
};
template<class T>struct LinearSystemResult {
    std::vector<T> particular;
    Matrix<T> kernel;
    std::vector<std::size_t> pivot_columns;
};
#endif
#ifndef SIRKIT_GAUSSIAN_DETAIL_DEFINED
#define SIRKIT_GAUSSIAN_DETAIL_DEFINED
namespace reinsirk::detail {
template<class T>
GaussianEliminationResult<T> field_eliminate(Matrix<T> matrix,std::size_t pivot_end,bool reduced) {
    static_assert(!std::is_integral_v<T>,"Gaussian elimination requires an exact field type, not an integer type");
    GaussianEliminationResult<T> result{std::move(matrix),{},{},0};
    auto& work=result.matrix;
    result.pivot_columns.reserve(std::min(work.rows(),pivot_end));
    result.pivots.reserve(std::min(work.rows(),pivot_end));
    for(std::size_t column=0;column<pivot_end&&result.rank()<work.rows();++column) {
        const auto rank=result.rank();std::size_t candidate=rank;
        while(candidate<work.rows()&&work.row(candidate)[column]==T{0})++candidate;
        if(candidate==work.rows())continue;
        auto pivot_row=work.row(rank);
        if(candidate!=rank) {
            auto other=work.row(candidate);
            for(std::size_t j=column;j<work.cols();++j)std::swap(pivot_row[j],other[j]);
            ++result.row_swaps;
        }
        const T pivot=pivot_row[column];
        result.pivot_columns.push_back(column);result.pivots.push_back(pivot);
        if(pivot!=T{1}) {
            const T inverse=T{1}/pivot;
            if(pivot*inverse!=T{1})throw std::domain_error("Gaussian elimination: non-invertible pivot");
            for(std::size_t j=column+1;j<work.cols();++j)pivot_row[j]*=inverse;
            pivot_row[column]=T{1};
        }
        const auto begin=reduced?std::size_t{0}:rank+1;
        for(std::size_t i=begin;i<work.rows();++i) {
            if(i==rank)continue;
            auto destination=work.row(i);const T factor=destination[column];
            if(factor==T{0})continue;
            for(std::size_t j=column+1;j<work.cols();++j)destination[j]-=factor*pivot_row[j];
            destination[column]=T{0};
        }
    }
    return result;
}
}
#endif
#ifndef SIRKIT_FIELD_GAUSSIAN_DEFINED
#define SIRKIT_FIELD_GAUSSIAN_DEFINED
template<class T>GaussianEliminationResult<T> GaussianElimination(Matrix<T> matrix,bool reduced=false) {
    const auto columns=matrix.cols();
    return reinsirk::detail::field_eliminate(std::move(matrix),columns,reduced);
}
template<class T>std::size_t MatrixRank(const Matrix<T>& matrix) {
    return GaussianElimination(matrix).rank();
}
template<class T>T MatrixDeterminant(const Matrix<T>& matrix) {
#ifndef SKIP_RUNTIME_CHECKS
    if(matrix.rows()!=matrix.cols())throw std::invalid_argument("MatrixDeterminant: non-square");
#endif
    auto result=GaussianElimination(matrix);
    if(result.rank()!=matrix.rows())return T{0};
    T determinant{1};for(const auto& pivot:result.pivots)determinant*=pivot;
    return (result.row_swaps&1)?T{0}-determinant:determinant;
}
template<class T>std::optional<Matrix<T>> MatrixInverse(const Matrix<T>& matrix) {
#ifndef SKIP_RUNTIME_CHECKS
    if(matrix.rows()!=matrix.cols())throw std::invalid_argument("MatrixInverse: non-square");
#endif
    const auto n=matrix.rows();
    if(n>std::numeric_limits<std::size_t>::max()/2)throw std::length_error("MatrixInverse: dimensions overflow");
    Matrix<T> augmented(n,n*2);
    for(std::size_t i=0;i<n;++i){auto row=augmented.row(i);const auto source=matrix.row(i);std::copy(source.begin(),source.end(),row.begin());row[n+i]=T{1};}
    auto elimination=reinsirk::detail::field_eliminate(std::move(augmented),n,true);
    if(elimination.rank()!=n)return std::nullopt;
    Matrix<T> inverse(n,n);
    for(std::size_t i=0;i<n;++i){const auto row=elimination.matrix.row(i);std::copy(row.begin()+static_cast<std::ptrdiff_t>(n),row.end(),inverse.row(i).begin());}
    return inverse;
}
template<class T>
std::optional<LinearSystemResult<T>> SolveLinearSystem(const Matrix<T>& matrix,const std::vector<T>& rhs) {
#ifndef SKIP_RUNTIME_CHECKS
    if(matrix.rows()!=rhs.size())throw std::invalid_argument("SolveLinearSystem: rhs size mismatch");
#endif
    const auto m=matrix.rows(),n=matrix.cols();
    if(n==std::numeric_limits<std::size_t>::max())throw std::length_error("SolveLinearSystem: dimensions overflow");
    Matrix<T> augmented(m,n+1);
    for(std::size_t i=0;i<m;++i){auto row=augmented.row(i);const auto source=matrix.row(i);std::copy(source.begin(),source.end(),row.begin());row[n]=rhs[i];}
    auto elimination=reinsirk::detail::field_eliminate(std::move(augmented),n,true);
    const auto rank=elimination.rank();
    for(std::size_t i=rank;i<m;++i)if(elimination.matrix.row(i)[n]!=T{0})return std::nullopt;
    LinearSystemResult<T> result{std::vector<T>(n,T{0}),Matrix<T>(n-rank,n),std::move(elimination.pivot_columns)};
    std::vector<std::uint8_t> pivot(n,0);
    for(std::size_t i=0;i<rank;++i){const auto column=result.pivot_columns[i];pivot[column]=1;result.particular[column]=elimination.matrix.row(i)[n];}
    std::size_t basis=0;
    for(std::size_t column=0;column<n;++column) {
        if(pivot[column])continue;
        auto vector=result.kernel.row(basis++);vector[column]=T{1};
        for(std::size_t i=0;i<rank;++i)vector[result.pivot_columns[i]]=T{0}-elimination.matrix.row(i)[column];
    }
    return result;
}
#endif
