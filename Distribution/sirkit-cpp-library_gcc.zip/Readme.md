# sirkit-cpp-library / GCC

このコンパイラで不要な分岐を除いた通常版です。CPU判定と設定マクロは保持します。

[使い方と通常版との違い](Document/fast_variants.md)・[資料一覧](Document/README.md)・[使用例](Examples)を参照。

提出用コードはVerify/current/submissionsにあります。この配布版へ通常版のオンラインACは転記していません。
