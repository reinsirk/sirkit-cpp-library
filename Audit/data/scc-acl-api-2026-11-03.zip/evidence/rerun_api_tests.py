from pathlib import Path
import subprocess,json,os
D=Path('/tmp/sirkit_scc_acl_agent_20261103');R=Path('/home/reinsirk/Atcoder_Env');rows=[x for x in json.loads((D/'checks.json').read_text()) if x['test']!='scc_acl_api_test']
for cc,args in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  for test in ['scc_acl_api_test']:
   exe=D/f'{cc}_{int(skip)}_{test}'
   cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-fsanitize=address,undefined','-fno-omit-frame-pointer']
   if test=='scc_acl_api_test':cmd+=['-Wall','-Wextra','-Werror']
   if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
   cmd+=[str(R/f'Verify/current/tests/{test}.cpp'),'-o',str(exe)]
   p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,(cmd,p.stderr)
   p=subprocess.run(['taskset','-c','4',str(exe)],capture_output=True,text=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'})
   rows.append(dict(compiler=cc,skip=skip,test=test,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,command=cmd))
   (D/'checks.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
   print(cc,skip,test,p.returncode,p.stdout.strip(),flush=True);assert p.returncode==0 and not p.stderr,p.stderr
