from pathlib import Path
import subprocess,json,random,statistics,os,time,hashlib,shutil
D=Path('/tmp/sirkit_segtree_speed_20261102');names={'sum':'segment_tree','affine':'segment_tree_composite'}
for kind,id in names.items():
 for label in ['old','greedy']:
  cmd=['taskset','-c','2','/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-std=c++23','-O2',str(D/(id+'_'+label+'.cpp')),'-o',str(D/('clang_'+id+'_'+label))];subprocess.run(cmd,check=True)
print('CLANG BUILT',flush=True);rs=[];rng=random.Random(75019)
for compiler in ['gcc','clang']:
 for kind,id in names.items():
  for n in [32,4096,500000]:
   for mode in ['mixed','query','update','short']:
    for rep in range(11):
     labels=['old','control','greedy'];rng.shuffle(labels);checks=[]
     for label in labels:
      exe=D/(('clang_' if compiler=='clang' else '')+id+'_'+('old' if label=='control' else label));shutil.copyfile(exe,D/'active_final');(D/'active_final').chmod(0o700)
      with open(D/f'{kind}_{n}_{mode}.in','rb') as inp,open(D/'output','wb') as out:
       t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active_final')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-t
      ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rs.append({'compiler':compiler,'kind':kind,'n':n,'mode':mode,'label':label,'rep':rep,'user_ns':round(ru.ru_utime*1e9),'system_ns':round(ru.ru_stime*1e9),'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
     assert len(set(checks))==1
    ms={l:statistics.median(x['cpu_ns'] for x in rs if x['compiler']==compiler and x['kind']==kind and x['n']==n and x['mode']==mode and x['label']==l) for l in labels}
    print(compiler,kind,n,mode,{l:round(v/ms['old'],3) for l,v in ms.items()},flush=True);(D/'final_main_raw.json').write_text(json.dumps(rs))
