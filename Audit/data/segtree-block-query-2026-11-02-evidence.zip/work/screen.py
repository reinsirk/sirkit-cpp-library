from pathlib import Path
import json,subprocess,random,statistics,shutil,os,sys,time,hashlib
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_segtree_speed_20261102');s=(D/'before.hpp').read_text()
prod='''        S left = identity_, right = identity_;
        if (l == r) return left;
        // n<=INT_MAXなのでbase_+rもunsignedの範囲に収まる。
        unsigned first = static_cast<unsigned>(base_) + static_cast<unsigned>(l);
        unsigned last = static_cast<unsigned>(base_) + static_cast<unsigned>(r);
        for (; first < last; first >>= 1, last >>= 1) {
            if (first & 1) left = std::invoke(op, left, data_[first++]);
            if (last & 1) right = std::invoke(op, data_[--last], right);
        }
        return std::invoke(op, left, right);'''
assert prod in s
flags='''        S left = identity_, right = identity_;
        bool has_left = false, has_right = false;
        unsigned first = static_cast<unsigned>(base_) + static_cast<unsigned>(l);
        unsigned last = static_cast<unsigned>(base_) + static_cast<unsigned>(r);
        for (; first < last; first >>= 1, last >>= 1) {
            if (first & 1) { if (has_left) left = std::invoke(op, left, data_[first++]); else { left = data_[first++]; has_left = true; } }
            if (last & 1) { if (has_right) right = std::invoke(op, data_[--last], right); else { right = data_[--last]; has_right = true; } }
        }
        if (!has_left) return right;
        if (!has_right) return left;
        return std::invoke(op, left, right);'''
greedy='''        if (l == r) return identity_;
        unsigned first = static_cast<unsigned>(base_) + static_cast<unsigned>(l);
        unsigned last = static_cast<unsigned>(base_) + static_cast<unsigned>(r);
        auto step = first & (~first + 1);
        if (step > last - first) {
            S result = data_[(last >> std::countr_zero(last)) - 1];
            last -= last & (~last + 1);
            while (first < last) {
                result = std::invoke(op, data_[(last >> std::countr_zero(last)) - 1], result);
                last -= last & (~last + 1);
            }
            return result;
        }
        S left = data_[first >> std::countr_zero(first)];
        first += step;
        while (first < last && (step = first & (~first + 1)) <= last - first) {
            left = std::invoke(op, left, data_[first >> std::countr_zero(first)]);
            first += step;
        }
        if (first == last) return left;
        S right = data_[(last >> std::countr_zero(last)) - 1];
        last -= last & (~last + 1);
        while (first < last) {
            right = std::invoke(op, data_[(last >> std::countr_zero(last)) - 1], right);
            last -= last & (~last + 1);
        }
        return std::invoke(op, left, right);'''
variants={'old':s,'idx32':s.replace('void update_ancestors(std::size_t p)','void update_ancestors(unsigned p)').replace('const auto p = base_ + static_cast<std::size_t>(i);','const unsigned p = static_cast<unsigned>(base_) + static_cast<unsigned>(i);').replace('return data_[base_ + static_cast<std::size_t>(i)];','return data_[static_cast<unsigned>(base_) + static_cast<unsigned>(i)];'),'flags':s.replace(prod,flags),'greedy':s.replace('#include <algorithm>','#include <algorithm>\n#include <bit>').replace(prod,greedy)}
level='''    void rebuild() {
        for (auto begin = base_ / 2; begin; begin >>= 1) {
            for (auto p = begin; p < 2 * begin; ++p)
                data_[p] = std::invoke(op, data_[2 * p], data_[2 * p + 1]);
        }
    }'''
a=s.index('    void rebuild() {');b=s.index('    void update_ancestors(',a);variants['levels']=s[:a]+level+'\n'+s[b:]
variants['greedy_idx32']=variants['idx32'].replace('#include <algorithm>','#include <algorithm>\n#include <bit>').replace(prod,greedy)
entries=[e for e in prepare_verify.collect() if e['id'] in ['segment_tree','segment_tree_composite']]
for k,v in variants.items():
 (D/(k+'.hpp')).write_text(v)
 for e in entries:
  code,_=prepare_verify.render(e,source_overrides={'DataStructure/Segment_Tree.cpp':v.encode()});src=D/(e['id']+'_'+k+'.cpp');src.write_bytes(code)
  subprocess.run(['taskset','-c','2','/usr/bin/g++','-std=c++23','-O2',str(src),'-o',str(D/(e['id']+'_'+k))],check=True)
print('BUILT',flush=True)
# deterministic generation mirrors both official operation forms, no task-specific main changes.
cases=[]
for kind in ['sum','affine']:
 for n,q in [(32,200000),(4096,300000),(500000,500000)]:
  for mode in ['mixed','query','update','short']:
   p=D/f'{kind}_{n}_{mode}.in';rng=random.Random(8751+n)
   with p.open('w') as f:
    f.write(f'{n} {q}\n')
    if kind=='sum':f.write(' '.join(str(rng.randrange(1000)) for _ in range(n))+'\n')
    else:
     for _ in range(n):f.write(f'{rng.randrange(998244353)} {rng.randrange(998244353)}\n')
    for i in range(q):
     if mode=='update' or(mode=='mixed' and rng.randrange(2)==0):
      if kind=='sum':f.write(f'0 {rng.randrange(n)} {rng.randrange(1000)}\n')
      else:f.write(f'0 {rng.randrange(n)} {rng.randrange(998244353)} {rng.randrange(998244353)}\n')
     else:
      if mode=='short':l=rng.randrange(n);r=min(n,l+rng.randrange(17))
      else:l=rng.randrange(n+1);r=rng.randrange(n+1);l,r=min(l,r),max(l,r)
      if kind=='sum':f.write(f'1 {l} {r}\n')
      else:f.write(f'1 {l} {r} {rng.randrange(998244353)}\n')
   cases.append({'kind':kind,'n':n,'q':q,'mode':mode,'path':str(p)})
print('INPUTS READY',flush=True);rng=random.Random(556819);rows=[]
for case in cases:
 for rep in range(5):
  labels=list(variants)+['control'];rng.shuffle(labels);checks=[]
  for label in labels:
   id='segment_tree' if case['kind']=='sum' else 'segment_tree_composite';exe=D/(id+'_'+('old' if label=='control' else label));shutil.copyfile(exe,D/'active_main');(D/'active_main').chmod(0o700)
   with open(case['path'],'rb') as inp,open(D/'output','wb') as out:
    t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active_main')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-t
   ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rows.append({**{k:v for k,v in case.items() if k!='path'},'label':label,'rep':rep,'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
  assert len(set(checks))==1,(case,checks)
 ms={k:statistics.median(r['cpu_ns'] for r in rows if r['kind']==case['kind'] and r['n']==case['n'] and r['mode']==case['mode'] and r['label']==k) for k in list(variants)+['control']}
 print(case['kind'],case['n'],case['mode'],{k:round(v/ms['old'],3) for k,v in ms.items()},flush=True);(D/'screen_raw.json').write_text(json.dumps(rows))
