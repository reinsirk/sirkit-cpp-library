# Segment Tree

固定長の列を完全二分木へ置き、点更新と半開区間の積を扱う。公開型は`segtree<S, op, e>`。`S op(S,S)`は結合的、`S e()`は左右の単位元を返すこと。可換性は不要で、文字列連結や行列積も左からの順序を保つ。関数名の代わりに同じ呼び出し形式の関数オブジェクトも指定できる。

型引数・コンストラクタ・操作名・引数と戻り値は[ACLのsegtree](https://atcoder.github.io/ac-library/production/document_ja/segtree.html)に合わせる。公開型はこのライブラリの方針に従いグローバルに置き、`atcoder::segtree`とは別の型である。同じ機能を別名で公開する型エイリアスは置かない。無効入力はACLのassertの代わりに例外で検査するため、失敗時の挙動まで同一ではない。

`segtree()`は空列、`segtree(int n)`はn個の単位元、`segtree(vector<S>)`は列から構築する。要素数は0以上で`int`に収まり、必要な領域を確保できること。演算・値のコピーをO(1)としてO(n+1)時間・領域で構築する。`set(int p,S x)`は点代入でO(log(n+1))。`get(int p)`と`all_prod()`はSの値をO(1)で返す。`prod(int l,int r)`は左からの区間積をO(log(n+1))で返し、空区間・空列の積は`e()`となる。

区間積では、葉番号の下位1bitが表す整列幅を使い、必要な節点へ直接進む。左端から区間内に収まる最大の整列ブロックを選び、左の累積値へ順番に結合する。次の左ブロックが右端を越えるときは、右端の下位1bitを落としながら残りのブロックを選び、右の累積値の前へ結合する。最初の節点は直接コピーし、単位元との積を作らない。左右の結合順を保つため、非可換演算でも左からの積になる。選ぶ節点数はO(log(n+1))、走査用の追加領域はO(1)。

`max_right<pred>(int l)`と`min_left<pred>(int r)`は`bool pred(S)`を使い、`int`の境界をO(log(n+1))で返す。`max_right(l,pred)`・`min_left(r,pred)`として関数オブジェクトを第2引数に渡す形式も使える。`pred(e())`が真であり、区間を延ばすと一度だけ真から偽へ移ることが必要。同じ値に同じ結果を返し、副作用を持たせない。検査を省かない場合は単位元に対する述語を一度確認するが、単調性を確認する全要素走査は行わない。

追加機能として、`size()`はintの要素数、`empty()`は空かどうかをO(1)で返す。`transform(int p,f)`は点を`f(現在値)`へ置換しO(log(n+1))。`values()`は列のコピー、`assign(values)`は再構築、`reset(int n)`はn個の単位元へ置換、`reset()`は現在の長さを単位元に戻す。旧列の破棄も含めO(旧n+n+1)。`clear()`は容量を保持して空へ戻し、`swap`は内容をO(1)で交換する。コピーは独立、移動元は空の列として使用可能。値のコピーや演算自体が例外を投げる場合、内容の強い保証は行わない。

通常は添字・区間・述語の単位元条件を低コストに確認し、`SKIP_RUNTIME_CHECKS`で除く。容量・添字計算のオーバーフロー対策と、vectorからの構築で要素数がintに収まることの確認は残す。

[使用例](../Examples/segment_tree_example.cpp)。数学的な参考は[AtCoder Algorithm Lecturesのモノイド設計](https://info.atcoder.jp/entry/algorithm_lectures/range_query_monoid_design)。実装はこのライブラリ用に組み立てたCC0コード。
