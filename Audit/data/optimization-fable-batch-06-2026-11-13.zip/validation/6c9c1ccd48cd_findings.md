# PrimeSieve 間引き列挙API候補

`for_each_prime_stride(first, step, f)`は0始まりの素数番号からstep個おきにf(uint64_t)を呼ぶ。stepは正、firstが個数以上なら呼ばない。first+stepを計算せず、UINT64_MAXの指定もwrapしない。既存API/所有/flagsはbyte一致のまま追加する。

std::popcountで出力対象のないwordを飛ばす。step<8では既存foreachを使い、step1/first0ではcounterも不要。新CPU専用コードは追加していない。

最終32構成と4つのExample実行が全成功。全limit0..2000×step1..200×first<step、word端、巨大first/step、zero-step例外、move-only callback、例外後の表、既存所有/故障を確認した。大表は既存foreach出力hashと照合した。

最終paired測定ではN5e8/a27がGCC111.129→98.286ms、Clang188.936→171.677ms、大aではGCC103.713→77.890ms、Clang173.621→145.305ms。Clangの絶対時間は以前と環境差があるため、同じrun内だけで比較する。

小a1はGCC7.159→7.238ms（+0.079ms/+1.1%、反復範囲重複）、Clangでは1.8%短縮した。全入力が一律に速くなるとは主張しない。Verify最大側の合法条件では利益があり、親がこの小差を含め採用判断する。

[SourceSHA・全raw・再現資料](final_report.json)。本体/Doc/Example/main候補を/tmpへ固定し、repoは変更していない。
