// SPDX-License-Identifier: CC0-1.0
#include SIEVE_SOURCE
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <memory>
#include <random>
#include <type_traits>
#include <vector>
static std::uint64_t checks=0,cases=0;
static void check(bool value){++checks;if(!value)std::abort();}
static std::vector<std::uint64_t> naive(std::size_t n){std::vector<bool> p(n+1,true);p[0]=false;if(n)p[1]=false;for(std::size_t i=2;i<=n/i;++i)if(p[i])for(std::size_t j=i*i;j<=n;j+=i)p[j]=false;std::vector<std::uint64_t> out;for(std::size_t i=2;i<=n;++i)if(p[i])out.push_back(i);return out;}
static void one(const PrimeSieve&s,const std::vector<std::uint64_t>&primes,std::uint64_t count,std::uint64_t first,std::uint64_t step){
 std::uint64_t index=first,called=0;
 s.for_each_prime_stride(first,step,[&](auto prime){static_assert(std::is_same_v<decltype(prime),std::uint64_t>);check(index<count&&prime==primes[index]);++called;index=step>UINT64_MAX-index?UINT64_MAX:index+step;});
 check(called==(first<count?(count-1-first)/step+1:0));++cases;
}
struct Digest {std::uint64_t hash=1,count=0;void operator()(std::uint64_t p){hash=hash*UINT64_C(0x9e3779b97f4a7c15)+p;++count;}};
struct MoveOnly {std::unique_ptr<int> owned=std::make_unique<int>(0);std::uint64_t* count;explicit MoveOnly(std::uint64_t& n):count(&n){}MoveOnly(const MoveOnly&)=delete;MoveOnly(MoveOnly&&)=default;void operator()(std::uint64_t)&{++*count;}};
int main(){
 const auto ref=naive(2000);
 for(std::uint64_t n=0;n<=2000;++n){PrimeSieve s(n);const auto count=std::upper_bound(ref.begin(),ref.end(),n)-ref.begin();
  for(std::uint64_t step=1;step<=200;++step)for(std::uint64_t first=0;first<step;++first)one(s,ref,count,first,step);
  for(std::uint64_t step:{UINT64_C(1),UINT64_C(7),UINT64_C(64),UINT64_MAX-1,UINT64_MAX})for(std::uint64_t first:{UINT64_C(0),std::uint64_t(count),std::uint64_t(count)+1,UINT64_MAX})one(s,ref,count,first,step);
#ifndef SKIP_RUNTIME_CHECKS
  bool caught=false;try{s.for_each_prime_stride(0,0,[](std::uint64_t){});}catch(const std::invalid_argument&){caught=true;}check(caught);
#endif
 }
 const PrimeSieve small(1000);std::uint64_t called=0;MoveOnly callback(called);small.for_each_prime_stride(0,3,callback);check(called==(small.prime_count()+2)/3);called=0;small.for_each_prime_stride(0,3,MoveOnly(called));check(called==(small.prime_count()+2)/3);
 called=0;small.for_each_prime_stride(0,1,callback);check(called==small.prime_count());called=0;small.for_each_prime_stride(0,1,MoveOnly(called));check(called==small.prime_count());
 struct CallbackException{};bool caught=false;try{small.for_each_prime_stride(0,1,[](std::uint64_t p){if(p==3)throw CallbackException{};});}catch(const CallbackException&){caught=true;}check(caught&&small.primes()==naive(1000));
 std::mt19937_64 rng(771791);
 for(std::uint64_t n:{UINT64_C(1000000),UINT64_C(100000000),UINT64_C(500000000)}){
  const PrimeSieve s(n);const auto count=s.prime_count();Digest all;s.for_each_prime([&](std::uint64_t p){all(p);});check(all.count==count);
  for(int trial=0;trial<12;++trial){const auto step=trial==0?UINT64_C(1):trial==1?UINT64_MAX:rng()%100000+1;const auto first=trial==0?UINT64_C(0):trial==1?UINT64_MAX:trial%2?count+rng()%99:rng()%(count+1);Digest expected,actual;auto skip=first;
   s.for_each_prime([&](std::uint64_t p){if(skip==0){expected(p);skip=step;}--skip;});s.for_each_prime_stride(first,step,[&](std::uint64_t p){actual(p);});check(expected.hash==actual.hash&&expected.count==actual.count);++cases;
  }
  check(s.prime_count()==count);std::printf("large n=%ju primes=%ju foreach_hash=%ju stride12PASS\n",static_cast<std::uintmax_t>(n),static_cast<std::uintmax_t>(count),static_cast<std::uintmax_t>(all.hash));
 }
 std::printf("PASS stride cases=%ju checks=%ju\n",static_cast<std::uintmax_t>(cases),static_cast<std::uintmax_t>(checks));
}
