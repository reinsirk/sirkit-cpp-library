from pathlib import Path
import json,sys,shutil,hashlib
R=Path('/home/reinsirk/Atcoder_Env');W=Path(__file__).parent;old=((W/'baseline.hpp') if (W/'baseline.hpp').exists() else R/'Math/Eratosthenes.cpp').read_text()
addition='''    template <class Function>
    void for_each_prime_stride(std::uint64_t first, std::uint64_t step, Function&& function) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (step == 0) throw std::invalid_argument("PrimeSieve::for_each_prime_stride: zero step");
#endif
        if (step < 8) {
            if (step == 1 && first == 0) { for_each_prime(function); return; }
            std::uint64_t skip = first;
            for_each_prime([&](std::uint64_t prime) {
                if (skip == 0) { function(prime); skip = step; }
                --skip;
            });
            return;
        }
        std::uint64_t skip = first;
        if (limit_ >= 2) {
            if (skip == 0) { function(std::uint64_t{2}); skip = step; }
            --skip;
        }
        for (std::size_t i = 0; i < flags_.size(); ++i) {
            std::uint64_t word = flags_[i];
            if (skip >= 8) {
                const auto count = static_cast<std::uint64_t>(std::popcount(word));
                if (skip >= count) { skip -= count; continue; }
            }
            while (word != 0) {
                if (skip == 0) {
                    function((static_cast<std::uint64_t>(i) * 64 + std::countr_zero(word)) * 2 + 1);
                    skip = step;
                }
                --skip;
                word &= word - 1;
            }
        }
    }

'''
marker='\nprivate:\n#if !defined(__clang__) || defined(__AVX2__)';assert old.count(marker)==1
candidate=old.replace(marker,'\n'+addition+marker);candidate=candidate.replace('// for_each_prime(f): 昇順にf(uint64_tの素数)を呼ぶ。O(limit/64+素数数)、呼出し中に表を変更しない。','// for_each_prime(f): 昇順にf(uint64_tの素数)を呼ぶ。O(limit/64+素数数)、呼出し中に表を変更しない。\n// for_each_prime_stride(first,step,f): 0始まりの素数番号first,first+step,...を同様に列挙。step>0。\n// 最悪O(limit/64+素数数)、追加領域O(1)。対象外のwordはまとめて飛ばす。')

a=candidate.index('        std::uint64_t skip = first;\n        if (limit_ >= 2)',candidate.index('void for_each_prime_stride('));b=candidate.index('\nprivate:\n#if !defined(__clang__)',a);words=candidate[a:b]
helper='    template <class Function>\n#if defined(__GNUC__) && !defined(__clang__)\n    [[gnu::noinline]]\n#endif\n    void for_each_prime_stride_words(std::uint64_t first, std::uint64_t step, Function& function) const {\n'+words
candidate=candidate[:a]+'        for_each_prime_stride_words(first, step, function);\n    }\n\n'+candidate[b:]
candidate=candidate.replace('\nprivate:\n#if !defined(__clang__)','\nprivate:\n'+helper+'#if !defined(__clang__)',1)
(W/'baseline.hpp').write_text(old);(W/'candidate_v1.hpp').write_text(candidate) if not (W/'candidate_v1.hpp').exists() else None;(W/'candidate.hpp').write_text(candidate)
for name in ['prime_sieve_simd_test','prime_sieve_boundary_test','prime_sieve_allocation_test']:shutil.copyfile(R/'Verify/current/tests'/f'{name}.cpp',W/'frozen_tests'/f'{name}.cpp')
sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
e=next(e for e in pv.collect() if e['id']=='eratosthenes');driver=((W/'baseline_driver.cpp') if (W/'baseline_driver.cpp').exists() else R/e['driver']).read_text();a=driver.index('    std::uint64_t remaining=b;');b=driver.index("    verify_out<<'\\n';",a);newdriver=driver[:a]+'''    sieve.for_each_prime_stride(b, a, [&](std::uint64_t prime) { verify_out << prime << ' '; });
'''+driver[b:];(W/'baseline_driver.cpp').write_text(driver);(W/'candidate_driver.cpp').write_text(newdriver);(W/'sources').mkdir(exist_ok=True);hashes={}
for label,source,dr in [('baseline',old,driver),('candidate',candidate,newdriver)]:
 data=pv.render(e,source_overrides={'Math/Eratosthenes.cpp':source.encode()},driver_override=dr)[0];(W/'sources'/f'{label}.cpp').write_bytes(data);hashes[label]=hashlib.sha256(data).hexdigest()
(W/'metadata.json').write_text(json.dumps({'entry':e,'baseline_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'source_sha256':hashes,'scope':'Existing prime_count/for_each_prime/flags/constructors unchanged. New stride API skips whole odd-bit words with std::popcount; no additional target-specific CPU implementation.'},indent=2)+'\n')
