from pathlib import Path
import difflib,hashlib,json,shutil,sys
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/prime_com_many_candidate');A=W/'adaptive';A.mkdir(exist_ok=True);sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'Scripts'));import generate_combination as gc;import prepare_verify as pv
shutil.copytree(W/'components',A/'components',dirs_exist_ok=True);s=(A/'components/prime_binomial.inc').read_text();a=s.index('    [[nodiscard]] std::vector<Mint> COM_many(');b=s.index('    [[nodiscard]] Mint Lucas(',a)
method='''    [[nodiscard]] std::vector<Mint> COM_many(
        const std::vector<std::pair<std::uint32_t, std::uint32_t>>& queries) const
    {
        check_modulus();
        if (queries.empty()) return {};
        std::uint32_t max_n = 0, max_valid_n = 0;
        std::size_t active_count = 0;
        for (const auto& [n,k] : queries) {
#ifndef SKIP_RUNTIME_CHECKS
            if (n >= static_cast<std::uint32_t>(modulus()))
                throw std::invalid_argument("PrimeBinomial::COM_many: n must be smaller than modulus");
#endif
            if (k <= n) {
                max_valid_n = std::max(max_valid_n, n);
                if (k > 1 && n-k > 1) { max_n = std::max(max_n, n); ++active_count; }
            }
        }
        const Mint zero(0), one(1);
        std::vector<Mint> result;
        if (queries.size() > result.max_size())
            throw std::length_error("PrimeBinomial: result size exceeds capacity");
        result.assign(queries.size(), zero);
        const auto active = [](std::uint32_t n, std::uint32_t k) {
            return k > 1 && k <= n && n-k > 1;
        };
        const auto simple = [&one](std::uint32_t n, std::uint32_t k) {
            return k == 0 || k == n ? one : Mint::raw(static_cast<int>(n));
        };
        if (active_count == 0) {
            for (std::size_t i = 0; i < queries.size(); ++i) {
                const auto [n,k] = queries[i];
                if (k <= n) result[i] = simple(n,k);
            }
            return result;
        }
        const auto use_tables = [&](const PrimeBinomial& prepared) {
            if (static_cast<std::size_t>(max_valid_n) < prepared.fac_.size()) {
                for (std::size_t i = 0; i < queries.size(); ++i) {
                    const auto [n,k] = queries[i];
                    if (k <= n) result[i] = prepared.fac_[n] * prepared.ifac_[k] * prepared.ifac_[n-k];
                }
            } else {
                for (std::size_t i = 0; i < queries.size(); ++i) {
                    const auto [n,k] = queries[i];
                    if (active(n,k)) result[i] = prepared.fac_[n] * prepared.ifac_[k] * prepared.ifac_[n-k];
                    else if (k <= n) result[i] = simple(n,k);
                }
            }
        };
        if (static_cast<std::size_t>(max_n) < fac_.size()
            && static_cast<std::size_t>(max_n) < ifac_.size()) {
            use_tables(*this);
            return result;
        }
        // 表が小さい場合は一括逆元より既存の逆階乗表の方が軽い。
        if (active_count >= (static_cast<std::uint64_t>(max_n) + 3) / 4) {
            PrimeBinomial prepared(*this);
            prepared.prepare(max_n);
            use_tables(prepared);
            return result;
        }
        std::vector<TableValue> factorial;
        make_factorial_table(factorial, static_cast<std::size_t>(max_n));
        Mint product(1);
        for (std::size_t i = 0; i < queries.size(); ++i) {
            const auto [n,k] = queries[i];
            if (!active(n,k)) {
                if (k <= n) result[i] = simple(n,k);
                continue;
            }
            result[i] = product;
            const Mint left = factorial[k], right = factorial[n-k];
            product *= left * right;
        }
        Mint inverse = product.inv();
        for (std::size_t i = queries.size(); i-- > 0;) {
            const auto [n,k] = queries[i];
            if (!active(n,k)) continue;
            const Mint left = factorial[k], right = factorial[n-k], numerator = factorial[n];
            const Mint denominator = left * right;
            result[i] = result[i] * inverse * numerator;
            inverse *= denominator;
        }
        return result;
    }

''';s=s[:a]+method+s[b:];s=s.replace('// 空でも法変更を検査。n>=modはinvalid_argument（SKIPで省略）。表構築はprepare同様max_stepsの対象外。','// 端は数学的に即答し、小さい範囲や準備済みの表は既存方式を使う。\n// 空でも法変更を検査。n>=modはinvalid_argument（SKIPで省略）。表構築はprepare同様max_stepsの対象外。');(A/'components/prime_binomial.inc').write_text(s)
headers,pieces=gc.load_sources(A/'components')
for rel,(kind,roots)in gc.TARGETS.items():
 p=A/'generated'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(gc.render(kind,roots,headers,pieces))
for name in ['baseline_library.cpp','baseline_main.cpp','candidate_main.cpp','test_mint.hpp','acl.hpp','api_test.cpp','test.py']:
 p=A/name;data=(W/name).read_text();data=data.replace(str(W),str(A))if name=='test.py'else data;p.write_text(data)
# Add explicit public Lucas checks and partial-table boundaries to the final fixture.
p=A/'api_test.cpp';t=p.read_text().replace('check(value(old.COM(n,k))==expected);}', 'check(value(old.COM(n,k))==expected);check(value(batch.Lucas(n,k))==expected);check(value(old.Lucas(n,k))==expected);}')
t=t.replace(' D::set_mod(97);BatchPrimeBinomial<D> limited', ''' {using P=TinyMint<998244353>;BaselinePrimeBinomial<P> full(20000);Queries q;for(std::uint32_t n=4090;n<10000;n+=7)q.emplace_back(n,n/2);for(int bound:{4094,4095,4096,4097}){BatchPrimeBinomial<P> partial(bound);auto r=partial.COM_many(q);for(std::size_t i=0;i<q.size();++i)check(value(r[i])==value(full.COM(q[i].first,q[i].second)));}}
 D::set_mod(97);BatchPrimeBinomial<D> limited''');p.write_text(t)
sha=lambda b:hashlib.sha256(b).hexdigest();candidate=(A/'generated/Math/Combination/Prime_Binomial.cpp').read_bytes();(A/'candidate_library.cpp').write_bytes(candidate);meta=json.loads((W/'sources.json').read_text());meta['candidate_canonical_sha256']=sha(s.encode());meta['body_sha256']['candidate']=sha(candidate);meta['programs']=[]
for variant in ['baseline','candidate','legacy_control']:
 body=(A/('baseline_library.cpp'if variant=='baseline'else'candidate_library.cpp')).read_bytes();driver=(A/('candidate_main.cpp'if variant=='candidate'else'baseline_main.cpp')).read_text()
 for skip in [False,True]:
  data,_=pv.render(meta['entry'],source_overrides={'Math/Combination/Prime_Binomial.cpp':body},driver_override=driver,skip_runtime_checks=skip);p=A/(variant+('_skip'if skip else'_checked')+'.cpp');p.write_bytes(data);meta['programs'].append({'name':variant,'skip':skip,'path':str(p),'sha256':sha(data)})
(A/'sources.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');(A/'canonical.diff').write_text(''.join(difflib.unified_diff((R/'Math/Combination/components/prime_binomial.inc').read_text().splitlines(True),s.splitlines(True),fromfile='canonical prime_binomial.inc',tofile='adaptive COM_many')));(A/'includes_prime.diff').write_text(''.join(difflib.unified_diff((R/'Math/Combination/components/includes_prime.txt').read_text().splitlines(True),(A/'components/includes_prime.txt').read_text().splitlines(True),fromfile='canonical includes_prime.txt',tofile='candidate')))
# Keep original source main and input hashes for fair paired reproduction.
shutil.copy2(W/'inputs.json',A/'inputs.json');programs=[]
for mint in ['ACL','StandardMint']:
 for variant in ['baseline','candidate','legacy_control']:
  body=(A/('baseline_library.cpp'if variant=='baseline'else'candidate_library.cpp')).read_bytes();driver=(A/('candidate_main.cpp'if variant=='candidate'else'baseline_main.cpp')).read_text()
  if mint=='StandardMint':driver=driver.replace('#include <atcoder/modint>',(A/'test_mint.hpp').read_text()).replace('atcoder::dynamic_modint<0>','TinyMint<0>')
  source,_=pv.render(meta['entry'],source_overrides={'Math/Combination/Prime_Binomial.cpp':body},driver_override=driver,skip_runtime_checks=True);p=A/f'{mint}_{variant}.cpp';p.write_bytes(source);programs.append({'mint':mint,'variant':variant,'path':str(p),'sha256':sha(source)})
(A/'bench_sources.json').write_text(json.dumps(programs,indent=2)+'\n');(A/'benchmark.py').write_text((W/'benchmark.py').read_text().replace(str(W),str(A)));print('prepared adaptive',meta['body_sha256']['candidate'])
