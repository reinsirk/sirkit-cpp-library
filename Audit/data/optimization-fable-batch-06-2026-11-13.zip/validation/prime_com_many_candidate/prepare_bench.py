from pathlib import Path
import hashlib,json,random,sys
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/prime_com_many_candidate');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
sha=lambda b:hashlib.sha256(b).hexdigest();meta=json.loads((W/'sources.json').read_text());(W/'inputs').mkdir(exist_ok=True);cases=[]
def isprime(n):return n>=2 and all(n%d for d in range(2,int(n**.5)+1))
assert isprime(9999991)
for name,p,maxn,q,mode in [('small_max',998244353,1000,200000,'valid'),('middle',998244353,1000000,200000,'independent'),('large',998244353,9999999,200000,'independent'),('wilson',9999991,9999990,200000,'independent'),('mostly_invalid',998244353,1000,200000,'mostly_invalid'),('all_invalid',998244353,9999998,200000,'all_invalid'),('maximum_T',998244353,9999999,1000000,'independent'),('mod2_maximum_T',2,1,1000000,'independent'),('mod97',97,96,200000,'independent')]:
 path=W/'inputs'/(name+'.in');rng=random.Random(712773+sum(map(ord,name)))
 with path.open('w')as f:
  f.write(f'{q} {p}\n')
  for i in range(q):
   n=rng.randrange(maxn+1)
   if mode=='valid':k=rng.randrange(n+1)
   elif mode=='mostly_invalid':k=rng.randrange(n+1)if i%20==0 else rng.randrange(n+1,10000000)
   elif mode=='all_invalid':k=rng.randrange(n+1,10000000)
   else:k=rng.randrange(maxn+1)
   if i==0:n,k=(maxn,maxn+1)if mode=='all_invalid'else(maxn,maxn//2)
   assert 0<=n<min(p,10000000)and 0<=k<min(p,10000000)
   f.write(f'{n} {k}\n')
 cases.append({'name':name,'p':p,'max_n':maxn,'q':q,'mode':mode,'input':str(path),'sha256':sha(path.read_bytes())})
(W/'inputs.json').write_text(json.dumps(cases,indent=2)+'\n')
programs=[]
for mint in ['ACL','StandardMint']:
 for variant in ['baseline','candidate','legacy_control']:
  body=(W/('baseline_library.cpp'if variant=='baseline'else'candidate_library.cpp')).read_bytes();driver=(W/('candidate_main.cpp'if variant=='candidate'else'baseline_main.cpp')).read_text()
  if mint=='StandardMint':driver=driver.replace('#include <atcoder/modint>',(W/'test_mint.hpp').read_text()).replace('atcoder::dynamic_modint<0>','TinyMint<0>')
  source,_=pv.render(meta['entry'],source_overrides={'Math/Combination/Prime_Binomial.cpp':body},driver_override=driver,skip_runtime_checks=True);path=W/f'{mint}_{variant}.cpp';path.write_bytes(source);programs.append({'mint':mint,'variant':variant,'path':str(path),'sha256':sha(source)})
(W/'bench_sources.json').write_text(json.dumps(programs,indent=2)+'\n');print('prepared',len(cases),'cases,',len(programs),'programs')
