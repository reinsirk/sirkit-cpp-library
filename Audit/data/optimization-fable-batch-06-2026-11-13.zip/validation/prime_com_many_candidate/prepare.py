from pathlib import Path
import difflib,hashlib,json,shutil,sys
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/prime_com_many_candidate');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'Scripts'));import generate_combination as gc;import prepare_verify as pv
sha=lambda b:hashlib.sha256(b).hexdigest();canonical=R/'Math/Combination/components';(W/'components').mkdir(exist_ok=True)
for p in canonical.iterdir():
 if p.is_file():shutil.copy2(p,W/'components'/p.name)
headers,pieces=gc.load_sources(canonical);baseline=gc.render('prime',('prime_binomial',),headers,pieces);assert baseline.encode()==(R/'Math/Combination/Prime_Binomial.cpp').read_bytes();(W/'baseline_library.cpp').write_text(baseline)
s=pieces['prime_binomial'];start=s.index('        const u64 p = static_cast<u64>(modulus());',s.index('    void extend_large'));end=s.index('        if constexpr (requires(Mint x) { -x; })',start);prefix=s[start:end].replace('fac_','table').replace('std::size_t i = old_size;','std::size_t i = old_size;')
helper='''    // 一括照会用の階乗表。既存表の接頭部は読み取りだけで再利用する。
    void make_factorial_table(std::vector<TableValue>& table, std::size_t target) const
    {
        if (target == std::numeric_limits<std::size_t>::max() || target + 1 > table.max_size())
            throw std::length_error("PrimeBinomial: table size exceeds capacity");
        grow_table(table, target + 1);
        auto old_size = std::min(fac_.size(), table.size());
        std::copy_n(fac_.begin(), old_size, table.begin());
        if (old_size == 0) { table[0] = Mint(1); old_size = 1; }
'''+prefix+'''    }

'''
needle='    // 固定法は定数として参照し、動的な法だけ変更検査を行う。';assert needle in s;s=s.replace(needle,helper+needle,1)
method='''    [[nodiscard]] std::vector<Mint> COM_many(
        const std::vector<std::pair<std::uint32_t, std::uint32_t>>& queries) const
    {
        check_modulus();
        if (queries.empty()) return {};
        std::uint32_t max_n = 0;
        std::size_t valid_count = 0;
        for (const auto& [n,k] : queries) {
#ifndef SKIP_RUNTIME_CHECKS
            if (n >= static_cast<std::uint32_t>(modulus()))
                throw std::invalid_argument("PrimeBinomial::COM_many: n must be smaller than modulus");
#endif
            if (k <= n) { max_n = std::max(max_n, n); ++valid_count; }
        }
        std::vector<Mint> result;
        if (queries.size() > result.max_size())
            throw std::length_error("PrimeBinomial: result size exceeds capacity");
        result.resize(queries.size());
        if (valid_count == 0) {
            std::fill(result.begin(), result.end(), Mint(0));
            return result;
        }
        if (static_cast<std::size_t>(max_n) < fac_.size()
            && static_cast<std::size_t>(max_n) < ifac_.size()) {
            for (std::size_t i = 0; i < queries.size(); ++i) {
                const auto [n,k] = queries[i];
                result[i] = k > n ? Mint(0) : fac_[n] * ifac_[k] * ifac_[n-k];
            }
            return result;
        }
        std::vector<TableValue> factorial;
        make_factorial_table(factorial, static_cast<std::size_t>(max_n));
        Mint product(1);
        for (std::size_t i = 0; i < queries.size(); ++i) {
            const auto [n,k] = queries[i];
            if (k > n) { result[i] = Mint(0); continue; }
            result[i] = product;
            const Mint left = factorial[k], right = factorial[n-k];
            product *= left * right;
        }
        Mint inverse = product.inv();
        for (std::size_t i = queries.size(); i-- > 0;) {
            const auto [n,k] = queries[i];
            if (k > n) continue;
            const Mint left = factorial[k], right = factorial[n-k], numerator = factorial[n];
            const Mint denominator = left * right;
            result[i] = result[i] * inverse * numerator;
            inverse *= denominator;
        }
        return result;
    }

'''
needle='    [[nodiscard]] Mint Lucas(i64 n, i64 k) const';assert needle in s;s=s.replace(needle,method+needle,1);s=s.replace('// Lucas(n,k): COMと同じ。COMもLucasを自動選択する。','// COM_many(queries): uint32_tの(n,k)列を一括計算しvector<Mint>で返す。全n<modが前提、k>nは0。\n// 有効な照会の最大nをM、件数をQとしてO(M+Q)時間・一時領域、逆元計算は最大1回。既存の表は変更しない。\n// 空でも法変更を検査。n>=modはinvalid_argument（SKIPで省略）。表構築はprepare同様max_stepsの対象外。\n// Lucas(n,k): COMと同じ。COMもLucasを自動選択する。',1)
(W/'components/prime_binomial.inc').write_text(s);h=(W/'components/includes_prime.txt').read_text();h+='#include <utility>\n';(W/'components/includes_prime.txt').write_text(h);headers,pieces=gc.load_sources(W/'components')
for rel,(kind,roots)in gc.TARGETS.items():
 p=W/'generated'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(gc.render(kind,roots,headers,pieces))
candidate=(W/'generated/Math/Combination/Prime_Binomial.cpp').read_bytes();(W/'candidate_library.cpp').write_bytes(candidate);(W/'canonical.diff').write_text(''.join(difflib.unified_diff((canonical/'prime_binomial.inc').read_text().splitlines(True),s.splitlines(True),fromfile='canonical prime_binomial.inc',tofile='candidate')))
entry=next(e for e in pv.collect()if e['id']=='binomial_prime_split');old=(R/entry['driver']).read_text();new=old.replace('PrimeBinomial<Mint> comb(max_n);','PrimeBinomial<Mint> comb(0);').replace("for (const auto& [n, k] : queries) verify_out << comb.COM(n, k).val() << '\\n';", "for (const auto value : comb.COM_many(queries)) verify_out << value.val() << '\\n';");assert new!=old;(W/'baseline_main.cpp').write_text(old);(W/'candidate_main.cpp').write_text(new);(W/'main.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=entry['driver'],tofile='COM_many main candidate')))
meta={'entry':entry,'canonical_sha256':sha((canonical/'prime_binomial.inc').read_bytes()),'candidate_canonical_sha256':sha(s.encode()),'body_sha256':{'baseline':sha(baseline.encode()),'candidate':sha(candidate)},'main_sha256':{'baseline':sha(old.encode()),'candidate':sha(new.encode())},'io_sha256':sha((R/'Verify/current/common/fast_io.hpp').read_bytes()),'programs':[],'prime_mod_problem_source':'https://raw.githubusercontent.com/yosupo06/library-checker-problems/master/enumerative_combinatorics/binomial_coefficient_prime_mod/task.md','prime_mod_problem_condition':'0<=n,k<min(m,10000000); m prime; T<=1000000; m<=2^30'}
for name,body,driver in [('baseline',baseline.encode(),old),('candidate',candidate,new),('legacy_control',candidate,old)]:
 for skip in [False,True]:
  program,_=pv.render(entry,source_overrides={'Math/Combination/Prime_Binomial.cpp':body},driver_override=driver,skip_runtime_checks=skip);p=W/(name+('_skip'if skip else'_checked')+'.cpp');p.write_bytes(program);meta['programs'].append({'name':name,'skip':skip,'path':str(p),'sha256':sha(program)})
meta['official_frozen']={str(p.relative_to(W/'official')):sha(p.read_bytes())for p in(W/'official').rglob('*')if p.is_file()};(W/'sources.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');print('prepared canonical candidate',meta['body_sha256'])
