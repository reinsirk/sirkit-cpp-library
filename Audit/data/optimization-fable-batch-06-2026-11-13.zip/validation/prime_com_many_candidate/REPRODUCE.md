# PrimeBinomial COM_many検討（reject固定）

root指示により、vector版・適応vector版・consumer overload版を全て今回はreject。
repo、既存API、製品Doc/Example、ZIP、オンライン記録は変更しない。Fable呼出しなし。
統合結果はreview.json。各段階のcandidate_library.cpp、canonical.diff、components/、main、rawを保持する。

## canonicalと前提

編集元はMath/Combination/components/prime_binomial.incとincludes_prime.txt。
Scripts/generate_combination.pyでPrime_Binomial.cpp/Combination_AtCoderMod.cppへ展開される。
新APIではpair<uint32_t,uint32_t>列を受け、全n<mod、k>nは数学的0という制約を明記した。
既存COM/Lucasのn>=mod対応、prepare、所有、max_stepsを変えていない。
新APIの一時表構築費用はprepare同様にmax_stepsの対象外。元の表は増やさない。
Mint::rawは現PrimeBinomialにも必須。val無し・単項minus無しの既存対応経路も照合した。

公式APIのsource_urlに従い、task.md/info.tomlとmod2/mod3/large_random生成器をofficial/へ保存。
公式の条件は0<=n,k<min(m,10^7)、T<=10^6、mは素数かつm<=2^30。
URL・全hashはsources.json/review.json、API応答はproblem_api.json。
したがってvariable-prime問題の合法入力にもn<pは成立する。旧COMのより広い範囲は保持した。

## 3段階

- このdir: facのみを一時構築し、分母をまとめて1回だけ逆元計算するvector版。
- adaptive/: 小範囲を既存表方式へ戻し、端の係数を即答する版。
- consumer/: 同名COM_many(queries,consumer) overloadを追加。小表はCOM→逐次consumer、大表はvector batch後に入力順でconsumer。

consumer中のMint法・同計算器・入力列の変更は禁止。例外は伝播し計算器を保持する。
入力検査はcallbackの呼出し前に行い、空入力でも法変更を検出する。
vectorの結果配列費用を避けても、計画走査と呼出文脈によるGCC回帰が残った。

## 照合

各段階でGCC15.2/Clang21×checked/skip×標準fallbackの8構成を実行。
小素数2/3/5/7/13/97のPascal、全n<pとk>n/UINT32_MAX、旧COM/Lucasのn>=p、
大素数998244353/1e9+7の20万件乱択と旧COM、空、全invalid、T100万、Wilson境界、
法変更検知、コピー/ムーブ後の再準備、既存計算予算を照合して全PASS。
consumer版では値の順序、空/不正入力時の未呼出し、2回目でthrowした際の状態保持も確認した。
3段階の合計チェック数はreview.jsonに記録。
採用をrejectしたため追加のallocation-fault注入や製品Doc/Example案は作成していない。

## 全体測定

CPU10、C++23 -O2 -Wall -Wextra、現entryのprefixを保持。オンラインSKIP/NDEBUG設定。
同じmain I/Oで2 warmup+7回交互、全出力byte一致、RSSは別processのtime %M。
ACL dynamic_modintと、拡張整数を使わないuint64%modの標準Mintを、それぞれ同一Mint内で比較。
各段階36組、計108 full-program比較。legacy-controlの.textは全compiler/Mintでbaselineと一致した。

最終consumer版のACL比率（候補/現行）:

|ケース|GCC|Clang|
|---|---:|---:|
|maxN1000,Q20万|1.083|.987|
|maxN100万,Q20万|1.049|1.007|
|maxN9999999,Q20万|.589|.598|
|Wilson p9999991,n=p-1|.803|.757|
|多数k>n、小表|1.155|1.006|
|全件k>n、大表|.081|.087|
|最大T100万、大表|.755|.752|
|mod2,T100万|1.030|.924|
|mod97|1.146|1.015|

大Nの約40%短縮・約38MiB減、Wilson/T100万の利益は実測として保持する。
一方、GCCのsmallMax/manyInvalid/mod97の明確な回帰が非回帰条件を満たさない。
他2種への展開や公開API採用は行わない。本体既存COM/prepareの改善という意味でも扱わない。

## 再現

各dirのtest.py/benchmark.pyが凍結sourceと入力hashを使う。原データはtest_results.json/results.json、rss/。
inputs.jsonは同一9入力を参照し、全n<min(p,10^7)とT上限を生成時に検査した。

```sh
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/prime_com_many_candidate/consumer/test.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/prime_com_many_candidate/consumer/benchmark.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/prime_com_many_candidate/finalize.py
```

元版は上記pathのconsumer/を除き、適応版はadaptive/へ置換する。
CPU10で他の計時を同時実行しない。再現時は凍結済みsourceを使いprepareで現repoへ置き換えない。
