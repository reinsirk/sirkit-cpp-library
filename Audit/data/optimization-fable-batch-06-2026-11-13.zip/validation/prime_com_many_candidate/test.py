from pathlib import Path
import hashlib,json,os,subprocess
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/prime_com_many_candidate');os.sched_setaffinity(0,{10});(W/'bin').mkdir(exist_ok=True);rows=[]
for label,prefix in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  for standard in [False,True]:
   exe=W/'bin'/f'api_{label}_{skip}_{standard}';cmd=[*prefix,'-std=c++23','-O2','-Wall','-Wextra','-I'+str(R/'Verify/current/vendor')]
   if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
   if standard:cmd+=['-U__SIZEOF_INT128__','-DSIRKIT_DISABLE_SIMD','-DSIRKIT_FORCE_STANDARD_ARITHMETIC']
   cmd += [str(W/'api_test.cpp'),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True,timeout=180);assert p.returncode==0,p.stderr;r=subprocess.run([str(exe)],capture_output=True,text=True,timeout=180);row={'compiler':label,'skip':skip,'standard_fallback':standard,'command':cmd,'diagnostics':p.stderr,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr};rows.append(row);(W/'test_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,skip,standard,r.returncode,r.stdout.strip(),flush=True);assert r.returncode==0,r.stderr
