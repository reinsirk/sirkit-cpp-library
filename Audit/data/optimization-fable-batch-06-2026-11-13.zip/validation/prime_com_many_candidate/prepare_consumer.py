from pathlib import Path
import difflib,hashlib,json,shutil,sys
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/prime_com_many_candidate');C=W/'consumer';C.mkdir(exist_ok=True);sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'Scripts'));import generate_combination as gc;import prepare_verify as pv
shutil.copytree(W/'components',C/'components',dirs_exist_ok=True);s=(C/'components/prime_binomial.inc').read_text();needle='    [[nodiscard]] std::vector<Mint> COM_many('
overload='''    template<class Consumer>
    void COM_many(const std::vector<std::pair<std::uint32_t, std::uint32_t>>& queries,
                  Consumer&& consume) const
    {
        check_modulus();
        if (queries.empty()) return;
        const auto p = static_cast<std::uint32_t>(modulus());
        if (p <= 3) {
#ifndef SKIP_RUNTIME_CHECKS
            for (const auto& [n,k] : queries) {
                static_cast<void>(k);
                if (n >= p)
                    throw std::invalid_argument("PrimeBinomial::COM_many: n must be smaller than modulus");
            }
#endif
            if (p == 2) {
                for (const auto& [n,k] : queries)
                    consume(Mint::raw(k <= n));
            } else {
                for (const auto& [n,k] : queries)
                    consume(Mint::raw(k <= n ? 1 + (n == 2 && k == 1) : 0));
            }
            return;
        }
        std::uint32_t max_n = 0;
        std::size_t valid_count = 0;
        for (const auto& [n,k] : queries) {
#ifndef SKIP_RUNTIME_CHECKS
            if (n >= p)
                throw std::invalid_argument("PrimeBinomial::COM_many: n must be smaller than modulus");
#endif
            const bool valid = k <= n;
            max_n = std::max(max_n, valid ? n : 0);
            valid_count += valid;
        }
        if (valid_count == 0) {
            const Mint zero(0);
            for (std::size_t i = 0; i < queries.size(); ++i) consume(zero);
            return;
        }
        if (static_cast<std::size_t>(max_n) < fac_.size()) {
            for (const auto& [n,k] : queries) consume(COM(n,k));
            return;
        }
        // 一括逆元の利得が小さい範囲は、既存表からその場で結果を渡す。
        if (valid_count >= (static_cast<std::uint64_t>(max_n) + 15) / 16) {
            PrimeBinomial prepared(*this);
            prepared.prepare(max_n);
            for (const auto& [n,k] : queries) consume(prepared.COM(n,k));
            return;
        }
        const auto values = COM_many(queries);
        for (const auto value : values) consume(value);
    }

''';assert needle in s;s=s.replace(needle,overload+needle,1);s=s.replace('        result.resize(queries.size());','        result.assign(queries.size(), Mint(0));',1);s=s.replace('// 有効な照会の最大nをM、件数をQとしてO(M+Q)時間・一時領域、逆元計算は最大1回。既存の表は変更しない。','// COM_many(queries,consume): 入力順にconsume(Mint)を呼ぶ。戻り値は使わない。小表では結果配列を作らない。\n// 有効な照会の最大nをM、件数をQとしてO(M+Q)時間・一時領域。既存表は変更しない。\n// callback中はMintの法・計算器・入力列を変更しない。例外は伝播し、計算器は保持する。')
(C/'components/prime_binomial.inc').write_text(s);headers,pieces=gc.load_sources(C/'components')
for rel,(kind,roots)in gc.TARGETS.items():
 p=C/'generated'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(gc.render(kind,roots,headers,pieces))
for name in ['baseline_library.cpp','baseline_main.cpp','test_mint.hpp','acl.hpp']:(C/name).write_bytes((W/name).read_bytes())
new=(W/'candidate_main.cpp').read_text().replace("for (const auto value : comb.COM_many(queries)) verify_out << value.val() << '\\n';", "comb.COM_many(queries, [](Mint value) { verify_out << value.val() << '\\n'; });");assert new!=(W/'candidate_main.cpp').read_text();(C/'candidate_main.cpp').write_text(new)
# Keep broad scalar/vector tests; add consumer order/lifetime/exception checks.
t=(W/'adaptive/api_test.cpp').read_text();t=t.replace('check(result.size()==q.size());','check(result.size()==q.size());std::vector<Mint> streamed;batch.COM_many(q,[&](Mint x){streamed.push_back(x);});check(streamed.size()==result.size());for(std::size_t i=0;i<result.size();++i)check(value(streamed[i])==value(result[i]));')
t=t.replace('check(batch.COM_many({}).empty());','check(batch.COM_many({}).empty());int empty_calls=0;batch.COM_many({},[&](Mint){++empty_calls;});check(empty_calls==0);')
t=t.replace('check(value(batch.COM(p,0))==1);','int invalid_calls=0;throws<std::invalid_argument>([&]{batch.COM_many({{0,0},{static_cast<std::uint32_t>(p),0}},[&](Mint){++invalid_calls;});});check(invalid_calls==0);check(value(batch.COM(p,0))==1);')
t=t.replace('const auto result=batch.COM_many(q);for', 'const auto result=batch.COM_many(q);std::size_t pos=0;batch.COM_many(q,[&](Mint x){check(value(x)==value(result[pos++]));});check(pos==result.size());for')
t=t.replace('throws<std::logic_error>([&]{(void)limited.COM_many({});});', 'throws<std::logic_error>([&]{(void)limited.COM_many({});});throws<std::logic_error>([&]{limited.COM_many({},[](D){});});')
t=t.replace(' Queries million', ''' {int calls=0;bool caught=false;try{limited.COM_many({{20,10},{10,3},{2,1},{0,0}},[&](D){if(++calls==2)throw 17;});}catch(int e){caught=e==17;}check(caught&&calls==2);throws<std::length_error>([&]{(void)limited.COM(80,31);});}
 Queries million''')
t=t.replace('check(many_zero.size()==million.size());','check(many_zero.size()==million.size());std::size_t zero_calls=0;limited.COM_many(million,[&](D x){check(value(x)==0);++zero_calls;});check(zero_calls==million.size());')
(C/'api_test.cpp').write_text(t);(C/'test.py').write_text((W/'test.py').read_text().replace(str(W),str(C)))
sha=lambda b:hashlib.sha256(b).hexdigest();candidate=(C/'generated/Math/Combination/Prime_Binomial.cpp').read_bytes();(C/'candidate_library.cpp').write_bytes(candidate);meta=json.loads((W/'sources.json').read_text());meta['candidate_canonical_sha256']=sha(s.encode());meta['body_sha256']['candidate']=sha(candidate);meta['main_sha256']['candidate']=sha(new.encode());meta['programs']=[]
for variant in ['baseline','candidate','legacy_control']:
 body=(C/('baseline_library.cpp'if variant=='baseline'else'candidate_library.cpp')).read_bytes();driver=(C/('candidate_main.cpp'if variant=='candidate'else'baseline_main.cpp')).read_text()
 for skip in [False,True]:
  data,_=pv.render(meta['entry'],source_overrides={'Math/Combination/Prime_Binomial.cpp':body},driver_override=driver,skip_runtime_checks=skip);p=C/(variant+('_skip'if skip else'_checked')+'.cpp');p.write_bytes(data);meta['programs'].append({'name':variant,'skip':skip,'path':str(p),'sha256':sha(data)})
(C/'sources.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');(C/'canonical.diff').write_text(''.join(difflib.unified_diff((R/'Math/Combination/components/prime_binomial.inc').read_text().splitlines(True),s.splitlines(True),fromfile='canonical prime_binomial.inc',tofile='consumer COM_many')));(C/'main.diff').write_text(''.join(difflib.unified_diff((C/'baseline_main.cpp').read_text().splitlines(True),new.splitlines(True),fromfile='binomial_prime_main.cpp',tofile='consumer main')));(C/'includes_prime.diff').write_text(''.join(difflib.unified_diff((R/'Math/Combination/components/includes_prime.txt').read_text().splitlines(True),(C/'components/includes_prime.txt').read_text().splitlines(True),fromfile='includes_prime.txt',tofile='candidate')))
shutil.copy2(W/'inputs.json',C/'inputs.json');programs=[]
for mint in ['ACL','StandardMint']:
 for variant in ['baseline','candidate','legacy_control']:
  body=(C/('baseline_library.cpp'if variant=='baseline'else'candidate_library.cpp')).read_bytes();driver=(C/('candidate_main.cpp'if variant=='candidate'else'baseline_main.cpp')).read_text()
  if mint=='StandardMint':driver=driver.replace('#include <atcoder/modint>',(C/'test_mint.hpp').read_text()).replace('atcoder::dynamic_modint<0>','TinyMint<0>')
  data,_=pv.render(meta['entry'],source_overrides={'Math/Combination/Prime_Binomial.cpp':body},driver_override=driver,skip_runtime_checks=True);p=C/f'{mint}_{variant}.cpp';p.write_bytes(data);programs.append({'mint':mint,'variant':variant,'path':str(p),'sha256':sha(data)})
(C/'bench_sources.json').write_text(json.dumps(programs,indent=2)+'\n');(C/'benchmark.py').write_text((W/'benchmark.py').read_text().replace(str(W),str(C)));print('prepared consumer',meta['body_sha256']['candidate'])
