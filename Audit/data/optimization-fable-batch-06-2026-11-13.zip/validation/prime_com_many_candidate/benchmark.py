from pathlib import Path
import hashlib,json,os,statistics,subprocess,time
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/prime_com_many_candidate');os.sched_setaffinity(0,{10});sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();programs=json.loads((W/'bench_sources.json').read_text());cases=json.loads((W/'inputs.json').read_text());report={'status':'running','cpu':10,'scope':'same original problem/main I/O, current prefix/flags, baseline full fac+ifac+COM vs new COM_many API+result output; core/Mint implementation fixed within each pair','method':'2 warmup+7 measured reverse-interleaved; exact stdout byte equality; RSS separate /usr/bin/time; default ACL and genuinely standard uint64 modular TinyMint compared separately','builds':[],'cases':[],'legacy_control':[]};(W/'bench_bin').mkdir(exist_ok=True);(W/'rss').mkdir(exist_ok=True)
for compiler,prefix in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for mint in ['ACL','StandardMint']:
  binaries={}
  for variant in ['baseline','candidate','legacy_control']:
   info=next(x for x in programs if x['mint']==mint and x['variant']==variant);src=Path(info['path']);assert sha(src)==info['sha256'];exe=W/'bench_bin'/f'{compiler}_{mint}_{variant}';cmd=[*prefix,'-std=c++23','-O2','-Wall','-Wextra']
   if mint=='StandardMint':cmd+=['-U__SIZEOF_INT128__','-DSIRKIT_DISABLE_SIMD','-DSIRKIT_FORCE_STANDARD_ARITHMETIC']
   cmd += [str(src),'-o',str(exe)];r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);assert r.returncode==0,r.stderr;binaries[variant]=exe;report['builds'].append({'compiler':compiler,'mint':mint,'variant':variant,'command':cmd,'source_sha256':info['sha256'],'binary_sha256':sha(exe),'diagnostics':r.stderr});section=W/'bench_bin'/f'{compiler}_{mint}_{variant}.text';subprocess.run(['/usr/bin/objcopy','--dump-section','.text='+str(section),str(exe)],check=True,capture_output=True);report['builds'][-1]['text_sha256']=sha(section)
  old=next(x for x in report['builds']if x['compiler']==compiler and x['mint']==mint and x['variant']=='baseline');control=next(x for x in report['builds']if x['compiler']==compiler and x['mint']==mint and x['variant']=='legacy_control');report['legacy_control'].append({'compiler':compiler,'mint':mint,'same_old_api_main_text_bytes':old['text_sha256']==control['text_sha256']});print(compiler,mint,'old API text identical',old['text_sha256']==control['text_sha256'],flush=True)
  for case in cases:
   path=Path(case['input']);assert sha(path)==case['sha256'];outputs={};ref=None
   for variant in ['baseline','candidate']:
    with path.open('rb')as f:r=subprocess.run([str(binaries[variant])],stdin=f,capture_output=True,check=True,timeout=90)
    if ref is None:ref=r.stdout
    assert r.stdout==ref,(compiler,mint,case['name'],'output mismatch');outputs[variant]=hashlib.sha256(r.stdout).hexdigest()
   samples={n:[]for n in ['baseline','candidate']}
   for iteration in range(9):
    for variant in (['baseline','candidate']if iteration%2==0 else['candidate','baseline']):
     with path.open('rb')as f:
      t=time.perf_counter_ns();subprocess.run([str(binaries[variant])],stdin=f,stdout=subprocess.DEVNULL,check=True);ms=(time.perf_counter_ns()-t)/1e6
     if iteration>=2:samples[variant].append(ms)
   median={n:statistics.median(v)for n,v in samples.items()};rss={}
   for variant in ['baseline','candidate']:
    raw=W/'rss'/f'{compiler}_{mint}_{case["name"]}_{variant}.txt'
    with path.open('rb')as f:subprocess.run(['/usr/bin/time','-f','%M','-o',str(raw),str(binaries[variant])],stdin=f,stdout=subprocess.DEVNULL,check=True,timeout=90)
    rss[variant]=int(raw.read_text())
   pairs=[c/b for c,b in zip(samples['candidate'],samples['baseline'])];row={'compiler':compiler,'mint':mint,'input':case,'all_outputs_equal':True,'output_sha256':outputs,'samples_ms':samples,'median_ms':median,'ratio':median['candidate']/median['baseline'],'paired_median_ratio':statistics.median(pairs),'wins_out_of_7':sum(p<1 for p in pairs),'peak_rss_kib':rss,'saved_rss_kib':rss['baseline']-rss['candidate'],'warmup':2,'measured':7};report['cases'].append(row);(W/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(compiler,mint,case['name'],round(row['ratio'],3),median,rss,'wins',row['wins_out_of_7'],flush=True)
report['status']='passed';(W/'results.json').write_text(json.dumps(report,indent=2)+'\n');print('FINAL',len(report['cases']),'full-program comparisons',flush=True)
