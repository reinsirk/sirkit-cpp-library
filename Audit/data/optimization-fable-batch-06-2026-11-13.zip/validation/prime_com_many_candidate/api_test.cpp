#include "test_mint.hpp"
#include <atcoder/modint.hpp>
#define PrimeBinomial BaselinePrimeBinomial
#include "baseline_library.cpp"
#undef PrimeBinomial
#undef SIRKIT_PRIME_BINOMIAL_DEFINED
#define PrimeBinomial BatchPrimeBinomial
#include "candidate_library.cpp"
#undef PrimeBinomial
#include <cstdio>
#include <cstdlib>
#include <random>
#include <type_traits>
using Query=std::pair<std::uint32_t,std::uint32_t>;
using Queries=std::vector<Query>;
std::uint64_t checks=0;
void check(bool ok){++checks;if(!ok){std::fprintf(stderr,"failure at check %llu\n",static_cast<unsigned long long>(checks));std::abort();}}
template<class Mint>int value(Mint x){if constexpr(requires{x.val();})return x.val();else return x.value;}
template<class E,class F>void throws(F f){bool caught=false;try{f();}catch(const E&){caught=true;}check(caught);}
std::vector<std::vector<int>> pascal(int n,int p){std::vector<std::vector<int>> t(n+1);for(int i=0;i<=n;++i){t[i].resize(i+1);t[i][0]=t[i][i]=1%p;for(int k=1;k<i;++k)t[i][k]=(t[i-1][k-1]+t[i-1][k])%p;}return t;}
template<class Mint>void small_prime(){const int p=Mint::mod(),limit=3*p+2;const auto triangle=pascal(limit,p);Queries q;for(int n=0;n<p;++n){for(int k=0;k<=p+1;++k)q.emplace_back(n,k);q.emplace_back(n,UINT32_MAX);}for(int bound:{0,p/2,p-1}){BatchPrimeBinomial<Mint> batch(bound);BaselinePrimeBinomial<Mint> old(bound);auto result=batch.COM_many(q);check(result.size()==q.size());for(std::size_t i=0;i<q.size();++i){auto[n,k]=q[i];int expected=k>n?0:triangle[n][k];check(value(result[i])==expected);check(value(batch.COM(n,k))==expected);check(value(old.COM(n,k))==expected);}for(int n=0;n<=limit;++n)for(int k=0;k<=n+1;++k){int expected=k>n?0:triangle[n][k];check(value(batch.COM(n,k))==expected);check(value(old.COM(n,k))==expected);}auto copy=batch;auto moved=std::move(copy);auto copied_result=moved.COM_many(q);for(std::size_t i=0;i<q.size();++i)check(value(copied_result[i])==value(result[i]));copy.prepare(p-1);auto rebuilt=copy.COM_many(q);for(std::size_t i=0;i<q.size();++i)check(value(rebuilt[i])==value(result[i]));check(batch.COM_many({}).empty());auto zeros=batch.COM_many({{0,1},{0,UINT32_MAX}});check(value(zeros[0])==0&&value(zeros[1])==0);
#ifndef SKIP_RUNTIME_CHECKS
 throws<std::invalid_argument>([&]{(void)batch.COM_many({{static_cast<std::uint32_t>(p),0}});});throws<std::invalid_argument>([&]{(void)batch.COM_many({{static_cast<std::uint32_t>(p),UINT32_MAX}});});check(value(batch.COM(p,0))==1);
#endif
 }}
template<class Mint>void random_many(){const std::uint32_t maxn=200000;std::mt19937 random(731291+Mint::mod());Queries q;q.reserve(200000);for(int i=0;i<200000;++i){const auto n=static_cast<std::uint32_t>(random()%(maxn+1));q.emplace_back(n,random()%(n+3));}q.emplace_back(maxn,maxn/2);BaselinePrimeBinomial<Mint> old(maxn);BatchPrimeBinomial<Mint> batch(0);const auto result=batch.COM_many(q);for(std::size_t i=0;i<q.size();++i)check(value(result[i])==value(old.COM(q[i].first,q[i].second)));batch.prepare(maxn);const auto cached=batch.COM_many(q);for(std::size_t i=0;i<q.size();++i)check(value(cached[i])==value(result[i]));}
int main(){small_prime<TinyMint<2>>();small_prime<TinyMint<3>>();small_prime<TinyMint<5>>();small_prime<TinyMint<7>>();small_prime<TinyMint<13>>();small_prime<TinyMint<97>>();small_prime<TinyMint<13,false>>();small_prime<TinyMint<13,true,false>>();using D=TinyMint<>;for(int p:{2,3,5,7,13,97}){D::set_mod(p);small_prime<D>();}random_many<TinyMint<998244353>>();random_many<TinyMint<1000000007>>();random_many<atcoder::modint998244353>();using ACL=atcoder::dynamic_modint<0>;ACL::set_mod(1000000007);random_many<ACL>();
 D::set_mod(97);BatchPrimeBinomial<D> limited(0,0);throws<std::length_error>([&]{(void)limited.COM(80,31);});auto prepared=limited.COM_many({{80,31},{0,1},{1,0}});check(value(prepared[0])==pascal(80,97)[80][31]);check(value(prepared[1])==0&&value(prepared[2])==1);throws<std::length_error>([&]{(void)limited.COM(80,31);});
 auto copy=limited;check(value(copy.COM_many({{80,31}})[0])==value(prepared[0]));
#ifndef SKIP_RUNTIME_CHECKS
 D::set_mod(101);throws<std::logic_error>([&]{(void)limited.COM_many({});});throws<std::logic_error>([&]{(void)limited.COM_many({{0,0}});});D::set_mod(97);
#endif
 // Empty/all-zero batches do not invert a denominator or change stored tables.
 D::inversions=0;check(limited.COM_many({}).empty());auto zero=limited.COM_many({{96,97},{0,1}});check(value(zero[0])==0&&value(zero[1])==0);check(D::inversions==0);
 Queries million(1000000,{0,1});auto many_zero=limited.COM_many(million);check(many_zero.size()==million.size());for(auto x:many_zero)check(value(x)==0);
 std::printf("PASS %llu Pascal/legacy COM/Lucas/batch/Mint/budget/state checks\n",static_cast<unsigned long long>(checks));}
