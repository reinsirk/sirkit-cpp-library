#include <cstdint>
#include <stdexcept>
template<int Fixed=0,bool HasVal=true,bool HasNeg=true>struct TinyMint {
    inline static int dynamic_modulus=3;
    inline static std::uint64_t inversions=0;
    static constexpr int mod()requires(Fixed!=0){return Fixed;}
    static int mod()requires(Fixed==0){return dynamic_modulus;}
    static void set_mod(int value)requires(Fixed==0){dynamic_modulus=value;}
    int value=0;
    TinyMint()=default;
    TinyMint(std::int64_t x){x%=mod();if(x<0)x+=mod();value=static_cast<int>(x);}
    static TinyMint raw(int v){TinyMint r;r.value=v;return r;}
    int val()const requires HasVal{return value;}
    TinyMint& operator+=(TinyMint b){value+=b.value;if(value>=mod())value-=mod();return *this;}
    friend TinyMint operator+(TinyMint a,TinyMint b){return a+=b;}
    TinyMint operator-()const requires HasNeg{return raw(value?mod()-value:0);}
    TinyMint& operator*=(TinyMint b){value=static_cast<int>(static_cast<std::uint64_t>(value)*static_cast<unsigned>(b.value)%static_cast<unsigned>(mod()));return *this;}
    friend TinyMint operator*(TinyMint a,TinyMint b){return a*=b;}
    TinyMint inv()const{++inversions;if(!value)throw std::domain_error("zero inverse");TinyMint a=*this,r=1;for(int e=mod()-2;e;e>>=1,a*=a)if(e&1)r*=a;return r;}
};
