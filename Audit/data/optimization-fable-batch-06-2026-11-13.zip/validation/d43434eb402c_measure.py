from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,time,unittest
r=Path('/home/reinsirk/Atcoder_Env');w=Path(__file__).resolve().parent
os.sched_setaffinity(0,{12})
file=r/'Scripts/tests/test_prime_sieve_stride_runtime.py';spec=importlib.util.spec_from_file_location('prime_stride_ci',file);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
rows=[];original=mod.PrimeSieveStrideRuntimeTests.run_command
protected=['Math/Eratosthenes.cpp','Document/prime_sieve.md','Verify/current/common/fast_io.hpp']
before={name:hashlib.sha256((r/name).read_bytes()).hexdigest()for name in protected}
def measured(self,command,phase,timeout):
 start=time.perf_counter();value=original(self,command,phase,timeout)
 rows.append({'test':self.id(),'phase':phase,'command':list(map(str,command)),'elapsed_seconds':time.perf_counter()-start,'stdout':value.stdout,'stderr':value.stderr,'returncode':value.returncode});return value
mod.PrimeSieveStrideRuntimeTests.run_command=measured
with (w/'gcc15_clang21.log').open('w')as log:
 start=time.perf_counter();result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(mod.PrimeSieveStrideRuntimeTests));elapsed=time.perf_counter()-start
report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cpu':12,'passed':result.wasSuccessful(),'tests_run':result.testsRun,'total_seconds':elapsed,'versions':{c:subprocess.check_output([c,'--version'],text=True).splitlines()[0]for c in ['/usr/bin/g++','/usr/bin/clang++']},'source_sha256':hashlib.sha256((r/'Math/Eratosthenes.cpp').read_bytes()).hexdigest(),'steps':rows,'protected_before':before,'protected_after':{name:hashlib.sha256((r/name).read_bytes()).hexdigest()for name in protected},'added_files':{name:hashlib.sha256((r/name).read_bytes()).hexdigest()for name in ['Scripts/tests/test_prime_sieve_stride_runtime.py','Verify/current/tests/prime_sieve_stride_test.cpp']}}
(w/'runtime_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('PASS'if result.wasSuccessful()else'FAIL','tests',result.testsRun,'seconds',elapsed,flush=True)
if not result.wasSuccessful():raise SystemExit(1)
