from pathlib import Path
import subprocess,json,hashlib
W=Path(__file__).parent;rows=[]
import sys
if '--examples-only' not in sys.argv:
 for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for mode,flags in [('checked',[]),('skip',['-DSKIP_RUNTIME_CHECKS']),('standard_checked',['-DSIRKIT_DISABLE_SIMD']),('standard_skip',['-DSIRKIT_DISABLE_SIMD','-DSKIP_RUNTIME_CHECKS'])]:
   for src in [W/'stride_test.cpp',*sorted((W/'frozen_tests').glob('*.cpp'))]:
    exe=W/f'{cc}-{mode}-{src.stem}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',*flags,'-DSIEVE_SOURCE="'+str(W/'candidate.hpp')+'"',str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','11',str(exe)],capture_output=True,text=True);rows.append({'compiler':cc,'mode':mode,'test':src.stem,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((W/'candidate.hpp').read_bytes()).hexdigest(),'passed':p.returncode==0,'stdout':p.stdout,'stderr':p.stderr});(W/'test_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,mode,src.stem,p.stdout.strip()[-210:],flush=True);assert p.returncode==0,p.stderr

if '--examples-only' in sys.argv:
 for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for mode,flags in [('checked',[]),('skip',['-DSKIP_RUNTIME_CHECKS'])]:
   src=W/'Examples/eratosthenes_example.cpp';exe=W/f'{cc}-{mode}-example';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',*flags,str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','11',str(exe)],capture_output=True,text=True);ok=p.returncode==0 and p.stdout.endswith('3 11 19 \n');rows.append({'compiler':cc,'mode':mode,'command':cmd,'passed':ok,'stdout':p.stdout,'stderr':p.stderr});(W/'example_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,mode,'example',ok,flush=True);assert ok,p.stderr
