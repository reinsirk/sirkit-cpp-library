from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
r=Path('/home/reinsirk/Atcoder_Env');w=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'Scripts'));import prepare_verify as pv
os.sched_setaffinity(0,{12});sha=lambda data:hashlib.sha256(data).hexdigest()
ids=['eratosthenes'];supplement_ids=['primality_sieve_local'];normal_ids=ids+supplement_ids;env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PATH='/usr/bin:/bin')
install=Path(subprocess.check_output(['/usr/bin/g++','-print-libgcc-file-name'],text=True).strip()).parent
compilers={'GCC':['/usr/bin/g++'],'Clang':['/usr/bin/clang++','--gcc-install-dir='+str(install)]}
report={'format':1,'ids':ids,'supplement_ids':supplement_ids,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','repo_generated':False,'online_status':'not_evaluated','cpu':12,'normal':[],'profiles':[],'notes':['Normal uses ci_verify --id selected --skip-sync because root already synced all artifacts; prepare(check=True) remains enabled.','Relevant primality_sieve_local normal supplement only (up to10000), no newly added stride runtime rerun. Variants checked and skip plus standard fallback. Fast strips runtime checks and is tested only on its valid-input unchecked contract, default and standard fallback. No unchanged local/large test rerun.']}
for name in ['sources','bin','raw']:(w/name).mkdir(exist_ok=True)
report['compilers']={k:subprocess.check_output([v[0],'--version'],text=True).splitlines()[0]for k,v in compilers.items()}
assert '15.2.0' in report['compilers']['GCC'];assert '21.' in report['compilers']['Clang']
entries={e['id']:e for e in pv.collect()};watched={'Verify/current/manifest.json','Variants/verify_manifest.json','Verify/current/common/fast_io.hpp','Document/prime_sieve.md','Examples/eratosthenes_example.cpp'}
for identity in normal_ids:
 entry=entries[identity];watched.update(entry['libraries']);watched.add(entry['driver']);watched.add('Verify/current/submissions/'+identity+'.cpp')
report['root_hashes_before']={p:sha((r/p).read_bytes())for p in sorted(watched)}
def save():(w/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
save()
for name,compiler in compilers.items():
 for fallback in [False,True]:
  output=w/'raw'/f'normal_{name}_{fallback}.json';cmd=[sys.executable,str(r/'Scripts/ci_verify.py'),'--skip-sync','--compiler',compiler[0],'--results',str(output)]
  for identity in normal_ids:cmd+=['--id',identity]
  if fallback:cmd+=['--fallback']
  start=time.monotonic();p=subprocess.run(cmd,cwd=r,env=env,capture_output=True,text=True,timeout=600)
  row={'compiler':name,'fallback':fallback,'command':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.monotonic()-start,'result':str(output),'passed':p.returncode==0};report['normal'].append(row);save();print('normal',name,'fallback',fallback,'PASS'if row['passed']else'FAIL',p.stdout.strip(),flush=True);assert row['passed'],p.stderr
profiles=[x for x in json.loads((r/'Variants/verify_manifest.json').read_text())['entries']if x['id']in ids];assert len(profiles)==4
report['profile_snapshot']=profiles
for item in profiles:
 for name in [*item['source_paths'].values(),item['driver']]:
  digest=sha((r/name).read_bytes())
  if name in report['root_hashes_before']:assert report['root_hashes_before'][name]==digest
  report['root_hashes_before'][name]=digest
 entry=entries[item['id']];profile=('Fast/'if item['fast']else'Variants/')+item['compiler'];libraries={k:(r/v).read_bytes()for k,v in item['source_paths'].items()};driver=(r/item['driver']).read_text();generated=(r/item['path']).read_bytes();assert sha(generated)==item['sha256'];report['root_hashes_before'][item['path']]=sha(generated)
 for skip in ([True]if item['fast']else[False,True]):
  source,_=pv.render({**entry,'submission_urls':item.get('submission_urls',[])},source_overrides=libraries,driver_override=driver,skip_runtime_checks=skip)
  lines=source.decode().splitlines(keepends=True);lines.insert(1 if lines[0].startswith('#define SKIP_RUNTIME_CHECKS')else 0,'// Profile: '+profile+'; online judgement is recorded separately.\n');source=''.join(lines).encode()
  if skip:assert source==generated,(profile,'render mismatch')
  else:assert not source.startswith(b'#define SKIP_RUNTIME_CHECKS')
  for fallback in [False,True]:
   label=item['id']+'_'+profile.replace('/','_')+('_skip'if skip else'_checked')+('_fallback'if fallback else'_default');src=w/'sources'/(label+'.cpp');src.write_bytes(source);exe=w/'bin'/label
   cmd=[*compilers[item['compiler']],'-std=c++23','-O2','-Wall','-Wextra']
   if fallback:cmd+=['-U__SIZEOF_INT128__','-DSIRKIT_FORCE_STANDARD_ARITHMETIC','-DSIRKIT_LINE_CONTAINER_FORCE_PORTABLE','-DSIRKIT_DISABLE_SIMD']
   cmd+=[str(src),'-o',str(exe)];start=time.monotonic();p=subprocess.run(cmd,cwd=r,env=env,capture_output=True,text=True,timeout=180)
   row={'id':item['id'],'profile':profile,'compiler':item['compiler'],'skip_runtime_checks':skip,'fast_unchecked_contract':item['fast'],'standard_fallback':fallback,'source':str(src),'source_sha256':sha(source),'generated_source_sha256':item['sha256'],'command':cmd,'compile_returncode':p.returncode,'compile_stdout':p.stdout,'compile_stderr':p.stderr,'compile_seconds':time.monotonic()-start,'samples':[]}
   if p.returncode==0:
    for i,sample in enumerate(entry['samples']):
     p=subprocess.run([str(exe)],input=sample['input'],text=True,capture_output=True,timeout=60,env=env);passed=p.returncode==0 and pv.matches(entry,sample,p.stdout)
     row['samples'].append({'index':i,'input':sample['input'],'expected':sample['output'],'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'sample_checker':entry.get('sample_checker','tokens'),'passed':passed})
   row['passed']=row['compile_returncode']==0 and len(row['samples'])==len(entry['samples'])and all(s['passed']for s in row['samples']);(w/'raw'/(label+'.json')).write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n');report['profiles'].append(row);save();print(label,'PASS'if row['passed']else'FAIL',flush=True);assert row['passed'],row
report['root_hashes_after']={p:sha((r/p).read_bytes())for p in report['root_hashes_before']};report['root_sources_unchanged']=report['root_hashes_before']==report['root_hashes_after'];assert report['root_sources_unchanged']
report['normal_build_configurations']=sum(len(json.loads(Path(row['result']).read_text())['results'])for row in report['normal']);report['profile_build_configurations']=len(report['profiles']);report['total_build_configurations']=report['normal_build_configurations']+report['profile_build_configurations'];assert report['total_build_configurations']==28
report['total_sample_executions']=sum(len(c['samples'])for row in report['normal']for c in json.loads(Path(row['result']).read_text())['results'])+sum(len(row['samples'])for row in report['profiles']);report['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();report['status']='passed';save();print('FINAL PASS',report['total_build_configurations'],'build configurations',report['total_sample_executions'],'samples',flush=True)
