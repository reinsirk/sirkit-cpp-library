from pathlib import Path
import subprocess,json,hashlib,random,time,statistics,shutil,os
W=Path(__file__).parent;rows=[];(W/'bin').mkdir(exist_ok=True);cases=[('large27',500000000,27,0),('large_sparse',500000000,100003,17),('all_primes',15000000,1,0),('middle6',100000000,6,0),('small1',10000,1,0),('small27',10000,27,9),('tiny',127,6,0)]
def save():(W/os.environ.get('REPORT_NAME','benchmark_results.json')).write_text(json.dumps({'cpu':11,'scope':'Full program: same constructor,prime_count,commonI/O/generated pragma/SKIP/NDEBUG and compilerC++23 O2. Baseline original for_each+remaining filter vs candidate new stride API and direct main call.2warm+9 shuffled interleaved copies at fixed executable path. No new CPU-specific stride path.','results':rows},indent=2)+'\n')
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 if os.environ.get('COMPILER_ONLY') and os.environ['COMPILER_ONLY']!=cc:continue
 bins={}
 for label in ['baseline','candidate']:
  src=W/'sources'/f'{label}.cpp';exe=W/'bin'/f'{cc}_{label}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;bins[label]=exe;rows.append({'kind':'build','compiler':cc,'label':label,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'passed':True});save()
 for name,n,a,b in cases:
  if os.environ.get("CASES_ONLY") and name not in os.environ["CASES_ONLY"].split(","):continue
  inp=W/(name+'.in');inp.write_text(f'{n} {a} {b}\n');outputs={}
  for label,exe in bins.items():
   p=subprocess.run(['taskset','-c','11',str(exe)],input=inp.read_bytes(),capture_output=True);assert p.returncode==0,p.stderr;outputs[label]=p.stdout
  assert outputs['baseline']==outputs['candidate'],(cc,name)
  raw={k:[] for k in bins};rng=random.Random(672147)
  for rep in range(11):
   order=list(raw);rng.shuffle(order)
   for label in order:
    active=W/'bin/active';shutil.copyfile(bins[label],active);active.chmod(0o755)
    with inp.open('rb') as fi,open('/dev/null','wb') as fo:
     start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','11',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
    assert p.returncode==0,p.stderr
    if rep>=2:raw[label].append(elapsed)
  med={k:statistics.median(v) for k,v in raw.items()};rows.append({'kind':'timing','compiler':cc,'case':name,'n':n,'step':a,'first':b,'output_byte_identical':True,'output_sha256':hashlib.sha256(outputs['baseline']).hexdigest(),'output_bytes':len(outputs['baseline']),'raw_ns':raw,'median_ns':med,'ratio':med['candidate']/med['baseline']});save();print(cc,name,{k:round(v/1e6,3) for k,v in med.items()},flush=True)
