# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,datetime,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_20261104');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();normalize=lambda t:'\n'.join(l.rstrip()for l in t.replace('\r\n','\n').splitlines()if l.strip()and not l.startswith('// Submission:'))
(R/'Audit/distribution-manifest-before-hld-2026-11-04.json').write_bytes((R/'Distribution/manifest.json').read_bytes())
for f,name in [('Graph/Heavy_Light_Decomposition.cpp','base.hpp'),('DataStructure/Fenwick_Tree.cpp','fenwick_frozen.cpp'),('Verify/current/common/fast_io.hpp','io.hpp'),('Verify/current/drivers/hld_jump_main.cpp','jump_driver.cpp'),('Verify/current/drivers/hld_vertex_add_path_sum_main.cpp','sum_driver.cpp'),('Document/heavy_light_decomposition.md','document_before.md'),('Examples/heavy_light_decomposition_example.cpp','example_before.cpp'),('Verify/current/tests/new_hld_reference_test.cpp','test_before.cpp')]: (D/name).write_bytes((R/f).read_bytes())
records=[];group=R/'Verify/current/groups/expansion_20261031.json';g=json.loads(group.read_text());p=R/'Verify/current/judgements.json';j=json.loads(p.read_text())
for sid,vid in [(415167,'hld_jump'),(415168,'hld_vertex_add_path_sum')]:
 api=json.loads((D/f'{sid}.json').read_text());o=api['overview'];e=next(e for e in g['entries'] if e['id']==vid);source=R/f'Verify/current/submissions/{vid}.cpp';assert normalize(api['source'])==normalize(source.read_text());assert o['status']=='AC'
 record=dict(id=vid,status='AC',url=f'https://judge.yosupo.jp/submission/{sid}',time_ms=round(o['time']*1000),memory_bytes=o['memory'],language=o['lang'],submission_time=o['submission_time'],checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),case_results=api['case_results'],submission_sha256=sha(source),uploaded_source_sha256=sha(D/f'{sid}.cpp'),source_hashes={f:sha(R/f)for f in e['libraries']},driver_sha256=sha(R/e['driver']),io_source_hashes={'Verify/current/common/fast_io.hpp':sha(R/'Verify/current/common/fast_io.hpp')},io_mode='shared_fast_io',matched_current_generation=True,needs_resubmission=False,source_match='改行・空行・行末空白・Submission注記を除いて現行本体・main・共通I/Oと一致。',evidence_file='Audit/online-hld-2026-11-04.json');records.append(record)
 e['submission_urls']=[record['url']];e['limitations']='オンラインでは対応する経路照会を検証。任意根・森・順序付き/辺モードの区間・祖先・LCA・境界・所有権・確保失敗は独立BFSとGCC/Clangの検査有無で補足。'
 j['entries']=[x for x in j['entries'] if x['id']!=vid]+[record]
group.write_text(json.dumps(g,ensure_ascii=False,indent=2)+'\n');p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
a={'endpoints':[f'https://v3.api.judge.yosupo.jp/submissions/{i}'for i in [415167,415168]],'scope':'通常版HLD初回のAC272ms/337ms。確認時の本体・main・共通I/Oと照合。以後の高速化案へACを転記しない。','records':records}
with zipfile.ZipFile(R/'Audit/data/online-hld-2026-11-04.zip','w',zipfile.ZIP_DEFLATED)as z:
 for f in ['415167.json','415168.json','415167.cpp','415168.cpp','confirm.py']:z.write(D/f,f)
(R/'Audit/online-hld-2026-11-04.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');print('Both AC/source match confirmed')
