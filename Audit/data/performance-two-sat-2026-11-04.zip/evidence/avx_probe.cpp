// SPDX-License-Identifier: CC0-1.0
#include "/tmp/sirkit_two_sat_speed_20261104/avx.hpp"
#include <cstdio>
#include <cstdlib>
int main(){
 if(!__builtin_cpu_supports("avx2"))return 2;
 unsigned checks=0;
 for(int n=0;n<=130;++n)for(int bad=-1;bad<n;++bad){
  std::vector<int> ids(2*n);for(int i=0;i<2*n;++i)ids[i]=i;
  if(bad>=0)ids[2*bad+1]=ids[2*bad];
  if(reinsirk::detail::two_sat_consistent_avx2(ids.data(),n)!=(bad<0))std::abort();
  ++checks;
 }
 std::printf("AVX2 pair equality/tails checks=%u\n",checks);
}
