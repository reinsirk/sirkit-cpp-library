# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,os,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_two_sat_speed_20261104');rows=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for compiler,args in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  for test in ['two_sat_acl_api_test','two_sat_component_test']:
   for order in ([False,True]if test=='two_sat_component_test'else[False]):
    src=R/f'Verify/current/tests/{test}.cpp';exe=D/f'{compiler}_{int(skip)}_{test}_{int(order)}'
    cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-DSIRKIT_DISABLE_SIMD','-fsanitize=address,undefined','-fno-omit-frame-pointer','-Wall','-Wextra','-Werror']
    if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
    if order:cmd+=['-DSIRKIT_TWO_SAT_TEST_SCC_FIRST']
    cmd+=[str(src),'-o',str(exe)]
    comp=subprocess.run(cmd,capture_output=True,text=True);assert comp.returncode==0,(test,comp.stderr)
    env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'};run=['taskset','-c','4',str(exe)];result=subprocess.run(run,capture_output=True,text=True,env=env)
    row=dict(compiler=compiler,skip_runtime_checks=skip,SCC_first=order,test=test,compile_command=cmd,compile_returncode=comp.returncode,compile_stderr=comp.stderr,run_command=run,environment={'ASAN_OPTIONS':'detect_leaks=0'},returncode=result.returncode,stdout=result.stdout,stderr=result.stderr,test_sha256=sha(src),source_sha256=sha(R/'Graph/Two_SAT.cpp'))
    rows.append(row);(D/'final_tests.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(compiler,skip,order,test,result.returncode,result.stdout.strip(),flush=True);assert result.returncode==0 and not result.stderr,result.stderr
