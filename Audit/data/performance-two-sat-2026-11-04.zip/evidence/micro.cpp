// SPDX-License-Identifier: CC0-1.0
#include SIRKIT_TWO_SAT_BENCH_SOURCE
#include <cstdint>
#include <cinttypes>
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <string>
int main(int argc,char**argv){
 if(argc!=5)return 2;
 const int n=std::atoi(argv[1]),reps=std::atoi(argv[4]);const std::string kind=argv[2],mode=argv[3];
 two_sat formula(n);
 if(kind=="chain")for(int i=0;i+1<n;++i)formula.imply(i,true,i+1,true);
 else if(kind=="early_unsat"){
  formula.force(0,true);formula.force(0,false);
  for(int i=1;i+1<n;++i)formula.imply(i,true,i+1,true);
 }else if(kind=="cycle_unsat"){
  for(int i=0;i<n;++i)formula.add_xor(i,(i+1)%n,false);
  formula.force(0,true);formula.force(n/2,false);
 }else if(kind=="planted"){
  std::uint64_t seed=415142;auto next=[&](){seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;return seed;};
  std::vector<unsigned char> truth(n);for(auto&v:truth)v=next()&1;
  for(int i=0;i<2*n;++i){const int a=next()%n,b=next()%n;bool f=next()&1,g=next()&1;if(f!=bool(truth[a])&&g!=bool(truth[b]))f=!f;formula.add_clause(a,f,b,g);}
 }
 if(mode=="answer"&&!formula.satisfiable())return 3;
 std::uint64_t sum=0;const auto start=std::clock();
 for(int r=0;r<reps;++r){
  if(mode=="sat")sum+=formula.satisfiable();
  else if(mode=="answer"){auto a=formula.answer();sum+=a.size();if(n)sum+=a[n/2];}
  else if(mode=="sat_answer"){const bool ok=formula.satisfiable();sum+=ok;if(ok){auto a=formula.answer();sum+=a.size();if(n)sum+=a[n/2];}}
  else return 4;
 }
 const auto nanos=static_cast<std::uint64_t>(std::clock()-start)*std::uint64_t{1000000000}/CLOCKS_PER_SEC;
 std::printf("%" PRIu64 " %" PRIu64 "\n",nanos,sum);
}
