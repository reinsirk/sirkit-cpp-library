# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,os,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_two_sat_speed_20261104');rows=[]
s=(R/'Graph/Two_SAT.cpp').read_text().replace('#if defined(__GNUC__) && !defined(__clang__)','#if 1');(D/'msan_gccpath.hpp').write_text(s)
for path in ['native_clang','gcc_answer_source']:
 for skip in [False,True]:
  exe=D/f'msan_{path}_{int(skip)}';cmd=['taskset','-c','4','/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-std=c++23','-O1','-fsanitize=memory','-fsanitize-memory-track-origins=2','-fno-omit-frame-pointer','-fPIE','-pie']
  if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
  if path=='gcc_answer_source':cmd+=[f'-DSIRKIT_TWO_SAT_TEST_SOURCE="{D}/msan_gccpath.hpp"']
  src=R/'Verify/current/tests/two_sat_acl_api_test.cpp';cmd+=[str(src),'-o',str(exe)];subprocess.run(cmd,check=True)
  attempts=[]
  for attempt in range(8):
   run=['taskset','-c','4',str(exe)];p=subprocess.run(run,text=True,capture_output=True,env={**os.environ,'MSAN_OPTIONS':'halt_on_error=1'})
   attempts.append(dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
   if p.returncode==0:break
   # PIEの配置でshadowを確保できない場合のみ再試行する。
   assert 'out of application range'in p.stderr or 'can not mmap the shadow memory'in p.stderr,p.stderr
  assert p.returncode==0 and not p.stderr,p.stderr
  rows.append(dict(test='two_sat_acl_api_test',path=path,skip_runtime_checks=skip,compile_command=cmd,run_command=run,environment={'MSAN_OPTIONS':'halt_on_error=1'},attempts=attempts,source_sha256=hashlib.sha256((R/'Graph/Two_SAT.cpp').read_bytes()).hexdigest()));(D/'msan.json').write_text(json.dumps(rows,indent=2)+'\n');print(path,skip,p.stdout.strip(),flush=True)
