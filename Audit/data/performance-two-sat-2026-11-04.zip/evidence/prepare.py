# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib,random
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_two_sat_speed_20261104');s=(D/'before.hpp').read_text();meta=[]
for name,count in [('random',5),('max_random',5),('cycle_unsat',2),('long_chain',4)]:
 src=D/'official_generator'/f'{name}.cpp';exe=src.with_suffix('');subprocess.run(['/usr/bin/g++','-std=c++23','-O2',str(src),'-o',str(exe)],check=True)
 for seed in range(count):
  f=D/f'official_{name}_{seed}.in'
  with f.open('wb')as out:subprocess.run([str(exe),str(seed)],stdout=out,check=True)
  meta.append(dict(name=f.stem,path=str(f),header=f.read_text().splitlines()[0],sha256=hashlib.sha256(f.read_bytes()).hexdigest(),source=f'https://raw.githubusercontent.com/yosupo06/library-checker-problems/master/other/two_sat/gen/{name}.cpp',seed=seed))
for n in [32,4096,250000]:
 for kind in ['empty','chain_sat','early_unsat','late_unsat','planted']:
  r=random.Random(415142+n);clauses=[]
  if kind=='chain_sat':clauses=[(-i,i+1)for i in range(1,n)]
  if kind in ['early_unsat','late_unsat']:
   var=1 if kind=='early_unsat'else n;clauses=[(var,var),(-var,-var)]
   clauses.extend((-i,i+1)for i in range(1,n))
  if kind=='planted':
   truth=[False]+[bool(r.getrandbits(1))for _ in range(n)]
   for _ in range(2*n):
    a,b=r.randrange(1,n+1),r.randrange(1,n+1);f,g=bool(r.getrandbits(1)),bool(r.getrandbits(1))
    if f!=truth[a]and g!=truth[b]:f=not f
    clauses.append((a if f else-a,b if g else-b))
  f=D/f'custom_{n}_{kind}.in'
  with f.open('w')as out:out.write(f'p cnf {n} {len(clauses)}\n');out.writelines(f'{a} {b} 0\n'for a,b in clauses)
  meta.append(dict(name=f.stem,path=str(f),header=f'p cnf {n} {len(clauses)}',sha256=hashlib.sha256(f.read_bytes()).hexdigest(),source='own generator',expected_sat=kind not in ['early_unsat','late_unsat']))
(D/'fixtures.json').write_text(json.dumps(meta,indent=2)+'\n')
old='''    std::vector<bool> answer() {
        std::vector<bool> result(static_cast<std::size_t>(n_));
        if (answer_.size() == result.size())
            for (int i = 0; i < n_; ++i) result[i] = answer_[i] != 0;
        return result;
    }'''
new='''    std::vector<bool> answer() {
        if (answer_.size() == static_cast<std::size_t>(n_))
            return std::vector<bool>(answer_.begin(), answer_.end());
        return std::vector<bool>(static_cast<std::size_t>(n_));
    }'''
assert old in s;ranged=s.replace(old,new);variants={'base':s,'range':ranged}
empty='''    bool satisfiable() {
        if (implications_.empty()) {
            std::vector<unsigned char> result(n_, 0);
            answer_.swap(result);
#ifndef SKIP_RUNTIME_CHECKS
            solved_ = satisfiable_ = true;
#endif
            return true;
        }
'''
e=ranged.replace('    bool satisfiable() {\n',empty);variants['empty']=e
oldcheck='''        for (int i = 0; i < n_; ++i) if (ids[2 * i] == ids[2 * i + 1]) {'''
block='''        bool consistent = true;
        int at = 0;
        for (; n_ - at >= 16; at += 16) {
            bool conflict = false;
            for (int j = 0; j < 16; ++j)
                conflict |= ids[2 * (at + j)] == ids[2 * (at + j) + 1];
            if (conflict) { consistent = false; break; }
        }
        for (; consistent && at < n_; ++at)
            if (ids[2 * at] == ids[2 * at + 1]) consistent = false;
        if (!consistent) {'''
assert oldcheck in e;variants['block']=e.replace(oldcheck,block)
# 融合はローカル結果へ書き、失敗時に既存cacheを更新しない。
f=e.replace(oldcheck,'        std::vector<unsigned char> result(n_);\n        for (int i = 0; i < n_; ++i) {\n            if (ids[2 * i] == ids[2 * i + 1]) {')
f=f.replace('''            return false;
        }
        std::vector<unsigned char> result(n_);
        for (int i = 0; i < n_; ++i) result[i] = ids[2 * i] < ids[2 * i + 1];''','''                return false;
            }
            result[i] = ids[2 * i] < ids[2 * i + 1];
        }''');variants['fused']=f
# 専用SCCへ分離し、通常のSCCの本体や共有guardに影響させない。
a=e.index('#ifndef SIRKIT_SCC_DETAIL_DEFINED');b=e.index('#endif',a)+6;helper=e[a:b].replace('SIRKIT_SCC_DETAIL_DEFINED','SIRKIT_TWO_SAT_SCC_DETAIL_DEFINED').replace('directed_component_ids_index','two_sat_component_ids_index').replace('directed_component_ids(','two_sat_component_ids(')
oldpop='''            if (child_low == entered[v]) {
                for (;;) {
                    const int u = pending.back(); pending.pop_back();
                    entered[u] = n; ids[u] = count;
                    if (u == v) break;
                }
                ++count;
            }'''
newpop='''            if (child_low == entered[v]) {
                if (pending.back() == v) {
                    pending.pop_back();
                    entered[v] = n; ids[v] = count;
                } else {
                    for (;;) {
                        const int u = pending.back(); pending.pop_back();
                        entered[u] = n; ids[u] = count;
                        if (entered[u ^ 1] == n && ids[u ^ 1] == count)
                            return {-1, {}};
                        if (u == v) break;
                    }
                }
                ++count;
            }'''
assert oldpop in helper;helper=helper.replace(oldpop,newpop);early=e[:a]+helper+e[b:];early=early.replace('reinsirk::detail::directed_component_ids(2 * n_, implications_)','reinsirk::detail::two_sat_component_ids(2 * n_, implications_)').replace(oldcheck,'        if (components.first < 0) {');variants['early']=early
# AVX2はCPU/コンパイラ/設定を満たす場合だけ利用。
avx_guard='!defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__))'
avx_code='''
#if '''+avx_guard+'''
#include <immintrin.h>
#ifndef SIRKIT_TWO_SAT_AVX2_DEFINED
#define SIRKIT_TWO_SAT_AVX2_DEFINED
namespace reinsirk::detail {
__attribute__((target("avx2"))) inline bool two_sat_consistent_avx2(const int* ids, int n) {
    int i = 0;
    for (; n - i >= 16; i += 16) {
        const int* p = ids + std::size_t(i) * 2;
        const auto a = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(p));
        const auto b = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(p + 8));
        const auto c = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(p + 16));
        const auto d = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(p + 24));
        const auto ea = _mm256_cmpeq_epi32(a, _mm256_shuffle_epi32(a, _MM_SHUFFLE(2,3,0,1)));
        const auto eb = _mm256_cmpeq_epi32(b, _mm256_shuffle_epi32(b, _MM_SHUFFLE(2,3,0,1)));
        const auto ec = _mm256_cmpeq_epi32(c, _mm256_shuffle_epi32(c, _MM_SHUFFLE(2,3,0,1)));
        const auto ed = _mm256_cmpeq_epi32(d, _mm256_shuffle_epi32(d, _MM_SHUFFLE(2,3,0,1)));
        const auto conflict = _mm256_or_si256(_mm256_or_si256(ea, eb), _mm256_or_si256(ec, ed));
        if (!_mm256_testz_si256(conflict, conflict)) return false;
    }
    for (; i < n; ++i) if (ids[2 * i] == ids[2 * i + 1]) return false;
    return true;
}
}
#endif
#endif
'''
a=e.index('#ifndef SIRKIT_TWO_SAT_DEFINED');avx=e[:a]+avx_code+'\n'+e[a:]
check='''        bool consistent = true;
#if '''+avx_guard+'''
        if (n_ >= 64 && __builtin_cpu_supports("avx2"))
            consistent = reinsirk::detail::two_sat_consistent_avx2(ids.data(), n_);
        else
#endif
            for (int i = 0; i < n_; ++i) if (ids[2 * i] == ids[2 * i + 1]) { consistent = false; break; }
        if (!consistent) {'''
variants['avx']=avx.replace(oldcheck,check)
for label,src in variants.items():
 (D/f'{label}.hpp').write_text(src);driver=(D/'driver.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"',(D/'io.hpp').read_text());(D/f'{label}.cpp').write_text('#define SKIP_RUNTIME_CHECKS\n'+src+'\n'+driver)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:subprocess.run(['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(D/f'{label}.cpp'),'-o',str(D/f'{cc}_{label}')],check=True)
print('Prepared 31 fixtures and 7 candidates')
