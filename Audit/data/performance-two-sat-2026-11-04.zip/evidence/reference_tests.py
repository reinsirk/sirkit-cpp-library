# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,os,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_two_sat_speed_20261104');rows=[]
for compiler,args in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  for test in ['new_scc_two_sat_reference_test','new_graph_allocation_test']:
   src=R/f'Verify/current/tests/{test}.cpp';exe=D/f'{compiler}_{int(skip)}_{test}'
   cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-DSIRKIT_DISABLE_SIMD']
   if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
   if test!='new_graph_allocation_test':cmd+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
   if test=='two_sat_acl_api_test':cmd+=['-Wall','-Wextra','-Werror']
   cmd+=[str(src),'-o',str(exe)]
   compile_result=subprocess.run(cmd,capture_output=True,text=True);assert compile_result.returncode==0,(test,compile_result.stderr)
   env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'}
   result=subprocess.run(['taskset','-c','4',str(exe)],capture_output=True,text=True,env=env)
   row=dict(compiler=compiler,skip_runtime_checks=skip,test=test,compile_command=cmd,compile_returncode=compile_result.returncode,compile_stderr=compile_result.stderr,run_command=['taskset','-c','4',str(exe)],environment={'ASAN_OPTIONS':'detect_leaks=0'},returncode=result.returncode,stdout=result.stdout,stderr=result.stderr,test_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),source_sha256=hashlib.sha256((R/'Graph/Two_SAT.cpp').read_bytes()).hexdigest())
   rows.append(row);(D/'reference_tests.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
   print(compiler,skip,test,result.returncode,result.stdout.strip(),flush=True)
   assert result.returncode==0 and not result.stderr,result.stderr
