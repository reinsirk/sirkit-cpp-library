# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,zipfile,subprocess,platform
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_two_sat_speed_20261104');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda f:json.loads((D/f).read_text())
for name,frozen in [('Graph/SCC.cpp','scc_frozen.cpp'),('Verify/current/drivers/two_sat_main.cpp','driver.cpp'),('Verify/current/common/fast_io.hpp','io.hpp')]:assert (R/name).read_bytes()==(D/frozen).read_bytes(),name
assert (R/'Graph/Two_SAT.cpp').read_bytes()==(D/'final.hpp').read_bytes()
ref=load('reference_tests.json');tests=load('final_tests.json');msan=load('msan.json');assert len(ref)==8 and len(tests)==12 and len(msan)==4
for row in ref+tests:
 assert row['returncode']==0 and not row['stderr'];assert row['source_sha256']==sha(R/'Graph/Two_SAT.cpp');assert row['test_sha256']==sha(R/f'Verify/current/tests/{row["test"]}.cpp')
for row in msan:assert row['attempts'][-1]['returncode']==0 and not row['attempts'][-1]['stderr']
whole=load('adopted_raw.json');micro=load('adopted_micro_raw.json');assert len(whole)==1302 and len(micro)==1638
summary=load('adopted_summary.json');assert len(summary['whole_main'])==62 and len(summary['API'])==78
profiles=json.loads(sorted((D/'profiles/runs').glob('*.json'))[-1].read_text());assert profiles['counts']=={'LOCAL_SAMPLE_PASS':10}
normal=load('normal_samples.json');assert len(normal)==2 and all(r['submission_sha256']==sha(R/'Verify/current/submissions/two_sat.cpp')for r in normal)
files=['Graph/Two_SAT.cpp','Graph/SCC.cpp','Document/two_sat.md','Examples/two_sat_example.cpp','Verify/current/drivers/two_sat_main.cpp','Verify/current/common/fast_io.hpp','Verify/current/tests/two_sat_acl_api_test.cpp','Verify/current/tests/two_sat_component_test.cpp','Verify/current/tests/new_scc_two_sat_reference_test.cpp','Verify/current/tests/new_graph_allocation_test.cpp']
archive=R/'Audit/data/performance-two-sat-2026-11-04.zip'
evidence=['before.hpp','scc_frozen.cpp','driver.cpp','io.hpp','base.hpp','range.hpp','empty.hpp','cached.hpp','block.hpp','fused.hpp','early.hpp','earlycached.hpp','avx.hpp','final.hpp','msan_gccpath.hpp','micro.cpp','prepare.py','fixtures.json','official_sources.json','probe.py','probes.json','probe.log','avx_probe.cpp','avx_probe.log','screen.py','screen_raw.json','screen.log','final_bench.py','final_raw.json','final_bench.log','micro_bench.py','micro_raw.json','micro_bench.log','adopted_bench.py','adopted_raw.json','adopted_bench.log','adopted_micro.py','adopted_micro_raw.json','adopted_micro.log','adopted_summary.json','reference_tests.py','reference_tests.json','reference_tests.log','final_tests.py','final_tests.json','final_tests.log','msan.py','msan.json','msan.log','generation.log','normal_samples.py','normal_samples.json','normal_samples.log','profiles.log','save_audit.py']
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for f in files:z.write(R/f,f)
 for f in evidence:z.write(D/f,'evidence/'+f)
 for p in (D/'profiles').rglob('*.json'):
  if 'attempts'not in p.parts:z.write(p,'evidence/profiles/'+p.relative_to(D/'profiles').as_posix())
audit={
 'date':'2026-11-04','scope':'通常版TwoSATのオンライン415142確認と、同一main/I/OでのP-Core高速化。公開APIはACL形式を維持。',
 'online':{'url':'https://judge.yosupo.jp/submission/415142','status':'AC','time_ms':100,'memory_bytes':36937728,'source_match_before_change':True,'before_source_sha256':sha(D/'before.hpp'),'confirmation_audit':'Audit/online-two-sat-415142-2026-11-04.json','current_status':'変更後はローカル検証済み、オンライン再提出待ち。AC100msを変更後の記録とは扱わない。'},
 'adopted':[
 'TwoSAT専用の非再帰SCCで成分確定時に相補リテラルの同居を確認し、矛盾を検出したら残りの走査と成分番号反転を省く。単一頂点成分には照合を追加しない。汎用Graph/SCC.cppは一字も変更しない。',
 '制約なしはSCC領域を作らず全falseの解を用意し、制約を持たないままの再判定では既存の解を使う。reset/コピー/ムーブ/swap後もキャッシュと制約の対応を保つ。',
 'GCCはanswer()をbyte配列からvector<bool>の範囲コンストラクタで生成する。Clangとその他は従来の添字代入を維持。内部表現にアクセスせず、標準のコンテナAPIだけを使う。'
 ],
 'invariants':'n=2*変数数は偶数。確定前のentered<n、確定済みはentered=n。idsは成分の確定中だけraw countを使い、以前の成分番号とは重ならない。同じ成分の相補対だけで{-1,{}}を返す。SATでは汎用SCCと成分番号まで一致。解のbyte配列は成功時だけswapし、確保失敗時の旧結果を保持。無辺キャッシュは常に全falseで、返り値は独立コピー。',
 'rejected':{
 'unconditional_range_answer':'GCCでは一様な解の変換が約4割短縮するが、Clangのn=250000の同じ値の解では約13%遅くなるため、Clangには適用しない。ランダムな解ではGCCもほぼ同等。',
 'fused_assignment':'判定と解作成を1ループにするとUNSATにも解用の確保が必要になる。全mainで安定した利益がなく不採用。',
 'portable_block_and_AVX2':'一致検査のblock化/AVX2も比較。AVX2はCPU判定・標準経路込みで検証し、尾端8646検査は通過したが、全mainで確かな優位がないため専用SIMDは追加しない。採用版は標準C++23の経路。'
 },
 'measurement':{
 'machine':subprocess.check_output(['lscpu'],text=True),'compiler_versions':{cc:subprocess.check_output([exe,'--version'],text=True).splitlines()[0]for cc,exe in [('GCC','g++'),('Clang','clang++')]},
 'CPU':'Intel Core i9-14900KのP-Core CPU12（core6、sibling13）。E-Coreを評価対象にしない。計測はCPU12用lockで直列化。',
 'settings':'C++23 -O2、SKIP_RUNTIME_CHECKS。ClangはGCC15のlibstdc++。march/native・最適化pragmaなし。GCC/Clangとも同一main・共通I/O。',
 'whole_main_method':'各組合せ7回、base/control（同じ実行物）/finalの順を乱数化。同じ実行パスにコピーして起動。wait4のuser+system CPU時間中央値。起動・入力・出力を含む。31入力×2コンパイラ×3ラベル×7=1302実行、各入力の出力SHA一致。',
 'API_method':'式の作成を計時外に置き、satisfiable/answer/両方を反復しstd::clockで計時。32/4096/250000変数、無辺/鎖/早期矛盾/矛盾閉路/充足可能乱数。各7回×3ラベルで1638実行。CPUタイマ分解能の影響が大きい無辺O(1)の比率を精密な速度主張に使わない。',
 'fixtures':'Library Checker公式generatorの16入力（掲載seed）と追加15入力。公式generatorはApache-2.0でありCC0の実装根拠にはせず、実行して入力を生成しただけ。原本・大容量入力・バイナリは証拠ZIPへ入れず、URL/seed/入力SHAを残す。',
 'whole_main_summary':summary['whole_main'],'API_summary':summary['API'],
 'interpretation':'公式random_00はGCC39.895→24.355ms、Clang40.050→25.009ms（約38〜39%短縮）。最大級randomは概ね同等でオンライン最大100msの大幅短縮は保証しない。GCCの長鎖は約4〜5%短縮、Clangはほぼ同等。n250000の一様な解のGCC answer単体は約4割短縮、乱数解は同等。追加早期矛盾の判定単体は約半分。',
 'limits':'ローカル計測でありオンラインとCPU/負荷が違う。数%以下の差はcontrolの揺れも併記して解釈する。小規模mainは約1msの起動・I/O等が支配し、Clangのcustom4096 early_unsatでは+0.118msの観測差があるが、同じ式の判定単体は短縮。大規模SATは概ね同等で、全条件で厳密に退行ゼロという主張はしない。'
 },
 'tests':{'reference_and_allocation':ref,'API_and_component':tests,'MemorySanitizer':msan,'coverage':'全探索14533式、公開APIの型/独立answer/未判定・UNSAT/reset/copy/move/swap/無辺再判定、全4頂点グラフを含む67076グラフで32bit・size_t・wrapperを汎用SCCと照合。30万深さ・別相補成分。GCC/Clang・検査有無・両貼付け順。ASan+UBSan、解放追跡。','allocation':'各設定109 failures/1091 successes/live_delta=0。ASanのリーク検出は無効、所有権解放は割当追跡で補足。','msan':'Clang標準経路と、GCC向け範囲変換を強制したソースをClangで計測した4設定。GCC生成機械語のMSan検査ではない。全設定未初期化値の報告なし。'},
 'verify':{'submission':'Verify/current/submissions/two_sat.cpp','normal_samples':normal,'profiles':profiles['counts'],'main_sha256':sha(D/'driver.cpp'),'io_sha256':sha(D/'io.hpp'),'unchanged':True,'new_submission_required':True},
 'license':'今回の変更は自作SCCに2-SATの数学的整合性検査を組み込んだ自作コード。標準コンテナAPIを使用。外部ライブラリの実装は取り込まず、CC0/SPDXと数学・ACL APIの参考URLを維持。',
 'hashes':{f:sha(R/f)for f in files},'evidence':{'path':archive.relative_to(R).as_posix(),'sha256':sha(archive),'files':evidence,'scope':'自作コード・旧版/候補/採用版、測定/テストスクリプトと全raw結果、入力の原典URL/seed/SHA。外部generator原本・バイナリ・大容量入力は含まない。'},
 'synchronization':'通常版・GCC/Clang・速度優先版・使用例・Verifyを同期。5配布ZIPの整合性はDistribution/validation.json。旧オンラインACは旧ハッシュに保持。'
}
(R/'Audit/performance-two-sat-2026-11-04.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n');print('TwoSAT audit saved: 1302 whole-main / 1638 API runs, 20 ASan/reference/allocation + 4 MSan settings PASS')
