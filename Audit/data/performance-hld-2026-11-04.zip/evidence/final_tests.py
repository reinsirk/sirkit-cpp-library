# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,os,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_20261104');rows=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for cc,args in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  for test in ['new_hld_reference_test','new_graph_allocation_test']:
   src=R/f'Verify/current/tests/{test}.cpp';exe=D/f'{cc}_{int(skip)}_{test}';cmd=['taskset','-c','6',*args,'-std=c++23','-O2','-DSIRKIT_DISABLE_SIMD']
   if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
   if test!='new_graph_allocation_test':cmd+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
   cmd+=[str(src),'-o',str(exe)];compiled=subprocess.run(cmd,text=True,capture_output=True);assert compiled.returncode==0,compiled.stderr
   run=['taskset','-c','6',str(exe)];p=subprocess.run(run,capture_output=True,text=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'});row=dict(compiler=cc,skip_runtime_checks=skip,test=test,compile_command=cmd,compile_stderr=compiled.stderr,run_command=run,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,source_sha256=sha(R/'Graph/Heavy_Light_Decomposition.cpp'),test_sha256=sha(src));rows.append(row);print(cc,skip,test,p.returncode,p.stdout.strip(),flush=True);(D/'final_tests.json').write_text(json.dumps(rows,indent=2)+'\n');assert p.returncode==0 and not p.stderr,p.stderr
