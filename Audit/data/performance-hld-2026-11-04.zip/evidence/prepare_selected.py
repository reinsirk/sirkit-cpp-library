# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,hashlib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_20261104');s=(R/'Graph/Heavy_Light_Decomposition.cpp').read_text();rows=[]
for problem in ['jump','sum']:
 code='#define SKIP_RUNTIME_CHECKS\n'+s+'\n'+((D/'fenwick_frozen.cpp').read_text()+'\n'if problem=='sum'else'')+(D/'io.hpp').read_text()+'\n'+(D/f'{problem}_driver.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"','');(D/f'{problem}_selected.cpp').write_text(code)
 for cc,prefix in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  exe=D/f'{cc}_{problem}_selected';cmd=['taskset','-c','6']+prefix+['-std=c++23','-O2','-Wall','-Wextra','-Werror',str(D/f'{problem}_selected.cpp'),'-o',str(exe)];subprocess.run(cmd,check=True)
  target='depth_path'if cc=='clang'and problem=='sum'else'connected'
  data=[]
  for label in ['selected',target]:
   text=D/f'{cc}_{problem}_{label}.text';subprocess.run(['objcopy','--dump-section',f'.text={text}',str(D/f'{cc}_{problem}_{label}')],check=True);data.append(text.read_bytes())
  assert data[0]==data[1],(cc,problem,target)
  rows.append(dict(compiler=cc,problem=problem,command=cmd,source_sha256=hashlib.sha256(s.encode()).hexdigest(),text_sha256=hashlib.sha256(data[0]).hexdigest(),matches_candidate=target))
(D/'selected_machine_code.json').write_text(json.dumps(rows,indent=2)+'\n');print('Selected Verify .text matches previously measured candidates in all four compiler/problem combinations')
