# 重軽分解

`HeavyLightDecomposition`は、木の部分木やパスを一次元配列の区間へ変換します。Segment Treeなどと組み合わせて、木上のパス和・最小値などを扱えます。[本体](../Graph/Heavy_Light_Decomposition.cpp)・[使用例](../Examples/heavy_light_decomposition_example.cpp)を参照してください。

## API

| API | 動作 |
| --- | --- |
| `HeavyLightDecomposition(graph,root=0)` / `build(graph,root=0)` | 無向森を分解／再構築する。 |
| `index(v)` / `vertex_at(i)` / `order()` | 頂点vの配列添字／逆変換／並びのconst参照。 |
| `subtree_range(v,edges=false)` | 部分木を表す半開区間[l,r)。trueなら根vを除く。 |
| `for_each_path(u,v,fn,edges=false)` | パスを進む順にfn(left,right,reversed)を呼ぶ。別の木なら呼ばずfalse。 |
| `path(u,v,edges=false)` | 同じ順序のInterval{left,right,reversed}をvectorで返す。別の木なら空。 |
| `lca(u,v)` / `distance(u,v)` | 最近共通祖先／辺数距離。別の木なら-1。 |
| `kth_ancestor(v,k)` / `jump(u,v,k)` | k個上の祖先／u→vのk番目の頂点。範囲外・別の木は-1。 |
| `parent(v)` / `depth(v)` / `component(v)` / `root_of(v)` | 親（根は-1）／深さ／木の番号／木の根。 |
| `same_component(u,v)` / `is_ancestor(u,v)` | 同じ木か／uがvの祖先か（自身も含む）。 |
| `size()` / `empty()` / `root()` / `component_count()` / `subtree_size(v)` | 頂点数／空か／指定根（空なら-1）／木の数／部分木の頂点数。 |
| `clear()` / `swap(other)` | 空にする／O(1)交換。 |

```cpp
Graph tree{{1}, {0,2}, {1,3}, {2}};
HeavyLightDecomposition hld(tree);
auto [l,r] = hld.subtree_range(1); // 頂点1,2,3に対応する区間。
auto ancestor = hld.lca(2,3);     // 2。
auto intervals = hld.path(0,3);  // パスを配列区間へ変換。
```

## 区間の読み方

部分木は1区間、パスはO(log N)区間へ分かれます。各区間は[left,right)で、reversed=trueならright-1からleftへ逆順に読みます。これを守れば、行列積や関数合成のように順序が重要な演算にも使えます。

辺を扱う場合は子側の頂点位置に辺の値を格納し、edges=trueを指定します。パスではLCAを、部分木では根vを除くため、余計な親辺を含めません。for_each_pathはヒープ確保を行いません。

構築はO(N+M)時間・領域で、長い鎖も反復処理します。パス分解・LCA・距離・祖先・jumpはO(log N)、その他の取得はO(1)です。pathの戻り値にはO(log N)領域を使います。

## 入力と所有

頂点は0..N-1で、対称な隣接リストの無向森が前提です。指定根の木から処理し、残りは最小未訪問頂点を根にします。空の入力にはroot=0を渡します。隣接リストの対称性を検査するためだけの全辺走査はしません。

通常の探索中に頂点範囲・自己辺・閉路・多重辺を検査します。`SKIP_RUNTIME_CHECKS`で検査と検査専用の親辺フラグを除きます。構築失敗時は旧結果を保ち、コピーは独立、move元は空です。orderの参照は再構築・代入・破棄で無効になります。

[参考講座](https://info.atcoder.jp/entry/algorithm_lectures/heavy_light_decomposition)は理論の参考で、実装例の転記ではありません。[独立参照](../Verify/current/tests/new_hld_reference_test.cpp)・[Jump on Tree](https://judge.yosupo.jp/problem/jump_on_tree)
