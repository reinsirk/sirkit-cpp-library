# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,hashlib,json
D=Path('/tmp/sirkit_hld_20261104');R=Path('/home/reinsirk/Atcoder_Env');s=(R/'Graph/Heavy_Light_Decomposition.cpp').read_text();a=s.index('    template<class Fn>');before=s[:a];tail=s[a:];old='''while (head_[u] != head_[v]) {
            if (index_[u] >= index_[v])''';new='''while (head_[u] != head_[v]) {
            if (depth_[head_[u]] >= depth_[head_[v]])''';assert old in tail;depth=before+tail.replace(old,new,1);(D/'depth_path.hpp').write_text(depth);hashes={}
for label,code in [('final',s),('depth_path',depth)]:
 (D/f'{label}.hpp').write_text(code)
 for problem in ['jump','sum']:
  source='#define SKIP_RUNTIME_CHECKS\n'+code+'\n'+((D/'fenwick_frozen.cpp').read_text()+'\n'if problem=='sum'else'')+(D/'io.hpp').read_text()+'\n'+(D/f'{problem}_driver.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"','');(D/f'{problem}_{label}.cpp').write_text(source)
  for cc,prefix in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
   if label=='depth_path'and(cc=='gcc'or problem=='jump'):continue
   exe=D/f'{cc}_{problem}_{label}';subprocess.run(['taskset','-c','6']+prefix+['-std=c++23','-O2','-Wall','-Wextra','-Werror',str(D/f'{problem}_{label}.cpp'),'-o',str(exe)],check=True)
   q=D/f'{cc}_{problem}_{label}.text';subprocess.run(['objcopy','--dump-section',f'.text={q}',str(exe)],check=True);hashes[f'{cc}_{problem}_{label}']=hashlib.sha256(q.read_bytes()).hexdigest()
   if label=='final':
    orig=D/f'{cc}_{problem}_connected.text';subprocess.run(['objcopy','--dump-section',f'.text={orig}',str(D/f'{cc}_{problem}_connected')],check=True);assert q.read_bytes()==orig.read_bytes(),(cc,problem)
(D/'machine_code.json').write_text(json.dumps(hashes,indent=2)+'\n');print('Original lca/same_component preserved; both Verify .text sections identical to measured candidate')
