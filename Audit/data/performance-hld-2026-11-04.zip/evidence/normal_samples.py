# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,json,subprocess,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_20261104');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as p
rows=[]
for e in p.collect():
 if e['id']not in ['hld_jump','hld_vertex_add_path_sum']:continue
 src=R/f'Verify/current/submissions/{e["id"]}.cpp'
 for cc,prefix in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  exe=D/f'normal_{e["id"]}_{cc}';cmd=['taskset','-c','6']+prefix+['-std=c++23','-O2',str(src),'-o',str(exe)];subprocess.run(cmd,check=True)
  for sample in e['samples']:
   run=subprocess.run([str(exe)],input=sample['input'],text=True,capture_output=True,check=True);assert run.stdout.split()==sample['output'].split()
  rows.append(dict(id=e['id'],compiler=cc,status='LOCAL_SAMPLE_PASS',compile_command=cmd,submission_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),samples=len(e['samples'])))
(D/'normal_samples.json').write_text(json.dumps(rows,indent=2)+'\n');print('Both normal submissions: GCC/Clang samples PASS')
