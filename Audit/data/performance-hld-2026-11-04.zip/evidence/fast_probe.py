# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,os,json,hashlib
D=Path('/tmp/sirkit_hld_20261104');rows=[]
for label in ['fast','fast_all']:
 exe=D/f'probe_{label}';cmd=['taskset','-c','6','/usr/bin/g++','-std=c++23','-O2','-fsanitize=address,undefined','-fno-omit-frame-pointer',f'-DHLD_SOURCE="{D}/{label}.hpp"',str(D/'probe_test.cpp'),'-o',str(exe)];subprocess.run(cmd,check=True)
 p=subprocess.run(['taskset','-c','6',str(exe)],text=True,capture_output=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'});rows.append(dict(label=label,command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,source_sha256=hashlib.sha256((D/f'{label}.hpp').read_bytes()).hexdigest()));print(label,p.returncode,p.stdout.strip(),flush=True);(D/'fast_probes.json').write_text(json.dumps(rows,indent=2)+'\n');assert p.returncode==0 and not p.stderr,p.stderr
