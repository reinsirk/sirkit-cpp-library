# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess
D=Path('/tmp/sirkit_hld_20261104')
for label in ['fast','fast_all']:
 code=(D/f'{label}.hpp').read_text()
 for problem in ['jump','sum']:
  s='#define SKIP_RUNTIME_CHECKS\n'+code+'\n'+((D/'fenwick_frozen.cpp').read_text()+'\n'if problem=='sum'else'')+(D/'io.hpp').read_text()+'\n'+(D/f'{problem}_driver.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"','');(D/f'{problem}_{label}.cpp').write_text(s)
  for cc,prefix in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:subprocess.run(['taskset','-c','6']+prefix+['-std=c++23','-O2','-Wall','-Wextra','-Werror',str(D/f'{problem}_{label}.cpp'),'-o',str(D/f'{cc}_{problem}_{label}')],check=True)
