# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,zipfile,subprocess,statistics
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_20261104');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda f:json.loads((D/f).read_text())
for f,snap in [('Graph/Heavy_Light_Decomposition.cpp','adopted.hpp'),('DataStructure/Fenwick_Tree.cpp','fenwick_frozen.cpp'),('Verify/current/common/fast_io.hpp','io.hpp'),('Verify/current/drivers/hld_jump_main.cpp','jump_driver.cpp'),('Verify/current/drivers/hld_vertex_add_path_sum_main.cpp','sum_driver.cpp')]:assert (R/f).read_bytes()==(D/snap).read_bytes(),f
base=(D/'base.hpp').read_text();actual=(D/'adopted.hpp').read_text()
for a,b in [('    int lca(', '    int distance('),('    bool same_component(', '    bool is_ancestor(')]:assert base[base.index(a):base.index(b,base.index(a))]==actual[actual.index(a):actual.index(b,actual.index(a))]
counts={'screen_raw.json':1530,'fast_raw.json':1530,'third_raw.json':972,'full_raw.json':2688,'depth_raw.json':468,'clang_sum_raw.json':651};assert sum(counts.values())==7839
for f,n in counts.items():
 rows=load(f);assert len(rows)==n,(f,len(rows));groups={}
 for r in rows:groups.setdefault((r['compiler'],r['case']),set()).add(r['sha256'])
 assert all(len(s)==1 for s in groups.values())
selected=load('selected_raw.json');summary=load('selected_summary.json');assert len(selected)==2688 and len(summary)==128
for r in summary:assert set(r['medians_cpu_ns'])=={'base','control','selected'}
probes=load('probes.json')+load('fast_probes.json')+load('third_probes.json');assert len(probes)==13 and all(r['returncode']==0 and not r['stderr']for r in probes)
tests=load('final_tests.json');assert len(tests)==8
for r in tests:assert r['returncode']==0 and not r['stderr']and r['source_sha256']==sha(R/'Graph/Heavy_Light_Decomposition.cpp')and r['test_sha256']==sha(R/f'Verify/current/tests/{r["test"]}.cpp')
msan=load('msan.json');assert len(msan)==2 and all(r['attempts'][-1]['returncode']==0 and not r['attempts'][-1]['stderr']for r in msan)
normal=load('normal_samples.json');assert len(normal)==4 and all(r['submission_sha256']==sha(R/f'Verify/current/submissions/{r["id"]}.cpp')for r in normal)
profile=json.loads(sorted((D/'profiles/runs').glob('*.json'))[-1].read_text());assert profile['counts']=={'LOCAL_SAMPLE_PASS':14},profile['counts']
proof=load('selected_machine_code.json');assert len(proof)==4 and all(r['source_sha256']==sha(R/'Graph/Heavy_Light_Decomposition.cpp')for r in proof)
files=['Graph/Heavy_Light_Decomposition.cpp','DataStructure/Fenwick_Tree.cpp','Document/heavy_light_decomposition.md','Examples/heavy_light_decomposition_example.cpp','Verify/current/tests/new_hld_reference_test.cpp','Verify/current/tests/new_graph_allocation_test.cpp','Verify/current/drivers/hld_jump_main.cpp','Verify/current/drivers/hld_vertex_add_path_sum_main.cpp','Verify/current/common/fast_io.hpp']
evidence=['base.hpp','reuse.hpp','light.hpp','build.hpp','jump.hpp','order.hpp','jump_order.hpp','all.hpp','fast.hpp','fast_all.hpp','connected.hpp','packed.hpp','packed_connected.hpp','depth_path.hpp','adopted.hpp','fenwick_frozen.cpp','io.hpp','jump_driver.cpp','sum_driver.cpp','document_before.md','example_before.cpp','test_before.cpp','probe_test.cpp','msan_reference_test.cpp','prepare_candidates.py','prepare_candidates.log','prepare_fast.py','prepare_third.py','prepare_final.py','prepare_final.log','machine_code.json','prepare_selected.py','prepare_selected.log','selected_machine_code.json','probe.py','probes.json','probe.log','fast_probe.py','fast_probes.json','fast_probe.log','third_probe.py','third_probes.json','third_probe.log','screen.py','screen_raw.json','screen.log','fast_bench.py','fast_raw.json','fast_bench.log','third_bench.py','third_raw.json','third_bench.log','full_bench.py','full_raw.json','full_bench.log','depth_bench.py','depth_raw.json','depth_bench.log','clang_sum_bench.py','clang_sum_raw.json','clang_sum_bench.log','selected_raw.json','selected_summary.json','final_tests.py','final_tests.json','final_tests.log','msan.py','msan.json','msan.log','msan_iostream.stderr','normal_samples.py','normal_samples.json','normal_samples.log','generation.log','profiles.log','save_audit.py']
archive=R/'Audit/data/performance-hld-2026-11-04.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for f in files:z.write(R/f,f)
 for f in evidence:z.write(D/f,'evidence/'+f)
 for f in ['fixtures.json','official_sources.json','custom_api_cases.json','prepare_fixtures.py','preparation.log']:z.write(D/'fixtures'/f,'evidence/fixtures/'+f)
 for p in (D/'profiles').rglob('*.json'):
  if 'attempts'not in p.parts:z.write(p,'evidence/profiles/'+p.relative_to(D/'profiles').as_posix())
a={
 'date':'2026-11-04','scope':'通常版HeavyLightDecompositionの初回オンラインVerify確認、使い方の補足、P-Core向け本体高速化。main/共通I/O/Fenwick Treeは固定。',
 'online':{'confirmation':'Audit/online-hld-2026-11-04.json','records':[{'id':'hld_jump','url':'https://judge.yosupo.jp/submission/415167','status':'AC','time_ms':272},{'id':'hld_vertex_add_path_sum','url':'https://judge.yosupo.jp/submission/415168','status':'AC','time_ms':337}],'before_source_sha256':sha(D/'base.hpp'),'current_status':'改修前との一致を確認したAC。現行本体はローカル検証済みで2本とも再提出待ち。通常版ACを派生版へ転記しない。'},
 'adopted':[
 '構築のDFS探索順をorder_へ一時保存し、部分木サイズ/heavy childの逆順集計が終わってから重鎖優先順で上書き。visitedの一時配列4Nバイトとpush_backを除く。heavyの同値選択順・最終の公開orderは維持。',
 '重鎖優先順を作る段階では、対称な無向森の性質から、親とheavy child以外の隣接先をlight childと判定。隣接先ごとのparent_[u]参照を省く。入力の検査は第1DFSに維持し、別の全辺検査は加えない。',
 'jumpをLCA取得＋祖先探索の2段階から、u側で残りkを減らす経路探索へ統合。同一重鎖はindex差だけで答え、kがdepth[u]+depth[v]を超す場合は先に-1。別成分や負のkも除外。入力検査は従来どおりu,vの順で必ず先に行う。',
 'for_each_path/jumpは単一成分なら成分配列の照合を省く。森では従来の照合を保つ。is_ancestorは部分木区間だけで判定でき、別成分の添字も区間外になる。',
 'jumpの重鎖比較には内部で計算したDFS添字を使う。for_each_pathはGCCで添字比較、Clang/その他では従来のhead深さ比較。どちらも通行順・reversed・辺モードを維持。コンパイラ別の選択は測定に基づき、CPU専用命令は追加しない。',
 '独立したlcaとsame_componentのAPIは元の関数本体をそのまま維持。便利な既存APIを残し、同じ機能の別名を追加しない。'
 ],
 'mathematical_and_ownership_review':'対称な無向森では親以外の隣接点は子であり、重鎖は連続したDFS添字になる。別headのうち後ろの添字を持つ鎖は他端点の祖先ではないため、そこを上げても経路を外れない。u側のkを減らすのはk>区間長のときだけ。kのint化前に鎖内の長さで上限を確認し、depth和は先にint64へ昇格。roots_.size()==1は全頂点が同じ木であることを表す。コピー/ムーブ/swapは全配列とroots_を同時に扱う。全所有はvectorのまま、直接new・解放省略なし。',
 'comparison_and_rejections':{
 'single_fused_jump':'統合だけでは小さい木の大量照会や一部の星型・鎖で上積みが弱いため、同一鎖と数学的な距離上限の早期処理を追加。',
 'preorder_for_every_compiler':'GCC/Clangともjumpは有効。経路和はClangのlong-path-decomposition_killerで約2.4〜2.7%遅れたため、Clangの区間分解比較は元に戻す。専用13回再比較では遅れを解消し、最終の公式相当全ケースも確認。',
 'packed_head_metadata':'head頂点とhead深さのpairを配置すると追加4Nバイトが必要で、GCC大規模ランダム/星型などが悪化。成分省略との組合せでも一貫して優位でなく不採用。',
 'unmeasured_extra_API_change':'LCAとsame_componentの比較変更はVerify mainで使わないため採用版では元へ戻す。最終4実行物の.textが測定したcandidateと一致することを確認し、測定対象をすり替えない。'
 },
 'measurement':{
 'CPU':'Intel Core i9-14900KのP-Core CPU12（core6、sibling13）。E-Coreは対象外。CPU12用lockで直列化し、入力生成/重いテスト/他のコンパイルと性能測定を重ねない。CPU設定は変更しない。',
 'compilers':{cc:subprocess.check_output([p,'--version'],text=True).splitlines()[0]for cc,p in [('GCC','/usr/bin/g++'),('Clang','/usr/bin/clang++')]},
 'flags':'-std=c++23 -O2、SKIP_RUNTIME_CHECKS、ClangはGCC15 libstdc++。march/nativeや最適化pragmaなし。PATHにはGCC15.3もあるため/usr/binのGCC15.2へ固定。',
 'method':'同じmain・共通I/O・Fenwick・検査設定。ラベルの順番を乱数化し、同じ実行パスにコピーして起動。wait4のuser+system CPU時間中央値とmax RSSを保存。controlはbaseと同じ実行物。試作5回、再比較9/13回、最終64入力は各7回。',
 'fixtures':'固定commit73876f1cbcf082d2b22722924b924d3d65a2f00eの公式生成器40入力と、32/4096/250000頂点の鎖・星・二分木・ランダム木24入力。頂点番号は無作為に入れ替え。原典/seed/入力SHAを保存。公式入力生成器の再帰だけstack上限を緩めたが、ライブラリ/計測の設定は変更しない。',
 'run_counts':counts,'total_measured_runs':7839,'selected_runs':2688,'selected_groups':128,'selected_summary':summary,'selected_summary_composition':'GCCの全64ケースとClangのjump33ケースはfull_raw.jsonのconnected（最終.text一致）。Clangのpath sum31ケースはclang_sum_raw.jsonのselected。final selected_raw.jsonへ統合。',
 'representative':'Jump max_random_00: GCC157.862→137.148ms（約13%）、Clang194.947→172.195ms（約12%）。small_random_00はGCC15.100→11.697ms、Clang15.550→11.319ms。Path Sumは概ね同等〜数%短縮で、Jumpほど大きい効果はない。',
 'limits':'オンラインとCPU/負荷が違うため再提出結果は未確認。全caseで厳密に退行0とは主張しない。GCC almost_line_01は+2.6%だがcontrolも+8.1%、Clang Path Sum max_random_00もbase/controlに約7%の揺れがある。数%の差はcontrolと併記して解釈する。小さい入力のmainは起動/IOが支配する。',
 'machine_code_equivalence':proof,'extra_SIMD':'重鎖/祖先の依存した走査が中心で、専用SIMDを追加する測定上の根拠はない。標準C++23の実装と既存の自動ベクトル化を利用し、SIRKIT_DISABLE_SIMDのビルドも検証。'
 },
 'tests':{'candidate_ASan_probes':probes,'selected_GCC_Clang_checked_skip':tests,'MemorySanitizer':msan,'coverage':'BFS参照1888601カウンタ。任意のラベル/根/森、全頂点対、lca/distance/kth/jumpの境界とint64極値、経路の向きと辺モード、部分木、copy/move/reset相当clear/build、30万頂点の鎖の両方向。新jumpは不正な頂点と負/最大kの組合せでも先にout_of_rangeを出す。',
 'allocation':'各設定108 failures/1092 successes/live_delta=0。ASanリーク検出は無効、所有解放は割当カウンタで補足。確保失敗時に旧状態を保持。',
 'MSan_output_adaptation':'最初は未計装libstdc++のostream数値整形出力で報告（msan_iostream.stderrに保存）。全assertを維持し、出力だけprintfに替えた同じ試験をchecked/SKIPで実行して報告なし。ライブラリの報告を抑制する設定は使わない。'},
 'usage_and_documentation':{'Document':'Document/heavy_light_decomposition.md','lines':len((R/'Document/heavy_light_decomposition.md').read_text().splitlines()),'characters':len((R/'Document/heavy_light_decomposition.md').read_text()),'example':'Examples/heavy_light_decomposition_example.cpp','changes':'頂点値をindex順に並べる、点加算、経路和、部分木和、0始まりjumpを短い例で説明。完全例にはFenwickとの組合せと向き付き文字列を残す。通常cin/coutの例、Verify mainは変更しない。READMEやDocumentへ履歴・測定の羅列を加えない。'},
 'verify':{'normal_samples':normal,'profiles':profile['counts'],'submissions':['Verify/current/submissions/hld_jump.cpp','Verify/current/submissions/hld_vertex_add_path_sum.cpp'],'main_unchanged':True,'common_IO_unchanged':True,'Fenwick_unchanged':True,'needs_resubmission':True},
 'license':'既存の自作HLDを改稿。外部ライブラリの実装本文を取り込まず、CC0/SPDXとAALの理論参考URLを維持。公式generatorはApache-2.0の検証資料であり、ライブラリ実装の出典とは扱わず、原本を証拠ZIPへ入れない。',
 'hashes':{f:sha(R/f)for f in files},'evidence':{'path':archive.relative_to(R).as_posix(),'sha256':sha(archive),'scope':'自作の変更前/試作/採用版、全コマンド・raw測定・テスト・入力生成再現器と原典/seed/SHA。外部generator原本・497MiBの入力・バイナリは含めない。'},
 'synchronization':'通常版/コンパイラ別/速度優先版、Document/Examples/Verify、5配布ZIPを同期。初回ACは改修前ハッシュへ保持し、現行をACと偽記しない。'
}
(R/'Audit/performance-hld-2026-11-04.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');print('HLD audit saved: 7839 benchmark runs, 64 cases × 2 compilers; final reference/allocation/MSan and 14 profiles + 4 normal samples PASS')
