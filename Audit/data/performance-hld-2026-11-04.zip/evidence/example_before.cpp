// SPDX-License-Identifier: CC0-1.0
#include "../Graph/Heavy_Light_Decomposition.cpp"
#include <cassert>
#include <iostream>
#include <string>
int main(){
 Graph tree{{1,2},{0,3,4},{0},{1},{1}};HeavyLightDecomposition hld(tree);
 assert(hld.lca(3,4)==1);assert(hld.jump(3,2,2)==0);assert(hld.kth_ancestor(4,2)==0);
 std::string label="abcde",path;
 hld.for_each_path(3,2,[&](int l,int r,bool reversed){if(reversed)for(int i=r;i-->l;)path+=label[hld.vertex_at(i)];else for(int i=l;i<r;++i)path+=label[hld.vertex_at(i)];});
 assert(path=="dbac");std::cout<<path<<'\n';
 auto[l,r]=hld.subtree_range(1);assert(r-l==3);auto edges=hld.path(3,2,true);assert(!edges.empty());
}
