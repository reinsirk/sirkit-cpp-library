// SPDX-License-Identifier: CC0-1.0
// 参考（重軽分解の理論）: https://info.atcoder.jp/entry/algorithm_lectures/heavy_light_decomposition
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/heavy_light_decomposition.md
//
// API一覧
// HeavyLightDecomposition(g,root=0)/build(g,root=0): 無向森を反復DFSで分解。O(n+m)時間・領域。
// 頂点番号[0,n)。隣接リストの対称性は前提。rootの木から、残りは最小未訪問頂点から構築する。
// 失敗時は元を保持。空のgにはroot=0。閉路・自己辺・多重辺は検査有効時に例外。
// size()/empty()/root()/component_count(): 頂点数/空か/指定根（空なら-1）/木の数。O(1)。
// parent(v)/depth(v)/component(v)/root_of(v): 親（根は-1）/深さ/木の番号/木の根。O(1)。
// index(v)/vertex_at(i)/order(): heavy優先DFS添字/対応頂点/順序配列へのconst参照。O(1)。
// same_component(u,v)/is_ancestor(u,v): 同じ木か/祖先か（自身を含む）。O(1)。
// subtree_range(v,edges=false): 部分木の半開区間。edges=trueは根vを除き子側の頂点で辺を表す。O(1)。
// subtree_size(v): 部分木の頂点数。O(1)。lca(u,v)/distance(u,v): LCA/辺数、異なる木は-1。O(log n)。
// kth_ancestor(v,k): k個上の頂点。k<0/根を越すと-1。jump(u,v,k): u→vのk番目、範囲外/異なる木は-1。O(log n)。
// for_each_path(u,v,fn,edges=false): 通行順にfn(left,right,reversed)を呼ぶ。接続ならtrue、異なる木はfalse。
// reversed=trueはright-1からleftへ読む。区間は半開。edges=trueはLCAを除く。O(log n)、ヒープ確保なし。
// path(u,v,edges=false): 同じ順序のInterval{left,right,reversed}配列を返す。異なる木は空。O(log n)時間・領域。
// clear()/swap(other): 空に戻す/O(1)交換。コピーは独立所有、ムーブ元は空。検査はSKIP_RUNTIME_CHECKSで除く。

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <utility>
#include <vector>

#ifndef SIRKIT_UNWEIGHTED_GRAPH_DEFINED
#define SIRKIT_UNWEIGHTED_GRAPH_DEFINED
using Graph = std::vector<std::vector<int>>;
#endif

#ifndef SIRKIT_HEAVY_LIGHT_DECOMPOSITION_DEFINED
#define SIRKIT_HEAVY_LIGHT_DECOMPOSITION_DEFINED
class HeavyLightDecomposition {
public:
    struct Interval { int left; int right; bool reversed; };
private:
    int root_ = -1;
    std::vector<int> parent_, depth_, component_, roots_, subtree_, heavy_, head_, index_, order_;
#ifndef SKIP_RUNTIME_CHECKS
    void vertex(int v) const {
        if (v < 0 || v >= size()) throw std::out_of_range("HLD: vertex out of range");
    }
#endif
    void prepare(const Graph& graph, int root) {
        if (graph.size() > static_cast<std::size_t>(std::numeric_limits<int>::max()))
            throw std::length_error("HLD: too many vertices");
        const int n = static_cast<int>(graph.size());
#ifndef SKIP_RUNTIME_CHECKS
        if ((n == 0 && root != 0) || (n != 0 && (root < 0 || root >= n)))
            throw std::out_of_range("HLD: root out of range");
#endif
        if (n == 0) return;
        root_ = root;
        parent_.assign(n, -2); depth_.resize(n); component_.resize(n); subtree_.assign(n, 1);
        heavy_.assign(n, -1); head_.resize(n); index_.resize(n); order_.resize(n);
        std::vector<int> visited, stack;
        visited.reserve(n); stack.reserve(n);
        const auto discover = [&](int start) {
            const int id = static_cast<int>(roots_.size()); roots_.push_back(start);
            parent_[start] = -1; component_[start] = id; stack.push_back(start);
            while (!stack.empty()) {
                const int v = stack.back(); stack.pop_back(); visited.push_back(v);
#ifndef SKIP_RUNTIME_CHECKS
                bool parent_seen = false;
#endif
                for (int u : graph[v]) {
#ifndef SKIP_RUNTIME_CHECKS
                    vertex(u);
#endif
                    if (u == parent_[v]) {
#ifndef SKIP_RUNTIME_CHECKS
                        if (parent_seen) throw std::invalid_argument("HLD: parallel edge");
                        parent_seen = true;
#endif
                        continue;
                    }
#ifndef SKIP_RUNTIME_CHECKS
                    if (parent_[u] != -2) throw std::invalid_argument("HLD: input must be a forest");
#endif
                    parent_[u] = v; depth_[u] = depth_[v] + 1;
                    component_[u] = id; stack.push_back(u);
                }
            }
        };
        discover(root);
        for (int v = 0; v < n; ++v) if (parent_[v] == -2) discover(v);
        for (std::size_t i = visited.size(); i != 0;) {
            const int v = visited[--i], parent = parent_[v];
            if (parent != -1) {
                subtree_[parent] += subtree_[v];
                if (heavy_[parent] == -1 || subtree_[v] > subtree_[heavy_[parent]]) heavy_[parent] = v;
            }
        }
        int position = 0;
        for (int start : roots_) {
            stack.push_back(start);
            while (!stack.empty()) {
                const int first = stack.back(); stack.pop_back();
                for (int v = first; v != -1; v = heavy_[v]) {
                    head_[v] = first; index_[v] = position; order_[position++] = v;
                    for (int u : graph[v]) if (parent_[u] == v && u != heavy_[v]) stack.push_back(u);
                }
            }
        }
    }
public:
    HeavyLightDecomposition() = default;
    explicit HeavyLightDecomposition(const Graph& graph, int root = 0) { prepare(graph, root); }
    HeavyLightDecomposition(const HeavyLightDecomposition&) = default;
    HeavyLightDecomposition(HeavyLightDecomposition&& other) noexcept { swap(other); }
    HeavyLightDecomposition& operator=(HeavyLightDecomposition other) noexcept { swap(other); return *this; }
    void swap(HeavyLightDecomposition& other) noexcept {
        std::swap(root_, other.root_); parent_.swap(other.parent_); depth_.swap(other.depth_);
        component_.swap(other.component_); roots_.swap(other.roots_); subtree_.swap(other.subtree_);
        heavy_.swap(other.heavy_); head_.swap(other.head_); index_.swap(other.index_); order_.swap(other.order_);
    }
    void clear() noexcept { HeavyLightDecomposition replacement; swap(replacement); }
    void build(const Graph& graph, int root = 0) { HeavyLightDecomposition replacement(graph, root); swap(replacement); }
    int size() const noexcept { return static_cast<int>(parent_.size()); }
    bool empty() const noexcept { return parent_.empty(); }
    int root() const noexcept { return root_; }
    int component_count() const noexcept { return static_cast<int>(roots_.size()); }
    int parent(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return parent_[v];
    }
    int depth(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return depth_[v];
    }
    int component(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return component_[v];
    }
    int root_of(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return roots_[component_[v]];
    }
    int index(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return index_[v];
    }
    int vertex_at(int i) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(i);
#endif
        return order_[i];
    }
    const std::vector<int>& order() const noexcept { return order_; }
    bool same_component(int u, int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        return component_[u] == component_[v];
    }
    bool is_ancestor(int u, int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        return component_[u] == component_[v] && index_[u] <= index_[v] && index_[v] < index_[u] + subtree_[u];
    }
    std::pair<int, int> subtree_range(int v, bool edges = false) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return {index_[v] + static_cast<int>(edges), index_[v] + subtree_[v]};
    }
    int subtree_size(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return subtree_[v];
    }
    int lca(int u, int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        if (component_[u] != component_[v]) return -1;
        while (head_[u] != head_[v]) {
            if (index_[u] > index_[v]) u = parent_[head_[u]];
            else v = parent_[head_[v]];
        }
        return index_[u] < index_[v] ? u : v;
    }
    int distance(int u, int v) const {
        const int w = lca(u, v);
        return w == -1 ? -1 : (depth_[u] - depth_[w]) + (depth_[v] - depth_[w]);
    }
    int kth_ancestor(int v, std::int64_t k) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        if (k < 0 || k > depth_[v]) return -1;
        for (;;) {
            const int within = depth_[v] - depth_[head_[v]];
            if (k <= within) return order_[index_[v] - static_cast<int>(k)];
            k -= static_cast<std::int64_t>(within) + 1; v = parent_[head_[v]];
        }
    }
    int jump(int u, int v, std::int64_t k) const {
        const int w = lca(u, v);
        if (w == -1 || k < 0) return -1;
        const int upward = depth_[u] - depth_[w], downward = depth_[v] - depth_[w];
        if (k > static_cast<std::int64_t>(upward) + downward) return -1;
        return k <= upward ? kth_ancestor(u, k) : kth_ancestor(v, upward + downward - k);
    }
    template<class Fn>
    bool for_each_path(int u, int v, Fn&& visit, bool edges = false) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        if (component_[u] != component_[v]) return false;
        std::array<Interval, std::numeric_limits<unsigned int>::digits + 1> downward;
        std::size_t count = 0;
        while (head_[u] != head_[v]) {
            if (index_[u] >= index_[v]) {
                visit(index_[head_[u]], index_[u] + 1, true); u = parent_[head_[u]];
            } else {
                downward[count++] = {index_[head_[v]], index_[v] + 1, false}; v = parent_[head_[v]];
            }
        }
        if (index_[u] >= index_[v]) {
            const int left = index_[v] + static_cast<int>(edges), right = index_[u] + 1;
            if (left < right) visit(left, right, true);
        } else {
            const int left = index_[u] + static_cast<int>(edges), right = index_[v] + 1;
            if (left < right) downward[count++] = {left, right, false};
        }
        while (count != 0) { const auto part = downward[--count]; visit(part.left, part.right, part.reversed); }
        return true;
    }
    std::vector<Interval> path(int u, int v, bool edges = false) const {
        std::vector<Interval> result;
        for_each_path(u, v, [&](int left, int right, bool reverse) { result.push_back({left, right, reverse}); }, edges);
        return result;
    }
};
#endif
