# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,subprocess,os,statistics,random,fcntl,shutil,hashlib
D=Path('/tmp/sirkit_hld_20261104');rng=random.Random(20261104);raw=[]
names=['official_jump_on_tree_small_random_0','official_jump_on_tree_random_0','official_jump_on_tree_max_random_0','official_jump_on_tree_uni_0','official_jump_on_tree_almost_uni_0','official_jump_on_tree_almost_line_0','official_jump_on_tree_line_0','custom_jump_on_tree_250000_balanced','custom_jump_on_tree_250000_random','official_vertex_add_path_sum_random_0','official_vertex_add_path_sum_max_random_0','official_vertex_add_path_sum_line_0','official_vertex_add_path_sum_almost_line_0','official_vertex_add_path_sum_long-path-decomposition_killer_0','custom_vertex_add_path_sum_250000_star','custom_vertex_add_path_sum_250000_balanced','custom_vertex_add_path_sum_250000_random']
fixtures={f['name']:f for f in json.loads((D/'fixtures/fixtures.json').read_text())}
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for case in names:
   f=fixtures[case];problem='jump'if f['problem']=='jump_on_tree'else'sum'
   for rep in range(5):
    labels=['base','control','reuse','light','build','jump','order','jump_order','all'];rng.shuffle(labels)
    for label in labels:
     shutil.copyfile(D/f'{cc}_{problem}_{"base"if label=="control"else label}',D/'active');(D/'active').chmod(0o700)
     with Path(f['path']).open('rb')as fi,(D/'output').open('wb')as fo:
      p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0
     raw.append(dict(compiler=cc,case=case,problem=problem,rep=rep,label=label,cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),max_rss_bytes=ru.ru_maxrss*1024,sha256=hashlib.sha256((D/'output').read_bytes()).hexdigest()))
   rr=[r for r in raw if r['compiler']==cc and r['case']==case];assert len({r['sha256']for r in rr})==1;m={l:statistics.median(r['cpu_ns']for r in rr if r['label']==l)for l in labels};print(cc,case,{k:round(x/m['base'],4)for k,x in m.items()},flush=True);(D/'screen_raw.json').write_text(json.dumps(raw))
