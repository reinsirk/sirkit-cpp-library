# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess
D=Path('/tmp/sirkit_hld_20261104');s=(D/'base.hpp').read_text()
reuse=s.replace('''        std::vector<int> visited, stack;
        visited.reserve(n); stack.reserve(n);''','''        std::vector<int> stack;
        stack.reserve(n);
        std::size_t visited_count = 0;''').replace('visited.push_back(v);','order_[visited_count++] = v;').replace('i = visited.size();','i = visited_count;').replace('visited[--i]','order_[--i]')
light=s.replace('''                    for (int u : graph[v]) if (parent_[u] == v && u != heavy_[v]) stack.push_back(u);''','''                    const int parent = parent_[v], heavy = heavy_[v];
                    for (int u : graph[v]) if (u != parent && u != heavy) stack.push_back(u);''')
build=reuse.replace('''                    for (int u : graph[v]) if (parent_[u] == v && u != heavy_[v]) stack.push_back(u);''','''                    const int parent = parent_[v], heavy = heavy_[v];
                    for (int u : graph[v]) if (u != parent && u != heavy) stack.push_back(u);''')
old='''        const int w = lca(u, v);
        if (w == -1 || k < 0) return -1;
        const int upward = depth_[u] - depth_[w], downward = depth_[v] - depth_[w];
        if (k > static_cast<std::int64_t>(upward) + downward) return -1;
        return k <= upward ? kth_ancestor(u, k) : kth_ancestor(v, upward + downward - k);'''
new='''#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        if (component_[u] != component_[v] || k < 0) return -1;
        const int destination = v;
        while (head_[u] != head_[v]) {
            if (depth_[head_[u]] >= depth_[head_[v]]) {
                const int within = depth_[u] - depth_[head_[u]];
                if (k <= within) return order_[index_[u] - static_cast<int>(k)];
                k -= static_cast<std::int64_t>(within) + 1;
                u = parent_[head_[u]];
            } else v = parent_[head_[v]];
        }
        if (depth_[u] >= depth_[v]) {
            const int within = depth_[u] - depth_[v];
            if (k <= within) return order_[index_[u] - static_cast<int>(k)];
            k -= within;
            const int downward = depth_[destination] - depth_[v];
            return k > downward ? -1 : kth_ancestor(destination, downward - k);
        }
        const int within = depth_[v] - depth_[u];
        if (k <= within) return order_[index_[u] + static_cast<int>(k)];
        const int downward = depth_[destination] - depth_[u];
        return k > downward ? -1 : kth_ancestor(destination, downward - k);'''
assert old in s
jump=s.replace(old,new)
order=s.replace('depth_[head_[u]] > depth_[head_[v]]','index_[u] > index_[v]').replace('depth_[head_[u]] >= depth_[head_[v]]','index_[u] >= index_[v]').replace('return depth_[u] < depth_[v] ? u : v;','return index_[u] < index_[v] ? u : v;').replace('if (depth_[u] >= depth_[v])','if (index_[u] >= index_[v])')
jump_order=jump.replace('depth_[head_[u]] >= depth_[head_[v]]','index_[u] >= index_[v]')
all_code=build.replace(old,new).replace('depth_[head_[u]] > depth_[head_[v]]','index_[u] > index_[v]').replace('depth_[head_[u]] >= depth_[head_[v]]','index_[u] >= index_[v]').replace('return depth_[u] < depth_[v] ? u : v;','return index_[u] < index_[v] ? u : v;').replace('if (depth_[u] >= depth_[v])','if (index_[u] >= index_[v])')
for label,code in [('base',s),('reuse',reuse),('light',light),('build',build),('jump',jump),('order',order),('jump_order',jump_order),('all',all_code)]:
 (D/f'{label}.hpp').write_text(code)
 for problem in ['jump','sum']:
  source='#define SKIP_RUNTIME_CHECKS\n'+code+'\n'+((D/'fenwick_frozen.cpp').read_text()+'\n'if problem=='sum'else'')+(D/'io.hpp').read_text()+'\n'+(D/f'{problem}_driver.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"','');(D/f'{problem}_{label}.cpp').write_text(source)
  for cc,prefix in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
   subprocess.run(['taskset','-c','6']+prefix+['-std=c++23','-O2','-Wall','-Wextra','-Werror',str(D/f'{problem}_{label}.cpp'),'-o',str(D/f'{cc}_{problem}_{label}')],check=True)
 print('built',label,flush=True)
