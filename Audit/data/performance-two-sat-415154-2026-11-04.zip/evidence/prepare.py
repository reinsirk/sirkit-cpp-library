# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,re,subprocess
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_two_sat_415154_20261104');P=Path('/tmp/sirkit_two_sat_speed_20261104')
j=json.loads((D/'415154.json').read_text());(D/'uploaded.cpp').write_bytes(j['source'].encode());s=(R/'Graph/Two_SAT.cpp').read_text();(D/'base.hpp').write_text(s)
for f,name in [('Verify/current/drivers/two_sat_main.cpp','driver.cpp'),('Verify/current/common/fast_io.hpp','io.hpp'),('Graph/SCC.cpp','scc_frozen.cpp')]: (D/name).write_bytes((R/f).read_bytes())
normalize=lambda t:'\n'.join(l.rstrip()for l in t.replace('\r\n','\n').splitlines()if l.strip()and not l.startswith('// Submission:'))
assert normalize(j['source'])==normalize((R/'Verify/current/submissions/two_sat.cpp').read_text())
old='''    std::vector<Index> begin(static_cast<std::size_t>(n) + 1);
    for (auto [u, v] : edges) { (void)v; ++begin[static_cast<std::size_t>(u) + 1]; }
    for (int v = 0; v < n; ++v) begin[v + 1] += begin[v];
    std::vector<Index> next(begin.begin() + 1, begin.end());'''
aos='''    struct State { Index end = 0, next = 0; int entered = -1; };
    std::vector<State> state(n);
    for (auto [u, v] : edges) { (void)v; ++state[u].end; }
    Index total = 0;
    for (auto& row : state) { total += row.end; row.end = row.next = total; }'''
a=s.replace(old,aos).replace('    std::vector<int> entered(n, -1), ids(n), dfs, pending;','    std::vector<int> ids(n), dfs, pending;')
assert a!=s
# Replace array access without changing owned vectors except row fields.
a=re.sub(r'begin\[([^\[\]]+) \+ 1\]',r'state[\1].end',a)
a=re.sub(r'next\[([^\[\]]+)\]',r'state[\1].next',a)
a=re.sub(r'entered\[([^\[\]]+)\]',r'state[\1].entered',a)
assert 'begin['not in a and 'next['not in a and 'entered['not in a
raw=s.replace('    for (auto& id : ids) id = count - 1 - id;\n','').replace('ids[v] = n - 1 - v;','ids[v] = v;').replace('result[i] = ids[2 * i] < ids[2 * i + 1];','result[i] = ids[2 * i] > ids[2 * i + 1];')
both=a.replace('    for (auto& id : ids) id = count - 1 - id;\n','').replace('ids[v] = n - 1 - v;','ids[v] = v;').replace('result[i] = ids[2 * i] < ids[2 * i + 1];','result[i] = ids[2 * i] > ids[2 * i + 1];')
for label,code in [('base',s),('aos',a),('raw',raw),('both',both)]:
 (D/f'{label}.hpp').write_text(code);source='#define SKIP_RUNTIME_CHECKS\n'+code+'\n'+(D/'io.hpp').read_text()+'\n'+(D/'driver.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"','');(D/f'{label}.cpp').write_text(source)
 for cc,prefix in [('gcc',['g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:subprocess.run(['taskset','-c','4']+prefix+['-std=c++23','-O2','-Wall','-Wextra','-Werror',str(D/f'{label}.cpp'),'-o',str(D/f'{cc}_{label}')],check=True)
print('Source match confirmed; four variants built')
