# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,json,subprocess,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_two_sat_415154_20261104');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as p;from verify_graph_samples import check_two_sat
entry=next(e for e in p.collect() if e['id']=='two_sat');rows=[];source=R/'Verify/current/submissions/two_sat.cpp'
for cc,prefix in [('GCC',['g++']),('Clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 command=['taskset','-c','4']+prefix+['-std=c++23','-O2',str(source),'-o',str(D/f'normal_{cc}')];subprocess.run(command,check=True)
 for sample in entry['samples']:
  run=subprocess.run([str(D/f'normal_{cc}')],input=sample['input'],text=True,capture_output=True);assert run.returncode==0 and check_two_sat(entry,sample,run.stdout),(cc,run.stdout,run.stderr)
 rows.append(dict(compiler=cc,status='LOCAL_SAMPLE_PASS',compile_command=command,submission_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),samples=len(entry['samples'])))
(D/'normal_samples.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows)
