# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,subprocess,statistics,random,fcntl
D=Path('/tmp/sirkit_two_sat_415154_20261104');rng=random.Random(415142);raw=[]
compilers={'gcc':['/usr/bin/g++'],'clang':['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']}
for cc,prefix in compilers.items():
 for label in ['base','unique','unique_init']:
  command=['taskset','-c','4']+prefix+['-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_TWO_SAT_BENCH_SOURCE="{D}/{label}.hpp"',str(D/'micro.cpp'),'-o',str(D/f'micro_{cc}_{label}')]
  subprocess.run(command,check=True)
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in compilers:
  for n in [32,4096,250000]:
   for kind in ['chain','early_unsat','cycle_unsat','planted']:
    for mode in ['sat','sat_answer']:
     if mode=='answer'and'unsat'in kind:continue
     reps={32:20000,4096:150,250000:3}[n]
     if kind=='empty'and mode=='sat':reps={32:30000,4096:300,250000:15}[n]
     for rep in range(7):
      labels=['base','control','unique','unique_init'];rng.shuffle(labels)
      for label in labels:
       exe=D/f'micro_{cc}_{"base"if label=="control"else label}'
       output=subprocess.check_output(['taskset','-c','12',str(exe),str(n),kind,mode,str(reps)],text=True).split();ns,total=map(int,output)
       raw.append(dict(compiler=cc,n=n,kind=kind,mode=mode,rep=rep,label=label,cpu_ns=ns,reps=reps,checksum=total))
     rr=[r for r in raw if r['compiler']==cc and r['n']==n and r['kind']==kind and r['mode']==mode];assert len({r['checksum']for r in rr})==1;m={l:statistics.median(r['cpu_ns']for r in rr if r['label']==l)for l in labels};print(cc,n,kind,mode,{k:round(x/m['base'],4)for k,x in m.items()},flush=True);(D/'micro_raw.json').write_text(json.dumps(raw))
