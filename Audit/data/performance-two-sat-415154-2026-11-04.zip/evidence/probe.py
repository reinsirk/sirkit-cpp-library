# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,os,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_two_sat_415154_20261104');rows=[]
for label in ['aos','raw','both','room','insert','resize','fused','unique']:
 exe=D/f'probe_{label}';cmd=['taskset','-c','4','/usr/bin/g++','-std=c++23','-O2','-fsanitize=address,undefined','-fno-omit-frame-pointer',f'-DSIRKIT_TWO_SAT_TEST_SOURCE="{D/(label+".hpp")}"',str(R/'Verify/current/tests/two_sat_acl_api_test.cpp'),'-o',str(exe)];subprocess.run(cmd,check=True);p=subprocess.run(['taskset','-c','4',str(exe)],capture_output=True,text=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'});rows.append(dict(label=label,command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));print(label,p.returncode,p.stdout.strip(),flush=True);assert p.returncode==0 and not p.stderr,p.stderr
(D/'probes.json').write_text(json.dumps(rows,indent=2)+'\n')
