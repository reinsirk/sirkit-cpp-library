# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess
D=Path('/tmp/sirkit_two_sat_415154_20261104');s=(D/'base.hpp').read_text()
room=s.replace('''        const auto maximum = implications_.max_size(), current = implications_.size();
        if (extra > maximum - current) throw std::length_error("two_sat: too many clauses");
        if (implications_.capacity() - current >= extra) return;''','''        const auto current = implications_.size();
        if (implications_.capacity() - current >= extra) return;
        const auto maximum = implications_.max_size();
        if (extra > maximum - current) throw std::length_error("two_sat: too many clauses");''')
insert=s.replace('''        implications_.emplace_back(2 * i + !a, 2 * j + b);
        implications_.emplace_back(2 * j + !b, 2 * i + a);''','''        const std::pair<int,int> arcs[2]{{2 * i + !a, 2 * j + b},{2 * j + !b, 2 * i + a}};
        implications_.insert(implications_.end(), arcs, arcs + 2);''')
resize=s.replace('''        implications_.emplace_back(2 * i + !a, 2 * j + b);
        implications_.emplace_back(2 * j + !b, 2 * i + a);''','''        const auto at = implications_.size();
        implications_.resize(at + 2);
        implications_[at] = {2 * i + !a, 2 * j + b};
        implications_[at + 1] = {2 * j + !b, 2 * i + a};''')
fused=s.replace('''    for (int v = 0; v < n; ++v) begin[v + 1] += begin[v];
    std::vector<Index> next(begin.begin() + 1, begin.end());''','''    auto next = std::make_unique_for_overwrite<Index[]>(n);
    for (int v = 0; v < n; ++v) {
        begin[v + 1] += begin[v];
        next[v] = begin[v + 1];
    }''')
unique=s.replace('std::pair<int, std::vector<int>>','std::pair<int, std::unique_ptr<int[]>>').replace('    std::vector<int> entered(n, -1), ids(n), dfs, pending;','    auto ids = std::make_unique_for_overwrite<int[]>(n);\n    std::vector<int> entered(n, -1), dfs, pending;').replace('    for (auto& id : ids) id = count - 1 - id;','    for (int v = 0; v < n; ++v) ids[v] = count - 1 - ids[v];').replace('        std::vector<int> ids(n);','        auto ids = std::make_unique_for_overwrite<int[]>(n);')
for label,code in [('room',room),('insert',insert),('resize',resize),('fused',fused),('unique',unique)]:
 assert code!=s; (D/f'{label}.hpp').write_text(code);source='#define SKIP_RUNTIME_CHECKS\n'+code+'\n'+(D/'io.hpp').read_text()+'\n'+(D/'driver.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"','');(D/f'{label}.cpp').write_text(source)
 for cc,prefix in [('gcc',['g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:subprocess.run(['taskset','-c','4']+prefix+['-std=c++23','-O2','-Wall','-Wextra','-Werror',str(D/f'{label}.cpp'),'-o',str(D/f'{cc}_{label}')],check=True)
print('5 more variants built')
