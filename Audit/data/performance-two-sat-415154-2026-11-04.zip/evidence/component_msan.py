# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,os,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_two_sat_415154_20261104');rows=[]
for skip in [False,True]:
 src=R/'Verify/current/tests/two_sat_component_test.cpp';exe=D/f'component_msan_{int(skip)}';cmd=['taskset','-c','6','clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-std=c++23','-O1','-fsanitize=memory','-fsanitize-memory-track-origins=2','-fno-omit-frame-pointer','-fPIE','-pie']
 if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
 cmd+=[str(src),'-o',str(exe)];subprocess.run(cmd,check=True);attempts=[]
 for attempt in range(8):
  run=['taskset','-c','6',str(exe)];p=subprocess.run(run,text=True,capture_output=True,env={**os.environ,'MSAN_OPTIONS':'halt_on_error=1'});attempts.append(dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
  if p.returncode==0:break
  assert 'out of application range'in p.stderr or 'can not mmap the shadow memory'in p.stderr,p.stderr
 assert p.returncode==0 and not p.stderr,p.stderr
 rows.append(dict(skip_runtime_checks=skip,compile_command=cmd,run_command=run,attempts=attempts,source_sha256=hashlib.sha256((R/'Graph/Two_SAT.cpp').read_bytes()).hexdigest(),test_sha256=hashlib.sha256(src.read_bytes()).hexdigest()));(D/'component_msan.json').write_text(json.dumps(rows,indent=2)+'\n');print(skip,p.stdout.strip(),flush=True)
