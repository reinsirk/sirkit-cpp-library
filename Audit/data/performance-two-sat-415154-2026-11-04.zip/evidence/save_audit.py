# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,zipfile,statistics,subprocess
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_two_sat_415154_20261104');P=Path('/tmp/sirkit_two_sat_speed_20261104');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda f:json.loads((D/f).read_text())
for f,frozen in [('Graph/Two_SAT.cpp','base.hpp'),('Graph/SCC.cpp','scc_frozen.cpp'),('Verify/current/drivers/two_sat_main.cpp','driver.cpp'),('Verify/current/common/fast_io.hpp','io.hpp'),('Verify/current/tests/two_sat_component_test.cpp','component_before.cpp')]:assert (R/f).read_bytes()==(D/frozen).read_bytes(),f
s=(D/'component_before.cpp').read_text().replace('check(result->second.empty());','check(result->second == nullptr);').replace('''            check(*result == reference);
            check(result->second.size() == static_cast<std::size_t>(n));''','''            check(result->first == reference.first);
            check(result->second != nullptr || n == 0);
            check(std::equal(reference.second.begin(), reference.second.end(), result->second.get()));''');(D/'component_unique.cpp').write_text(s)
counts={'screen_raw.json':700,'more_raw.json':980,'unique_screen_raw.json':1100,'final_raw.json':1674,'micro_raw.json':1344};summaries={}
for f,count in counts.items():
 a=load(f);assert len(a)==count,(f,len(a));keys=['compiler','n','kind','mode']if f=='micro_raw.json'else['compiler','case'];groups={}
 for row in a:groups.setdefault(tuple(row[k]for k in keys),[]).append(row)
 summary=[]
 for key,rows in groups.items():
  measure={label:statistics.median(r['cpu_ns']for r in rows if r['label']==label)for label in dict.fromkeys(r['label']for r in rows)}
  if f!='micro_raw.json':assert len({r['sha256']for r in rows})==1
  else:assert len({r['checksum']for r in rows})==1
  summary.append(dict(zip(keys,key),medians_cpu_ns=measure,ratios_to_base={l:x/measure['base']for l,x in measure.items()}))
 summaries[f]=summary
(D/'summaries.json').write_text(json.dumps(summaries,indent=2)+'\n')
probes=load('probes.json');assert len(probes)==8 and all(r['returncode']==0 and not r['stderr']for r in probes)
tests=load('final_tests.json')+load('reference_tests.json');assert len(tests)==20
for r in tests:
 assert r['returncode']==0 and not r['stderr'];assert r['source_sha256']==sha(D/'adopted.hpp');testpath=D/'component_unique.cpp'if r['test']=='two_sat_component_test'else R/f'Verify/current/tests/{r["test"]}.cpp';assert sha(testpath)==r['test_sha256'],r['test']
msan=load('msan.json')+load('component_msan.json');assert len(msan)==6 and all(r['attempts'][-1]['returncode']==0 and not r['attempts'][-1]['stderr']for r in msan)
normal=load('normal_samples.json');assert all(r['submission_sha256']==sha(R/'Verify/current/submissions/two_sat.cpp')for r in normal)
# 同じ標準ライブラリ経路の候補はコード領域の一致も確認する。
code_hashes={}
for cc in ['gcc','clang']:
 for label in ['base','unique','unique_init','conditional']:
  p=D/f'{cc}_{label}';q=D/f'{cc}_{label}.text';subprocess.run(['objcopy','--dump-section',f'.text={q}',str(p)],check=True);code_hashes[f'{cc}_{label}']=sha(q)
assert code_hashes['gcc_unique']==code_hashes['gcc_conditional'];assert code_hashes['clang_unique_init']==code_hashes['clang_conditional']
archive=R/'Audit/data/performance-two-sat-415154-2026-11-04.zip'
evidence=['base.hpp','aos.hpp','raw.hpp','both.hpp','room.hpp','insert.hpp','resize.hpp','fused.hpp','unique.hpp','unique_init.hpp','conditional.hpp','adopted.hpp','scc_frozen.cpp','driver.cpp','io.hpp','component_before.cpp','component_unique.cpp','msan_gccpath.hpp','prepare.py','more.py','screen.py','screen_raw.json','screen.log','more_bench.py','more_raw.json','more_bench.log','unique_screen.py','unique_screen_raw.json','unique_screen.log','full_bench.py','final_raw.json','full_bench.log','micro.cpp','micro_bench.py','micro_raw.json','micro_bench.log','summaries.json','probe.py','probes.json','probe.log','final_tests.py','final_tests.json','final_tests.log','reference_tests.py','reference_tests.json','reference_tests.log','msan.py','msan.json','msan.log','component_msan.py','component_msan.json','component_msan.log','generation.log','normal_samples.py','normal_samples.json','normal_samples.log','save_audit.py']
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for f in evidence:z.write(D/f,'evidence/'+f)
 for f in ['fixtures.json','official_sources.json']:z.write(P/f,'evidence/'+f)
 for f in ['Graph/Two_SAT.cpp','Graph/SCC.cpp','Verify/current/drivers/two_sat_main.cpp','Verify/current/common/fast_io.hpp','Verify/current/tests/two_sat_component_test.cpp','Verify/current/tests/two_sat_acl_api_test.cpp','Verify/current/tests/new_scc_two_sat_reference_test.cpp','Verify/current/tests/new_graph_allocation_test.cpp']:z.write(R/f,f)
online=load('415154.json');previous=json.loads((P/'415142.json').read_text());a={
 'date':'2026-11-04','decision':'追加の本体変更なし。415154でAC92msとなった成分確定時矛盾検出・無辺再判定・GCC answer範囲変換を維持。試作の本体と補足テストは元へ戻し、SHA一致を確認。再提出不要。',
 'online':{'url':'https://judge.yosupo.jp/submission/415154','status':'AC','time_ms':92,'previous_ms':100,'improvement_percent':8.0,'memory_bytes':online['overview']['memory'],'source_matches_current':True,'confirmation_audit':'Audit/online-two-sat-415154-2026-11-04.json','current_source_sha256':sha(R/'Graph/Two_SAT.cpp'),'needs_resubmission':False,'notable_case':'random_00 64→41ms。最大級random 87〜92ms。long_chain_02は53→61msの観測差も残るため、オンライン全条件が短縮したとは主張しない。'},
 'proposals':[
 {'labels':['aos','both'],'method':'CSRの終端・走査位置・DFS状態を頂点単位に配置。bothは成分番号反転も省く。','decision':'GCC/Clangとも長鎖・大きい閉路で約3〜5%遅くなるため不採用。'},
 {'labels':['raw'],'method':'専用SCCの成分番号を反転せず、解構築時の比較だけ逆転。','decision':'走査1回を省けるが全mainで安定した改善がなく、一部Clang max_randomでは約2%遅れたため不採用。'},
 {'labels':['room','insert','resize'],'method':'容量内の上限検査の順序変更、2辺をまとめたinsert、resize後の代入を比較。容量保護は維持。','decision':'GCC/Clangの双方で安定した上積みなし。resize/insertはClangの一部条件で数%遅くなり不採用。'},
 {'labels':['fused'],'method':'CSRの累積和と初期走査位置の設定を統合。nextはRAII所有の未初期化配列。','decision':'一部GCCで改善したが、追加SATやClangを含む全体で安定しないため不採用。'},
 {'labels':['unique','unique_init','conditional'],'method':'専用SCCの成分番号配列を所有unique_ptrで返す。uniqueは初期化を省き、unique_initはゼロ初期化、conditionalはGCCだけ初期化を省く。','decision':'uniqueはn250000の早期UNSAT判定単体でGCC約20〜21%、Clang約17〜19%短縮。ただし全mainの大規模SATではGCC max_random_02 +4.2%（同一base control +1.9%）、Clang max_random_01 +1.6%/03 +1.5%などが観測され、旧速度を一様に維持できないため不採用。unique_init/conditionalでも安定した解消なし。'}],
 'ownership_and_correctness_review':'全ての候補は標準C++23のコンテナ/RAIIを使用し、直接new式や解放の省略は加えない。初期化省略のids読出しは親lowの退避代入後、確定相補頂点の成分代入後、または全頂点確定後に限る。SAT時の解、未判定/UNSATのanswer長、コピー/ムーブ/リセット等を試作でも検証した。',
 'measurement':{'CPU':'Intel Core i9-14900KのP-Core CPU12（core6、sibling13）。E-Coreは対象外。/tmp/sirkit_performance_cpu12.lockで計測直列化。','compiler_flags':'GCC15.2/Clang21.1.8、-std=c++23 -O2、SKIP_RUNTIME_CHECKS。ClangはGCC15 libstdc++。march/nativeや最適化pragmaは追加しない。','method':'main・共通I/O・検査設定は固定。全mainは同じ実行パスへコピーして起動し、順番を乱数化。wait4のuser+system CPU時間中央値。controlはbaseと同じ実行物。各候補7回、unique再比較11回、全31入力比較9回。APIは作成を計時外に置きstd::clockで反復判定・解取得を7回測る。','run_counts':counts,'total_measured_runs':sum(counts.values()),'output_checks':'全mainは入力ごとに出力SHA一致。APIはチェックサム一致。公式16・追加15入力の原典/seed/入力SHAを保存。外部generator原本や大容量入力はZIPへ入れない。','summary':summaries,'identical_machine_code_controls':code_hashes,'limits':'ローカル性能でありオンラインと条件は異なる。1〜数%はcontrolにも揺れがあり、初回測定だけで改善を断定しない。GCC unique/conditionalとClang unique_init/conditionalは.textが一致するのに中央値が異なり、小差の不確かさを確認できる。特定の早期矛盾が速いだけで全面的な採用とはしない。'},
 'rejected_prototype_tests':{'source_sha256':sha(D/'adopted.hpp'),'source_snapshot':'evidence/adopted.hpp','component_test_snapshot':'evidence/component_unique.cpp','scope':'ここに列挙する20設定とMSan6設定は、採用しなかったunique候補に対する結果。現行本体の新たなAC/検証結果とは扱わない。','GCC_API_probes':probes,'ASan_reference_allocation_settings':tests,'MemorySanitizer_settings':msan,'results':'全設定PASS。公開API14533式、成分67076グラフ/32bit・size_t/両貼付け順、約200万参照検査、割当109failures/1091successes/live_delta=0。API/成分参照はASan+UBSan、割当は所有数カウンタ。MSanで未初期化読出し報告なし。ASanリーク検出は無効。'},
 'current_validation':{'body_unchanged_from_online':True,'main_unchanged':True,'io_unchanged':True,'component_test_restored':True,'previous_full_validation':'Audit/performance-two-sat-2026-11-04.json','normal_generated_samples':normal,'source_sha256':sha(R/'Graph/Two_SAT.cpp'),'test_sha256':sha(R/'Verify/current/tests/two_sat_component_test.cpp'),'latest_submission_comment':'https://judge.yosupo.jp/submission/415154','main_sha256':sha(R/'Verify/current/drivers/two_sat_main.cpp'),'io_sha256':sha(R/'Verify/current/common/fast_io.hpp')},
 'evidence':{'path':archive.relative_to(R).as_posix(),'sha256':sha(archive),'scope':'自作の変更前・試作、全測定・照合・テスト、入力URL/seed/SHA。未採用案を現行に混ぜず、バイナリ・外部generator・大容量入力は含めない。'},
 'synchronization':'本体/Document/使用例の変更はなし。通常・派生VerifyのURLと判定記録、監査、5配布ZIPを同期。通常版ACを派生版へ転記しない。'
}
assert sha(R/'Graph/Two_SAT.cpp')==json.loads((R/'Audit/performance-two-sat-2026-11-04.json').read_text())['hashes']['Graph/Two_SAT.cpp']
(R/'Audit/performance-two-sat-415154-2026-11-04.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');print('No additional body change: 415154 AC92ms; 5798 benchmark runs and rejected-prototype tests archived')
