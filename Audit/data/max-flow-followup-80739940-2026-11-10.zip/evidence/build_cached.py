# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,sys,json,hashlib
D=Path('/tmp/sirkit_maxflow_80739940');R=Path('/home/reinsirk/Atcoder_Env');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as p;e=next(x for x in p.collect()if x['id']=='max_flow_grid');rows=[]
for label in ['cached']:
 h=D/('before/Graph/Max_Flow.cpp'if label=='base'else'cached.hpp');data,_=p.render(e,source_overrides={'Graph/Max_Flow.cpp':h.read_bytes()});src=D/f'{label}.cpp';src.write_bytes(data)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  cmd=['taskset','-c','4',*args,'-std=c++23','-O2',str(src),'-o',str(D/f'{cc}_grid_{label}')];subprocess.run(cmd,check=True)
  cmd2=['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror','-DSKIP_RUNTIME_CHECKS',f'-DFLOW_SOURCE="{h}"','-DFLOW_TYPE=mf_graph',str(D/'general_bench.cpp'),'-o',str(D/f'{cc}_graph_{label}')];subprocess.run(cmd2,check=True)
  for sample in e['samples']:
   r=subprocess.run([str(D/f'{cc}_grid_{label}')],input=sample['input'],text=True,capture_output=True);assert r.returncode==0 and not r.stderr and p.matches(e,sample,r.stdout)
  rows.append(dict(compiler=cc,label=label,grid_command=cmd,general_command=cmd2,source_sha256=hashlib.sha256(data).hexdigest()));print(cc,label,'PASS',flush=True)
(D/'cached_builds.json').write_text(json.dumps(rows,indent=2)+'\n')
