# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,os,json,fcntl,random,statistics,shutil,hashlib,sys,re
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_maxflow_80739940');sys.path.insert(0,str(R/'Scripts'));from verify_graph_samples import check_max_flow_grid
fixtures=json.loads((D/'fixtures.json').read_text());rng=random.Random(80622766);raw=[];summary=[]
# 構築・入力・出力・破棄を含む。汎用入力のflowだけのCPU時間は補足値として区別する。
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for f in fixtures:
   text=Path(f['path']).read_text();assert hashlib.sha256(text.encode()).hexdigest()==f['sha256'];reps=11 if f['kind']=='grid'else 7
   for rep in range(reps):
    labels=['old','control','api','early'];rng.shuffle(labels)
    for label in labels:
     source=D/f'{cc}_{f["kind"]}_{"old"if label=="control"else label}';shutil.copyfile(source,D/'active');(D/'active').chmod(0o700)
     with Path(f['path']).open('rb')as fi,(D/'output').open('wb')as fo,(D/'error').open('wb')as fe:
      p=subprocess.Popen(['setarch','x86_64','-R','taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo,stderr=fe);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0,(f['name'],label,p.returncode,(D/'error').read_text())
     output=(D/'output').read_text();err=(D/'error').read_text();value=int(output.split()[0]);flow_ms=None
     if f['expected_flow']is not None:assert value==f['expected_flow'],(f['name'],label,value,f['expected_flow'])
     if f['kind']=='grid':assert not err and check_max_flow_grid({},dict(input=text,output=str(value)),output),(f['name'],label)
     else:
      m=re.fullmatch(r'flow_cpu_ms=([\d.]+)\n',err);assert m,err;flow_ms=float(m[1])
     raw.append(dict(compiler=cc,case=f['name'],kind=f['kind'],label=label,rep=rep,cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),flow_cpu_ms=flow_ms,rss_bytes=ru.ru_maxrss*1024,flow_value=value,oracle=f['oracle'],output_sha256=hashlib.sha256(output.encode()).hexdigest()))
   rr=[x for x in raw if x['compiler']==cc and x['case']==f['name']];assert len({x['flow_value']for x in rr})==1;m={l:statistics.median(x['cpu_ns']for x in rr if x['label']==l)for l in labels};base=statistics.median(x['cpu_ns']for x in rr if x['label']in['old','control']);item=dict(compiler=cc,case=f['name'],kind=f['kind'],median_cpu_ns=m,pooled_old_cpu_ns=base,api_ratio=m['api']/base,early_ratio=m['early']/base,control_ratio=m['control']/m['old'],samples_per_label=reps)
   if f['kind']=='graph':
    fm={l:statistics.median(x['flow_cpu_ms']for x in rr if x['label']==l)for l in labels};fb=statistics.median(x['flow_cpu_ms']for x in rr if x['label']in['old','control']);item['median_flow_cpu_ms']=fm;item['flow_early_ratio']=fm['early']/fb if fb else None
   summary.append(item);(D/'benchmark_raw.json').write_text(json.dumps(raw));(D/'benchmark_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(cc,f['name'],'api',round(item['api_ratio'],4),'early',round(item['early_ratio'],4),'control',round(item['control_ratio'],4),'flow',round(item.get('flow_early_ratio')or 0,4),'ms',round(base/1e6,2),round(m['early']/1e6,2),flush=True)
print('Complete',len(raw),'whole-process samples',flush=True)
