# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,statistics,sys,datetime,subprocess
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_maxflow_80739940');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();old=json.loads((R/'Audit/max-flow-acl-80622766-2026-11-06.json').read_text());proof=[]
for f in ['Graph/Max_Flow.cpp','Verify/current/drivers/max_flow_grid_main.cpp','Verify/current/common/fast_io.hpp']:
 assert(R/f).read_bytes()==(D/'before'/f).read_bytes();assert sha(R/f)==old['sources'][f]['sha256'];proof.append(dict(path=f,sha256=sha(R/f),unchanged_from_previous_validated_release=True))
summary=[];total=0
for filename,candidate in [('benchmark_raw.json','scratch'),('cached_raw.json','cached')]:
 a=json.loads((D/filename).read_text());total+=len(a)
 for cc,case in sorted({(x['compiler'],x['case'])for x in a}):
  rr=[x for x in a if(x['compiler'],x['case'])==(cc,case)];assert len({x['flow_value']for x in rr})==1;m={l:statistics.median(x['cpu_ns']for x in rr if x['label']==l)for l in ['base','control',candidate]};b=statistics.median(x['cpu_ns']for x in rr if x['label']in['base','control']);summary.append(dict(candidate=candidate,compiler=cc,case=case,kind=rr[0]['kind'],median_cpu_ns=m,baseline_pooled_ns=b,candidate_ratio=m[candidate]/b,control_ratio=m['control']/m['base'],samples_per_label=len(rr)//3))
assert total==1812
(D/'review_summary.json').write_text(json.dumps(summary,indent=2)+'\n');(D/'source_proofs.json').write_text(json.dumps(proof,indent=2)+'\n')
files={}
for p in D.iterdir():
 if p.is_file()and p.suffix in ['.py','.cpp','.hpp','.json','.log','.stderr']:files['evidence/'+p.name]=p.read_bytes()
for p in(D/'before').rglob('*'):
 if p.is_file():files['before/'+str(p.relative_to(D/'before'))]=p.read_bytes()
sys.path.insert(0,str(R/'Scripts'));from deterministic_zip import write_archive
z=R/'Audit/data/max-flow-followup-80739940-2026-11-10.zip';write_archive(z,files)
a=dict(date='2026-11-10',checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='最大流の再提出を画像で確認し、main/IO固定でP-Core向け追加案2つを比較。採用せず既存のBFS高速化を維持。',online_confirmation='Audit/online-max-flow-80739940-2026-11-10.json',online=dict(url='https://atcoder.jp/contests/practice2/submissions/80739940',status='AC',time_ms=6,previous_time_ms=7,source='利用者の提出情報画像',source_match=False,limitations='提出本文はHTTP403、ブラウザ接続も不可。画像のコード長21308Bとローカル20830Bの差を含め、一致を断定しない。オンラインの1ms差を本体単体の短縮率へ換算しない。'),decision='追加案を採用しない。本体・main・IOは前回の独立参照/ASan+UBSan/容量上限/確保失敗/標準C++23の試験を通過した版とbyte一致。追加の再提出は不要。',candidates=[dict(name='scratch',change='Frameのvector管理をmake_unique_for_overwrite配列と局所depthへ変更。コピーは作業配列を持たず、flow前に必要領域を確保。',review='各pushで全フィールド代入し、距離増加により深さ<=N。所有と再構築の整合を独立レビュー。容量上限にPTRDIFF_MAX相当の追加を検討できるが、本候補自体を採用しない。',result='GCCの350000鎖は全体約5%/接続星型は約8%短縮するが、GCCのランダムグリッド約2〜3%、Clangの星型や近いsinkの大規模グラフ約3〜4%後退があり不採用。'),dict(name='cached',change='辺走査で隣接配列・次数・次の距離を局所変数へ保存し、繰り返し読出しを減らす。',result='GCCの深い鎖・星型で約2〜3%短縮する一方、GCCのランダムグリッドで約2〜3%後退。Clangは多くが測定揺らぎ程度で、不採用。')],measurement=dict(cpu='Intel Core i9-14900K CPU12(P-Core)',compilers={x:subprocess.check_output([f'/usr/bin/{x}','--version'],text=True).splitlines()[0]for x in ['g++','clang++']},flags=['-std=c++23','-O2'],skip_runtime_checks=True,whole_process_runs=total,scope='同じVerify main/共通IOを使い、同じ実行パスへコピーしてbase/control/candidateの実行順を混ぜる。setarch -Rでprocess単位のASLRを揃えtaskset CPU12。rusage(user+system)には構築・入力・流量計算・出力・破棄を含む。',generic_scope='一般容量入力の補足ベンチではflow単体のCPU時間を別記し、容量・流量保存・最小カットも検証。Verify全体の成果と区別する。',fixtures='前回監査に保存した自作入力生成器を再実行。26入力の構成・seed・SHAをmetadataへ保存。',summary=summary,limits='小さい入力はprocess起動・計時の揺らぎが大きい。一部対照にも大きな変動があるため小規模の比率を採用根拠としない。全体の後退を避け、前後の良い条件だけで新案を採用しない。'),validation=dict(source_preservation=proof,outputs='全1812実行で流量の前後一致、既知/独立参照の期待流量、グリッド配置の妥当性、一般グラフの容量/保存則/最小カットを検査。',previous_validation='Audit/max-flow-acl-80622766-2026-11-06.json。現在の本体・main・IOが同じため、既存の同じ回帰試験を繰り返さない。'),provenance='候補は既存CC0の自作コードから独立に改変。外部実装を取り込まず、公開API・ライセンスは変更しない。',evidence=dict(path=str(z.relative_to(R)),sha256=sha(z),entries=len(files)),required_resubmission=[])
(R/'Audit/max-flow-followup-80739940-2026-11-10.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');print('Review:',total,'runs; library/main/IO unchanged; no resubmission required')
