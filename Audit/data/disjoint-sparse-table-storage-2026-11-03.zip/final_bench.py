# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,subprocess,json,random,statistics,shutil,os,time,fcntl,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_disjoint_speed_20261103');P=Path('/tmp/sirkit_sparse_speed_20261103');sys.path.insert(0,str(R/'Scripts'));import prepare_verify
v={'base':(D/'before.hpp').read_text(),'selected':(R/'DataStructure/Disjoint_Sparse_Table.cpp').read_text()};(D/'selected.hpp').write_text(v['selected']);e=next(e for e in prepare_verify.collect() if e['id']=='disjoint_sparse_table');comps=[('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]
for label,src in v.items():
 data,_=prepare_verify.render(e,source_overrides={'DataStructure/Disjoint_Sparse_Table.cpp':src.encode()});(D/f'final_{label}.cpp').write_bytes(data)
 for cc,cmd in comps:
  for kind,inp,flags in [('main',D/f'final_{label}.cpp',[]),('micro',D/'micro.cpp',['-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_DISJOINT_TEST_SOURCE="{D/(("before" if label=="base" else "selected")+".hpp")}"'])]:
   q=subprocess.run(['taskset','-c','2',*cmd,'-std=c++23','-O2',*flags,str(inp),'-o',str(D/f'final_{kind}_{cc}_{label}')],capture_output=True,text=True);assert q.returncode==0,q.stderr
print('BUILT',flush=True)
raw=[];rng=random.Random(984513)
cases=[f'official_{family}_{i}' for family,count in [('random',5),('max_random',5),('small_width_query',5),('small_values',1)] for i in range(count)]+[f'{n}_{mode}' for n in [32,4096,500000] for mode in ['random','short','build']]
with open('/tmp/sirkit_performance_cpu12.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc,_ in comps:
  for case in cases:
   inp=P/((case if case.startswith('official') else 'input_'+case)+'.in')
   for rep in range(15):
    labels=['base','control','selected'];rng.shuffle(labels)
    for label in labels:
     shutil.copyfile(D/f'final_main_{cc}_{"base" if label=="control" else label}',D/'active_final');(D/'active_final').chmod(0o700)
     with inp.open('rb') as fi,(D/'output').open('wb') as fo:
      st=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active_final')],stdin=fi,stdout=fo);_,status,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status);assert p.returncode==0
      cpu=round((ru.ru_utime+ru.ru_stime)*1e9);wall=time.perf_counter_ns()-st
     raw.append(dict(compiler=cc,case=case,rep=rep,label=label,cpu_ns=cpu,wall_ns=wall,max_rss_bytes=ru.ru_maxrss*1024,sha256=hashlib.sha256((D/'output').read_bytes()).hexdigest()))
   rows=[r for r in raw if r['compiler']==cc and r['case']==case];assert len({r['sha256'] for r in rows})==1
   m={l:statistics.median(r['cpu_ns'] for r in rows if r['label']==l) for l in labels};print('MAIN',cc,case,{k:round(x/m['base'],4) for k,x in m.items()},flush=True);(D/'final_raw.json').write_text(json.dumps(raw))
 tasks=[]
 for ty in ['min','sum','affine','bool']:
  for n,reps in [(32,20000),(4096,150),(500000,3)]:
   for mode in ['build','query']:tasks.append((ty,n,mode,reps))
 for ty in ['min','bool']:
  for n in [32,500000]:tasks.append((ty,n,'get',1))
 for n in [32,4096,500000]:tasks.append(('sum',n,'boundary',1))
 for mode in ['copy','values']:tasks.append(('min',500000,mode,3))
 for n in [0,1,2]:tasks.append(('min',n,'build',50000))
 raw=[]
 for cc,_ in comps:
  for ty,n,mode,reps in tasks:
   for rep in range(11):
    labels=['base','control','selected'];rng.shuffle(labels);checks=[]
    for label in labels:
     shutil.copyfile(D/f'final_micro_{cc}_{"base" if label=="control" else label}',D/'active_micro_final');(D/'active_micro_final').chmod(0o700)
     q=subprocess.run(['taskset','-c','12',str(D/'active_micro_final'),str(n),mode,str(reps),ty],capture_output=True,text=True,check=True);check,cpu=map(int,q.stdout.split());checks.append(check);raw.append(dict(compiler=cc,type=ty,n=n,mode=mode,repeated_operations=reps,rep=rep,label=label,cpu_ns=cpu,checksum=check))
    assert len(set(checks))==1
   rows=[r for r in raw if (r['compiler'],r['type'],r['n'],r['mode'])==(cc,ty,n,mode)];m={l:statistics.median(r['cpu_ns'] for r in rows if r['label']==l) for l in labels};print('MICRO',cc,ty,n,mode,{k:round(x/m['base'],4) for k,x in m.items()},flush=True);(D/'final_micro_raw.json').write_text(json.dumps(raw))
print('DONE',flush=True)
