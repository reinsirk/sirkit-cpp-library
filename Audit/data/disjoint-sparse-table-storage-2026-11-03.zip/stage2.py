# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,subprocess,json,random,statistics,shutil,os,time,fcntl,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_disjoint_speed_20261103');P=Path('/tmp/sirkit_sparse_speed_20261103');sys.path.insert(0,str(R/'Scripts'));import prepare_verify
s=(D/'dedup_loop.hpp').read_text()
old='''            for (std::size_t begin = 0; begin < n;) {
                const auto middle = begin + std::min(half, n - begin);
                const auto end = middle + std::min(half, n - middle);
                for (auto i = middle; i > begin + 1; --i) row[i - 2] = op_(values[i - 2], row[i - 1]);
                if (middle < end)
                    for (auto i = middle + 1; i < end; ++i) row[i] = op_(row[i - 1], values[i]);
                begin = end;
            }'''
new='''            std::size_t begin = 0;
            if (half <= n / 2) {
                const auto span = half * 2;
                const auto last = n - span;
                for (; begin <= last; begin += span) {
                    const auto middle = begin + half;
                    const auto end = middle + half;
                    for (auto i = middle; i > begin + 1; --i) row[i - 2] = op_(values[i - 2], row[i - 1]);
                    for (auto i = middle + 1; i < end; ++i) row[i] = op_(row[i - 1], values[i]);
                }
            }
            if (begin < n) {
                const auto middle = begin + std::min(half, n - begin);
                for (auto i = middle; i > begin + 1; --i) row[i - 2] = op_(values[i - 2], row[i - 1]);
                if (middle < n)
                    for (auto i = middle + 1; i < n; ++i) row[i] = op_(row[i - 1], values[i]);
            }'''
assert old in s
v={'base':(D/'before.hpp').read_text(),'dedup_loop':s,'fullblocks':s.replace(old,new)}
v['loop_fullblocks']=(D/'loop.hpp').read_text().replace(old,new)
e=next(e for e in prepare_verify.collect() if e['id']=='disjoint_sparse_table')
for label,src in v.items():
 (D/f'{label}.hpp').write_text(src);data,_=prepare_verify.render(e,source_overrides={'DataStructure/Disjoint_Sparse_Table.cpp':src.encode()});(D/f'{label}.cpp').write_bytes(data)
 for cc,cmd in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  q=subprocess.run(['taskset','-c','2',*cmd,'-std=c++23','-O2',str(D/f'{label}.cpp'),'-o',str(D/f'{cc}_{label}')],capture_output=True,text=True);assert q.returncode==0,q.stderr
print('BUILT',flush=True)
cases=['official_random_0','official_random_2','official_max_random_0','official_max_random_1','official_small_width_query_0','official_small_width_query_3','32_random','4096_random','500000_build']
raw=[];rng=random.Random(723361)
with open('/tmp/sirkit_performance_cpu12.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for case in cases:
   inp=P/((case if case.startswith('official') else 'input_'+case)+'.in')
   for rep in range(11):
    labels=list(v)+['control'];rng.shuffle(labels)
    for label in labels:
     shutil.copyfile(D/f'{cc}_{"base" if label=="control" else label}',D/'active');(D/'active').chmod(0o700)
     with inp.open('rb') as fi,(D/'output').open('wb') as fo:
      st=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,status,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status);assert p.returncode==0
      cpu=round((ru.ru_utime+ru.ru_stime)*1e9);wall=time.perf_counter_ns()-st
     raw.append(dict(compiler=cc,case=case,rep=rep,label=label,cpu_ns=cpu,wall_ns=wall,sha256=hashlib.sha256((D/'output').read_bytes()).hexdigest()))
   rows=[r for r in raw if r['compiler']==cc and r['case']==case];assert len({r['sha256'] for r in rows})==1
   med={l:statistics.median(r['cpu_ns'] for r in rows if r['label']==l) for l in labels};print(cc,case,{k:round(x/med['base'],4) for k,x in med.items()},flush=True)
   (D/'stage2_raw.json').write_text(json.dumps(raw))
