# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,random,statistics,json,shutil,fcntl
D=Path('/tmp/sirkit_disjoint_speed_20261103');raw=[];rng=random.Random(119732)
variants=['base','dedup_loop'];comps=[('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]
for cc,cmd in comps:
 for label in variants:
  c=['taskset','-c','2',*cmd,'-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_DISJOINT_TEST_SOURCE="{D/(label+".hpp")}"',str(D/'micro.cpp'),'-o',str(D/f'micro_{cc}_{label}')];p=subprocess.run(c,capture_output=True,text=True);assert p.returncode==0,p.stderr
print('BUILT',flush=True)
tasks=[]
for ty in ['min','sum','affine','bool']:
 for n,reps in [(32,20000),(4096,150),(500000,3)]:
  for mode in ['build','query']:tasks.append((ty,n,mode,reps))
for ty in ['min','bool']:
 for n in [32,500000]:tasks.append((ty,n,'get',1))
for n in [32,4096,500000]:tasks.append(('sum',n,'boundary',1))
for mode in ['copy','values']:tasks.append(('min',500000,mode,3))
with open('/tmp/sirkit_performance_cpu12.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc,_ in comps:
  for ty,n,mode,reps in tasks:
   for rep in range(9):
    labels=['base','control','dedup_loop'];rng.shuffle(labels);checks=[]
    for label in labels:
     shutil.copyfile(D/f'micro_{cc}_{"base" if label=="control" else label}',D/'active_micro');(D/'active_micro').chmod(0o700)
     p=subprocess.run(['taskset','-c','12',str(D/'active_micro'),str(n),mode,str(reps),ty],capture_output=True,text=True,check=True);check,ns=map(int,p.stdout.split());checks.append(check);raw.append(dict(compiler=cc,type=ty,n=n,mode=mode,repeated_operations=reps,rep=rep,label=label,cpu_ns=ns,checksum=check))
    assert len(set(checks))==1
   rows=[r for r in raw if (r['compiler'],r['type'],r['n'],r['mode'])==(cc,ty,n,mode)];m={l:statistics.median(r['cpu_ns'] for r in rows if r['label']==l) for l in labels};print(cc,ty,n,mode,{k:round(v/m['base'],4) for k,v in m.items()},flush=True);(D/'micro_raw.json').write_text(json.dumps(raw))
