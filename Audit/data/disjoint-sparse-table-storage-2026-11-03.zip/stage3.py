# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,subprocess,json,random,statistics,shutil,os,time,fcntl,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_disjoint_speed_20261103');P=Path('/tmp/sirkit_sparse_speed_20261103');sys.path.insert(0,str(R/'Scripts'));import prepare_verify
s=(D/'dedup_loop.hpp').read_text()
last=s.replace('''        if (r - l == 1) return table_.front()[l];
        const auto k = std::bit_width(l ^ (r - 1)) - 1;
        return op_(table_[k][l], table_[k][r - 1]);''','''        const auto last = r - 1;
        if (l == last) return table_.front()[l];
        const auto k = std::bit_width(l ^ last) - 1;
        return op_(table_[k][l], table_[k][last]);''')
assert last!=s
sz=s.replace('    std::vector<std::vector<T>> table_;','    std::vector<std::vector<T>> table_;\n    std::size_t length_ = 0;').replace(': op_(std::move(op)), identity_(identity) {',': op_(std::move(op)), identity_(identity), length_(values.size()) {').replace('table_(std::move(other.table_)) {','table_(std::move(other.table_)), length_(other.length_) {').replace('        other.table_.clear();','        other.table_.clear(); other.length_ = 0;').replace('return table_.empty() ? 0 : table_.front().size();','return length_;').replace('void clear() noexcept { table_.clear(); }','void clear() noexcept { table_.clear(); length_ = 0; }').replace('        table_.swap(other.table_);','        table_.swap(other.table_); swap(length_, other.length_);')
assert sz!=s
szlast=sz.replace('''        if (r - l == 1) return table_.front()[l];
        const auto k = std::bit_width(l ^ (r - 1)) - 1;
        return op_(table_[k][l], table_[k][r - 1]);''','''        const auto last = r - 1;
        if (l == last) return table_.front()[l];
        const auto k = std::bit_width(l ^ last) - 1;
        return op_(table_[k][l], table_[k][last]);''')
v={'base':(D/'before.hpp').read_text(),'dedup_loop':s,'last':last,'size':sz,'size_last':szlast};e=next(e for e in prepare_verify.collect() if e['id']=='disjoint_sparse_table')
for label,src in v.items():
 (D/f'{label}.hpp').write_text(src);data,_=prepare_verify.render(e,source_overrides={'DataStructure/Disjoint_Sparse_Table.cpp':src.encode()});(D/f'{label}.cpp').write_bytes(data)
 for cc,cmd in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for kind,inp,flags in [('main',D/f'{label}.cpp',[]),('micro',D/'micro.cpp',['-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_DISJOINT_TEST_SOURCE="{D/(label+".hpp")}"'])]:
   q=subprocess.run(['taskset','-c','2',*cmd,'-std=c++23','-O2',*flags,str(inp),'-o',str(D/f's3_{kind}_{cc}_{label}')],capture_output=True,text=True);assert q.returncode==0,q.stderr
print('BUILT',flush=True)
cases=['official_random_2','official_max_random_0','official_small_width_query_0','32_random','4096_random','500000_build']
raw=[];rng=random.Random(113287)
with open('/tmp/sirkit_performance_cpu12.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for kind in ['main','micro']:
  for cc in ['gcc','clang']:
   tasks=cases if kind=='main' else [('min',32,'query',1),('min',4096,'query',1),('min',500000,'query',1),('sum',4096,'query',1),('sum',500000,'query',1),('affine',500000,'query',1),('bool',500000,'query',1),('min',500000,'get',1),('sum',500000,'boundary',1)]
   for case in tasks:
    for rep in range(9):
     labels=list(v)+['control'];rng.shuffle(labels)
     for label in labels:
      shutil.copyfile(D/f's3_{kind}_{cc}_{"base" if label=="control" else label}',D/'active3');(D/'active3').chmod(0o700)
      if kind=='main':
       inp=P/((case if case.startswith('official') else 'input_'+case)+'.in')
       with inp.open('rb') as fi,(D/'output').open('wb') as fo:
        st=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active3')],stdin=fi,stdout=fo);_,status,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status);assert p.returncode==0
        cpu=round((ru.ru_utime+ru.ru_stime)*1e9);wall=time.perf_counter_ns()-st
       check=hashlib.sha256((D/'output').read_bytes()).hexdigest()
      else:
       ty,n,mode,reps=case;p=subprocess.run(['taskset','-c','12',str(D/'active3'),str(n),mode,str(reps),ty],capture_output=True,text=True,check=True);check,cpu=map(int,p.stdout.split());wall=None
      raw.append(dict(kind=kind,compiler=cc,case=case,rep=rep,label=label,cpu_ns=cpu,wall_ns=wall,checksum=check))
    rows=[r for r in raw if r['kind']==kind and r['compiler']==cc and r['case']==case];assert len({r['checksum'] for r in rows})==1
    med={l:statistics.median(r['cpu_ns'] for r in rows if r['label']==l) for l in labels};print(kind,cc,case,{k:round(x/med['base'],4) for k,x in med.items()},flush=True);(D/'stage3_raw.json').write_text(json.dumps(raw))
