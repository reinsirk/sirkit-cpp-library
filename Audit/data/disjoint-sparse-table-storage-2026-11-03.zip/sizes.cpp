// SPDX-License-Identifier: CC0-1.0
#include SIRKIT_DISJOINT_TEST_SOURCE
#include <cstdint>
#include <cstdio>
#include <functional>
int main(){std::printf("int32=%zu int64=%zu bool=%zu\n",sizeof(DisjointSparseTable<std::int32_t,std::plus<std::int32_t>>),sizeof(DisjointSparseTable<std::int64_t,std::plus<std::int64_t>>),sizeof(DisjointSparseTable<bool,std::logical_and<bool>>));}
