# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,datetime,statistics,subprocess,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_disjoint_speed_20261103');P=Path('/tmp/sirkit_sparse_speed_20261103');load=lambda n:json.loads((D/n).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=R/'DataStructure/Disjoint_Sparse_Table.cpp';driver=R/'Verify/current/drivers/disjoint_sparse_table_main.cpp';io=R/'Verify/current/common/fast_io.hpp'
assert source.read_bytes()==(D/'selected.hpp').read_bytes();assert driver.read_bytes()==(D/'driver.cpp').read_bytes()
assert sha(io)=='291bf8dbc56a1d691f6256fe95b4714183c2cf5d9e55e4bef240e31d1eb178c1'
host={}
for k,c in [('cpu',['lscpu','-J']),('topology',['lscpu','-e=CPU,CORE,MAXMHZ,MINMHZ,ONLINE']),('gcc',['/usr/bin/g++','--version']),('clang',['/usr/bin/clang++','--version'])]:host[k]={'command':c,'stdout':subprocess.run(c,capture_output=True,text=True,check=True).stdout}
host['governor']=Path('/sys/devices/system/cpu/cpu12/cpufreq/scaling_governor').read_text().strip();host['kernel_core_id']=Path('/sys/devices/system/cpu/cpu12/topology/core_id').read_text().strip();host['thread_siblings']=Path('/sys/devices/system/cpu/cpu12/topology/thread_siblings_list').read_text().strip();(D/'host.json').write_text(json.dumps(host,indent=2)+'\n')
full=[];raw=load('final_raw.json');assert len(raw)==2250
for cc in ['gcc','clang']:
 for case in sorted({r['case'] for r in raw}):
  rs=[r for r in raw if r['compiler']==cc and r['case']==case];assert len({r['sha256'] for r in rs})==1
  m={v:statistics.median(r['cpu_ns'] for r in rs if r['label']==v) for v in ['base','control','selected']}
  full.append({'compiler':cc,'case':case,'median_process_cpu_ms':{k:v/1e6 for k,v in m.items()},'selected_over_base':m['selected']/m['base'],'control_over_base':m['control']/m['base'],'median_wall_ms':{v:statistics.median(r['wall_ns'] for r in rs if r['label']==v)/1e6 for v in m},'median_max_rss_bytes':{v:statistics.median(r['max_rss_bytes'] for r in rs if r['label']==v) for v in m},'output_sha256':rs[0]['sha256']})
ms=[];raw=load('final_micro_raw.json');assert len(raw)==2376
for cc in ['gcc','clang']:
 for ty,n,mode in sorted({(r['type'],r['n'],r['mode']) for r in raw}):
  rs=[r for r in raw if (r['compiler'],r['type'],r['n'],r['mode'])==(cc,ty,n,mode)];assert len({r['checksum'] for r in rs})==1
  m={v:statistics.median(r['cpu_ns'] for r in rs if r['label']==v) for v in ['base','control','selected']};rep=rs[0]['repeated_operations'];unit_count=rep if mode in ['build','copy','values'] else (100000 if mode=='boundary' else 1000000)
  ms.append({'compiler':cc,'type':ty,'n':n,'mode':mode,'timed_cpu_ms':{k:v/1e6 for k,v in m.items()},'selected_over_base':m['selected']/m['base'],'control_over_base':m['control']/m['base'],'ns_per_operation_or_boundary_pair':{k:v/unit_count for k,v in m.items()},'operation_count':unit_count,'checksum':rs[0]['checksum']})
tests=load('final_tests.json');profiles=load('profile_tests.json');standard=load('standard_cpp23_tests.json');assert len(tests)==12 and len(profiles)==6 and len(standard)==2
assert all(r['returncode']==0 and not r.get('stderr') for r in tests+profiles+standard)
for r in tests:assert r['test_sha256']==sha(R/f'Verify/current/tests/{r["test"]}.cpp')
profile_samples=next((D/'profiles/runs').glob('*.json'));samples=json.loads(profile_samples.read_text());assert samples['counts']=={'LOCAL_SAMPLE_PASS':10}
evidence=R/'Audit/data/disjoint-sparse-table-storage-2026-11-03.zip'
with zipfile.ZipFile(evidence,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(D.iterdir()):
  if p.is_file() and p.suffix in {'.py','.hpp','.cpp','.json','.log','.stderr'}:z.write(p,p.name)
 z.write(P/'official_metadata.json','inputs_metadata.json');z.write(P/'screen_build.py','original_fixture_generation.py')
 z.write(profile_samples,'profile_runs/'+profile_samples.name)
 for name in ['DataStructure/Disjoint_Sparse_Table.cpp','Verify/current/tests/disjoint_sparse_table_storage_test.cpp','Document/disjoint_sparse_table.md']:z.write(R/name,'current/'+name)
report={
 'date_jst':'2026-11-03','checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'adopted_locally_validated_needs_online_resubmission',
 'library':'DataStructure/Disjoint_Sparse_Table.cpp','before_source_sha256':sha(D/'before.hpp'),'current_source_sha256':sha(source),
 'online':{'url':'https://judge.yosupo.jp/submission/414929','status':'AC','time_ms':83,'memory_bytes':47243264,'scope':'改修前の本体。本体・main・共通IOは確認時の提出ソースと一致。採用版のACを意味しない。','evidence':'online-disjoint-sparse-table-414929-2026-11-03.json'},
 'unchanged':{'public_api':True,'generic_associative_operations':True,'noncommutative_order':True,'bool_proxy_overload_selection':True,'construction_op_call_order_and_count':True,'ownership':'vectorが所有する。新たなraw所有ポインタ・手動解放は使わない。','driver_sha256':sha(driver),'common_io_sha256':sha(io),'main_unchanged':True,'common_io_unchanged':True},
 'adopted':[
  'half=1の行はOp呼出しがなく原列と同一なので、元列をtable_[0]で共用。values_メンバーを除く。n0は空、n1/n2は第0行のみ。',
  '右prefixはmiddle<endを確認しmiddle+1から開始。各反復のi!=middle分岐を除く。',
  '右端r-1を共有し、単要素判定をl==lastへ変更。空区間の処理を先に維持する。',
  '公開size/get/check_range/境界探索で使う要素数length_を保持。copy/move/clear/swapで表と同期する。検査専用の状態ではない。'],
 'memory':{'array_saving':'n>=2で元列のコピー1本を削減。int32でn500000なら2000000byte。','n1_exception':'旧版は元列vectorだけだったが、新版は外側の行vectorの確保が1回増える。','object_sizes':load('sizes.json'),'actual_rss':'final_full_main_resultsのmedian_max_rss_bytes。max_random_0では両コンパイラで約2.1MB減少。'},
 'performance_environment':{'cpu':'Intel Core i9-14900K','logical_cpu':12,'core_kind':'P-Core','lscpu_core_index':6,'kernel_core_id':host['kernel_core_id'],'sibling_logical_cpu':13,'governor':'powersave','fixed_frequency':False,'flags':['-std=c++23','-O2'],'compiler_versions':{'gcc':'15.2.0','clang':'21'},'clang_extra_flag':'--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','march_native':False,'checks':'SKIP_RUNTIME_CHECKS','simultaneous_compilation_or_other_performance_runs_during_final_measurement':False,'source':'host.json'},
 'final_full_main_protocol':{'cases':25,'official_generator_cases':16,'custom_cases':9,'repetitions':15,'labels':{'base':'83ms提出の本体','control':'baseと同一バイナリ','selected':'採用版'},'same_driver_and_io':True,'order':'seed984513でラベル順を混ぜる。実行ファイル名・P-Coreを統一。','timer':'wait4のuser+system CPU時間、プロセス全体。wallと最大RSSも保存。','correctness':'すべての版・反復で出力SHA256が一致。公式生成器は既存の入力を再利用し、元の生成器ソースは同梱しない。','noise':'周波数固定なし。control差を併記。特に短い操作の比率のみから無退行・普遍的な速さを断定しない。'},
 'final_full_main_results':full,
 'micro_protocol':{'repetitions':11,'types':{'min':'int32最小値','sum':'int64和、非負値','affine':'2個のuint64による法998244353の写像合成（非可換）','bool':'bool AND'},'timer':'std::clockで構築/破棄、照会、get、境界探索、コピー、valuesの対象部分のみを計時。入力生成・入出力は計時外。','operation_count':'query/getは1000000回。boundaryはmax_right/min_leftの100000組。build/copy/valuesはrepeated_operationsの回数。構築・コピーは破棄時間と結果観測のall_prodを含む。','limitations':'小規模では最適化や確保器の再利用、クロック粒度、controlの揺らぎの影響が大きい。'},
 'micro_results':ms,
 'assessment':{'official_large_full_main':'GCC max_randomは8.40〜10.63%、small_width_queryは6.36〜8.15%短縮。Clangは各7.78〜10.70%、6.42〜9.25%短縮。','other_official_cases':'公式相当のrandom5件・small_valuesも両コンパイラで短縮。','large_min_build':'n500000の最小値構築はGCC約22.7%、Clang約23.7%短縮。','small_cost':'n1構築はGCC9.24→15.32ns、Clang9.60→16.44ns/個（反復測定）。小規模getや中規模の和の照会にも数%〜10%の差が残り、一部はcontrolの差と重なる。全操作・全サイズでの無退行とは主張しない。','decision':'小規模の多少の退行を許容し大規模で明確な改善を採る既存方針に基づく。','online_next':'同じmainの通常版を再提出して実時間を確認する。オンライン短縮量の保証はしない。'},
 'rejected_candidates':['元列コピーを残したメンバー初期化だけの案は上積みが安定しない。','fullblockと端数を分離する構築はコードが増え、Clangの一部で単純な分岐削減案より遅いため不採用。','要素数保持/右端共有がない単純な重複削除は一部照会で退行した。採用版では両者を合わせる。'],
 'simd':'prefix/suffixには実際の依存があり、依存を無視するSIMD指示は加えない。今回は標準C++の格納・分岐・添字計算の変更で改善した。専用CPU命令や追加CPU判定はない。',
 'correctness':{'normal':tests,'profile_and_baseline_type_tests':profiles,'standard_cpp23':standard,'profile_samples':{'count':10,'status':'LOCAL_SAMPLE_PASS','evidence':'profile_runs/'+profile_samples.name},'scope':'既存831604/831478項目の静的表テスト、新規73146項目の型/呼出順/境界/所有権テスト、3987項目/2526回の確保失敗試験でlive_delta0。新規テストは元版でもGCC/Clangで通る。','sanitizers':'値/参照テストはASan+UBSan。独自のnew/delete置換による失敗予算試験は別実行。LSanは実行環境の制約でdetect_leaks=0。','review':'別エージェントが値型・n0/1/2・uint境界・例外時length_同期・bool proxy・非可換の呼出順を読み取り確認。検査有無のC++23をrootで実行。'},
 'documentation':{'file':'Document/disjoint_sparse_table.md','changed':False,'reason':'公開API・前提・計算量・参照寿命・所有権の仕様は不変。内部最適化と測定をREADME/Documentへ追加しない。'},
 'license':{'implementation':'CC0-1.0。既存の自作本体を改修し、外部実装のコードは追加していない。','input_generators':'Library CheckerのApache-2.0生成器は入力作成にのみ使用した既存ファイルを再利用。生成器ソースは証跡ZIPへ含めず、URL/原ソースSHA/入力SHAをinputs_metadata.jsonへ保存。'},
 'evidence':{'file':'data/'+evidence.name,'sha256':sha(evidence),'bytes':evidence.stat().st_size,'scope':'自作ソース・比較コード・生測定・テスト結果。バイナリ、巨大入力、公式生成器原ソースは含めない。'},
 'resubmit':['Verify/current/submissions/disjoint_sparse_table.cpp']}
p=R/'Audit/performance-disjoint-sparse-table-storage-2026-11-03.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('audit',p.name,'evidence_bytes',evidence.stat().st_size,'full',len(full),'micro',len(ms))
