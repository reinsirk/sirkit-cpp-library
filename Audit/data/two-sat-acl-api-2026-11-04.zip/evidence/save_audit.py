# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_two_sat_acl_20261104');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tests=json.loads((D/'tests.json').read_text());assert len(tests)==12 and all(x['returncode']==0 and not x['stderr']for x in tests)
for row in tests:assert row['source_sha256']==sha(R/'Graph/Two_SAT.cpp')and row['test_sha256']==sha(R/f'Verify/current/tests/{row["test"]}.cpp')
profile=json.loads(sorted((D/'profiles/runs').glob('*.json'))[-1].read_text());assert profile['counts']=={'LOCAL_SAMPLE_PASS':10};normal=json.loads((D/'normal_samples.json').read_text());assert len(normal)==2
assert (R/'Graph/SCC.cpp').read_bytes()==(D/'scc_frozen.cpp').read_bytes();assert (R/'Verify/current/common/fast_io.hpp').read_bytes()==(D/'io_frozen.hpp').read_bytes()
files=['Graph/Two_SAT.cpp','Document/two_sat.md','Examples/two_sat_example.cpp','Verify/current/drivers/two_sat_main.cpp','Verify/current/tests/two_sat_acl_api_test.cpp','Verify/current/tests/new_scc_two_sat_reference_test.cpp','Verify/current/tests/new_graph_allocation_test.cpp']
archive=R/'Audit/data/two-sat-acl-api-2026-11-04.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for f in files:z.write(R/f,f)
 for f in ['before.cpp','scc_frozen.cpp','driver_before.cpp','io_frozen.hpp','run_tests.py','tests.json','tests.log','generation.log','profiles.log','normal_samples.json','save_audit.py']:z.write(D/f,'evidence/'+f)
 for p in (D/'profiles').rglob('*.json'):
  if 'attempts'not in p.parts:z.write(p,'evidence/profiles/'+p.relative_to(D/'profiles').as_posix())
audit={
 'date':'2026-11-04','scope':'TwoSATの通常版・各派生版をACL形式のtwo_sat APIへ統一し、初回オンラインVerify用コードを準備。',
 'specification_sources':['https://atcoder.github.io/ac-library/production/document_ja/twosat.html','https://github.com/atcoder/ac-library/blob/master/atcoder/twosat.hpp'],
 'implementation_origin':'ACLは型名・呼び出し・戻り値・前提の仕様を確認した参考。実装を転載せず、既存の自作2-SATと共有SCCを維持。既存のSPDX/参考URLも保持。',
 'compatibility':{'type':'global two_sat','constructors':['非explicit two_sat()','explicit two_sat(int)'],'members':['void add_clause(int,bool,int,bool)','bool satisfiable()','std::vector<bool> answer()（非const、値返し）'],'answer_semantics':'判定前/UNSATでも長さn。内容は未規定。返り値を書き換えても内部解に影響しない。制約追加後は再判定して新しい解として使う。','namespace':'AGENTSに従いグローバル公開。atcoder::の名前空間やACLのヘッダー配置まで同一にはしない。','removed_without_alias':['TwoSAT','solve()','byte配列のconst参照を返す旧answer()'],'extensions_preserved':['imply','force','add_xor','reserve_clauses','size/clause_count','reset/swap/独立コピー/ムーブ','成功後のvalue(int) const（O(1)）']},
 'cost_and_state':{'constructor':'O(1)。答えのbyte配列を従来どおり遅延作成。','satisfiable':'旧solveから名称のみ変更。判定の関数本体は文字列一致。O(n+m)時間・追加領域、共有SCCも変更なし。','answer':'内部byte配列を保持し、取得時にvector<bool>へ変換。ACLと同じO(n)時間・領域の値返し。未実行/UNSATはn個のfalseを返す実装だが、公開仕様では内容を保証しない。','validation':'answerは判定状態で例外を投げない。成功後限定valueの有効性・変数番号検査と専用状態をSKIP_RUNTIME_CHECKSで除く。容量・添字保護と数学的矛盾判定は維持。','performance_claim':'速度の新たな改善は主張しない。従来の判定計算/byte cache/O(1)valueを維持。answerの返し方とVerify呼出はACL仕様に伴い変わるため、旧mainとの総時間を本体の速度改善とは扱わない。'},
 'verify':{'submission':'Verify/current/submissions/two_sat.cpp','problem':'https://judge.yosupo.jp/problem/two_sat','status':'初回オンライン提出前','main':'同じ共通高速IOを使い、型名/判定名を移行。SAT時にanswer()を1回取得して素直に出力する。バッチ化/並べ替え/分布での切替なし。','io_sha256':sha(D/'io_frozen.hpp'),'normal_samples':normal,'profiles':profile['counts'],'dependence':'ACLのインストール不要。本体と共有IOを貼付け、先頭でSKIP_RUNTIME_CHECKSを定義。'},
 'tests':{'results':tests,'coverage':'API型/非explicit default/explicit int/旧solveなし、全2変数までの節集合（節内順序・重複を同一視）と乱数を含む14533式、返り値コピー、未実行/UNSAT/再判定/追加制約/コピー/ムーブ/追加API、独立全探索、既存SCCとの同時貼付け、確保失敗。','settings':'GCC15.2/Clang21、C++23-O2、検査有無。API/参照はASan+UBSan、SIRKIT_DISABLE_SIMD。割当試験は各設定109 failures/1091 successes/live_delta=0。','leak_scope':'ASAN_OPTIONS=detect_leaks=0。例外時の解放は割当試験のliveカウンタで補足。'},
 'hashes':{f:sha(R/f)for f in files},'shared_SCC_source_sha256':sha(R/'Graph/SCC.cpp'),
 'source_compatibility':'既存利用コードは型名と判定名、およびanswerの型/返し方の移行が必要。旧名aliasを追加しない。',
 'evidence':{'path':archive.relative_to(R).as_posix(),'sha256':sha(archive),'scope':'自作ソースと変更前スナップショット・テスト・全コマンド/結果。ACL実装の原本は含めない。'},
 'synchronization':'本体/Document/使用例/Verify driver/テスト/通常GCC-Clangと速度優先版を同期。SCC本体とAC80ms記録は変更しない。5配布ZIP検証はDistribution/validation.json。'
}
(R/'Audit/two-sat-acl-api-2026-11-04.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n');print('TwoSAT API audit saved: 12 typed/reference/allocation runs, 10 profile + 2 normal sample settings PASS')
