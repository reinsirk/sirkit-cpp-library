# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,subprocess,os,random,fcntl,shutil,statistics,hashlib,sys
D=Path('/tmp/sirkit_suffix_416494');fixtures=json.loads((D/'fixtures.json').read_text());names=['custom_32_binary','custom_4096_binary','custom_500000_all_same','custom_500000_binary','custom_500000_random26','custom_500000_periodic3','custom_500000_long_runs','custom_500000_last_different','custom_500000_middle_different','custom_500000_fibonacci','official_suffixarray_max_random_00','official_suffixarray_all_same_00','official_suffixarray_fib_str_00','official_suffixarray_binary_carry_00','official_suffixarray_almost_single_00','official_suffixarray_near_power_of_2_max_random_00']
labels=sys.argv[1:];stem='screen';reps=3;raw=[];summary=[];rng=random.Random(416380)
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for id in ['suffix_array','suffix_array_substrings']:
   for f in [x for x in fixtures if x['name']in names]:
    values=[]
    for rep in range(reps):
     order=labels.copy();rng.shuffle(order)
     for label in order:
      src=D/f'{cc}_{"base"if label=="control"else label}_{id}';shutil.copyfile(src,D/'active');(D/'active').chmod(0o700)
      with Path(f['path']).open('rb')as fi,(D/'output').open('wb')as fo:
       p=subprocess.Popen(['setarch','x86_64','-R','taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,status,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status);assert p.returncode==0
      digest=hashlib.sha256((D/'output').read_bytes()).hexdigest();expected=f['oracles'].get(id,{}).get('expected_sha256')
      if expected:assert digest==expected,(id,f['name'],label)
      row=dict(compiler=cc,id=id,case=f['name'],rep=rep,label=label,cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),rss_bytes=ru.ru_maxrss*1024,output_sha256=digest);raw.append(row);values.append(row)
    assert len({r['output_sha256']for r in values})==1,(cc,id,f['name']);m={l:statistics.median(r['cpu_ns']for r in values if r['label']==l)for l in labels};base=statistics.median(r['cpu_ns']for r in values if r['label']in ['base','control']);row=dict(compiler=cc,id=id,case=f['name'],median_cpu_ns=m,pooled_base_ns=base,ratios={l:m[l]/base for l in labels});summary.append(row);print(cc,id,f['name'],{l:round(m[l]/base,3)for l in labels},flush=True);(D/f'{stem}_raw.json').write_text(json.dumps(raw));(D/f'{stem}_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Complete',len(raw),flush=True)
