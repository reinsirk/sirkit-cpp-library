# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_suffix_416494/agent');source=R/'String/Suffix_Array.cpp';base=source.read_text()
forward='''        for (int slot = 0; slot < n; ++slot) {
            const int before = suffixes[slot] - 1;
'''
backward='''        for (int slot = n - 1; slot >= 0; --slot) {
            const int before = suffixes[slot] - 1;
'''
assert base.count(forward)==1 and base.count(backward)==1
rows={}
for distance,locality in [(16,1),(32,1),(64,3)]:
    def hints(direction):
        condition=f'slot < n - {distance}'if direction=='forward'else f'slot >= {distance}'
        offset=f'slot + {distance}'if direction=='forward'else f'slot - {distance}'
        return f'''#if defined(__GNUC__) || defined(__clang__)
            if ({condition}) {{
                const int ahead = suffixes[{offset}];
                if (ahead > 0) {{
                    __builtin_prefetch(small.data() + ahead - 1, 0, {locality});
                    __builtin_prefetch(symbols.data() + ahead - 1, 0, {locality});
                }}
            }}
#endif
'''
    f=forward.replace('            const int before',hints('forward')+'            const int before',1)
    b=backward.replace('            const int before',hints('backward')+'            const int before',1)
    candidate=base.replace(forward,f,1).replace(backward,b,1)
    name=f'prefetch{distance}.hpp';(D/name).write_text(candidate)
    rows[name]=dict(distance=distance,locality=locality,sha256=hashlib.sha256(candidate.encode()).hexdigest(),bytes=len(candidate.encode()))
meta=dict(source=str(source),source_sha256=hashlib.sha256(base.encode()).hexdigest(),canonical_modified=False,compiled_or_tested=False,candidates=rows)
(D/'prefetch_metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(meta,ensure_ascii=False,indent=2))
