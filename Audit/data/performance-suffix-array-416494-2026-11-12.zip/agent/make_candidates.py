# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_suffix_416494/agent')
source=R/'String/Suffix_Array.cpp';base=source.read_text()
old_boundary='''                if (offset > 0 && ((small[position + offset] & 2) || (small[previous + offset] & 2))) {
                    different = (small[position + offset] & 2) != (small[previous + offset] & 2); break;
                }
'''
new_boundary='''                if (offset > 0 && (small[position + offset] & 2)) break;
'''
old_class='''    // 0=L型、1=S型、3=LMS。判定後に境界印を重ねる。
    std::vector<std::uint8_t> small(n);
    small[n - 1] = 1;
    for (int i = n - 2; i >= 0; --i)
        small[i] = symbols[i] < symbols[i + 1] ||
            (symbols[i] == symbols[i + 1] && small[i + 1]);
    std::vector<int> selected;
    selected.reserve(static_cast<std::size_t>(n / 2));
    for (int i = 1; i < n; ++i)
        if (small[i] && !small[i - 1]) { small[i] |= 2; selected.push_back(i); }
'''
new_class='''    // 0=L型、1=S型、3=LMS。隣接2位置の型を決めてから境界印を重ねる。
    std::vector<std::uint8_t> small(n);
    std::vector<int> selected;
    selected.reserve(static_cast<std::size_t>(n / 2));
    small[n - 1] = 1;
    for (int i = n - 2; i >= 0; --i) {
        small[i] = symbols[i] < symbols[i + 1] ||
            (symbols[i] == symbols[i + 1] && small[i + 1]);
        if (!small[i] && small[i + 1]) { small[i + 1] |= 2; selected.push_back(i + 1); }
    }
    std::reverse(selected.begin(), selected.end());
'''
assert base.count(old_boundary)==1 and base.count(old_class)==1
headers={
    'label_simplified.hpp':base.replace(old_boundary,new_boundary,1),
    'classification_fused.hpp':base.replace(old_class,new_class,1),
    'classification_fused_label_simplified.hpp':base.replace(old_class,new_class,1).replace(old_boundary,new_boundary,1),
}
for name,data in headers.items():(D/name).write_text(data)
meta=dict(source=str(source),source_sha256=hashlib.sha256(base.encode()).hexdigest(),canonical_modified=False,compiled_or_tested=False,candidates={name:dict(sha256=hashlib.sha256(data.encode()).hexdigest(),bytes=len(data.encode()))for name,data in headers.items()})
(D/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(meta,ensure_ascii=False,indent=2))
