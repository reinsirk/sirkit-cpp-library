# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,statistics,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_suffix_416494')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,a):p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
validation=load(D/'final_validation.json');assert validation['all_passed'] and validation['passed_jobs']==24
assert sha(R/'String/Suffix_Array.cpp')==sha(D/'final.hpp')
fixtures=load(D/'fixtures.json');ns={f['name']:f['n']for f in fixtures}
whole=[]
for stem,label,runs in [('confirm','fused_encode_all',10500),('backfill_confirm','final',8400)]:
 rows=load(D/f'{stem}_summary.json');assert len(rows)==300 and len(load(D/f'{stem}_raw.json'))==runs
 for cc in ['gcc','clang']:
  for identifier in ['suffix_array','suffix_array_substrings']:
   a=[r for r in rows if r['compiler']==cc and r['id']==identifier and ns[r['case']]>=200000]
   whole.append(dict(phase=stem,compiler=cc,id=identifier,cases=len(a),geometric_mean_ratio=statistics.geometric_mean(r['ratios'][label]for r in a),worst_ratio=max(r['ratios'][label]for r in a),cases_above_1_02=[dict(case=r['case'],ratio=r['ratios'][label])for r in a if r['ratios'][label]>1.02]))
base=(D/'base.hpp').read_text();final=(D/'final.hpp').read_text();public='#ifndef SIRKIT_SUFFIX_ARRAY_DEFINED';assert base[base.index(public):]==final[final.index(public):]
frozen={}
for p in ['Verify/current/drivers/suffix_array_main.cpp','Verify/current/drivers/suffix_array_substrings_main.cpp','Verify/current/common/fast_io.hpp']:
 assert (R/p).read_bytes()==(D/'before'/p).read_bytes();frozen[p]=sha(R/p)
profilepath=next((D/'profiles/runs').glob('*.json'));profiles=load(profilepath);assert profiles['counts']=={'LOCAL_SAMPLE_PASS':14}
correspondence=load(D/'current_correspondence.json');assert len(correspondence)==4 and all(r['final_benchmarked_text_matches_current']for r in correspondence)
for p in ['Document/suffix_array.md','Examples/suffix_array_example.cpp']:
 assert sha(R/p)==load(D/'frozen_document_examples.json')[p]
audit=dict(date='2026-11-12',library='String/Suffix_Array.cpp',decision='adopt_reverse_classification_LMS_fusion_and_string_encoding_without_zero_initialization',required_resubmission=['Verify/current/submissions/suffix_array.cpp','Verify/current/submissions/suffix_array_substrings.cpp'],online_evidence='Audit/online-suffix-array-416494-416493-2026-11-12.json',online_scope='416494 AC57msと416493 AC48msは本体改修前の提出。今回の改修と派生版は未提出。',source_sha256=dict(before=sha(D/'base.hpp'),after=sha(D/'final.hpp')),frozen_main_IO=frozen,public_API_vector_encodings_LCP_checks_and_search_unchanged=True,changes=[
 '逆向きのS/L分類とLMS検出を統合し、全入力をもう一度走査する処理を省く。集めたLMSを逆順に戻し、従来の位置順・縮約列末尾の一意な0を維持。',
 '文字列の符号化配列だけmake_unique_for_overwriteを使い、直後に上書きする全要素のゼロ初期化を省く。終端0を明示し、非終端全要素を設定する。',
 '内部SA-ISはspan<const int>で借用する。文字列のunique_ptrと、従来どおりのvectorを使う整数列/再帰の両方に対応し、所有者の生存中だけ参照する。'
 ],ownership='通常版の所有はvector/unique_ptr、直接new式・解放省略はなし。独立した確保失敗注入で全設定live_delta=0。',measurement=dict(cpu='Intel Core i9-14900K CPU12/core6 P-Core; sibling13',E_core_measured=False,compilers={'GCC':'15.2.0','Clang':'21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'},flags=['-std=c++23','-O2'],march_native=False,extra_pragmas=False,new_SIMD_or_CPU_dispatch=False,standard_CXX23_path=True,ASLR='setarch x86_64 -R for child only',lock='/tmp/sirkit_performance_cpu12.lock',compilation_during_timing=False,whole='固定main/共通IOのuser+system CPU時間。同一activeパスでbase/control/候補を決定的shuffle。controlはbaseと同じ実行ファイル。',whole_phase_statistics=whole,whole_repetitions_per_phase=7,large_selection='入力長20万以上の48ケース。小さい入力の起動費を平均改善率へ混ぜない。',fixture_rows=len(fixtures),byte_unique_inputs=len({f['sha256']for f in fixtures}),fixture_origin='前回Audit/data/performance-suffix-array-416380-2026-11-11.zipと同じ固定公開生成器/補助入力。SHAで対応。',official_revision='73876f1cbcf082d2b22722924b924d3d65a2f00e',fixture_scope='固定seedによる公開ケース相当と独立作成ケース。制約外100万要素を含み、オンライン入力との同一性は主張しない。',all_variant_outputs_equal=True,core='steady_clock時間、入力作成/事前SA構築は外。APIの結果を全要素checksumへ消費する部分は含む。LCP/検索は事前SA構築後の確保状態を含む。',core_operations=['bounded integer SA','compressed int64 SA','vector<bool> SA','LCP reuse','equal range search'],core_settings=['checked','SKIP_RUNTIME_CHECKS'],core_sizes=[32,4096,500000],core_extra='int64は100万要素も追加。最終版7反復、気になったboolは50万/100万要素を21反復で再測定。',core_output_hashes_equal=True),rejected_candidates=[
 dict(name='prefetch16/prefetch32/prefetch64',reason='ヒントを入れた先読みはGCC平均約5〜6%、Clang平均約2〜3%増加し不採用。GNU/Clangガード付きの候補だけに留め、配布コードへ入れない。'),
 dict(name='all_encoders_uninitialized',reason='整数列の一部に増減があり、整数列の符号化は元のvector経路を保持。文字列の測定済みコードと同じ.textを保てることを両コンパイラ/両mainで確認。'),
 dict(name='uninitialized_internal_starts_cursor_flags',reason='初期化をさらに省いても、全条件に安定した上積みは見られない。'),
 dict(name='label_boundary_simplification',reason='同値な判定の短縮でも性能の増減があり、採用案を安定して上回らない。'),
 dict(name='selected_tail_backfill',reason='LMS位置を配列末尾から埋めてreverseを省く案も正当性試験は通るが、全75入力の再測定ではGCCのSA単体で平均約0.7%の追加短縮に留まり、GCCのSA+LCPとClang両mainでは平均約0.3〜0.5%増加。採用済みのvector構造を維持。')
 ],targeted_followup='初回の全体測定で約2%増加したFib/100万交互列等は21反復で増加が再現しなかった。Clangの整数列の増加は元のvector符号化へ戻し、最終版を再測定。boolの周期列も21反復で再確認。小さい差から全条件の厳密な非後退は保証しない。',validation=dict(jobs=24,all_passed=True,compiler_and_checks='GCC/Clang × checked/SKIP_RUNTIME_CHECKS',tests=['ACL形式API/列型/境界','独立な短列SA・LCP・検索参照と全二進列','20万要素の独立doubling参照等','確保失敗・所有権'],sanitizers='API/参照試験をASAN+UBSANでも全4設定実行。hostのptrace制約によりdetect_leaks=0、解放は独立の確保カウンタで検証。',allocation_counters=[r['counters']for r in validation['jobs']if r['test']=='string_math_allocation_test'],variant_and_example_profiles=profiles,current_correspondence=correspondence),license='CC0-1.0独自実装。新しい外部実装のコードは転記していない。数学的なSA-ISの原論文参照とACLの公開API参照を維持。公開問題生成器の本文は一時領域のみで使い、配布コード/証拠ZIPへ入れない。',evidence='Audit/data/performance-suffix-array-416494-2026-11-12.zip')
put(R/'Audit/performance-suffix-array-416494-2026-11-12.json',audit)
files=[p for p in D.iterdir()if p.is_file()and p.suffix in ['.json','.py','.hpp','.cpp']]
files += [p for p in (D/'agent').iterdir()if p.is_file()and p.suffix in ['.json','.py','.hpp','.txt']]
for directory in ['before','after','profiles/runs']:
 files += [p for p in (D/directory).rglob('*')if p.is_file()and p.suffix in ['.json','.cpp','.hpp']]
with zipfile.ZipFile(R/audit['evidence'],'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(set(files)):z.write(p,str(p.relative_to(D)))
print('audit/evidence ready',whole)
