// SPDX-License-Identifier: CC0-1.0
#include SEGMENT_SOURCE
#include LAZY_SOURCE
#include <cassert>
#include <type_traits>
#include <vector>
struct Or{bool operator()(bool a,bool b)const noexcept{return a||b;}};
struct Xor{bool operator()(bool a,bool b)const noexcept{return a!=b;}};
struct Mapping{bool operator()(bool f,bool x,std::size_t n)const noexcept{return x!=(f&&(n&1));}};
struct Composition{bool operator()(bool f,bool g)const noexcept{return f!=g;}};
int main(){SegmentTree<bool,Or>s(std::vector<bool>{false,true,false},false,Or{});static_assert(std::is_same_v<decltype(s.get(0)),bool>);assert(s.get(1));s.set(1,false);assert(!s.get(1)&&!s.prod(0,3)&&!s.all_prod());LazySegmentTree<bool,bool,Xor,Mapping,Composition>l(std::vector<bool>{false,true,false},false,false,{}, {},{});l.apply(0,3,true);assert(l.get(0)&&!l.get(1)&&l.get(2));assert(!l.prod(0,3));}
