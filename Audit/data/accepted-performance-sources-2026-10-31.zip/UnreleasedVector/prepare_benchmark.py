from pathlib import Path
import subprocess,json,random,importlib.util,hashlib,sys
sys.dont_write_bytecode=True
p=Path(__file__).parent;root=Path('/home/reinsirk/Atcoder_Env');spec=importlib.util.spec_from_file_location('prepare',root/'Scripts/prepare_verify.py');prepare=importlib.util.module_from_spec(spec);spec.loader.exec_module(prepare)
ids=['fenwick_tree','segment_tree','lazy_segment_tree','implicit_treap_affine','wavelet_kth','aho_corasick_counts','suffix_automaton','palindromic_tree'];entries={}
for path in(root/'Verify/current/groups').glob('*.json'):
 for item in json.loads(path.read_text())['entries']:
  if item['id']in ids:entries[item['id']]=item
inputs=[];mod=998244353
for large in [False,True]:
 n=100000 if large else 1024;q=200000 if large else 100000;rng=random.Random(n+7338)
 lines=[f'{n} {q}',' '.join(str(rng.randrange(1000000001))for _ in range(n))]
 for _ in range(q):
  if rng.randrange(2):lines.append(f'0 {rng.randrange(n)} {rng.randrange(1000000001)}')
  else:l=rng.randrange(n);r=rng.randrange(l+1,n+1);lines.append(f'1 {l} {r}')
 target=p/f'input_add_{n}.txt';target.write_text('\n'.join(lines)+'\n')
 for kind in ['fenwick_tree','segment_tree']:inputs.append({'kind':kind,'n':n,'input':str(target),'size':'large'if large else'small'})
 affine=p.parent/'link_cut_tree/performance'/f'input_affine_{n}.txt';assert affine.exists();inputs.append({'kind':'lazy_segment_tree','n':n,'input':str(affine),'size':'large'if large else'small'})
 lines=[f'{n} {q}',' '.join(str(rng.randrange(mod))for _ in range(n))];length=n
 for _ in range(q):
  x=rng.randrange(100)
  if not length or x<42:pos=rng.randrange(length+1);lines.append(f'0 {pos} {rng.randrange(mod)}');length+=1
  elif x<52:pos=rng.randrange(length);lines.append(f'1 {pos}');length-=1
  else:
   l=rng.randrange(length);r=rng.randrange(l+1,length+1)
   if x<64:lines.append(f'2 {l} {r}')
   elif x<82:lines.append(f'3 {l} {r} {rng.randrange(mod)} {rng.randrange(mod)}')
   else:lines.append(f'4 {l} {r}')
 target=p/f'input_treap_{n}.txt';target.write_text('\n'.join(lines)+'\n');inputs.append({'kind':'implicit_treap_affine','n':n,'input':str(target),'size':'large'if large else'small'})
 lines=[f'{n} {q}',' '.join(str(rng.randrange(1000000001))for _ in range(n))]
 for _ in range(q):l=rng.randrange(n);r=rng.randrange(l+1,n+1);lines.append(f'{l} {r} {rng.randrange(r-l)}')
 target=p/f'input_wavelet_{n}.txt';target.write_text('\n'.join(lines)+'\n');inputs.append({'kind':'wavelet_kth','n':n,'input':str(target),'size':'large'if large else'small'})
 patterns=50000 if large else 1000;text_length=500000 if large else 10000;lines=[''.join(rng.choice('abcdefghijklmnopqrstuvwxyz')for _ in range(text_length)),str(patterns)];lines.extend(''.join(rng.choice('abcdefghijklmnopqrstuvwxyz')for _ in range(12))for _ in range(patterns));target=p/f'input_aho_{n}.txt';target.write_text('\n'.join(lines)+'\n');inputs.append({'kind':'aho_corasick_counts','n':patterns,'input':str(target),'size':'large'if large else'small'})
 text_length=500000 if large else 10000
 for kind in ['suffix_automaton','palindromic_tree']:
  text=''.join(rng.choice('abcd')for _ in range(text_length))if kind=='suffix_automaton'else'a'*text_length;target=p/f'input_{kind}_{text_length}.txt';target.write_text(text+'\n');inputs.append({'kind':kind,'n':text_length,'input':str(target),'size':'large'if large else'small'})
for info in inputs:info['sha256']=hashlib.sha256(Path(info['input']).read_bytes()).hexdigest()
(p/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
timer='''#include <ctime>
#include <cstdio>
#include <cstdint>
#include <cinttypes>
struct BenchmarkTimer {timespec start{};BenchmarkTimer(){clock_gettime(CLOCK_THREAD_CPUTIME_ID,&start);}~BenchmarkTimer(){timespec end{};clock_gettime(CLOCK_THREAD_CPUTIME_ID,&end);const auto ns=(static_cast<std::int64_t>(end.tv_sec)-start.tv_sec)*1000000000+end.tv_nsec-start.tv_nsec;std::fprintf(stderr,"THREAD_NS=%" PRId64 "\\n",ns);}};
BenchmarkTimer benchmark_timer;
'''
records=[];out=p/'binaries.json';existing=json.loads(out.read_text())if out.exists()else[]
for cc,compiler,args in [('gcc','/usr/bin/g++',[]),('clang','/usr/bin/clang++',['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for native in [False,True]:
  config=cc+('_native'if native else'_default');flags=['-std=c++23','-O2',*args]+(['-march=native']if native else[])
  for variant in ['normal','buffer','unreleased']:
   bundle=hashlib.sha256(b''.join((p/variant/entry['libraries'][0]).read_bytes()for entry in entries.values())).hexdigest()
   reuse=next((r for r in existing if r['config']==config and r['variant']==variant and r.get('bundle_sha256')==bundle),None)
   if reuse:records.append(reuse);out.write_text(json.dumps(records,indent=2)+'\n');print('reused',config,variant,flush=True);continue
   row={'config':config,'variant':variant,'bundle_sha256':bundle,'verify':{},'api':{}}
   for kind,entry in entries.items():
    key=entry['libraries'][0];source=p/variant/key;driver=(root/entry['driver']).read_text().replace('int main(',timer+'int main(',1);data,hashes=prepare.render(entry,skip_runtime_checks=True,source_overrides={key:source.read_bytes()},driver_override=driver);cpp=p/f'{config}_{variant}_{kind}.cpp';cpp.write_bytes(data);binary=cpp.with_suffix('');cmd=['taskset','-c','8',compiler,*flags,str(cpp),'-o',str(binary)];c=subprocess.run(cmd,capture_output=True,text=True);assert c.returncode==0,c.stderr;row['verify'][kind]=str(binary)
   for index,(kind,key)in enumerate([('sam','String/Suffix_Automaton.cpp'),('pal','String/Palindromic_Tree.cpp'),('aho','String/Aho_Corasick.cpp'),('treap','DataStructure/implicit_treap.cpp')]):
    binary=p/f'{config}_{variant}_api_{kind}';cmd=['taskset','-c','8',compiler,*flags,'-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_BENCH_KIND={index}',f'-DLIBRARY_SOURCE="{p/variant/key}"',str(p/'growth_benchmark.cpp'),'-o',str(binary)];c=subprocess.run(cmd,capture_output=True,text=True);assert c.returncode==0,c.stderr;row['api'][kind]=str(binary)
   records.append(row);out.write_text(json.dumps(records,indent=2)+'\n');print('prepared',config,variant,flush=True)
  records.append(dict(records[-3],variant='normal_control'));records.append(dict(records[-3],variant='buffer_control'));out.write_text(json.dumps(records,indent=2)+'\n')
print('benchmark binaries ready',len(records),flush=True)
