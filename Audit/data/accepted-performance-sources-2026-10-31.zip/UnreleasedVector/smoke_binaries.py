from pathlib import Path
import subprocess,json,hashlib
p=Path(__file__).parent;root=Path('/home/reinsirk/Atcoder_Env');entries={}
for path in(root/'Verify/current/groups').glob('*.json'):
 for row in json.loads(path.read_text())['entries']:entries[row['id']]=row
expected={};count=0
for row in json.loads((p/'binaries.json').read_text()):
 if row['variant'].endswith('control'):continue
 for kind,binary in row['verify'].items():
  text=entries[kind]['samples'][0]['input'];r=subprocess.run(['taskset','-c','8',binary],input=text,text=True,capture_output=True,check=True);key=('verify',kind);expected.setdefault(key,r.stdout);assert expected[key]==r.stdout,(row,kind,r.stdout);count+=1
 for kind,binary in row['api'].items():
  r=subprocess.run(['taskset','-c','8',binary,'100','1','0'],capture_output=True,text=True,check=True);data=json.loads(r.stdout);key=('api',kind);expected.setdefault(key,data['hash']);assert expected[key]==data['hash'],(row,kind,data);count+=1
(p/'smoke_results.json').write_text(json.dumps({'binaries':count,'all_passed':True,'expected':{str(k):v for k,v in expected.items()}},indent=2)+'\n');print('smoke',count,'PASS')
