from pathlib import Path
import sys,json,hashlib,importlib.util
sys.dont_write_bytecode=True
root=Path('/home/reinsirk/Atcoder_Env');p=Path(__file__).parent
sys.path.insert(0,str(root/'Scripts'));spec=importlib.util.spec_from_file_location('fastgen',root/'Scripts/generate_fast_sources.py');gen=importlib.util.module_from_spec(spec);spec.loader.exec_module(gen)
functions={'DataStructure/Fenwick_Tree.cpp':gen.fenwick,'DataStructure/Segment_Tree.cpp':gen.segment,'DataStructure/Lazy_Segment_Tree.cpp':gen.lazy_segment,'DataStructure/implicit_treap.cpp':gen.implicit_treap,'DataStructure/Wavelet_Matrix.cpp':gen.wavelet_matrix,'String/Aho_Corasick.cpp':gen.aho_corasick}
functions['String/Suffix_Automaton.cpp']=lambda source:gen.fast_buffer_storage(source,[('std::vector<State> states_;','reinsirk::detail::FastBuffer<State> states_;'),('std::vector<State>{}.swap(states_);','reinsirk::detail::FastBuffer<State>{}.swap(states_);')])
functions['String/Palindromic_Tree.cpp']=lambda source:gen.fast_buffer_storage(source,[('std::vector<Node> nodes_;','reinsirk::detail::FastBuffer<Node> nodes_;'),('std::vector<Node>{}.swap(nodes_);','reinsirk::detail::FastBuffer<Node>{}.swap(nodes_);')])
helper=(p/'Unreleased_Vector.cpp').read_text();helper=helper[helper.index('#include '):]
rows=[]
for name,build in functions.items():
 normal=(root/name).read_text();buffer=build(normal);candidate=buffer
 for t in ['T','S','F']:
  old='reinsirk::detail::FastBuffer<'+t+'>'
  new='std::conditional_t<std::is_same_v<'+t+',bool>,reinsirk::detail::FastBuffer<'+t+'>,reinsirk::detail::UnreleasedVector<'+t+'>>'
  candidate=candidate.replace(old,new)
 candidate=candidate.replace('reinsirk::detail::FastBuffer<','reinsirk::detail::UnreleasedVector<')
 # bool分岐にだけ旧FastBufferを保持する。
 for t in ['T','S','F']:candidate=candidate.replace('bool>,reinsirk::detail::UnreleasedVector<'+t+'>,reinsirk::detail::UnreleasedVector<'+t+'>>','bool>,reinsirk::detail::FastBuffer<'+t+'>,reinsirk::detail::UnreleasedVector<'+t+'>>')
 candidate=candidate.replace('// 速度優先版: 内部の主要領域は破棄・解放しない。格納型のデストラクタの副作用を必要としないこと。','// 速度優先候補: 最後の主要配列は破棄・解放しない。成長/代入/clear等は通常vectorの破棄・回収を行う。\n// 最後の破棄や格納型デストラクタの副作用を必要としないこと。bool配列だけは旧FastBuffer。')
 at=candidate.index('#include ');candidate=candidate[:at]+helper+'\n'+candidate[at:]
 row={'library':name,'formal_source_sha256':hashlib.sha256(normal.encode()).hexdigest(),'files':{}}
 for kind,text in [('normal',normal),('buffer',buffer),('unreleased',candidate)]:
  target=p/kind/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text);row['files'][kind]={'path':str(target),'sha256':hashlib.sha256(text.encode()).hexdigest()}
 rows.append(row)
(p/'candidates.json').write_text(json.dumps(rows,indent=2)+'\n');print('prepared',len(rows),'libraries, no formal mutation')
