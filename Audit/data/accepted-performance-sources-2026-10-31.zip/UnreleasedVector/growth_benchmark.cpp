#include <cinttypes>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <string>
#include <vector>
#include LIBRARY_SOURCE
std::uint64_t cpu(){timespec t{};clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t);return static_cast<std::uint64_t>(t.tv_sec)*1000000000+static_cast<std::uint64_t>(t.tv_nsec);}
std::uint64_t next(std::uint64_t&r){r^=r<<13;r^=r>>7;r^=r<<17;return r;}
#if SIRKIT_BENCH_KIND==3
struct Algebra{struct S{std::uint64_t sum;std::size_t count;};using F=std::uint64_t;static S op(S a,S b){return {a.sum+b.sum,a.count+b.count};}static S e(){return {0,0};}static S mapping(F f,S x){return {x.sum+f*x.count,x.count};}static F composition(F f,F g){return f+g;}static F id(){return 0;}};
#endif
int main(int argc,char**argv){if(argc!=4)return 1;const auto n=static_cast<std::size_t>(std::strtoull(argv[1],nullptr,10));const int cycles=std::atoi(argv[2]),reserve=std::atoi(argv[3]);std::uint64_t hash=0,build_ns=0,query_ns=0,teardown_ns=0;
 for(int cycle=0;cycle<cycles;++cycle){std::uint64_t random=731592+static_cast<std::uint64_t>(cycle);auto t0=cpu();std::uint64_t t1{},t2{};{
#if SIRKIT_BENCH_KIND==0
  SuffixAutomaton<> tree;if(reserve)tree.reserve(n);for(std::size_t i=0;i<n;++i)tree.append(static_cast<std::uint8_t>('a'+next(random)%4));t1=cpu();hash+=tree.distinct_substring_count();for(int i=0;i<1000;++i)hash+=tree.occurrences(i&1?"aba":"cac");t2=cpu();tree.clear();
#elif SIRKIT_BENCH_KIND==1
  PalindromicTree<> tree;if(reserve)tree.reserve(n);for(std::size_t i=0;i<n;++i)tree.append(static_cast<std::uint8_t>('a'));t1=cpu();hash+=tree.distinct_palindrome_count();for(int i=0;i<1000;++i)hash+=tree.occurrences(i&1?"aba":"cac");t2=cpu();tree.clear();
#elif SIRKIT_BENCH_KIND==2
  AhoCorasick<> tree;if(reserve)tree.reserve_nodes(n*8);for(std::size_t i=0;i<n;++i){std::string pattern(12,'a');for(auto&c:pattern)c=static_cast<char>('a'+next(random)%26);tree.add(pattern);}tree.build();t1=cpu();std::string text(n*12,'a');for(auto&c:text)c=static_cast<char>('a'+next(random)%26);auto counts=tree.match_counts(text);for(auto count:counts)hash+=count;hash+=tree.state_count();t2=cpu();tree.clear();
#elif SIRKIT_BENCH_KIND==3
  using A=Algebra;lazy_implicit_treap<A::S,A::op,A::e,A::F,A::mapping,A::composition,A::id,true>tree;if(reserve)tree.reserve(n);for(std::size_t i=0;i<n;++i){const auto position=static_cast<int>(next(random)%(i+1));const auto value=next(random);tree.insert_at(position,{value,1});}t1=cpu();for(int i=0;i<10000;++i){const auto l=next(random)%n,r=l+1+next(random)%(n-l);tree.apply(l,r,1);hash^=tree.prod(l,r).sum;}t2=cpu();tree.clear();
#endif
  }auto t3=cpu();build_ns+=t1-t0;query_ns+=t2-t1;teardown_ns+=t3-t2;
 }
 std::printf("{\"hash\":%" PRIu64 ",\"build_ns\":%" PRIu64 ",\"query_ns\":%" PRIu64 ",\"teardown_ns\":%" PRIu64 "}\n",hash,build_ns,query_ns,teardown_ns);
}
