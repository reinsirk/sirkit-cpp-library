// SPDX-License-Identifier: CC0-1.0
// 参考（モノイドと作用）: https://info.atcoder.jp/entry/algorithm_lectures/range_query_monoid_design
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/lazy_segment_tree.md
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/fast_variants.md
//
// API一覧
// 速度優先候補: 最後の主要配列は破棄・解放しない。成長/代入/clear等は通常vectorの破棄・回収を行う。
// 最後の破棄や格納型デストラクタの副作用を必要としないこと。bool配列だけは旧FastBuffer。
// 入力・容量・件数の前提と確保成功を利用側が保証する。例外時の状態復元は保証しない。
// [LazySegmentTree<S,F,Op,Mapping,Composition>]
// (n,identity_value,identity_update,op={},mapping={},compose={})/(vector<S>,同じ引数): 単位元の列/列から構築。O(n+1)時間・領域。
// Op(a,b)は結合的、identity_valueは左右の単位元。Mapping(f,value,length)は長さlengthの集約値へfを作用させる。演算/コピーはO(1)とする。
// Composition(newer,older)はolderの後にnewerを適用する作用。identity_updateは恒等作用。作用は区間の結合と整合し、長さを変えない。
// size()/empty(): 要素数/空か、O(1)。set(i,value)/apply(i,f)/apply(l,r,f)/apply_all(f): 点代入/点作用/半開区間作用/全体作用。O(log(n+1))。
// get(i): 点のS値、prod(l,r): 左からの区間積を返す。O(log(n+1))。all_prod(): 全積のconst S&（boolは値）、O(1)。
// 空区間のprod・空列の全積はidentity_value。照会でも遅延伝播で内部状態を変更する。添字は0始まり。
// max_right(l,pred)/min_left(r,pred): predが真の最大右端/最小左端。O(log(n+1))。pred(identity_value)==trueと境界の単調性が前提。
// values(): 全点を伝播してコピー、O(n+1)。assign(vector<S>)/reset(n)/reset(): 列再構築/n要素/現在の長さを単位元にする。O(旧n+n+1)。
// clear()/swap(other): 空へ戻す/交換。O(旧n+1)/O(1)。コピーは独立、移動元は空。演算等が例外を投げる場合は内容の強い保証なし。

#include <concepts>
#include <cstddef>
#include <initializer_list>
#include <iterator>
#include <type_traits>
#include <utility>
#include <vector>

#ifndef SIRKIT_UNRELEASED_VECTOR_DEFINED
#define SIRKIT_UNRELEASED_VECTOR_DEFINED
namespace reinsirk::detail {
template<class T>
class UnreleasedVector {
    union {std::vector<T> values_;};
public:
    using value_type=T;
    using size_type=typename std::vector<T>::size_type;
    using difference_type=typename std::vector<T>::difference_type;
    using reference=typename std::vector<T>::reference;
    using const_reference=typename std::vector<T>::const_reference;
    using pointer=typename std::vector<T>::pointer;
    using const_pointer=typename std::vector<T>::const_pointer;
    using iterator=typename std::vector<T>::iterator;
    using const_iterator=typename std::vector<T>::const_iterator;
    using reverse_iterator=typename std::vector<T>::reverse_iterator;
    using const_reverse_iterator=typename std::vector<T>::const_reverse_iterator;
    UnreleasedVector()noexcept:values_{}{}
    explicit UnreleasedVector(size_type n):values_(n){}
    UnreleasedVector(size_type n,const T&value):values_(n,value){}
    template<std::input_iterator It> UnreleasedVector(It first,It last):values_(first,last){}
    UnreleasedVector(std::initializer_list<T> values):values_(values){}
    UnreleasedVector(const std::vector<T>&values)requires std::is_copy_constructible_v<T>:values_(values){}
    UnreleasedVector(std::vector<T>&&values)noexcept:values_(std::move(values)){values.clear();}
    UnreleasedVector(const UnreleasedVector&other)requires std::is_copy_constructible_v<T>:values_(other.values_){}
    UnreleasedVector&operator=(const UnreleasedVector&other)requires(std::is_copy_constructible_v<T>&&std::is_copy_assignable_v<T>){if(this!=&other)values_=other.values_;return *this;}
    UnreleasedVector(UnreleasedVector&&other)noexcept:values_(std::move(other.values_)){other.values_.clear();}
    UnreleasedVector&operator=(UnreleasedVector&&other)noexcept{if(this!=&other){values_=std::move(other.values_);other.values_.clear();}return *this;}
    ~UnreleasedVector()noexcept{} // 意図的にactiveなvectorを破棄しない。
    UnreleasedVector&operator=(std::initializer_list<T> values){values_=values;return *this;}
    iterator begin()noexcept{return values_.begin();}
    const_iterator begin()const noexcept{return values_.begin();}
    const_iterator cbegin()const noexcept{return values_.cbegin();}
    iterator end()noexcept{return values_.end();}
    const_iterator end()const noexcept{return values_.end();}
    const_iterator cend()const noexcept{return values_.cend();}
    reverse_iterator rbegin()noexcept{return values_.rbegin();}
    const_reverse_iterator rbegin()const noexcept{return values_.rbegin();}
    const_reverse_iterator crbegin()const noexcept{return values_.crbegin();}
    reverse_iterator rend()noexcept{return values_.rend();}
    const_reverse_iterator rend()const noexcept{return values_.rend();}
    const_reverse_iterator crend()const noexcept{return values_.crend();}
    bool empty()const noexcept{return values_.empty();}
    size_type size()const noexcept{return values_.size();}
    size_type capacity()const noexcept{return values_.capacity();}
    size_type max_size()const noexcept{return values_.max_size();}
    T*data()noexcept requires(!std::is_same_v<T,bool>){return values_.data();}
    const T*data()const noexcept requires(!std::is_same_v<T,bool>){return values_.data();}
    reference operator[](size_type i)noexcept{return values_[i];}
    const_reference operator[](size_type i)const noexcept{return values_[i];}
    reference at(size_type i){return values_.at(i);}
    const_reference at(size_type i)const{return values_.at(i);}
    reference front()noexcept{return values_.front();}
    const_reference front()const noexcept{return values_.front();}
    reference back()noexcept{return values_.back();}
    const_reference back()const noexcept{return values_.back();}
    void reserve(size_type n){values_.reserve(n);}
    void shrink_to_fit(){values_.shrink_to_fit();}
    void clear()noexcept{values_.clear();}
    void resize(size_type n){values_.resize(n);}
    void resize(size_type n,const T&value){values_.resize(n,value);}
    template<class...Args>reference emplace_back(Args&&...args){return values_.emplace_back(std::forward<Args>(args)...);}
    void push_back(const T&value){values_.push_back(value);}
    void push_back(T&&value){values_.push_back(std::move(value));}
    void pop_back()noexcept{values_.pop_back();}
    void assign(size_type n,const T&value){values_.assign(n,value);}
    template<std::input_iterator It>void assign(It first,It last){values_.assign(first,last);}
    void assign(std::initializer_list<T> values){values_.assign(values);}
    iterator insert(const_iterator position,const T&value){return values_.insert(position,value);}
    iterator insert(const_iterator position,T&&value){return values_.insert(position,std::move(value));}
    iterator insert(const_iterator position,size_type n,const T&value){return values_.insert(position,n,value);}
    template<std::input_iterator It>iterator insert(const_iterator position,It first,It last){return values_.insert(position,first,last);}
    iterator insert(const_iterator position,std::initializer_list<T> values){return values_.insert(position,values);}
    template<class...Args>iterator emplace(const_iterator position,Args&&...args){return values_.emplace(position,std::forward<Args>(args)...);}
    iterator erase(const_iterator position){return values_.erase(position);}
    iterator erase(const_iterator first,const_iterator last){return values_.erase(first,last);}
    void swap(UnreleasedVector&other)noexcept{values_.swap(other.values_);}
    friend void swap(UnreleasedVector&a,UnreleasedVector&b)noexcept{a.swap(b);}
};
}
#endif

#include <algorithm>
#include <cstddef>
#include <iterator>
#include <limits>
#include <memory>
#include <type_traits>
#include <utility>
#include <vector>

#ifndef SIRKIT_FAST_BUFFER_DEFINED
#define SIRKIT_FAST_BUFFER_DEFINED
namespace reinsirk::detail {
template <class T>
class FastBuffer {
    T* data_ = nullptr;
    std::size_t size_ = 0, capacity_ = 0;
    void grow() {
        const auto limit = max_size();
        reserve(capacity_ == 0 ? 1 : capacity_ > limit - capacity_ ? limit : capacity_ * 2);
    }
public:
    using value_type = T;
    using size_type = std::size_t;
    using iterator = T*;
    using const_iterator = const T*;
    using reference = T&;
    using const_reference = const T&;
    FastBuffer() noexcept = default;
    explicit FastBuffer(std::size_t count) {
        reserve(count);
        for (; size_ < count; ++size_) std::construct_at(data_ + size_);
    }
    FastBuffer(std::size_t count, const T& value) {
        reserve(count);
        for (; size_ < count; ++size_) std::construct_at(data_ + size_, value);
    }
    template <std::input_iterator Iterator>
    FastBuffer(Iterator first, Iterator last) {
        if (first == last) return;
        if constexpr (std::forward_iterator<Iterator>) reserve(static_cast<std::size_t>(std::distance(first, last)));
        for (; first != last; ++first) emplace_back(*first);
    }
    FastBuffer(const std::vector<T>& values) : FastBuffer(values.begin(), values.end()) {}
    FastBuffer(const FastBuffer& other) : FastBuffer(other.begin(), other.end()) {}
    FastBuffer& operator=(const FastBuffer& other) {
        if (this != &other) { FastBuffer next(other); swap(next); }
        return *this;
    }
    FastBuffer(FastBuffer&& other) noexcept
        : data_(std::exchange(other.data_, nullptr)), size_(std::exchange(other.size_, 0)),
          capacity_(std::exchange(other.capacity_, 0)) {}
    FastBuffer& operator=(FastBuffer&& other) noexcept {
        if (this != &other) {
            data_ = std::exchange(other.data_, nullptr);
            size_ = std::exchange(other.size_, 0); capacity_ = std::exchange(other.capacity_, 0);
        }
        return *this;
    }
    // デストラクタは、格納値の破棄もdeallocateも行わない。
    ~FastBuffer() = default;
    std::size_t size() const noexcept { return size_; }
    std::size_t capacity() const noexcept { return capacity_; }
    bool empty() const noexcept { return size_ == 0; }
    static constexpr std::size_t max_size() noexcept {
        return static_cast<std::size_t>(std::numeric_limits<std::ptrdiff_t>::max()) / sizeof(T);
    }
    T* data() noexcept { return data_; }
    const T* data() const noexcept { return data_; }
    T* begin() noexcept { return data_; }
    const T* begin() const noexcept { return data_; }
    T* end() noexcept { return size_ == 0 ? data_ : data_ + size_; }
    const T* end() const noexcept { return size_ == 0 ? data_ : data_ + size_; }
    const T* cbegin() const noexcept { return begin(); }
    const T* cend() const noexcept { return end(); }
    T& operator[](std::size_t index) noexcept { return data_[index]; }
    const T& operator[](std::size_t index) const noexcept { return data_[index]; }
    T& front() noexcept { return data_[0]; }
    const T& front() const noexcept { return data_[0]; }
    T& back() noexcept { return data_[size_ - 1]; }
    const T& back() const noexcept { return data_[size_ - 1]; }
    void reserve(std::size_t count) {
        if (count <= capacity_) return;
        // allocator::allocateはT配列の領域を開始する。要素は使用時だけ構築する。
        T* next = std::allocator<T>{}.allocate(count);
        for (std::size_t i = 0; i < size_; ++i)
            std::construct_at(next + i, std::move_if_noexcept(data_[i]));
        data_ = next; capacity_ = count;
    }
    template <class... Args>
    T& emplace_back(Args&&... args) {
        if (size_ == capacity_) {
            // 引数が自身の要素を参照していても、移動する前に新要素を作る。
            T value(std::forward<Args>(args)...);
            grow();
            T* added = std::construct_at(data_ + size_, std::move_if_noexcept(value));
            ++size_;
            return *added;
        }
        T* added = std::construct_at(data_ + size_, std::forward<Args>(args)...);
        ++size_;
        return *added;
    }
    void push_back(const T& value) { emplace_back(value); }
    void push_back(T&& value) { emplace_back(std::move(value)); }
    void pop_back() noexcept { --size_; }
    void clear() noexcept { size_ = 0; }
    void resize(std::size_t count) {
        if (count < size_) { size_ = count; return; }
        reserve(count);
        for (; size_ < count; ++size_) std::construct_at(data_ + size_);
    }
    void resize(std::size_t count, const T& value) {
        if (count < size_) { size_ = count; return; }
        if (count > capacity_) { T copy(value); reserve(count); resize(count, copy); return; }
        for (; size_ < count; ++size_) std::construct_at(data_ + size_, value);
    }
    void assign(std::size_t count, const T& value) { FastBuffer next(count, value); swap(next); }
    template <std::input_iterator Iterator>
    void assign(Iterator first, Iterator last) { FastBuffer next(first, last); swap(next); }
    void swap(FastBuffer& other) noexcept {
        std::swap(data_, other.data_); std::swap(size_, other.size_); std::swap(capacity_, other.capacity_);
    }
    friend void swap(FastBuffer& a, FastBuffer& b) noexcept { a.swap(b); }
};
}
#endif

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

#ifndef SIRKIT_LAZY_SEGMENT_TREE_DEFINED
#define SIRKIT_LAZY_SEGMENT_TREE_DEFINED
template<class S, class F, class Op, class Mapping, class Composition>
class LazySegmentTree {
    [[no_unique_address]] Op op_;
    [[no_unique_address]] Mapping mapping_;
    [[no_unique_address]] Composition compose_;
    S value_identity_;
    F update_identity_;
    std::size_t n_ = 0, base_ = 1, height_ = 0;
    std::conditional_t<std::is_same_v<S,bool>,reinsirk::detail::FastBuffer<S>,reinsirk::detail::UnreleasedVector<S>> data_;
    std::conditional_t<std::is_same_v<F,bool>,reinsirk::detail::FastBuffer<F>,reinsirk::detail::UnreleasedVector<F>> lazy_;
    reinsirk::detail::UnreleasedVector<std::uint8_t> pending_;
    static std::size_t leaf_base(std::size_t n) {
        if (!n) return 1;
        const auto limit = std::min({std::vector<S>{}.max_size() / 2,
                                     std::vector<F>{}.max_size(), std::vector<std::uint8_t>{}.max_size()});
        std::size_t base = 1;
        while (base < n) {
            if (base > limit / 2) throw std::length_error("LazySegmentTree: size");
            base *= 2;
        }
        if (base > limit) throw std::length_error("LazySegmentTree: size");
        return base;
    }
    void check_index(std::size_t i) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (i >= n_) throw std::out_of_range("LazySegmentTree: index");
#else
        (void)i;
#endif
    }
    void check_range(std::size_t l, std::size_t r) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (l > r || r > n_) throw std::out_of_range("LazySegmentTree: range");
#else
        (void)l; (void)r;
#endif
    }
    void pull(std::size_t p) { data_[p] = op_(data_[2 * p], data_[2 * p + 1]); }
    void act(std::size_t p, const F& f, std::size_t length) {
        data_[p] = mapping_(f, data_[p], length);
        if (p < base_) {
            if (pending_[p]) lazy_[p] = compose_(f, lazy_[p]);
            else { lazy_[p] = f; pending_[p] = 1; }
        }
    }
    void push(std::size_t p, std::size_t length) {
        if (!pending_[p]) return;
        act(2 * p, lazy_[p], length / 2);
        act(2 * p + 1, lazy_[p], length / 2);
        pending_[p] = 0;
    }
    void push_path(std::size_t leaf) {
        for (auto level = height_; level; --level) push(leaf >> level, std::size_t{1} << level);
    }
    void push_boundary(std::size_t l, std::size_t r) {
        for (auto level = height_; level; --level) {
            const auto length = std::size_t{1} << level;
            if (l & (length - 1)) push(l >> level, length);
            if (r & (length - 1)) push((r - 1) >> level, length);
        }
    }
    void pull_path(std::size_t leaf) {
        for (leaf >>= 1; leaf; leaf >>= 1) pull(leaf);
    }
public:
    using const_reference = typename std::vector<S>::const_reference;
    explicit LazySegmentTree(std::size_t n, const S& identity_value, const F& identity_update,
                             Op op = Op{}, Mapping mapping = Mapping{}, Composition compose = Composition{})
        : op_(std::move(op)), mapping_(std::move(mapping)), compose_(std::move(compose)),
          value_identity_(identity_value), update_identity_(identity_update), n_(n), base_(leaf_base(n)),
          data_(n ? 2 * base_ : 0, value_identity_), lazy_(n ? base_ : 0, update_identity_), pending_(n ? base_ : 0, 0) {
        for (auto p = base_; p > 1; p >>= 1) ++height_;
    }
    explicit LazySegmentTree(const std::vector<S>& values, const S& identity_value, const F& identity_update,
                             Op op = Op{}, Mapping mapping = Mapping{}, Composition compose = Composition{})
        : LazySegmentTree(values.size(), identity_value, identity_update, std::move(op), std::move(mapping), std::move(compose)) {
        if (!n_) return;
        std::copy(values.begin(), values.end(), data_.begin() + base_);
        for (auto p = base_; p > 1;) pull(--p);
    }
    LazySegmentTree(const LazySegmentTree&) = default;
    LazySegmentTree& operator=(const LazySegmentTree& other) {
        if (this != &other) { LazySegmentTree replacement(other); swap(replacement); }
        return *this;
    }
    LazySegmentTree(LazySegmentTree&& other)
        : op_(other.op_), mapping_(other.mapping_), compose_(other.compose_),
          value_identity_(other.value_identity_), update_identity_(other.update_identity_),
          n_(other.n_), base_(other.base_), height_(other.height_), data_(std::move(other.data_)),
          lazy_(std::move(other.lazy_)), pending_(std::move(other.pending_)) {
        other.clear();
    }
    LazySegmentTree& operator=(LazySegmentTree&& other) {
        if (this != &other) { LazySegmentTree replacement(std::move(other)); swap(replacement); }
        return *this;
    }
    std::size_t size() const noexcept { return n_; }
    bool empty() const noexcept { return n_ == 0; }
    S get(std::size_t i) {
        check_index(i);
        const auto leaf = base_ + i;
        push_path(leaf);
        return data_[leaf];
    }
    void set(std::size_t i, const S& value) {
        check_index(i);
        const auto leaf = base_ + i;
        push_path(leaf); data_[leaf] = value; pull_path(leaf);
    }
    void apply(std::size_t i, const F& f) {
        check_index(i);
        const auto leaf = base_ + i;
        push_path(leaf); act(leaf, f, 1); pull_path(leaf);
    }
    void apply(std::size_t l, std::size_t r, const F& f) {
        check_range(l, r);
        if (l == r) return;
        l += base_; r += base_;
        push_boundary(l, r);
        auto left = l, right = r;
        std::size_t length = 1;
        while (left < right) {
            if (left & 1) act(left++, f, length);
            if (right & 1) act(--right, f, length);
            left >>= 1; right >>= 1; length *= 2;
        }
        for (std::size_t level = 1; level <= height_; ++level) {
            const auto span = std::size_t{1} << level;
            if (l & (span - 1)) pull(l >> level);
            if (r & (span - 1)) pull((r - 1) >> level);
        }
    }
    void apply_all(const F& f) { apply(0, n_, f); }
    S prod(std::size_t l, std::size_t r) {
        check_range(l, r);
        if (l == r) return value_identity_;
        l += base_; r += base_;
        push_boundary(l, r);
        S left = value_identity_, right = value_identity_;
        for (; l < r; l >>= 1, r >>= 1) {
            if (l & 1) left = op_(left, data_[l++]);
            if (r & 1) right = op_(data_[--r], right);
        }
        return op_(left, right);
    }
    const_reference all_prod() const noexcept { return n_ ? data_[1] : value_identity_; }
    template<class Pred> std::size_t max_right(std::size_t l, Pred pred) {
        check_range(l, l);
#ifndef SKIP_RUNTIME_CHECKS
        if (!pred(value_identity_)) throw std::invalid_argument("LazySegmentTree: predicate(identity)");
#endif
        if (l == n_) return n_;
        auto node = base_ + l;
        push_path(node);
        std::size_t length = 1;
        S accumulated = value_identity_;
        while (true) {
            while (!(node & 1)) { node >>= 1; length *= 2; }
            S candidate = op_(accumulated, data_[node]);
            if (!pred(candidate)) {
                while (node < base_) {
                    push(node, length); node *= 2; length /= 2;
                    S next = op_(accumulated, data_[node]);
                    if (pred(next)) { accumulated = std::move(next); ++node; }
                }
                return std::min(n_, node - base_);
            }
            accumulated = std::move(candidate);
            ++node;
            if ((node & (node - 1)) == 0) return n_;
        }
    }
    template<class Pred> std::size_t min_left(std::size_t r, Pred pred) {
        check_range(r, r);
#ifndef SKIP_RUNTIME_CHECKS
        if (!pred(value_identity_)) throw std::invalid_argument("LazySegmentTree: predicate(identity)");
#endif
        if (r == 0) return 0;
        auto node = base_ + r;
        push_path(node - 1);
        std::size_t length = 1;
        S accumulated = value_identity_;
        while (true) {
            --node;
            while (node > 1 && (node & 1)) { node >>= 1; length *= 2; }
            S candidate = op_(data_[node], accumulated);
            if (!pred(candidate)) {
                while (node < base_) {
                    push(node, length); node = 2 * node + 1; length /= 2;
                    S next = op_(data_[node], accumulated);
                    if (pred(next)) { accumulated = std::move(next); --node; }
                }
                return node + 1 - base_;
            }
            accumulated = std::move(candidate);
            if ((node & (node - 1)) == 0) return 0;
        }
    }
    std::vector<S> values() {
        if (!n_) return {};
        for (std::size_t begin = 1, length = base_; begin < base_; begin *= 2, length /= 2)
            for (auto p = begin; p < 2 * begin; ++p) push(p, length);
        return std::vector<S>(data_.begin() + base_, data_.begin() + base_ + n_);
    }
    void assign(const std::vector<S>& values) {
        LazySegmentTree replacement(values, value_identity_, update_identity_, op_, mapping_, compose_); swap(replacement);
    }
    void reset(std::size_t n) {
        LazySegmentTree replacement(n, value_identity_, update_identity_, op_, mapping_, compose_); swap(replacement);
    }
    void reset() {
        std::fill(data_.begin(), data_.end(), value_identity_);
        std::fill(lazy_.begin(), lazy_.end(), update_identity_);
        std::fill(pending_.begin(), pending_.end(), 0);
    }
    void clear() noexcept {
        data_.clear(); lazy_.clear(); pending_.clear(); n_ = 0; base_ = 1; height_ = 0;
    }
    void swap(LazySegmentTree& other) noexcept(std::is_nothrow_swappable_v<Op> && std::is_nothrow_swappable_v<Mapping>
        && std::is_nothrow_swappable_v<Composition> && std::is_nothrow_swappable_v<S> && std::is_nothrow_swappable_v<F>) {
        using std::swap;
        swap(op_, other.op_); swap(mapping_, other.mapping_); swap(compose_, other.compose_);
        swap(value_identity_, other.value_identity_); swap(update_identity_, other.update_identity_);
        swap(n_, other.n_); swap(base_, other.base_); swap(height_, other.height_);
        data_.swap(other.data_); lazy_.swap(other.lazy_); pending_.swap(other.pending_);
    }
};
#endif
