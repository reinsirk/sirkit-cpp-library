`UnreleasedVector` は匿名union内の `std::vector` を通常どおり構築し、最後のvectorの破棄と領域解放だけを省きます。操作は通常のvectorに委譲し、再確保時に旧領域を回収します。clearは要素を破棄して容量を保持します。最後の配列はプロセス終了まで累積するため、格納値の最後の破棄や資源回収を必要としない処理に限ります。通常版の所有権管理は変わりません。

Implicit TreapのFast版ではこの格納を使います。Aho–CorasickのFast版はGCCの場合だけ使用し、Clangでは従来のFastBufferを維持します。ほかのFenwick/Segment/Lazy/WaveletのFast格納、Suffix Automaton/回文木の通常vectorは維持します。

同じ提出コード・入出力・コンパイラ設定の比較では、Treapは旧FastBuffer比で全条件がおおむね同等から数%改善でした。AhoはGCCの大規模ケースで終了までのCPU時間がおおむね同等、最大RSSが144,312→75,272 KiB（約140.9→73.5 MiB）でした。Clangでは大規模CPU時間が約19%増えたため切り替えません。繰り返し構築の小規模APIでは、解放を行う通常版の方が速い場合があります。

測定条件・生データ・対照のばらつきは [Audit](../Audit/fast-unreleased-vector-2026-10-31.json) にあります。RSSにはPython起動側のfork前常駐量が下限として混入するため、36 MiB未満の差を根拠にメモリ改善とはしていません。
