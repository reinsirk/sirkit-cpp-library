from pathlib import Path
import subprocess,json,os,hashlib
p=Path(__file__).parent;root=Path('/home/reinsirk/Atcoder_Env');rows=[]
for cc,compiler,extra in [('gcc','/usr/bin/g++',[]),('clang','/usr/bin/clang++',['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  for test,macro,key,fixture in [('treap','HEADER','DataStructure/implicit_treap.cpp','implicit_treap_exhaustive_test.cpp'),('aho','AHO_HEADER','String/Aho_Corasick.cpp','aho_corasick_reference_test.cpp')]:
   source=p/key;binary=p/f'final_{cc}_{skip}_{test}';cmd=['taskset','-c','8',compiler,*extra,'-std=c++23','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer']+(['-DSKIP_RUNTIME_CHECKS']if skip else[])+[f'-D{macro}="{source}"',str(root/'Verify/current/tests'/fixture),'-o',str(binary)];c=subprocess.run(cmd,capture_output=True,text=True);assert c.returncode==0,c.stderr;r=subprocess.run(['taskset','-c','8',str(binary)],capture_output=True,text=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1'));assert r.returncode==0,(r.stdout,r.stderr);rows.append({'compiler':cc,'skip':skip,'test':test,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'compile_command':cmd,'exit_code':r.returncode,'stdout':r.stdout});(p/'selected_validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,skip,test,'ASanUBSan PASS',flush=True)
 for key in ['DataStructure/implicit_treap.cpp','String/Aho_Corasick.cpp']:
  cmd=['taskset','-c','8',compiler,*extra,'-std=c++23','-pedantic-errors','-fsyntax-only',str(p/key)];r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,r.stderr;rows.append({'compiler':cc,'source':key,'test':'standalone','compile_command':cmd,'exit_code':0});(p/'selected_validation.json').write_text(json.dumps(rows,indent=2)+'\n')
print('final selected',len(rows),'PASS',flush=True)
