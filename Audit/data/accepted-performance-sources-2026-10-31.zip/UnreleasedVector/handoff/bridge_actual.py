from pathlib import Path
import subprocess,json,hashlib
p=Path(__file__).parent.parent;out=p/'handoff';binaries=json.loads((p/'binaries.json').read_text());rows=[]
for cc,compiler,extra in [('gcc','/usr/bin/g++',[]),('clang','/usr/bin/clang++',['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for native in [False,True]:
  config=cc+('_native'if native else'_default')
  for kind,key,api_kind,index in [('implicit_treap_affine','DataStructure/implicit_treap.cpp','treap',3),('aho_corasick_counts','String/Aho_Corasick.cpp','aho',2)]:
   variant='buffer'if cc=='clang'and api_kind=='aho'else'unreleased';row=next(r for r in binaries if r['config']==config and r['variant']==variant)
   for benchmark in ['verify','api']:
    actual=Path(row[benchmark][kind if benchmark=='verify'else api_kind])
    if benchmark=='verify':selected=out/f'{config}_skip_{kind}_selected'
    else:
     selected=out/f'{config}_selected_api_{api_kind}';cmd=['taskset','-c','8',compiler,*extra,'-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS']+(['-march=native']if native else[])+[f'-DSIRKIT_BENCH_KIND={index}',f'-DLIBRARY_SOURCE="{out/key}"',str(p/'growth_benchmark.cpp'),'-o',str(selected)];c=subprocess.run(cmd,capture_output=True,text=True);assert c.returncode==0,c.stderr
    sections={}
    for section in ['.text','.rodata','.data','.eh_frame']:
     content=[]
     for label,binary in [('actual_timed',actual),('selected',selected)]:
      dumped=out/f'{config}_{kind}_{benchmark}_{label}_{section[1:]}.bin';c=subprocess.run(['objcopy','--dump-section',section+'='+str(dumped),str(binary)],capture_output=True,text=True);assert c.returncode==0,c.stderr;content.append(dumped.read_bytes())
     sections[section]={'identical':content[0]==content[1],'sha256':[hashlib.sha256(x).hexdigest()for x in content],'bytes':list(map(len,content))}
    same=all(v['identical']for v in sections.values());rows.append({'config':config,'library':key,'benchmark':benchmark,'actual_timed_binary':str(actual),'selected_binary':str(selected),'sections':sections,'all_runtime_sections_identical':same});(out/'actual_binary_bridge.json').write_text(json.dumps(rows,indent=2)+'\n');print(config,kind,benchmark,'actual timed bytes identical',same,flush=True)
