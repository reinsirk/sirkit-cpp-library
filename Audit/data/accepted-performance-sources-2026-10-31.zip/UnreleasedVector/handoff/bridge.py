from pathlib import Path
import subprocess,json,ast,importlib.util,sys,hashlib
sys.dont_write_bytecode=True
p=Path(__file__).parent.parent;out=p/'handoff';root=Path('/home/reinsirk/Atcoder_Env');spec=importlib.util.spec_from_file_location('prepare',root/'Scripts/prepare_verify.py');prepare=importlib.util.module_from_spec(spec);spec.loader.exec_module(prepare)
entries={}
for path in(root/'Verify/current/groups').glob('*.json'):
 for item in json.loads(path.read_text())['entries']:entries[item['id']]=item
for node in ast.parse((p/'prepare_benchmark.py').read_text()).body:
 if isinstance(node,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='timer'for t in node.targets):timer=ast.literal_eval(node.value)
rows=[]
for cc,compiler,extra in [('gcc','/usr/bin/g++',[]),('clang','/usr/bin/clang++',['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for native in [False,True]:
  for checked in [False,True]:
   config=f'{cc}_{"native"if native else"default"}_{"checked"if checked else"skip"}'
   for kind,key in [('implicit_treap_affine','DataStructure/implicit_treap.cpp'),('aho_corasick_counts','String/Aho_Corasick.cpp')]:
    old=p/('buffer'if cc=='clang'and kind=='aho_corasick_counts'else'unreleased')/key;new=out/key;entry=entries[kind];driver=(root/entry['driver']).read_text().replace('int main(',timer+'int main(',1);binaries=[]
    for label,source in [('measured',old),('selected',new)]:
     data,hashes=prepare.render(entry,skip_runtime_checks=not checked,source_overrides={key:source.read_bytes()},driver_override=driver);cpp=out/f'{config}_{kind}_{label}.cpp';cpp.write_bytes(data);binary=cpp.with_suffix('');cmd=['taskset','-c','8',compiler,*extra,'-std=c++23','-O2']+(['-march=native']if native else[])+[str(cpp),'-o',str(binary)];c=subprocess.run(cmd,capture_output=True,text=True);assert c.returncode==0,c.stderr;binaries.append(binary)
    sections={}
    for section in ['.text','.rodata','.data','.eh_frame']:
     dumped=[]
     for label,binary in zip(['measured','selected'],binaries):
      target=out/f'{config}_{kind}_{label}_{section[1:]}.bin';c=subprocess.run(['objcopy','--dump-section',section+'='+str(target),str(binary)],capture_output=True,text=True);assert c.returncode==0,c.stderr;dumped.append(target.read_bytes())
     sections[section]={'identical':dumped[0]==dumped[1],'lengths':list(map(len,dumped)),'sha256':[hashlib.sha256(x).hexdigest()for x in dumped]}
    same=all(v['identical']for v in sections.values());rows.append({'config':config,'library':key,'old_source_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'selected_source_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'sections':sections,'all_runtime_sections_identical':same});(out/'byte_bridge.json').write_text(json.dumps(rows,indent=2)+'\n');print(config,kind,'identical',same,flush=True)
print('bridge',len(rows),'complete',flush=True)
