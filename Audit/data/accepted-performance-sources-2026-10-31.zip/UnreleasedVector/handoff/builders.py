# SPDX-License-Identifier: CC0-1.0
# Rootのgenerate_fast_sources.pyへ移す候補。ここでは正式ファイルを変更しない。
from pathlib import Path

def replace_once(source,old,new):
    if source.count(old)!=1:raise ValueError('source changed: '+old)
    return source.replace(old,new)

def helper_body(path):
    text=path.read_text();return text[text.index('#include '):]

def introduce(source,note):
    source=replace_once(source,'//\n// API一覧','// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/fast_variants.md\n//\n// API一覧')
    return replace_once(source,'// API一覧\n','// API一覧\n'+note+'\n// 入力・容量・件数の前提と確保成功を利用側が保証する。例外時の状態復元は保証しない。\n')

def treap_unreleased(source,unreleased_helper):
    source=introduce(source,'// 速度優先版: 最後のノード配列は破棄・解放しない。プロセス終了まで累積する。\n// ノード配列はvectorの通常の成長を使い、再確保時の旧領域を回収する。格納型の破棄の副作用を必要としないこと。')
    source=replace_once(source,'std::vector<StoredNode> nodes_;','reinsirk::detail::UnreleasedVector<StoredNode> nodes_;')
    at=source.index('#include ');return source[:at]+helper_body(unreleased_helper)+'\n'+source[at:]

def aho_compiler_storage(source,buffer_helper,unreleased_helper):
    source=introduce(source,'// 速度優先版: GCCでは最後の主要配列の破棄・解放を省き、成長時はvectorとして旧領域を回収する。\n// Clangでは従来のFastBufferを使い、成長中の旧領域も保持する。最後の領域はプロセス終了まで累積する。\n// 格納型の破棄の副作用を必要としないこと。')
    for old,new in [('std::vector<reinsirk::detail::AhoNode<Alphabet>> nodes_;','reinsirk::detail::AhoStorage<reinsirk::detail::AhoNode<Alphabet>> nodes_;'),('std::vector<reinsirk::detail::AhoPattern> patterns_;','reinsirk::detail::AhoStorage<reinsirk::detail::AhoPattern> patterns_;'),('std::vector<int> order_;','reinsirk::detail::AhoStorage<int> order_;'),('std::vector<int> order; order.reserve(nodes_.size()); order.push_back(0);','reinsirk::detail::AhoStorage<int> order; order.reserve(nodes_.size()); order.push_back(0);')]:source=replace_once(source,old,new)
    alias='''#ifndef SIRKIT_AHO_FAST_STORAGE_DEFINED
#define SIRKIT_AHO_FAST_STORAGE_DEFINED
namespace reinsirk::detail {
#if defined(__GNUC__) && !defined(__clang__)
template<class T>using AhoStorage=UnreleasedVector<T>;
#else
template<class T>using AhoStorage=FastBuffer<T>;
#endif
}
#endif
'''
    at=source.index('#include ');return source[:at]+helper_body(buffer_helper)+'\n'+helper_body(unreleased_helper)+'\n'+alias+source[at:]

if __name__=='__main__':
    root=Path('/home/reinsirk/Atcoder_Env');p=Path(__file__).parent.parent;out=Path(__file__).parent
    for name,builder in [('DataStructure/implicit_treap.cpp',lambda source:treap_unreleased(source,p/'Unreleased_Vector.cpp')),('String/Aho_Corasick.cpp',lambda source:aho_compiler_storage(source,root/'Fast/Source/Internal/Buffer.cpp',p/'Unreleased_Vector.cpp'))]:
        target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(builder((p/'normal'/name).read_text()))
    print('selected sources staged only')
