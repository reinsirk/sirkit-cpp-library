from pathlib import Path
import subprocess,os,json,hashlib
p=Path(__file__).parent;rows=[]
for cc,compiler,extra in [('gcc','/usr/bin/g++',[]),('clang','/usr/bin/clang++',['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  for native,san in [(False,False),(True,False),(False,True)]:
   config=f'{cc}_{"skip"if skip else"checked"}_{"native"if native else"default"}'+('_san'if san else'')
   for fixture in ['unreleased_vector_reference_test.cpp','unreleased_vector_ownership_test.cpp']:
    binary=p/f'{config}_{fixture[:-4]}';cmd=['taskset','-c','8',compiler,*extra,'-std=c++23','-O1'if san else'-O2']+(['-DSKIP_RUNTIME_CHECKS']if skip else[])+(['-march=native']if native else[])+(['-g','-fsanitize=address,undefined','-fno-omit-frame-pointer']if san else[])+[f'-DSIRKIT_UNRELEASED_VECTOR_SOURCE="{p.parent/"Unreleased_Vector.cpp"}"',str(p/fixture),'-o',str(binary)];c=subprocess.run(cmd,capture_output=True,text=True);assert c.returncode==0,c.stderr;r=subprocess.run(['taskset','-c','8',str(binary)],capture_output=True,text=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1'));assert r.returncode==0,(r.stdout,r.stderr);rows.append({'config':config,'fixture':fixture,'fixture_sha256':hashlib.sha256((p/fixture).read_bytes()).hexdigest(),'compile_command':cmd,'exit_code':0,'stdout':r.stdout});(p/'final_fixtures_validation.json').write_text(json.dumps(rows,indent=2)+'\n')
   print(config,'2fixtures PASS',flush=True)
