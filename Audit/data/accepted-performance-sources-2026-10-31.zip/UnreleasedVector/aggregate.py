from pathlib import Path
import json,statistics,math,collections
p=Path(__file__).parent;raw=json.loads((p/'raw.json').read_text());groups=collections.defaultdict(list)
for r in raw:groups[r['config'],r['benchmark'],r['kind'],r['size']].append(r)
rows=[]
for key,values in groups.items():
 fields=['process_cpu_ns','process_wall_ns','peak_rss_kib']+(['thread_cpu_ns']if key[1]=='verify'else['build_ns','query_ns','teardown_ns'])
 for metric in fields:
  parts={variant:[r[metric]for r in values if r['variant']==variant]for variant in ['normal','normal_control','buffer','buffer_control','unreleased']};medians={v:statistics.median(n)for v,n in parts.items()};cv={}
  for baseline in ['normal','buffer']:
   pool=parts[baseline]+parts[baseline+'_control'];cv[baseline]=statistics.stdev(pool)/statistics.mean(pool)if statistics.mean(pool)else 0
  rows.append({'config':key[0],'benchmark':key[1],'kind':key[2],'size':key[3],'metric':metric,'medians':medians,'unreleased_over_buffer':medians['unreleased']/medians['buffer']if medians['buffer']else 0,'unreleased_over_normal':medians['unreleased']/medians['normal']if medians['normal']else 0,'buffer_control_ratio':medians['buffer_control']/medians['buffer']if medians['buffer']else 0,'normal_control_ratio':medians['normal_control']/medians['normal']if medians['normal']else 0,'control_cv':cv,'rss_python_floor_confounded':metric=='peak_rss_kib'and min(medians.values())<36*1024})
summary=[]
for benchmark in ['verify','api']:
 for kind in sorted({r['kind']for r in rows if r['benchmark']==benchmark}):
  for metric in ['process_cpu_ns','process_wall_ns','thread_cpu_ns'if benchmark=='verify'else'build_ns']:
   chosen=[r for r in rows if r['benchmark']==benchmark and r['kind']==kind and r['metric']==metric]
   summary.append({'benchmark':benchmark,'kind':kind,'metric':metric,'cases':len(chosen),'unreleased_over_buffer_geomean':math.exp(statistics.mean(math.log(r['unreleased_over_buffer'])for r in chosen)),'unreleased_over_buffer_min':min(r['unreleased_over_buffer']for r in chosen),'unreleased_over_buffer_max':max(r['unreleased_over_buffer']for r in chosen),'unreleased_over_normal_geomean':math.exp(statistics.mean(math.log(r['unreleased_over_normal'])for r in chosen)),'max_buffer_control_cv':max(r['control_cv']['buffer']for r in chosen),'max_buffer_control_median_ratio':max(r['buffer_control_ratio']for r in chosen),'min_buffer_control_median_ratio':min(r['buffer_control_ratio']for r in chosen)})
(p/'aggregate.json').write_text(json.dumps({'records':len(raw),'rows':rows,'summary':summary,'rss_limitation':'Python pre-exec fork memory creates roughly21–33MiB RSS floor as the parent log grows. RSS below36MiB is marked confounded; no conclusions drawn there. Larger observations abovefloor can be compared.'},indent=2)+'\n')
for r in summary:
 if r['metric']=='process_cpu_ns':print(json.dumps(r),flush=True)
print('DETAIL LARGE CPU/BUILD/RSS',flush=True)
for r in rows:
 if r['size']=='large'and r['metric']in['process_cpu_ns','build_ns','peak_rss_kib']:print(r['config'],r['benchmark'],r['kind'],r['metric'],'ratio',round(r['unreleased_over_buffer'],3),'normal',round(r['unreleased_over_normal'],3),'control',round(r['buffer_control_ratio'],3),'cv',round(r['control_cv']['buffer'],3),'base',r['medians']['buffer'],'candidate',r['medians']['unreleased'],'floor',r['rss_python_floor_confounded'],flush=True)
