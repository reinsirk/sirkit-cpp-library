from pathlib import Path
import subprocess,json,hashlib
p=Path(__file__).parent;file=p/'binaries.json';rows=json.loads(file.read_text());mapping=[('sam','String/Suffix_Automaton.cpp'),('pal','String/Palindromic_Tree.cpp'),('aho','String/Aho_Corasick.cpp'),('treap','DataStructure/implicit_treap.cpp')]
for row in rows:
 if row['variant'].endswith('control'):continue
 cc,native=row['config'].split('_');compiler='/usr/bin/g++'if cc=='gcc'else'/usr/bin/clang++';extra=[]if cc=='gcc'else['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'];flags=['-std=c++23','-O2',*extra]+(['-march=native']if native=='native'else[])
 for index,(kind,key)in enumerate(mapping):
  binary=Path(row['api'][kind]);cmd=['taskset','-c','8',compiler,*flags,'-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_BENCH_KIND={index}',f'-DLIBRARY_SOURCE="{p/row["variant"]/key}"',str(p/'growth_benchmark.cpp'),'-o',str(binary)];c=subprocess.run(cmd,capture_output=True,text=True);assert c.returncode==0,c.stderr
 row['growth_source_sha256']=hashlib.sha256((p/'growth_benchmark.cpp').read_bytes()).hexdigest();print('rebuilt API',row['config'],row['variant'],flush=True)
for row in rows:
 if row['variant'].endswith('control'):row['growth_source_sha256']=hashlib.sha256((p/'growth_benchmark.cpp').read_bytes()).hexdigest()
file.write_text(json.dumps(rows,indent=2)+'\n')
