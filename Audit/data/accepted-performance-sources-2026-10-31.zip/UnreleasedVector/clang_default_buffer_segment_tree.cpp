#define SKIP_RUNTIME_CHECKS
// Verify: https://judge.yosupo.jp/problem/point_add_range_sum

// Library: DataStructure/Segment_Tree.cpp
// SPDX-License-Identifier: CC0-1.0
// 参考（モノイドと区間積）: https://info.atcoder.jp/entry/algorithm_lectures/range_query_monoid_design
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/segment_tree.md
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/fast_variants.md
//
// API一覧
// 速度優先版: 内部の主要領域は破棄・解放しない。格納型のデストラクタの副作用を必要としないこと。
// 入力・容量・件数の前提と確保成功を利用側が保証する。例外時の状態復元は保証しない。
// [SegmentTree<T, Op=std::plus<T>>]
// SegmentTree(n=0, identity=T{}, op=Op{})/SegmentTree(vector<T>,identity=T{},op=Op{}): 単位元の列/列から構築。O(n+1)時間・領域。
// Op(a,b)はconst呼出可能かつ結合的、identityは左右の単位元。非可換演算も可。演算/コピーをO(1)とし、添字0始まり・区間は半開。
// size()/empty(): 要素数/空か、O(1)。get(i): const T&（T=boolは値）を返す、O(1)。参照は変更・再構築・移動で無効になり得る。
// set(i,value)/transform(i,f): 1点をvalue/f(現在値)へ更新。O(log(n+1))。prod(l,r): [l,r)を左から積算、O(log(n+1))。
// all_prod(): 全体の積へのconst T&（T=boolは値）。O(1)。空区間のprodと空列の全積はidentity。
// max_right(l,pred)/min_left(r,pred): predが真の最大の右端/最小の左端、O(log(n+1))。pred(identity)==trueと境界の単調性が前提。
// values(): 列のコピー、O(n+1)。assign(vector<T>)/reset(n)/reset(): 列を再構築/n要素/現在の長さを単位元にする。O(旧n+n+1)。
// clear()/swap(other): 空にして容量保持/内容交換。O(旧n+1)/O(1)。コピーは独立、移動元は空。演算・値のコピー等が投げた場合、内容の強い保証はしない。

#include <algorithm>
#include <cstddef>
#include <iterator>
#include <limits>
#include <memory>
#include <type_traits>
#include <utility>
#include <vector>

#ifndef SIRKIT_FAST_BUFFER_DEFINED
#define SIRKIT_FAST_BUFFER_DEFINED
namespace reinsirk::detail {
template <class T>
class FastBuffer {
    T* data_ = nullptr;
    std::size_t size_ = 0, capacity_ = 0;
    void grow() {
        const auto limit = max_size();
        reserve(capacity_ == 0 ? 1 : capacity_ > limit - capacity_ ? limit : capacity_ * 2);
    }
public:
    using value_type = T;
    using size_type = std::size_t;
    using iterator = T*;
    using const_iterator = const T*;
    using reference = T&;
    using const_reference = const T&;
    FastBuffer() noexcept = default;
    explicit FastBuffer(std::size_t count) {
        reserve(count);
        for (; size_ < count; ++size_) std::construct_at(data_ + size_);
    }
    FastBuffer(std::size_t count, const T& value) {
        reserve(count);
        for (; size_ < count; ++size_) std::construct_at(data_ + size_, value);
    }
    template <std::input_iterator Iterator>
    FastBuffer(Iterator first, Iterator last) {
        if (first == last) return;
        if constexpr (std::forward_iterator<Iterator>) reserve(static_cast<std::size_t>(std::distance(first, last)));
        for (; first != last; ++first) emplace_back(*first);
    }
    FastBuffer(const std::vector<T>& values) : FastBuffer(values.begin(), values.end()) {}
    FastBuffer(const FastBuffer& other) : FastBuffer(other.begin(), other.end()) {}
    FastBuffer& operator=(const FastBuffer& other) {
        if (this != &other) { FastBuffer next(other); swap(next); }
        return *this;
    }
    FastBuffer(FastBuffer&& other) noexcept
        : data_(std::exchange(other.data_, nullptr)), size_(std::exchange(other.size_, 0)),
          capacity_(std::exchange(other.capacity_, 0)) {}
    FastBuffer& operator=(FastBuffer&& other) noexcept {
        if (this != &other) {
            data_ = std::exchange(other.data_, nullptr);
            size_ = std::exchange(other.size_, 0); capacity_ = std::exchange(other.capacity_, 0);
        }
        return *this;
    }
    // デストラクタは、格納値の破棄もdeallocateも行わない。
    ~FastBuffer() = default;
    std::size_t size() const noexcept { return size_; }
    std::size_t capacity() const noexcept { return capacity_; }
    bool empty() const noexcept { return size_ == 0; }
    static constexpr std::size_t max_size() noexcept {
        return static_cast<std::size_t>(std::numeric_limits<std::ptrdiff_t>::max()) / sizeof(T);
    }
    T* data() noexcept { return data_; }
    const T* data() const noexcept { return data_; }
    T* begin() noexcept { return data_; }
    const T* begin() const noexcept { return data_; }
    T* end() noexcept { return size_ == 0 ? data_ : data_ + size_; }
    const T* end() const noexcept { return size_ == 0 ? data_ : data_ + size_; }
    const T* cbegin() const noexcept { return begin(); }
    const T* cend() const noexcept { return end(); }
    T& operator[](std::size_t index) noexcept { return data_[index]; }
    const T& operator[](std::size_t index) const noexcept { return data_[index]; }
    T& front() noexcept { return data_[0]; }
    const T& front() const noexcept { return data_[0]; }
    T& back() noexcept { return data_[size_ - 1]; }
    const T& back() const noexcept { return data_[size_ - 1]; }
    void reserve(std::size_t count) {
        if (count <= capacity_) return;
        // allocator::allocateはT配列の領域を開始する。要素は使用時だけ構築する。
        T* next = std::allocator<T>{}.allocate(count);
        for (std::size_t i = 0; i < size_; ++i)
            std::construct_at(next + i, std::move_if_noexcept(data_[i]));
        data_ = next; capacity_ = count;
    }
    template <class... Args>
    T& emplace_back(Args&&... args) {
        if (size_ == capacity_) {
            // 引数が自身の要素を参照していても、移動する前に新要素を作る。
            T value(std::forward<Args>(args)...);
            grow();
            T* added = std::construct_at(data_ + size_, std::move_if_noexcept(value));
            ++size_;
            return *added;
        }
        T* added = std::construct_at(data_ + size_, std::forward<Args>(args)...);
        ++size_;
        return *added;
    }
    void push_back(const T& value) { emplace_back(value); }
    void push_back(T&& value) { emplace_back(std::move(value)); }
    void pop_back() noexcept { --size_; }
    void clear() noexcept { size_ = 0; }
    void resize(std::size_t count) {
        if (count < size_) { size_ = count; return; }
        reserve(count);
        for (; size_ < count; ++size_) std::construct_at(data_ + size_);
    }
    void resize(std::size_t count, const T& value) {
        if (count < size_) { size_ = count; return; }
        if (count > capacity_) { T copy(value); reserve(count); resize(count, copy); return; }
        for (; size_ < count; ++size_) std::construct_at(data_ + size_, value);
    }
    void assign(std::size_t count, const T& value) { FastBuffer next(count, value); swap(next); }
    template <std::input_iterator Iterator>
    void assign(Iterator first, Iterator last) { FastBuffer next(first, last); swap(next); }
    void swap(FastBuffer& other) noexcept {
        std::swap(data_, other.data_); std::swap(size_, other.size_); std::swap(capacity_, other.capacity_);
    }
    friend void swap(FastBuffer& a, FastBuffer& b) noexcept { a.swap(b); }
};
}
#endif

#include <algorithm>
#include <cstddef>
#include <functional>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

#ifndef SIRKIT_SEGMENT_TREE_DEFINED
#define SIRKIT_SEGMENT_TREE_DEFINED
template<class T, class Op = std::plus<T>>
class SegmentTree {
    [[no_unique_address]] Op op_;
    T identity_;
    std::size_t n_ = 0, base_ = 1;
    reinsirk::detail::FastBuffer<T> data_;
    static std::size_t leaf_base(std::size_t n) {
        if (n == 0) return 1;
        const auto limit = std::vector<T>{}.max_size() / 2;
        std::size_t base = 1;
        while (base < n) {
            if (base > limit / 2) throw std::length_error("SegmentTree: size");
            base *= 2;
        }
        if (base > limit) throw std::length_error("SegmentTree: size");
        return base;
    }
    void check_index(std::size_t i) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (i >= n_) throw std::out_of_range("SegmentTree: index");
#else
        (void)i;
#endif
    }
    void check_range(std::size_t l, std::size_t r) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (l > r || r > n_) throw std::out_of_range("SegmentTree: range");
#else
        (void)l; (void)r;
#endif
    }
    void rebuild() {
        for (auto p = base_; p > 1;) {
            --p;
            data_[p] = op_(data_[2 * p], data_[2 * p + 1]);
        }
    }
    void update_ancestors(std::size_t p) {
        for (p >>= 1; p; p >>= 1) data_[p] = op_(data_[2 * p], data_[2 * p + 1]);
    }
public:
    using const_reference = typename std::vector<T>::const_reference;
    explicit SegmentTree(std::size_t n = 0, const T& identity = T{}, Op op = Op{})
        : op_(std::move(op)), identity_(identity), n_(n), base_(leaf_base(n)),
          data_(n ? 2 * base_ : 0, identity_) {}
    explicit SegmentTree(const std::vector<T>& values, const T& identity = T{}, Op op = Op{})
        : SegmentTree(values.size(), identity, std::move(op)) {
        if (!n_) return;
        std::copy(values.begin(), values.end(), data_.begin() + base_);
        rebuild();
    }
    SegmentTree(const SegmentTree&) = default;
    SegmentTree& operator=(const SegmentTree& other) {
        if (this != &other) { SegmentTree replacement(other); swap(replacement); }
        return *this;
    }
    SegmentTree(SegmentTree&& other)
        : op_(other.op_), identity_(other.identity_), n_(other.n_), base_(other.base_), data_(std::move(other.data_)) {
        other.n_ = 0; other.base_ = 1; other.data_.clear();
    }
    SegmentTree& operator=(SegmentTree&& other) {
        if (this != &other) { SegmentTree replacement(std::move(other)); swap(replacement); }
        return *this;
    }
    std::size_t size() const noexcept { return n_; }
    bool empty() const noexcept { return n_ == 0; }
    const_reference get(std::size_t i) const { check_index(i); return data_[base_ + i]; }
    void set(std::size_t i, const T& value) {
        check_index(i);
        const auto p = base_ + i;
        data_[p] = value;
        update_ancestors(p);
    }
    template<class F> void transform(std::size_t i, F&& f) {
        check_index(i);
        const auto p = base_ + i;
        data_[p] = std::invoke(std::forward<F>(f), std::as_const(data_)[p]);
        update_ancestors(p);
    }
    T prod(std::size_t l, std::size_t r) const {
        check_range(l, r);
        T left = identity_, right = identity_;
        if (l == r) return left;
        for (l += base_, r += base_; l < r; l >>= 1, r >>= 1) {
            if (l & 1) left = op_(left, data_[l++]);
            if (r & 1) right = op_(data_[--r], right);
        }
        return op_(left, right);
    }
    const_reference all_prod() const noexcept { return n_ ? data_[1] : identity_; }
    template<class Pred> std::size_t max_right(std::size_t l, Pred pred) const {
        check_range(l, l);
#ifndef SKIP_RUNTIME_CHECKS
        if (!pred(identity_)) throw std::invalid_argument("SegmentTree: predicate(identity)");
#endif
        if (l == n_) return n_;
        T accumulated = identity_;
        auto node = base_ + l;
        while (true) {
            while (!(node & 1)) node >>= 1;
            T candidate = op_(accumulated, data_[node]);
            if (!pred(candidate)) {
                while (node < base_) {
                    node *= 2;
                    T next = op_(accumulated, data_[node]);
                    if (pred(next)) { accumulated = std::move(next); ++node; }
                }
                return std::min(n_, node - base_);
            }
            accumulated = std::move(candidate);
            ++node;
            if ((node & (node - 1)) == 0) return n_;
        }
    }
    template<class Pred> std::size_t min_left(std::size_t r, Pred pred) const {
        check_range(r, r);
#ifndef SKIP_RUNTIME_CHECKS
        if (!pred(identity_)) throw std::invalid_argument("SegmentTree: predicate(identity)");
#endif
        if (r == 0) return 0;
        T accumulated = identity_;
        auto node = base_ + r;
        while (true) {
            --node;
            while (node > 1 && (node & 1)) node >>= 1;
            T candidate = op_(data_[node], accumulated);
            if (!pred(candidate)) {
                while (node < base_) {
                    node = 2 * node + 1;
                    T next = op_(data_[node], accumulated);
                    if (pred(next)) { accumulated = std::move(next); --node; }
                }
                return node + 1 - base_;
            }
            accumulated = std::move(candidate);
            if ((node & (node - 1)) == 0) return 0;
        }
    }
    std::vector<T> values() const {
        if (!n_) return {};
        return std::vector<T>(data_.begin() + base_, data_.begin() + base_ + n_);
    }
    void assign(const std::vector<T>& values) {
        SegmentTree replacement(values, identity_, op_); swap(replacement);
    }
    void reset(std::size_t n) {
        SegmentTree replacement(n, identity_, op_); swap(replacement);
    }
    void reset() { std::fill(data_.begin(), data_.end(), identity_); }
    void clear() noexcept { data_.clear(); n_ = 0; base_ = 1; }
    void swap(SegmentTree& other) noexcept(std::is_nothrow_swappable_v<Op> && std::is_nothrow_swappable_v<T>) {
        using std::swap;
        swap(op_, other.op_); swap(identity_, other.identity_);
        swap(n_, other.n_); swap(base_, other.base_); data_.swap(other.data_);
    }
};
#endif


// SPDX-License-Identifier: CC0-1.0
// Verify I/O: Verify/current/common/fast_io.hpp
// SPDX-License-Identifier: CC0-1.0
#include <algorithm>
#include <array>
#include <charconv>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <vector>

#ifndef SIRKIT_VERIFY_FAST_IO_DEFINED
#define SIRKIT_VERIFY_FAST_IO_DEFINED

// VerifyInput(file=stdin): 非所有のFILEから読む。別の入力方式と混用しない。
// >> 整数: 64bit以下の十進整数を読む。検査省略時は値域内の正しい入力を前提とする。
// >> char/string: 空白を飛ばし、1文字／空白までの文字列を読む。
// >> 浮動小数点: 十進文字列を変換する。通常のCロケールで使う。
// bool / !: 直前までの読み取りが成功しているか／失敗したかを返す。
class VerifyInput {
    static constexpr std::size_t buffer_size = 1 << 17;
    std::FILE* file_;
    std::array<unsigned char, buffer_size> buffer_;
    std::size_t position_ = 0, size_ = 0;
    bool good_ = true;

    int peek() {
        if (position_ == size_) {
            size_ = std::fread(buffer_.data(), 1, buffer_.size(), file_);
            position_ = 0;
            if (size_ == 0) return EOF;
        }
        return buffer_[position_];
    }

    int skip_space() {
        int c;
        while ((c = peek()) != EOF && c <= ' ') ++position_;
        if (c == EOF) good_ = false;
        return c;
    }

public:
    explicit VerifyInput(std::FILE* file = stdin) : file_(file) {}
    VerifyInput(const VerifyInput&) = delete;
    VerifyInput& operator=(const VerifyInput&) = delete;

    explicit operator bool() const noexcept { return good_; }
    bool operator!() const noexcept { return !good_; }

    template<class T>
        requires (std::is_integral_v<T> && sizeof(T) <= sizeof(std::uint64_t)
                  && !std::is_same_v<T, char>)
    VerifyInput& operator>>(T& result) {
        if (!good_) return *this;
        int c = skip_space();
        if (c == EOF) return *this;
        bool negative = false;
        if (c == '-' || c == '+') {
            negative = c == '-';
            ++position_;
            c = peek();
        }
        if (c == EOF) {
            good_ = false;
            return *this;
        }
#ifndef SKIP_RUNTIME_CHECKS
        if (c < '0' || c > '9') {
            good_ = false;
            return *this;
        }
        // 先頭の0を除けば、20桁以下の末尾直前の値はuint64_tに収まる。
        while (c == '0') {
            ++position_;
            c = peek();
        }
        std::uint64_t previous = 0;
        unsigned last_digit = 0;
        std::size_t digits = 0;
#endif
        std::uint64_t value = 0;
        while (c >= '0' && c <= '9') {
#ifndef SKIP_RUNTIME_CHECKS
            previous = value;
            last_digit = static_cast<unsigned>(c - '0');
            if (digits <= 20) ++digits;
#endif
            value = value * 10 + static_cast<unsigned>(c - '0');
            ++position_;
            c = peek();
        }
#ifndef SKIP_RUNTIME_CHECKS
        constexpr auto maximum = std::numeric_limits<std::uint64_t>::max();
        if ((c != EOF && c > ' ') || digits > 20
            || (digits == 20 && (previous > maximum / 10
                || (previous == maximum / 10 && last_digit > maximum % 10)))) {
            good_ = false;
            return *this;
        }
        std::uint64_t limit = static_cast<std::uint64_t>(std::numeric_limits<T>::max());
        if constexpr (std::is_signed_v<T>) limit += negative;
        else if (negative && value != 0) good_ = false;
        if (value > limit) good_ = false;
        if (!good_) return *this;
#endif
        if constexpr (std::is_signed_v<T>) {
            constexpr std::uint64_t minimum_magnitude =
                static_cast<std::uint64_t>(std::numeric_limits<T>::max()) + 1;
            // -(最小値)は評価せず、絶対値が最大値+1のときだけ最小値を使う。
            result = negative
                ? (value == minimum_magnitude ? std::numeric_limits<T>::min()
                                  : static_cast<T>(-static_cast<T>(value)))
                : static_cast<T>(value);
        } else result = static_cast<T>(value);
        return *this;
    }

    VerifyInput& operator>>(char& result) {
        if (!good_) return *this;
        const int c = skip_space();
        if (c != EOF) {
            result = static_cast<char>(c);
            ++position_;
        }
        return *this;
    }

    VerifyInput& operator>>(std::string& result) {
        if (!good_) return *this;
        int c = skip_space();
        if (c == EOF) return *this;
        result.clear();
        do {
            result.push_back(static_cast<char>(c));
            ++position_;
            c = peek();
        } while (c != EOF && c > ' ');
        return *this;
    }

    template<class T> requires std::is_floating_point_v<T>
    VerifyInput& operator>>(T& result) {
        std::string token;
        *this >> token;
        if (!good_) return *this;
#ifndef SKIP_RUNTIME_CHECKS
        char* end = nullptr;
        const long double value = std::strtold(token.c_str(), &end);
        if (end != token.c_str() + token.size()) good_ = false;
        else result = static_cast<T>(value);
#else
        result = static_cast<T>(std::strtold(token.c_str(), nullptr));
#endif
        return *this;
    }
};

// VerifyOutput(file=stdout): 非所有のFILEへ書く。破棄時にflushし、FILEは閉じない。
// << 整数/char/文字列/浮動小数点: 値を出力する。整数は64bit以下に対応する。
// fixed(digits): 浮動小数点を小数点以下digits桁で出力する（digits>=0）。
// flush(): バッファの内容をFILEへ渡す。bool / !で書き込み失敗を確認できる。
class VerifyOutput {
    static constexpr std::size_t buffer_size = 1 << 17;
    std::FILE* file_;
    std::array<char, buffer_size> buffer_;
    std::size_t size_ = 0;
    int precision_ = 6;
    bool fixed_ = false, good_ = true;

    void write(std::string_view text) {
        while (!text.empty() && good_) {
            if (size_ == buffer_.size()) flush();
            const auto count = std::min(text.size(), buffer_.size() - size_);
            std::memcpy(buffer_.data() + size_, text.data(), count);
            size_ += count;
            text.remove_prefix(count);
        }
    }

public:
    explicit VerifyOutput(std::FILE* file = stdout) : file_(file) {}
    VerifyOutput(const VerifyOutput&) = delete;
    VerifyOutput& operator=(const VerifyOutput&) = delete;
    ~VerifyOutput() { flush(); }

    explicit operator bool() const noexcept { return good_; }
    bool operator!() const noexcept { return !good_; }

    VerifyOutput& fixed(int digits) {
        if (digits < 0) throw std::invalid_argument("negative output precision");
        fixed_ = true;
        precision_ = digits;
        return *this;
    }

    void flush() noexcept {
        std::size_t written = 0;
        while (written < size_ && good_) {
            const auto count = std::fwrite(buffer_.data() + written, 1, size_ - written, file_);
            if (count == 0) good_ = false;
            written += count;
        }
        size_ = 0;
    }

    template<class T>
        requires (std::is_integral_v<T> && sizeof(T) <= sizeof(std::uint64_t)
                  && !std::is_same_v<T, char>)
    VerifyOutput& operator<<(T value) {
        if constexpr (std::is_same_v<T, bool>) return *this << static_cast<char>('0' + value);
        else {
            char digits[std::numeric_limits<std::uint64_t>::digits10 + 3];
            const auto end = std::to_chars(digits, digits + sizeof(digits), value).ptr;
            write(std::string_view(digits, static_cast<std::size_t>(end - digits)));
            return *this;
        }
    }

    VerifyOutput& operator<<(char value) {
        if (size_ == buffer_.size()) flush();
        if (good_) buffer_[size_++] = value;
        return *this;
    }

    VerifyOutput& operator<<(std::string_view value) { write(value); return *this; }
    VerifyOutput& operator<<(const std::string& value) { write(value); return *this; }
    VerifyOutput& operator<<(const char* value) { write(value); return *this; }

    template<class T> requires std::is_floating_point_v<T>
    VerifyOutput& operator<<(T value) {
        char local[128];
        const char* format = fixed_ ? "%.*Lf" : "%.*Lg";
        const int count = std::snprintf(local, sizeof(local), format, precision_,
                                        static_cast<long double>(value));
        if (count < 0) good_ = false;
        else if (static_cast<std::size_t>(count) < sizeof(local))
            write(std::string_view(local, static_cast<std::size_t>(count)));
        else {
            std::vector<char> text(static_cast<std::size_t>(count) + 1);
            std::snprintf(text.data(), text.size(), format, precision_, static_cast<long double>(value));
            write(std::string_view(text.data(), static_cast<std::size_t>(count)));
        }
        return *this;
    }
};

inline VerifyInput verify_in;
inline VerifyOutput verify_out;
#endif

#include <cstdint>
#include <vector>
#include <ctime>
#include <cstdio>
#include <cstdint>
#include <cinttypes>
struct BenchmarkTimer {timespec start{};BenchmarkTimer(){clock_gettime(CLOCK_THREAD_CPUTIME_ID,&start);}~BenchmarkTimer(){timespec end{};clock_gettime(CLOCK_THREAD_CPUTIME_ID,&end);const auto ns=(static_cast<std::int64_t>(end.tv_sec)-start.tv_sec)*1000000000+end.tv_nsec-start.tv_nsec;std::fprintf(stderr,"THREAD_NS=%" PRId64 "\n",ns);}};
BenchmarkTimer benchmark_timer;
int main() {
    int n{}, q{}; verify_in >> n >> q;
    std::vector<std::int64_t> a(n);
    for (auto& x : a) verify_in >> x;
    SegmentTree<std::int64_t> tree(a);
    while (q--) {
        int type{}, p{}; std::int64_t x{}; verify_in >> type >> p >> x;
        if (type == 0) tree.transform(p, [&](auto value) { return value + x; });
        else verify_out << tree.prod(p, static_cast<std::size_t>(x)) << '\n';
    }
}
