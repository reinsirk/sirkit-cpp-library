from pathlib import Path
import subprocess,json,time,os,random,hashlib,re,argparse
p=Path(__file__).parent;parser=argparse.ArgumentParser();parser.add_argument('--config');parser.add_argument('--repeats',type=int,default=3);parser.add_argument('--output',default='raw');args=parser.parse_args()
rows=json.loads((p/'binaries.json').read_text());rows=[r for r in rows if not args.config or r['config']==args.config];inputs=json.loads((p/'inputs.json').read_text());rawfile=p/(args.output+'.jsonl');records=[];expected={};rng=random.Random(735119)
api_cases=[]
for kind in ['sam','pal','aho','treap']:
 api_cases.append({'kind':kind,'n':1000,'cycles':20,'reserve':0,'size':'small'})
 api_cases.append({'kind':kind,'n':50000 if kind=='aho'else 100000 if kind=='treap'else 500000,'cycles':1,'reserve':0,'size':'large'})
stdout=p/'measurement_stdout.tmp';stderr=p/'measurement_stderr.tmp';empty=p/'empty_input.tmp';empty.write_bytes(b'')
with rawfile.open('w',buffering=1)as log:
 for repeat in range(args.repeats):
  work=[(row,'verify',info)for row in rows for info in inputs]+[(row,'api',info)for row in rows for info in api_cases];rng.shuffle(work)
  for row,benchmark,info in work:
   binary=row[benchmark][info['kind']];cmd=['taskset','-c','12',binary]+([str(info['n']),str(info['cycles']),str(info['reserve'])]if benchmark=='api'else[])
   with Path(info['input']if benchmark=='verify'else empty).open('rb')as inp,stdout.open('wb')as out,stderr.open('wb')as err:
    start=time.perf_counter_ns();child=subprocess.Popen(cmd,stdin=inp,stdout=out,stderr=err);pid,status,usage=os.wait4(child.pid,0);elapsed=time.perf_counter_ns()-start;child.returncode=os.waitstatus_to_exitcode(status)
   assert child.returncode==0,(cmd,stderr.read_text());record={'config':row['config'],'variant':row['variant'],'bundle_sha256':row['bundle_sha256'],'binary':binary,'benchmark':benchmark,'repeat':repeat,**info,'process_cpu_ns':round((usage.ru_utime+usage.ru_stime)*1e9),'process_wall_ns':elapsed,'peak_rss_kib':usage.ru_maxrss}
   if benchmark=='verify':
    digest=hashlib.sha256(stdout.read_bytes()).hexdigest();key=(benchmark,info['kind'],info['size']);record['output_sha256']=digest;record['thread_cpu_ns']=int(re.search(r'THREAD_NS=(\d+)',stderr.read_text()).group(1));expected.setdefault(key,digest);assert expected[key]==digest,record
   else:
    result=json.loads(stdout.read_text());key=(benchmark,info['kind'],info['size']);record.update(result);expected.setdefault(key,result['hash']);assert expected[key]==result['hash'],record
   records.append(record);log.write(json.dumps(record)+'\n')
   if len(records)%120==0:print('raw records',len(records),flush=True)
(p/(args.output+'.json')).write_text(json.dumps(records,indent=2)+'\n');print('RAW COMPLETE CPU12 RELEASE',len(records),flush=True)
