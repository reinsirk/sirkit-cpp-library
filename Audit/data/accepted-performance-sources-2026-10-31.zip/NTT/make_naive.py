from pathlib import Path
import hashlib
D=Path(__file__).parent;s=(D/'avx2_tile8_roots_lazy.hpp').read_text()
helper=r'''
    template<bool Check>
    [[gnu::target("avx2")]]
    static std::vector<std::uint32_t> naive_avx2(std::vector<std::uint32_t>& a,std::vector<std::uint32_t>& b,std::size_t output) {
        if(a.size()>b.size())a.swap(b);
        std::vector<std::uint32_t> result(output);
        for(std::size_t i=0;i<a.size();++i) {
#ifndef SKIP_RUNTIME_CHECKS
            if constexpr(Check)if(a[i]>=Mod)throw std::invalid_argument("NTT: coefficient not normalized");
#endif
            const auto coefficient=_mm256_set1_epi32(static_cast<int>(encode(a[i])));
            std::size_t j=0;
            for(;j+8<=b.size();j+=8) {
                const auto input=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(b.data()+j));
#ifndef SKIP_RUNTIME_CHECKS
                if constexpr(Check)if(i==0)vector_check(input);
#endif
                const auto old=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(result.data()+i+j));
                const auto product=vector_reduce(vector_multiply(coefficient,input));
                const auto sum=vector_reduce(_mm256_add_epi32(old,product));
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(result.data()+i+j),sum);
            }
            for(;j<b.size();++j) {
#ifndef SKIP_RUNTIME_CHECKS
                if constexpr(Check)if(i==0&&b[j]>=Mod)throw std::invalid_argument("NTT: coefficient not normalized");
#endif
                result[i+j]=add(result[i+j],multiply(a[i],b[j]));
            }
        }
        return result;
    }
'''
needle='    template<bool Check>\n    [[gnu::target("avx2")]]\n    void forward_avx2'
assert needle in s;s=s.replace(needle,helper+needle,1)
needle='        if (std::min(a.size(), b.size()) <= 32) {\n'
replacement=needle+'''#if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__))
            if(use_avx2(output))return naive_avx2<Check>(a,b,output);
#endif
'''
assert needle in s;s=s.replace(needle,replacement,1)
(D/'avx2_tile8_roots_lazy_naive.hpp').write_text(s);print(hashlib.sha256(s.encode()).hexdigest(),len(s))
