from pathlib import Path
import os,subprocess,json,hashlib
D=Path(__file__).parent;OUT=D/'threshold_checks';OUT.mkdir(exist_ok=True);os.setsid();(OUT/'runner.pid').write_text(str(os.getpid()));os.sched_setaffinity(0,{4});rows=[]
source=(D/'avx2_tile8_roots_lazy_naive.hpp').read_text()
for n in [16,32,64,128]:
 header=D/f'threshold{n}.hpp';header.write_text(source.replace('n>=256','n>='+str(n)))
 for mode,compiler in {'gcc-default':['/usr/bin/g++'],'gcc-native':['/usr/bin/g++','-march=native'],'clang-default':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'],'clang-native':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-march=native']}.items():
  for fixture in ['final_reference_test','bench']:
   target=(D/'bench'/f'{mode}-threshold{n}') if fixture=='bench'else OUT/f'threshold{n}-{mode}'
   cmd=compiler+['-std=c++23','-O2','-Wall','-Wextra','-Wpedantic','-Werror']+(['-DSKIP_RUNTIME_CHECKS']if fixture=='bench'else[])+[f'-DNTT_HEADER="{header}"',str(D/(fixture+'.cpp')),'-o',str(target)]
   a=subprocess.run(cmd,capture_output=True,text=True);row=dict(threshold=n,mode=mode,fixture=fixture,sha256=hashlib.sha256(header.read_bytes()).hexdigest(),command=cmd,compile_exit=a.returncode,compile_stderr=a.stderr)
   if a.returncode==0 and fixture!='bench':
    b=subprocess.run([str(target)],capture_output=True,text=True);row.update(run_exit=b.returncode,stdout=b.stdout,stderr=b.stderr,passed=b.returncode==0)
   elif a.returncode==0:row['passed']=True
   rows.append(row);(OUT/'results.json').write_text(json.dumps(rows,indent=2));print(n,mode,fixture,row.get('passed'),flush=True);assert row.get('passed')and not a.stderr and not row.get('stderr'),row
print('16 boundary configs / 16 bench ready',flush=True)
