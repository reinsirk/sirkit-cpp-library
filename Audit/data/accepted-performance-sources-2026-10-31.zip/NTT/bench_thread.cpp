// SPDX-License-Identifier: CC0-1.0
#ifndef NTT_HEADER
#error NTT_HEADER required
#endif
#include NTT_HEADER
#include <chrono>
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <random>
#include <string>
namespace {
constexpr std::uint32_t mod=998244353;
volatile std::uint64_t sink=0;
void consume(const std::vector<std::uint32_t>& a){std::uint64_t x=a.size();for(std::size_t i=0;i<8&&!a.empty();++i)x=x*1000000007+a[(i*137+1)%a.size()];sink=x;}
struct Case {const char*name;std::size_t n,m;int repetitions;};
const Case cases[]={
 {"generic",0,0,2000},{"generic",1,1,10000},{"generic",16,16,3000},{"generic",32,32,1000},{"generic",33,33,1000},
 {"generic",128,128,300},{"generic",1024,1024,100},{"generic",65536,65536,3},{"generic",524288,524288,1},
 {"generic",262144,1,10},{"generic",262144,32,1},{"generic",262144,33,1},{"generic",262144,1024,1},
 {"normalized",33,33,1000},{"normalized",1024,1024,100},{"normalized",65536,65536,3},{"normalized",524288,524288,1},
 {"square",32,0,1000},{"square",33,0,1000},{"square",1024,0,100},{"square",65536,0,3},{"square",524288,0,1},
 {"roundtrip",128,0,500},{"roundtrip",256,0,300},{"roundtrip",1024,0,100},{"roundtrip",131072,0,3},{"roundtrip",1048576,0,1},
 {"cold",1024,1024,50},{"cold",65536,65536,3},{"cold",524288,524288,1},
 {"prepare",1024,0,200},{"prepare",1048576,0,1},{"cachehit",1048576,0,200000},
 {"normalized_move",33,33,1000},{"normalized_move",1024,1024,100},{"normalized_move",65536,65536,3},{"normalized_move",524288,524288,1},
 {"forward",128,0,500},{"forward",1024,0,100},{"forward",1048576,0,1},
 {"inverse",128,0,500},{"inverse",1024,0,100},{"inverse",1048576,0,1},
 {"samealias",65536,0,3},{"samealias",524288,0,1},
{"forward",16,0,1000},{"forward",32,0,1000},{"forward",64,0,1000},{"forward",256,0,1000},{"inverse",16,0,1000},{"inverse",32,0,1000},{"inverse",64,0,1000},{"inverse",256,0,1000},{"roundtrip",16,0,1000},{"roundtrip",32,0,1000},{"roundtrip",64,0,1000},{"roundtrip",256,0,1000},
{"generic",17,17,3000}
};
}
int main(int argc,char**argv){
 if(argc!=2)return 2;
 const auto index=static_cast<std::size_t>(std::strtoull(argv[1],nullptr,10));if(index>=std::size(cases))return 2;
 const auto c=cases[index];
 std::mt19937_64 rng(0x59202cab1234ULL);std::vector<std::uint32_t>a(c.n),b(c.m);for(auto&v:a)v=static_cast<std::uint32_t>(rng()%mod);for(auto&v:b)v=static_cast<std::uint32_t>(rng()%mod);
 NTT<>engine;const auto operation=std::string(c.name);
 if(c.n>32&&operation!="cold"&&operation!="prepare")engine.prepare(std::bit_ceil(operation=="roundtrip"||operation=="forward"||operation=="inverse"||operation=="cachehit"?c.n:operation=="square"||operation=="samealias"?2*c.n-1:c.n+c.m-1));
 std::vector<std::vector<std::uint32_t>> first,second;
 if(operation=="inverse")engine.transform(a);
 if(operation=="normalized_move"||operation=="forward"||operation=="inverse"){
  first.assign(c.repetitions,a);if(operation=="normalized_move")second.assign(c.repetitions,b);
 }
 if(operation=="forward"||operation=="roundtrip")engine.prepare(c.n);
 timespec cpu_start{},cpu_stop{};
 if(::clock_gettime(CLOCK_THREAD_CPUTIME_ID,&cpu_start)!=0)return 3;
 const auto start=std::chrono::steady_clock::now();
 for(int repeat=0;repeat<c.repetitions;++repeat){
  if(operation=="generic")consume(engine.convolution(a,b));
  else if(operation=="normalized")consume(engine.convolution_normalized(a,b));
  else if(operation=="normalized_move")consume(engine.convolution_normalized(std::move(first[repeat]),std::move(second[repeat])));
  else if(operation=="forward"){engine.transform(first[repeat]);consume(first[repeat]);}
  else if(operation=="inverse"){engine.transform(first[repeat],true);consume(first[repeat]);}
  else if(operation=="square")consume(engine.square(a));
  else if(operation=="samealias")consume(engine.convolution(a,a));
  else if(operation=="roundtrip"){engine.transform(a);engine.transform(a,true);consume(a);}
  else if(operation=="cold"){NTT<>fresh;consume(fresh.convolution(a,b));}
  else if(operation=="prepare"){engine.clear_cache();engine.prepare(c.n);sink=engine.roots_capacity();}
  else if(operation=="cachehit"){engine.prepare(c.n);sink=engine.roots_capacity();}
 }
 const auto wall_stop=std::chrono::steady_clock::now();
 if(::clock_gettime(CLOCK_THREAD_CPUTIME_ID,&cpu_stop)!=0)return 3;
 const auto elapsed=std::chrono::duration<double,std::micro>(wall_stop-start).count()/c.repetitions;
 const auto cpu_elapsed=((static_cast<double>(cpu_stop.tv_sec)-cpu_start.tv_sec)*1e9+cpu_stop.tv_nsec-cpu_start.tv_nsec)/1000/c.repetitions;
 std::printf("%zu,%s,%zu,%zu,%d,%.6f,%.6f,%ju\n",index,c.name,c.n,c.m,c.repetitions,elapsed,cpu_elapsed,static_cast<std::uintmax_t>(sink));
}
