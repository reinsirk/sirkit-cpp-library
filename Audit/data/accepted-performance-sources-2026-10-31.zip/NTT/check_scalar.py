from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/home/reinsirk/Atcoder_Env');p=Path(__file__).parent;o=p/'scalar_checks';o.mkdir(exist_ok=True);os.sched_setaffinity(0,{4});results=[]
for candidate in ['radix4','montgomery','montgomery_radix4']:
 for cc,flags in {'gcc':['/usr/bin/g++','-std=c++23','-O2','-Wall','-Wextra','-Wpedantic','-Werror'],'clang':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-std=c++23','-O2','-Wall','-Wextra','-Wpedantic','-Werror']}.items():
  for skip in [False,True]:
   for fixture in ['ntt_reference_test','suffix_ntt_large_reference_test']:
    target=o/f'{candidate}-{cc}-{int(skip)}-{fixture}';cmd=flags+(['-DSKIP_RUNTIME_CHECKS']if skip else[])+[f'-DNTT_HEADER="{p/(candidate+".hpp")}"',str(root/f'Verify/current/tests/{fixture}.cpp'),'-o',str(target)];a=subprocess.run(cmd,capture_output=True,text=True);row=dict(candidate=candidate,sha256=hashlib.sha256((p/(candidate+'.hpp')).read_bytes()).hexdigest(),compiler=cc,skip=skip,fixture=fixture,command=cmd,compile_exit=a.returncode,compile_stderr=a.stderr)
    if a.returncode==0:
     b=subprocess.run([str(target)],capture_output=True,text=True);row.update(run_exit=b.returncode,stdout=b.stdout,stderr=b.stderr,passed=b.returncode==0)
    results.append(row);(o/'results.json').write_text(json.dumps(results,indent=2));print(candidate,cc,skip,fixture,row.get('passed'),flush=True);assert row.get('passed')and not a.stderr and not row.get('stderr'),row
print('24 scalar PASS',flush=True)
