from pathlib import Path
import os,subprocess,json,hashlib
D=Path(__file__).parent;ROOT=Path('/home/reinsirk/Atcoder_Env');candidate='vector_radix4_threshold16';OUT=D/'sanitizer';OUT.mkdir(exist_ok=True);os.setsid();os.sched_setaffinity(0,{4});(OUT/'runner.pid').write_text(str(os.getpid()));rows=[]
for cc,compiler in {'gcc':['/usr/bin/g++'],'clang':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']}.items():
 for disabled in [False,True]:
  for fixture in ['final_reference_test','formal_power_series_reference_test']:
   target=OUT/f'{cc}-{int(disabled)}-{fixture}';source=D/(fixture+'.cpp') if fixture=='final_reference_test'else ROOT/f'Verify/current/tests/{fixture}.cpp';fps=D/(candidate+'_final_checks')/(('disabled'if disabled else'simd')+'_fps.hpp')
   cmd=compiler+['-std=c++23','-O1','-g','-Wall','-Wextra','-Wpedantic','-Werror','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer']+(['-DSIRKIT_DISABLE_SIMD','-DSIRKIT_FORCE_STANDARD_ARITHMETIC','-U__SIZEOF_INT128__']if disabled else[])+[f'-DNTT_HEADER="{D/(candidate+".hpp")}"',f'-DFPS_HEADER="{fps}"',str(source),'-o',str(target)]
   a=subprocess.run(cmd,capture_output=True,text=True);row=dict(compiler=cc,disabled=disabled,fixture=fixture,command=cmd,compile_exit=a.returncode,compile_stderr=a.stderr)
   if a.returncode==0:
    b=subprocess.run([str(target)],capture_output=True,text=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0'));row.update(run_exit=b.returncode,stdout=b.stdout,stderr=b.stderr,passed=b.returncode==0)
   rows.append(row);(OUT/'results.json').write_text(json.dumps(rows,indent=2));print(cc,disabled,fixture,row.get('passed'),flush=True);assert row.get('passed')and not a.stderr and not row.get('stderr'),row
print('8 ASan/UBSan configs PASS',flush=True)
