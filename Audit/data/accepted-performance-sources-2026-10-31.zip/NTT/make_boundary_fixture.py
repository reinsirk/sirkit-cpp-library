from pathlib import Path
D=Path(__file__).parent
source=Path('/home/reinsirk/Atcoder_Env/Verify/current/tests/ntt_reference_test.cpp').read_text()
extra=r'''
template<std::uint32_t Mod,std::uint32_t Root>void boundary(std::mt19937_64&rng){
 NTT<Mod,Root> engine;
 for(std::size_t n=128;n<=2048&&n<=engine.max_length();n*=2){
  std::vector<std::uint32_t>a(n);for(auto&v:a)v=static_cast<std::uint32_t>(rng()%Mod);const auto saved=a;
  std::vector<std::uint32_t>expected(n);const auto omega=reinsirk::detail::ntt_power(Root,static_cast<std::uint32_t>((Mod-1)/n),Mod);
  for(std::size_t k=0;k<n;++k){const auto step=reinsirk::detail::ntt_power(omega,static_cast<std::uint32_t>(k),Mod);std::uint64_t weight=1;for(std::size_t j=0;j<n;++j){expected[k]=static_cast<std::uint32_t>((expected[k]+std::uint64_t{a[j]}*weight)%Mod);weight=weight*step%Mod;}}
  engine.transform(a);check(a==expected);engine.transform(a,true);check(a==saved);
  auto copy=engine;auto moved=std::move(copy);check(moved.roots_capacity()>=n);auto copy2=moved;copy2.clear_cache();check(copy2.roots_capacity()==0);check(moved.roots_capacity()>=n);
#ifndef SKIP_RUNTIME_CHECKS
  for(std::size_t index=0;index<n;index+=n>256?31:1)for(auto badvalue:{Mod,UINT32_MAX}){
   a.assign(n,0);a[index]=badvalue;rejects<std::invalid_argument>([&]{engine.transform(a);});
   a.assign(n,0);a[index]=badvalue;rejects<std::invalid_argument>([&]{engine.transform(a,true);});
  }
#endif
 }
 for(std::size_t n:{0,1,2,31,32,33,63,64,65,127,128,129,255,256,257,1025}){
  for(std::size_t m:{0,1,2,31,32,33,127,255}){
   if(std::min(n,m)>32&&std::bit_ceil(n+m-1)>engine.max_length())continue;
   std::vector<std::uint64_t>a(n,UINT64_MAX),b(m,UINT64_MAX);if(n)a[0]=0;if(m)b.back()=Mod;
   check(engine.convolution(a,b)==reference<Mod>(a,b));
  }
 }
}
'''
source=source.replace('\n}\nint main()', '\n'+extra+'\n}\nint main()',1)
source=source.replace('NTT<>engine;for(int n:', 'test_mod<1224736769,3>(rng);test_mod<2013265921,31>(rng);test_mod<1053818881,7>(rng);test_mod<1073741789,2>(rng);test_mod<1073741827,2>(rng);boundary<998244353,3>(rng);boundary<167772161,3>(rng);boundary<1053818881,7>(rng);boundary<1224736769,3>(rng);boundary<2013265921,31>(rng);NTT<>engine;for(int n:')
(D/'boundary_reference_test.cpp').write_text(source)
