from pathlib import Path
import hashlib,re
D=Path(__file__).parent
for name in ['montgomery_roots','montgomery_radix4_roots','avx2_tile8_roots']:
 s=(D/(name+'.hpp')).read_text()
 s=s.replace('return value>=Mod?value-Mod:value;','return value;')
 marker='    static constexpr std::uint32_t encode(std::uint32_t value) noexcept {'
 helpers='''    static constexpr std::uint32_t working_normalize(std::uint32_t value) noexcept {
        if constexpr(montgomery_)return value>=Mod?value-Mod:value;
        else return value;
    }
    static constexpr std::uint32_t working_add(std::uint32_t a,std::uint32_t b) noexcept {
        if constexpr(montgomery_){const auto value=a+b;return value>=2*Mod?value-2*Mod:value;}
        else return add(a,b);
    }
    static constexpr std::uint32_t working_subtract(std::uint32_t a,std::uint32_t b) noexcept {
        if constexpr(montgomery_)return a>=b?a-b:a+2*Mod-b;
        else return subtract(a,b);
    }
'''
 assert marker in s;s=s.replace(marker,helpers+marker)
 # Only kernels work in [0,2Mod); the naive API continues in [0,Mod).
 start=s.index('    template <bool Check>\n    void forward(')
 end=s.index('    template <bool Check>\n    std::vector<std::uint32_t> compute',start)
 part=s[start:end]
 part=re.sub(r'\badd\(', 'working_add(',part);part=re.sub(r'\bsubtract\(', 'working_subtract(',part)
 # Final inverse scaling leaves Montgomery form and must be canonical.
 part=part.replace('working_multiply(a[0], inverse_n)','working_normalize(working_multiply(a[0], inverse_n))')
 part=part.replace('working_multiply(a[i], inverse_n)','working_normalize(working_multiply(a[i], inverse_n))')
 part=part.replace('working_multiply(a[n - i], inverse_n)','working_normalize(working_multiply(a[n - i], inverse_n))')
 part=part.replace('working_multiply(a[n / 2], inverse_n)','working_normalize(working_multiply(a[n / 2], inverse_n))')
 for v in ['a[0]','a[i]','a[n-i]','a[n/2]']:
  part=part.replace('working_multiply('+v+',inverse_n)','working_normalize(working_multiply('+v+',inverse_n))')
 s=s[:start]+part+s[end:]
 s=s.replace('else return working_multiply(value,1);','else return working_normalize(working_multiply(value,1));')
 if name.startswith('avx2'):
  start=s.index('    static bool use_avx2(');end=s.index('\n#endif\n\n    template <bool Check>',start)
  part=s[start:end]
  part=part.replace('return vector_reduce(_mm256_or_si256(reduced_even,reduced_odd));','return _mm256_or_si256(reduced_even,reduced_odd);')
  part=part.replace('return vector_reduce(_mm256_add_epi32(a,b));','const auto sum=_mm256_add_epi32(a,b);return _mm256_min_epu32(sum,_mm256_sub_epi32(sum,_mm256_set1_epi32(static_cast<int>(2*Mod))));')
  part=part.replace('return vector_reduce(_mm256_sub_epi32(_mm256_add_epi32(a,_mm256_set1_epi32(static_cast<int>(Mod))),b));','const auto difference=_mm256_sub_epi32(_mm256_add_epi32(a,_mm256_set1_epi32(static_cast<int>(2*Mod))),b);return _mm256_min_epu32(difference,_mm256_sub_epi32(difference,_mm256_set1_epi32(static_cast<int>(2*Mod))));')
  part=re.sub(r'\badd\(', 'working_add(',part);part=re.sub(r'\bsubtract\(', 'working_subtract(',part)
  for v in ['a[0]','a[i]','a[n-i]','a[n/2]']:
   part=part.replace('working_multiply('+v+',inverse_n)','working_normalize(working_multiply('+v+',inverse_n))')
  part=part.replace('vector_multiply(hi,scale)','vector_reduce(vector_multiply(hi,scale))').replace('vector_multiply(lo,scale)','vector_reduce(vector_multiply(lo,scale))')
  s=s[:start]+part+s[end:]
 out=D/(name+'_lazy.hpp');out.write_text(s);print(out.name,hashlib.sha256(s.encode()).hexdigest(),len(s))
