from pathlib import Path
import hashlib,json
D=Path(__file__).parent
s=(D/'montgomery.hpp').read_text()
condition='!defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__))'
s=s.replace('#include <vector>','#include <vector>\n#if '+condition+'\n#include <immintrin.h>\n#endif')
s=s.replace('#ifndef SIRKIT_NTT_DEFINED', '''#if '''+condition+'''
#ifndef SIRKIT_NTT_SIMD_DETAIL_DEFINED
#define SIRKIT_NTT_SIMD_DETAIL_DEFINED
namespace reinsirk::detail {
inline bool ntt_avx2_available() noexcept {
    static const bool available=__builtin_cpu_supports("avx2");
    return available;
}
}
#endif
#endif

#ifndef SIRKIT_NTT_DEFINED''',1)
helper=r'''
#if @CONDITION@
    static bool use_avx2(std::size_t n) noexcept {
        if constexpr(montgomery_)return n>=256 && reinsirk::detail::ntt_avx2_available();
        else return false;
    }
    [[gnu::always_inline,gnu::target("avx2")]]
    static inline __m256i vector_reduce(__m256i value) noexcept {
        const auto mod=_mm256_set1_epi32(static_cast<int>(Mod));
        return _mm256_min_epu32(value,_mm256_sub_epi32(value,mod));
    }
    [[gnu::always_inline,gnu::target("avx2")]]
    static inline __m256i vector_add(__m256i a,__m256i b) noexcept {
        return vector_reduce(_mm256_add_epi32(a,b));
    }
    [[gnu::always_inline,gnu::target("avx2")]]
    static inline __m256i vector_subtract(__m256i a,__m256i b) noexcept {
        return vector_reduce(_mm256_sub_epi32(_mm256_add_epi32(a,_mm256_set1_epi32(static_cast<int>(Mod))),b));
    }
    [[gnu::always_inline,gnu::target("avx2")]]
    static inline __m256i vector_multiply(__m256i a,__m256i b) noexcept {
        const auto mod=_mm256_set1_epi32(static_cast<int>(Mod));
        const auto inverse=_mm256_set1_epi32(static_cast<int>(negative_inverse_));
        const auto even=_mm256_mul_epu32(a,b);
        const auto odd=_mm256_mul_epu32(_mm256_srli_epi64(a,32),_mm256_srli_epi64(b,32));
        const auto q_even=_mm256_mul_epu32(even,inverse),q_odd=_mm256_mul_epu32(odd,inverse);
        const auto reduced_even=_mm256_srli_epi64(_mm256_add_epi64(even,_mm256_mul_epu32(q_even,mod)),32);
        const auto reduced_odd=_mm256_slli_epi64(_mm256_srli_epi64(_mm256_add_epi64(odd,_mm256_mul_epu32(q_odd,mod)),32),32);
        return vector_reduce(_mm256_or_si256(reduced_even,reduced_odd));
    }
#ifndef SKIP_RUNTIME_CHECKS
    [[gnu::always_inline,gnu::target("avx2")]]
    static inline void vector_check(__m256i value) {
        const auto maximum=_mm256_set1_epi32(static_cast<int>(Mod-1));
        if(_mm256_movemask_epi8(_mm256_cmpeq_epi32(value,_mm256_min_epu32(value,maximum)))!=-1)
            throw std::invalid_argument("NTT: coefficient not normalized");
    }
#endif
    [[gnu::target("avx2")]]
    static void pointwise_avx2(std::vector<std::uint32_t>& a,const std::vector<std::uint32_t>& b) noexcept {
        for(std::size_t i=0;i<a.size();i+=8) {
            const auto x=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+i));
            const auto y=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(b.data()+i));
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+i),vector_multiply(x,y));
        }
    }
    template<bool Check>
    [[gnu::target("avx2")]]
    void forward_avx2(std::vector<std::uint32_t>& a) const {
        const auto n=a.size();
        for(std::size_t length=n;length>=2;length>>=1) {
            const auto half=length>>1;
            for(std::size_t block=0;block<n;block+=length) {
                std::size_t j=0;
                for(;j+8<=half;j+=8) {
                    auto u=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+block+j));
                    auto v=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+block+j+half));
                    if(length==n) {
#ifndef SKIP_RUNTIME_CHECKS
                        if constexpr(Check){vector_check(u);vector_check(v);}
#endif
                        const auto r2=_mm256_set1_epi32(static_cast<int>(r_squared_));
                        u=vector_multiply(u,r2);v=vector_multiply(v,r2);
                    }
                    const auto roots=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data()+half+j));
                    _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+block+j),vector_add(u,v));
                    _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+block+j+half),vector_multiply(vector_subtract(u,v),roots));
                }
                for(;j<half;++j) {
                    auto u=a[block+j],v=a[block+j+half];
#ifndef SKIP_RUNTIME_CHECKS
                    if constexpr(Check)if(length==n&&(u>=Mod||v>=Mod))throw std::invalid_argument("NTT: coefficient not normalized");
#endif
                    if(length==n){u=encode(u);v=encode(v);}
                    a[block+j]=add(u,v);a[block+j+half]=working_multiply(subtract(u,v),roots_[half+j]);
                }
            }
        }
    }
    template<bool Check>
    [[gnu::target("avx2")]]
    void backward_avx2(std::vector<std::uint32_t>& a) const {
        const auto n=a.size();
        for(std::size_t length=2;length<=n;length<<=1) {
            const auto half=length>>1;
            for(std::size_t block=0;block<n;block+=length) {
                std::size_t j=0;
                for(;j+8<=half;j+=8) {
                    const auto u=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+block+j));
                    const auto raw=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+block+j+half));
                    const auto roots=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data()+half+j));
                    const auto v=vector_multiply(raw,roots);
                    _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+block+j),vector_add(u,v));
                    _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+block+j+half),vector_subtract(u,v));
                }
                for(;j<half;++j) {
                    const auto u=a[block+j],raw=a[block+j+half];
#ifndef SKIP_RUNTIME_CHECKS
                    if constexpr(Check)if(length==2&&(u>=Mod||raw>=Mod))throw std::invalid_argument("NTT: coefficient not normalized");
#endif
                    const auto v=working_multiply(raw,roots_[half+j]);
                    a[block+j]=add(u,v);a[block+j+half]=subtract(u,v);
                }
            }
        }
        const auto inverse_n=reinsirk::detail::ntt_power(static_cast<std::uint32_t>(n),Mod-2,Mod);
        const auto scale=_mm256_set1_epi32(static_cast<int>(inverse_n));
        const auto reverse=_mm256_setr_epi32(7,6,5,4,3,2,1,0);
        a[0]=working_multiply(a[0],inverse_n);
        std::size_t i=1;
        for(;i+8<=n/2;i+=8) {
            const auto lo=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+i));
            const auto hi=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+n-i-7));
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+i),_mm256_permutevar8x32_epi32(vector_multiply(hi,scale),reverse));
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+n-i-7),_mm256_permutevar8x32_epi32(vector_multiply(lo,scale),reverse));
        }
        for(;i<n-i;++i) {
            const auto lo=working_multiply(a[i],inverse_n),hi=working_multiply(a[n-i],inverse_n);
            a[i]=hi;a[n-i]=lo;
        }
        a[n/2]=working_multiply(a[n/2],inverse_n);
    }
#endif
'''.replace('@CONDITION@',condition)
s=s.replace('    template <bool Check>\n    void forward(',helper+'\n    template <bool Check>\n    void forward(',1)
s=s.replace('void forward(std::vector<std::uint32_t>& a) const {\n        const std::size_t n = a.size();','void forward(std::vector<std::uint32_t>& a) const {\n        const std::size_t n = a.size();\n#if '+condition+'\n        if constexpr(montgomery_)if(use_avx2(n)){forward_avx2<Check>(a);return;}\n#endif',1)
s=s.replace('void backward(std::vector<std::uint32_t>& a) const {\n        const std::size_t n = a.size();','void backward(std::vector<std::uint32_t>& a) const {\n        const std::size_t n = a.size();\n#if '+condition+'\n        if constexpr(montgomery_)if(use_avx2(n)){backward_avx2<Check>(a);return;}\n#endif',1)
s=s.replace('        for (std::size_t i = 0; i < length; ++i) a[i] = working_multiply(a[i], b[i]);','''#if '''+condition+'''
        if(use_avx2(length))pointwise_avx2(a,b);
        else
#endif
        for (std::size_t i = 0; i < length; ++i) a[i] = working_multiply(a[i], b[i]);''',1)
s=s.replace('        for (auto& value : x) value = working_multiply(value, value);','''#if '''+condition+'''
        if(use_avx2(length))pointwise_avx2(x,x);
        else
#endif
        for (auto& value : x) value = working_multiply(value, value);''',1)
(D/'avx2.hpp').write_text(s)
print(hashlib.sha256(s.encode()).hexdigest(),len(s))
