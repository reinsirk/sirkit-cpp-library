from pathlib import Path
import subprocess,os,json,hashlib
D=Path(__file__).parent;ROOT=Path('/home/reinsirk/Atcoder_Env');OUT=D/'avx2_checks';OUT.mkdir(exist_ok=True)
os.setsid();(OUT/'runner.pid').write_text(str(os.getpid()));os.sched_setaffinity(0,{4})
results=[]
compilers={'gcc':['/usr/bin/g++'],'clang':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']}
source=(D/'avx2.hpp').read_text();(D/'avx2_cpu_false.hpp').write_text(source.replace('static const bool available=__builtin_cpu_supports("avx2");','static const bool available=false;'))
for mode,header,defines in [('avx2','avx2.hpp',[]),('disabled','avx2.hpp',['SIRKIT_DISABLE_SIMD']),('cpu_false','avx2_cpu_false.hpp',[])]:
 for cc,compiler in compilers.items():
  for skip in [False,True]:
   for fixture in ['boundary_reference_test','suffix_ntt_large_reference_test','string_math_allocation_test']:
    path=D/(fixture+'.cpp') if fixture=='boundary_reference_test' else ROOT/f'Verify/current/tests/{fixture}.cpp'
    target=OUT/f'{mode}-{cc}-{int(skip)}-{fixture}'
    cmd=compiler+['-std=c++23','-O2','-Wall','-Wextra','-Wpedantic','-Werror']+[f'-D{x}' for x in defines]+(['-DSKIP_RUNTIME_CHECKS']if skip else[])+[f'-DNTT_HEADER="{D/header}"',str(path),'-o',str(target)]
    a=subprocess.run(cmd,capture_output=True,text=True);row=dict(mode=mode,sha256=hashlib.sha256((D/header).read_bytes()).hexdigest(),compiler=cc,skip=skip,fixture=fixture,command=cmd,compile_exit=a.returncode,compile_stderr=a.stderr)
    if a.returncode==0:
     b=subprocess.run([str(target)],capture_output=True,text=True);row.update(run_exit=b.returncode,stdout=b.stdout,stderr=b.stderr,passed=b.returncode==0)
    results.append(row);(OUT/'results.json').write_text(json.dumps(results,indent=2));print(mode,cc,skip,fixture,row.get('passed'),flush=True)
    assert row.get('passed')and not a.stderr and not row.get('stderr'),row
print('36 AVX2 boundary/large/allocation PASS',flush=True)
