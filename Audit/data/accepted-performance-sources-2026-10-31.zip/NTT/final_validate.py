from pathlib import Path
import subprocess,os,json,hashlib,argparse,importlib.util
D=Path(__file__).parent;ROOT=Path('/home/reinsirk/Atcoder_Env');p=argparse.ArgumentParser();p.add_argument('candidate');args=p.parse_args();OUT=D/(args.candidate+'_final_checks');OUT.mkdir(exist_ok=True);os.setsid();(OUT/'runner.pid').write_text(str(os.getpid()));os.sched_setaffinity(0,{4});rows=[]
source=(D/(args.candidate+'.hpp')).read_text();(OUT/'cpu_false.hpp').write_text(source.replace('static const bool available=__builtin_cpu_supports("avx2");','static const bool available=false;'))
spec=importlib.util.spec_from_file_location('fps_generator',ROOT/'Scripts/generate_formal_power_series.py');generator=importlib.util.module_from_spec(spec);spec.loader.exec_module(generator)
bridge=OUT/'render_root';(bridge/'Math/FPS/components').mkdir(parents=True,exist_ok=True)
for name in ['formal_power_series_header.inc','formal_power_series_body.inc']:(bridge/'Math/FPS/components'/name).write_bytes((ROOT/'Math/FPS/components'/name).read_bytes())
for mode,ntt,defines in [('simd',D/(args.candidate+'.hpp'),[]),('disabled',D/(args.candidate+'.hpp'),['SIRKIT_DISABLE_SIMD','SIRKIT_FORCE_STANDARD_ARITHMETIC']),('cpu_false',OUT/'cpu_false.hpp',[])]:
 (bridge/'Math/NTT.cpp').write_bytes(ntt.read_bytes());fps=OUT/(mode+'_fps.hpp');fps.write_bytes(generator.render(bridge))
 for cc,compiler in {'gcc':['/usr/bin/g++'],'clang':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']}.items():
  for skip in [False,True]:
   for fixture in ['final_reference_test','suffix_ntt_large_reference_test','string_math_allocation_test','formal_power_series_reference_test','string_math_second_allocation_test','formal_power_series_reference_test_ntt_first']:
    path=D/(fixture+'.cpp') if fixture=='final_reference_test' else ROOT/f'Verify/current/tests/{fixture.replace("_ntt_first","")}.cpp';target=OUT/f'{mode}-{cc}-{int(skip)}-{fixture}'
    cmd=compiler+['-std=c++23','-O2','-Wall','-Wextra','-Wpedantic','-Werror']+(['-DSIRKIT_TEST_NTT_FIRST']if fixture.endswith('_ntt_first')else[])+[f'-D{x}' for x in defines]+(['-DSKIP_RUNTIME_CHECKS']if skip else[])+[f'-DNTT_HEADER="{ntt}"',f'-DFPS_HEADER="{fps}"',str(path),'-o',str(target)]
    a=subprocess.run(cmd,capture_output=True,text=True);row=dict(mode=mode,compiler=cc,skip=skip,fixture=fixture,ntt_sha256=hashlib.sha256(ntt.read_bytes()).hexdigest(),fixture_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),command=cmd,compile_exit=a.returncode,compile_stderr=a.stderr)
    if a.returncode==0:
     b=subprocess.run([str(target)],capture_output=True,text=True);row.update(run_exit=b.returncode,stdout=b.stdout,stderr=b.stderr,passed=b.returncode==0)
    rows.append(row);(OUT/'results.json').write_text(json.dumps(rows,indent=2));print(mode,cc,skip,fixture,row.get('passed'),flush=True);assert row.get('passed')and not a.stderr and not row.get('stderr'),row
print('72 final configs PASS',flush=True)
