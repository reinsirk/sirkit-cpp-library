from pathlib import Path
import subprocess,os,json,hashlib
D=Path(__file__).parent;OUT=D/'new_checks';OUT.mkdir(exist_ok=True);os.setsid();(OUT/'runner.pid').write_text(str(os.getpid()));os.sched_setaffinity(0,{4});results=[]
for candidate in ['baseline_roots','montgomery_roots','montgomery_radix4_roots','avx2_tile8','avx2_tile8_roots','montgomery_roots_lazy','montgomery_radix4_roots_lazy','avx2_tile8_roots_lazy']:
 for cc,compiler in {'gcc':['/usr/bin/g++'],'clang':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']}.items():
  target=OUT/f'{candidate}-{cc}';cmd=compiler+['-std=c++23','-O2','-Wall','-Wextra','-Wpedantic','-Werror',f'-DNTT_HEADER="{D/(candidate+".hpp")}"',str(D/'boundary_reference_test.cpp'),'-o',str(target)]
  a=subprocess.run(cmd,capture_output=True,text=True);row=dict(candidate=candidate,sha256=hashlib.sha256((D/(candidate+'.hpp')).read_bytes()).hexdigest(),compiler=cc,command=cmd,compile_exit=a.returncode,compile_stderr=a.stderr)
  if a.returncode==0:
   b=subprocess.run([str(target)],capture_output=True,text=True);row.update(run_exit=b.returncode,stdout=b.stdout,stderr=b.stderr,passed=b.returncode==0)
  results.append(row);(OUT/'results.json').write_text(json.dumps(results,indent=2));print(candidate,cc,row.get('passed'),flush=True);assert row.get('passed')and not a.stderr and not row.get('stderr'),row
print('16 new PASS',flush=True)
