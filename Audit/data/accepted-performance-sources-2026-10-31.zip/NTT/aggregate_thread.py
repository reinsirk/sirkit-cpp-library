from pathlib import Path
import json,statistics,argparse
D=Path(__file__).parent;OUT=D/'thread_bench'
p=argparse.ArgumentParser();p.add_argument('--name',required=True);a=p.parse_args()
manifest=json.loads((OUT/(a.name+'_manifest.json')).read_text());rows=json.loads((OUT/(a.name+'_raw.json')).read_text());modes=manifest['modes'];cases=manifest['cases'];candidates=manifest['candidates']
summary=[]
for mode in modes:
 for case in cases:
  cpu_base=statistics.median(r['thread_microseconds']for r in rows if r['mode']==mode and r['index']==case and r['candidate']=='baseline')
  base=statistics.median(r['microseconds']for r in rows if r['mode']==mode and r['index']==case and r['candidate']=='baseline')
  for candidate in candidates:
   selected=[r for r in rows if r['mode']==mode and r['index']==case and r['candidate']==candidate];median=statistics.median(r['microseconds']for r in selected);row={k:selected[0][k]for k in ['mode','candidate','index','operation','n','m']};cpu=statistics.median(r['thread_microseconds']for r in selected);row.update(median_us=median,ratio=median/base,baseline_us=base,thread_median_us=cpu,thread_ratio=cpu/cpu_base,thread_baseline_us=cpu_base);summary.append(row)
(OUT/(a.name+'_summary.json')).write_text(json.dumps(summary,indent=2));print('DONE',manifest['finished_unix']-manifest['started_unix'],flush=True)
