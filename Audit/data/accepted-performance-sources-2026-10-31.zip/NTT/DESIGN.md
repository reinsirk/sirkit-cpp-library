# NTT試作の前提と採否基準

本体・FPS・既存driverは未変更。全候補は一つのuint32根表とvector所有を維持する。返却係数は常に[0,Mod)。公開transformの並び、各法の最大長、検査省略時も残す容量上限はbaselineと同じ。

- radix4: 2段を融合し、各blockのj=0にある単位根の積を省く。順DIF/逆DITを維持する。
- Montgomery: Mod<2^30でR=2^32。64bit積だけで計算でき、拡張整数に依存しない。順変換の最初の読込時にMontgomery表現へ変え、逆変換の最終スケール時に元へ戻す。根表も同じ領域に置く。
- roots: 既存half/2段の値を新しい段の偶数番へコピー、奇数番だけstepを掛ける。逐次乗算の依存鎖と乗算数を減らす。表のサイズとclear/copy/moveは従来通り。
- AVX2: 偶数/奇数laneを分けたVPMULUDQで8係数分のMontgomery積を作る。target("avx2")を関数単位で付け、対応CPUのみ呼ぶ。SIRKIT_DISABLE_SIMDでは追加intrinsic/CPU判定ごと除外する。
- tile8: 末尾/先頭3段を8点block内で融合し、shuffle/blendにより中間のメモリ走査を省く。
- lazy: 内部値を[0,2Mod)とし、積ごとのMod引きを省く。a,b<2Modならt=ab<4Mod^2<2^62、qMod<2^62。t+qMod<2^63なので64bit加算は安全。還元後は(t+qMod)/2^32<2Mod。加減算も4Mod<2^32で安全。公開係数に戻す箇所でMod未満へ正規化する。
- naive AVX2: 短い列を外側にし、固定係数のみR領域へ変換、長い列8係数との積を通常領域で直接得る。結果は毎回Mod未満へ直す。端数は従来のscalar演算。新しい全走査や照会順変更はない。

AVX2未対応CPUは標準C++のscalar Montgomery経路を使う。Mod>=2^30ではcanonical scalar経路を使う。CPU非対応時にbaselineと同一の命令列という意味ではなく、APIと数学的前提を維持した標準経路である。必要なら最終選択時にrootへ明示する。

性能はCPU12のP-CoreでGCC15.2/Clang21、O2、default/native、SKIP_RUNTIME_CHECKSで比較する。main/共通IOは変更しない。API単体benchmarkは入力作成を外し、同一case/seed/repetitionで測る。通常畳み込み・所有vector移動・square・自己alias・長短不均衡・順逆transform・根表初回/再利用を別々に記録。baselineをcontrol名でも同じ実行ファイルで混ぜ、分散を把握する。

試作の初回scalar radix4+lazyには最終逆変換の正規化漏れがあり、独立参照が検出した。make_lazy.pyで最終スケール箇所を全て正規化し、修正版SHA=d29148de2534025222beef8e97cb04b7c66a55ad79835194e6946d2870db56fcはGCC/Clang境界参照を通過。失敗時のJSONはnew_checks/initial_failure.jsonに保持する。

採用時はrootがMath/NTT.cppを同期し、Scripts/generate_formal_power_series.pyでFPSへ同梱する。本agent側ではtempに同じrender方式のFPSを生成し、NTT先/後の同時貼付・FPS全機能・確保失敗を先に照合する。

数学・命令の参考（実装の転記なし）:
- https://nyaannyaan.github.io/library/ntt/ntt.hpp.html
- https://www.intel.com/content/dam/www/public/us/en/documents/manuals/64-ia-32-architectures-software-developer-vol-2b-manual.pdf
- https://clang.llvm.org/docs/AttributeReference.html#target
