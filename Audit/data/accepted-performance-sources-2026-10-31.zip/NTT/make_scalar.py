from pathlib import Path
import hashlib,json
p=Path(__file__).parent;baseline=(p/'baseline.hpp').read_text()
forward4=r'''    template <bool Check>
    void forward(std::vector<std::uint32_t>& a) const {
        const std::size_t n = a.size();
        constexpr auto imaginary = reinsirk::detail::ntt_power(Root, (Mod - 1) / 4, Mod);
        std::size_t length = n;
        for (; length >= 4; length >>= 2) {
            const auto quarter = length / 4;
            for (std::size_t block = 0; block < n; block += length) {
                auto u0=a[block], u1=a[block+quarter], u2=a[block+2*quarter], u3=a[block+3*quarter];
#ifndef SKIP_RUNTIME_CHECKS
                if constexpr (Check) if (length==n && (u0>=Mod || u1>=Mod || u2>=Mod || u3>=Mod))
                    throw std::invalid_argument("NTT: coefficient not normalized");
#endif
                const auto s0=add(u0,u2), s1=add(u1,u3), d0=subtract(u0,u2), d1=multiply(subtract(u1,u3),imaginary);
                a[block]=add(s0,s1); a[block+quarter]=subtract(s0,s1);
                a[block+2*quarter]=add(d0,d1); a[block+3*quarter]=subtract(d0,d1);
                for (std::size_t j=1;j<quarter;++j) {
                    u0=a[block+j];u1=a[block+j+quarter];u2=a[block+j+2*quarter];u3=a[block+j+3*quarter];
#ifndef SKIP_RUNTIME_CHECKS
                    if constexpr (Check) if (length==n && (u0>=Mod || u1>=Mod || u2>=Mod || u3>=Mod))
                        throw std::invalid_argument("NTT: coefficient not normalized");
#endif
                    const auto v0=add(u0,u2),v1=add(u1,u3);
                    const auto v2=multiply(subtract(u0,u2),roots_[2*quarter+j]);
                    const auto v3=multiply(subtract(u1,u3),roots_[3*quarter+j]);
                    a[block+j]=add(v0,v1);
                    a[block+j+quarter]=multiply(subtract(v0,v1),roots_[quarter+j]);
                    a[block+j+2*quarter]=add(v2,v3);
                    a[block+j+3*quarter]=multiply(subtract(v2,v3),roots_[quarter+j]);
                }
            }
        }
        if (length==2) for (std::size_t i=0;i<n;i+=2) {
            const auto u=a[i],v=a[i+1];
#ifndef SKIP_RUNTIME_CHECKS
            if constexpr (Check) if (n==2 && (u>=Mod || v>=Mod))
                throw std::invalid_argument("NTT: coefficient not normalized");
#endif
            a[i]=add(u,v);a[i+1]=subtract(u,v);
        }
    }
'''
backward4=r'''    template <bool Check>
    void backward(std::vector<std::uint32_t>& a) const {
        const std::size_t n=a.size();
        constexpr auto imaginary = reinsirk::detail::ntt_power(Root, (Mod - 1) / 4, Mod);
        std::size_t completed=1;
        for (std::size_t length=4;length<=n;) {
            const auto quarter=length/4;
            for(std::size_t block=0;block<n;block+=length) {
                auto u0=a[block],u1=a[block+quarter],u2=a[block+2*quarter],u3=a[block+3*quarter];
#ifndef SKIP_RUNTIME_CHECKS
                if constexpr(Check) if(length==4&&(u0>=Mod||u1>=Mod||u2>=Mod||u3>=Mod))
                    throw std::invalid_argument("NTT: coefficient not normalized");
#endif
                const auto s0=add(u0,u1),d0=subtract(u0,u1),s1=add(u2,u3),d1=multiply(subtract(u2,u3),imaginary);
                a[block]=add(s0,s1);a[block+quarter]=add(d0,d1);
                a[block+2*quarter]=subtract(s0,s1);a[block+3*quarter]=subtract(d0,d1);
                for(std::size_t j=1;j<quarter;++j) {
                    u0=a[block+j];u1=a[block+j+quarter];u2=a[block+j+2*quarter];u3=a[block+j+3*quarter];
#ifndef SKIP_RUNTIME_CHECKS
                    if constexpr(Check) if(length==4&&(u0>=Mod||u1>=Mod||u2>=Mod||u3>=Mod))
                        throw std::invalid_argument("NTT: coefficient not normalized");
#endif
                    u1=multiply(u1,roots_[quarter+j]);u3=multiply(u3,roots_[quarter+j]);
                    const auto v0=add(u0,u1),v1=subtract(u0,u1);
                    const auto v2=multiply(add(u2,u3),roots_[2*quarter+j]);
                    const auto v3=multiply(subtract(u2,u3),roots_[3*quarter+j]);
                    a[block+j]=add(v0,v2);a[block+j+quarter]=add(v1,v3);
                    a[block+j+2*quarter]=subtract(v0,v2);a[block+j+3*quarter]=subtract(v1,v3);
                }
            }
            completed=length;
            if(length>n/4)break;
            length*=4;
        }
        if(completed<n) {
            const auto half=n/2;
            const auto u=a[0],v=a[half];
#ifndef SKIP_RUNTIME_CHECKS
            if constexpr(Check) if(n==2&&(u>=Mod||v>=Mod))
                throw std::invalid_argument("NTT: coefficient not normalized");
#endif
            a[0]=add(u,v);a[half]=subtract(u,v);
            for(std::size_t j=1;j<half;++j) {
                const auto x=a[j],y=multiply(a[j+half],roots_[half+j]);
                a[j]=add(x,y);a[j+half]=subtract(x,y);
            }
        }
        const auto inverse_n=reinsirk::detail::ntt_power(static_cast<std::uint32_t>(n),Mod-2,Mod);
        a[0]=multiply(a[0],inverse_n);
        for(std::size_t i=1;i<n-i;++i) {
            const auto lo=multiply(a[i],inverse_n),hi=multiply(a[n-i],inverse_n);
            a[i]=hi;a[n-i]=lo;
        }
        if(n>1)a[n/2]=multiply(a[n/2],inverse_n);
    }
'''
def replace_kernel(source,f,b):
 start=source.index('    template <bool Check>\n    void forward(');end=source.index('    template <bool Check>\n    std::vector<std::uint32_t> compute',start)
 return source[:start]+f+b+source[end:]
radix=replace_kernel(baseline,forward4,backward4);(p/'radix4.hpp').write_text(radix)
# Working representation uses 32-bit Montgomery only when Mod<2^30.
mont_helpers=r'''    static constexpr bool montgomery_ = Mod < (std::uint32_t{1} << 30);
    static constexpr std::uint32_t negative_inverse_ = [] {
        std::uint32_t x=Mod;for(int i=0;i<5;++i)x*=2u-Mod*x;return 0u-x;
    }();
    static constexpr std::uint32_t montgomery_one_ = static_cast<std::uint32_t>((std::uint64_t{1} << 32)%Mod);
    static constexpr std::uint32_t r_squared_ = static_cast<std::uint32_t>(std::uint64_t{montgomery_one_}*montgomery_one_%Mod);
    static constexpr std::uint32_t working_multiply(std::uint32_t a,std::uint32_t b) noexcept {
        if constexpr(montgomery_) {
            const auto product=std::uint64_t{a}*b;
            const auto q=static_cast<std::uint32_t>(product)*negative_inverse_;
            const auto value=static_cast<std::uint32_t>((product+std::uint64_t{q}*Mod)>>32);
            return value>=Mod?value-Mod:value;
        } else return multiply(a,b);
    }
    static constexpr std::uint32_t encode(std::uint32_t value) noexcept {
        if constexpr(montgomery_)return working_multiply(value,r_squared_);
        else return value;
    }
    template<bool Encode,bool Check>
    static void bit_reverse_convert(std::vector<std::uint32_t>& a) {
        const auto convert=[](std::uint32_t value) {
#ifndef SKIP_RUNTIME_CHECKS
            if constexpr(Check)if(value>=Mod)throw std::invalid_argument("NTT: coefficient not normalized");
#endif
            if constexpr(Encode)return encode(value);
            else return working_multiply(value,1);
        };
        a[0]=convert(a[0]);
        for(std::size_t i=1,reverse=0;i<a.size();++i) {
            std::size_t bit=a.size()>>1;
            for(;reverse&bit;bit>>=1)reverse^=bit;
            reverse^=bit;
            if(i<reverse){const auto lo=convert(a[i]),hi=convert(a[reverse]);a[i]=hi;a[reverse]=lo;}
            else if(i==reverse)a[i]=convert(a[i]);
        }
    }
'''
def make_montgomery(source,radix=False):
 source=source.replace('    template <std::integral T>\n    static std::uint32_t normalize',mont_helpers+'    template <std::integral T>\n    static std::uint32_t normalize',1)
 start=source.index('    template <bool Check>\n    void forward(');end=source.index('    template <bool Check>\n    std::vector<std::uint32_t> compute',start)
 kernels=source[start:end].replace('multiply(', 'working_multiply(')
 # Every raw input is encoded once in the first DIF stage, after validation.
 if not radix:
  kernels=kernels.replace('const auto u = a[block + j], v = a[block + j + half];','auto u = a[block + j], v = a[block + j + half];')
  needle='                    a[block + j] = add(u, v);';assert kernels.count(needle)==2
  kernels=kernels.replace(needle,'                    if constexpr(montgomery_)if(length==n){u=encode(u);v=encode(v);}\n'+needle,1)
 else:
  kernels=kernels.replace('constexpr auto imaginary = reinsirk::detail::ntt_power(Root, (Mod - 1) / 4, Mod);','constexpr auto imaginary = encode(reinsirk::detail::ntt_power(Root, (Mod - 1) / 4, Mod));')
  kernels=kernels.replace('                const auto s0=add(u0,u2)', '                if constexpr(montgomery_)if(length==n){u0=encode(u0);u1=encode(u1);u2=encode(u2);u3=encode(u3);}\n                const auto s0=add(u0,u2)',1)
  kernels=kernels.replace('                    const auto v0=add(u0,u2)', '                    if constexpr(montgomery_)if(length==n){u0=encode(u0);u1=encode(u1);u2=encode(u2);u3=encode(u3);}\n                    const auto v0=add(u0,u2)',1)
  kernels=kernels.replace('            const auto u=a[i],v=a[i+1];','            auto u=a[i],v=a[i+1];',1)
  kernels=kernels.replace('            a[i]=add(u,v);a[i+1]=subtract(u,v);','            if constexpr(montgomery_)if(n==2){u=encode(u);v=encode(v);}\n            a[i]=add(u,v);a[i+1]=subtract(u,v);',1)
 source=source[:start]+kernels+source[end:]
 source=source.replace('a[i] = multiply(a[i], b[i]);','a[i] = working_multiply(a[i], b[i]);').replace('value = multiply(value, value);','value = working_multiply(value, value);')
 source=source.replace('roots_.resize(length); roots_[1] = 1;','roots_.resize(length); roots_[1] = encode(1);')
 source=source.replace('const auto step = reinsirk::detail::ntt_power(Root, static_cast<std::uint32_t>((Mod - 1) / (half * 2)), Mod);','const auto step = encode(reinsirk::detail::ntt_power(Root, static_cast<std::uint32_t>((Mod - 1) / (half * 2)), Mod));')
 source=source.replace('std::uint32_t value = 1;','std::uint32_t value = encode(1);').replace('roots_[half + j] = value; value = multiply(value, step);','roots_[half + j] = value; value = working_multiply(value, step);')
 old='        if (inverse) { bit_reverse(a); backward<true>(a); }\n        else { forward<true>(a); bit_reverse(a); }'
 new='''        if constexpr(montgomery_) {
            if(inverse){bit_reverse_convert<true,true>(a);backward<false>(a);}
            else{forward<true>(a);bit_reverse_convert<false,false>(a);}
        }else{
'''+old+'''\n        }'''
 assert old in source;source=source.replace(old,new)
 return source
mont=make_montgomery(baseline);(p/'montgomery.hpp').write_text(mont)
mont4=make_montgomery(radix,True);(p/'montgomery_radix4.hpp').write_text(mont4)
manifest={x.name:dict(sha256=hashlib.sha256(x.read_bytes()).hexdigest(),bytes=x.stat().st_size)for x in [p/'baseline.hpp',p/'radix4.hpp',p/'montgomery.hpp',p/'montgomery_radix4.hpp']};(p/'scalar_candidates.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest,indent=2))
