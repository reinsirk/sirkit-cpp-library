from pathlib import Path
import hashlib
D=Path(__file__).parent;s=(D/'avx2.hpp').read_text()
start=s.index('    template<bool Check>\n    [[gnu::target("avx2")]]\n    void forward_avx2')
end=s.index('    template<bool Check>\n    [[gnu::target("avx2")]]\n    void backward_avx2',start)
f=s[start:end].replace('length>=2','length>=16')
pos=f.rfind('    }')
f=f[:pos]+r'''
        const auto u4=_mm256_setr_epi32(0,1,0,1,4,5,4,5),v4=_mm256_setr_epi32(2,3,2,3,6,7,6,7);
        const auto r4=_mm256_setr_epi32(static_cast<int>(roots_[2]),static_cast<int>(roots_[3]),static_cast<int>(roots_[2]),static_cast<int>(roots_[3]),static_cast<int>(roots_[2]),static_cast<int>(roots_[3]),static_cast<int>(roots_[2]),static_cast<int>(roots_[3]));
        const auto r8=_mm256_setr_epi32(static_cast<int>(roots_[4]),static_cast<int>(roots_[5]),static_cast<int>(roots_[6]),static_cast<int>(roots_[7]),static_cast<int>(roots_[4]),static_cast<int>(roots_[5]),static_cast<int>(roots_[6]),static_cast<int>(roots_[7]));
        for(std::size_t block=0;block<n;block+=8) {
            auto x=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+block));
            auto u=_mm256_permute2x128_si256(x,x,0),v=_mm256_permute2x128_si256(x,x,0x11);
            x=_mm256_blend_epi32(vector_add(u,v),vector_multiply(vector_subtract(u,v),r8),0xf0);
            u=_mm256_permutevar8x32_epi32(x,u4);v=_mm256_permutevar8x32_epi32(x,v4);
            x=_mm256_blend_epi32(vector_add(u,v),vector_multiply(vector_subtract(u,v),r4),0xcc);
            u=_mm256_shuffle_epi32(x,_MM_SHUFFLE(2,2,0,0));v=_mm256_shuffle_epi32(x,_MM_SHUFFLE(3,3,1,1));
            x=_mm256_blend_epi32(vector_add(u,v),vector_subtract(u,v),0xaa);
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+block),x);
        }
'''+f[pos:]
s=s[:start]+f+s[end:]
start=s.index('    template<bool Check>\n    [[gnu::target("avx2")]]\n    void backward_avx2')
end=s.index('\n#endif\n\n    template <bool Check>',start)
b=s[start:end]
b=b.replace('for(std::size_t length=2;length<=n;length<<=1)', 'for(std::size_t length=16;length<=n;length<<=1)',1)
pos=b.index('        for(std::size_t length=16')
b=b[:pos]+r'''
        const auto u4=_mm256_setr_epi32(0,1,0,1,4,5,4,5),v4=_mm256_setr_epi32(2,3,2,3,6,7,6,7);
        const auto r4=_mm256_setr_epi32(static_cast<int>(roots_[2]),static_cast<int>(roots_[3]),static_cast<int>(roots_[2]),static_cast<int>(roots_[3]),static_cast<int>(roots_[2]),static_cast<int>(roots_[3]),static_cast<int>(roots_[2]),static_cast<int>(roots_[3]));
        const auto r8=_mm256_setr_epi32(static_cast<int>(roots_[4]),static_cast<int>(roots_[5]),static_cast<int>(roots_[6]),static_cast<int>(roots_[7]),static_cast<int>(roots_[4]),static_cast<int>(roots_[5]),static_cast<int>(roots_[6]),static_cast<int>(roots_[7]));
        for(std::size_t block=0;block<n;block+=8) {
            auto x=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+block));
            auto u=_mm256_shuffle_epi32(x,_MM_SHUFFLE(2,2,0,0)),v=_mm256_shuffle_epi32(x,_MM_SHUFFLE(3,3,1,1));
            x=_mm256_blend_epi32(vector_add(u,v),vector_subtract(u,v),0xaa);
            u=_mm256_permutevar8x32_epi32(x,u4);v=vector_multiply(_mm256_permutevar8x32_epi32(x,v4),r4);
            x=_mm256_blend_epi32(vector_add(u,v),vector_subtract(u,v),0xcc);
            u=_mm256_permute2x128_si256(x,x,0);v=vector_multiply(_mm256_permute2x128_si256(x,x,0x11),r8);
            x=_mm256_blend_epi32(vector_add(u,v),vector_subtract(u,v),0xf0);
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+block),x);
        }
'''+b[pos:]
s=s[:start]+b+s[end:]
(D/'avx2_tile8.hpp').write_text(s);print(hashlib.sha256(s.encode()).hexdigest(),len(s))
