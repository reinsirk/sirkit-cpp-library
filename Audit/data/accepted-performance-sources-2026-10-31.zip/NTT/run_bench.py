from pathlib import Path
import subprocess,json,random,hashlib,os,time,statistics,argparse
D=Path(__file__).parent;OUT=D/'bench';os.setsid();os.sched_setaffinity(0,{12});(OUT/'measurement.pid').write_text(str(os.getpid()))
p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('--screen',action='store_true');p.add_argument('--repetitions',type=int,default=5);a=p.parse_args()
if a.screen:
 modes=['gcc-default'];candidates=['baseline','control','radix4','montgomery','montgomery_radix4_roots','montgomery_radix4_roots_lazy','avx2','avx2_tile8','avx2_tile8_roots_lazy','baseline_roots','avx2_tile8_roots_lazy_naive'];cases=[4,6,7,8,11,12,19,20,21,24,26,28,29,31,33,35,36,39,42]
else:
 modes=['gcc-default','gcc-native','clang-default','clang-native'];candidates=['baseline','control','montgomery_radix4_roots_lazy','avx2_tile8_roots_lazy_naive'];cases=list(range(45))
rows=[];rng=random.Random(0x3148cafe);expected={}
manifest={'name':a.name,'started_unix':time.time(),'repetitions':a.repetitions,'modes':modes,'candidates':candidates,'cases':cases,'cpu':12,'bench_sha256':hashlib.sha256((D/'bench.cpp').read_bytes()).hexdigest(),'headers':{c:hashlib.sha256((D/(('baseline'if c=='control'else c)+'.hpp')).read_bytes()).hexdigest()for c in candidates}}
(OUT/(a.name+'_manifest.json')).write_text(json.dumps(manifest,indent=2))
for repetition in range(a.repetitions):
 tasks=[(mode,case,candidate)for mode in modes for case in cases for candidate in candidates];rng.shuffle(tasks)
 for mode,case,candidate in tasks:
  executable=OUT/(mode+'-'+('baseline'if candidate=='control'else candidate));r=subprocess.run([str(executable),str(case)],capture_output=True,text=True,check=True);fields=r.stdout.strip().split(',');assert not r.stderr and len(fields)==7,(r.stderr,r.stdout)
  row=dict(repetition=repetition,mode=mode,candidate=candidate,index=int(fields[0]),operation=fields[1],n=int(fields[2]),m=int(fields[3]),loops=int(fields[4]),microseconds=float(fields[5]),checksum=fields[6]);key=case
  if key in expected:assert expected[key]==row['checksum'],(expected[key],row)
  expected[key]=row['checksum'];rows.append(row)
 (OUT/(a.name+'_raw.json')).write_text(json.dumps(rows,indent=2));print(a.name,'round',repetition+1,'rows',len(rows),flush=True)
manifest['finished_unix']=time.time();(OUT/(a.name+'_manifest.json')).write_text(json.dumps(manifest,indent=2))
summary=[]
for mode in modes:
 for case in cases:
  base=statistics.median(r['microseconds']for r in rows if r['mode']==mode and r['index']==case and r['candidate']=='baseline')
  for candidate in candidates:
   selected=[r for r in rows if r['mode']==mode and r['index']==case and r['candidate']==candidate];median=statistics.median(r['microseconds']for r in selected);row={k:selected[0][k]for k in ['mode','candidate','index','operation','n','m']};row.update(median_us=median,ratio=median/base,baseline_us=base);summary.append(row)
(OUT/(a.name+'_summary.json')).write_text(json.dumps(summary,indent=2));print('DONE',manifest['finished_unix']-manifest['started_unix'],flush=True)
