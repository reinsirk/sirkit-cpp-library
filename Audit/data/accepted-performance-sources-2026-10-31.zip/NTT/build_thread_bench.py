from pathlib import Path
import os,subprocess,json,hashlib
D=Path(__file__).parent;OUT=D/'thread_bench';OUT.mkdir(exist_ok=True);os.setsid();(OUT/'runner.pid').write_text(str(os.getpid()));os.sched_setaffinity(0,{4});rows=[]
s=(D/'bench_threshold.cpp').read_text().replace('#include <chrono>','#include <chrono>\n#include <ctime>')
s=s.replace(' const auto start=std::chrono::steady_clock::now();',' timespec cpu_start{},cpu_stop{};\n if(::clock_gettime(CLOCK_THREAD_CPUTIME_ID,&cpu_start)!=0)return 3;\n const auto start=std::chrono::steady_clock::now();')
s=s.replace(' const auto elapsed=std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-start).count()/c.repetitions;',' const auto wall_stop=std::chrono::steady_clock::now();\n if(::clock_gettime(CLOCK_THREAD_CPUTIME_ID,&cpu_stop)!=0)return 3;\n const auto elapsed=std::chrono::duration<double,std::micro>(wall_stop-start).count()/c.repetitions;\n const auto cpu_elapsed=((static_cast<double>(cpu_stop.tv_sec)-cpu_start.tv_sec)*1e9+cpu_stop.tv_nsec-cpu_start.tv_nsec)/1000/c.repetitions;')
s=s.replace('"%zu,%s,%zu,%zu,%d,%.6f,%ju\\n",index,c.name,c.n,c.m,c.repetitions,elapsed,', '"%zu,%s,%zu,%zu,%d,%.6f,%.6f,%ju\\n",index,c.name,c.n,c.m,c.repetitions,elapsed,cpu_elapsed,')
(D/'bench_thread.cpp').write_text(s)
for mode,compiler in {'gcc-default':['/usr/bin/g++'],'gcc-native':['/usr/bin/g++','-march=native'],'clang-default':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'],'clang-native':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-march=native']}.items():
 for candidate in ['baseline','threshold16','threshold32','threshold64','threshold128','vector_radix4']:
  header=D/(candidate+'.hpp');target=OUT/f'{mode}-{candidate}';cmd=compiler+['-std=c++23','-O2','-Wall','-Wextra','-Wpedantic','-Werror','-DSKIP_RUNTIME_CHECKS',f'-DNTT_HEADER="{header}"',str(D/'bench_thread.cpp'),'-o',str(target)]
  a=subprocess.run(cmd,capture_output=True,text=True);row=dict(mode=mode,candidate=candidate,command=cmd,sha256=hashlib.sha256(header.read_bytes()).hexdigest(),exit=a.returncode,stderr=a.stderr);rows.append(row);(OUT/'build.json').write_text(json.dumps(rows,indent=2));print(mode,candidate,a.returncode,flush=True);assert a.returncode==0 and not a.stderr,row
print('24 thread/wall bench ready',flush=True)
