from pathlib import Path
import hashlib
D=Path(__file__).parent;s=(D/'avx2_tile8_roots_lazy_naive.hpp').read_text();scalar=(D/'montgomery_radix4_roots_lazy.hpp').read_text()
start=scalar.index('    template <bool Check>\n    void forward(');end=scalar.index('    template <bool Check>\n    std::vector<std::uint32_t> compute',start);part=scalar[start:end]
condition='!defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__))'
for method in ['forward','backward']:
 needle='void '+method+'(std::vector<std::uint32_t>& a) const {\n        const std::size_t '+('n = a.size();'if method=='forward'else'n=a.size();')
 replacement=needle+'\n#if '+condition+'\n        if constexpr(montgomery_)if(use_avx2(n)){'+method+'_avx2<Check>(a);return;}\n#endif'
 assert needle in part;part=part.replace(needle,replacement,1)
start=s.index('    template <bool Check>\n    void forward(');end=s.index('    template <bool Check>\n    std::vector<std::uint32_t> compute',start);s=s[:start]+part+s[end:]
(D/'combined.hpp').write_text(s);print(hashlib.sha256(s.encode()).hexdigest(),len(s))
