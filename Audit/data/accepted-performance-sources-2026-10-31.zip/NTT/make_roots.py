from pathlib import Path
import hashlib
D=Path(__file__).parent
for name in ['baseline','montgomery','montgomery_radix4','avx2','avx2_tile8']:
 s=(D/(name+'.hpp')).read_text()
 old='''            std::uint32_t value = encode(1);
            for (std::size_t j = 0; j < half; ++j) {
                roots_[half + j] = value; value = working_multiply(value, step);
            }'''
 new='''            for (std::size_t j = 0; j < half/2; ++j) {
                const auto value=roots_[half/2+j];
                roots_[half+2*j]=value;
                roots_[half+2*j+1]=working_multiply(value,step);
            }'''
 if name=='baseline':
  old=old.replace('encode(1)','1').replace('working_multiply','multiply')
  new=new.replace('working_multiply','multiply')
 assert old in s,name
 s=s.replace(old,new)
 out=D/(name+'_roots.hpp');out.write_text(s);print(out.name,hashlib.sha256(s.encode()).hexdigest(),len(s))
