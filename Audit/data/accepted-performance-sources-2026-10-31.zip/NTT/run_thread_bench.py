from pathlib import Path
import subprocess,json,random,hashlib,os,time,statistics,argparse
D=Path(__file__).parent;OUT=D/'thread_bench';os.setsid();os.sched_setaffinity(0,{12});(OUT/'measurement.pid').write_text(str(os.getpid()))
p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('--screen',action='store_true');p.add_argument('--repetitions',type=int,default=5);a=p.parse_args()
modes=['gcc-default','gcc-native','clang-default','clang-native'];candidates=['baseline','control','threshold16','threshold32','threshold64','threshold128','vector_radix4','vector_radix4_threshold16'];cases=list(range(58))
rows=[];rng=random.Random(0x3148cafe);expected={}
manifest={'name':a.name,'started_unix':time.time(),'repetitions':a.repetitions,'modes':modes,'candidates':candidates,'cases':cases,'cpu':12,'bench_sha256':hashlib.sha256((D/'bench_thread.cpp').read_bytes()).hexdigest(),'headers':{c:hashlib.sha256((D/(('baseline'if c=='control'else c)+'.hpp')).read_bytes()).hexdigest()for c in candidates}}
(OUT/(a.name+'_manifest.json')).write_text(json.dumps(manifest,indent=2))
for repetition in range(a.repetitions):
 tasks=[(mode,case,candidate)for mode in modes for case in cases for candidate in candidates];rng.shuffle(tasks)
 for mode,case,candidate in tasks:
  executable=OUT/(mode+'-'+('baseline'if candidate=='control'else candidate));r=subprocess.run([str(executable),str(case)],capture_output=True,text=True,check=True);fields=r.stdout.strip().split(',');assert not r.stderr and len(fields)==8,(r.stderr,r.stdout)
  row=dict(repetition=repetition,mode=mode,candidate=candidate,index=int(fields[0]),operation=fields[1],n=int(fields[2]),m=int(fields[3]),loops=int(fields[4]),microseconds=float(fields[5]),thread_microseconds=float(fields[6]),checksum=fields[7]);key=case
  if key in expected:assert expected[key]==row['checksum'],(expected[key],row)
  expected[key]=row['checksum'];rows.append(row)
 (OUT/(a.name+'_raw.json')).write_text(json.dumps(rows,indent=2));print(a.name,'round',repetition+1,'rows',len(rows),flush=True)
manifest['finished_unix']=time.time();(OUT/(a.name+'_manifest.json')).write_text(json.dumps(manifest,indent=2))
print('RAW_DONE',manifest['finished_unix']-manifest['started_unix'],flush=True)
