from pathlib import Path
import os,subprocess,json,hashlib
D=Path(__file__).parent;OUT=D/'bench';OUT.mkdir(exist_ok=True);os.setsid();(OUT/'runner.pid').write_text(str(os.getpid()));os.sched_setaffinity(0,{4});results=json.loads((OUT/'build.json').read_text()) if (OUT/'build.json').exists() else []
compilers={'gcc-default':['/usr/bin/g++'],'gcc-native':['/usr/bin/g++','-march=native'],'clang-default':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'],'clang-native':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-march=native']}
for mode,compiler in compilers.items():
 for candidate in ['baseline','radix4','montgomery','montgomery_radix4_roots','montgomery_radix4_roots_lazy','avx2','avx2_tile8','avx2_tile8_roots_lazy','baseline_roots','avx2_tile8_roots_lazy_naive']:
  target=OUT/f'{mode}-{candidate}';cmd=compiler+['-std=c++23','-O2','-Wall','-Wextra','-Wpedantic','-Werror','-DSKIP_RUNTIME_CHECKS',f'-DNTT_HEADER="{D/(candidate+".hpp")}"',str(D/'bench.cpp'),'-o',str(target)]
  if target.exists() and target.stat().st_mtime>max((D/'bench.cpp').stat().st_mtime,(D/(candidate+'.hpp')).stat().st_mtime):
   print(mode,candidate,'exists',flush=True);continue
  a=subprocess.run(cmd,capture_output=True,text=True);row=dict(mode=mode,candidate=candidate,sha256=hashlib.sha256((D/(candidate+'.hpp')).read_bytes()).hexdigest(),command=cmd,exit=a.returncode,stderr=a.stderr)
  results.append(row);(OUT/'build.json').write_text(json.dumps(results,indent=2));print(mode,candidate,a.returncode,flush=True);assert a.returncode==0 and not a.stderr,row
print('36 bench binaries ready',flush=True)
