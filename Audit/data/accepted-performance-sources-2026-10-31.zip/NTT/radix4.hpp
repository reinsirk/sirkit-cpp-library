// SPDX-License-Identifier: CC0-1.0
// 参考（NTTの利用範囲・Verify問題。バタフライと所有構造は独自実装）:
// https://nyaannyaan.github.io/library/ntt/ntt.hpp.html
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/ntt.md
//
// API一覧
// NTT<Mod=998244353,Root=3>: Mint不要の素数法NTT。3<=Mod<2^31、Rootは最大2冪位数の根を生成する値。
// NTT(): 根を確保せず生成。コピーは独立、コピーの時間・領域は保持する根の数に比例。
// modulus()/max_length(): 法/対応する最大変換長をO(1)で返す。
// prepare(length): 必要な根を保持。lengthは0または2冪、上限は2^v2(Mod-1)。新規分O(length)時間・保持O(length)。
// transform(a,inverse=false): 正順の係数と正順の周波数を相互変換しvoidを返す。aはuint32_tのvector。
// transformは空または対応する2冪長、各値0..Mod-1が前提。O(n log n)時間、根以外の追加領域O(1)。
// convolution(a,b): 整数vectorを法Modへ正規化し畳み込みを返す。負数/uint64_t最大値も可。空を含めば{}。
// convolution_normalized(a,b): uint32_tの正規化済みvectorを値で受け取り再利用。std::moveで入力領域を譲渡可。
// square(a): 同じ列の畳み込み。大規模では順変換を1回にする。返却値はvector<uint32_t>。
// 畳み込みは短い方32要素以下ならO(nm)、それ以外はL=bit_ceil(n+m-1)としてO(L log L)、追加O(L)。
// NTT経路のLとtransform長は上限以下。長さ・容量の上限検査はSKIP_RUNTIME_CHECKSでも維持。
// ConvolutionMod<Mod,Root>(a,b): 一時NTTを使う簡易版。同じ長さを繰り返すならNTTオブジェクトを再利用する。
// roots_capacity()/clear_cache(): 根の保持数を返す/解放。通常操作は入力不変、transformは例外までの変更が残り得る。

#include <algorithm>
#include <bit>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

#ifndef SIRKIT_NTT_DETAIL_DEFINED
#define SIRKIT_NTT_DETAIL_DEFINED
namespace reinsirk::detail {
constexpr bool ntt_prime(std::uint32_t n) noexcept {
    if (n < 2 || n % 2 == 0) return n == 2;
    for (std::uint32_t d = 3; d <= n / d; d += 2) if (n % d == 0) return false;
    return true;
}
constexpr std::uint32_t ntt_power(std::uint32_t a, std::uint32_t exponent, std::uint32_t mod) noexcept {
    std::uint32_t result = 1;
    for (; exponent != 0; exponent >>= 1) {
        if (exponent & 1) result = static_cast<std::uint32_t>(std::uint64_t{result} * a % mod);
        a = static_cast<std::uint32_t>(std::uint64_t{a} * a % mod);
    }
    return result;
}
}
#endif

#ifndef SIRKIT_NTT_DEFINED
#define SIRKIT_NTT_DEFINED
template <std::uint32_t Mod = 998244353, std::uint32_t Root = 3>
class NTT {
    static_assert(Mod >= 3 && Mod < (std::uint32_t{1} << 31) && reinsirk::detail::ntt_prime(Mod),
                  "NTT modulus must be an odd prime below 2^31");
    static_assert(Root > 0 && Root < Mod, "NTT root outside modulus");
    static constexpr int rank_ = std::countr_zero(Mod - 1);
    static constexpr std::uint32_t highest_root_ = reinsirk::detail::ntt_power(Root, (Mod - 1) >> rank_, Mod);
    static_assert(reinsirk::detail::ntt_power(highest_root_, std::uint32_t{1} << (rank_ - 1), Mod) == Mod - 1,
                  "NTT root has insufficient power-of-two order");
    std::vector<std::uint32_t> roots_;

    static constexpr std::uint32_t multiply(std::uint32_t a, std::uint32_t b) noexcept {
        return static_cast<std::uint32_t>(std::uint64_t{a} * b % Mod);
    }
    static constexpr std::uint32_t add(std::uint32_t a, std::uint32_t b) noexcept {
        const auto sum = a + b;
        return sum >= Mod ? sum - Mod : sum;
    }
    static constexpr std::uint32_t subtract(std::uint32_t a, std::uint32_t b) noexcept {
        return a >= b ? a - b : a + Mod - b;
    }
    template <std::integral T>
    static std::uint32_t normalize(T value) noexcept {
        static_assert(sizeof(T) <= sizeof(std::uint64_t));
        if constexpr (std::is_signed_v<T>) {
            const auto remainder = static_cast<std::int64_t>(value) % static_cast<std::int64_t>(Mod);
            return static_cast<std::uint32_t>(remainder < 0 ? remainder + Mod : remainder);
        } else return static_cast<std::uint32_t>(static_cast<std::uint64_t>(value) % Mod);
    }
    static std::size_t result_size(std::size_t a, std::size_t b) {
        if (a == 0 || b == 0) return 0;
        if (a - 1 > std::numeric_limits<std::size_t>::max() - b)
            throw std::length_error("NTT: convolution size overflow");
        return (a - 1) + b;
    }
    static std::size_t transform_size(std::size_t output) {
        if (output > max_length()) throw std::length_error("NTT: transform too long");
        return std::bit_ceil(output);
    }
    static void bit_reverse(std::vector<std::uint32_t>& a) noexcept {
        const std::size_t n = a.size();
        for (std::size_t i = 1, reverse = 0; i < n; ++i) {
            std::size_t bit = n >> 1;
            for (; reverse & bit; bit >>= 1) reverse ^= bit;
            reverse ^= bit;
            if (i < reverse) std::swap(a[i], a[reverse]);
        }
    }
    template <bool Check>
    void forward(std::vector<std::uint32_t>& a) const {
        const std::size_t n = a.size();
        constexpr auto imaginary = reinsirk::detail::ntt_power(Root, (Mod - 1) / 4, Mod);
        std::size_t length = n;
        for (; length >= 4; length >>= 2) {
            const auto quarter = length / 4;
            for (std::size_t block = 0; block < n; block += length) {
                auto u0=a[block], u1=a[block+quarter], u2=a[block+2*quarter], u3=a[block+3*quarter];
#ifndef SKIP_RUNTIME_CHECKS
                if constexpr (Check) if (length==n && (u0>=Mod || u1>=Mod || u2>=Mod || u3>=Mod))
                    throw std::invalid_argument("NTT: coefficient not normalized");
#endif
                const auto s0=add(u0,u2), s1=add(u1,u3), d0=subtract(u0,u2), d1=multiply(subtract(u1,u3),imaginary);
                a[block]=add(s0,s1); a[block+quarter]=subtract(s0,s1);
                a[block+2*quarter]=add(d0,d1); a[block+3*quarter]=subtract(d0,d1);
                for (std::size_t j=1;j<quarter;++j) {
                    u0=a[block+j];u1=a[block+j+quarter];u2=a[block+j+2*quarter];u3=a[block+j+3*quarter];
#ifndef SKIP_RUNTIME_CHECKS
                    if constexpr (Check) if (length==n && (u0>=Mod || u1>=Mod || u2>=Mod || u3>=Mod))
                        throw std::invalid_argument("NTT: coefficient not normalized");
#endif
                    const auto v0=add(u0,u2),v1=add(u1,u3);
                    const auto v2=multiply(subtract(u0,u2),roots_[2*quarter+j]);
                    const auto v3=multiply(subtract(u1,u3),roots_[3*quarter+j]);
                    a[block+j]=add(v0,v1);
                    a[block+j+quarter]=multiply(subtract(v0,v1),roots_[quarter+j]);
                    a[block+j+2*quarter]=add(v2,v3);
                    a[block+j+3*quarter]=multiply(subtract(v2,v3),roots_[quarter+j]);
                }
            }
        }
        if (length==2) for (std::size_t i=0;i<n;i+=2) {
            const auto u=a[i],v=a[i+1];
#ifndef SKIP_RUNTIME_CHECKS
            if constexpr (Check) if (n==2 && (u>=Mod || v>=Mod))
                throw std::invalid_argument("NTT: coefficient not normalized");
#endif
            a[i]=add(u,v);a[i+1]=subtract(u,v);
        }
    }
    template <bool Check>
    void backward(std::vector<std::uint32_t>& a) const {
        const std::size_t n=a.size();
        constexpr auto imaginary = reinsirk::detail::ntt_power(Root, (Mod - 1) / 4, Mod);
        std::size_t completed=1;
        for (std::size_t length=4;length<=n;) {
            const auto quarter=length/4;
            for(std::size_t block=0;block<n;block+=length) {
                auto u0=a[block],u1=a[block+quarter],u2=a[block+2*quarter],u3=a[block+3*quarter];
#ifndef SKIP_RUNTIME_CHECKS
                if constexpr(Check) if(length==4&&(u0>=Mod||u1>=Mod||u2>=Mod||u3>=Mod))
                    throw std::invalid_argument("NTT: coefficient not normalized");
#endif
                const auto s0=add(u0,u1),d0=subtract(u0,u1),s1=add(u2,u3),d1=multiply(subtract(u2,u3),imaginary);
                a[block]=add(s0,s1);a[block+quarter]=add(d0,d1);
                a[block+2*quarter]=subtract(s0,s1);a[block+3*quarter]=subtract(d0,d1);
                for(std::size_t j=1;j<quarter;++j) {
                    u0=a[block+j];u1=a[block+j+quarter];u2=a[block+j+2*quarter];u3=a[block+j+3*quarter];
#ifndef SKIP_RUNTIME_CHECKS
                    if constexpr(Check) if(length==4&&(u0>=Mod||u1>=Mod||u2>=Mod||u3>=Mod))
                        throw std::invalid_argument("NTT: coefficient not normalized");
#endif
                    u1=multiply(u1,roots_[quarter+j]);u3=multiply(u3,roots_[quarter+j]);
                    const auto v0=add(u0,u1),v1=subtract(u0,u1);
                    const auto v2=multiply(add(u2,u3),roots_[2*quarter+j]);
                    const auto v3=multiply(subtract(u2,u3),roots_[3*quarter+j]);
                    a[block+j]=add(v0,v2);a[block+j+quarter]=add(v1,v3);
                    a[block+j+2*quarter]=subtract(v0,v2);a[block+j+3*quarter]=subtract(v1,v3);
                }
            }
            completed=length;
            if(length>n/4)break;
            length*=4;
        }
        if(completed<n) {
            const auto half=n/2;
            const auto u=a[0],v=a[half];
#ifndef SKIP_RUNTIME_CHECKS
            if constexpr(Check) if(n==2&&(u>=Mod||v>=Mod))
                throw std::invalid_argument("NTT: coefficient not normalized");
#endif
            a[0]=add(u,v);a[half]=subtract(u,v);
            for(std::size_t j=1;j<half;++j) {
                const auto x=a[j],y=multiply(a[j+half],roots_[half+j]);
                a[j]=add(x,y);a[j+half]=subtract(x,y);
            }
        }
        const auto inverse_n=reinsirk::detail::ntt_power(static_cast<std::uint32_t>(n),Mod-2,Mod);
        a[0]=multiply(a[0],inverse_n);
        for(std::size_t i=1;i<n-i;++i) {
            const auto lo=multiply(a[i],inverse_n),hi=multiply(a[n-i],inverse_n);
            a[i]=hi;a[n-i]=lo;
        }
        if(n>1)a[n/2]=multiply(a[n/2],inverse_n);
    }
    template <bool Check>
    std::vector<std::uint32_t> compute(std::vector<std::uint32_t> a, std::vector<std::uint32_t> b) {
        const std::size_t output = result_size(a.size(), b.size());
        if (output == 0) return {};
        if (std::min(a.size(), b.size()) <= 32) {
            std::vector<std::uint32_t> result(output);
            for (std::size_t i = 0; i < a.size(); ++i) {
#ifndef SKIP_RUNTIME_CHECKS
                if constexpr (Check) if (a[i] >= Mod) throw std::invalid_argument("NTT: coefficient not normalized");
#endif
                for (std::size_t j = 0; j < b.size(); ++j) {
#ifndef SKIP_RUNTIME_CHECKS
                    if constexpr (Check) if (i == 0 && b[j] >= Mod)
                        throw std::invalid_argument("NTT: coefficient not normalized");
#endif
                    result[i + j] = add(result[i + j], multiply(a[i], b[j]));
                }
            }
            return result;
        }
        const auto length = transform_size(output);
        prepare(length);
        a.resize(length); b.resize(length);
        forward<Check>(a); forward<Check>(b);
        for (std::size_t i = 0; i < length; ++i) a[i] = multiply(a[i], b[i]);
        backward<false>(a); a.resize(output);
        return a;
    }

public:
    static constexpr std::uint32_t modulus() noexcept { return Mod; }
    static constexpr std::size_t max_length() noexcept { return std::size_t{1} << rank_; }
    [[nodiscard]] std::size_t roots_capacity() const noexcept { return roots_.size(); }
    void clear_cache() noexcept { std::vector<std::uint32_t>{}.swap(roots_); }
    void prepare(std::size_t length) {
        if (length == 0) return;
        if (!std::has_single_bit(length) || length > max_length())
            throw std::length_error("NTT: length must be a supported power of two");
        if (length <= 1 || length <= roots_.size()) return;
        const std::size_t previous = std::max<std::size_t>(2, roots_.size());
        roots_.resize(length); roots_[1] = 1;
        for (std::size_t half = previous; half < length; half <<= 1) {
            const auto step = reinsirk::detail::ntt_power(Root, static_cast<std::uint32_t>((Mod - 1) / (half * 2)), Mod);
            std::uint32_t value = 1;
            for (std::size_t j = 0; j < half; ++j) {
                roots_[half + j] = value; value = multiply(value, step);
            }
        }
    }
    void transform(std::vector<std::uint32_t>& a, bool inverse = false) {
        if (a.empty()) return;
        prepare(a.size());
        if (a.size() == 1) {
#ifndef SKIP_RUNTIME_CHECKS
            if (a[0] >= Mod) throw std::invalid_argument("NTT: coefficient not normalized");
#endif
            return;
        }
        if (inverse) { bit_reverse(a); backward<true>(a); }
        else { forward<true>(a); bit_reverse(a); }
    }
    template <std::integral T, std::integral U>
    std::vector<std::uint32_t> convolution(const std::vector<T>& a, const std::vector<U>& b) {
        if (a.empty() || b.empty()) return {};
        const auto output = result_size(a.size(), b.size());
        if (std::min(a.size(), b.size()) > 32) (void)transform_size(output);
        std::vector<std::uint32_t> x(a.size()), y(b.size());
        for (std::size_t i = 0; i < a.size(); ++i) x[i] = normalize<T>(a[i]);
        for (std::size_t i = 0; i < b.size(); ++i) y[i] = normalize<U>(b[i]);
        return compute<false>(std::move(x), std::move(y));
    }
    std::vector<std::uint32_t> convolution_normalized(std::vector<std::uint32_t> a,
                                                      std::vector<std::uint32_t> b) {
        return compute<true>(std::move(a), std::move(b));
    }
    template <std::integral T>
    std::vector<std::uint32_t> square(const std::vector<T>& a) {
        if (a.size() <= 32) return convolution(a, a);
        const auto output = result_size(a.size(), a.size()), length = transform_size(output);
        prepare(length);
        std::vector<std::uint32_t> x(length);
        for (std::size_t i = 0; i < a.size(); ++i) x[i] = normalize<T>(a[i]);
        forward<false>(x);
        for (auto& value : x) value = multiply(value, value);
        backward<false>(x); x.resize(output);
        return x;
    }
};
#endif

#ifndef SIRKIT_CONVOLUTION_MOD_DEFINED
#define SIRKIT_CONVOLUTION_MOD_DEFINED
template <std::uint32_t Mod = 998244353, std::uint32_t Root = 3, std::integral T, std::integral U>
std::vector<std::uint32_t> ConvolutionMod(const std::vector<T>& a, const std::vector<U>& b) {
    return NTT<Mod, Root>{}.convolution(a, b);
}
#endif
