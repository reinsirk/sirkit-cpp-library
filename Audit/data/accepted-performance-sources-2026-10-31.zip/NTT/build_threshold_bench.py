from pathlib import Path
import os,subprocess,json,hashlib
D=Path(__file__).parent;OUT=D/'threshold_bench';OUT.mkdir(exist_ok=True);os.setsid();(OUT/'runner.pid').write_text(str(os.getpid()));os.sched_setaffinity(0,{4});rows=[]
s=(D/'bench.cpp').read_text();s=s.replace('{"samealias",524288,0,1}', '{"samealias",524288,0,1},\n'+','.join('{"'+op+'",'+str(n)+',0,1000}'for op in ['forward','inverse','roundtrip']for n in [16,32,64,256])+',\n{"generic",17,17,3000}')
s=s.replace(' const auto start=std::chrono', ' if(operation=="forward"||operation=="roundtrip")engine.prepare(c.n);\n const auto start=std::chrono');(D/'bench_threshold.cpp').write_text(s)
for mode,compiler in {'gcc-default':['/usr/bin/g++'],'gcc-native':['/usr/bin/g++','-march=native'],'clang-default':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'],'clang-native':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-march=native']}.items():
 for candidate in ['baseline','threshold16','threshold32','threshold64','threshold128','vector_radix4']:
  header=D/(candidate+'.hpp');target=OUT/f'{mode}-{candidate}';cmd=compiler+['-std=c++23','-O2','-Wall','-Wextra','-Wpedantic','-Werror','-DSKIP_RUNTIME_CHECKS',f'-DNTT_HEADER="{header}"',str(D/'bench_threshold.cpp'),'-o',str(target)]
  a=subprocess.run(cmd,capture_output=True,text=True);row=dict(mode=mode,candidate=candidate,command=cmd,sha256=hashlib.sha256(header.read_bytes()).hexdigest(),exit=a.returncode,stderr=a.stderr);rows.append(row);(OUT/'build.json').write_text(json.dumps(rows,indent=2));print(mode,candidate,a.returncode,flush=True);assert a.returncode==0 and not a.stderr,row
print('24 threshold bench ready',flush=True)
