from pathlib import Path
D=Path(__file__).parent;s=(D/'boundary_reference_test.cpp').read_text()
extra=r'''
template<std::uint32_t Mod,std::uint32_t Root>void large_more(std::mt19937_64& rng){
 NTT<Mod,Root> engine;constexpr std::size_t n=65536,m=32769;
 std::vector<std::uint32_t>a(n,1),b(m,1);const auto c=engine.convolution_normalized(a,b);
 for(std::size_t i=0;i<c.size();++i)check(c[i]==std::min({i+1,n,m,n+m-1-i}));
 check(engine.square(a)==engine.convolution_normalized(a,a));
 std::vector<std::uint32_t>v(131072);for(auto&x:v)x=static_cast<std::uint32_t>(rng()%Mod);const auto saved=v;engine.transform(v);engine.transform(v,true);check(v==saved);
 engine.prepare(262144);const auto capacity=engine.roots_capacity();NTT<Mod,Root>copy=engine;engine.clear_cache();check(engine.roots_capacity()==0&&copy.roots_capacity()==capacity);auto moved=std::move(copy);auto c2=moved.convolution_normalized(a,b);check(c2==c);copy.prepare(16);check(copy.roots_capacity()>=16);
#ifndef SKIP_RUNTIME_CHECKS
 for(bool swapped:{false,true})for(std::size_t position=0;position<263;++position){std::vector<std::uint32_t>x(3,1),y(263,1);y[position]=UINT32_MAX;if(swapped)x.swap(y);rejects<std::invalid_argument>([&]{engine.convolution_normalized(x,y);});}
#endif
}
'''
s=s.replace('boundary<2013265921,31>(rng);','boundary<2013265921,31>(rng);boundary<17,3>(rng);boundary<3,2>(rng);')
s=s.replace('int main(){',extra+'\nint main(){',1)
s=s.replace('test_mod<998244353,3>(rng);','large_more<998244353,3>(rng);large_more<167772161,3>(rng);large_more<469762049,3>(rng);large_more<754974721,11>(rng);large_more<1053818881,7>(rng);large_more<1224736769,3>(rng);large_more<2013265921,31>(rng);test_mod<998244353,3>(rng);',1)
(D/'final_reference_test.cpp').write_text(s)
