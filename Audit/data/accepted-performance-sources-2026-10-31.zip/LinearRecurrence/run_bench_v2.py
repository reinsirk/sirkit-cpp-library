from pathlib import Path
import subprocess,json,hashlib,random,time,resource
w=Path(__file__).resolve().parent;build=[r for r in json.loads((w/'build.json').read_text()) if r['candidate']=='baseline']+json.loads((w/'build_v2.json').read_text());rows=[];expected={};randomizer=random.Random(18032027)
cases=[(0,0,1000),(1,0,2000),(1,2**64-1,500),(8,3,500),(8,2**64-1,50),(15,2**64-1,30),(16,2**64-1,30),(64,2**64-1,3),(256,2**64-1,1),(1024,0,1000),(1024,511,1),(1024,1023,1),(1024,1024,1),(16,16,1000)]
for repeat in range(7):
 for compiler in ('gcc','clang'):
  for native in (False,True):
   variants=[r for r in build if r['compiler']==compiler and r['native']==native];variants +=[{**r,'candidate':'control'}for r in variants if r['candidate']=='baseline'];randomizer.shuffle(variants)
   for r in variants:
    assert hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()==r['binary_sha256']
    for d,k,q in cases:
     before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.perf_counter_ns();run=subprocess.run(['taskset','-c','12',r['path'],str(d),str(k),str(q)],capture_output=True,text=True,check=True,timeout=180);wall=time.perf_counter_ns()-start;after=resource.getrusage(resource.RUSAGE_CHILDREN);measure=json.loads(run.stdout);key=(d,k,q);expected.setdefault(key,measure['checksum']);assert expected[key]==measure['checksum'];rows.append({**r,**measure,'d':d,'k':k,'q':q,'repeat':repeat,'process_cpu_ns':round(((after.ru_utime+after.ru_stime)-(before.ru_utime+before.ru_stime))*1e9),'process_wall_ns':wall})
   (w/'raw_v2.json').write_text(json.dumps(rows,indent=2));print(repeat,compiler,native,'PASS',flush=True)
