from pathlib import Path
import subprocess,json,hashlib
w=Path(__file__).resolve().parent;rows=[]
for compiler in ('gcc','clang'):
 for native in (False,True):
  for candidate in ('baseline','normal_shortcut','clang_weights'):
   prefix=['/usr/bin/g++']if compiler=='gcc'else['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'];exe=w/(compiler+str(native)+candidate);source=w/(candidate+'.hpp');command=['taskset','-c','10']+prefix+['-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS','-DHEADER="'+str(source)+'"']+(['-march=native']if native else[])+[str(w/'weights_bench.cpp'),'-o',str(exe)];run=subprocess.run(command,capture_output=True,text=True,timeout=180);row=dict(compiler=compiler,native=native,candidate=candidate,command=command,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),build_exit=run.returncode,diagnostics=run.stdout+run.stderr,path=str(exe))
   if run.returncode==0:row['binary_sha256']=hashlib.sha256(exe.read_bytes()).hexdigest()
   rows.append(row);(w/'build.json').write_text(json.dumps(rows,indent=2));print(compiler,native,candidate,run.returncode,flush=True)
   if run.returncode:raise SystemExit(1)
