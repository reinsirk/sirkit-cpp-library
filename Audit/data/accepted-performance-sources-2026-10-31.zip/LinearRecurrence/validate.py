from pathlib import Path
import subprocess,json,hashlib,os,time
r=Path('/home/reinsirk/Atcoder_Env');w=Path(__file__).resolve().parent;out=w/'validation';out.mkdir(exist_ok=True);rows=[]
for candidate in ('normal_shortcut','clang_weights'):
 for compiler in ('gcc','clang'):
  for skip in (False,True):
   for mode in ('default','native','sanitize'):
    fixtures=['linear_recurrence_reference_test.cpp']+(['linear_recurrence_allocation_test.cpp']if mode=='default'else[])
    for fixture_name in fixtures:
     while(w/'pause').exists():(w/'pause_ack').write_text('paused');time.sleep(.1)
     (w/'pause_ack').unlink(missing_ok=True)
     header=w/(candidate+'.hpp');fixture=r/'Verify/current/tests'/fixture_name
     defines=['-DRECURRENCE_HEADER="'+str(header)+'"','-DHEADER="'+str(header)+'"']
     prefix=['/usr/bin/g++']if compiler=='gcc'else['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
     flags=['-std=c++23','-O2']+defines+(['-DSKIP_RUNTIME_CHECKS']if skip else[])+(['-march=native']if mode=='native'else[])
     if mode=='sanitize':flags+=['-O1','-fsanitize=address,undefined','-fno-omit-frame-pointer']
     exe=out/(candidate+compiler+str(skip)+mode+fixture.stem);command=['taskset','-c','2']+prefix+flags+[str(fixture),'-o',str(exe)];built=subprocess.run(command,capture_output=True,text=True,timeout=240);row=dict(candidate=candidate,compiler=compiler,skip=skip,mode=mode,fixture=str(fixture),fixture_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),source_sha256=hashlib.sha256(header.read_bytes()).hexdigest(),command=command,build_exit=built.returncode,diagnostics=built.stdout+built.stderr)
     if built.returncode==0:
      env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=0';run=subprocess.run(['taskset','-c','2',str(exe)],capture_output=True,text=True,env=env,timeout=240);row.update(run_exit=run.returncode,stdout=run.stdout,stderr=run.stderr)
     rows.append(row);(out/'results.json').write_text(json.dumps(rows,indent=2));print(candidate,compiler,skip,mode,fixture.stem,row.get('run_exit',1),flush=True)
     if row['build_exit']or row.get('run_exit',1):raise SystemExit(1)
