// SPDX-License-Identifier: CC0-1.0
#ifndef HEADER
#define HEADER "baseline.cpp"
#endif
#include HEADER
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <random>
[[gnu::noinline]] Matrix<std::uint32_t> product(const Matrix<std::uint32_t>&a,const Matrix<std::uint32_t>&b) {
    asm volatile("":::"memory");return a*b;
}
int main(int argc,char**argv) {
    if(argc!=5)return 2;
    const int loops=static_cast<int>(std::strtoul(argv[4],nullptr,10));if(loops<=0)return 2;
    const auto rows=static_cast<std::size_t>(std::strtoull(argv[1],nullptr,10)),inner=static_cast<std::size_t>(std::strtoull(argv[2],nullptr,10)),columns=static_cast<std::size_t>(std::strtoull(argv[3],nullptr,10));
    std::mt19937_64 rng(91827);Matrix<std::uint32_t>a(rows,inner),b(inner,columns);
    for(auto&x:a.values())x=static_cast<std::uint32_t>(rng());for(auto&x:b.values())x=static_cast<std::uint32_t>(rng());
    timespec before{},after{};clock_gettime(CLOCK_THREAD_CPUTIME_ID,&before);const auto start=std::chrono::steady_clock::now();
    Matrix<std::uint32_t> c;for(int rep=0;rep<loops;++rep)c=product(a,b);asm volatile("":::"memory");const auto stop=std::chrono::steady_clock::now();clock_gettime(CLOCK_THREAD_CPUTIME_ID,&after);
    std::uint64_t checksum=c.size();for(auto x:c.values())checksum=checksum*UINT64_C(11995408973635179863)+x;
    std::printf("%zu,%zu,%zu,%.6f,%.6f,%ju\n",rows,inner,columns,std::chrono::duration<double,std::micro>(stop-start).count()/loops,((after.tv_sec-before.tv_sec)*1e6+(after.tv_nsec-before.tv_nsec)/1000.0)/loops,static_cast<std::uintmax_t>(checksum));
}
