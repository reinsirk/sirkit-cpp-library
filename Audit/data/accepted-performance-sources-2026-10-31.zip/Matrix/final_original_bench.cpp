// SPDX-License-Identifier: CC0-1.0
#ifndef HEADER
#define HEADER "baseline.cpp"
#endif
#include HEADER
#include "/tmp/sirkit_12h_20261031_095733/matrix_optimization/verify_field.hpp"
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <random>
#include <type_traits>
struct Field2 {
 std::uint32_t value=0;Field2()=default;Field2(std::uint64_t x):value(static_cast<std::uint32_t>(x&1)){}
 std::uint32_t get()const noexcept{return value;}
 Field2&operator+=(Field2 b){value^=b.value;return *this;}friend Field2 operator*(Field2 a,Field2 b){return Field2(a.value&b.value);}
};
#ifndef METHOD
#define METHOD 0
#endif
template<class T>[[gnu::noinline]]Matrix<T> product(const Matrix<T>&a,const Matrix<T>&b){
 asm volatile("":::"memory");
#if METHOD==0
 return a*b;
#else
 Matrix<T>c(a.rows(),b.cols());
#if METHOD==1
 for(std::size_t i=0;i<a.rows();++i)for(std::size_t j=0;j<b.cols();++j)for(std::size_t k=0;k<a.cols();++k)c.row(i)[j]+=a.row(i)[k]*b.row(k)[j];
#else
 constexpr std::size_t block=32;
 for(std::size_t ii=0;ii<a.rows();ii+=block)for(std::size_t kk=0;kk<a.cols();kk+=block)for(std::size_t jj=0;jj<b.cols();jj+=block)
  for(std::size_t i=ii;i<std::min(a.rows(),ii+block);++i){const auto left=a.row(i);auto output=c.row(i);for(std::size_t k=kk;k<std::min(a.cols(),kk+block);++k){const T coefficient=left[k];const auto right=b.row(k);for(std::size_t j=jj;j<std::min(b.cols(),jj+block);++j)output[j]+=coefficient*right[j];}}
#endif
 return c;
#endif
}
static volatile std::uint64_t sink=0;
template<class T>void run(std::size_t index){const auto local=index%6;const std::size_t sizes[]={16,64,192,384};const auto m=local<4?sizes[local]:(local==4?std::size_t{16}:std::size_t{384});const auto k=local<4?sizes[local]:std::size_t{256};const auto n=local<4?sizes[local]:(local==4?std::size_t{384}:std::size_t{16});const int loops=(local==0?500:(local==1?20:1))*(std::is_same_v<T,std::uint32_t>?8:1);std::mt19937_64 rng(14);Matrix<T>a(m,k),b(k,n);for(auto&x:a.values())x=T(rng()%7);for(auto&x:b.values())x=T(rng()%7);Matrix<T>c;timespec before{},after{};clock_gettime(CLOCK_THREAD_CPUTIME_ID,&before);const auto start=std::chrono::steady_clock::now();for(int rep=0;rep<loops;++rep)c=product(a,b);asm volatile("":::"memory");const auto stop=std::chrono::steady_clock::now();clock_gettime(CLOCK_THREAD_CPUTIME_ID,&after);std::uint64_t checksum=c.size();for(const auto&x:c.values()){if constexpr(std::is_integral_v<T>)checksum=checksum*UINT64_C(11995408973635179863)+x;else checksum=checksum*UINT64_C(11995408973635179863)+x.get();}sink=checksum;std::printf("%zu,%zu,%zu,%zu,%d,%.6f,%.6f,%ju\n",index,m,k,n,loops,std::chrono::duration<double,std::micro>(stop-start).count()/loops,((after.tv_sec-before.tv_sec)*1e6+(after.tv_nsec-before.tv_nsec)/1000.0)/loops,static_cast<std::uintmax_t>(checksum));}
int main(int argc,char**argv){if(argc!=2)return 2;const auto index=static_cast<std::size_t>(std::strtoul(argv[1],nullptr,10));if(index<6)run<std::uint32_t>(index);else if(index<12)run<Field2>(index);else if(index<18)run<VerifyMatrixField>(index);else return 2;}
