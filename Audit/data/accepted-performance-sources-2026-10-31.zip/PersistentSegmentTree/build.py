from pathlib import Path
import subprocess,json,hashlib,os
root=Path('/home/reinsirk/Atcoder_Env');work=Path(__file__).resolve().parent
names=['buffer_raw','vector_raw','buffer_raw_noinline','vector_raw_noinline','buffer_memcpy','buffer_unique']
records=[]
for compiler in ('gcc','clang'):
 for name in names:
  source=work/(name+'.hpp')
  prefix=['/usr/bin/g++'] if compiler=='gcc' else ['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
  for native in (False,True):
   exe=work/(compiler+str(native)+'_'+name)
   cmd=['taskset','-c','2']+prefix+['-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS','-DSTORAGE_KIND=3','-DSTORAGE_LIBRARY="'+str(source)+'"']+(['-march=native'] if native else [])+[str(root/'Audit/Benchmarks/fast_storage.cpp'),'-o',str(exe)]
   run=subprocess.run(cmd,capture_output=True,text=True,timeout=240)
   row={'compiler':compiler,'native':native,'variant':name,'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'command':cmd,'build_exit':run.returncode,'diagnostics':run.stdout+run.stderr,'executable':str(exe)}
   records.append(row);(work/'build.json').write_text(json.dumps(records,indent=2));print(compiler,native,name,run.returncode,flush=True)
   if run.returncode:raise SystemExit(1)
   row['executable_sha256']=hashlib.sha256(exe.read_bytes()).hexdigest()
  fixture=root/'Verify/current/tests/persistent_tree_pruefer_reference_test.cpp'
  exe=work/(compiler+'_test_'+name)
  cmd=['taskset','-c','2']+prefix+['-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS','-DPERSISTENT_SEGMENT_TREE_SOURCE="'+str(source)+'"',str(fixture),'-o',str(exe)]
  run=subprocess.run(cmd,capture_output=True,text=True,timeout=240)
  row={'compiler':compiler,'variant':name,'test':str(fixture),'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'command':cmd,'build_exit':run.returncode,'diagnostics':run.stdout+run.stderr}
  if run.returncode==0:
   run=subprocess.run(['taskset','-c','2',str(exe)],capture_output=True,text=True,timeout=180);row.update(run_exit=run.returncode,stdout=run.stdout,stderr=run.stderr)
  records.append(row);(work/'build.json').write_text(json.dumps(records,indent=2));print(compiler,'test',name,row.get('run_exit',1),flush=True)
  if row['build_exit'] or row.get('run_exit',1):raise SystemExit(1)
(work/'build.json').write_text(json.dumps(records,indent=2))
