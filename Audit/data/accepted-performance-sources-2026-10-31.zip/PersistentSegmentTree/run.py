from pathlib import Path
import subprocess,json,hashlib,resource,time,random,shutil
work=Path(__file__).resolve().parent;old=Path('/tmp/sirkit_12h_20261031_095733/fast_storage_bench')
records=json.loads((work/'build.json').read_text())+json.loads((work/'iterative_build.json').read_text())
lookup={(r['compiler'],r['native'],r['variant']):r for r in records if 'executable' in r}
normal={(r['compiler'],r['native']):r for r in json.loads((old/'build.json').read_text()) if r['kind']==3 and not r['fast']}
for r in list(lookup.values())+list(normal.values()):
 assert hashlib.sha256(Path(r['executable']).read_bytes()).hexdigest()==r['executable_sha256']
variants=list(dict.fromkeys(r['variant'] for r in lookup.values()));rng=random.Random(20261031);rows=[];active=work/'active'
for compiler in ('gcc','clang'):
 for native in (False,True):
  for n,q in [(32,200000),(4096,200000),(65536,120000)]:
   for op in (0,1):
    for repeat in range(3):
     labels=['normal','control']+variants;rng.shuffle(labels);checks=[]
     for label in labels:
      r=normal[compiler,native] if label in ('normal','control') else lookup[compiler,native,label]
      shutil.copyfile(r['executable'],active);active.chmod(0o700);seed=734021+repeat
      before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.perf_counter_ns()
      run=subprocess.run(['taskset','-c','12',str(active),str(n),str(q),str(seed),str(op)],capture_output=True,text=True,timeout=180)
      elapsed=time.perf_counter_ns()-start;after=resource.getrusage(resource.RUSAGE_CHILDREN)
      if run.returncode:raise RuntimeError(run.stderr)
      row=json.loads(run.stdout);checks.append(row['checksum']);row.update(compiler=compiler,native=native,n=n,q=q,operation=op,repeat=repeat,label=label,seed=seed,executable_sha256=r['executable_sha256'],process_wall_ns=elapsed,process_user_ns=round((after.ru_utime-before.ru_utime)*1e9),process_system_ns=round((after.ru_stime-before.ru_stime)*1e9),process_minor_faults=after.ru_minflt-before.ru_minflt,process_major_faults=after.ru_majflt-before.ru_majflt);rows.append(row)
     assert len(set(checks))==1
    (work/'raw.json').write_text(json.dumps(rows,indent=2));print(compiler,native,n,op,'PASS',flush=True)
