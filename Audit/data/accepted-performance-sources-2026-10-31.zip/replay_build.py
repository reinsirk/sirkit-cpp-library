# SPDX-License-Identifier: CC0-1.0
"""凍結記録を変更せず、NTT/FastStorageの同じfixtureとflagsを別ディレクトリへビルドする。"""
from pathlib import Path
import argparse,json,subprocess
p=argparse.ArgumentParser();p.add_argument('group',choices=['ntt','fast-storage']);p.add_argument('destination',type=Path);p.add_argument('--compile-cpu',type=int,default=4);p.add_argument('--match',help='Only build output names containing this text');a=p.parse_args();root=Path(__file__).resolve().parent;destination=a.destination.resolve();destination.mkdir(parents=True,exist_ok=False)
manifest=json.loads((root/'manifest.json').read_text());mapping={e['original_path']:str(root/name)for name,e in manifest['payloads'].items()}
file=root/('NTT/thread_bench/build.json'if a.group=='ntt'else'FastStorage/build.json');rows=json.loads(file.read_text());commands=[]
if a.group=='ntt':
 # Original24build records precede the selected threshold+radix4 combination. Add its4 builds with exactly the same fixture/flags.
 rows +=[{**r,'candidate':'vector_radix4_threshold16','command':[v.replace('baseline.hpp','vector_radix4_threshold16.hpp').replace('-baseline','-vector_radix4_threshold16')for v in r['command']]}for r in rows if r['candidate']=='baseline']
for r in rows:
 command=list(r['command']);old_output=command[command.index('-o')+1]
 if a.match and a.match not in Path(old_output).name:continue
 for i,v in enumerate(command):
  for old,new in sorted(mapping.items(),key=lambda e:-len(e[0])):v=v.replace(old,new)
  command[i]=v
 command[command.index('-o')+1]=str(destination/Path(old_output).name)
 commands.append(command)
for command in commands:subprocess.run(['taskset','-c',str(a.compile_cpu)]+command,check=True)
(destination/'replayed_commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print('Built',len(commands),'same-fixture executables. No timing run performed; request an isolated P-Core window before benchmarking.')
