from pathlib import Path
import os,subprocess,json,time
D=Path(__file__).parent;OUT=D/'lifecycle_bench';OUT.mkdir(exist_ok=True);os.setsid();os.sched_setaffinity(0,{4});rows=[]
def pause():
 while(D/'pause').exists():
  (D/'pause_ack').write_text('build paused');time.sleep(.1)
 (D/'pause_ack').unlink(missing_ok=True)
for compiler,base in {'GCC':['/usr/bin/g++'],'Clang':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']}.items():
 for native in [False,True]:
  for disabled in [False,True]:
   for candidate in ['baseline','A','B','BP','BE','BPE']:
    pause();mode=compiler+('-native'if native else'-default')+('-nosimd'if disabled else'');target=OUT/(mode+'-'+candidate);cmd=base+['-std=c++23','-O2','-Wall','-Wextra','-Wpedantic','-Werror','-DSKIP_RUNTIME_CHECKS']+(['-march=native']if native else[])+(['-DSIRKIT_DISABLE_SIMD']if disabled else[])+[f'-DMAP_HEADER="{D/compiler/(candidate+"_Hash_map.cpp")}"',f'-DSET_HEADER="{D/compiler/(candidate+"_Hash_set.cpp")}"',str(D/'bench_lifecycle.cpp'),'-o',str(target)]
    a=subprocess.run(cmd,capture_output=True,text=True);row=dict(mode=mode,candidate=candidate,command=cmd,exit=a.returncode,stderr=a.stderr);rows.append(row);(OUT/'build.json').write_text(json.dumps(rows,indent=2));print(mode,candidate,a.returncode,flush=True);assert a.returncode==0 and not a.stderr,row
pause();print('24 hash bench ready',flush=True)
