from pathlib import Path
D=Path(__file__).parent;s=(D/'bench_lifecycle.cpp').read_text()
extra=r'''
#include <new>
#include <sys/resource.h>
namespace {std::uint64_t allocations=0,requested=0,deallocations=0;std::uint64_t measured_allocations=0,measured_requested=0,measured_deallocations=0;std::int64_t measured_minor=0,measured_major=0;}
void*operator new(std::size_t n){++allocations;requested+=n;if(void*p=std::malloc(n?n:1))return p;throw std::bad_alloc();}
void*operator new[](std::size_t n){return ::operator new(n);}
void operator delete(void*p)noexcept{if(p){++deallocations;std::free(p);}}
void operator delete(void*p,std::size_t)noexcept{::operator delete(p);}
void operator delete[](void*p)noexcept{::operator delete(p);}
void operator delete[](void*p,std::size_t)noexcept{::operator delete(p);}
void*operator new(std::size_t n,std::align_val_t a){++allocations;requested+=n;void*p=nullptr;if(::posix_memalign(&p,static_cast<std::size_t>(a),n?n:1)==0)return p;throw std::bad_alloc();}
void*operator new[](std::size_t n,std::align_val_t a){return ::operator new(n,a);}
void operator delete(void*p,std::align_val_t)noexcept{::operator delete(p);}
void operator delete(void*p,std::size_t,std::align_val_t)noexcept{::operator delete(p);}
void operator delete[](void*p,std::align_val_t)noexcept{::operator delete(p);}
void operator delete[](void*p,std::size_t,std::align_val_t)noexcept{::operator delete(p);}
'''
s=s.replace('namespace {\nvolatile',extra+'\nnamespace {\nvolatile',1)
s=s.replace(' timespec start_cpu{};', ' std::uint64_t a0{},r0{},d0{};rusage usage0{};\n timespec start_cpu{};',1)
s=s.replace(' Timer(){if(', ' Timer(){if(::getrusage(RUSAGE_SELF,&usage0))std::abort();a0=allocations;r0=requested;d0=deallocations;if(',1)
s=s.replace('return{std::chrono::duration<double,std::micro>', 'rusage usage1{};if(::getrusage(RUSAGE_SELF,&usage1))std::abort();measured_allocations=allocations-a0;measured_requested=requested-r0;measured_deallocations=deallocations-d0;measured_minor=usage1.ru_minflt-usage0.ru_minflt;measured_major=usage1.ru_majflt-usage0.ru_majflt;return{std::chrono::duration<double,std::micro>',1)
s=s.replace('"%zu,%d,%d,%zu,%d,%.6f,%.6f,%ju\\n"','"%zu,%d,%d,%zu,%d,%.6f,%.6f,%ju,%ju,%ju,%ju,%jd,%jd\\n"')
s=s.replace('static_cast<std::uintmax_t>(checksum));','static_cast<std::uintmax_t>(checksum),static_cast<std::uintmax_t>(measured_allocations),static_cast<std::uintmax_t>(measured_requested),static_cast<std::uintmax_t>(measured_deallocations),static_cast<std::intmax_t>(measured_minor),static_cast<std::intmax_t>(measured_major));')
s=s.replace('void*operator new','[[gnu::noinline]]void*operator new').replace('void operator delete','[[gnu::noinline]]void operator delete')
(D/'bench_stats.cpp').write_text(s)
