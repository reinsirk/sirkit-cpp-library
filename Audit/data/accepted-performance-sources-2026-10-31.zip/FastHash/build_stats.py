from pathlib import Path
import os,subprocess,json,time
D=Path(__file__).parent;OUT=D/'stats';OUT.mkdir(exist_ok=True);os.sched_setaffinity(0,{4});rows=[]
for compiler,base in {'GCC':['/usr/bin/g++'],'Clang':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']}.items():
 for candidate in ['baseline','B','BP','BE','BPE']:
  while(D/'pause').exists():(D/'pause_ack').write_text('stats build paused');time.sleep(.1)
  (D/'pause_ack').unlink(missing_ok=True)
  target=OUT/(compiler+'-'+candidate);cmd=base+['-std=c++23','-O2','-Wall','-Wextra','-Wpedantic','-Werror','-DSKIP_RUNTIME_CHECKS',f'-DMAP_HEADER="{D/compiler/(candidate+"_Hash_map.cpp")}"',f'-DSET_HEADER="{D/compiler/(candidate+"_Hash_set.cpp")}"',str(D/'bench_stats.cpp'),'-o',str(target)];a=subprocess.run(cmd,capture_output=True,text=True);row=dict(compiler=compiler,candidate=candidate,command=cmd,exit=a.returncode,stderr=a.stderr);rows.append(row);(OUT/'build.json').write_text(json.dumps(rows,indent=2));print(compiler,candidate,a.returncode,flush=True);assert a.returncode==0 and not a.stderr,(compiler,candidate,a.stderr[:2000])
print('10 stats binaries ready',flush=True)
