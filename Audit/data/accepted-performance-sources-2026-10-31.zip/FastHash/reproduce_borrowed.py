from pathlib import Path
import subprocess,os,json
D=Path(__file__).parent;os.setsid();os.sched_setaffinity(0,{4});(D/'repro_runner.pid').write_text(str(os.getpid()));rows=[]
for cc,compiler in {'gcc':['/usr/bin/g++'],'clang':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']}.items():
 for fixed,header in [(False,D/'Hash_map_normal_frozen.cpp'),(True,D/'Hash_map_tombstone_fix.cpp')]:
  target=D/f'borrowed-{cc}-{int(fixed)}';cmd=compiler+['-std=c++23','-O1','-g','-DSKIP_RUNTIME_CHECKS','-fsanitize=address,undefined','-fno-sanitize-recover=all',f'-DHEADER="{header}"',str(D/'borrowed_map_repro.cpp'),'-o',str(target)];a=subprocess.run(cmd,capture_output=True,text=True);assert a.returncode==0,a.stderr
  for operation in ['contains','insert']:
   b=subprocess.run([str(target),operation],capture_output=True,text=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0'));row=dict(compiler=cc,fixed=fixed,header=str(header),operation=operation,command=cmd,exit=b.returncode,stdout=b.stdout,stderr=b.stderr,passed=(b.returncode==0)if fixed else('heap-use-after-free'in b.stderr));rows.append(row);print(cc,fixed,operation,row['passed'],flush=True);assert row['passed'],row
(D/'borrowed_repro_results.json').write_text(json.dumps(rows,indent=2));print('8 controls confirmed',flush=True)
