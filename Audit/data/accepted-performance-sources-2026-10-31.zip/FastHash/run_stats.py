from pathlib import Path
import os,subprocess,json,time
D=Path(__file__).parent;OUT=D/'stats';os.sched_setaffinity(0,{4});rows=[]
for repeat in range(3):
 for compiler in ['GCC','Clang']:
  for candidate in ['baseline','B','BP','BE','BPE']:
   for case in [base+offset for base in [0,20,40,60,80]for offset in [1,5,11]]+list(range(101,120,2)):
    while(D/'pause').exists():(D/'pause_ack').write_text('stats run paused');time.sleep(.1)
    (D/'pause_ack').unlink(missing_ok=True)
    b=subprocess.run([str(OUT/(compiler+'-'+candidate)),str(case)],capture_output=True,text=True);assert b.returncode==0 and not b.stderr,(compiler,candidate,case,b.stderr);f=b.stdout.strip().split(',');assert len(f)==13,b.stdout
    row=dict(repetition=repeat,compiler=compiler,candidate=candidate,index=int(f[0]),type=int(f[1]),operation=int(f[2]),n=int(f[3]),loops=int(f[4]),checksum=f[7],new_calls=int(f[8]),requested_bytes=int(f[9]),delete_calls=int(f[10]),minor_faults=int(f[11]),major_faults=int(f[12]));rows.append(row)
 (OUT/'raw.json').write_text(json.dumps(rows,indent=2));print('stats round',repeat+1,len(rows),flush=True)
print('stats DONE',flush=True)
