from pathlib import Path
import os,subprocess,json,random,time,statistics,argparse,hashlib,resource
D=Path(__file__).parent;OUT=D/'lifecycle_bench';p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('--screen',action='store_true');p.add_argument('--repetitions',type=int,default=5);a=p.parse_args();os.setsid();os.sched_setaffinity(0,{12})
if a.screen:
 modes=['GCC-default','Clang-default'];cases=[base+offset for base in [0,20,40,60,80]for offset in [1,3,5,7,11,13,15,19]]+list(range(101,120,2))
else:
 modes=[cc+mode+off for cc in ['GCC','Clang']for mode in ['-default','-native']for off in ['','-nosimd']];cases=list(range(120))
candidates=['baseline','control','A','B','BP','BE','BPE'];rows=[];rng=random.Random(0x4817cafe);expected={}
manifest=dict(name=a.name,cpu=12,modes=modes,cases=cases,candidates=candidates,repetitions=a.repetitions,started_unix=time.time(),bench_sha256=hashlib.sha256((D/'bench_lifecycle.cpp').read_bytes()).hexdigest(),headers={str(x.relative_to(D)):hashlib.sha256(x.read_bytes()).hexdigest()for cc in ['GCC','Clang']for x in(D/cc).glob('*.cpp')if x.name.startswith(('A_','B_','baseline_'))})
(OUT/(a.name+'_manifest.json')).write_text(json.dumps(manifest,indent=2))
for repetition in range(a.repetitions):
 tasks=[(mode,case,candidate)for mode in modes for case in cases for candidate in candidates];rng.shuffle(tasks)
 for mode,case,candidate in tasks:
  executable=OUT/(mode+'-'+('baseline'if candidate=='control'else candidate));usage0=resource.getrusage(resource.RUSAGE_CHILDREN);process_start=time.perf_counter();r=subprocess.run([str(executable),str(case)],capture_output=True,text=True);process_wall=time.perf_counter()-process_start;usage1=resource.getrusage(resource.RUSAGE_CHILDREN);assert r.returncode==0 and not r.stderr,(mode,case,candidate,r.returncode,r.stderr);f=r.stdout.strip().split(',');assert len(f)==8,r.stdout
  row=dict(repetition=repetition,mode=mode,candidate=candidate,index=int(f[0]),type=int(f[1]),operation=int(f[2]),n=int(f[3]),loops=int(f[4]),wall_microseconds=float(f[5]),thread_microseconds=float(f[6]),checksum=f[7],process_wall_microseconds=process_wall*1e6,process_user_microseconds=(usage1.ru_utime-usage0.ru_utime)*1e6,process_system_microseconds=(usage1.ru_stime-usage0.ru_stime)*1e6,process_cpu_microseconds=((usage1.ru_utime-usage0.ru_utime)+(usage1.ru_stime-usage0.ru_stime))*1e6);
  if case in expected:assert expected[case]==row['checksum'],row
  expected[case]=row['checksum'];rows.append(row)
 (OUT/(a.name+'_raw.json')).write_text(json.dumps(rows,indent=2));print(a.name,'round',repetition+1,'rows',len(rows),flush=True)
manifest['finished_unix']=time.time();(OUT/(a.name+'_manifest.json')).write_text(json.dumps(manifest,indent=2));print('RAW_DONE',manifest['finished_unix']-manifest['started_unix'],flush=True)
