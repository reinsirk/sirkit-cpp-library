// SPDX-License-Identifier: CC0-1.0
// Fast専用: 固定長配列をnew[]で確保し、要素と領域を破棄しない。
#include <algorithm>
#include <cstddef>
#include <limits>
#include <utility>
#ifndef SIRKIT_FAST_HASH_ARRAY_DEFINED
#define SIRKIT_FAST_HASH_ARRAY_DEFINED
namespace reinsirk::detail {
template<class T>class FastHashArray {
    T* data_=nullptr;
    std::size_t size_=0;
public:
    FastHashArray() noexcept=default;
    explicit FastHashArray(std::size_t n):data_(n?new T[n]:nullptr),size_(n){}
    FastHashArray(std::size_t n,const T& value):FastHashArray(n){if(n)std::fill_n(data_,n,value);}
    FastHashArray(const FastHashArray&)=delete;
    FastHashArray& operator=(const FastHashArray&)=delete;
    FastHashArray(FastHashArray&& other)noexcept:data_(std::exchange(other.data_,nullptr)),size_(std::exchange(other.size_,0)){}
    FastHashArray& operator=(FastHashArray&& other)noexcept{if(this!=&other){data_=std::exchange(other.data_,nullptr);size_=std::exchange(other.size_,0);}return *this;}
    ~FastHashArray()=default;
    static constexpr std::size_t max_size()noexcept{return static_cast<std::size_t>(std::numeric_limits<std::ptrdiff_t>::max())/sizeof(T);}
    std::size_t size()const noexcept{return size_;}
    bool empty()const noexcept{return size_==0;}
    T*data()noexcept{return data_;}const T*data()const noexcept{return data_;}
    T*begin()noexcept{return data_;}const T*begin()const noexcept{return data_;}
    T*end()noexcept{return size_?data_+size_:data_;}const T*end()const noexcept{return size_?data_+size_:data_;}
    T&operator[](std::size_t i)noexcept{return data_[i];}const T&operator[](std::size_t i)const noexcept{return data_[i];}
    void swap(FastHashArray& other)noexcept{std::swap(data_,other.data_);std::swap(size_,other.size_);}
};
}
#endif
