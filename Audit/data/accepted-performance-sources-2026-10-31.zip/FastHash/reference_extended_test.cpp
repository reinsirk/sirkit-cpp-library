// SPDX-License-Identifier: CC0-1.0
#ifndef MAP_HEADER
#error MAP_HEADER required
#endif
#ifndef SET_HEADER
#error SET_HEADER required
#endif
#include MAP_HEADER
#include MAP_HEADER
#include SET_HEADER
#include SET_HEADER
#include <compare>
#include <array>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <memory>
#include <random>
#include <set>
#include <string>
#include <string_view>
#include <tuple>
#include <vector>
namespace {
std::uint64_t checks=0;
void check(bool v){++checks;if(!v)std::abort();}
struct ConstantHash{template<class T>std::uint64_t operator()(const T&)const noexcept{return 0;}};
template<class Key,class Hash>void map_case(const std::vector<Key>&keys,Hash hash){
 HashMap<Key,int,Hash> a(0,hash);std::map<Key,int>ref;std::mt19937_64 rng(0x13741a);
 for(int step=0;step<6000;++step){const auto&k=keys[rng()%keys.size()];const int value=static_cast<int>(rng()%1000);
  switch(rng()%9){
   case 0:case 1:{a[k]=value;ref[k]=value;break;}
   case 2:{const auto x=a.try_emplace(k,value);const auto y=ref.try_emplace(k,value);check(x.second==y.second&&x.first->second==y.first->second);break;}
   case 3:{auto x=a.insert_or_assign(k,value);auto y=ref.insert_or_assign(k,value);check(x.second==y.second);break;}
   case 4:{a.erase(k,false);ref.erase(k);break;}
   case 5:{auto x=a.find(k);check((x==a.end())==!ref.contains(k));if(x!=a.end())check(x->second==ref.at(k));break;}
   case 6:{check(a.get_or_default(k,-1)==(ref.contains(k)?ref.at(k):-1));break;}
   case 7:{check(a.contains(k)==ref.contains(k));break;}
   case 8:{auto x=a.find(k);if(x!=a.end()){a.erase(x,false);ref.erase(k);}break;}
  }
  check(a.size()==ref.size());
  if(step%173==0){auto copy=a;check(copy.size()==ref.size());for(const auto&[q,v]:ref)check(copy.at(q)==v);if(!keys.empty())copy.insert_or_assign(keys.front(),-77);for(const auto&[q,v]:ref)check(a.at(q)==v);auto moved=std::move(copy);check(copy.empty());copy=std::move(moved);check(moved.empty());HashMap<Key,int,Hash>assigned(0,hash);assigned=a;check(assigned.size()==a.size());std::map<Key,int>got;for(const auto&[q,v]:a)got.emplace(q,v);check(got==ref);const auto&ca=a;std::size_t backwards=0;auto it=ca.end();while(it!=ca.begin()){--it;check(ref.at(it->first)==it->second);++backwards;}check(backwards==ref.size());}
  if(step%211==0)a.reserve(127);
  if(step%509==0)a.rehash(0);
  if(step%1061==0){a.clear();ref.clear();check(a.empty()&&a.begin()==a.end());}
 }
}
template<class Key,class Hash>void set_case(const std::vector<Key>&keys,Hash hash){
 HashSet<Key,Hash>a(0,hash);std::set<Key>ref;std::mt19937_64 rng(0x13742b);
 for(int step=0;step<6000;++step){const auto&k=keys[rng()%keys.size()];switch(rng()%5){
  case 0:case 1:{auto x=a.insert_checked(k);auto y=ref.insert(k);check(x.second==y.second&&*x.first==*y.first);break;}
  case 2:{a.erase(k,false);ref.erase(k);break;}
  case 3:check(a.contains(k)==ref.contains(k));break;
  case 4:{auto x=a.find(k);check((x==a.end())==!ref.contains(k));break;}
 }check(a.size()==ref.size());
 if(step%173==0){auto copy=a;check(copy==a);copy.insert(keys.front());check(a.contains(keys.front())==ref.contains(keys.front()));auto moved=std::move(copy);check(copy.empty());copy=std::move(moved);check(moved.empty());HashSet<Key,Hash>assigned(0,hash);assigned=a;check(assigned==a);std::set<Key>got;for(const auto&q:a)got.insert(q);check(got==ref);std::size_t backwards=0;auto it=a.end();while(it!=a.begin()){--it;check(ref.contains(*it));++backwards;}check(backwards==ref.size());}
 if(step%211==0)a.reserve(127);
 if(step%509==0)a.rehash(0);
 if(step%1061==0){a.clear();ref.clear();check(a.empty()&&a.begin()==a.end());}
 }
}
struct NDKey{int value;NDKey()=delete;explicit NDKey(int v):value(v){};NDKey(const NDKey&)=default;NDKey(NDKey&&)noexcept=default;~NDKey(){};auto operator<=>(const NDKey&)const=default;};
struct NDHash{std::uint64_t operator()(const NDKey&k)const{return GenericHash(17)(k.value);}};
struct NDValue{std::string text;NDValue()=delete;explicit NDValue(int x):text(std::to_string(x)){};NDValue(const NDValue&)=default;NDValue(NDValue&&)noexcept=default;};
struct NonNoexceptHash{std::uint64_t operator()(int x)const{return GenericHash(31)(x);}};
struct alignas(64) AlignedValue {
 int value;std::string text;AlignedValue()=delete;explicit AlignedValue(int v):value(v),text(128,static_cast<char>('a'+v%20)){}
 AlignedValue(const AlignedValue&)=default;AlignedValue(AlignedValue&&)noexcept=default;
 bool operator==(const AlignedValue&other)const{return value==other.value&&text==other.text;}
};
struct AlignedHash{std::uint64_t operator()(const AlignedValue&v)const noexcept{return GenericHash(123)(v.value);}};
void aligned_values(){
 HashMap<int,AlignedValue>map;for(int i=0;i<80;++i)map.try_emplace(i,i);map.reserve(500);auto copy=map;check(reinterpret_cast<std::uintptr_t>(std::addressof(copy.at(7)))%64==0);copy.at(7).text[0]='z';check(map.at(7).text[0]!='z');map.erase(7,false);check(copy.at(7).text[0]=='z');
 HashSet<AlignedValue,AlignedHash>set;for(int i=0;i<80;++i)set.emplace(i);set.reserve(500);auto sc=set;const AlignedValue key(7);set.erase(key,false);check(sc.contains(key));for(const auto&v:sc)check(reinterpret_cast<std::uintptr_t>(std::addressof(v))%64==0);
}
void deep_values(){
 HashMap<int,std::string> strings;strings.try_emplace(1,128,'a');auto copied=strings;copied.at(1)[0]='b';check(strings.at(1)[0]=='a');strings.erase(1,false);check(copied.at(1)[0]=='b');
 HashMap<int,std::vector<int>> vectors;for(int i=0;i<64;++i)vectors.try_emplace(i,17,i);auto vc=vectors;vc.at(3)[0]=999;check(vectors.at(3)[0]==3);vectors.erase(3,false);check(vc.at(3)[0]==999);
 using Tuple=std::tuple<int,std::string,std::vector<int>>;HashMap<int,Tuple> tuples;tuples.try_emplace(1,7,std::string(128,'c'),std::vector<int>{1,2,3});auto tc=tuples;std::get<1>(tc.at(1))[0]='d';std::get<2>(tc.at(1)).push_back(4);check(std::get<1>(tuples.at(1))[0]=='c'&&std::get<2>(tuples.at(1)).size()==3);tuples.clear();check(std::get<2>(tc.at(1)).size()==4);
 HashMap<int,std::pair<std::string,std::unique_ptr<int>>> pairs;for(int i=0;i<128;++i)pairs.try_emplace(i,std::string(80,'p'),std::make_unique<int>(i));pairs.reserve(500);auto moved=std::move(pairs);check(pairs.empty());for(int i=0;i<128;++i)check(*moved.at(i).second==i&&moved.at(i).first.size()==80);
 const std::string key(128,'k');HashMap<std::string,int> km;km[key]=7;auto kc=km;km.erase(key,false);check(kc.at(key)==7);HashSet<std::string> ks;ks.insert(key);auto ksc=ks;ks.erase(key,false);check(ksc.contains(key));
 HashMap<double,int> floating;floating[0.0]=7;check(floating.at(-0.0)==7);floating.erase(-0.0,false);floating[1.5]=11;check(floating.size()==1&&floating.at(1.5)==11);
}
void special(){
 HashMap<NDKey,NDValue,NDHash> nondefault;for(int i=0;i<250;++i)nondefault.try_emplace(NDKey(i),i*3);nondefault.reserve(700);auto copy=nondefault;nondefault.clear();for(int i=0;i<250;++i)check(copy.at(NDKey(i)).text==std::to_string(i*3));
 HashMap<int,std::unique_ptr<int>,NonNoexceptHash> moveonly;for(int i=0;i<1000;++i)moveonly.try_emplace(i,std::make_unique<int>(i*7));moveonly.reserve(5000);for(int i=0;i<1000;i+=3)moveonly.erase(i,false);auto moved=std::move(moveonly);check(moveonly.empty());moveonly=std::move(moved);check(moved.empty());for(int i=0;i<1000;++i){check(moveonly.contains(i)==(i%3!=0));if(i%3)check(*moveonly.at(i)==i*7);}moveonly.clear();check(moveonly.empty());moveonly.try_emplace(7,std::make_unique<int>(42));check(*moveonly.at(7)==42);
 HashSet<NDKey,NDHash> ndset;for(int i=0;i<200;++i)ndset.emplace(i);auto ndcopy=ndset;ndset.clear();for(int i=0;i<200;++i)check(ndcopy.contains(NDKey(i)));check(ndcopy.erase_if([](const NDKey&k){return k.value%3==0;})==67);
 HashSet<int>a(0,GenericHash(1)),b(0,GenericHash(2));for(int i:{1,2,3})a.insert(i);for(int i:{3,2,1})b.insert(i);check(a==b);GenericHash gh(9);check(gh(a)==gh(b));HashMap<HashSet<int>,int> nested(0,gh);nested[a]=7;check(nested.at(b)==7);auto nc=nested;check(nc.at(a)==7);
}
struct RecordEqual{int*const* records;bool operator()(int a,int b)const{return *records[a]==*records[b];}};
void borrowed_records(){
 std::array<std::unique_ptr<int>,3>values;std::array<int*,3>records{};for(int i=0;i<3;++i){values[i]=std::make_unique<int>(i+5);records[i]=values[i].get();}
 HashMap<int,int,ConstantHash,RecordEqual>map(0,ConstantHash{},RecordEqual{records.data()});HashSet<int,ConstantHash,RecordEqual>set(0,ConstantHash{},RecordEqual{records.data()});
 map[0]=7;map[1]=9;set.insert(0);set.insert(1);map.erase(0,false);set.erase(0,false);values[0].reset();records[0]=nullptr;
 check(!map.contains(2)&&!set.contains(2));auto mc=map;auto sc=set;check(mc.try_emplace(2,13).second);check(sc.insert_checked(2).second);check(mc.at(1)==9&&sc.contains(1));
}
void borrowed(){
 const std::string keeper(128,'c'),probe(128,'b');
 for(int repeat=0;repeat<16;++repeat){
  auto erased=std::make_unique<std::string>(128,'a');HashMap<std::string_view,int,ConstantHash> map;map.try_emplace(*erased,1);map.try_emplace(keeper,3);map.erase(std::string_view(*erased),false);erased.reset();auto copy=map;check(!copy.contains(probe));check(copy.try_emplace(probe,2).second);check(copy.at(keeper)==3);
  auto value=std::make_unique<std::string>(128,'a');HashSet<std::string_view,ConstantHash>set;set.insert(*value);set.insert(keeper);set.erase(std::string_view(*value),false);value.reset();auto sc=set;check(!sc.contains(probe));check(sc.insert_checked(probe).second);check(sc.contains(keeper));
 }
}
}
int main(){
 std::vector<int>ints;std::vector<std::string>strings;std::vector<std::vector<int>>vectors;std::vector<std::pair<int,int>>pairs;std::vector<std::tuple<int,std::string>>tuples;
 for(int i=-80;i<=80;++i){ints.push_back(i);strings.push_back(std::string(24,'x')+std::to_string(i));vectors.push_back({i,i/3,i*i});pairs.emplace_back(i,i*i);tuples.emplace_back(i,std::to_string(i));}
 map_case(ints,GenericHash(123));map_case(ints,ConstantHash{});map_case(strings,GenericHash(124));map_case(vectors,GenericHash(125));map_case(pairs,GenericHash(126));map_case(tuples,GenericHash(127));
 set_case(ints,GenericHash(123));set_case(ints,ConstantHash{});set_case(strings,GenericHash(124));set_case(vectors,GenericHash(125));set_case(pairs,GenericHash(126));set_case(tuples,GenericHash(127));special();aligned_values();deep_values();borrowed();borrowed_records();
 std::printf("Fast hash reference checks=%ju\n",static_cast<std::uintmax_t>(checks));
}
