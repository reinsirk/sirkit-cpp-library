from pathlib import Path
import json,statistics,argparse
D=Path(__file__).parent;OUT=D/'bench';p=argparse.ArgumentParser();p.add_argument('--name',required=True);a=p.parse_args();manifest=json.loads((OUT/(a.name+'_manifest.json')).read_text());rows=json.loads((OUT/(a.name+'_raw.json')).read_text());summary=[]
for mode in manifest['modes']:
 for case in manifest['cases']:
  baseline=[r for r in rows if r['mode']==mode and r['index']==case and r['candidate']=='baseline'];cpu_base=statistics.median(r['thread_microseconds']for r in baseline);wall_base=statistics.median(r['wall_microseconds']for r in baseline)
  for candidate in manifest['candidates']:
   selected=[r for r in rows if r['mode']==mode and r['index']==case and r['candidate']==candidate];cpu=statistics.median(r['thread_microseconds']for r in selected);wall=statistics.median(r['wall_microseconds']for r in selected);row={k:selected[0][k]for k in ['mode','candidate','index','type','operation','n']};row.update(thread_median_us=cpu,thread_baseline_us=cpu_base,thread_ratio=cpu/cpu_base,wall_median_us=wall,wall_baseline_us=wall_base,wall_ratio=wall/wall_base);summary.append(row)
(OUT/(a.name+'_summary.json')).write_text(json.dumps(summary,indent=2));print(len(summary),'summary rows')
