from pathlib import Path
import os,subprocess,json,hashlib,time
D=Path(__file__).parent;OUT=D/'checks';OUT.mkdir(exist_ok=True);os.setsid();os.sched_setaffinity(0,{4});(OUT/'runner.pid').write_text(str(os.getpid()));rows=[]
def pause():
 while(D/'pause').exists():
  (D/'pause_ack').write_text('reference paused');time.sleep(.1)
 (D/'pause_ack').unlink(missing_ok=True)
for family in ['A','B']:
 for compiler,flags in {'GCC':['/usr/bin/g++'],'Clang':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']}.items():
  for native in [False,True]:
   for disabled in [False,True]:
    pause();target=OUT/f'{family}-{compiler}-{int(native)}-{int(disabled)}';cmd=flags+['-std=c++23','-O2','-Wall','-Wextra','-Wpedantic','-Werror','-DSKIP_RUNTIME_CHECKS']+(['-march=native']if native else[])+(['-DSIRKIT_DISABLE_SIMD']if disabled else[])+[f'-DMAP_HEADER="{D/compiler/(family+"_Hash_map.cpp")}"',f'-DSET_HEADER="{D/compiler/(family+"_Hash_set.cpp")}"',str(D/'reference_test.cpp'),'-o',str(target)];a=subprocess.run(cmd,capture_output=True,text=True);row=dict(family=family,compiler=compiler,native=native,disabled=disabled,command=cmd,map_sha256=hashlib.sha256((D/compiler/(family+'_Hash_map.cpp')).read_bytes()).hexdigest(),set_sha256=hashlib.sha256((D/compiler/(family+'_Hash_set.cpp')).read_bytes()).hexdigest(),fixture_sha256=hashlib.sha256((D/'reference_test.cpp').read_bytes()).hexdigest(),compile_exit=a.returncode,compile_stderr=a.stderr)
    if a.returncode==0:
     b=subprocess.run([str(target)],capture_output=True,text=True);row.update(run_exit=b.returncode,stdout=b.stdout,stderr=b.stderr,passed=b.returncode==0)
    rows.append(row);(OUT/'results.json').write_text(json.dumps(rows,indent=2));print(family,compiler,native,disabled,row.get('passed'),flush=True);assert row.get('passed')and not a.stderr and not row.get('stderr'),str((family,compiler,native,disabled))
print('16 Fast hash configs PASS',flush=True)
