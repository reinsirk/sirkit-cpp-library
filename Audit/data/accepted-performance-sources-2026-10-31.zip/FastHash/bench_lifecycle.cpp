// SPDX-License-Identifier: CC0-1.0
#include MAP_HEADER
#include SET_HEADER
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <numeric>
#include <random>
#include <string>
#include <vector>
namespace {
volatile std::uint64_t sink=0;
struct Case{int type,operation;std::size_t n;int loops;};
// type: map<u64,u64>,map<string,u64>,map<u64,string>,set<u64>,set<string>
// op: construct,insert_grow,insert_reserved,hit,miss,churn,copy,clear,iterate,destroy
constexpr Case cases[]={
#define CASES(TYPE,SMALL,LARGE) {TYPE,0,SMALL,128},{TYPE,0,LARGE,1},{TYPE,1,SMALL,128},{TYPE,1,LARGE,1},{TYPE,2,SMALL,128},{TYPE,2,LARGE,1},{TYPE,3,SMALL,128},{TYPE,3,LARGE,3},{TYPE,4,SMALL,128},{TYPE,4,LARGE,3},{TYPE,5,SMALL,128},{TYPE,5,LARGE,1},{TYPE,6,SMALL,128},{TYPE,6,LARGE,1},{TYPE,7,SMALL,128},{TYPE,7,LARGE,1},{TYPE,8,SMALL,128},{TYPE,8,LARGE,3},{TYPE,9,SMALL,128},{TYPE,9,LARGE,1}
 CASES(0,64,262144),CASES(1,64,32768),CASES(2,64,32768),CASES(3,64,262144),CASES(4,64,32768),
{0,10,64,128},{0,10,262144,1},{0,11,64,128},{0,11,262144,1},{1,10,64,128},{1,10,32768,1},{1,11,64,128},{1,11,32768,1},{2,10,64,128},{2,10,32768,1},{2,11,64,128},{2,11,32768,1},{3,10,64,128},{3,10,262144,1},{3,11,64,128},{3,11,262144,1},{4,10,64,128},{4,10,32768,1},{4,11,64,128},{4,11,32768,1}
#undef CASES
};
struct Timer{
 timespec start_cpu{};std::chrono::steady_clock::time_point start_wall;
 Timer(){if(::clock_gettime(CLOCK_THREAD_CPUTIME_ID,&start_cpu))std::abort();start_wall=std::chrono::steady_clock::now();asm volatile("":::"memory");}
 std::pair<double,double> stop(int loops){asm volatile("":::"memory");const auto wall=std::chrono::steady_clock::now();timespec cpu{};if(::clock_gettime(CLOCK_THREAD_CPUTIME_ID,&cpu))std::abort();return{std::chrono::duration<double,std::micro>(wall-start_wall).count()/loops,((static_cast<double>(cpu.tv_sec)-start_cpu.tv_sec)*1e9+cpu.tv_nsec-start_cpu.tv_nsec)/1000/loops};}
};
template<class K>K key(std::size_t i){if constexpr(std::is_same_v<K,std::string>)return std::string(48,'k')+std::to_string(i);else return static_cast<K>(i);}
template<class V>V value(std::size_t i){if constexpr(std::is_same_v<V,std::string>)return std::string(64,'v')+std::to_string(i);else return static_cast<V>(i*7+19);}
template<class T>std::uint64_t fold(const T&v){if constexpr(std::is_same_v<T,std::string>)return v.size()*131+static_cast<unsigned char>(v[0]);else return static_cast<std::uint64_t>(v);}
template<class Table>[[gnu::noinline]]Table* create(std::size_t n){return new Table(n,GenericHash(0x1234abcd));}
template<class Table>[[gnu::noinline]]Table* duplicate(const Table&src){return new Table(src);}
template<class Table>[[gnu::noinline]]void destroy(Table*p){delete p;}
template<bool Map,class Table,class Key>void put(Table&t,const Key&k,std::size_t i){if constexpr(Map)t.try_emplace(k,value<typename Table::mapped_type>(i));else t.insert(k);}
template<bool Map,class Table>std::uint64_t digest(const Table&t){std::uint64_t result=t.size();for(const auto&entry:t){if constexpr(Map)result+=fold(entry.first)*1234567+fold(entry.second);else result+=fold(entry)*1234567;}return result;}
template<bool Map,class K,class V>void run(std::size_t index,const Case&c){
 using Table=std::conditional_t<Map,HashMap<K,V>,HashSet<K>>;
 std::vector<K>keys;keys.reserve(c.n*2);for(std::size_t i=0;i<c.n*2;++i)keys.push_back(key<K>(i));
 std::vector<std::size_t>order(c.n);std::iota(order.begin(),order.end(),0);std::mt19937_64 rng(0x41ab3c);std::shuffle(order.begin(),order.end(),rng);
 std::vector<Table*>handles(static_cast<std::size_t>(c.loops));std::uint64_t checksum=0;std::pair<double,double>elapsed;
 const auto fill=[&](Table&t){for(auto i:order)put<Map>(t,keys[i],i);};
 if(c.operation==10||c.operation==11){Timer timer;for(int repeat=0;repeat<c.loops;++repeat){auto*p=create<Table>(c.operation==10?c.n:0);fill(*p);for(auto i:order){auto it=p->find(keys[i]);if(it==p->end())std::abort();if constexpr(Map)checksum+=fold(it->second);else checksum+=fold(*it);}destroy(p);}sink=checksum;elapsed=timer.stop(c.loops);}
 else if(c.operation==0){Timer timer;for(auto&p:handles)p=create<Table>(c.n);sink=handles.back()->capacity();elapsed=timer.stop(c.loops);for(auto*p:handles){fill(*p);checksum+=digest<Map>(*p);destroy(p);}}
 else if(c.operation==1||c.operation==2){for(auto&p:handles)p=create<Table>(c.operation==2?c.n:0);Timer timer;for(auto*p:handles)fill(*p);sink=handles.back()->size();elapsed=timer.stop(c.loops);for(auto*p:handles){checksum+=digest<Map>(*p);destroy(p);}}
 else if(c.operation==6){auto*src=create<Table>(c.n);fill(*src);for(std::size_t i=0;i<c.n;i+=3)src->erase(keys[i],false);Timer timer;for(auto&p:handles)p=duplicate(*src);sink=handles.back()->size();elapsed=timer.stop(c.loops);for(auto*p:handles){checksum+=digest<Map>(*p);destroy(p);}destroy(src);}
 else if(c.operation==7||c.operation==9){for(auto&p:handles){p=create<Table>(c.n);fill(*p);checksum+=digest<Map>(*p);}sink=checksum;Timer timer;if(c.operation==7){for(auto*p:handles)p->clear();}else{for(auto*p:handles)destroy(p);}elapsed=timer.stop(c.loops);if(c.operation==7){for(auto*p:handles){if(!p->empty())std::abort();destroy(p);}}}
 else {auto*p=create<Table>(c.n);fill(*p);Timer timer;for(int repeat=0;repeat<c.loops;++repeat){
  if(c.operation==3||c.operation==4){const auto offset=c.operation==4?c.n:0;for(auto i:order){auto it=p->find(keys[offset+i]);if(it!=p->end()){if constexpr(Map)checksum+=fold(it->second);else checksum+=fold(*it);}else checksum+=17;}}
  else if(c.operation==5){const auto old=(repeat&1)?c.n:0,new_offset=old?0:c.n;for(auto i:order){p->erase(keys[old+i],false);put<Map>(*p,keys[new_offset+i],new_offset+i);}}
  else if(c.operation==8)checksum+=digest<Map>(*p);
 }sink=checksum;elapsed=timer.stop(c.loops);checksum+=digest<Map>(*p);destroy(p);}
 sink=checksum;
 std::printf("%zu,%d,%d,%zu,%d,%.6f,%.6f,%ju\n",index,c.type,c.operation,c.n,c.loops,elapsed.first,elapsed.second,static_cast<std::uintmax_t>(checksum));
}
}
int main(int argc,char**argv){if(argc!=2)return 2;const auto index=static_cast<std::size_t>(std::strtoull(argv[1],nullptr,10));if(index>=std::size(cases))return 2;const auto c=cases[index];switch(c.type){case 0:run<true,std::uint64_t,std::uint64_t>(index,c);break;case 1:run<true,std::string,std::uint64_t>(index,c);break;case 2:run<true,std::uint64_t,std::string>(index,c);break;case 3:run<false,std::uint64_t,std::uint64_t>(index,c);break;case 4:run<false,std::string,std::uint64_t>(index,c);break;}}
