from pathlib import Path
import importlib.util,sys,json,hashlib
D=Path(__file__).parent;R=Path('/home/reinsirk/Atcoder_Env')
spec=importlib.util.spec_from_file_location('variant_specialize',R/'Scripts/generate_variants.py');module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
BUFFER=(R/'Fast/Source/Internal/Buffer.cpp').read_text();BUFFER=BUFFER[BUFFER.index('#include '):]
RAW=(D/'RawArray.hpp').read_text();RAW=RAW[RAW.index('#include '):]
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b,1)
def copy_ctor(s,kind,simd=False):
 result=once(s,f'    {kind}(const {kind}&) = default;',f'''    {kind}(const {kind}& other) requires std::is_copy_constructible_v<value_type>
        : slots_(other.slots_.size()),state_(other.state_.size(),0),size_(other.size_),occupied_(other.occupied_),
          shift_(other.shift_),hash_(other.hash_),equal_(other.equal_) {{
        for(size_type i=0;i<slots_.size();++i) {{
            state_[i]=other.state_[i];
            if constexpr(std::is_same_v<Slot,CompactSlot>) {{
                if(state_[i])slots_[i].emplace(*other.slots_[i]);
            }} else if(state_[i]==1)slots_[i].emplace(*other.slots_[i]);
        }}
    }}''')
 if simd:
  old='''        for(size_type i=0;i<slots_.size();++i) {
            state_[i]=other.state_[i];'''
  new='''        if(!state_.empty())std::copy_n(other.state_.data(),state_.size(),state_.data());
#if !defined(SIRKIT_DISABLE_SIMD) && defined(__SSE2__) && (defined(__x86_64__) || defined(__i386__))
        if(slots_.size()>=16) {
            for(size_type base=0;base<slots_.size();base+=16) {
                const auto states=_mm_loadu_si128(reinterpret_cast<const __m128i*>(state_.data()+base));
                unsigned mask;
                if constexpr(std::is_same_v<Slot,CompactSlot>)mask=static_cast<unsigned>(~_mm_movemask_epi8(_mm_cmpeq_epi8(states,_mm_setzero_si128())))&65535u;
                else mask=static_cast<unsigned>(_mm_movemask_epi8(_mm_cmpeq_epi8(states,_mm_set1_epi8(1))));
                while(mask) {const auto i=base+std::countr_zero(mask);slots_[i].emplace(*other.slots_[i]);mask&=mask-1;}
            }
            return;
        }
#endif
        for(size_type i=0;i<slots_.size();++i) {'''
  assert result.count(old)==1;result=result.replace(old,new,1)
 return result
def replace_slots(s,kind):
 start=s.index('    // 自明に',s.index('class '+kind+' {'));end=s.index('    static_assert(std::is_copy_constructible_v<value_type>',start)
 storage='''    template<bool Compact>union SlotStorage {
        std::remove_cv_t<value_type> value;
        SlotStorage()noexcept{}
        ~SlotStorage() requires std::is_trivially_destructible_v<value_type> = default;
        ~SlotStorage()noexcept requires (!std::is_trivially_destructible_v<value_type>) {} // Fast契約: 登録値も破棄しない。
        SlotStorage(const SlotStorage&)=delete;
        SlotStorage(SlotStorage&&)=delete;
        value_type&operator*()noexcept{return value;}
        const value_type&operator*()const noexcept{return value;}
        value_type*operator->()noexcept{return std::addressof(value);}
        const value_type*operator->()const noexcept{return std::addressof(value);}
        template<class...Args>void emplace(Args&&...args){std::construct_at(std::addressof(value),std::forward<Args>(args)...);}
        void reset()noexcept{}
    };
    using CompactSlot=SlotStorage<true>;
    using Slot=std::conditional_t<
        std::is_nothrow_default_constructible_v<value_type>&&
        std::is_nothrow_move_constructible_v<value_type>&&
        std::is_trivially_copy_constructible_v<value_type>&&
        std::is_trivially_destructible_v<value_type>,CompactSlot,SlotStorage<false>>;
'''
 return s[:start]+storage+s[end:]
def single_pass(s,kind):
 start=s.index('        if constexpr (std::is_nothrow_move_constructible_v<value_type> &&',s.index('    void rebuild(size_type capacity)'))
 end=s.index('        slots_.swap(next);',start)
 key='slots_[i]->first'if kind=='HashMap'else'*slots_[i]'
 replacement=f'''        for(size_type i=0;i<slots_.size();++i){{
            if(state_[i]!=1)continue;
            size_type p=bucket({key},shift);
            while(state[p])p=(p+1)&(capacity-1);
            if constexpr(std::is_move_constructible_v<value_type>)next[p].emplace(std::move(*slots_[i]));
            else next[p].emplace(*slots_[i]);
            state[p]=1;
        }}
'''
 return s[:start]+replacement+s[end:]
records=[]
for family in ['A','B']:
 for kind,file in [('HashMap','Hash_map'),('HashSet','Hash_set')]:
  source=(R/'DataStructure'/(file+'.cpp')).read_text()
  if kind=='HashMap':assert source.count('std::is_same_v<Slot, CompactSlot> && std::is_integral_v<Key>')==2,'normal tombstone fix pending'
  source=copy_ctor(source,kind,simd=family=='B')
  if family=='B':source=single_pass(replace_slots(source,kind),kind)
  storage='reinsirk::detail::FastBuffer'if family=='A'else'reinsirk::detail::FastHashArray'
  source=source.replace('std::vector<Slot>',storage+'<Slot>').replace('std::vector<std::uint8_t>',storage+'<std::uint8_t>')
  head='// Fast試作'+family+': 主要配列を解放せず、例外後の状態を保証しない。\n'
  if family=='B':head+='// 格納値の破棄・資源回収も省略する。正常入力・確保/構築成功・有効な容量が前提。\n'
  source=head+source;at=source.index('#include ');source=source[:at]+(BUFFER if family=='A'else RAW+'\n#if !defined(SIRKIT_DISABLE_SIMD) && defined(__SSE2__) && (defined(__x86_64__) || defined(__i386__))\n#include <emmintrin.h>\n#endif\n')+'\n'+source[at:]
  (D/(family+'_'+file+'.cpp')).write_text(source)
  for compiler in ['GCC','Clang']:
   content=module.specialize(source,compiler,fast=True).encode();p=D/compiler/(family+'_'+file+'.cpp');p.parent.mkdir(exist_ok=True);p.write_bytes(content);records.append({'family':family,'kind':kind,'compiler':compiler,'path':str(p),'sha256':hashlib.sha256(content).hexdigest()})
for compiler in ['GCC','Clang']:
 for file in ['Hash_map','Hash_set']:
  p=D/compiler/('baseline_'+file+'.cpp');p.write_text(module.specialize((R/'DataStructure'/(file+'.cpp')).read_text(),compiler,fast=True))
(D/'candidates.json').write_text(json.dumps(records,indent=2));print('8 candidates ready')
