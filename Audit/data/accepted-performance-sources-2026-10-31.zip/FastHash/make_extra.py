from pathlib import Path
import importlib.util,sys,json,hashlib
D=Path(__file__).parent;R=Path('/home/reinsirk/Atcoder_Env');spec=importlib.util.spec_from_file_location('variant_specialize',R/'Scripts/generate_variants.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);rows=[]
def prefault(s):
 start=0
 while True:
  marker=s.find('// 値の構築前に領域を',start)
  if marker<0:break
  begin=s.rfind('#if ',0,marker);end=s.index('#endif',marker)+len('#endif');block=s[begin:end];assert 'defined(__GNUC__)'in block;block=block[block.index('\n')+1:];block=block[:block.rfind('#endif')];block=block.replace('if constexpr (std::is_same_v<Slot, CompactSlot>)','');s=s[:begin]+block+s[end:];start=begin+len(block)
 return s
for name in ['Hash_map','Hash_set']:
 base=(D/('B_'+name+'.cpp')).read_text();p=prefault(base)
 e=base.replace('void reset()noexcept{}','void reset()noexcept{if constexpr(!std::is_trivially_destructible_v<value_type>)std::destroy_at(std::addressof(value));}')
 needle='        for (size_type i = 0; i < slots_.size(); ++i) if (state_[i] == 1) slots_[i].reset();\n';assert e.count(needle)==1;e=e.replace(needle,'')
 for family,s in [('BP',p),('BE',e),('BPE',prefault(e))]:
  (D/(family+'_'+name+'.cpp')).write_text(s)
  for compiler in ['GCC','Clang']:
   out=D/compiler/(family+'_'+name+'.cpp');out.write_text(m.specialize(s,compiler,fast=True));rows.append(dict(family=family,name=name,compiler=compiler,sha256=hashlib.sha256(out.read_bytes()).hexdigest()))
(D/'extra_candidates.json').write_text(json.dumps(rows,indent=2));print('12 extra headers ready')
