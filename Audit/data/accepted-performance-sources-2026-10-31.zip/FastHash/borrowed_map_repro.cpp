// SPDX-License-Identifier: CC0-1.0
#ifndef HEADER
#error HEADER required
#endif
#include HEADER
#include <cstdio>
#include <cstdlib>
#include <memory>
#include <string>
#include <string_view>
struct ConstantHash {
    std::uint64_t operator()(std::string_view) const noexcept { return 0; }
};
int main(int argc,char**argv) {
    auto erased=std::make_unique<std::string>(128,'a');
    const std::string keeper(128,'c'),probe(128,'b');
    HashMap<std::string_view,int,ConstantHash> map;
    map.try_emplace(std::string_view(*erased),1);
    map.try_emplace(std::string_view(keeper),3);
    map.erase(std::string_view(*erased),false);
    erased.reset();
    if(argc>1&&argv[1][0]=='i') {
        const auto result=map.try_emplace(std::string_view(probe),2);
        if(!result.second||result.first->second!=2||map.size()!=2)std::abort();
    } else if(map.contains(std::string_view(probe)))std::abort();
    if(map.at(std::string_view(keeper))!=3)std::abort();
    std::puts("borrowed-key PASS");
}
