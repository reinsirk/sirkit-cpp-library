from pathlib import Path
import importlib.util,sys,re,json,hashlib
D=Path(__file__).parent;R=Path('/home/reinsirk/Atcoder_Env');spec=importlib.util.spec_from_file_location('variant_specialize',R/'Scripts/generate_variants.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);rows=[]
def reorder_retire(source):
 for method in ['rebuild_simd','rebuild']:
  begin=source.index('    void '+method+'(');opening=source.index('{',begin);depth=1;end=opening+1
  while depth:
   depth+=(source[end]=='{')-(source[end]=='}');end+=1
  body=source[opening+1:end-1];release='        next.release_storage();state.release_storage();'
  cleanup='''        if constexpr(!std::is_trivially_destructible_v<value_type>)
            for(size_type i=0;i<next.size();++i)if(state[i]==1)next[i].reset();
'''
  have_cleanup=cleanup in body;body=body.replace(cleanup,'').replace(release+'\n','');at=body.rindex('invalidate();')+len('invalidate();');body=body[:at]+'\n'+(cleanup if have_cleanup else'')+release+body[at:];source=source[:opening+1]+body+source[end-1:]
 return source
for name in ['Hash_map','Hash_set']:
 s=(D/('BPE_'+name+'.cpp')).read_text().replace('FastHashArray','FastHashReleasedArray').replace('SIRKIT_FAST_HASH_ARRAY_DEFINED','SIRKIT_FAST_HASH_RELEASED_ARRAY_DEFINED')
 needle='    void swap(FastHashReleasedArray& other)noexcept{';assert s.count(needle)==1;s=s.replace(needle,'    void release_storage()noexcept{delete[] data_;data_=nullptr;size_=0;}\n'+needle,1)
 pattern=r'slots_\.swap\(next\);\s*state_\.swap\(state\);';assert len(re.findall(pattern,s))==2;s=re.sub(pattern,lambda x:x.group()+'\n        next.release_storage();state.release_storage();',s)
 d=s.replace('        next.release_storage();state.release_storage();','''        if constexpr(!std::is_trivially_destructible_v<value_type>)
            for(size_type i=0;i<next.size();++i)if(state[i]==1)next[i].reset();
        next.release_storage();state.release_storage();''')
 d=reorder_retire(d);s=reorder_retire(s)
 (D/('BRD_'+name+'.cpp')).write_text(d)
 for cc in ['GCC','Clang']:(D/cc/('BRD_'+name+'.cpp')).write_text(m.specialize(d,cc,fast=True))
 (D/('BR_'+name+'.cpp')).write_text(s)
 for cc in ['GCC','Clang']:
  p=D/cc/('BR_'+name+'.cpp');p.write_text(m.specialize(s,cc,fast=True));rows.append(dict(compiler=cc,name=name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(D/'release_candidates.json').write_text(json.dumps(rows,indent=2));print('4 BR headers ready')
p=D/'check.py';s=p.read_text().replace("['A','B']","['BR','BRD']").replace("OUT=D/'checks'","OUT=D/'release_checks'").replace("16 Fast hash configs PASS","16 release hash configs PASS");(D/'check_release.py').write_text(s)
p=D/'build_extra_bench.py';s=p.read_text().replace("['baseline','A','B','BP','BE','BPE']","['BR','BRD']");(D/'build_release_bench.py').write_text(s)
