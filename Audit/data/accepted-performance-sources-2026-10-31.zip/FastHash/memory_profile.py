from pathlib import Path
import os,subprocess,json,time
D=Path(__file__).parent;os.sched_setaffinity(0,{4});rows=[]
for repeat in range(3):
 for cc in ['GCC','Clang']:
  for candidate in ['baseline','BPE','BR','BRD']:
   for case in [103,107,111,115,119]:
    while(D/'pause').exists():(D/'pause_ack').write_text('memory profile paused');time.sleep(.1)
    (D/'pause_ack').unlink(missing_ok=True)
    proc=subprocess.Popen([str(D/'lifecycle_bench'/(cc+'-default-'+candidate)),str(case)],stdout=subprocess.PIPE,stderr=subprocess.PIPE);_,status,usage=os.wait4(proc.pid,0);proc.returncode=os.waitstatus_to_exitcode(status);stdout=proc.stdout.read().decode();stderr=proc.stderr.read().decode();proc.stdout.close();proc.stderr.close();assert proc.returncode==0 and not stderr,(cc,candidate,case,stderr);rows.append(dict(repetition=repeat,compiler=cc,candidate=candidate,index=case,max_rss_kib=usage.ru_maxrss,minor_faults=usage.ru_minflt,major_faults=usage.ru_majflt,checksum=stdout.strip().split(',')[-1]))
 (D/'memory_profile.json').write_text(json.dumps(rows,indent=2));print('RSS round',repeat+1,len(rows),flush=True)
print('RSS complete; CPU4 execution times are deliberately not used',flush=True)
