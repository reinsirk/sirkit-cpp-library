from pathlib import Path
import os,subprocess,json,time,hashlib,argparse
D=Path(__file__).parent;p=argparse.ArgumentParser();p.add_argument('candidate');a=p.parse_args();OUT=D/(a.candidate+'_sanitizer');OUT.mkdir(exist_ok=True);os.sched_setaffinity(0,{4});rows=[]
for compiler,flags in {'GCC':['/usr/bin/g++'],'Clang':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']}.items():
 for disabled in [False,True]:
  while(D/'pause').exists():(D/'pause_ack').write_text('sanitizer paused');time.sleep(.1)
  (D/'pause_ack').unlink(missing_ok=True)
  target=OUT/(compiler+'-'+str(int(disabled)));cmd=flags+['-std=c++23','-O1','-g','-Wall','-Wextra','-Wpedantic','-Werror','-DSKIP_RUNTIME_CHECKS','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer']+(['-DSIRKIT_DISABLE_SIMD']if disabled else[])+[f'-DMAP_HEADER="{D/compiler/(a.candidate+"_Hash_map.cpp")}"',f'-DSET_HEADER="{D/compiler/(a.candidate+"_Hash_set.cpp")}"',str(D/'reference_test.cpp'),'-o',str(target)];c=subprocess.run(cmd,capture_output=True,text=True);row=dict(candidate=a.candidate,compiler=compiler,disabled=disabled,command=cmd,compile_exit=c.returncode,compile_stderr=c.stderr,fixture_sha256=hashlib.sha256((D/'reference_test.cpp').read_bytes()).hexdigest())
  if c.returncode==0:
   r=subprocess.run([str(target)],capture_output=True,text=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0'));row.update(exit=r.returncode,stdout=r.stdout,stderr=r.stderr,passed=r.returncode==0)
  rows.append(row);(OUT/'results.json').write_text(json.dumps(rows,indent=2));print(a.candidate,compiler,disabled,row.get('passed'),flush=True);assert row.get('passed')and not c.stderr and not row.get('stderr'),(a.candidate,compiler,disabled)
print('4 ASan/UBSan configs PASS; intentional leaks excluded',flush=True)
