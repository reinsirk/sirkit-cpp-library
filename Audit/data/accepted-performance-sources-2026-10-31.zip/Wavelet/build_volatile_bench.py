from pathlib import Path
import subprocess,json,hashlib
w=Path(__file__).resolve().parent;out=w/'volatile_bench';out.mkdir(exist_ok=True);source=w/'avx_inline_volatile.cpp';rows=[]
old=(w/'avx_inline_static.cpp').read_text();new=source.read_text()
for compiler in ('gcc','clang'):
 prefix=['/usr/bin/g++'] if compiler=='gcc' else ['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
 row={'compiler':compiler,'candidate':'volatile','native':False,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'flags':['-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS']}
 for name in ('api','api32','kth','frequency'):
  exe=out/(compiler+'_'+name)
  if name in ('api','api32'):
   fixture=w/'api_benchmark.cpp';extra=['-DWAVELET_SOURCE="'+str(source)+'"']+(['-DWAVELET_BENCH_TYPE=std::int32_t'] if name=='api32' else [])
  else:
   text=(w/(name+'_avx_inline_static.cpp')).read_text();assert text.count(old)==1;fixture=out/(name+'.cpp');fixture.write_text(text.replace(old,new));extra=[]
  command=['taskset','-c','6']+prefix+row['flags']+extra+[str(fixture),'-o',str(exe)];run=subprocess.run(command,capture_output=True,text=True,timeout=180);assert run.returncode==0,run.stderr;row[name]=str(exe);row[name+'_sha256']=hashlib.sha256(exe.read_bytes()).hexdigest();print(compiler,name,'PASS',flush=True)
 rows.append(row);(out/'build.json').write_text(json.dumps(rows,indent=2))
