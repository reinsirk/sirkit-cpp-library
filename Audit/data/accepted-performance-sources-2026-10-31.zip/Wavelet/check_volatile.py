from pathlib import Path
import subprocess,json,hashlib
w=Path(__file__).resolve().parent;out=w/'volatile_checks';out.mkdir(exist_ok=True)
records=[]
for compiler in ('gcc','clang'):
 for native in (False,True):
  objects=[]
  for variant in ('avx_inline_static','avx_inline_volatile'):
   source=w/(variant+'.cpp');active=out/'active.hpp';active.write_bytes(source.read_bytes());exe=out/(compiler+str(native)+variant+'.o');prefix=['/usr/bin/g++'] if compiler=='gcc' else ['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'];cmd=['taskset','-c','6']+prefix+['-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS','-DWAVELET_SOURCE="'+str(active)+'"']+(['-march=native'] if native else [])+['-c',str(w/'query_wrappers.cpp'),'-o',str(exe)];subprocess.run(cmd,check=True,capture_output=True);objects.append(exe.read_bytes())
  row={'compiler':compiler,'native':native,'whole_object_equal':objects[0]==objects[1],'object_sha256':[hashlib.sha256(o).hexdigest() for o in objects]};records.append(row);(out/'results.json').write_text(json.dumps(records,indent=2));print(compiler,native,row['whole_object_equal'],flush=True)
