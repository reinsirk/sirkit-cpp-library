from pathlib import Path
import subprocess,json,struct,re,hashlib
out=Path(__file__).parent

def symbols(binary):
 result={}
 for line in subprocess.check_output(['nm','-C','-S','--defined-only',str(binary)],text=True).splitlines():
  parts=line.split(maxsplit=3)
  if len(parts)==4:
   try:result[parts[3]]=(int(parts[0],16),int(parts[1],16))
   except ValueError:pass
 return result

def elf_bytes(binary,address,length):
 data=binary.read_bytes();assert data[:5]==b'\x7fELF\x02'
 phoff=struct.unpack_from('<Q',data,32)[0];entsize,count=struct.unpack_from('<HH',data,54)
 for i in range(count):
  typ,flags,offset,vaddr,paddr,filesize,memsize,align=struct.unpack_from('<IIQQQQQQ',data,phoff+i*entsize)
  if typ==1 and vaddr<=address and address+length<=vaddr+filesize:return data[offset+address-vaddr:offset+address-vaddr+length]
 raise ValueError((binary,address,length))

def instructions(binary,symbol):
 text=subprocess.check_output(['objdump','-d','-C','-M','intel','--no-show-raw-insn',str(binary)],text=True)
 lines=text.splitlines();start=next(i for i,line in enumerate(lines) if line.endswith(' <'+symbol+'>:'))
 base=int(lines[start].split()[0],16);result=[]
 for line in lines[start+1:]:
  if not line.strip():break
  match=re.match(r'\s*([0-9a-f]+):\s+(.*)',line)
  if not match:continue
  instruction=match.group(2).split('#')[0].strip()
  # 相対アドレスは命令の対象を維持して正規化。内部CFGのオフセットは残す。
  def target(m):
   address,name=m.group(1),m.group(2)
   if name==symbol or name.startswith(symbol+'+0x'):return '<self+'+hex(int(address,16)-base)+'>'
   return '<'+name+'>'
  instruction=re.sub(r'\b([0-9a-f]+) <([^>]+)>',target,instruction)
  instruction=re.sub(r'\[rip[+-]0x[0-9a-f]+\]','[rip+RELOC]',instruction)
  result.append(instruction)
 return result

rows=[]
for cc in ['gcc','clang']:
 base=out/f'api_baseline_{cc}_native';base_symbols=symbols(base)
 for name in ['avx_dispatch_exact','avx_inline_exact','avx_dispatch_static','avx_inline_static']:
  candidate=out/f'api_{name}_{cc}_native'
  if not candidate.exists():continue
  cand_symbols=symbols(candidate)
  entry={'compiler':cc,'candidate':name,'symbols':[]}
  for symbol,(address,length) in base_symbols.items():
   if symbol!='main' and not ('WaveletMatrix<long>::' in symbol and any(k in symbol for k in ['::access(', '::rank(', '::kth_smallest(', '::count_less_unchecked('])):continue
   if symbol not in cand_symbols:continue
   new_address,new_length=cand_symbols[symbol];old_bytes=elf_bytes(base,address,length);new_bytes=elf_bytes(candidate,new_address,new_length)
   old_instructions=instructions(base,symbol);new_instructions=instructions(candidate,symbol)
   item={'symbol':symbol,'baseline_address':hex(address),'candidate_address':hex(new_address),'baseline_size':length,'candidate_size':new_length,'raw_bytes_equal':old_bytes==new_bytes,'normalized_instructions_equal':old_instructions==new_instructions,'baseline_sha256':hashlib.sha256(old_bytes).hexdigest(),'candidate_sha256':hashlib.sha256(new_bytes).hexdigest(),'vzeroupper_baseline':sum('vzeroupper' in s for s in old_instructions),'vzeroupper_candidate':sum('vzeroupper' in s for s in new_instructions)}
   if old_instructions!=new_instructions:
    item['first_differences']=[{'index':i,'baseline':a,'candidate':b} for i,(a,b) in enumerate(zip(old_instructions,new_instructions)) if a!=b][:8]
   entry['symbols'].append(item)
  entry['cpu_detection_linked']='__cpu_indicator_init' in cand_symbols
  rows.append(entry)
(out/'elf_comparison.json').write_text(json.dumps(rows,indent=2))
for r in rows:
 print(r['compiler'],r['candidate'],'CPU detection linked:',r['cpu_detection_linked'])
 for s in r['symbols']:print(' ',s['symbol'].split('(')[0],s['baseline_address'],s['candidate_address'],'bytes',s['raw_bytes_equal'],'instructions',s['normalized_instructions_equal'],'vzeroupper',s['vzeroupper_baseline'],s['vzeroupper_candidate'])
