// SPDX-License-Identifier: CC0-1.0
#include WAVELET_SOURCE
using Matrix = WaveletMatrix<std::int64_t>;
extern "C" {
std::int64_t wm_access(const Matrix& m, std::size_t i) { return m.access(i); }
std::size_t wm_count(const Matrix& m, std::size_t l, std::size_t r, std::int64_t x) { return m.count(l,r,x); }
std::size_t wm_less(const Matrix& m, std::size_t l, std::size_t r, std::int64_t x) { return m.count_less(l,r,x); }
std::int64_t wm_kth(const Matrix& m, std::size_t l, std::size_t r, std::size_t k) { return m.kth_smallest(l,r,k); }
std::int64_t wm_min(const Matrix& m, std::size_t l, std::size_t r) { return m.range_min(l,r); }
std::int64_t wm_max(const Matrix& m, std::size_t l, std::size_t r) { return m.range_max(l,r); }
std::int64_t wm_pred(const Matrix& m, std::size_t l, std::size_t r, std::int64_t x) { return m.predecessor(l,r,x).value_or(0); }
std::int64_t wm_succ(const Matrix& m, std::size_t l, std::size_t r, std::int64_t x) { return m.successor(l,r,x).value_or(0); }
}
int main() {}
