from pathlib import Path
import json,subprocess,hashlib,random,resource,time
w=Path(__file__).resolve().parent;rows=[r for r in json.loads((w/'benchmark_binaries.json').read_text()) if not r['native'] and r['candidate'] in ('baseline','avx_inline_static')]+json.loads((w/'volatile_bench/build.json').read_text());rows += [{**r,'candidate':'control'}for r in rows if r['candidate']=='baseline'];records=[];expected={};rng=random.Random(20261101)
cases=[(500000,100000,31,'mixed',False),(500000,100000,64,'mixed',False),(1000000,0,31,'build',False),(1000000,0,31,'build',True),(128,100000,8,'mixed',False)]
inputs={kind:(w/('screen_'+kind+'.in')).read_bytes()for kind in ('kth','frequency')}
for repeat in range(3):
 order=rows.copy();rng.shuffle(order)
 for row in order:
  for n,q,bits,kind,type32 in cases:
   before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.perf_counter_ns();run=subprocess.run(['taskset','-c','12',row['api32']if type32 else row['api'],str(n),str(q),str(bits),kind],capture_output=True,text=True,check=True);after=resource.getrusage(resource.RUSAGE_CHILDREN);measure=json.loads(run.stdout);key=(n,q,bits,kind,type32);expected.setdefault(key,measure['hash']);assert expected[key]==measure['hash'];records.append({**row,**measure,'repeat':repeat,'type32':type32,'process_cpu_ns':round(((after.ru_utime+after.ru_stime)-(before.ru_utime+before.ru_stime))*1e9),'process_wall_ns':time.perf_counter_ns()-start})
  for kind,data in inputs.items():
   before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.perf_counter_ns();run=subprocess.run(['taskset','-c','12',row[kind]],input=data,capture_output=True,check=True);after=resource.getrusage(resource.RUSAGE_CHILDREN);digest=hashlib.sha256(run.stdout).hexdigest();key=('verify',kind);expected.setdefault(key,digest);assert expected[key]==digest;records.append({**row,'repeat':repeat,'kind':kind,'benchmark':'verify','process_cpu_ns':round(((after.ru_utime+after.ru_stime)-(before.ru_utime+before.ru_stime))*1e9),'process_wall_ns':time.perf_counter_ns()-start,'output_sha256':digest})
  (w/'volatile_bench/raw.json').write_text(json.dumps(records,indent=2));print(repeat,row['compiler'],row['candidate'],'PASS',flush=True)
