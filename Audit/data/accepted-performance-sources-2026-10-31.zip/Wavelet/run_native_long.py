from pathlib import Path
import json,random,subprocess,statistics
out=Path(__file__).parent
rows=[r for r in json.loads((out/'benchmark_binaries.json').read_text()) if r['native'] and r['candidate'] in ['baseline','avx_inline_static']]
rows += [{**r,'candidate':'baseline_control'} for r in rows if r['candidate']=='baseline']
records=[];expected={};rng=random.Random(0x571bd64)
for repeat in range(5):
 order=rows.copy();rng.shuffle(order)
 for row in order:
  for n in [100000,500000]:
   for kind in ['access','count','kth']:
    result=subprocess.run(['taskset','-c','12',row['api'],str(n),'200000','64',kind],text=True,capture_output=True,check=True)
    item=json.loads(result.stdout);key=(n,kind)
    if key in expected:assert item['hash']==expected[key]
    else:expected[key]=item['hash']
    records.append({**row,**item,'repeat':repeat})
  (out/'native_long_results.json').write_text(json.dumps(records,indent=2));print('native long',repeat,row['candidate'],row['compiler'],'OK',flush=True)
print('native long raw complete',len(records),flush=True)
