import pathlib,json,subprocess,resource,time,hashlib,random,statistics
out=pathlib.Path(__file__).parent
rows=[r for r in json.loads((out/'benchmark_binaries.json').read_text()) if r['candidate'] in ['baseline','avx_inline_static']]
rows += [{**r,'candidate':'baseline_control'} for r in rows if r['candidate']=='baseline']
records=[];expected={};rng=random.Random(0xc17123)
inputs={kind:(out/('screen_'+kind+'.in')).read_bytes() for kind in ['kth','frequency']}
cases=[(200000,30000,64,kind,False) for kind in ['access','count','less','kth','minmax','predsucc']]
cases += [(200000,20000,b,'mixed',False) for b in [31,64]]
cases += [(16,50000,b,'mixed',False) for b in [0,8,31,64]]
cases += [(1000000,0,31,'build',False),(1000000,0,31,'build',True),(200000,20000,31,'mixed',True)]
def api(row,n,q,bits,kind,type32,rep,stage):
 result=subprocess.run(['taskset','-c','12',row['api32'] if type32 else row['api'],str(n),str(q),str(bits),kind],text=True,capture_output=True,check=True)
 measure=json.loads(result.stdout);key=(n,q,bits,kind,type32)
 if key in expected:assert expected[key]==measure['hash']
 else:expected[key]=measure['hash']
 records.append({**row,**measure,'benchmark':'api','type32':type32,'repeat':rep,'stage':stage})
for rep in range(3):
 order=rows.copy();rng.shuffle(order)
 for row in order:
  for n,q,bits,kind,type32 in cases:api(row,n,q,bits,kind,type32,rep,'paired')
  for kind,data in inputs.items():
   before=resource.getrusage(resource.RUSAGE_CHILDREN);wall=time.perf_counter()
   process=subprocess.run(['taskset','-c','12',row[kind]],input=data,capture_output=True,check=True)
   elapsed=time.perf_counter()-wall;after=resource.getrusage(resource.RUSAGE_CHILDREN)
   digest=hashlib.sha256(process.stdout).hexdigest();key=('verify',kind)
   if key in expected:assert expected[key]==digest
   else:expected[key]=digest
   records.append({**row,'benchmark':'verify','kind':kind,'n':200000,'q':200000,'repeat':rep,'stage':'paired','cpu':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'wall':elapsed,'output_sha256':digest})
  (out/'static_compare_results.json').write_text(json.dumps(records,indent=2));print('paired',rep,row['candidate'],row['compiler'],row['native'],'OK',flush=True)
# B=0..64、語境界より大きい列。これは精密比較ではなく、全幅の出力一致と極端な性能低下の確認。
for row in rows:
 for bits in range(65):api(row,4096,1000,bits,'mixed',False,0,'all_widths')
 (out/'static_compare_results.json').write_text(json.dumps(records,indent=2));print('all widths',row['candidate'],row['compiler'],row['native'],'OK',flush=True)
print('all raw complete',len(records),flush=True)
