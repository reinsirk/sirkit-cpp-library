import subprocess,pathlib,json,os
root=pathlib.Path('/home/reinsirk/Atcoder_Env');out=pathlib.Path(__file__).parent
rows=[]
for name in ['avx_dispatch_exact','avx_inline_exact']:
 source=out/(name+'.cpp')
 for label,cc,args in [('gcc','/usr/bin/g++',[]),('clang','/usr/bin/clang++',['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for config,extra in [('checked',[]),('san',['-fsanitize=address,undefined','-fno-omit-frame-pointer']),('native',['-march=native']),('disabled',['-DSIRKIT_DISABLE_SIMD']),('forced_software',['-DSIRKIT_WAVELET_FORCE_SOFTWARE'])]:
   tests=['wavelet_matrix_reference_test','wavelet_matrix_second_reference_test','wavelet_matrix_allocation_test','all_widths_test'] if config in ['checked','san'] else ['wavelet_matrix_second_reference_test','all_widths_test']
   for test in tests:
    fixture=out/(test+'.cpp') if test=='all_widths_test' else root/'Verify/current/tests'/(test+'.cpp')
    binary=out/f'{name}_{label}_{config}_{test}'
    command=['taskset','-c','8',cc,*args,'-std=c++23','-O1' if config=='san' else '-O2','-DWAVELET_SOURCE="'+str(source)+'"',*extra,str(fixture),'-o',str(binary)]
    build=subprocess.run(command,text=True,capture_output=True)
    if build.returncode:print(build.stderr,flush=True);raise SystemExit(1)
    env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=0';env['UBSAN_OPTIONS']='halt_on_error=1'
    result=subprocess.run(['taskset','-c','8',str(binary)],env=env,text=True,capture_output=True)
    print(name,label,config,test,result.returncode,result.stdout.strip(),result.stderr,flush=True)
    rows.append({'candidate':name,'compiler':label,'config':config,'test':test,'command':command,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    (out/'more_validation.json').write_text(json.dumps(rows,indent=2))
    if result.returncode:raise SystemExit(1)
