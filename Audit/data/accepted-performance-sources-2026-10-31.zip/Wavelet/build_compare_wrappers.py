from pathlib import Path
import subprocess,importlib.util,contextlib,io,json,hashlib
out=Path(__file__).parent
spec=importlib.util.spec_from_file_location('elf_compare',out/'compare_elf.py');compare=importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):spec.loader.exec_module(compare)
records=[]
for cc,compiler,args in [('gcc','/usr/bin/g++',[]),('clang','/usr/bin/clang++',['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for native in [False,True]:
  baseline=None
  for name in ['baseline','avx_dispatch_static','avx_inline_static']:
   target=out/f'wrappers_{name}_{cc}_{native}'
   command=['taskset','-c','8',compiler,*args,'-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS','-DWAVELET_SOURCE="'+str(out/(name+'.cpp'))+'"',str(out/'query_wrappers.cpp'),'-o',str(target)]+(['-march=native'] if native else [])
   subprocess.run(command,check=True)
   symbols=compare.symbols(target)
   if name=='baseline':baseline=(target,symbols);continue
   entry={'compiler':cc,'native':native,'candidate':name,'wrappers':[]}
   for symbol,(address,length) in symbols.items():
    if not symbol.startswith('wm_'):continue
    old_address,old_length=baseline[1][symbol]
    old=compare.elf_bytes(baseline[0],old_address,old_length);new=compare.elf_bytes(target,address,length)
    old_instructions=compare.instructions(baseline[0],symbol);new_instructions=compare.instructions(target,symbol)
    entry['wrappers'].append({'name':symbol,'baseline_address':hex(old_address),'candidate_address':hex(address),'baseline_size':old_length,'candidate_size':length,'raw_bytes_equal':old==new,'normalized_instructions_equal':old_instructions==new_instructions,'baseline_sha256':hashlib.sha256(old).hexdigest(),'candidate_sha256':hashlib.sha256(new).hexdigest(),'vzeroupper_baseline':sum('vzeroupper' in x for x in old_instructions),'vzeroupper_candidate':sum('vzeroupper' in x for x in new_instructions)})
   records.append(entry);print(cc,native,name,'raw matches',sum(x['raw_bytes_equal'] for x in entry['wrappers']),'normalized matches',sum(x['normalized_instructions_equal'] for x in entry['wrappers']),flush=True)
(out/'wrapper_comparison.json').write_text(json.dumps(records,indent=2))
