// SPDX-License-Identifier: CC0-1.0
#include WAVELET_SOURCE
#include <chrono>
#include <cinttypes>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <random>
#include <string>
#include <string_view>
struct Stamp { double wall, cpu; };
static Stamp stamp() {
    timespec t{}; clock_gettime(CLOCK_THREAD_CPUTIME_ID, &t);
    return {std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count(),
        static_cast<double>(t.tv_sec)+static_cast<double>(t.tv_nsec)*1e-9};
}
#ifndef WAVELET_BENCH_TYPE
#define WAVELET_BENCH_TYPE std::int64_t
#endif
using Value = WAVELET_BENCH_TYPE;
using Unsigned = std::make_unsigned_t<Value>;
struct Query { std::size_t l, r, k, index; Value x; };
int main(int argc,char**argv) {
    if(argc!=5) return 2;
    const auto n=static_cast<std::size_t>(std::strtoull(argv[1],nullptr,10));
    const auto q=static_cast<std::size_t>(std::strtoull(argv[2],nullptr,10));
    const auto width=static_cast<unsigned>(std::strtoul(argv[3],nullptr,10));
    const std::string_view kind=argv[4];
    std::mt19937_64 rng(0x8931b2a);
    const auto mask=width==64?UINT64_MAX:((std::uint64_t{1}<<width)-1);
    auto restore=[](std::uint64_t x){return std::bit_cast<Value>(static_cast<Unsigned>(x^(std::uint64_t{1}<<(std::numeric_limits<Unsigned>::digits-1))));};
    std::vector<Value> values(n);
    for(auto& v:values)v=restore(rng()&mask);
    if(n>0)values[0]=restore(0);if(n>1)values[1]=restore(mask);
    std::vector<Query> queries(q);
    for(auto& query:queries){
        query.l=rng()%n;query.r=rng()%n;if(query.l>query.r)std::swap(query.l,query.r);++query.r;
        query.k=rng()%(query.r-query.l);query.index=rng()%n;
        query.x=(rng()&1)?values[rng()%n]:restore(rng()&mask);
    }
    const auto begin=stamp();
    WaveletMatrix<Value> matrix(values);
    const auto built=stamp();
    std::uint64_t hash=0;
    auto loop=[&](auto operation){for(const auto& query:queries)hash+=operation(query);};
    if(kind=="access")loop([&](const auto& x){return static_cast<std::uint64_t>(matrix.access(x.index));});
    else if(kind=="count")loop([&](const auto& x){return matrix.count(x.l,x.r,x.x);});
    else if(kind=="less")loop([&](const auto& x){return matrix.count_less(x.l,x.r,x.x);});
    else if(kind=="kth")loop([&](const auto& x){return static_cast<std::uint64_t>(matrix.kth_smallest(x.l,x.r,x.k));});
    else if(kind=="minmax")loop([&](const auto& x){return static_cast<std::uint64_t>(matrix.range_min(x.l,x.r))+static_cast<std::uint64_t>(matrix.range_max(x.l,x.r));});
    else if(kind=="predsucc")loop([&](const auto& x){return static_cast<std::uint64_t>(matrix.predecessor(x.l,x.r,x.x).value_or(0))+static_cast<std::uint64_t>(matrix.successor(x.l,x.r,x.x).value_or(0));});
    else if(kind=="mixed")loop([&](const auto& x){
        std::uint64_t part=static_cast<std::uint64_t>(matrix.access(x.index));part+=matrix.count(x.l,x.r,x.x);
        part+=matrix.count_less(x.l,x.r,x.x);part+=static_cast<std::uint64_t>(matrix.kth_smallest(x.l,x.r,x.k));
        part+=static_cast<std::uint64_t>(matrix.range_min(x.l,x.r));part+=static_cast<std::uint64_t>(matrix.range_max(x.l,x.r));
        part+=static_cast<std::uint64_t>(matrix.predecessor(x.l,x.r,x.x).value_or(0));part+=static_cast<std::uint64_t>(matrix.successor(x.l,x.r,x.x).value_or(0));return part;
    });
    const auto end=stamp();
    std::printf("{\"n\":%zu,\"q\":%zu,\"bits\":%u,\"kind\":\"%s\",\"build_cpu\":%.9f,\"build_wall\":%.9f,\"query_cpu\":%.9f,\"query_wall\":%.9f,\"hash\":%" PRIu64 "}\n",n,q,width,std::string(kind).c_str(),built.cpu-begin.cpu,built.wall-begin.wall,end.cpu-built.cpu,end.wall-built.wall,hash);
}
