from pathlib import Path
import subprocess,json,hashlib,os
root=Path('/home/reinsirk/Atcoder_Env');w=Path(__file__).resolve().parent;out=w/'volatile_final';out.mkdir(exist_ok=True);source=w/'avx_inline_volatile.cpp';rows=[]
fixtures=[root/'Verify/current/tests/wavelet_matrix_reference_test.cpp',root/'Verify/current/tests/wavelet_matrix_second_reference_test.cpp',w/'formal_wavelet_matrix_all_widths_test.cpp',root/'Verify/current/tests/wavelet_matrix_allocation_test.cpp']
false=source.read_text().replace('#include <vector>','#include <vector>\n#include <cstdlib>',1).replace('static_cast<bool>(__builtin_cpu_supports("popcnt"))','(std::getenv("SIRKIT_TEST_HAS_POPCNT") != nullptr)').replace('static_cast<bool>(__builtin_cpu_supports("avx2"))','(std::getenv("SIRKIT_TEST_HAS_AVX2") != nullptr)').replace('"popcnt %1, %0"','"ud2 # %1, %0"');(out/'runtime_false_trap.hpp').write_text(false)
for compiler in ('gcc','clang'):
 for skip in (False,True):
  for mode in ('default','sanitize','runtime_false_trap'):
   selected=fixtures if mode=='default' else fixtures[:3] if mode=='sanitize' else fixtures[2:3]
   for fixture in selected:
    header=out/'runtime_false_trap.hpp' if mode=='runtime_false_trap' else source
    prefix=['/usr/bin/g++'] if compiler=='gcc' else ['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'];flags=['-std=c++23','-O2','-DWAVELET_SOURCE="'+str(header)+'"']+(['-DSKIP_RUNTIME_CHECKS'] if skip else [])
    if mode=='sanitize':flags+=['-O1','-fsanitize=address,undefined','-fno-omit-frame-pointer']
    exe=out/(compiler+str(skip)+mode+fixture.stem);cmd=['taskset','-c','6']+prefix+flags+[str(fixture),'-o',str(exe)];build=subprocess.run(cmd,capture_output=True,text=True,timeout=240);row={'compiler':compiler,'skip':skip,'mode':mode,'fixture':str(fixture),'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(header.read_bytes()).hexdigest(),'command':cmd,'build_exit':build.returncode,'diagnostics':build.stdout+build.stderr}
    if build.returncode==0:
     env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=0';env.pop('SIRKIT_TEST_HAS_POPCNT',None);env.pop('SIRKIT_TEST_HAS_AVX2',None);run=subprocess.run(['taskset','-c','6',str(exe)],capture_output=True,text=True,env=env,timeout=180);row.update(run_exit=run.returncode,stdout=run.stdout,stderr=run.stderr)
    rows.append(row);(out/'results.json').write_text(json.dumps(rows,indent=2));print(compiler,skip,mode,fixture.stem,row.get('run_exit',1),flush=True)
    if row['build_exit'] or row.get('run_exit',1):raise SystemExit(1)
