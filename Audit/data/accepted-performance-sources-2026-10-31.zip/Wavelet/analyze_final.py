from pathlib import Path
import json,statistics,math
out=Path(__file__).parent;rows=json.loads((out/'final_compare_results.json').read_text());summary=[]
for compiler in ['gcc','clang']:
 for native in [False,True]:
  subset=[r for r in rows if r['compiler']==compiler and r['native']==native and r['stage']=='paired']
  groups={}
  for row in subset:
   key=(row['candidate'],row['benchmark'],row['kind'],row['n'],row['q'],row.get('bits'),row.get('type32'))
   groups.setdefault(key,[]).append(row)
  def median(key,measure):return statistics.median(r[measure] for r in groups[key])
  for name in ['avx_dispatch_exact','avx_inline_exact']:
   result={'compiler':compiler,'native':native,'candidate':name,'cases':[]}
   for key in groups:
    if key[0]!=name:continue
    base=('baseline',*key[1:])
    measures=['cpu','wall'] if key[1]=='verify' else (['build_cpu','build_wall'] if key[4]==0 else ['query_cpu','query_wall'])
    item={'benchmark':key[1],'kind':key[2],'n':key[3],'q':key[4],'bits':key[5],'type32':key[6]}
    for measure in measures:
     b,c=median(base,measure),median(key,measure);item[measure]={'baseline':b,'candidate':c,'ratio':c/b if b else None}
    result['cases'].append(item)
   large=[r['query_cpu']['ratio'] for r in result['cases'] if r['benchmark']=='api' and r['n']==200000]
   result['large_query_geomean_ratio']=math.prod(large)**(1/len(large));result['large_query_worst_ratio']=max(large)
   summary.append(result)
   print(compiler,'native' if native else 'default',name,'large query geom/worst',round(result['large_query_geomean_ratio'],4),round(result['large_query_worst_ratio'],4))
   for r in result['cases']:
    if r['benchmark']=='verify':print('  verify',r['kind'],{k:round(v,5) for k,v in r['cpu'].items()})
    elif r['q']==0:print('  build','32bit' if r['type32'] else '64bit',{k:round(v,5) for k,v in r['build_cpu'].items()})
    elif r['n']==200000:print('  API',r['kind'],r['bits'],'32' if r['type32'] else '64',round(r['query_cpu']['ratio'],4))
(out/'final_summary.json').write_text(json.dumps(summary,indent=2))
