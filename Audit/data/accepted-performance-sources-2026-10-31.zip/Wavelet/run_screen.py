import pathlib,json,subprocess,resource,time,hashlib,random,statistics
out=pathlib.Path(__file__).parent
rows=json.loads((out/'benchmark_binaries.json').read_text())
records=[]
rng=random.Random(0x573af)
# 計測対象と同じI/O・main。データ生成と比較用ハッシュは計測外。
def make_input(kind,n,q):
 values=[rng.randrange(1_000_000_000) for _ in range(n)]
 lines=[f'{n} {q}',' '.join(map(str,values))]
 for _ in range(q):
  l=rng.randrange(n);r=rng.randrange(l+1,n+1)
  x=rng.randrange(r-l) if kind=='kth' else (values[rng.randrange(n)] if rng.randrange(2) else rng.randrange(1_000_000_000))
  lines.append(f'{l} {r} {x}')
 return ('\n'.join(lines)+'\n').encode()
inputs={kind:make_input(kind,200000,200000) for kind in ['kth','frequency']}
for kind,data in inputs.items(): (out/('screen_'+kind+'.in')).write_bytes(data)
order=rows.copy();rng.shuffle(order)
expected={}
for row in order:
 for width,n,q,kind in [(31,200000,20000,'mixed'),(64,200000,20000,'mixed'),(31,1000000,0,'build'),(8,16,100000,'mixed'),(0,16,100000,'mixed')]:
  result=subprocess.run(['taskset','-c','12',row['api'],str(n),str(q),str(width),kind],text=True,capture_output=True,check=True)
  measurement=json.loads(result.stdout);key=('api',width,n,q,kind)
  if key in expected:assert expected[key]==measurement['hash']
  else:expected[key]=measurement['hash']
  records.append({**row,**measurement,'benchmark':'api'})
 for kind,data in inputs.items():
  before=resource.getrusage(resource.RUSAGE_CHILDREN);wall=time.perf_counter()
  process=subprocess.run(['taskset','-c','12',row[kind]],input=data,capture_output=True,check=True)
  elapsed=time.perf_counter()-wall;after=resource.getrusage(resource.RUSAGE_CHILDREN)
  digest=hashlib.sha256(process.stdout).hexdigest();key=('verify',kind)
  if key in expected:assert expected[key]==digest
  else:expected[key]=digest
  records.append({**row,'benchmark':'verify','kind':kind,'n':200000,'q':200000,'cpu':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'wall':elapsed,'output_sha256':digest})
 (out/'screen_results.json').write_text(json.dumps(records,indent=2))
 print('screen',row['candidate'],row['compiler'],'native' if row['native'] else 'default','OK',flush=True)
for compiler in ['gcc','clang']:
 for native in [False,True]:
  subset=[r for r in records if r['compiler']==compiler and r['native']==native]
  print(compiler,'native' if native else 'default')
  for name in ['baseline','swar','dispatch','pack','pack_partition','avx_partition','avx_dispatch']:
   sub=[r for r in subset if r['candidate']==name]
   apis=[r for r in sub if r['benchmark']=='api' and r['n']==200000]
   build=next(r['build_cpu'] for r in sub if r['benchmark']=='api' and r['n']==1000000)
   ver=[r['cpu'] for r in sub if r['benchmark']=='verify']
   print(name,'query',round(sum(r['query_cpu'] for r in apis),5),'build',round(build,5),'verify',round(sum(ver),5))
