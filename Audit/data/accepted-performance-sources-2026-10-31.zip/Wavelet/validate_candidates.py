import subprocess,pathlib,json,os,hashlib
root=pathlib.Path('/home/reinsirk/Atcoder_Env');out=pathlib.Path(__file__).parent
records=[]
for name in ['swar','dispatch','pack','pack_partition','avx_partition','avx_dispatch']:
 source=out/(name+'.cpp')
 for test in ['wavelet_matrix_reference_test','wavelet_matrix_second_reference_test','wavelet_matrix_allocation_test']:
  for sanitized in [False,True]:
   binary=out/(name+'_'+test+('_san' if sanitized else ''))
   command=['taskset','-c','8','/usr/bin/g++','-std=c++23','-O1' if sanitized else '-O2','-DWAVELET_SOURCE="'+str(source)+'"',str(root/'Verify/current/tests'/f'{test}.cpp'),'-o',str(binary)]
   if sanitized:command+=['-g','-fsanitize=address,undefined','-fno-omit-frame-pointer']
   built=subprocess.run(command,text=True,capture_output=True)
   if built.returncode: print(name,test,built.stderr,flush=True);raise SystemExit(1)
   env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=0';env['UBSAN_OPTIONS']='halt_on_error=1'
   run=subprocess.run(['taskset','-c','8',str(binary)],text=True,capture_output=True,env=env)
   print(name,test,sanitized,run.returncode,run.stdout.strip(),run.stderr,flush=True)
   records.append({'candidate':name,'test':test,'sanitizer':sanitized,'compile_command':command,'compile_exit':built.returncode,'run_exit':run.returncode,'stdout':run.stdout,'stderr':run.stderr,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
   (out/'initial_validation.json').write_text(json.dumps(records,indent=2))
   if run.returncode:raise SystemExit(1)
