import json,pathlib,subprocess,importlib.util,hashlib
root=pathlib.Path('/home/reinsirk/Atcoder_Env');out=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location('prepare',root/'Scripts/prepare_verify.py');prepare=importlib.util.module_from_spec(spec);spec.loader.exec_module(prepare)
rows=json.loads((out/'benchmark_binaries.json').read_text())
for name in ['baseline','swar','dispatch','pack','pack_partition','avx_partition','avx_dispatch_exact','avx_inline_exact','avx_dispatch_static','avx_inline_static']:
 source=out/(name+'.cpp')
 for label,cc,args in [('gcc','/usr/bin/g++',[]),('clang','/usr/bin/clang++',['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for native in [False,True]:
   tag=f'{name}_{label}_{"native" if native else "default"}'
   if any(row['candidate']==name and row['compiler']==label and row['native']==native for row in rows): continue
   flags=['-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS',*args]+(['-march=native'] if native else [])
   command=['taskset','-c','8',cc,*flags,'-DWAVELET_SOURCE="'+str(source)+'"',str(out/'api_benchmark.cpp'),'-o',str(out/('api_'+tag))]
   compiled=subprocess.run(command,text=True,capture_output=True)
   if compiled.returncode:print(compiled.stderr);raise SystemExit(1)
   command32=['taskset','-c','8',cc,*flags,'-DWAVELET_SOURCE="'+str(source)+'"','-DWAVELET_BENCH_TYPE=std::int32_t',str(out/'api_benchmark.cpp'),'-o',str(out/('api32_'+tag))]
   compiled=subprocess.run(command32,text=True,capture_output=True)
   if compiled.returncode:print(compiled.stderr);raise SystemExit(1)
   row={'api32':str(out/('api32_'+tag)),'candidate':name,'compiler':label,'native':native,'api':str(out/('api_'+tag)),'flags':flags,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
   for kind in ['kth','frequency']:
    entry={'id':'wavelet_'+kind,'libraries':['DataStructure/Wavelet_Matrix.cpp'],'driver':f'Verify/current/drivers/wavelet_{kind}_main.cpp','problem_url':'https://judge.yosupo.jp/problem/'+('range_kth_smallest' if kind=='kth' else 'static_range_frequency')}
    data,hashes=prepare.render(entry,source_overrides={'DataStructure/Wavelet_Matrix.cpp':source.read_bytes()})
    generated=out/f'{kind}_{name}.cpp';generated.write_bytes(data)
    binary=out/f'{kind}_{tag}'
    command=['taskset','-c','8',cc,*flags,str(generated),'-o',str(binary)]
    compiled=subprocess.run(command,text=True,capture_output=True)
    if compiled.returncode:print(compiled.stderr);raise SystemExit(1)
    row[kind]=str(binary)
   rows.append(row);(out/'benchmark_binaries.json').write_text(json.dumps(rows,indent=2));print('bench binaries ready',tag,flush=True)
