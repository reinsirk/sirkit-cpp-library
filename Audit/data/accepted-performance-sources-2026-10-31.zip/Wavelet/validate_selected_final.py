from pathlib import Path
import subprocess,json,os,hashlib
root=Path('/home/reinsirk/Atcoder_Env');out=Path(__file__).parent;source=out/'avx_inline_static.cpp'
rows=json.loads((out/'selected_final_validation.json').read_text()) if (out/'selected_final_validation.json').exists() else []
for label,cc,args in [('gcc','/usr/bin/g++',[]),('clang','/usr/bin/clang++',['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for config,flags in [('skip',['-DSKIP_RUNTIME_CHECKS']),('skip_native',['-DSKIP_RUNTIME_CHECKS','-march=native']),('san_skip',['-DSKIP_RUNTIME_CHECKS','-fsanitize=address,undefined','-fno-omit-frame-pointer']),('san_disabled',['-DSIRKIT_DISABLE_SIMD','-fsanitize=address,undefined','-fno-omit-frame-pointer'])]:
  for fixture in ['wavelet_matrix_reference_test','wavelet_matrix_second_reference_test','wavelet_matrix_allocation_test','all_widths_test']:
   key=f'{label}_{config}_{fixture}'
   if any(r['name']==key and r['exit_code']==0 for r in rows):continue
   test=out/(fixture+'.cpp') if fixture=='all_widths_test' else root/'Verify/current/tests'/(fixture+'.cpp')
   binary=out/key;command=['taskset','-c','8',cc,*args,'-std=c++23','-O1' if 'san' in config else '-O2','-DWAVELET_SOURCE="'+str(source)+'"',*flags,str(test),'-o',str(binary)]
   subprocess.run(command,check=True)
   env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=0';env['UBSAN_OPTIONS']='halt_on_error=1'
   result=subprocess.run(['taskset','-c','8',str(binary)],text=True,capture_output=True,env=env)
   rows.append({'name':key,'compile_command':command,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
   (out/'selected_final_validation.json').write_text(json.dumps(rows,indent=2))
   print(key,result.returncode,result.stdout.strip(),result.stderr,flush=True)
   if result.returncode:raise SystemExit(1)
