from pathlib import Path
import hashlib,json
root=Path('/home/reinsirk/Atcoder_Env');out=Path(__file__).parent
baseline=(root/'DataStructure/Wavelet_Matrix.cpp').read_text()
(out/'baseline.cpp').write_text(baseline)
software='''inline unsigned wavelet_software_popcount(std::uint64_t value) noexcept {
    value -= (value >> 1) & UINT64_C(0x5555555555555555);
    value = (value & UINT64_C(0x3333333333333333)) + ((value >> 2) & UINT64_C(0x3333333333333333));
    value = (value + (value >> 4)) & UINT64_C(0x0f0f0f0f0f0f0f0f);
    return static_cast<unsigned>((value * UINT64_C(0x0101010101010101)) >> 56);
}
'''
capcondition='!defined(SIRKIT_DISABLE_SIMD) && !defined(SIRKIT_WAVELET_FORCE_SOFTWARE) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__))'
oldbuild='''            std::size_t zeros = 0;
            for (std::size_t i = 0; i < n_; ++i) {
                if ((current[i] >> shift) & U{1}) bits.set(i);
                else ++zeros;
            }
            bits.finish(); zero_.push_back(zeros);'''
oldpartition='''                if ((value >> shift) & U{1}) next[high++] = value;
                else next[low++] = value;'''
newpartition='''                const auto bit = static_cast<std::size_t>((value >> shift) & U{1});
                next[bit != 0 ? high : low] = value;
                low += bit ^ std::size_t{1}; high += bit;'''
scalarbuild='''    template<class U> std::size_t build_bits(std::span<const U> values, unsigned shift) {
        prefix_.resize(words_.size() + 1);
        for (std::size_t word = 0; word < words_.size(); ++word) {
            const auto start = word * 64;
            const auto count = std::min(std::size_t{64}, values.size() - start);
            std::uint64_t packed = 0;
            for (std::size_t i = 0; i < count; ++i)
                packed |= static_cast<std::uint64_t>((values[start + i] >> shift) & U{1}) << i;
            words_[word] = packed;
            prefix_[word + 1] = prefix_[word] + wavelet_popcount(packed);
        }
        return values.size() - prefix_.back();
    }
'''
avxbuild='''#if CAPCONDITION
    template<class U> __attribute__((target("avx2")))
    std::size_t build_avx2(std::span<const U> values, unsigned shift) {
        prefix_.resize(words_.size() + 1);
        for (std::size_t word = 0; word < words_.size(); ++word) {
            const auto start = word * 64;
            const auto count = std::min(std::size_t{64}, values.size() - start);
            std::uint64_t packed = 0;
            std::size_t i = 0;
            if constexpr (sizeof(U) == 4) {
                const auto shifts = _mm256_set1_epi32(static_cast<int>(31 - shift));
                for (; i + 8 <= count; i += 8) {
                    const auto loaded = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(values.data() + start + i));
                    const auto shifted = _mm256_sllv_epi32(loaded, shifts);
                    packed |= static_cast<std::uint64_t>(_mm256_movemask_ps(_mm256_castsi256_ps(shifted))) << i;
                }
            } else if constexpr (sizeof(U) == 8) {
                const auto shifts = _mm256_set1_epi64x(static_cast<std::int64_t>(63 - shift));
                for (; i + 4 <= count; i += 4) {
                    const auto loaded = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(values.data() + start + i));
                    const auto shifted = _mm256_sllv_epi64(loaded, shifts);
                    packed |= static_cast<std::uint64_t>(_mm256_movemask_pd(_mm256_castsi256_pd(shifted))) << i;
                }
            }
            for (; i < count; ++i)
                packed |= static_cast<std::uint64_t>((values[start + i] >> shift) & U{1}) << i;
            words_[word] = packed;
            prefix_[word + 1] = prefix_[word] + wavelet_popcount(packed);
        }
        return values.size() - prefix_.back();
    }
#endif
'''.replace('CAPCONDITION',capcondition)
records={}
for name,dispatch,pack,partition,avx in [('swar',False,False,False,False),('dispatch',True,False,False,False),('pack',False,True,False,False),('pack_partition',False,True,True,False),('avx_partition',False,True,True,True),('avx_dispatch',True,True,True,True)]:
    text=baseline.replace('std::popcount(', 'wavelet_popcount(')
    helpers='\n#ifndef SIRKIT_WAVELET_POPCOUNT_DEFINED\n#define SIRKIT_WAVELET_POPCOUNT_DEFINED\nnamespace reinsirk::detail {\n'+software
    if dispatch:
        helpers+='#if '+capcondition+' && !defined(__POPCNT__)\n'
        helpers+='inline const bool wavelet_has_popcnt = [] { __builtin_cpu_init(); return static_cast<bool>(__builtin_cpu_supports("popcnt")); }();\n'
        helpers+='__attribute__((target("popcnt"))) inline unsigned wavelet_hardware_popcount(std::uint64_t value) noexcept { return static_cast<unsigned>(std::popcount(value)); }\n#endif\n'
    if avx:
        helpers+='#if '+capcondition+'\ninline const bool wavelet_has_avx2 = [] { __builtin_cpu_init(); return static_cast<bool>(__builtin_cpu_supports("avx2")); }();\n#endif\n'
    helpers+='inline unsigned wavelet_popcount(std::uint64_t value) noexcept {\n#if defined(__POPCNT__)\n    return static_cast<unsigned>(std::popcount(value));\n'
    if dispatch:
        helpers+='#elif '+capcondition+'\n    return wavelet_has_popcnt ? wavelet_hardware_popcount(value) : wavelet_software_popcount(value);\n'
    helpers+='#else\n    return wavelet_software_popcount(value);\n#endif\n}\n}\n#endif\n'
    if avx:
        helpers='#if '+capcondition+'\n#include <immintrin.h>\n#endif\n'+helpers
    text=text.replace('#ifndef SIRKIT_WAVELET_RANK_BITS_DEFINED',helpers+'\n#ifndef SIRKIT_WAVELET_RANK_BITS_DEFINED',1)
    if pack:
        added=scalarbuild
        if avx:
            added=avxbuild+added.replace('        prefix_.resize(words_.size() + 1);','''#if CAPCONDITION
        if constexpr (sizeof(U) == 4 || sizeof(U) == 8)
            if (values.size() >= 128 && wavelet_has_avx2) return build_avx2(values, shift);
#endif
        prefix_.resize(words_.size() + 1);'''.replace('CAPCONDITION',capcondition),1)
        text=text.replace('    bool at(std::size_t index)',added+'    bool at(std::size_t index)',1)
        assert oldbuild in text
        text=text.replace(oldbuild,'            const auto zeros = bits.build_bits(std::span<const U>(current), shift);\n            zero_.push_back(zeros);')
    if partition:
        assert oldpartition in text;text=text.replace(oldpartition,newpartition)
    (out/(name+'.cpp')).write_text(text)
    records[name]={'source':str(out/(name+'.cpp')),'sha256':hashlib.sha256(text.encode()).hexdigest(),'runtime_popcnt':dispatch,'packed_build':pack,'branchless_partition':partition,'avx2_build':avx}
records['baseline']={'source':str(out/'baseline.cpp'),'sha256':hashlib.sha256(baseline.encode()).hexdigest()}
(out/'candidates.json').write_text(json.dumps(records,indent=2))
print('created',list(records))
