from pathlib import Path
import sys,json,hashlib,zipfile,datetime
sys.dont_write_bytecode=True
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_remaining_20261113');sys.path.insert(0,str(R));from Scripts import optimization_handoff as h,prepare_verify as p
from Scripts.deterministic_zip import write_archive
sha=lambda b:hashlib.sha256(b).hexdigest();progress=json.loads((R/'Verify/optimization/remaining-2026-11-13.json').read_text());assert (progress['codex_complete'],progress['fable_complete'],progress['fable_pending'],progress['post_resubmission_fable_complete'])==(101,101,0,3)
q=h.queue(R,R/'Verify/optimization/stages');from collections import Counter
pre=json.loads((W/'final_validation_after_fable_sa16_flags/results.json').read_text());assert pre['status']=='passed';assert all(sha((R/path).read_bytes())==digest for path,digest in pre['source_hashes_after'].items());assert len(list((R/'Audit').glob('optimization-fable-batch-*-2026-11-13.json')))==12
for path in [R/'Audit/optimization-final-2026-11-13.json',R/'Audit/data/optimization-final-validation-2026-11-13.zip',Path('/tmp/Verify_ready_87_20261113_after_Fable.zip'),Path('/tmp/Verify_ready_new47_20261113_after_Fable.zip')]:assert not path.exists(),path
assert Counter(e['next_stage'] for e in q['entries'])=={'complete':8,'confirm_source':7,'resubmit':87}
entries={e['id']:e for e in p.collect()};ready=sorted([e for e in q['entries'] if e['next_stage']=='resubmit'],key=lambda e:e['id']);oldzip=Path('/tmp/Verify_ready_40_20261113_after_Fable.zip')
with zipfile.ZipFile(oldzip) as z:old={n.removesuffix('.cpp'):sha(z.read(n)) for n in z.namelist() if n.endswith('.cpp')}
assert len(old)==40
for id,digest in old.items():assert sha((R/'Verify/current/submissions'/f'{id}.cpp').read_bytes())==digest,('Earlierready40source changed',id)
ready_artifacts=[]
for label,rs in [('87',ready),('new47',[e for e in ready if e['id'] not in old])]:
 assert len(rs)==(87 if label=='87' else 47);files={};table=['# 再提出用コード','',f'Codex→Fableの検討、採否に必要な独立照合と測定を終えた{len(rs)}件です。現在版のオンライン再提出は未実施です。', '先の40件を全体87件に含み、new47版はそこから新たに準備できた47件だけです。各cppをそのままC++23へ提出できます。Submissionコメントは以前の提出履歴です。','', '| ソース | 問題 | SHA-256 |','| --- | --- | --- |']
 for e in rs:
  id=e['id'];data=(R/'Verify/current/submissions'/f'{id}.cpp').read_bytes();assert sha(data)==e['source_sha256'];rendered,_=p.render(entries[id]);assert data==rendered;files[id+'.cpp']=data;table.append(f"| {id}.cpp | {e['problem_url']} | {sha(data)} |")
 files['README.md']=('\n'.join(table)+'\n').encode();path=Path('/tmp')/f'Verify_ready_{label}_20261113_after_Fable.zip';assert not path.exists();write_archive(path,files);ready_artifacts.append({'path':str(path),'count':len(rs),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())})
validation=json.loads((W/'final_validation_after_fable_sa16_flags/results.json').read_text());assert validation['status']=='passed';assert all(sha((R/path).read_bytes())==s for path,s in validation['source_hashes_after'].items());log=(W/'final_validation_after_fable_sa16_flags/python_tests.stderr.log').read_text();assert 'Ran 276 tests' in log and log.rstrip().endswith('OK');assert len(validation['commands'])==16 and all(x['returncode']==0 for x in validation['commands'])
proof_files={};v=W/'final_validation_after_fable_sa16_flags'
for path in v.iterdir():
 if path.is_file():proof_files['final_validation/'+path.name]=path.read_bytes()
for name in ['final_verify_after_fable.py','final_verify_after_fable_sa16.py','final_verify_after_fable_sa16_flags.py','finalize_fable_all.py']:
 proof_files['reproduction/'+name]=(W/name).read_bytes()
proof_files['current_queue.json']=(json.dumps(q,ensure_ascii=False,indent=2)+'\n').encode();proof_files['current_progress.json']=(R/'Verify/optimization/remaining-2026-11-13.json').read_bytes();proof_files['ready_artifacts.json']=(json.dumps(ready_artifacts,indent=2)+'\n').encode()
zrel='Audit/data/optimization-final-validation-2026-11-13.zip';assert not (R/zrel).exists();write_archive(R/zrel,proof_files)
reports=[]
for path in sorted((R/'Audit').glob('optimization-fable-batch-*-2026-11-13.json')):
 r=json.loads(path.read_text());z=r['snapshot_archive'];assert sha((R/z['path']).read_bytes())==z['sha256'];assert r['execution']['is_error'] is False and r['execution']['extra_usage_used'] is False;reports.append({'path':str(path.relative_to(R)),'sha256':sha(path.read_bytes()),'ids':list(r['snapshots']),'decisions':r['candidate_decisions']['candidate_decisions'],'archive':z})
assert len(reports)==12
report={'format':1,'date':'2026-11-13','prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'complete','scope':'過去ACのVerifyコード101件をCodex→Fableで検討。変更後Graph3も再検討。Z Algorithmの完了記録は別枠。Library Checkerはプログラム全体、AtCoderは本体と素直なmainを対象とする。','pipeline':{'path':'Verify/optimization/remaining-2026-11-13.json','sha256':sha((R/'Verify/optimization/remaining-2026-11-13.json').read_bytes()),'codex_complete':101,'fable_complete':101,'fable_pending':0,'post_resubmission_fable_complete':3},'current_queue':q,'batch_reports':reports,'fable_quota':{'ordinary_reset_confirmed_at':'2026-11-13T19:40:00+09:00','five_hour_final_observed_utilization':0.96,'extra_usage_used':False,'free_reset_used':False,'further_model_calls_needed':False,'last_successful_execution':'batch_11。実際のassistant modelはclaude-fable-5-2、is_error=false、completedを確認。'},'validation':{'python_tests':276,'sync_checks':15,'all_passed':True,'source_hashes':validation['source_hashes_after'],'archive':{'path':zrel,'sha256':sha((R/zrel).read_bytes())}},'ready_artifacts':ready_artifacts,'online_scope':'Z Algorithmを含む8件は現行本文照合済みAC。AtCoder7件は画像AC・実提出本文未照合。87件は現在版の再提出待ち。旧ACを変更後ソースへ転記しない。','fastest_reconsideration':'Audit/fastest-reconsideration-2026-11-13.md','source_policy':'本体・main・入出力・コンパイラ設定、および異なる実験の効果は分けて記録する。不採用案は製品へ反映せず検証資料を保存する。','git':'gitのステージ・コミット・push・PR作成は実施していない。'}
path=R/'Audit/optimization-final-2026-11-13.json';assert not path.exists();path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'report':str(path),'validation_archive':zrel,'ready_artifacts':ready_artifacts},ensure_ascii=False,indent=2))
