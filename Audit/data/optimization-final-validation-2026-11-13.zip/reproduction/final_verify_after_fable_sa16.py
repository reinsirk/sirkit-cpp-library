from pathlib import Path
import sys,subprocess,os,json,hashlib,datetime
sys.dont_write_bytecode=True
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_remaining_20261113/final_validation_after_fable_sa16');W.mkdir(exist_ok=False);os.sched_setaffinity(0,{13});env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');report={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','commands':[]}
paths=['Verify/current/manifest.json','Variants/manifest.json','Variants/verify_manifest.json','Verify/current/common/fast_io.hpp','Math/Eratosthenes.cpp','String/Suffix_Array.cpp','Geometry/components/polygon.inc','Geometry/components/linear_functions.inc'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();report['source_hashes_before']={p:sha(R/p) for p in paths}
def save():(W/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
commands=[('python_tests',[sys.executable,'-m','unittest','discover','-s','Scripts/tests','-v'])]
for generator in ['generate_geometry.py','generate_zeta.py','generate_combination.py','generate_formal_power_series.py','generate_linear_recurrence.py','generate_gaussian_elimination.py','generate_binary_matrix.py','generate_convolution.py','generate_polynomial.py','generate_fast_sources.py','generate_variants.py','prepare_variant_verify.py','check_source_api_docs.py','prepare_verify.py','update_verify_status.py']:
 commands.append((generator.removesuffix('.py'),[sys.executable,'Scripts/'+generator,'--check']))
for name,cmd in commands:
 with (W/(name+'.stdout.log')).open('w') as out,(W/(name+'.stderr.log')).open('w') as err:q=subprocess.run(cmd,cwd=R,env=env,stdout=out,stderr=err)
 report['commands'].append({'name':name,'command':cmd,'returncode':q.returncode,'stdout':str(W/(name+'.stdout.log')),'stderr':str(W/(name+'.stderr.log'))});save();print(name,q.returncode,flush=True);assert q.returncode==0,name
report['source_hashes_after']={p:sha(R/p) for p in paths};assert report['source_hashes_after']==report['source_hashes_before'];report['status']='passed';report['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
