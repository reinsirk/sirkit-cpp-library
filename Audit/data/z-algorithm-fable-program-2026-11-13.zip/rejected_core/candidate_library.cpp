// SPDX-License-Identifier: CC0-1.0
// 参考（Z配列の用途とVerify先。実装は独自構成）:
// https://judge.yosupo.jp/problem/zalgorithm
// 参考（ACLのAPI）: https://atcoder.github.io/ac-library/production/document_ja/string.html
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/z_algorithm.md
//
// API一覧
// z_algorithm(const std::string&)/z_algorithm<T>(const std::vector<T>&): ACL形式のZ配列を返す。
// 追加のz_algorithm(sequence)は任意の添字アクセス可能な列に対応。空なら{}、非空ならz[0]=n。
// PrefixMatches(pattern,text): textの各開始位置とpatternの共通接頭辞長を返す。
// ZMatches(pattern,text): 完全一致する開始位置を昇順に返す。空patternは0..text.size()。
// size()/添字アクセスと同値関係の==が使える列が前提。比較O(1)ならZはO(n)、後2者はO(n+m)時間。
// 各列長はINT_MAX未満。Z/PrefixMatchesの領域は返却値とpattern長、ZMatchesはこれに一致数。
// SIRKIT_DISABLE_SIMD: string/string_view/vectorの4バイト以下の整数列で使う8バイト単位比較を除く。

#include <algorithm>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <vector>

#ifndef SIRKIT_Z_ALGORITHM_IMPL_DEFINED
#define SIRKIT_Z_ALGORITHM_IMPL_DEFINED
namespace reinsirk::detail {
#ifndef SIRKIT_DISABLE_SIMD
// s[i]がdata()[i]と一致する標準の列だけを8バイト単位比較の対象にする。
template <class> inline constexpr bool z_word_container = false;
template <class C, class Traits, class Alloc>
inline constexpr bool z_word_container<std::basic_string<C, Traits, Alloc>> = true;
template <class C, class Traits>
inline constexpr bool z_word_container<std::basic_string_view<C, Traits>> = true;
template <class T, class Alloc>
inline constexpr bool z_word_container<std::vector<T, Alloc>> = true;

// 組み込みの==がバイト列の一致と同値になる4バイト以下の整数要素（boolを除く）。
template <class Sequence>
concept z_word_sequence = std::endian::native == std::endian::little
    && z_word_container<Sequence>
    && std::is_integral_v<typename Sequence::value_type>
    && !std::is_same_v<typename Sequence::value_type, bool>
    && std::has_unique_object_representations_v<typename Sequence::value_type>
    && sizeof(typename Sequence::value_type) <= 4;

inline std::uint64_t z_load_word(const void* p) noexcept {
    std::uint64_t word;
    std::memcpy(&word, p, sizeof(word));
    return word;
}
#endif

// i以降でs[0]と等しい最初の位置を返す。なければn。
template <class Sequence>
int z_find_first(const Sequence& s, int i, int n) {
#ifndef SIRKIT_DISABLE_SIMD
    if constexpr (z_word_sequence<Sequence>) {
        using T = typename Sequence::value_type;
        constexpr int lane_bits = static_cast<int>(8 * sizeof(T));
        constexpr int lanes = static_cast<int>(8 / sizeof(T));
        constexpr std::uint64_t ones = ~std::uint64_t{0} / (~std::uint64_t{0} >> (64 - lane_bits));
        constexpr std::uint64_t highs = ones << (lane_bits - 1);
        const T* const data = s.data();
        const std::uint64_t first = ones * static_cast<std::make_unsigned_t<T>>(data[0]);
        // s[0]と等しい要素を0にして探す。最下位の検出は下位からの借りの影響を受けない。
        for (; n - i >= lanes; i += lanes) {
            const std::uint64_t x = z_load_word(data + i) ^ first;
            const std::uint64_t hit = (x - ones) & ~x & highs;
            if (hit != 0) return i + std::countr_zero(hit) / lane_bits;
        }
    }
#endif
    while (i < n && !static_cast<bool>(s[0] == s[i])) ++i;
    return i;
}

// s[0,length)=s[i,i+length)の一致を伸ばし、最初の不一致か末尾までの一致長を返す。
template <class Sequence>
int z_extend(const Sequence& s, int i, int length, int n) {
#ifndef SIRKIT_DISABLE_SIMD
    if constexpr (z_word_sequence<Sequence>) {
        using T = typename Sequence::value_type;
        constexpr int lane_bits = static_cast<int>(8 * sizeof(T));
        constexpr int lanes = static_cast<int>(8 / sizeof(T));
        const T* const data = s.data();
        // 最下位の異なるビットが最初の不一致要素を示す（リトルエンディアン）。
        for (; n - i - length >= lanes; length += lanes) {
            const std::uint64_t diff = z_load_word(data + length) ^ z_load_word(data + i + length);
            if (diff != 0) return length + std::countr_zero(diff) / lane_bits;
        }
    }
#endif
    while (length < n - i && s[length] == s[i + length]) ++length;
    return length;
}

template <class Sequence>
std::vector<int> z_algorithm_impl(const Sequence& s) {
    if (s.size() >= static_cast<std::size_t>(std::numeric_limits<int>::max()))
        throw std::length_error("z_algorithm: sequence too long");
    const int n = static_cast<int>(s.size());
    std::vector<int> z(s.size());
    if (n == 0) return z;
    z[0] = n;
    int i = 1, length = 0;
    while (i < n) {
        if (length == 0) {
            // 未処理位置のz[i]は零初期化済み。s[0]と一致しない位置は書き直さない。
            i = reinsirk::detail::z_find_first(s, i, n);
            if (i == n) break;
            length = 1;
        }
        length = reinsirk::detail::z_extend(s, i, length, n);
        z[i] = length;
        // 末尾まで一致した箱では、残りも確定済みの値だけで埋められる。
        if (length == n - i) {
            if (i == 1) {
                for (++i; i < n; ++i) z[i] = n - i;
            } else {
                const int left = i;
                for (++i; i < n; ++i) z[i] = std::min(n - i, z[i - left]);
            }
            break;
        }
        // 箱内で不一致まで確定する位置を写し、次の位置へ一致長を持ち越す。
        int advance = 1;
        while (advance < length && z[advance] < length - advance) {
            z[i + advance] = z[advance];
            ++advance;
        }
        i += advance;
        length = std::max(0, length - advance);
    }
    return z;
}
}
#endif

#ifndef SIRKIT_Z_ALGORITHM_DEFINED
#define SIRKIT_Z_ALGORITHM_DEFINED
template<class T>
std::vector<int> z_algorithm(const std::vector<T>& s) {
    return reinsirk::detail::z_algorithm_impl(s);
}
inline std::vector<int> z_algorithm(const std::string& s) {
    return reinsirk::detail::z_algorithm_impl(s);
}
template<class Sequence>
    requires requires(const Sequence& s) { s.size(); s[0] == s[0]; }
std::vector<int> z_algorithm(const Sequence& s) {
    return reinsirk::detail::z_algorithm_impl(s);
}
#endif

#ifndef SIRKIT_Z_MATCHES_DEFINED
#define SIRKIT_Z_MATCHES_DEFINED
template <class Pattern, class Text>
std::vector<int> PrefixMatches(const Pattern& pattern, const Text& text) {
    if (text.size() >= static_cast<std::size_t>(std::numeric_limits<int>::max()))
        throw std::length_error("PrefixMatches: text too long");
    const auto z = z_algorithm(pattern);
    const int n = static_cast<int>(text.size()), m = static_cast<int>(pattern.size());
    std::vector<int> matches(text.size());
    int left = 0, right = 0;
    for (int i = 0; i < n; ++i) {
        int length = i < right ? std::min(right - i, z[i - left]) : 0;
        while (length < m && length < n - i && pattern[length] == text[i + length]) ++length;
        matches[i] = length;
        if (i + length > right) { left = i; right = i + length; }
    }
    return matches;
}

template <class Pattern, class Text>
std::vector<int> ZMatches(const Pattern& pattern, const Text& text) {
    auto lengths = PrefixMatches(pattern, text);
    std::vector<int> positions;
    const int m = static_cast<int>(pattern.size());
    for (int i = 0; i < static_cast<int>(lengths.size()); ++i)
        if (lengths[i] == m) positions.push_back(i);
    if (m == 0) positions.push_back(static_cast<int>(text.size()));
    return positions;
}
#endif
