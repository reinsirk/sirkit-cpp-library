#include Z_HEADER
#include <array>
#include <cassert>
#include <deque>
#include <random>
#include <span>
#include <cstdio>
struct FoldTraits : std::char_traits<char> {
 static bool eq(char a,char b) { return (a|32)==(b|32); }
};
struct ProxyBool { bool value; explicit operator bool() const{return value;} bool operator!()const=delete; };
struct Element { int value; ProxyBool operator==(const Element& b)const{return {value%3==b.value%3};} };
struct Custom {std::vector<int> a; std::size_t size()const{return a.size();} int operator[](int i)const{return a[i]%7;} };
struct Huge {std::size_t n;std::size_t size()const{return n;}int operator[](int)const{std::abort();}};
std::uint64_t checks=0;
void check(bool good){++checks;if(!good){std::fprintf(stderr,"failure at check %llu\n",static_cast<unsigned long long>(checks));std::abort();}}
template<class S> std::vector<int> naive(const S&s){std::vector<int> z(s.size());for(int i=0;i<static_cast<int>(s.size());++i)while(z[i]<static_cast<int>(s.size())-i&&s[z[i]]==s[i+z[i]])++z[i];return z;}
template<class S>void one(const S&s){check(z_algorithm(s)==naive(s));}
template<class P,class T>void matches(const P&p,const T&t){std::vector<int> lengths(t.size()),positions;for(int i=0;i<static_cast<int>(t.size());++i){while(lengths[i]<static_cast<int>(p.size())&&lengths[i]<static_cast<int>(t.size())-i&&p[lengths[i]]==t[i+lengths[i]])++lengths[i];if(lengths[i]==static_cast<int>(p.size()))positions.push_back(i);}if(p.size()==0)positions.push_back(static_cast<int>(t.size()));check(PrefixMatches(p,t)==lengths);check(ZMatches(p,t)==positions);}
template<class T>void typed(std::mt19937_64&rng){for(int n=0;n<=192;++n)for(int shape=0;shape<6;++shape){std::vector<T>s(n);for(int i=0;i<n;++i){auto bits=shape==0?0:shape==1?i%3:shape==2?rng()%2:shape==3?rng()%5:shape==4?rng():i==n/2?1:0;s[i]=static_cast<T>(bits);}if(n&&shape==5)s[0]=std::numeric_limits<T>::min();one(s);one(std::span<const T>(s));one(std::deque<T>(s.begin(),s.end()));std::vector<T> p(s.begin(),s.begin()+n/3);matches(p,s);}}
int main(){std::mt19937_64 rng(0xf00dcafe1234ULL);
for(int n=0;n<=14;++n)for(unsigned mask=0;mask<(1U<<n);++mask){std::string s(n,'a');for(int i=0;i<n;++i)s[i]+=mask>>i&1;one(s);one(std::string_view(s));}
typed<signed char>(rng);typed<unsigned char>(rng);typed<char16_t>(rng);typed<std::int16_t>(rng);typed<std::uint16_t>(rng);typed<std::int32_t>(rng);typed<std::uint32_t>(rng);typed<char32_t>(rng);typed<std::int64_t>(rng);
for(int n=0;n<=192;++n){std::vector<bool>s(n);std::vector<Element> objects(n);Custom custom;for(int i=0;i<n;++i){s[i]=rng()&1;objects[i]={static_cast<int>(rng()%30)};custom.a.push_back(rng()%70);}one(s);one(objects);one(custom);std::vector<bool>p(s.begin(),s.begin()+n/2);matches(p,s);std::vector<Element>op(objects.begin(),objects.begin()+n/2);matches(op,objects);}
for(int n=0;n<=192;++n){std::basic_string<char,FoldTraits>s(n,'a');for(int i=0;i<n;++i)s[i]="aAbB"[rng()%4];one(s);one(std::basic_string_view<char,FoldTraits>(s));matches(s.substr(0,n/3),s);}
std::basic_string<char,FoldTraits> semantics="aAaAaAaAaAaAaAaA";check(!static_cast<bool>(semantics[0]==semantics[1]));check(FoldTraits::eq(semantics[0],semantics[1]));check(z_algorithm(semantics)[1]==0);
for(auto n:{static_cast<std::size_t>(INT32_MAX),std::numeric_limits<std::size_t>::max()}){bool got=false;try{z_algorithm(Huge{n});}catch(const std::length_error&){got=true;}check(got);got=false;try{PrefixMatches(Huge{n},std::string{});}catch(const std::length_error&){got=true;}check(got);got=false;try{PrefixMatches(std::string{},Huge{n});}catch(const std::length_error&){got=true;}check(got);}
std::printf("independent checks=%llu\n",static_cast<unsigned long long>(checks));}
