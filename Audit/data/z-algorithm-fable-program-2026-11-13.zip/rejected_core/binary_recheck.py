from pathlib import Path
import json,os,subprocess,time,statistics
os.sched_setaffinity(0,{10});root=Path('/tmp/sirkit_dev_pipeline_20261113');work=Path('/tmp/sirkit_z_library_review');report=[]
for compiler in ['g++','clang++']:
 for driver,pair in [('common',['codex','claude_library']),('custom',['claude_driver','claude_both'])]:
  results={v:[] for v in pair}
  for repeat in range(47):
   for v in pair if repeat%2==0 else pair[::-1]:
    with (root/'binary_500000.in').open('rb') as inp:
     begin=time.perf_counter_ns();subprocess.run([str(root/f'z_{compiler}_{v}')],stdin=inp,stdout=subprocess.DEVNULL,check=True);ms=(time.perf_counter_ns()-begin)/1e6
    if repeat>=6:results[v].append(ms)
  med={v:statistics.median(t) for v,t in results.items()};row={'compiler':compiler,'driver':driver,'median_ms':med,'candidate_over_normal':med[pair[1]]/med[pair[0]],'samples':results};report.append(row);print(row['compiler'],driver,med,row['candidate_over_normal'],flush=True)
(work/'binary_recheck.json').write_text(json.dumps(report,indent=2)+'\n')
