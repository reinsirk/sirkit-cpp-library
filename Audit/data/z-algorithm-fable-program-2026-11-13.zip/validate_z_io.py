import hashlib,json,os,subprocess
from pathlib import Path
w=Path('/tmp/sirkit_dev_pipeline_20261113');root=Path('/home/reinsirk/Atcoder_Env');os.sched_setaffinity(0,{11});rows=[]
for compiler,extra in [('g++',[]),('clang++',['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for scalar in (False,True):
  exe=w/f'io_test_{compiler}_{scalar}';cmd=[compiler,'-std=c++23','-O2','-Wall','-Wextra',*extra]
  if scalar:cmd+=['-DSIRKIT_DISABLE_SIMD']
  cmd +=[str(root/'Verify/current/tests/z_algorithm_io_test.cpp'),'-o',str(exe)]
  r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,r.stderr
  run=subprocess.run([str(exe)],capture_output=True,text=True);assert run.returncode==0,run.stderr
  rows.append({'compiler':compiler,'scalar':scalar,'command':cmd,'compile_diagnostics':r.stderr,'returncode':run.returncode})
cmd=['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-std=c++23','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',str(root/'Verify/current/tests/z_algorithm_io_test.cpp'),'-o',str(w/'io_test_sanitized')]
r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,r.stderr
r=subprocess.run([str(w/'io_test_sanitized')],env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'},capture_output=True,text=True);assert r.returncode==0,r.stderr
rows.append({'compiler':'clang++','command':cmd,'sanitizers':'ASan+UBSan, LeakSanitizer disabled because unavailable under host ptrace','returncode':r.returncode})
report={'status':'PASS','helper_tests':rows,'coverage':'0..9999999 and uint32 boundary/random to_chars comparison; all-byte pairs/random delimiter comparisons; bounds guards','body_sha256':hashlib.sha256((root/'String/Z_Algorithm.cpp').read_bytes()).hexdigest(),'driver_sha256':hashlib.sha256((root/'Verify/current/drivers/z_algorithm_main.cpp').read_bytes()).hexdigest()}
(w/'z_io_validation.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS: helper GCC/Clang x scalar/default and ASan/UBSan')
