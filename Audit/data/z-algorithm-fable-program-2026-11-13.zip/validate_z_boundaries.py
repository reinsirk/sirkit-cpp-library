from pathlib import Path
import json,os,subprocess
w=Path('/tmp/sirkit_dev_pipeline_20261113');os.sched_setaffinity(0,{11});cases=0;rows=[]
for compiler in ['g++','clang++']:
 for stage in ['final','scalar']:
  exe=w/f'z_{compiler}_{stage}';count=0
  for n in [0,1,7,8,9,65535,65536,65537,131071,131072,131073,(1<<20)-1,1<<20,(1<<20)+1,(2<<20)+1]:
   expected=(' '.join(str(n-i if i%4==0 else 0) for i in range(n))+'\n').encode()
   token=(b'ab\x80\xff'*((n+3)//4))[:n]
   for prefix,suffix in [(b'',b''),(bytes(range(33)),b'\n ignored' if n else b'')]:
    r=subprocess.run([str(exe)],input=prefix+token+suffix,capture_output=True,check=True)
    assert r.stdout==expected,(compiler,stage,n,prefix,r.stdout[:100],expected[:100]);count+=1
  if Path('/dev/full').exists():
   with open('/dev/full','wb') as full:r=subprocess.run([str(exe)],input=b'a\n',stdout=full,stderr=subprocess.PIPE)
   assert r.returncode!=0;count+=1
  rows.append({'compiler':compiler,'stage':stage,'cases':count,'status':'PASS'});cases+=count
report={'status':'PASS','cases':cases,'results':rows,'coverage':'closed-form periodic Z reference, all leading control/space bytes, no newline, high byte values, output flush and 1/2MiB fread expansion boundaries, /dev/full write error exit'}
(w/'z_boundaries.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS',cases)
