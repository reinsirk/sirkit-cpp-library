from pathlib import Path
import json,os,statistics,subprocess,sys,time
sys.path.insert(0,'/home/reinsirk/Atcoder_Env')
from Scripts import prepare_verify as p
w=Path('/tmp/sirkit_dev_pipeline_20261113');os.sched_setaffinity(0,{9})
e=next(x for x in p.collect() if x['id']=='z_algorithm');driver=(p.ROOT/e['driver']).read_text()
vectors={'word_both':driver,'word_scan':driver.replace('#ifndef SIRKIT_DISABLE_SIMD','',1)}
# Disable the numeric word branch or scanner branch independently, preserving preprocessor nesting.
parts=driver.split('#ifndef SIRKIT_DISABLE_SIMD');assert len(parts)==3
variants={'word_both':driver,'word_scan':parts[0]+'#ifndef SIRKIT_DISABLE_SIMD'+parts[1]+'#if 0'+parts[2], 'word_output':parts[0]+'#if 0'+parts[1]+'#ifndef SIRKIT_DISABLE_SIMD'+parts[2], 'scalar':parts[0]+'#if 0'+parts[1]+'#if 0'+parts[2]}
results=[]
for compiler in ['g++','clang++']:
 bins={}
 for label,s in variants.items():
  source,_=p.render(e,driver_override=s);path=w/f'z_path_{label}.cpp';path.write_bytes(source);exe=w/f'z_path_{compiler}_{label}'
  cmd=[compiler,'-std=c++23','-O2','-Wall','-Wextra']
  if compiler=='clang++':cmd+=['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
  r=subprocess.run(cmd+[str(path),'-o',str(exe)],capture_output=True,text=True);assert r.returncode==0,r.stderr;bins[label]=exe
 labels=list(variants)
 for case in ['random','equal','periodic','binary','fibonacci']:
  path=w/f'{case}_500000.in';expected=None
  for label in labels:
   with path.open('rb') as f:o=subprocess.run([str(bins[label])],stdin=f,capture_output=True,check=True).stdout
   if expected is None:expected=o
   assert o==expected
  samples={v:[] for v in labels}
  for iteration in range(35):
   order=labels[iteration%4:]+labels[:iteration%4]
   if iteration%2:order.reverse()
   for v in order:
    with path.open('rb') as f:
     t=time.perf_counter_ns();subprocess.run([str(bins[v])],stdin=f,stdout=subprocess.DEVNULL,check=True);elapsed=(time.perf_counter_ns()-t)/1e6
    if iteration>=4:samples[v].append(elapsed)
  med={v:statistics.median(x) for v,x in samples.items()};results.append({'compiler':compiler,'case':case,'n':500000,'median_ms':med,'samples_ms':samples})
  print(compiler,case,{v:round(med[v]/med['scalar'],3) for v in labels},flush=True)
(w/'io_path_benchmark.json').write_text(json.dumps({'cpu':9,'warmup':4,'measured':31,'results':results},indent=2)+'\n')
