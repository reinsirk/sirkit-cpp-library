from pathlib import Path
import hashlib,json,os,random,statistics,subprocess,sys,time
sys.path.insert(0,'/home/reinsirk/Atcoder_Env')
from Scripts import prepare_verify as p
w=Path('/tmp/sirkit_dev_pipeline_20261113');c=w/'claude_review';os.sched_setaffinity(0,{9})
entry=next(e for e in p.collect() if e['id']=='z_algorithm');entry['allow_custom_io']=True
versions=['before','codex','final','scalar']
final,_=p.render(entry)
(w/'z_final.cpp').write_bytes(final)
(w/'z_scalar.cpp').write_bytes(b'#define SIRKIT_DISABLE_SIMD\n'+final)
binaries={};commands=[]
for compiler in ('g++','clang++'):
 for v in versions:
  exe=w/f'z_{compiler}_{v}';cmd=[compiler,'-std=c++23','-O2','-Wall','-Wextra']
  if compiler=='clang++':cmd+=['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
  cmd += [str(w/f'z_{v}.cpp'),'-o',str(exe)]
  r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,r.stderr
  commands.append({'compiler':compiler,'stage':v,'command':cmd,'diagnostics':r.stderr});binaries[compiler,v]=exe
rng=random.Random(3821)
def naive(s):
 out=[]
 for i in range(len(s)):
  k=0
  while i+k<len(s) and s[k]==s[i+k]:k+=1
  out.append(k)
 return out
samples=['','a','ab','a'*63,'abacaba']+[''.join(rng.choice('abc') for _ in range(rng.randrange(1,200))) for _ in range(70)]
for (compiler,v),exe in binaries.items():
 for s in samples:
  r=subprocess.run([str(exe)],input=(' \r\n'+s+'\n').encode(),capture_output=True,check=True)
  assert list(map(int,r.stdout.split()))==naive(s),(compiler,v,s,r.stdout)
cases=[]
for n in (1000,500000):
 for kind in ('random','equal','periodic'):
  path=w/f'{kind}_{n}.in';cases.append((kind,n,path))
for kind,s in [('binary',''.join(rng.choice('ab') for _ in range(500000))),('fibonacci','')]:
 if kind=='fibonacci':
  a,b='a','ab'
  while len(b)<500000:a,b=b,b+a
  s=b[:500000]
 path=w/f'{kind}_500000.in';path.write_text(s+'\n');cases.append((kind,len(s),path))
results=[]
for compiler in ('g++','clang++'):
 for kind,n,path in cases:
  outputs=[]
  for v in versions:
   with path.open('rb') as f:outputs.append(subprocess.run([str(binaries[compiler,v])],stdin=f,capture_output=True,check=True).stdout)
  assert all(x==outputs[0] for x in outputs),(compiler,kind)
  times={v:[] for v in versions}
  for iteration in range(11):
   order=versions[iteration%4:]+versions[:iteration%4]
   if iteration%2:order=list(reversed(order))
   for v in order:
    with path.open('rb') as f:
     t=time.perf_counter_ns();subprocess.run([str(binaries[compiler,v])],stdin=f,stdout=subprocess.DEVNULL,check=True);elapsed=(time.perf_counter_ns()-t)/1e6
    if iteration>=2:times[v].append(elapsed)
  med={v:statistics.median(t) for v,t in times.items()}
  results.append({'compiler':compiler,'case':kind,'n':n,'milliseconds':times,'median_ms':med,'over_codex':{v:med[v]/med['codex'] for v in versions},'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(outputs[0]).hexdigest()})
  print(compiler,kind,n,{v:round(med[v]/med['codex'],3) for v in versions},flush=True)
report={'format':1,'scope':'whole_program_and_scalar_fallback_comparison','cpu':9,'warmup_pairs':2,'measured_pairs':9,'correctness':'passed','small_reference_cases':len(samples),'results':results,'commands':commands,'sources':{v:hashlib.sha256((w/f'z_{v}.cpp').read_bytes()).hexdigest() for v in versions}}
(w/'z_final_benchmark.json').write_text(json.dumps(report,indent=2)+'\n')
