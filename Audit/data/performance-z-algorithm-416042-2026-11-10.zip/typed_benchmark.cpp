// SPDX-License-Identifier: CC0-1.0
#include Z_HEADER
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <random>
#include <string>
#include <vector>
int main(int argc,char** argv) {
    if(argc!=4)return 1;
    const int operation=std::atoi(argv[1]),n=std::atoi(argv[2]),shape=std::atoi(argv[3]);
    std::mt19937_64 rng(416042);
    std::vector<std::int64_t> a(n);std::vector<bool> bits(n);std::string p(n,'a'),t(2*n,'a');
    for(int i=0;i<2*n;++i){int value=shape==0?0:shape==1?i%3:static_cast<int>(rng()%2);t[i]=static_cast<char>('a'+value);if(i<n){a[i]=value;bits[i]=value!=0;p[i]=t[i];}}
    const int repetitions=std::max(2,2000000/std::max(1,n));std::uint64_t checksum=0;
    const auto begin=std::chrono::steady_clock::now();
    for(int r=0;r<repetitions;++r){
        std::vector<int> z;
        if(operation==0)z=z_algorithm(a);
        else if(operation==1)z=z_algorithm(bits);
        else if(operation==2)z=PrefixMatches(p,t);
        else z=ZMatches(p,t);
        checksum+=z.size();if(!z.empty())checksum+=static_cast<std::uint64_t>(z.front()+z.back()+z[z.size()/2]);
    }
    const auto elapsed=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-begin).count();
    std::printf("%jd %ju\n",static_cast<std::intmax_t>(elapsed),static_cast<std::uintmax_t>(checksum));
}
