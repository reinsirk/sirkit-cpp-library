# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
R=Path('/home/reinsirk/Atcoder_Env')
D=Path('/tmp/sirkit_z_416042')
s=(R/'String/Z_Algorithm.cpp').read_text()
s=s.replace('#include <algorithm>','#include <algorithm>\n#include <bit>\n#include <climits>\n#include <cstdint>\n#include <cstring>')
condition='!defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__)) && CHAR_BIT == 8'
s=s.replace('#include <vector>', '#include <vector>\n\n#if '+condition+'\n#include <immintrin.h>\n#endif')
standard=r'''inline std::vector<int> z_algorithm_bytes_word(const char* data, int n) {
    std::vector<int> z(static_cast<std::size_t>(n));
    if (n == 0) return z;
    z[0] = n;
    int left = 0, right = 0;
    for (int i = 1; i < n; ++i) {
        int length = i < right ? std::min(right - i, z[i - left]) : 0;
        const int limit = n - i;
        if (length < limit && data[length] == data[i + length]) {
            ++length;
#if defined(UINT64_MAX) && CHAR_BIT == 8
            if constexpr (std::endian::native == std::endian::little || std::endian::native == std::endian::big) {
                while (limit - length >= 8) {
                    std::uint64_t a, b;
                    std::memcpy(&a, data + length, sizeof(a));
                    std::memcpy(&b, data + i + length, sizeof(b));
                    const auto difference = a ^ b;
                    if (difference != 0) {
                        if constexpr (std::endian::native == std::endian::little)
                            length += static_cast<int>(std::countr_zero(difference) / 8);
                        else length += static_cast<int>(std::countl_zero(difference) / 8);
                        break;
                    }
                    length += 8;
                }
            }
#endif
            while (length < limit && data[length] == data[i + length]) ++length;
        }
        z[i] = length;
        if (i + length > right) { left = i; right = i + length; }
    }
    return z;
}
'''
avx=r'''[[gnu::target("avx2")]] inline std::vector<int> z_algorithm_bytes_avx2(const char* data, int n) {
    std::vector<int> z(static_cast<std::size_t>(n));
    if (n == 0) return z;
    z[0] = n;
    int left = 0, right = 0;
    for (int i = 1; i < n; ++i) {
        int length = i < right ? std::min(right - i, z[i - left]) : 0;
        const int limit = n - i;
        // 通常のランダム列では、最初の1byteが異なる場合をここで終える。
        if (length < limit && data[length] == data[i + length]) {
            ++length;
            while (limit - length >= 32) {
                __m256i a, b;
                std::memcpy(&a, data + length, 32);
                std::memcpy(&b, data + i + length, 32);
                const auto difference = ~static_cast<std::uint32_t>(
                    _mm256_movemask_epi8(_mm256_cmpeq_epi8(a, b)));
                if (difference != 0) {
                    length += static_cast<int>(std::countr_zero(difference));
                    break;
                }
                length += 32;
            }
            while (length < limit && data[length] == data[i + length]) ++length;
        }
        z[i] = length;
        if (i + length > right) { left = i; right = i + length; }
    }
    return z;
}
inline bool z_algorithm_byte_avx2_available() {
    static const bool supported = __builtin_cpu_supports("avx2");
    return supported;
}
'''
helpers='''#ifndef SIRKIT_Z_BYTE_ALGORITHM_DEFINED
#define SIRKIT_Z_BYTE_ALGORITHM_DEFINED
namespace reinsirk::detail {
'''+standard+'\n#if '+condition+'\n'+avx+'#endif\n}\n#endif\n\n'
marker='#ifndef SIRKIT_Z_ALGORITHM_DEFINED\n'
assert marker in s
s=s.replace(marker,helpers+marker,1)
a='''inline std::vector<int> z_algorithm(const std::string& s) {
    return reinsirk::detail::z_algorithm_impl(s);
}'''
b='''inline std::vector<int> z_algorithm(const std::string& s) {
    if (s.size() < 4096) return reinsirk::detail::z_algorithm_impl(s);
    if (s.size() >= static_cast<std::size_t>(std::numeric_limits<int>::max()))
        throw std::length_error("z_algorithm: sequence too long");
    const int n = static_cast<int>(s.size());
#if '''+condition+'''
    if (reinsirk::detail::z_algorithm_byte_avx2_available())
        return reinsirk::detail::z_algorithm_bytes_avx2(s.data(), n);
#endif
    return reinsirk::detail::z_algorithm_bytes_word(s.data(), n);
}'''
assert a in s
s=s.replace(a,b)
(D/'bytes.hpp').write_text(s)
print(D/'bytes.hpp')
