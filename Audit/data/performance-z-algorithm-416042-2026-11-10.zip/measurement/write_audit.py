# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,datetime,zipfile,subprocess
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_z_416042')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(name):return json.loads((D/name).read_text())
whole=load('final_summary.json');typed=load('typed_summary.json');fixtures=load('fixtures.json')
key=['official_max_random_00','official_max_random_01','official_all_same_01','official_fib_str_00','official_binary_carry_00']
selected=[{**r,'reduction_percent':100*(1-r['ratios']['run_fast_tail'])}for r in whole if r['case'] in key]
core='String/Z_Algorithm.cpp';driver='Verify/current/drivers/z_algorithm_main.cpp';io='Verify/current/common/fast_io.hpp';submitted='Verify/current/submissions/z_algorithm.cpp'
for path in [driver,io]:assert (R/path).read_bytes()==(D/'before'/path).read_bytes()
audit={
 'date':'2026-11-10','library':core,'status':'accepted_local_optimization_requires_online_resubmission',
 'online':{'url':'https://judge.yosupo.jp/submission/416042','status':'AC','time_ms':22,'evidence':'Audit/online-z-algorithm-416042-2026-11-10.json','scope':'変更前コードのAC。公開APIの本文を取得し、空行/改行/行末空白/Submission注記のみ除いて本体・main・IOの一致を確認。変更後のオンライン判定ではない。'},
 'change':['一致範囲内で不一致まで確定するZ値を連続してコピーし、一致長を次位置へ持ち越す。','先頭要素の不一致は零初期化済みの出力を利用し、余計な書込みを省く。','末尾まで一致した後は比較せず既知のZ値から残りを埋める。全要素同値の場合も同じ一般則から埋める。','汎用==の結果はcontextual boolと同じ明示bool変換を使用。API・チェック・所有権・O(n)時間/O(n)結果領域は維持。'],
 'correctness_invariants':['outer iは未処理位置。コピーは旧i+1..旧i+advance-1までなので次iは未代入で零初期化が有効。','advance==iなら直前に代入したz[i]=lengthを読むため、length<length-iは偽。未計算位置を参照しない。','コピー後の一致長をmax(0,length-advance)として保持する。展開成功は右端を進め、コピーはiを進めるため合計O(n)。','末尾到達後のmin(n-i,z[i-left])は確定済みの位置だけを参照。left=1なら同値関係の推移性から残りはn-i。','n<INT_MAXの上限を検査省略時も維持し、i+length等はn以内。空列・vector<bool>・等値比較のみの型に対応。'],
 'source_hashes':{'before':sha(D/'before'/core),'after':sha(R/core),'submission_after':sha(R/submitted),'driver':sha(R/driver),'io':sha(R/io)},
 'frozen_verify':{'main_unchanged':True,'io_unchanged':True,'query_batching_or_input_specific_switch':False,'skip_runtime_checks':True,'submission_bytes':(R/submitted).stat().st_size},
 'measurement':{'cpu':'Intel Core i9-14900K, CPU 12/core 6 P-Core (sibling CPU 13), max 6 GHz','affinity':'taskset -c 12','E_core_measurement':False,'compiler':{'gcc':'/usr/bin/g++ 15.2.0','clang':'/usr/bin/clang++ 21.1.8, --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'},'flags':['-std=c++23','-O2'],'march_native':False,'extra_optimize_pragmas':False,'ASLR':'各試験子プロセスのみsetarch x86_64 -R。システム設定は変更しない。','timing_lock':'/tmp/sirkit_performance_cpu12.lock','order':'決定的にシャッフル。baseとcontrolは同一実行ファイルで、同じactiveパスへ置き換えて実行。','whole_verify':'入力から出力・破棄までの子プロセスuser+system時間。before/control中央値をまとめた値を分母にafter中央値を比較。','whole_repetitions':9,'whole_fixture_count':len(fixtures),'whole_runs':len(load('final_raw.json')),'all_outputs_equal':True,'official_generator_revision':load('official_generation_plan.json')['revision'],'official_note':'固定コミットの公式生成器による再生成入力であり、オンライン現行ケースのバイト列一致は主張しない。','custom_note':'独自の小規模/500000要素/制約外1000000要素を含む。小入力は起動時間の影響を受ける。','selected_results':selected,'all_results_file':'final_summary.json','text_equivalence':load('final_builds.json')},
 'other_operations':{'operations':{'0':'z_algorithm(vector<int64_t>)','1':'z_algorithm(vector<bool>)','2':'PrefixMatches(string,string)','3':'ZMatches(string,string)'},'n':[32,4096,500000],'shapes':{'0':'all_same','1':'periodic3','2':'binary_random'},'repetitions':7,'runs':len(load('typed_raw.json')),'scope':'入力生成を除いた構築/結果配列確保/破棄を含む呼出しループのsteady_clock時間。Verify main全体とは別測定。','result':'全72条件でafter中央値がbefore/control pooled中央値より小さい。一般のすべての入力に対する非退行を保証する意味ではない。','max_ratio':max(r['ratio']for r in typed),'all_checksums_equal':True},
 'tradeoffs':{'small_inputs':'全体測定の小ケースでは起動時間の揺れを含む増減がある。全小ケースが速いとは主張しない。','large_inputs':'GCC official_random_06 +0.7%、custom_last_different +0.2%等の小幅増加がある。最大ランダム約3%、fib/carry約14%の改善を優先。Clangの最大ランダム約3〜5%、fib/carry約15〜17%。','online':'22msからの短縮幅は未提出のため未確認。'},
 'rejected_candidates':[{'candidates':['skip','tail','zero','run','run_tail','run_fast'],'reason':'run_fast_tailを全体の速度と簡潔さで採用。他の候補は補助比較のみ。'},{'candidates':['bytes','bytes_word','run_bytes','run_bytes_fast','run_bytes_fast_word'],'reason':'AVX2/memcpy単位比較も測定したが、標準版より遅い条件やGCC first_different約6%・Clang binary等の退行が残るため不採用。追加ISA/CPU判定/専用マクロは現行Z本体に導入しない。'}],
 'verification':{'tests':load('tests.json'),'sanitizers':'ASan/UBSan、GCC/Clang×checked/SKIP。確保失敗試験は専用global operator newフックを使いサニタイザなし。','independent_reference':'短列の直接全比較、接尾辞配列とLCPからの独立Z参照、検索はpattern+範囲外sentinel+textの独立参照。','allocation_result':'各コンパイラ2340 checks / 70 injected allocation failures / live_delta=0。','api_result':'各設定10257 checks。文字列/vectorのACL形式・literal・explicit型引数・string_view/span/array・比較結果proxy・巨大長・重複貼り付け。','large_reference_result':'各設定115 cases / 384 checks。全256バイト/NUL・周期・mutation・bool/整数境界・長い検索。','variants':{'counts':{'LOCAL_SAMPLE_PASS':10},'run_file':'profiles/runs/'+sorted((D/'profiles/runs').glob('*.json'))[-1].name,'scope':'通常/GCC/Clang/速度優先GCC/速度優先Clangの提出用コードと使用例。'}},
 'documentation':'公開APIは不変のためDocument/READMEに測定記録を追加しない。内部不変条件のみ本体に短く注記。',
 'license':'採用実装・テスト・計測補助は独自のCC0-1.0。公式外部生成器(Apache-2.0)のソース本文をライブラリ/証跡ZIPへ収録しない。固定URL/ハッシュと再生成手順のみ保存。',
 'evidence_zip':'Audit/data/performance-z-algorithm-416042-2026-11-10.zip','required_resubmission':[submitted]
}
# Current online record remains historical, with current hashes attached separately.
p=R/'Verify/current/judgements.json';a=json.loads(p.read_text());entry=next(x for x in a['entries']if x['id']=='z_algorithm');entry['current_submission_sha256']=sha(R/submitted);entry['performance_audit']='Audit/performance-z-algorithm-416042-2026-11-10.json';p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
(R/'Audit/performance-z-algorithm-416042-2026-11-10.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
files=[]
for p in D.iterdir():
 if p.is_file() and p.suffix in ['.json','.py','.hpp','.log'] and p.name not in ['z_fast_reference_dependencies.json']:
  files.append((p,'measurement/'+p.name))
for name in ['typed_benchmark.cpp','416042.cpp','before/String/Z_Algorithm.cpp','before/Verify/current/submissions/z_algorithm.cpp','before/Verify/current/drivers/z_algorithm_main.cpp','before/Verify/current/common/fast_io.hpp']:
 files.append((D/name,name))
for name in [core,submitted,driver,io,'Verify/current/tests/z_algorithm_fast_test.cpp','Verify/current/tests/z_algorithm_acl_api_test.cpp','Verify/current/tests/string_algorithms_reference_test.cpp','Verify/current/tests/string_math_allocation_test.cpp','Audit/performance-z-algorithm-416042-2026-11-10.json','Audit/online-z-algorithm-416042-2026-11-10.json']:
 files.append((R/name,'after/'+name))
for p in (D/'profiles').rglob('*.json'):files.append((p,'profiles/'+str(p.relative_to(D/'profiles'))))
path=R/audit['evidence_zip'];path.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p,name in sorted(files,key=lambda v:v[1]):z.writestr(zipfile.ZipInfo(name,(2026,11,10,0,0,0)),p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
print('audit/evidence',path.stat().st_size,'bytes',len(files),'entries')
