# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
D=Path('/tmp/sirkit_z_416042')
s=(D/'bytes.hpp').read_text()
run=(D/'run_tail.hpp').read_text()
def function_span(text, name):
    a=text.index(name)
    b=text.index('{',a)
    depth=0
    for i in range(b,len(text)):
        if text[i]=='{':depth+=1
        elif text[i]=='}':
            depth-=1
            if depth==0:return a,i+1
    raise ValueError(name)
a,b=function_span(s,'std::vector<int> z_algorithm_impl(const Sequence& s)')
c,d=function_span(run,'std::vector<int> z_algorithm_impl(const Sequence& s)')
s=s[:a]+run[c:d]+s[b:]
old_head='''    int left = 0, right = 0;
    for (int i = 1; i < n; ++i) {
        int length = i < right ? std::min(right - i, z[i - left]) : 0;
        const int limit = n - i;'''
new_head='''    int i = 1, length = 0;
    while (i < n) {
        const int limit = n - i;'''
old_tail='''        z[i] = length;
        if (i + length > right) { left = i; right = i + length; }
'''
new_tail='''        z[i] = length;
        if (length == limit) {
            if (i == 1) {
                for (++i; i < n; ++i) z[i] = n - i;
            } else {
                const int left = i;
                for (++i; i < n; ++i) z[i] = std::min(n - i, z[i - left]);
            }
            break;
        }
        int advance = 1;
        // 拡張不要と確定した位置はZ配列からまとめて埋める。
        while (advance < length && z[advance] < length - advance) {
            z[i + advance] = z[advance];
            ++advance;
        }
        i += advance;
        length = std::max(0, length - advance);
'''
for name in ['z_algorithm_bytes_word','z_algorithm_bytes_avx2']:
    a,b=function_span(s,'std::vector<int> '+name+'(const char* data, int n)')
    f=s[a:b]
    assert old_head in f and old_tail in f,name
    f=f.replace(old_head,new_head).replace(old_tail,new_tail)
    s=s[:a]+f+s[b:]
(D/'run_bytes.hpp').write_text(s)
print(D/'run_bytes.hpp')
