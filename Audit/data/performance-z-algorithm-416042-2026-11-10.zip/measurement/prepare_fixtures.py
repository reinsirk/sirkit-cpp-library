# SPDX-License-Identifier: CC0-1.0
"""Z配列の比較入力を作成する。コンパイル・性能測定・外部コードの実行は行わない。"""
from pathlib import Path
import argparse
import hashlib
import json
import random
import tomllib

D = Path(__file__).resolve().parent
I = D / 'fixtures' / 'inputs'
O = D / 'fixtures' / 'expected'
I.mkdir(parents=True, exist_ok=True)
O.mkdir(parents=True, exist_ok=True)
REVISION = json.loads((D / 'official_revision.json').read_text())['revision']
ROOT = f'https://raw.githubusercontent.com/yosupo06/library-checker-problems/{REVISION}/'
INFO = tomllib.loads((D / 'info.toml').read_text())
N_MAX = INFO['params']['N_MAX']
SEED = 20261110416042
ROWS = []

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def naive_z(data):
    result = []
    for i in range(len(data)):
        length = 0
        while length < len(data) - i and data[length] == data[i + length]:
            length += 1
        result.append(length)
    return result

def register(name, payload, source, *, seed=None, formula=None, formula_name=None):
    assert payload and len(payload.split()) == 1
    assert all(32 < c < 127 for c in payload)
    path = I / (name + '.in')
    path.write_bytes(payload + b'\n')
    n = len(payload)
    row = dict(name=name, path=str(path), n=n, bytes=path.stat().st_size,
               sha256=sha(path), seed=seed, source=source,
               within_problem_limit=n <= N_MAX)
    if n <= 256:
        expected = naive_z(payload)
        oracle = 'independent_naive'
    elif formula is not None:
        expected = [formula(i, n) for i in range(n)]
        oracle = 'known_formula'
    else:
        expected = None
        oracle = 'before_after_only'
    row.update(oracle=oracle, expected_path=None, expected_sha256=None)
    if expected is not None:
        out = O / (name + '.out')
        out.write_text(' '.join(map(str, expected)) + '\n')
        row.update(expected_path=str(out), expected_sha256=sha(out))
    if formula_name:
        row['formula'] = formula_name
    ROWS.append(row)

def fibonacci(n):
    a, b = b'a', b'ab'
    while len(b) < n:
        a, b = b, a + b
    return b[:n]

def random_word(n, alphabet, seed):
    rng = random.Random(seed)
    return bytes(rng.choices(alphabet, k=n))

def customs():
    for n in [1, 32, 256]:
        register(f'custom_{n}_all_same', b'a' * n, 'self-generated',
                 formula=lambda i, n: n - i, formula_name='z[i]=n-i')
        register(f'custom_{n}_binary', random_word(n, b'ab', SEED+n),
                 'self-generated', seed=SEED+n)
        register(f'custom_{n}_periodic3', (b'abc' * ((n+2)//3))[:n],
                 'self-generated', formula=lambda i, n: n-i if i%3 == 0 else 0,
                 formula_name='z[i]=(i%3==0 ? n-i : 0)')
    for n in [4096, N_MAX]:
        register(f'custom_{n}_all_same', b'a' * n, 'self-generated',
                 formula=lambda i,n:n-i, formula_name='z[i]=n-i')
        register(f'custom_{n}_random26', random_word(n,b'abcdefghijklmnopqrstuvwxyz',SEED+n+1),
                 'self-generated',seed=SEED+n+1)
        register(f'custom_{n}_binary', random_word(n,b'ab',SEED+n+2),
                 'self-generated',seed=SEED+n+2)
        register(f'custom_{n}_periodic3',(b'abc'*((n+2)//3))[:n],
                 'self-generated',formula=lambda i,n:n-i if i%3==0 else 0,
                 formula_name='z[i]=(i%3==0 ? n-i : 0)')
        register(f'custom_{n}_last_different', b'a'*(n-1)+b'b', 'self-generated',
                 formula=lambda i,n:n if i==0 else max(0,n-i-1),
                 formula_name='z[0]=n; z[i>0]=max(0,n-i-1)')
        mid=n//2
        register(f'custom_{n}_middle_different',b'a'*mid+b'b'+b'a'*(n-mid-1),
                 'self-generated',formula=lambda i,n:n if i==0 else (n//2-i if i<n//2 else 0 if i==n//2 else min(n//2,n-i)),
                 formula_name='single b at n/2; direct run-length formula')
    n=N_MAX
    register(f'custom_{n}_first_different',b'b'+b'a'*(n-1),'self-generated',
             formula=lambda i,n:n if i==0 else 0,formula_name='z[0]=n; z[i>0]=0')
    register(f'custom_{n}_prefix_then_random',b'a'*(n//2)+random_word(n-n//2,b'abcdefghijklmnopqrstuvwxyz',SEED+11),
             'self-generated',seed=SEED+11)
    register(f'custom_{n}_fibonacci',fibonacci(n),'self-generated')
    start=172039
    carry=bytes(97+((i & -i).bit_length()-1) for i in range(start,start+n))
    register(f'custom_{n}_binary_carry',carry,'self-generated',seed=start)
    for kind, alphabet in [('all_same',b'a'),('random26',b'abcdefghijklmnopqrstuvwxyz'),('binary',b'ab')]:
        n=1000000
        payload=b'a'*n if kind=='all_same' else random_word(n,alphabet,SEED+n+len(alphabet))
        register(f'custom_{n}_{kind}',payload,'self-generated beyond N_MAX',
                 seed=None if kind=='all_same' else SEED+n+len(alphabet),
                 formula=(lambda i,n:n-i) if kind=='all_same' else None,
                 formula_name='z[i]=n-i' if kind=='all_same' else None)

def static_official():
    for test in INFO['tests']:
        if not test['name'].endswith('.in'):
            continue
        stem=test['name'][:-3]
        for i in range(test['number']):
            relative=f'string/zalgorithm/gen/{stem}_{i:02d}.in'
            register(f'official_{stem}_{i:02d}',(D/'official'/relative).read_bytes().strip(),
                     ROOT+relative)

def official_plan():
    root=D/'official/string/zalgorithm'
    (root/'params.h').write_text(''.join(f'constexpr int {k} = {v};\n' for k,v in INFO['params'].items()))
    build=D/'official_build'
    build.mkdir(exist_ok=True)
    compile_commands=[]
    runs=[]
    for test in INFO['tests']:
        if not test['name'].endswith('.cpp'):
            continue
        stem=Path(test['name']).stem
        src=root/'gen'/test['name']
        exe=build/stem
        compile_commands.append(dict(name=stem,command=['taskset','-c','4','/usr/bin/g++','-std=c++23','-O2','-I',str(D/'official/common'),str(src),'-o',str(exe)],source_url=ROOT+f'string/zalgorithm/gen/{test["name"]}',source_sha256=sha(src)))
        for seed in range(test['number']):
            runs.append(dict(name=f'official_{stem}_{seed:02d}',command=[str(exe),str(seed)],output=str(I/f'official_{stem}_{seed:02d}.in'),seed=seed,source_url=ROOT+f'string/zalgorithm/gen/{test["name"]}'))
    (D/'official_generation_plan.json').write_text(json.dumps(dict(revision=REVISION,compile=compile_commands,runs=runs,registration_command=['python3',str(Path(__file__).resolve()),'--register-official']),indent=2)+'\n')
    source_files=[p for p in(D/'official').rglob('*') if p.is_file() and p.name!='params.h']
    manifest=dict(repository='https://github.com/yosupo06/library-checker-problems',revision=REVISION,
                  license='Apache-2.0',usage='external code retained only in /tmp; not library implementation or distributable evidence',
                  constraints=dict(N_MAX=N_MAX),files=[dict(path=str(p.relative_to(D/'official')),url=ROOT+str(p.relative_to(D/'official')),sha256=sha(p))for p in sorted(source_files)])
    (D/'official_sources.json').write_text(json.dumps(manifest,indent=2)+'\n')

def generated_official():
    plan=json.loads((D/'official_generation_plan.json').read_text())
    for run in plan['runs']:
        path=Path(run['output'])
        if path.exists():
            register(run['name'],path.read_bytes().strip(),run['source_url'],seed=run['seed'])

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--register-official',action='store_true')
    args=parser.parse_args()
    customs();static_official();official_plan()
    if args.register_official:
        generated_official()
    (D/'fixtures.json').write_text(json.dumps(ROWS,indent=2)+'\n')
    print(f'fixtures={len(ROWS)} bytes={sum(r["bytes"]for r in ROWS)} independent={sum(r["oracle"]=="independent_naive"for r in ROWS)} known={sum(r["oracle"]=="known_formula"for r in ROWS)} before_after={sum(r["oracle"]=="before_after_only"for r in ROWS)}')
    print(f'official commit={REVISION} N_MAX={N_MAX} compile_commands=5 runs=24 (not executed)')

if __name__=='__main__':main()
