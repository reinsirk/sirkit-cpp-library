// SPDX-License-Identifier: CC0-1.0
// 参考（Z配列の用途とVerify先。実装は独自構成）:
// https://judge.yosupo.jp/problem/zalgorithm
// 参考（ACLのAPI）: https://atcoder.github.io/ac-library/production/document_ja/string.html
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/z_algorithm.md
//
// API一覧
// z_algorithm(const std::string&)/z_algorithm<T>(const std::vector<T>&): ACL形式のZ配列を返す。
// 追加のz_algorithm(sequence)は任意の添字アクセス可能な列に対応。空なら{}、非空ならz[0]=n。
// PrefixMatches(pattern,text): textの各開始位置とpatternの共通接頭辞長を返す。
// ZMatches(pattern,text): 完全一致する開始位置を昇順に返す。空patternは0..text.size()。
// size()/添字アクセスと同値関係の==が使える列が前提。比較O(1)ならZはO(n)、後2者はO(n+m)時間。
// 各列長はINT_MAX未満。Z/PrefixMatchesの領域は返却値とpattern長、ZMatchesはこれに一致数。

#include <algorithm>
#include <bit>
#include <climits>
#include <cstdint>
#include <cstring>
#include <cstddef>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

#if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__)) && CHAR_BIT == 8
#include <immintrin.h>
#endif

#ifndef SIRKIT_Z_ALGORITHM_IMPL_DEFINED
#define SIRKIT_Z_ALGORITHM_IMPL_DEFINED
namespace reinsirk::detail {
template <class Sequence>
std::vector<int> z_algorithm_impl(const Sequence& s) {
    if (s.size() >= static_cast<std::size_t>(std::numeric_limits<int>::max()))
        throw std::length_error("z_algorithm: sequence too long");
    const int n = static_cast<int>(s.size());
    std::vector<int> z(s.size());
    if (n == 0) return z;
    z[0] = n;
    int i = 1, length = 0;
    while (i < n) {
        while (length < n - i && s[length] == s[i + length]) ++length;
        z[i] = length;
        if (length == n - i) {
            if (i == 1) {
                for (++i; i < n; ++i) z[i] = n - i;
            } else {
                const int left = i;
                for (++i; i < n; ++i) z[i] = std::min(n - i, z[i - left]);
            }
            break;
        }
        int advance = 1;
        while (advance < length && z[advance] < length - advance) {
            z[i + advance] = z[advance];
            ++advance;
        }
        i += advance;
        length = std::max(0, length - advance);
    }
    return z;
}
}
#endif

#ifndef SIRKIT_Z_BYTE_ALGORITHM_DEFINED
#define SIRKIT_Z_BYTE_ALGORITHM_DEFINED
namespace reinsirk::detail {
inline std::vector<int> z_algorithm_bytes_word(const char* data, int n) {
    std::vector<int> z(static_cast<std::size_t>(n));
    if (n == 0) return z;
    z[0] = n;
    int i = 1, length = 0;
    while (i < n) {
        const int limit = n - i;
        if (length < limit && data[length] == data[i + length]) {
            ++length;
#if defined(UINT64_MAX) && CHAR_BIT == 8
            if constexpr (std::endian::native == std::endian::little || std::endian::native == std::endian::big) {
                while (limit - length >= 8) {
                    std::uint64_t a, b;
                    std::memcpy(&a, data + length, sizeof(a));
                    std::memcpy(&b, data + i + length, sizeof(b));
                    const auto difference = a ^ b;
                    if (difference != 0) {
                        if constexpr (std::endian::native == std::endian::little)
                            length += static_cast<int>(std::countr_zero(difference) / 8);
                        else length += static_cast<int>(std::countl_zero(difference) / 8);
                        break;
                    }
                    length += 8;
                }
            }
#endif
            while (length < limit && data[length] == data[i + length]) ++length;
        }
        z[i] = length;
        if (length == limit) {
            if (i == 1) {
                for (++i; i < n; ++i) z[i] = n - i;
            } else {
                const int left = i;
                for (++i; i < n; ++i) z[i] = std::min(n - i, z[i - left]);
            }
            break;
        }
        int advance = 1;
        // 拡張不要と確定した位置はZ配列からまとめて埋める。
        while (advance < length && z[advance] < length - advance) {
            z[i + advance] = z[advance];
            ++advance;
        }
        i += advance;
        length = std::max(0, length - advance);
    }
    return z;
}

#if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__)) && CHAR_BIT == 8
[[gnu::target("avx2")]] inline std::vector<int> z_algorithm_bytes_avx2(const char* data, int n) {
    std::vector<int> z(static_cast<std::size_t>(n));
    if (n == 0) return z;
    z[0] = n;
    int i = 1, length = 0;
    while (i < n) {
        const int limit = n - i;
        // 通常のランダム列では、最初の1byteが異なる場合をここで終える。
        if (length < limit && data[length] == data[i + length]) {
            ++length;
            while (limit - length >= 32) {
                __m256i a, b;
                std::memcpy(&a, data + length, 32);
                std::memcpy(&b, data + i + length, 32);
                const auto difference = ~static_cast<std::uint32_t>(
                    _mm256_movemask_epi8(_mm256_cmpeq_epi8(a, b)));
                if (difference != 0) {
                    length += static_cast<int>(std::countr_zero(difference));
                    break;
                }
                length += 32;
            }
            while (length < limit && data[length] == data[i + length]) ++length;
        }
        z[i] = length;
        if (length == limit) {
            if (i == 1) {
                for (++i; i < n; ++i) z[i] = n - i;
            } else {
                const int left = i;
                for (++i; i < n; ++i) z[i] = std::min(n - i, z[i - left]);
            }
            break;
        }
        int advance = 1;
        // 拡張不要と確定した位置はZ配列からまとめて埋める。
        while (advance < length && z[advance] < length - advance) {
            z[i + advance] = z[advance];
            ++advance;
        }
        i += advance;
        length = std::max(0, length - advance);
    }
    return z;
}
inline bool z_algorithm_byte_avx2_available() {
    static const bool supported = __builtin_cpu_supports("avx2");
    return supported;
}
#endif
}
#endif

#ifndef SIRKIT_Z_ALGORITHM_DEFINED
#define SIRKIT_Z_ALGORITHM_DEFINED
template<class T>
std::vector<int> z_algorithm(const std::vector<T>& s) {
    return reinsirk::detail::z_algorithm_impl(s);
}
inline std::vector<int> z_algorithm(const std::string& s) {
    if (s.size() < 4096) return reinsirk::detail::z_algorithm_impl(s);
    if (s.size() >= static_cast<std::size_t>(std::numeric_limits<int>::max()))
        throw std::length_error("z_algorithm: sequence too long");
    const int n = static_cast<int>(s.size());
#if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__)) && CHAR_BIT == 8
    if (reinsirk::detail::z_algorithm_byte_avx2_available())
        return reinsirk::detail::z_algorithm_bytes_avx2(s.data(), n);
#endif
    return reinsirk::detail::z_algorithm_bytes_word(s.data(), n);
}
template<class Sequence>
    requires requires(const Sequence& s) { s.size(); s[0] == s[0]; }
std::vector<int> z_algorithm(const Sequence& s) {
    return reinsirk::detail::z_algorithm_impl(s);
}
#endif

#ifndef SIRKIT_Z_MATCHES_DEFINED
#define SIRKIT_Z_MATCHES_DEFINED
template <class Pattern, class Text>
std::vector<int> PrefixMatches(const Pattern& pattern, const Text& text) {
    if (text.size() >= static_cast<std::size_t>(std::numeric_limits<int>::max()))
        throw std::length_error("PrefixMatches: text too long");
    const auto z = z_algorithm(pattern);
    const int n = static_cast<int>(text.size()), m = static_cast<int>(pattern.size());
    std::vector<int> matches(text.size());
    int left = 0, right = 0;
    for (int i = 0; i < n; ++i) {
        int length = i < right ? std::min(right - i, z[i - left]) : 0;
        while (length < m && length < n - i && pattern[length] == text[i + length]) ++length;
        matches[i] = length;
        if (i + length > right) { left = i; right = i + length; }
    }
    return matches;
}

template <class Pattern, class Text>
std::vector<int> ZMatches(const Pattern& pattern, const Text& text) {
    auto lengths = PrefixMatches(pattern, text);
    std::vector<int> positions;
    const int m = static_cast<int>(pattern.size());
    for (int i = 0; i < static_cast<int>(lengths.size()); ++i)
        if (lengths[i] == m) positions.push_back(i);
    if (m == 0) positions.push_back(static_cast<int>(text.size()));
    return positions;
}
#endif
