# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
D=Path('/tmp/sirkit_manacher_416371');base=(D/'before/String/Manacher.cpp').read_text();(D/'base.hpp').write_text(base)
a=base.index('    for (Center center = start; center < centers; ++center) {');b=base.index('    return result;',a)
body=base[a:b];body=body[body.index('{')+1:body.rindex('}')]
body=body.replace('        int length = (center & 1) == 0 ? 1 : 0;','        int length = Gap ? 0 : 1;').replace('result[center] = reflected; continue;','result[center] = reflected; return;')
paired='''    const auto process = [&]<bool Gap>(Center center, int half) {
'''+body+'''    };
    for (int half = static_cast<int>(start / 2); half < n - 1; ++half) {
        const auto center = Center{2} * static_cast<Center>(half);
        process.template operator()<false>(center, half);
        process.template operator()<true>(center + 1, half);
    }
    result.back() = 1;
'''
paired_half=paired.replace('''        int l = static_cast<int>((center + 1 - static_cast<Center>(length)) / 2) - 1;
        int r = static_cast<int>((center + static_cast<Center>(length) + 1) / 2);''','''        const int radius = length / 2;
        int l = half - radius - (Gap ? 0 : 1);
        int r = half + radius + 1;''')
for name,s in [('paired',paired),('paired_half',paired_half)]:
 (D/(name+'.hpp')).write_text(base[:a]+s+base[b:])
# Two explicit center bodies keep inlining decisions separate from the paired lambda.
expanded='''    for (int half = static_cast<int>(start / 2); half < n - 1; ++half) {
'''
for gap in [False,True]:
 cur=body.replace('int length = Gap ? 0 : 1;', 'int length = '+('0;'if gap else'1;'))
 cur=cur.replace('result[center] = reflected; return;', 'result[center] = reflected; break;')
 cur=cur.replace('''        int l = static_cast<int>((center + 1 - static_cast<Center>(length)) / 2) - 1;
        int r = static_cast<int>((center + static_cast<Center>(length) + 1) / 2);''','''        const int radius = length / 2;
        int l = half - radius - '''+('0;'if gap else'1;')+'''
        int r = half + radius + 1;''')
 expanded+='        do {\n            const auto center = Center{2} * static_cast<Center>(half)'+(' + 1'if gap else'')+';\n'+cur+'        } while (false);\n'
expanded+='    }\n    result.back() = 1;\n'
(D/'paired_expanded.hpp').write_text(base[:a]+expanded+base[b:])
