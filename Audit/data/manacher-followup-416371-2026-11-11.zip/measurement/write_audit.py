# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_manacher_416371');P=Path('/tmp/sirkit_manacher_416358')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['String/Manacher.cpp','Verify/current/drivers/manacher_main.cpp','Verify/current/common/fast_io.hpp']:assert (R/n).read_bytes()==(D/'before'/n).read_bytes()
assert sha(R/'String/Manacher.cpp')==load(R/'Audit/performance-manacher-416368-2026-11-11.json')['source_hashes']['after']
whole=load(D/'final_summary.json');typed=load(D/'typed_summary.json');fixtures=load(P/'agent_fixtures/fixtures.json');fm={r['name']:r for r in fixtures};labels=['paired','paired_half','paired_expanded']
audit={
 'date':'2026-11-11','library':'String/Manacher.cpp','decision':'retain_current_AC29ms_implementation','required_resubmission':[],
 'online':{'url':'https://judge.yosupo.jp/submission/416371','status':'AC','time_ms':29,'evidence':'Audit/online-manacher-416371-2026-11-11.json','scope':'本体/main/共通IOは空白等のみ除いて提出本文と一致。同値列4件は21〜22msへ短縮。遅いケースが提出ごとに移るため最大値だけで後退を断定しない。'},
 'unchanged':{'canonical':sha(R/'String/Manacher.cpp'),'main':sha(R/'Verify/current/drivers/manacher_main.cpp'),'IO':sha(R/'Verify/current/common/fast_io.hpp'),'library_main_IO_unchanged':True,'API_documentation_examples_unchanged':True},
 'candidates':[{'name':'paired','description':'文字上/文字間の中心を同じ反復で処理し、templated lambdaのboolで奇偶を定数化。最後の文字中心は常に1。','result':'条件ごとの増減があり不採用。'},{'name':'paired_half','description':'pairedで元の文字位置を渡し、l/rを半径の半分から計算。','result':'大規模int64/binary呼出しがGCC約3.5%増、bool/periodic3がClang約3.0%増などがあるため不採用。'},{'name':'paired_expanded','description':'2中心の本体を明示的に展開し、lambda/inliningの判断と分けて比較。','result':'大規模random全体で約1〜2%改善する条件もあるが、同値列等に増加、boolの単体呼出しにも増加が残る。重複する本体が長くなり、現行を置き換える安定した上積みとは判断しない。'}],
 'candidate_sha256':{l:sha(D/(l+'.hpp'))for l in labels},
 'measurement':{'cpu':'Intel Core i9-14900K、CPU12/core6 P-Core、sibling13、max6GHz','E_Core_measured':False,'compiler':{'gcc':'15.2.0','clang':'21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'},'flags':['-std=c++23','-O2'],'march_native':False,'extra_pragmas':False,'lock':'/tmp/sirkit_performance_cpu12.lock','order':'before/control/candidatesを決定的にshuffleし同じactiveパスで実行。controlはbeforeと同じ実行ファイル。','ASLR':'子プロセスだけsetarch x86_64 -R。システム設定変更なし。','whole':'固定main/IO全体のuser+system時間。after中央値/before-control pooled中央値。','fixtures':len(fixtures),'official_revision':'73876f1cbcf082d2b22722924b924d3d65a2f00e','fixture_scope':'前回と同じ公式固定生成器24入力と自作26入力。制約外1000000を含む。オンライン入力の同一性は主張しない。','whole_repetitions':9,'whole_runs':len(load(D/'final_raw.json')),'all_outputs_equal':True,'whole_regressions':{cc:{l:sorted([dict(case=r['case'],ratio=r['ratios'][l])for r in whole if r['compiler']==cc and fm[r['case']]['n']>=200000],key=lambda r:r['ratio'],reverse=True)[:5]for l in ['paired_half','paired_expanded']}for cc in ['gcc','clang']},'small_caveat':'小入力全体時間は起動時間で揺れる。単発最速値による採否ではない。'},
 'generic_API_measurement':{'operations':{'0':'PalindromicLengths(string)','1':'PalindromicLengths(vector<int64_t>)','2':'PalindromicLengths(vector<bool>)'},'sizes':[32,4096,500000],'shapes':{'0':'all_same','1':'periodic3','2':'binary_random'},'repetitions':7,'runs':len(load(D/'typed_raw.json')),'scope':'入力生成を除き返却領域の確保/計算/破棄を含む反復呼出しのsteady_clock時間。Verify全体とは区別。','all_checksums_equal':True,'large_results':[r for r in typed if r['n']==500000]},
 'verification':{'experimental_candidates':load(D/'quick_tests.json'),'candidate_note':'GCC/ASan/UBSanで短い全二値列/三値列7375ケースを独立naiveと照合し、両コンパイラでサンプルも確認。全体比較の出力も一致。候補は不採用で配布本体へ入れない。','canonical':'本体/driver/IOは無変更で、オンライン実提出ACと本文一致を確認。既存のGCC/Clang×checked/SKIP、独立長列131 cases/9234220 checks、確保失敗2343 checks/69 failures/live_delta0の検証済みソースhashと一致するため、その証跡を参照。無変更の既存試験を重複して走らせない。','prior_evidence':'Audit/performance-manacher-416368-2026-11-11.json'},
 'conclusion':'追加3案に通常版を置き換えるほど安定した改善はなく、AC29msの現在の本体を維持。最新の提出記録/URL/配布だけ同期する。最適化の不可能性を証明する意味ではない。',
 'license':'候補/測定補助は独自CC0-1.0。公式外部生成器の本文は保存せず、前回の固定URL/ハッシュ/再生成計画だけ参照。',
 'evidence_zip':'Audit/data/manacher-followup-416371-2026-11-11.zip'
}
p=R/'Audit/manacher-followup-416371-2026-11-11.json';p.write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n');files=[]
for f in D.iterdir():
 if f.is_file()and f.suffix in ['.json','.py','.hpp','.log']:files.append((f,'measurement/'+f.name))
for n in ['fixtures.json','official_sources.json','official_generation_plan.json','prepare.py']:files.append((P/'agent_fixtures'/n,'fixture_dependencies/'+n))
for n in ['quick_test.cpp','typed_benchmark.cpp']:files.append((P/n,'measurement/'+n))
for n in ['416371.cpp','before/String/Manacher.cpp','before/Verify/current/submissions/manacher.cpp','before/Verify/current/drivers/manacher_main.cpp','before/Verify/current/common/fast_io.hpp']:files.append((D/n,n))
for n in ['String/Manacher.cpp','Verify/current/submissions/manacher.cpp','Audit/online-manacher-416371-2026-11-11.json','Audit/manacher-followup-416371-2026-11-11.json']:files.append((R/n,'after/'+n))
with zipfile.ZipFile(R/audit['evidence_zip'],'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f,n in sorted(files,key=lambda v:v[1]):z.writestr(zipfile.ZipInfo(n,(2026,11,11,0,0,0)),f.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
print('audit/evidence',len(files),(R/audit['evidence_zip']).stat().st_size)
