# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,sys,subprocess,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_manacher_416371');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as p;e=next(x for x in p.collect()if x['id']=='manacher');rows=[]
for label in sys.argv[1:]or['base','short','skip_zero_copy','remaining','branch_advance','copy_back','cached_first']:
 h=D/('before/String/Manacher.cpp'if label=='base'else label+'.hpp');data,_=p.render(e,source_overrides={'String/Manacher.cpp':h.read_bytes()});src=D/f'{label}.cpp';src.write_bytes(data)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  exe=D/f'{cc}_{label}';cmd=['taskset','-c','4',*args,'-std=c++23','-O2',str(src),'-o',str(exe)];subprocess.run(cmd,check=True)
  for sample in e['samples']:
   r=subprocess.run([str(exe)],input=sample['input'],text=True,capture_output=True);assert r.returncode==0 and not r.stderr and p.matches(e,sample,r.stdout)
  rows.append(dict(label=label,compiler=cc,command=cmd,source_sha256=hashlib.sha256(data).hexdigest()));print(cc,label,'PASS',flush=True)
path=D/'builds.json';a=json.loads(path.read_text())if path.exists()else[];path.write_text(json.dumps(a+rows,indent=2)+'\n')
