from pathlib import Path
import hashlib,json,os,random,statistics,subprocess,time
work=Path('/tmp/sirkit_dev_pipeline_20261113');os.sched_setaffinity(0,{9})
versions=['before','codex'];compilers=['g++','clang++'];binaries={};commands={}
for c in compilers:
 for version in versions:
  exe=work/f'z_{c}_{version}';cmd=[c,'-std=c++23','-O2','-Wall','-Wextra']
  if c=='clang++':cmd+=['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
  cmd+=[str(work/f'z_{version}.cpp'),'-o',str(exe)]
  result=subprocess.run(cmd,capture_output=True,text=True);assert result.returncode==0,result.stderr
  binaries[c,version]=exe;commands[c,version]=cmd
rng=random.Random(20261113);samples=['a','aa','ab','aaaaaaa','abacaba']+[''.join(rng.choice('abcd') for _ in range(rng.randrange(1,180))) for _ in range(120)]
def naive(s):
 answer=[len(s)]
 for i in range(1,len(s)):
  k=0
  while i+k<len(s) and s[k]==s[i+k]:k+=1
  answer.append(k)
 return answer
for c in compilers:
 for version in versions:
  for s in samples:
   out=subprocess.run([str(binaries[c,version])],input=(s+'\n').encode(),capture_output=True,check=True).stdout
   assert list(map(int,out.split()))==naive(s)
cases=[]
for n in [1000,500000]:
 random_s=''.join(rng.choice('abcdefghijklmnopqrstuvwxyz') for _ in range(n))
 for name,s in [('random',random_s),('equal','a'*n),('periodic',('abacaba'*((n+6)//7))[:n])]:
  path=work/f'{name}_{n}.in';path.write_text(s+'\n');cases.append((name,n,path))
results=[]
for c in compilers:
 for name,n,path in cases:
  outputs=[]
  for version in versions:
   with path.open('rb') as inp:
    outputs.append(subprocess.run([str(binaries[c,version])],stdin=inp,capture_output=True,check=True).stdout)
  assert outputs[0]==outputs[1]
  timings={v:[] for v in versions}
  for iteration in range(11):
   order=versions if iteration%2==0 else list(reversed(versions))
   for version in order:
    with path.open('rb') as inp:
     start=time.perf_counter_ns();subprocess.run([str(binaries[c,version])],stdin=inp,stdout=subprocess.DEVNULL,check=True);elapsed=(time.perf_counter_ns()-start)/1e6
    if iteration>=2:timings[version].append(elapsed)
  med={v:statistics.median(timings[v]) for v in versions}
  results.append({'compiler':c,'case':name,'n':n,'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(outputs[0]).hexdigest(),'milliseconds':timings,'median_ms':med,'codex_over_before':med['codex']/med['before']})
report={'format':1,'id':'z_algorithm','scope':'whole_program','measurement':'local synthetic valid alphabet inputs, end-to-end wall time including process startup and I/O; not online timing','cpu':9,'warmup_pairs':2,'measured_pairs':9,'small_reference_cases':len(samples),'correctness':'passed','results':results,'commands':[{ 'compiler':c,'stage':v,'command':commands[c,v]} for c in compilers for v in versions],'sources':{v:hashlib.sha256((work/f'z_{v}.cpp').read_bytes()).hexdigest() for v in versions}}
(work/'z_codex_benchmark.json').write_text(json.dumps(report,indent=2)+'\n')
for r in results:print(r['compiler'],r['case'],r['n'],round(r['codex_over_before'],3))
