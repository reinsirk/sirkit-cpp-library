// SPDX-License-Identifier: CC0-1.0
// 参考（Z配列の用途とVerify先。実装は独自構成）:
// https://judge.yosupo.jp/problem/zalgorithm
// 参考（ACLのAPI）: https://atcoder.github.io/ac-library/production/document_ja/string.html
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/z_algorithm.md
//
// API一覧
// z_algorithm(const std::string&)/z_algorithm<T>(const std::vector<T>&): ACL形式のZ配列を返す。
// 追加のz_algorithm(sequence)は任意の添字アクセス可能な列に対応。空なら{}、非空ならz[0]=n。
// PrefixMatches(pattern,text): textの各開始位置とpatternの共通接頭辞長を返す。
// ZMatches(pattern,text): 完全一致する開始位置を昇順に返す。空patternは0..text.size()。
// size()/添字アクセスと同値関係の==が使える列が前提。比較O(1)ならZはO(n)、後2者はO(n+m)時間。
// 各列長はINT_MAX未満。Z/PrefixMatchesの領域は返却値とpattern長、ZMatchesはこれに一致数。

#include <algorithm>
#include <bit>
#include <climits>
#include <cstdint>
#include <cstring>
#include <type_traits>
#include <cstddef>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

#if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__)) && CHAR_BIT == 8
#include <immintrin.h>
#endif

#ifndef SIRKIT_Z_PREFIX_EXTEND_DEFINED
#define SIRKIT_Z_PREFIX_EXTEND_DEFINED
namespace reinsirk::detail {
inline int extend_prefix_word(const char* a, const char* b, int length, int limit) {
#if defined(UINT64_MAX) && CHAR_BIT == 8
    if constexpr (std::endian::native == std::endian::little || std::endian::native == std::endian::big) {
        while (limit - length >= 8) {
            std::uint64_t x, y;
            std::memcpy(&x, a + length, sizeof(x));
            std::memcpy(&y, b + length, sizeof(y));
            const auto difference = x ^ y;
            if (difference != 0) {
                if constexpr (std::endian::native == std::endian::little)
                    return length + static_cast<int>(std::countr_zero(difference) / 8);
                else return length + static_cast<int>(std::countl_zero(difference) / 8);
            }
            length += 8;
        }
    }
#endif
    while (length < limit && a[length] == b[length]) ++length;
    return length;
}
#if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__)) && CHAR_BIT == 8
[[gnu::target("avx2")]] inline int extend_prefix_avx2(const char* a, const char* b, int length, int limit) {
    while (limit - length >= 32) {
        __m256i x, y;
        std::memcpy(&x, a + length, 32);
        std::memcpy(&y, b + length, 32);
        const auto difference = ~static_cast<std::uint32_t>(
            _mm256_movemask_epi8(_mm256_cmpeq_epi8(x, y)));
        if (difference != 0) return length + static_cast<int>(std::countr_zero(difference));
        length += 32;
    }
    return extend_prefix_word(a, b, length, limit);
}
inline bool prefix_avx2_available() {
    static const bool supported = __builtin_cpu_supports("avx2");
    return supported;
}
#endif
}
#endif

#ifndef SIRKIT_Z_ALGORITHM_IMPL_DEFINED
#define SIRKIT_Z_ALGORITHM_IMPL_DEFINED
namespace reinsirk::detail {
template <class Sequence>
std::vector<int> z_algorithm_impl(const Sequence& s) {
    if (s.size() >= static_cast<std::size_t>(std::numeric_limits<int>::max()))
        throw std::length_error("z_algorithm: sequence too long");
    const int n = static_cast<int>(s.size());
    std::vector<int> z(s.size());
    if (n == 0) return z;
    z[0] = n;
    int i = 1;
    while (i < n && s[0] == s[i]) ++i;
    for (int j = 1; j < i; ++j) z[j] = i - j;
    if (i == n) return z;
    ++i;
    int length = 0;
    while (i < n) {
        if (length == 0) {
            // 未処理位置のz[i]は零初期化済み。不一致なら書き直さない。
            if (!static_cast<bool>(s[0] == s[i])) { ++i; continue; }
            length = 1;
        }
        if constexpr (std::is_same_v<Sequence, std::string>) {
            const int limit = n - i;
            // 短い一致は通常比較。長い一致のときだけブロック比較へ進む。
            const int short_limit = length + std::min(16, limit - length);
            while (length < short_limit && s[length] == s[i + length]) ++length;
            if (length == short_limit && length < limit) {
                #if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__)) && CHAR_BIT == 8
                if (limit - length >= 64 && prefix_avx2_available())
                    length = extend_prefix_avx2(s.data(), s.data() + i, length, limit);
                else
#endif
                    length = extend_prefix_word(s.data(), s.data() + i, length, limit);
            }
        } else {
            while (length < n - i && s[length] == s[i + length]) ++length;
        }
        z[i] = length;
        // 末尾まで一致した箱では、残りも確定済みの値だけで埋められる。
        if (length == n - i) {
            if (i == 1) {
                for (++i; i < n; ++i) z[i] = n - i;
            } else {
                const int left = i;
                for (++i; i < n; ++i) z[i] = std::min(n - i, z[i - left]);
            }
            break;
        }
        // 箱内で不一致まで確定する位置を写し、次の位置へ一致長を持ち越す。
        int advance = 1;
        while (advance < length && z[advance] < length - advance) {
            z[i + advance] = z[advance];
            ++advance;
        }
        i += advance;
        length = std::max(0, length - advance);
    }
    return z;
}
}
#endif

#ifndef SIRKIT_Z_ALGORITHM_DEFINED
#define SIRKIT_Z_ALGORITHM_DEFINED
template<class T>
std::vector<int> z_algorithm(const std::vector<T>& s) {
    return reinsirk::detail::z_algorithm_impl(s);
}
inline std::vector<int> z_algorithm(const std::string& s) {
    return reinsirk::detail::z_algorithm_impl(s);
}
template<class Sequence>
    requires requires(const Sequence& s) { s.size(); s[0] == s[0]; }
std::vector<int> z_algorithm(const Sequence& s) {
    return reinsirk::detail::z_algorithm_impl(s);
}
#endif

#ifndef SIRKIT_Z_MATCHES_DEFINED
#define SIRKIT_Z_MATCHES_DEFINED
template <class Pattern, class Text>
std::vector<int> PrefixMatches(const Pattern& pattern, const Text& text) {
    if (text.size() >= static_cast<std::size_t>(std::numeric_limits<int>::max()))
        throw std::length_error("PrefixMatches: text too long");
    const auto z = z_algorithm(pattern);
    const int n = static_cast<int>(text.size()), m = static_cast<int>(pattern.size());
    std::vector<int> matches(text.size());
    int left = 0, right = 0;
    for (int i = 0; i < n; ++i) {
        int length = i < right ? std::min(right - i, z[i - left]) : 0;
        while (length < m && length < n - i && pattern[length] == text[i + length]) ++length;
        matches[i] = length;
        if (i + length > right) { left = i; right = i + length; }
    }
    return matches;
}

template <class Pattern, class Text>
std::vector<int> ZMatches(const Pattern& pattern, const Text& text) {
    auto lengths = PrefixMatches(pattern, text);
    std::vector<int> positions;
    const int m = static_cast<int>(pattern.size());
    for (int i = 0; i < static_cast<int>(lengths.size()); ++i)
        if (lengths[i] == m) positions.push_back(i);
    if (m == 0) positions.push_back(static_cast<int>(text.size()));
    return positions;
}
#endif
