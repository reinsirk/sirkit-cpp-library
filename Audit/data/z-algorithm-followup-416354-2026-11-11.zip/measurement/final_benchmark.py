# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,os,random,json,statistics,fcntl,shutil,hashlib,sys
D=Path('/tmp/sirkit_z_416354');fixtures=json.loads(Path('/tmp/sirkit_z_416042/fixtures.json').read_text());rng=random.Random(416042);raw=[];summary=[]
names=['official_max_random_00','official_max_random_01','official_all_same_01','official_fib_str_00','official_binary_carry_00','custom_500000_random26','custom_500000_binary','custom_500000_periodic3','custom_500000_last_different','custom_500000_first_different','custom_500000_prefix_then_random','custom_4096_random26','custom_32_binary']
labels_in=['base','control','leading_run','leading_simple'];stem='final';reps=9
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for f in fixtures:
   for rep in range(reps):
    labels=labels_in.copy();rng.shuffle(labels)
    for label in labels:
     src=D/f'{cc}_{"base"if label=="control"else label}';shutil.copyfile(src,D/'active');(D/'active').chmod(0o700)
     with Path(f['path']).open('rb')as fi,(D/'output').open('wb')as fo:
      p=subprocess.Popen(['setarch','x86_64','-R','taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0
     h=hashlib.sha256((D/'output').read_bytes()).hexdigest()
     if f.get('expected_sha256'):assert h==f['expected_sha256'],(f['name'],label)
     raw.append(dict(compiler=cc,case=f['name'],rep=rep,label=label,cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),rss_bytes=ru.ru_maxrss*1024,output_sha256=h))
   rr=[x for x in raw if(x['compiler'],x['case'])==(cc,f['name'])];assert len({x['output_sha256']for x in rr})==1;m={l:statistics.median(x['cpu_ns']for x in rr if x['label']==l)for l in labels_in};base=statistics.median(x['cpu_ns']for x in rr if x['label']in['base','control']);summary.append(dict(compiler=cc,case=f['name'],median_cpu_ns=m,pooled_base_ns=base,ratios={l:m[l]/base for l in labels_in}));print(cc,f['name'],{l:round(m[l]/base,3)for l in labels_in},flush=True);(D/f'{stem}_raw.json').write_text(json.dumps(raw));(D/f'{stem}_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Complete',len(raw),flush=True)
