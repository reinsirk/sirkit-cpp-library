# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,zipfile,datetime
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_z_416354');P=Path('/tmp/sirkit_z_416042')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
for name in ['String/Z_Algorithm.cpp','Verify/current/drivers/z_algorithm_main.cpp','Verify/current/common/fast_io.hpp']:
 assert (D/'before'/name).read_bytes()==(R/name).read_bytes()
whole=load(D/'final_summary.json');typed=load(D/'typed_summary.json');guard=load(D/'guard_typed_summary.json');online=load(D/'416354.json');fixtures=load(P/'fixtures.json')
labels=['short','skip_zero_copy','remaining','branch_advance','copy_back','cached_first','long_word','long_avx2','leading_run','leading_word','leading_avx2','leading_simple','leading_guard']
commands=load(D/'builds.json');raw_paths=list(D.glob('*_raw.json'));counts={p.name:len(load(p))for p in raw_paths}
audit={
 'date':'2026-11-11','library':'String/Z_Algorithm.cpp','decision':'retain_current_AC_15ms_implementation','required_resubmission':[],
 'online':{'url':'https://judge.yosupo.jp/submission/416354','status':'AC','time_ms':15,'previous_url':'https://judge.yosupo.jp/submission/416042','previous_time_ms':22,'observed_reduction_percent':100*(22-15)/22,'source_match':'提出本文と現行本体/main/共通IOが空行・改行・行末空白・Submission注記のみ除き一致。','evidence':'Audit/online-z-algorithm-416354-2026-11-11.json','scope':'22→15msはオンライン観測値。ケースには9→1msや7→15msの増減もあるので、約32%を本体のみの短縮率と断定しない。'},
 'unchanged':{'canonical':sha(R/'String/Z_Algorithm.cpp'),'main':sha(R/'Verify/current/drivers/z_algorithm_main.cpp'),'shared_IO':sha(R/'Verify/current/common/fast_io.hpp'),'canonical_body_unchanged_from_416354':True,'main_and_io_unchanged':True,'API_documentation_example_unchanged':True},
 'candidates':[
  {'names':['short','skip_zero_copy','remaining','branch_advance','copy_back','cached_first'],'scope':'長さ1の特別処理、コピーする0の書込み省略、残り長保持、分岐で残り長設定、比較式書換え、算術型の先頭値キャッシュ。','result':'安定した全体改善が得られない。短縮条件と退行条件が混在。'},
  {'names':['long_word','long_avx2'],'scope':'文字列の短い一致はscalar比較し、16byte延長に成功してからword/AVX2比較へ進む。CPU判定とヘルパー呼出しも長一致の経路だけ。','result':'周期/longrunに短縮があるが、大規模random/binary等で後退。追加実装を正当化する一貫した改善がなく不採用。'},
  {'names':['leading_run','leading_word','leading_avx2'],'scope':'先頭の同値runから確定Z値をまとめて出力し、最初の非同値位置を省略。word/AVX2との併用も比較。','result':'末尾だけ異なる列等で改善するが、ランダム列や他APIの退行が残る。'},
  {'names':['leading_simple'],'scope':'leading_runで到達不能になったtailのi==1分岐も除去。全57入力と汎用APIで詳しく比較。','result':'500000要素last_differentでGCC約3.7%・Clang約8.1%改善。ただしClang max_random_00約2.1%増、純呼出しvector<bool>/binary約3.2%増等があり不採用。'},
  {'names':['leading_guard'],'scope':'先頭2要素が同値の場合だけrunを処理し、短いprefixの開始位置/通常経路を維持する案。','result':'純呼出し試験の大規模int64/binaryがGCC約5.2%増、bool/binaryがClang約2.9%増等。現行版を置き換えない。'}],
 'source_sha256':{name:sha(D/(name+'.hpp'))for name in labels},
 'measurement':{'host':'Intel Core i9-14900K','cpu':'P-Core CPU 12/core 6、sibling CPU 13、max 6 GHz','compiler':{'gcc':'15.2.0','clang':'21.1.8 (--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15)'},'flags':['-std=c++23','-O2'],'march_native':False,'additional_pragmas':False,'affinity':'taskset -c 12','ASLR':'子プロセスのみsetarch x86_64 -R。システム設定は変更しない。','lock':'/tmp/sirkit_performance_cpu12.lock','order':'before/control/candidateを決定的にシャッフルし同じ実行パスactiveで比較。controlはbeforeと同じバイナリ。','baseline':'今回のAC15ms版。前回22ms版ではない。','fixture_count':len(fixtures),'whole_screen_repetitions':3,'whole_final_repetitions':9,'whole_final_runs':len(load(D/'final_raw.json')),'whole_final_scope':'全57入力の固定main/IO込みの子プロセスuser+system時間。中央値、before/control pooled中央値比。','generic_repetitions':7,'generic_operations':{'4':'z_algorithm(string)','0':'z_algorithm(vector<int64_t>)','1':'z_algorithm(vector<bool>)','2':'PrefixMatches(string,string)','3':'ZMatches(string,string)'},'generic_sizes':[32,4096,500000],'generic_shapes':{'0':'all_same','1':'periodic3','2':'binary_random'},'generic_scope':'入力生成を除き、結果vectorの構築/破棄を含む繰返し呼出しのsteady_clock時間。Verify全体と区別。','run_counts':counts,'all_outputs_or_checksums_equal':True,'small_input_caveat':'全体測定の小入力は起動時間の影響が大きい。増減のすべてを本体差と見なさない。','official_revision':'73876f1cbcf082d2b22722924b924d3d65a2f00e','fixtures_reused':'Audit/data/performance-z-algorithm-416042-2026-11-10.zipの生成補助/公式固定URL/メタデータと同じ入力。現行オンラインケースのバイト列一致は主張しない。'},
 'selected_whole_results':[r for r in whole if r['case'] in ['custom_500000_last_different','custom_500000_middle_different','official_max_random_00','official_max_random_01','official_all_same_01','official_fib_str_00','official_binary_carry_00']],
 'selected_generic_regressions':{'leading_simple':[r for r in typed if r['n']==500000 and r['ratio']>1.01],'leading_guard':[r for r in guard if r['n']==500000 and r['ratio']>1.01]},
 'correctness':{'candidate_reference':load(D/'candidate_reference.json'),'scope':'leading_run/leading_simpleをGCC/Clang×検査有効無効でASan/UBSanつき接尾辞配列/LCP独立参照と照合。各115 cases/384 checks。追加APIなし。','canonical':'本体は無変更で今回の実提出ACを確認。前回の独立参照・境界・メモリ・確保失敗・API検証を維持。無変更の試験を無用に繰返さない。','prior_evidence':'Audit/performance-z-algorithm-416042-2026-11-10.json'},
 'conclusion':'13案を比較したが、通常版を置き換えるほど安定した改善は得られない。main/IO/本体は維持し、最新ACと提出注記を同期する。Z配列一般の最適化限界を証明するものではない。',
 'license':'候補・測定補助は独自CC0-1.0。公式外部生成器のソース本文は収録せず、前回と同じ固定URL/ハッシュだけ参照。',
 'evidence_zip':'Audit/data/z-algorithm-followup-416354-2026-11-11.zip'
}
path=R/'Audit/z-algorithm-followup-416354-2026-11-11.json';path.write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
files=[]
for p in D.iterdir():
 if p.is_file() and p.suffix in ['.json','.py','.hpp','.log']:files.append((p,'measurement/'+p.name))
for p in (D/'agent').glob('*'):
 if p.is_file():files.append((p,'candidate_sources/'+p.name))
for name in ['fixtures.json','official_sources.json','official_generation_plan.json','prepare_fixtures.py']:
 files.append((P/name,'fixture_dependencies/'+name))
for name in ['typed_benchmark.cpp','416354.cpp','before/String/Z_Algorithm.cpp','before/Verify/current/submissions/z_algorithm.cpp','before/Verify/current/drivers/z_algorithm_main.cpp','before/Verify/current/common/fast_io.hpp']:
 files.append((D/name,name))
files.append((path,'Audit/'+path.name));files.append((R/'Audit/online-z-algorithm-416354-2026-11-11.json','Audit/online-z-algorithm-416354-2026-11-11.json'))
with zipfile.ZipFile(R/audit['evidence_zip'],'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p,name in sorted(files,key=lambda v:v[1]):z.writestr(zipfile.ZipInfo(name,(2026,11,11,0,0,0)),p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
print('audit evidence',len(files),(R/audit['evidence_zip']).stat().st_size)
p=R/'Audit/distribution-manifest-before-z-confirmation-416354-2026-11-11.json';assert not p.exists();p.write_bytes((D/'before/Distribution/manifest.json').read_bytes())
