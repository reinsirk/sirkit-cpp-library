# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_z_416354');base=(D/'before/String/Z_Algorithm.cpp').read_text()
changes={
 'short':base.replace('        int advance = 1;','        if (length == 1) { ++i; length = 0; continue; }\n        int advance = 1;'),
 'skip_zero_copy':base.replace('            z[i + advance] = z[advance];','            if (z[advance] != 0) z[i + advance] = z[advance];'),
 'remaining':base.replace('        while (length < n - i && s[length] == s[i + length]) ++length;','        const int remaining = n - i;\n        while (length < remaining && s[length] == s[i + length]) ++length;').replace('if (length == n - i)', 'if (length == remaining)'),
 'branch_advance':base.replace('        length = std::max(0, length - advance);','        if (advance < length) length -= advance;\n        else length = 0;'),
 'copy_back':base.replace('        while (advance < length && z[advance] < length - advance) {','        while (advance < length && advance + z[advance] < length) {'),
}
# Only arithmetic elements are copied. Other element types keep existing references and requirements.
start=base.index('    int i = 1, length = 0;');end=base.index('    return z;',start);body=base[start:end].replace('s[0] == s[i]','first == s[i]')
cached=base[:start]+'    const auto run = [&](const auto& first) {\n'+body+'    };\n    using Element = std::remove_cvref_t<decltype(s[0])>;\n    if constexpr (std::is_arithmetic_v<Element>) {\n        const Element first = s[0];\n        run(first);\n    } else run(s[0]);\n'+base[end:]
changes['cached_first']=cached.replace('#include <string>','#include <string>\n#include <type_traits>')
changes['base']=base
for name,source in changes.items():(D/(name+'.hpp')).write_text(source)
