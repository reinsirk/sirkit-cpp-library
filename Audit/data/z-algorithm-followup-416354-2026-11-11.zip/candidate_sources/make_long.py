# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_z_416354/agent')
base=(R/'String/Z_Algorithm.cpp').read_text()
common='''#ifndef SIRKIT_Z_PREFIX_EXTEND_DEFINED
#define SIRKIT_Z_PREFIX_EXTEND_DEFINED
namespace reinsirk::detail {
inline int extend_prefix_word(const char* a, const char* b, int length, int limit) {
#if defined(UINT64_MAX) && CHAR_BIT == 8
    if constexpr (std::endian::native == std::endian::little || std::endian::native == std::endian::big) {
        while (limit - length >= 8) {
            std::uint64_t x, y;
            std::memcpy(&x, a + length, sizeof(x));
            std::memcpy(&y, b + length, sizeof(y));
            const auto difference = x ^ y;
            if (difference != 0) {
                if constexpr (std::endian::native == std::endian::little)
                    return length + static_cast<int>(std::countr_zero(difference) / 8);
                else return length + static_cast<int>(std::countl_zero(difference) / 8);
            }
            length += 8;
        }
    }
#endif
    while (length < limit && a[length] == b[length]) ++length;
    return length;
}
SIMD_HELPER
}
#endif

'''
simd='''#if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__)) && CHAR_BIT == 8
[[gnu::target("avx2")]] inline int extend_prefix_avx2(const char* a, const char* b, int length, int limit) {
    while (limit - length >= 32) {
        __m256i x, y;
        std::memcpy(&x, a + length, 32);
        std::memcpy(&y, b + length, 32);
        const auto difference = ~static_cast<std::uint32_t>(
            _mm256_movemask_epi8(_mm256_cmpeq_epi8(x, y)));
        if (difference != 0) return length + static_cast<int>(std::countr_zero(difference));
        length += 32;
    }
    return extend_prefix_word(a, b, length, limit);
}
inline bool prefix_avx2_available() {
    static const bool supported = __builtin_cpu_supports("avx2");
    return supported;
}
#endif'''
for label,use_simd in [('long_word',False),('long_avx2',True)]:
 s=base.replace('#include <algorithm>','#include <algorithm>\n#include <bit>\n#include <climits>\n#include <cstdint>\n#include <cstring>\n#include <type_traits>')
 helpers=common.replace('SIMD_HELPER',simd if use_simd else '')
 if use_simd:s=s.replace('#ifndef SIRKIT_Z_ALGORITHM_IMPL_DEFINED','''#if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__)) && CHAR_BIT == 8
#include <immintrin.h>
#endif

#ifndef SIRKIT_Z_ALGORITHM_IMPL_DEFINED''',1)
 s=s.replace('#ifndef SIRKIT_Z_ALGORITHM_IMPL_DEFINED',helpers+'#ifndef SIRKIT_Z_ALGORITHM_IMPL_DEFINED',1)
 call='length = extend_prefix_word(s.data(), s.data() + i, length, limit);'
 if use_simd:call='''#if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__)) && CHAR_BIT == 8
                if (limit - length >= 64 && prefix_avx2_available())
                    length = extend_prefix_avx2(s.data(), s.data() + i, length, limit);
                else
#endif
                    length = extend_prefix_word(s.data(), s.data() + i, length, limit);'''
 old='        while (length < n - i && s[length] == s[i + length]) ++length;'
 new='''        if constexpr (std::is_same_v<Sequence, std::string>) {
            const int limit = n - i;
            // 短い一致は通常比較。長い一致のときだけブロック比較へ進む。
            const int short_limit = length + std::min(16, limit - length);
            while (length < short_limit && s[length] == s[i + length]) ++length;
            if (length == short_limit && length < limit) {
                CALL
            }
        } else {
            while (length < n - i && s[length] == s[i + length]) ++length;
        }'''.replace('CALL',call)
 assert s.count(old)==1
 s=s.replace(old,new)
 (D/(label+'.hpp')).write_text(s)
 print(D/(label+'.hpp'))
