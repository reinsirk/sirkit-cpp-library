// SPDX-License-Identifier: CC0-1.0
#include SIRKIT_SCC_BENCH_SOURCE
#include "/home/reinsirk/Atcoder_Env/Graph/Two_SAT.cpp"
#include <cstdint>
#include <cinttypes>
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <string>
int main(int argc,char**argv){
 if(argc!=5)return 2;
 const int n=std::atoi(argv[1]),reps=std::atoi(argv[4]);const std::string kind=argv[2],mode=argv[3];
 std::vector<std::pair<int,int>> edges;
 if(kind=="line"||kind=="cycle"){
  for(int i=1;i<n;++i)edges.emplace_back(i-1,i);
  if(kind=="cycle"&&n)edges.emplace_back(n-1,0);
 }else if(kind=="paired")for(int i=0;i<n;++i)edges.emplace_back(i,i^1);
 else if(kind=="star")for(int i=1;i<n;++i)edges.emplace_back(0,i);
 else if(kind=="random"||kind=="dag"){
  std::uint64_t seed=937191;
  auto next=[&](){seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;return seed;};
  for(int i=0;i<2*n;++i){int u=next()%n,v=next()%n;if(kind=="dag"&&u>v)std::swap(u,v);edges.emplace_back(u,v);}
 }
 scc_graph graph(n);graph.reserve_edges(edges.size());for(auto[u,v]:edges)graph.add_edge(u,v);
 Graph adjacent;if(mode=="constructor"){adjacent.resize(n);for(auto[u,v]:edges)adjacent[u].push_back(v);}
 TwoSAT sat(n);if(mode=="sat")for(auto[u,v]:edges)sat.add_clause(u,true,v,false);
 if(mode=="condensation")graph.build();
 std::uint64_t sum=0;const auto start=std::clock();
 for(int r=0;r<reps;++r){
  if(mode=="build")sum+=graph.build();
  else if(mode=="scc"){auto groups=graph.scc();sum+=groups.size();if(!groups.empty())sum+=groups.front().front();}
  else if(mode=="condensation"){auto dag=graph.condensation();sum+=dag.size();}
  else if(mode=="constructor"){scc_graph g(adjacent);sum+=g.component_count();}
  else if(mode=="sat"){sum+=sat.solve();sum+=sat.answer().size();}
  else return 3;
 }
 const auto elapsed=std::clock()-start;
 const std::uint64_t nanos=static_cast<std::uint64_t>(elapsed)*std::uint64_t{1000000000}/CLOCKS_PER_SEC;
 std::printf("%" PRIu64 " %" PRIu64 "\n",nanos,sum);
}
