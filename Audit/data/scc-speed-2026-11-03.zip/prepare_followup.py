# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess
D=Path('/tmp/sirkit_scc_speed_20261103');s=(D/'index32.hpp').read_text();reverse=s.replace('std::vector<Index> next(begin.begin(), begin.end() - 1);','std::vector<Index> next(begin.begin() + 1, begin.end());').replace('    for (auto [u, v] : edges) destination[next[u]++] = v;\n    std::copy_n(begin.begin(), n, next.begin());','    for (auto it = edges.rbegin(); it != edges.rend(); ++it)\n        destination[--next[it->first]] = it->second;')
(D/'reverse.hpp').write_text(reverse)
old='''        std::vector<std::vector<int>> groups(count_);
        std::vector<std::size_t> sizes(count_);'''
new='''        std::vector<std::vector<int>> groups(count_);
        if (count_ == 1) {
            auto& group = groups.front();
            group.resize(n_);
            for (int v = 0; v < n_; ++v) group[v] = v;
            return groups;
        }
        if (count_ == n_) {
            for (int v = 0; v < n_; ++v) groups[ids_[v]].push_back(v);
            return groups;
        }
        std::vector<int> sizes(count_);'''
assert old in reverse
for label,text in [('group',reverse.replace(old,new)),('resize',reverse.replace(old,new).replace('for (int id = 0; id < count_; ++id) groups[id].reserve(sizes[id]);\n        for (int v = 0; v < n_; ++v) groups[ids_[v]].push_back(v);','for (int id = 0; id < count_; ++id) groups[id].resize(sizes[id]);\n        for (int v = n_; v-- > 0;) groups[ids_[v]][--sizes[ids_[v]]] = v;'))]:
 # 同じ成分ID順を保つ空辺専用経路。
 needle='''inline std::pair<int, std::vector<int>> directed_component_ids(
        int n, const std::vector<std::pair<int, int>>& edges) {
'''
 assert needle in text
 text=text.replace(needle,needle+'''    if (edges.empty()) {
        std::vector<int> ids(n);
        for (int v = 0; v < n; ++v) ids[v] = n - 1 - v;
        return {n, std::move(ids)};
    }
''')
 (D/f'{label}.hpp').write_text(text)
for label in ['reverse','group','resize']:
 text=(D/f'{label}.hpp').read_text();driver=(D/'driver.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"',(D/'io.hpp').read_text());(D/f'{label}.cpp').write_text('#define SKIP_RUNTIME_CHECKS\n'+text+'\n'+driver)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:subprocess.run(['taskset','-c','4',*args,'-std=c++23','-O2',str(D/f'{label}.cpp'),'-o',str(D/f'{cc}_{label}')],check=True)
print('reverse/group/resize compiled')
