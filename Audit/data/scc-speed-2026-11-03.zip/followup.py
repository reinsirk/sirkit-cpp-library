# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,subprocess,os,statistics,random,fcntl,shutil,hashlib
D=Path('/tmp/sirkit_scc_speed_20261103');rng=random.Random(20261104);raw=[]
cases=[x['name']for x in json.loads((D/'fixtures.json').read_text())if x['name'].startswith('official_')]+['custom_500000_'+k for k in ['line','cycle','empty','dag','paired','star']]+['custom_4096_'+k for k in ['line','random','dag','cycle']if (D/f'custom_4096_{k}.in').exists()]+['custom_32_dag']
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for case in cases:
   for rep in range(9):
    labels=['base','control','index32','reverse','group','resize'];rng.shuffle(labels)
    for label in labels:
     shutil.copyfile(D/f'{cc}_{"base"if label=="control"else label}',D/'active');(D/'active').chmod(0o700)
     with (D/f'{case}.in').open('rb')as fi,(D/'output').open('wb')as fo:
      p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0
     raw.append(dict(compiler=cc,case=case,rep=rep,label=label,cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),max_rss_bytes=ru.ru_maxrss*1024,sha256=hashlib.sha256((D/'output').read_bytes()).hexdigest()))
   rr=[r for r in raw if r['compiler']==cc and r['case']==case];assert len({r['sha256']for r in rr})==1;m={l:statistics.median(r['cpu_ns']for r in rr if r['label']==l)for l in labels};print(cc,case,{k:round(x/m['base'],4)for k,x in m.items()},flush=True);(D/'followup_raw.json').write_text(json.dumps(raw))
