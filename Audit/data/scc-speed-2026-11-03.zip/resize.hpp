// SPDX-License-Identifier: CC0-1.0
// 参考（問題選定・強連結成分の考え方）: https://nyaannyaan.github.io/library/graph/strongly-connected-components.hpp
// 参考（API仕様）: https://atcoder.github.io/ac-library/production/document_ja/scc.html
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/scc.md
//
// API一覧
// scc_graph() / scc_graph(n): 空／n頂点の有向グラフ。頂点番号[0,n)。O(1)準備。
// scc_graph(g): Graphから構築・分解。自己辺・多重辺可。O(n+m)時間・領域。
// add_edge(u,v): 有向辺追加。償却O(1)。分解結果を無効化する。reserve_edges(m): m辺分を確保。
// scc(): 分解し、トポロジカル順のvector<vector<int>>を返す。群内は頂点番号の昇順。O(n+m)時間・領域。
// build(): 頂点群を作らず分解し、成分数を返す追加API。O(n+m)時間・領域。
// size()/edge_count(): 頂点数/辺数。O(1)。component_count()/id(v)/ids(): 成分数/番号/番号配列へのconst参照。O(1)。
// 成分番号は縮約DAGのトポロジカル順。異成分の辺u→vではid(u)<id(v)。結果の照会はscc/build後に行う。
// condensation(unique=true): 縮約Graph。自己辺は除き、既定では多重辺も除く。O(n+m)時間・追加領域。
// reset(n=0): 空のn頂点へ戻す。swap(other): O(1)交換。コピーは独立所有、ムーブ元は空の未分解グラフ。
// 入力検査はSKIP_RUNTIME_CHECKSで除く。ids()の参照は再scc/build・代入・破棄で無効になる。

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <utility>
#include <vector>

#ifndef SIRKIT_UNWEIGHTED_GRAPH_DEFINED
#define SIRKIT_UNWEIGHTED_GRAPH_DEFINED
using Graph = std::vector<std::vector<int>>;
#endif

#ifndef SIRKIT_SCC_DETAIL_DEFINED
#define SIRKIT_SCC_DETAIL_DEFINED
namespace reinsirk::detail {
template<class Index>
inline std::pair<int, std::vector<int>> directed_component_ids_index(
        int n, const std::vector<std::pair<int, int>>& edges) {
    std::vector<Index> begin(static_cast<std::size_t>(n) + 1);
    for (auto [u, v] : edges) { (void)v; ++begin[static_cast<std::size_t>(u) + 1]; }
    for (int v = 0; v < n; ++v) begin[v + 1] += begin[v];
    std::vector<Index> next(begin.begin() + 1, begin.end());
    std::vector<int> destination(edges.size());
    for (auto it = edges.rbegin(); it != edges.rend(); ++it)
        destination[--next[it->first]] = it->second;
    // ids is low-link while a vertex is pending, and its component after pop.
    std::vector<int> entered(n, -1), ids(n), dfs, pending;
    dfs.reserve(n); pending.reserve(n);
    int clock = 0, count = 0;
    for (int root = 0; root < n; ++root) {
        if (entered[root] != -1) continue;
        int v = root;
        entered[v] = ids[v] = clock++;
        pending.push_back(v);
        for (;;) {
            if (next[v] != begin[v + 1]) {
                const int u = destination[next[v]++];
                if (entered[u] == -1) {
                    dfs.push_back(v);
                    v = u;
                    entered[v] = ids[v] = clock++;
                    pending.push_back(v);
                } else ids[v] = std::min(ids[v], entered[u]);
                continue;
            }
            const int child_low = ids[v];
            const bool is_root = child_low == entered[v];
            // Parent's low-link must use the saved low value before ids[v] becomes a component id.
            const bool has_parent = !dfs.empty();
            int parent = 0;
            if (has_parent) {
                parent = dfs.back(); dfs.pop_back();
                ids[parent] = std::min(ids[parent], child_low);
            }
            if (is_root) {
                for (;;) {
                    const int u = pending.back(); pending.pop_back();
                    entered[u] = n; ids[u] = count;
                    if (u == v) break;
                }
                ++count;
            }
            if (!has_parent) break;
            v = parent;
        }
    }
    for (auto& id : ids) id = count - 1 - id;
    return {count, std::move(ids)};
}
inline std::pair<int, std::vector<int>> directed_component_ids(
        int n, const std::vector<std::pair<int, int>>& edges) {
    if (edges.empty()) {
        std::vector<int> ids(n);
        for (int v = 0; v < n; ++v) ids[v] = n - 1 - v;
        return {n, std::move(ids)};
    }
    if (edges.size() <= std::numeric_limits<std::uint32_t>::max())
        return directed_component_ids_index<std::uint32_t>(n, edges);
    return directed_component_ids_index<std::size_t>(n, edges);
}
}
#endif

#ifndef SIRKIT_SCC_GRAPH_DEFINED
#define SIRKIT_SCC_GRAPH_DEFINED
class scc_graph {
    int n_ = 0, count_ = 0;
    std::vector<std::pair<int, int>> edges_;
    std::vector<int> ids_;
#ifndef SKIP_RUNTIME_CHECKS
    bool built_ = false;
    void vertex(int v) const {
        if (v < 0 || v >= n_) throw std::out_of_range("SCC: vertex out of range");
    }
    void require_build() const {
        if (!built_) throw std::logic_error("SCC: call scc or build first");
    }
#endif
public:
    scc_graph() = default;
    explicit scc_graph(int n) : n_(n) {
        if (n < 0) throw std::length_error("SCC: negative size");
    }
    explicit scc_graph(const Graph& g) {
        if (g.size() > static_cast<std::size_t>(std::numeric_limits<int>::max()))
            throw std::length_error("SCC: too many vertices");
        n_ = static_cast<int>(g.size());
        for (int u = 0; u < n_; ++u) for (int v : g[u]) add_edge(u, v);
        build();
    }
    scc_graph(const scc_graph&) = default;
    scc_graph(scc_graph&& other) noexcept { swap(other); }
    scc_graph& operator=(scc_graph other) noexcept { swap(other); return *this; }
    void swap(scc_graph& other) noexcept {
        std::swap(n_, other.n_); std::swap(count_, other.count_);
        edges_.swap(other.edges_); ids_.swap(other.ids_);
#ifndef SKIP_RUNTIME_CHECKS
        std::swap(built_, other.built_);
#endif
    }
    void reset(int n = 0) { scc_graph replacement(n); swap(replacement); }
    int size() const noexcept { return n_; }
    std::size_t edge_count() const noexcept { return edges_.size(); }
    void reserve_edges(std::size_t count) { edges_.reserve(count); }
    void add_edge(int u, int v) {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        edges_.emplace_back(u, v);
#ifndef SKIP_RUNTIME_CHECKS
        built_ = false;
#endif
    }
    int build() {
        auto result = reinsirk::detail::directed_component_ids(n_, edges_);
        ids_.swap(result.second); count_ = result.first;
#ifndef SKIP_RUNTIME_CHECKS
        built_ = true;
#endif
        return count_;
    }
    int component_count() const {
#ifndef SKIP_RUNTIME_CHECKS
        require_build();
#endif
        return count_;
    }
    int id(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        require_build(); vertex(v);
#endif
        return ids_[v];
    }
    const std::vector<int>& ids() const {
#ifndef SKIP_RUNTIME_CHECKS
        require_build();
#endif
        return ids_;
    }
    std::vector<std::vector<int>> scc() {
        build();
        std::vector<std::vector<int>> groups(count_);
        if (count_ == 1) {
            auto& group = groups.front();
            group.resize(n_);
            for (int v = 0; v < n_; ++v) group[v] = v;
            return groups;
        }
        if (count_ == n_) {
            for (int v = 0; v < n_; ++v) groups[ids_[v]].push_back(v);
            return groups;
        }
        std::vector<int> sizes(count_);
        for (int id : ids_) ++sizes[id];
        for (int id = 0; id < count_; ++id) groups[id].resize(sizes[id]);
        for (int v = n_; v-- > 0;) groups[ids_[v]][--sizes[ids_[v]]] = v;
        return groups;
    }
    Graph condensation(bool unique_edges = true) const {
#ifndef SKIP_RUNTIME_CHECKS
        require_build();
#endif
        Graph result(count_);
        if (!unique_edges) {
            for (auto [u, v] : edges_) if (ids_[u] != ids_[v]) result[ids_[u]].push_back(ids_[v]);
            return result;
        }
        std::vector<std::vector<int>> destinations(count_);
        for (auto [u, v] : edges_) if (ids_[u] != ids_[v]) destinations[ids_[u]].push_back(ids_[v]);
        std::vector<int> last(count_, -1);
        for (int from = 0; from < count_; ++from)
            for (int to : destinations[from]) if (last[to] != from) {
                last[to] = from; result[from].push_back(to);
            }
        return result;
    }
};
#endif
