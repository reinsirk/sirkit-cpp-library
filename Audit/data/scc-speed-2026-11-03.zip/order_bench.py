# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,statistics,random,shutil,os,json,hashlib,fcntl
D=Path('/tmp/sirkit_scc_speed_20261103');s=(D/'final_before_ordering.hpp').read_text();old='''        if (count_ == n_) {
            for (int v = 0; v < n_; ++v) groups[ids_[v]].push_back(v);
            return groups;
        }'''
assert old in s
variants={'order_reserve':s.replace(old,'''        if (count_ == n_) {
            for (auto& group : groups) group.reserve(1);
            for (int v = 0; v < n_; ++v) groups[ids_[v]].push_back(v);
            return groups;
        }'''),'order_resize':s.replace(old,'''        if (count_ == n_) {
            for (auto& group : groups) group.resize(1);
            for (int v = 0; v < n_; ++v) groups[ids_[v]][0] = v;
            return groups;
        }''')}
raw=[];rng=random.Random(833102)
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for label,text in variants.items():
  (D/f'{label}.hpp').write_text(text);driver=(D/'driver.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"',(D/'io.hpp').read_text());(D/f'{label}.cpp').write_text('#define SKIP_RUNTIME_CHECKS\n'+text+'\n'+driver)
  for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:subprocess.run(['taskset','-c','4',*args,'-std=c++23','-O2',str(D/f'{label}.cpp'),'-o',str(D/f'{cc}_{label}')],check=True)
 for cc in ['gcc','clang']:
  for case in ['official_max_random_0','official_max_random_2','official_random_2','official_large_cycle_0','custom_500000_dag','custom_500000_line','custom_500000_empty','custom_500000_star','custom_4096_dag','custom_32_dag']:
   for rep in range(9):
    labels=['base','control','group','order_reserve','order_resize'];rng.shuffle(labels)
    for label in labels:
     shutil.copyfile(D/f'{cc}_{"base"if label=="control"else label}',D/'active');(D/'active').chmod(0o700)
     with (D/f'{case}.in').open('rb')as fi,(D/'output').open('wb')as fo:
      p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0
     raw.append(dict(compiler=cc,case=case,rep=rep,label=label,cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),sha256=hashlib.sha256((D/'output').read_bytes()).hexdigest()))
   rr=[r for r in raw if r['compiler']==cc and r['case']==case];assert len({r['sha256']for r in rr})==1;m={l:statistics.median(r['cpu_ns']for r in rr if r['label']==l)for l in labels};print(cc,case,{k:round(x/m['base'],4)for k,x in m.items()},flush=True);(D/'order_raw.json').write_text(json.dumps(raw))
