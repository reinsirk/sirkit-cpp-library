# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
D=Path('/tmp/sirkit_scc_speed_20261103');s=(D/'group.hpp').read_text();old='''        std::vector<std::vector<int>> destinations(count_);
        for (auto [u, v] : edges_) if (ids_[u] != ids_[v]) destinations[ids_[u]].push_back(ids_[v]);
        std::vector<int> last(count_, -1);
        for (int from = 0; from < count_; ++from)
            for (int to : destinations[from]) if (last[to] != from) {
                last[to] = from; result[from].push_back(to);
            }
        return result;'''
new='''        for (auto [u, v] : edges_) if (ids_[u] != ids_[v]) result[ids_[u]].push_back(ids_[v]);
        std::vector<int> last(count_, -1);
        for (int from = 0; from < count_; ++from) {
            auto& row = result[from];
            std::size_t used = 0;
            for (int to : row) if (last[to] != from) {
                last[to] = from; row[used++] = to;
            }
            row.resize(used);
            if (used < row.capacity() / 2) {
                std::vector<int> compact(row);
                row.swap(compact);
            }
        }
        return result;'''
assert old in s;s=s.replace(old,new);(D/'compact.hpp').write_text(s);(D/'compact_body.txt').write_text(new)
