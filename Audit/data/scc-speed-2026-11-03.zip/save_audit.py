# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,zipfile,collections,statistics,datetime
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_scc_speed_20261103');A=R/'Audit'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def summaries(file,keys):
 rows=json.loads((D/file).read_text());d=collections.defaultdict(lambda:collections.defaultdict(list))
 for x in rows:d[tuple(x[k]for k in keys)][x['label']].append(x['cpu_ns'])
 result=[]
 for key,values in d.items():
  med={label:statistics.median(ns)for label,ns in values.items()};result.append(dict(**dict(zip(keys,key)),median_cpu_ns=med,ratio_to_before={l:v/med['base']for l,v in med.items()}))
 return result
source_files=[]
for f in ['random.cpp','max_random.cpp','large_cycle.cpp','random.h','info.toml']:
 p=D/'official_generator'/f
 u='https://raw.githubusercontent.com/yosupo06/library-checker-problems/master/' + ('common/random.h'if f=='random.h'else 'graph/scc/'+('gen/'if f.endswith('.cpp')else'')+f)
 source_files.append(dict(file=f,url=u,sha256=sha(p)))
(D/'official_metadata.json').write_text(json.dumps(dict(license='Apache-2.0',sources_not_redistributed=True,files=source_files,fixtures=json.loads((D/'fixtures.json').read_text())),indent=2)+'\n')
checks=json.loads((D/'checks.json').read_text());final=json.loads((D/'final_checks.json').read_text());assert len(checks)==16 and len(final)==12 and all(x['returncode']==0 and not x['stderr']for x in checks+final)
profile=json.loads(sorted((D/'profiles/runs').glob('*.json'))[-1].read_text());assert profile['counts']=={'LOCAL_SAMPLE_PASS':14}
archive=A/'data/scc-speed-2026-11-03.zip'
files=['before.hpp','two_sat_before.hpp','driver.cpp','io.hpp','mark.hpp','merged.hpp','local.hpp','index32.hpp','reverse.hpp','group.hpp','resize.hpp','compact.hpp','adopted.hpp','final.hpp','final_before_ordering.hpp','allocation_before_ordering.cpp','allocation_before_condensation.cpp','order_reserve.hpp','order_resize.hpp','order_bench.py','order_bench.log','order_raw.json','order_micro_bench.py','order_micro_bench.log','order_micro_raw.json','order_checks.py','order_checks.log','order_checks.json','prepare.py','prepare.log','extend.py','extend.log','screen.py','screen.log','screen_raw.json','prepare_followup.py','prepare_followup.log','followup.py','followup.log','followup_raw.json','micro.cpp','micro_bench.py','micro_bench.log','micro_raw.json','compact_prepare.py','compact_bench.py','compact_bench.log','compact_raw.json','checks.py','checks.log','checks.json','final_checks.py','final_checks.log','final_checks.json','generation.log','profiles.log','normal_samples.json','official_metadata.json','save_audit.py']
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for f in files:z.write(D/f,f)
 for f in ['Graph/SCC.cpp','Graph/Two_SAT.cpp','Verify/current/tests/scc_acl_api_test.cpp','Verify/current/tests/new_scc_two_sat_reference_test.cpp','Verify/current/tests/scc_index_paths_test.cpp','Verify/current/tests/scc_condensation_test.cpp','Verify/current/tests/new_graph_allocation_test.cpp']:z.write(R/f,'final/'+f)
 for p in (D/'profiles').rglob('*.json'):
  if 'attempts'not in p.parts:z.write(p,'profiles/'+p.relative_to(D/'profiles').as_posix())
audit={
 'date':'2026-11-03','decision':'共有作業領域・32bit CSR・現在頂点の保持・成分一覧と縮約Graphの構築改善を採用。mainと共通I/Oは変更なし。',
 'baseline_online':'Audit/online-scc-414951-2026-11-03.json',
 'online_status':{'before_submission':414951,'before_status':'AC','before_ms':93,'current_status':'未提出','needs_resubmission':['Verify/current/submissions/scc.cpp'],'scope':'TwoSATも共通SCC内部関数を同期。通常版TwoSATはまだ初回オンラインVerify前。通常版のACを派生版へ転記しない。'},
 'changes':['enteredのnを成分確定の印に使い、active配列を除去。low-linkと最終成分番号をidsの同じ領域へ格納し、親への伝播は成分番号の上書き前に行う。','現在頂点をローカルへ保持し、DFSスタックには親だけを保存。反復処理・辺順・従来の成分ID列を維持。','辺数がUINT32_MAX以下の場合に限りCSRのprefix/cursorをuint32_tにし、超過時はsize_t経路へ戻す。逆順の辺を後方から詰め、辺順を変えずcursorの再初期化を省く。','無辺・1成分・全頂点が別成分の数学的に確定するケースでは不要な探索・サイズ集計を省く。singletonも成分順にreserveして配置を維持。通常経路の成分サイズ計数もintにして領域を減らす。','縮約Graphは各行の同じ領域で重複を詰め、頂点群の二重作成を除去。多重辺を除いて容量が過大になった行は小さいvectorへ置き換えて解放。unique=falseの多重辺とunique=trueの最初の出現順を維持。'],
 'API':'scc_graph/add_edge/sccと既存のbuild/ids/condensation等を維持。Graph/Two_SAT.cppと共有ガード内の実装は同一。',
 'bounds':'CSRのprefix/cursorは0..m。m==UINT32_MAXも表現可で、後方充填のアクセス時はdecrement後の値がm未満。m超過はsize_t。両テンプレート経路を同じ小規模/大規模入力で直接試験したが、4b辺の実確保・実測はしていない。n/clock/countはintの最大値まで表現可能。',
 'environment':{'cpu':'Intel Core i9-14900K P-Core CPU12（sibling13）','compiler_versions':profile['compiler_versions'],'flags':['-std=c++23','-O2','SKIP_RUNTIME_CHECKS'],'march_native':False,'custom_optimization_pragmas':False,'explicit_SIMD_added':False,'governor':'powersave、周波数固定なし','timing':'同じmain/共通I/O/コンパイラ/検査条件。順序を乱数化し、同じファイル名へバイナリを切替。controlはbeforeと同じバイナリ。mainはwait4 user+system、API単体はstd::clock。','contention':'自分の性能測定・コンパイル/テストをflockで直列化。E-Coreは対象外。'},
 'performance':{'screen':summaries('screen_raw.json',['compiler','case']),'followup_main':summaries('followup_raw.json',['compiler','case']),'API_before_allocation_ordering':summaries('micro_raw.json',['compiler','n','kind','mode']),'final_main_allocation_ordering':summaries('order_raw.json',['compiler','case']),'final_DAG_API':summaries('order_micro_raw.json',['compiler','n','kind','mode']),'condensation_followup':summaries('compact_raw.json',['compiler','n','kind','mode']),'scope':'公式generator取得版の固定seedから作った入力相当であり、稼働中ジャッジのgenerator commit/隠し入力と同一だとは断定しない。全main出力SHAまたはAPI checksumを照合。初期group案の公式相当11入力はGCC4.5〜12.5%、Clang4.6〜16.2%短縮。最終order_reserve案はfinal_main_allocation_orderingの4公式相当+6独自入力を再測定し、公式相当4入力でGCC5.1〜13.1%/Clang5.9〜16.2%短縮。初期案の全入力結果を最終版の全入力測定と混同しない。オンライン時間は再提出で確認する。','limitations':['初期group案はClang4096頂点DAGのscc単体約10.5%増、大規模DAG mainも退行したため、singletonを成分順に確保するorder_reserve案へ修正。最終再測定の大規模DAG mainはGCC約8.4%/Clang約8.8%短縮、scc単体は約24%/20%短縮。Clang4096頂点DAGのscc単体もbefore同等となった。','縮約GraphのClang32頂点pairedは約13%増。大規模では明確に改善し、小規模退行許容の方針で採用。全条件の非退行を断定しない。','最初のAPI用測定補助コードにprintfの型不一致を発見して中断・修正。-Wall -Wextra -Werrorで全設定を再コンパイルし、全API比較を再実行した有効なmicro_raw.jsonのみ採用。修正前データは証拠ZIPへ含めない。']},
 'tests':{'before_condensation_change':checks,'final_condensation_change':final,'final_allocation_ordering':json.loads((D/'order_checks.json').read_text()),'profiles':profile['counts'],'normal_submissions':json.loads((D/'normal_samples.json').read_text()),'coverage':'独立Kosarajuと到達可能性全探索、n<=4の全有向グラフ、乱数・69,680グラフ、30万鎖/閉路、自己辺・多重辺・200,000重複辺、再分解・API型・コピー/ムーブ・TwoSAT全探索・確保失敗を検証。','settings':'GCC/Clang×検査有無。API/参照/両添字経路/縮約はASan+UBSan、最終例外試験はorder_checks.json（singleton確保失敗も追加）、各設定live_delta=0。SIRKIT_DISABLE_SIMDも定義。','memory_leak_scope':'ASAN_OPTIONS=detect_leaks=0。部分構築・縮約中の確保失敗による解放はliveカウンタの割当試験で補足。'},
 'hashes':{'before_scc':sha(D/'before.hpp'),'current_scc':sha(R/'Graph/SCC.cpp'),'before_two_sat':sha(D/'two_sat_before.hpp'),'current_two_sat':sha(R/'Graph/Two_SAT.cpp'),'driver_before_and_after':sha(D/'driver.cpp'),'io_before_and_after':sha(D/'io.hpp')},
 'evidence':{'path':archive.relative_to(R).as_posix(),'sha256':sha(archive),'contents':'自作コード/比較候補/測定ログ/生データ/fixtureの出典とSHA/テスト結果。公式generator原本・実行バイナリ・大きい入力・無効な測定データは含めない。'},
 'synchronization':'本体・GCC/Clang・速度優先・通常/派生Verifyを同期。公開API/Documentの記述・使用例の呼出は変更不要。配布ZIP検証はDistribution/validation.json。'
}
(A/'performance-scc-2026-11-03.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print('Audit/evidence saved',len(checks)+len(final)+len(json.loads((D/'order_checks.json').read_text())),'checked builds/runs,',profile['counts'])
