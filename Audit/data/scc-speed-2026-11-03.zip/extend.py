# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_scc_speed_20261103');base=(D/'merged.hpp').read_text();a=base.index('inline std::pair<int, std::vector<int>> directed_component_ids(');end=base.index('\n}\n}\n#endif',a)+2
part=Path('/tmp/sirkit_scc_review_20261103/merged.hpp').read_text();part=part[part.index('inline std::pair'):].replace('merged_component_ids','directed_component_ids').rstrip()
local=base[:a]+part+base[end:];(D/'local.hpp').write_text(local)
idxpart=part.replace('inline std::pair<int, std::vector<int>> directed_component_ids(', 'template<class Index>\ninline std::pair<int, std::vector<int>> directed_component_ids_index(').replace('std::vector<std::size_t>', 'std::vector<Index>')
idxpart+='''
inline std::pair<int, std::vector<int>> directed_component_ids(
        int n, const std::vector<std::pair<int, int>>& edges) {
    if (edges.size() <= std::numeric_limits<std::uint32_t>::max())
        return directed_component_ids_index<std::uint32_t>(n, edges);
    return directed_component_ids_index<std::size_t>(n, edges);
}'''
idx=(base[:a]+idxpart+base[end:]).replace('#include <cstddef>','#include <cstddef>\n#include <cstdint>');(D/'index32.hpp').write_text(idx)
for label,src in [('local',local),('index32',idx)]:
 driver=(D/'driver.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"',(D/'io.hpp').read_text());(D/f'{label}.cpp').write_text('#define SKIP_RUNTIME_CHECKS\n'+src+'\n'+driver)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:subprocess.run(['taskset','-c','4',*args,'-std=c++23','-O2',str(D/f'{label}.cpp'),'-o',str(D/f'{cc}_{label}')],check=True)
print('local/index32 compiled')
