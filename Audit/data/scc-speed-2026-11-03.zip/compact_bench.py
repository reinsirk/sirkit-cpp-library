# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,random,json,shutil,statistics,fcntl
D=Path('/tmp/sirkit_scc_speed_20261103');raw=[];rng=random.Random(543123)
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  subprocess.run(['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror','-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_SCC_BENCH_SOURCE="{D/"compact.hpp"}"',str(D/'micro.cpp'),'-o',str(D/f'micro_{cc}_compact')],check=True)
 for cc in ['gcc','clang']:
  for n,reps in [(32,20000),(4096,150),(500000,3)]:
   for kind in ['line','random','paired']:
    for rep in range(11):
     labels=['base','control','group','compact'];rng.shuffle(labels)
     for label in labels:
      shutil.copyfile(D/f'micro_{cc}_{"base" if label=="control"else label}',D/'micro_active');(D/'micro_active').chmod(0o700)
      p=subprocess.run(['taskset','-c','12',str(D/'micro_active'),str(n),kind,'condensation',str(reps)],capture_output=True,text=True,check=True);cpu,checksum=map(int,p.stdout.split());raw.append(dict(compiler=cc,n=n,kind=kind,mode='condensation',repetitions=reps,rep=rep,label=label,cpu_ns=cpu,checksum=checksum))
    rr=[r for r in raw if (r['compiler'],r['n'],r['kind'])==(cc,n,kind)];assert len({r['checksum']for r in rr})==1;m={l:statistics.median(r['cpu_ns']for r in rr if r['label']==l)for l in labels};print(cc,n,kind,{k:round(x/m['base'],4)for k,x in m.items()},flush=True);(D/'compact_raw.json').write_text(json.dumps(raw))
