# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,os,json,hashlib,fcntl
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_scc_speed_20261103');rows=[]
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for skip in [False,True]:
   for test in ['scc_acl_api_test','new_scc_two_sat_reference_test','new_graph_allocation_test']:
    exe=D/f'test_{cc}_{int(skip)}_{test}';cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-DSIRKIT_DISABLE_SIMD']+(['-DSKIP_RUNTIME_CHECKS']if skip else [])
    if test!='new_graph_allocation_test':cmd+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
    if test in ['scc_acl_api_test','scc_index_paths_test','scc_condensation_test']:cmd+=['-Wall','-Wextra','-Werror']
    cmd+=[str(R/f'Verify/current/tests/{test}.cpp'),'-o',str(exe)]
    p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,(test,p.stderr)
    p=subprocess.run(['taskset','-c','4',str(exe)],capture_output=True,text=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'})
    rows.append(dict(compiler=cc,skip=skip,test=test,command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,test_sha256=hashlib.sha256((R/f'Verify/current/tests/{test}.cpp').read_bytes()).hexdigest()))
    (D/'order_checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,skip,test,p.returncode,p.stdout.strip(),flush=True);assert p.returncode==0 and not p.stderr,p.stderr
