# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,random,statistics,shutil,fcntl
D=Path('/tmp/sirkit_scc_speed_20261103');rng=random.Random(141130);raw=[]
tasks=[]
for n,reps in [(32,20000),(4096,150),(500000,3)]:
 for kind in ['empty','line','cycle','dag','random','paired']:
  for mode in ['build','scc']:tasks.append((n,kind,mode,reps))
for n,reps in [(4096,100),(500000,2)]:
 for kind in ['line','random']:tasks.append((n,kind,'constructor',reps))
 for kind in ['line','random','paired']:tasks.append((n,kind,'condensation',reps))
for n,reps in [(32,20000),(4096,150),(250000,3)]:
 for kind in ['empty','line','random']:tasks.append((n,kind,'sat',reps))
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for label in ['base','group']:
   src='before' if label=='base' else label
   subprocess.run(['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror','-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_SCC_BENCH_SOURCE="{D/(src+".hpp")}"',str(D/'micro.cpp'),'-o',str(D/f'micro_{cc}_{label}')],check=True)
 print('MICRO BUILT',flush=True)
 for cc in ['gcc','clang']:
  for n,kind,mode,reps in tasks:
   for rep in range(7):
    labels=['base','control','group'];rng.shuffle(labels)
    for label in labels:
     shutil.copyfile(D/f'micro_{cc}_{"base"if label=="control"else label}',D/'micro_active');(D/'micro_active').chmod(0o700)
     p=subprocess.run(['taskset','-c','12',str(D/'micro_active'),str(n),kind,mode,str(reps)],capture_output=True,text=True,check=True);cpu,checksum=map(int,p.stdout.split());raw.append(dict(compiler=cc,n=n,kind=kind,mode=mode,repetitions=reps,rep=rep,label=label,cpu_ns=cpu,checksum=checksum))
   rr=[r for r in raw if (r['compiler'],r['n'],r['kind'],r['mode'])==(cc,n,kind,mode)];assert len({r['checksum']for r in rr})==1;m={l:statistics.median(r['cpu_ns']for r in rr if r['label']==l)for l in labels};print(cc,n,kind,mode,{k:round(x/m['base'],4)for k,x in m.items()},flush=True);(D/'micro_raw.json').write_text(json.dumps(raw))
