# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,hashlib,json,random
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_scc_speed_20261103');src=(D/'before.hpp').read_text();meta=[]
for name in ['random','max_random','large_cycle']:
 p=D/'official_generator'/f'{name}.cpp';exe=p.with_suffix('');subprocess.run(['/usr/bin/g++','-std=c++23','-O2',str(p),'-o',str(exe)],check=True)
 for seed in range(1 if name=='large_cycle' else 5):
  f=D/f'official_{name}_{seed}.in'
  with f.open('wb') as out:subprocess.run([str(exe),str(seed)],stdout=out,check=True)
  meta.append(dict(name=f.stem,path=str(f),header=f.read_text().splitlines()[0],sha256=hashlib.sha256(f.read_bytes()).hexdigest(),source=f'https://raw.githubusercontent.com/yosupo06/library-checker-problems/master/graph/scc/gen/{name}.cpp',seed=seed))
for n in [32,4096,500000]:
 for kind in ['empty','line','cycle','star','dag','paired']:
  if kind=='empty':edges=[]
  elif kind in ['line','cycle']:edges=[(i-1,i) for i in range(1,n)]+([(n-1,0)] if kind=='cycle' else [])
  elif kind=='star':edges=[(0,i)for i in range(1,n)]
  elif kind=='dag':
   r=random.Random(9296+n);edges=[]
   for i in range(2*n):
    u,v=r.randrange(n),r.randrange(n)
    if u>v:u,v=v,u
    edges.append((u,v))
  else:edges=[(i,i^1)for i in range(n)]
  f=D/f'custom_{n}_{kind}.in'
  with f.open('w') as out:
   out.write(f'{n} {len(edges)}\n');out.writelines(f'{u} {v}\n'for u,v in edges)
  meta.append(dict(name=f.stem,path=str(f),header=f'{n} {len(edges)}',sha256=hashlib.sha256(f.read_bytes()).hexdigest(),source='own fixture generator'))
(D/'fixtures.json').write_text(json.dumps(meta,indent=2)+'\n')
mark=src.replace('    std::vector<unsigned char> active(n);\n','').replace('        active[root] = 1; ','        ').replace('                    active[u] = 1; ','                    ').replace('} else if (active[u]) low[v]', '} else low[v]').replace('                    active[u] = 0; ids[u] = count;', '                    entered[u] = n; ids[u] = count;')
(D/'mark.hpp').write_text(mark)
merged=mark.replace('low(n), ids(n),','ids(n),').replace('low[','ids[')
merged=merged.replace('            dfs.pop_back();\n            if (ids[v] == entered[v])', '            dfs.pop_back();\n            const int child_low = ids[v];\n            if (child_low == entered[v])').replace('ids[parent], ids[v]', 'ids[parent], child_low')
(D/'merged.hpp').write_text(merged)
for label in ['base','mark','merged']:
 text=src if label=='base' else (D/f'{label}.hpp').read_text()
 io=(R/'Verify/current/common/fast_io.hpp').read_text();driver=(D/'driver.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"',io)
 (D/f'{label}.cpp').write_text('#define SKIP_RUNTIME_CHECKS\n'+text+'\n'+driver)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  subprocess.run(['taskset','-c','4',*args,'-std=c++23','-O2',str(D/f'{label}.cpp'),'-o',str(D/f'{cc}_{label}')],check=True)
print('fixtures and base/mark/merged compiled',flush=True)
