// SPDX-License-Identifier: CC0-1.0
// 参考（2-SATの問題分類）: https://nyaannyaan.github.io/library/math/two-sat.hpp
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/two_sat.md
//
// API一覧
// TwoSAT(n=0): n個のbool変数。変数番号[0,n)。O(1)準備。n<=INT_MAX/2。
// add_clause(i,a,j,b): (x_i==a)または(x_j==b)という節を追加。償却O(1)。解を無効化する。
// imply(i,a,j,b): (x_i==a)なら(x_j==b)。force(i,a): x_i==aを強制。償却O(1)。
// add_xor(i,j,different=true): 2変数の値が異なる/等しいという制約。償却O(1)。
// reserve_clauses(m): m節分の領域を確保。size()/clause_count(): 変数数/内部2リテラル節数。O(1)。
// solve(): 充足可能ならtrue。反復SCCでO(n+m)時間・追加領域。追加後は再実行する。
// answer(): 最後のsolve成功時の0/1 byte配列へのconst参照。value(i): そのbool値。O(1)。
// reset(n=0): 制約を捨てn変数へ。swap(other): O(1)。コピーは独立所有、ムーブ元は空の未解決状態。
// 入力検査はSKIP_RUNTIME_CHECKSで除く。answer/valueは最後のsolveがtrueであることが前提。

#include <algorithm>
#include <cstddef>
#include <limits>
#include <stdexcept>
#include <utility>
#include <vector>

#ifndef SIRKIT_SCC_DETAIL_DEFINED
#define SIRKIT_SCC_DETAIL_DEFINED
namespace reinsirk::detail {
inline std::pair<int, std::vector<int>> directed_component_ids(
        int n, const std::vector<std::pair<int, int>>& edges) {
    std::vector<std::size_t> begin(static_cast<std::size_t>(n) + 1);
    for (auto [u, v] : edges) { (void)v; ++begin[static_cast<std::size_t>(u) + 1]; }
    for (int v = 0; v < n; ++v) begin[v + 1] += begin[v];
    std::vector<std::size_t> next(begin.begin(), begin.end() - 1);
    std::vector<int> destination(edges.size());
    for (auto [u, v] : edges) destination[next[u]++] = v;
    std::copy_n(begin.begin(), n, next.begin());
    std::vector<int> entered(n, -1), low(n), ids(n), dfs, pending;
    std::vector<unsigned char> active(n);
    dfs.reserve(n); pending.reserve(n);
    int clock = 0, count = 0;
    for (int root = 0; root < n; ++root) {
        if (entered[root] != -1) continue;
        entered[root] = low[root] = clock++;
        active[root] = 1; dfs.push_back(root); pending.push_back(root);
        while (!dfs.empty()) {
            const int v = dfs.back();
            if (next[v] != begin[v + 1]) {
                const int u = destination[next[v]++];
                if (entered[u] == -1) {
                    entered[u] = low[u] = clock++;
                    active[u] = 1; dfs.push_back(u); pending.push_back(u);
                } else if (active[u]) low[v] = std::min(low[v], entered[u]);
                continue;
            }
            dfs.pop_back();
            if (low[v] == entered[v]) {
                for (;;) {
                    const int u = pending.back(); pending.pop_back();
                    active[u] = 0; ids[u] = count;
                    if (u == v) break;
                }
                ++count;
            }
            if (!dfs.empty()) {
                const int parent = dfs.back();
                low[parent] = std::min(low[parent], low[v]);
            }
        }
    }
    for (auto& id : ids) id = count - 1 - id;
    return {count, std::move(ids)};
}
}
#endif

#ifndef SIRKIT_TWO_SAT_DEFINED
#define SIRKIT_TWO_SAT_DEFINED
class TwoSAT {
    int n_ = 0;
    std::vector<std::pair<int, int>> implications_;
    std::vector<unsigned char> answer_;
#ifndef SKIP_RUNTIME_CHECKS
    bool solved_ = false, satisfiable_ = false;
    void variable(int i) const {
        if (i < 0 || i >= n_) throw std::out_of_range("TwoSAT: variable out of range");
    }
    void require_answer() const {
        if (!solved_ || !satisfiable_) throw std::logic_error("TwoSAT: no current satisfying assignment");
    }
#endif
    void room(std::size_t extra) {
        const auto maximum = implications_.max_size(), current = implications_.size();
        if (extra > maximum - current) throw std::length_error("TwoSAT: too many clauses");
        if (implications_.capacity() - current >= extra) return;
        const auto capacity = implications_.capacity();
        const auto grown = capacity <= maximum / 2 ? capacity * 2 : maximum;
        implications_.reserve(std::max(current + extra, std::max(std::min(std::size_t{4}, maximum), grown)));
    }
    void invalidate() noexcept {
#ifndef SKIP_RUNTIME_CHECKS
        solved_ = satisfiable_ = false;
#endif
    }
public:
    explicit TwoSAT(int n = 0) : n_(n) {
        if (n < 0 || n > std::numeric_limits<int>::max() / 2) throw std::length_error("TwoSAT: invalid variable count");
    }
    TwoSAT(const TwoSAT&) = default;
    TwoSAT(TwoSAT&& other) noexcept { swap(other); }
    TwoSAT& operator=(TwoSAT other) noexcept { swap(other); return *this; }
    void swap(TwoSAT& other) noexcept {
        std::swap(n_, other.n_); implications_.swap(other.implications_); answer_.swap(other.answer_);
#ifndef SKIP_RUNTIME_CHECKS
        std::swap(solved_, other.solved_); std::swap(satisfiable_, other.satisfiable_);
#endif
    }
    void reset(int n = 0) { TwoSAT replacement(n); swap(replacement); }
    int size() const noexcept { return n_; }
    std::size_t clause_count() const noexcept { return implications_.size() / 2; }
    void reserve_clauses(std::size_t count) {
        if (count > implications_.max_size() / 2) throw std::length_error("TwoSAT: too many clauses");
        implications_.reserve(count * 2);
    }
    void add_clause(int i, bool a, int j, bool b) {
#ifndef SKIP_RUNTIME_CHECKS
        variable(i); variable(j);
#endif
        room(2);
        implications_.emplace_back(2 * i + !a, 2 * j + b);
        implications_.emplace_back(2 * j + !b, 2 * i + a);
        invalidate();
    }
    void imply(int i, bool a, int j, bool b) { add_clause(i, !a, j, b); }
    void force(int i, bool a) { add_clause(i, a, i, a); }
    void add_xor(int i, int j, bool different = true) {
#ifndef SKIP_RUNTIME_CHECKS
        variable(i); variable(j);
#endif
        room(4);
        add_clause(i, true, j, different);
        add_clause(i, false, j, !different);
    }
    bool solve() {
        const auto components = reinsirk::detail::directed_component_ids(2 * n_, implications_);
        const auto& ids = components.second;
        for (int i = 0; i < n_; ++i) if (ids[2 * i] == ids[2 * i + 1]) {
            answer_.clear();
#ifndef SKIP_RUNTIME_CHECKS
            solved_ = true; satisfiable_ = false;
#endif
            return false;
        }
        std::vector<unsigned char> result(n_);
        for (int i = 0; i < n_; ++i) result[i] = ids[2 * i] < ids[2 * i + 1];
        answer_.swap(result);
#ifndef SKIP_RUNTIME_CHECKS
        solved_ = satisfiable_ = true;
#endif
        return true;
    }
    const std::vector<unsigned char>& answer() const {
#ifndef SKIP_RUNTIME_CHECKS
        require_answer();
#endif
        return answer_;
    }
    bool value(int i) const {
#ifndef SKIP_RUNTIME_CHECKS
        require_answer(); variable(i);
#endif
        return answer_[i] != 0;
    }
};
#endif
