// SPDX-License-Identifier: CC0-1.0
#include "Verify/current/common/fast_io.hpp"
#include <vector>
int main(){
    int n,q;verify_in>>n>>q;std::vector<std::vector<int>> graph(n);
    std::vector<int> parent(n),degree(n);
    for(int i=1;i<n;++i){verify_in>>parent[i];++degree[parent[i]];++degree[i];}
    for(int v=0;v<n;++v)graph[v].reserve(degree[v]);
    for(int i=1;i<n;++i){graph[parent[i]].push_back(i);graph[i].push_back(parent[i]);}
    LCA lca(graph);
    while(q--){int u,v;verify_in>>u>>v;verify_out<<lca.get(u,v)<<'\n';}
}
