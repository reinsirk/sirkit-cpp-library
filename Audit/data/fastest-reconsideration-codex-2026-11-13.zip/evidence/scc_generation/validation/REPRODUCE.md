# SCC同期後の限定検証

通常scc 8構成、Variants 8構成、Fast 4構成、local相当8構成を確認。
GCC15.2/Clang21、checked/skip、通常/標準fallbackを使用。
Fastは生成時に本体検査が除去済みのため、skip有効入力契約のみ。

p.collect()にGraph/SCC.cppを使うlocal entryは無く、sccだけだった。
local相当には既存 `Verify/current/tests/scc_acl_api_test.cpp` を使った。
このfixtureはn≤28、到達可能性の独立参照、ACL API型、scc/build/ids、
追加辺後の再構築、返却値の独立性、コピー/ムーブを検査する。
各実行のcheck数は1,751,857。TwoSATと30万頂点を含む大規模fixtureは再実行しない。

通常版は `Scripts/ci_verify.py --id scc --skip-sync` をcompiler/fallback別に実行。
rootの同期完了後なのでpackage同期確認だけを省略し、prepare(check=True)は残した。
派生は既存Dijkstra/LCA限定helperを再利用し、現在profile manifestのscc 4件だけを対象にした。
checkedは同じprofile body/driverで再renderし、skipのrenderは生成済み全文とbyte一致を確認。
全sampleは現在のSCC checkerで照合。

`results.json` に環境、全コマンド、SHA、結果、rootのsource/manifest前後不変を保存。
`raw/` に通常ci結果と派生/localのビルド診断・sample出力。
`sources/` に通常と派生のchecked/skip全文、およびlocal fixtureと本体を凍結。

```sh
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/scc_generation/validation/validate.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/scc_generation/validation/freeze_normal.py
```

CPU10に固定。リポジトリ・ZIP・判定記録を変更せず、オンライン提出はしない。
