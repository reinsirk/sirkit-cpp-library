# Reproduction

All commands below operate in `/tmp/sirkit_fastest_review_20261113/lca_hld/`. Program and input SHA values are in `review.json`, the API snapshots, and `measurements/`. Public submissions are immutable snapshots; no login is needed to read them.

The scripts use `/usr/bin/g++` 15.2, CPU10 and an unlimited stack for every variant. Do not run concurrent measurements on CPU10. The main benchmark skips a problem if its result JSON already exists; preserve existing evidence and use a separate result copy for a fresh measurement.

```sh
python3 build_experiments.py
python3 generate_inputs.py
python3 benchmark.py
python3 jump_extra.py
python3 extra_benchmark.py
/usr/bin/g++ -std=c++23 -O2 official_gen/generate.cpp -o official_gen/generate
official_gen/generate 0 > inputs/composite_official_worst_00.in
official_gen/generate 1 > inputs/composite_official_worst_01.in
python3 official_worst_benchmark.py
python3 finalize_report.py
```

`official_gen/gen/worst_for_path_decomposition.cpp` and `random.h` are archived official generator inputs. `official_gen/params.h` contains the published `N_AND_Q_MAX=200000`, `MOD=998244353`. The wrapper includes standard headers. Generated input/output SHA values match `composite_official_hashes.json` for both official worst cases.

Normalization removes source `#pragma GCC optimize(...)` declarations and compiles the matched variants with `-std=c++23 -O2 -DNDEBUG -Wall -Wextra`. `best_original` keeps the original source pragma. Targeted Jump variants disclose the original explicit CPU target; scalar/common-IO variants remove it. Regular file stdin is required by third-party mmap readers. Numeric outputs are compared as tokens because their whitespace formats differ.

The root-prefix sum experiment retains the own HLD/Fenwick APIs but uses another algorithm. It is a comparison reference, not a replacement verification of `path_prod`. The LCA ladder omission is deliberately API-incomplete and must not be adopted. All experimental derivatives remain in this temporary directory.
