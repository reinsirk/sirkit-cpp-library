# LCA/HLD と Fastest の比較

最新5提出はすべてAC。公式公開v3 APIの時間順AC一覧からFastestを取得した。現行生成コードとの違いは改行と`// Submission:`のURLだけだった。

| Verify | 自分 | Fastest | 倍率 | Fastest提出日 |
|---|---:|---:|---:|---|
| [lca](https://judge.yosupo.jp/submission/416743) | 113 ms | [24 ms](https://judge.yosupo.jp/submission/278239) | 4.71 | 2025-04-09 |
| [hld_jump](https://judge.yosupo.jp/submission/416738) | 200 ms | [56 ms](https://judge.yosupo.jp/submission/403437) | 3.57 | 2026-09-17 |
| [hld_path_prod](https://judge.yosupo.jp/submission/416740) | 251 ms | [100 ms](https://judge.yosupo.jp/submission/278241) | 2.51 | 2025-04-09 |
| [hld_vertex_add_path_sum](https://judge.yosupo.jp/submission/416741) | 281 ms | [100 ms](https://judge.yosupo.jp/submission/278241) | 2.81 | 2025-04-09 |
| [hld_path_composite](https://judge.yosupo.jp/submission/416739) | 241 ms | [116 ms](https://judge.yosupo.jp/submission/319096) | 2.08 | 2025-10-07 |

APIの現在の`cpp`はGCC15.2/C++23だが、古い提出時のコンパイラ版はAPIにない。最速側にはOfastや固定ISAもあるため、順位の時間をそのまま本体比較には使わない。

## LCA：汎用構築・配置・I/Oの複合差

単純なO(log N)対O(1)ではない。自分の`get`は有界な浅い木のliftingと、深い木の32点RMQを使う。Fastestは問題の`p_i<i`、`u<v`を利用し、親配列から隣接表を作らず構築する。森・部分木・level ancestor等の機能も持たない。

GCC15.2/O2に正規化した50万頂点・50万random照会では、自分114.4ms、自分の本体/mainのまま最速I/Oへ交換98.1ms、最速の本体/mainを自分I/Oへ交換40.9ms、最速全体20.5msだった。I/O以外の差が残る。

自分の計測用版は、入力＋隣接表25.2ms、本体構築42.0ms、照会＋I/O40.5ms。常時RMQを選ぶ本体候補は132.7msへ悪化した。lineで未使用ladderを外すと約10%改善したが、ancestor APIを壊すため採用不可。親配列入力に合う構築経路や配置が検討対象になる。

## Jump：別indexと入出力のbulk処理

最速は16byteの頂点情報、XOR次数による木の構築、micro/macroの祖先情報、AVX2/BMI2、64件bulk入出力、8件先のprefetchを組み合わせる。

同じ自分I/O・GCC15.2/O2でも、最速scalar indexはrandom98.1ms対HLD204.1ms、binary90.0ms対154.1ms。lineは75.3ms対81.9msと差が小さい。

最速プログラム内の分離実験では、prefetchを外すと約6〜15%遅くなった。prefetchなし・同じISA/I/Oでscalar kernelへ戻す差は約-1〜8%。64件bulkを単発処理へ戻すと約30〜59%遅くなった。SIMDだけで全差を説明することはできない。

## Path Sum：別の代数的アルゴリズムと実装定数

最速は「部分木の両端更新＋根からの累積和＋LCA」。HLDの区間和分割とは別のO(log N)アルゴリズムで、Fenwickの内容も異なる。

randomではowned257.6ms、callback277.6msに対し、最速を自分I/Oへ交換しても138.8msだった。ただしlineでは自分98.3/96.5msに対して106.4msとなり逆転する。

同じ自分HLD/Fenwick/I/OでEuler根和の式だけを独立実装した比較は、random263.3ms、binary195.7ms、line131.6ms。計算量を変えるだけで常勝にはならず、LCA・構築・配列アクセスの定数も大きい。

`.range()`がDFS順の元の頂点値を返す契約は維持する。根和の差分へ内部を置換せず、別アルゴリズムとして設計を検討する必要がある。

## Composite：公式の最悪形状で構造差を確認

最速は重鎖と補助平衡木を融合し、アフィンの順方向・逆方向集約を共有する。一般のHLD区間ごとに独立したSegmentTree照会を呼ぶ構成とは異なる。

公式`worst_for_path_decomposition`のseed0/1を再生成し、入力SHAと自分の出力SHAが公式`hash.json`に一致した。同じGCC15.2/O2で次の結果になった。

| 変種 | 00 | 01 |
|---|---:|---:|
| 自分 | 205.6 ms | 208.4 ms |
| 自分本体/main＋最速I/O | 191.4 ms | 197.5 ms |
| 最速本体/main＋自分I/O | 129.4 ms | 133.0 ms |
| 最速全体 | 113.3 ms | 114.2 ms |

最悪形状ではI/O交換だけの改善は約5〜7%。同じI/Oでも最速構造は約36〜37%短く、構造と集約実装の差が支配的だった。一方、通常randomでの本体差は小さく、lineは自分46.3msに対して最速＋自分I/O66.3msとなった。

## 再現資料

`review.json`にURL・ソースSHA・ケース別時間・分類・計測条件を保存。`programs/`は比較専用の派生版、`measurements/`は全測定、各Pythonスクリプトが再現手順に当たる。第三者コードはリポジトリへ移していない。

大規模測定はCPU10、GCC15.2、O2、NDEBUG、同一入力で交互に実行。通常の大規模比較は2回準備＋7回計測、Jump分離と公式最悪ケースは2回準備＋9回計測。全変種の出力tokenが一致し、小規模は独立した素朴モデルとも一致した。別ブロック間では絶対時間が変動するため、同じブロック内の比で判断する。
