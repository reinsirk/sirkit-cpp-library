# LCA同期後の限定検証

通常lca 8構成、Variants 8構成、Fast 4構成、通常lca_local 8構成、計28構成・28 sampleが全PASS。
GCC15.2/Clang21、checked/skip、通常/標準fallbackを使用。
Fastは生成時に本体検査が除去済みのため、skip有効入力契約のみで検証した。
lca_localは80個の小森を扱う既存local sampleであり、大規模full独立試験は再実行していない。

通常版は `Scripts/ci_verify.py --id lca --id lca_local --skip-sync` をcompiler/fallback別に実行。
同期チェックはrootで実施済み。ci内のprepare(check=True)は省かず、書込み・生成は行わない。
派生は既存Dijkstra検証helperを再利用し、現在profile manifestの4件に限定。
checkedは同じprofile body/driverから再renderし、skipのrenderは現在生成済み全文とbyte一致を確認。
全sampleは現在のprepare_verify.matchesで照合。

`results.json` に環境、全コマンド、SHA、結果、profile生成物とmetadataの前後不変を保存。
`raw/` に通常ci結果と派生のビルド診断/sample出力。
`sources/` に通常と派生の実際のchecked/skip全文を凍結した。

再現:
`PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/lca_generation/validation/validate.py`

CPU10に固定。リポジトリ・ZIP・判定記録を変更せず、オンライン提出はしない。
