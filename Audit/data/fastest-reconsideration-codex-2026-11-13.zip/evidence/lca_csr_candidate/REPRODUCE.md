# LCAの汎用辺列adapter候補

採用判断は親が行う。この作業は全て/tmpで実施し、repo/生成物/Fable snapshotは未変更。

## 採用候補

最終候補は `clean_ref/`。

- `candidate_library.cpp` / `library.diff`: `LCA(int,span<const pair<int,int>>,root)` と同引数のbuild。
- `candidate_main.cpp` / `main.diff`: 入力parentをpair列へ読み、新APIを呼ぶだけ。
- `document_candidate.md` / `document.diff`: 53行2796字。span型、検査、負のn、構築領域、所有権を説明。
- `example_candidate.cpp` / `example.diff`: 最初の構築を辺列へ変更。既存隣接リストbuild例も保持。
- `lca_edge_list_test.cpp`: CI向け軽量独立参照。GCC/Clang checked/skipで約21万項目、約3〜5ms。
- `csr_allocation_test.cpp`: 新constructor/buildの確保失敗、漏れ、元とコピーの保持を確認。

内部CSRはunique_ptr<int[]>で辺を所有し、vector<span<const int>>で各行を参照する。
入力の辺spanは保持しない。各無向辺を1回渡し、端点の向き・順序は任意。
既存グラフ版の検査・例外・全照会・コピー/ムーブ契約を保持した。
新APIだけ構築時の全端点検査を済ませ、その後の既存DFSで重複検査を省く。
負のn、内部容量上限はSKIPでも維持。CSRにO(N+M)時間・一時領域を追加し、前処理後に破棄する。

## 同じ条件の比較

CPU10、GCC15.2/Clang21、C++23 -O2 -Wall -Wextra。現在のentry内GCC O3 pragmaを両者に維持し、Clangは無視。
SKIP、mainの入出力、照会ループは同じ。2 warmup+9回交互、出力はbyte単位一致。
全体時間の比較であり、LCA照会の新アルゴリズムや共通I/Oの成果とはしない。

最終const参照版の公式4入力で、候補/現行はGCC .669〜.815、Clang .746〜.855。
各ケースのpeak RSSは約15MiB減。小入力は起動時間込みで同等。
公式genのmax_random_01/max_line_00/binary_00/almost_line_01を再現し、全入力・出力SHAが公式hash.jsonと一致。
取得URL・生成器/入力hashは `official/generation.json`。

初回は通常版、同じ旧API/mainを使うadapter版、新CSR main、グラフを照会前に解放するだけの旧API対照を測った。
adapter旧APIには一貫した回帰がなく、グラフ解放だけではCSRの利益を再現しなかった。
最終const参照版の旧APIバイナリは初回adapter測定版とbyte一致。`clean_ref/binary_equivalence.json` を参照。
CSR側はconst参照変更でコード生成が変わったので、最終ソースで全ケースを再測定した。

## 検証と原データ

- `review.json`: 最終採否提案、API/検査/領域、全path/SHA、ケース要約。
- `results.json`: 初回4対照。全サンプルとRSS。
- `clean_ref/results.json`: 最終2対照。両compiler×公式4+独立4入力、全サンプルとRSS。
- `clean_ref/test_results.json`: full20構成、367,292,224項目。小森全列挙、任意根、所有権、30万頂点3形状、深い分岐66ケース。
- `clean_ref/final_test_results.json`: 軽量CI8構成、Clang ASan+UBSan checked/skip、Example2 compiler。
- `clean_ref/allocation_results.json`: 4構成×44確保失敗点、各149照合、live allocation差0。

full参照の完了後に最終APIコメントだけを拡充した。最終ソースで軽量参照・sanitizer・Example・全性能ケースを再実行した。
GCCの提出mainではvalid-input前提の抽出により未初期化の可能性の警告が出る（baselineにもある）。
新ライブラリのrange-forコピー警告は解消した。既存deep fixtureの自己代入/字下げ警告は原データへ残す。

```sh
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/lca_csr_candidate/clean_ref/test.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/lca_csr_candidate/clean_ref/final_check.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/lca_csr_candidate/clean_ref/benchmark.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/lca_csr_candidate/finalize.py
```

計時はCPU10で一度に1件。初回rawを保持する場合は再実行前にresultsを別名へ保存する。
`prepare.py` は初回試作生成器なので、完成済み最終候補を上書きしないこと。
CIへ置く場合、light testの既定includeはVerify/current/testsからGraph/LCA.cppへの相対位置。
/tmpで単体buildする場合は `-DSIRKIT_LCA_SOURCE="/tmp/sirkit_fastest_review_20261113/lca_csr_candidate/clean_ref/candidate_library.cpp"` を渡す。
