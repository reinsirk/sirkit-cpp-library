# 採用後LCAのGCC設定確認

結論: 現行 `gcc_optimization: O3` を維持する。repo設定は変更しない。

採用後の本体・mainは `clean_ref` 最終候補とbyte一致を確認した。
公式 max_random_01 / max_line_00 / binary_00 / almost_line_01を用い、
GCC15.2 `/usr/bin/g++ -std=c++23 -O2 -Wall -Wextra` で生成pragmaなし・O3・O3,unroll-loopsを比較した。
CLIの-O2は全設定で共通。pragma以外を除いたソースframe SHAが3設定で一致する。
CPU10で2 warmup+7回ずつ、順序を反転・回転して交互実行。12組全て公式出力SHAと一致した。

|ケース|pragmaなし / O3|unroll / O3|
|---|---:|---:|
|max_random_01|1.057|1.007|
|max_line_00|1.050|1.028|
|binary_00|0.990|1.007|
|almost_line_01|1.031|0.989|

pragmaなしは3ケースで約3〜6%遅く、unrollにも一貫した改善がない。
1%前後の差について、7回だけで有意差とは主張しない。
全4ケースの幾何平均はpragmaなし1.032、unroll1.008。現行変更の根拠はない。

`results.json` に全時間サンプル、公式入力・出力SHA、body/main/IO/source/frame/compilerの条件を保存。
`recommendations.json` は採否、`sources/` は実際の提出全文。
`PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/lca_csr_candidate/compiler_settings/benchmark.py`
で再現できる。CPU10に他の計時を同時実行しない。
