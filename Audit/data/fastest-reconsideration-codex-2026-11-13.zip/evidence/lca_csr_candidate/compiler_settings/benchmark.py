from pathlib import Path
import copy,datetime,hashlib,json,math,os,re,statistics,subprocess,sys,time
R=Path('/home/reinsirk/Atcoder_Env');P=Path('/tmp/sirkit_fastest_review_20261113/lca_csr_candidate');C=P/'clean_ref';W=P/'compiler_settings';sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
os.sched_setaffinity(0,{10});sha=lambda data:hashlib.sha256(data).hexdigest();flags=['-std=c++23','-O2','-Wall','-Wextra'];version=subprocess.check_output(['/usr/bin/g++','--version'],text=True);assert '15.2.0' in version
body=(R/'Graph/LCA.cpp').read_bytes();driver=(R/'Verify/current/drivers/lca_main.cpp').read_text();io=(R/'Verify/current/common/fast_io.hpp').read_bytes();assert body==(C/'candidate_library.cpp').read_bytes();assert driver==(C/'candidate_main.cpp').read_text();entry=next(e for e in pv.collect()if e['id']=='lca');entry.pop('gcc_optimization',None);caseinfo=[r['input']for r in json.loads((C/'results.json').read_text())['results']if r['compiler']=='GCC'and r['input']['official']];assert len(caseinfo)==4
for d in ['sources','bin']:(W/d).mkdir(exist_ok=True)
report={'format':1,'status':'running','cpu':10,'compiler':version,'flags':flags,'baseline_setting':'O3','body_sha256':sha(body),'driver_sha256':sha(driver.encode()),'io_sha256':sha(io),'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'actual generated GCC-only pragmas; external -O2 common; 2 warmup +7 measured, order alternated and rotated; all output SHA matches official','programs':{},'cases':[]};frames=set();binaries={}
for name,setting in [('none',None),('O3','O3'),('O3_unroll','O3,unroll-loops')]:
 e=copy.deepcopy(entry)
 if setting:e['gcc_optimization']=setting
 data,_=pv.render(e,source_overrides={'Graph/LCA.cpp':body},driver_override=driver,skip_runtime_checks=True);source=W/'sources'/(name+'.cpp');source.write_bytes(data);frame=re.sub(rb'^#if defined\(__GNUC__\) && !defined\(__clang__\)\n#pragma GCC optimize\([^\n]*\)\n#endif\n',b'',data,flags=re.M);frames.add(sha(frame));binary=W/'bin'/name;cmd=['/usr/bin/g++',*flags,str(source),'-o',str(binary)];r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);assert r.returncode==0,r.stderr;binaries[name]=binary;report['programs'][name]={'setting':setting,'source':str(source),'source_sha256':sha(data),'frame_sha256':sha(frame),'command':cmd,'binary_sha256':sha(binary.read_bytes()),'diagnostics':r.stderr}
assert len(frames)==1;report['same_body_main_io_and_frame']=True
for info in caseinfo:
 path=Path(info['path']);assert sha(path.read_bytes())==info['input_sha256'];outputs={}
 for name,exe in binaries.items():
  with path.open('rb')as f:r=subprocess.run([str(exe)],stdin=f,capture_output=True,check=True,timeout=60)
  outputs[name]=sha(r.stdout);assert outputs[name]==info['official_output_sha256'],(path,name,'official output differs')
 samples={n:[]for n in binaries};names=list(binaries)
 for iteration in range(9):
  order=names if iteration%2==0 else names[::-1];shift=(iteration//2)%len(order);order=order[shift:]+order[:shift]
  for name in order:
   with path.open('rb')as f:
    t=time.perf_counter_ns();subprocess.run([str(binaries[name])],stdin=f,stdout=subprocess.DEVNULL,check=True);ms=(time.perf_counter_ns()-t)/1e6
   if iteration>=2:samples[name].append(ms)
 med={n:statistics.median(v)for n,v in samples.items()};paired={n:[v/b for v,b in zip(samples[n],samples['O3'])]for n in names};row={'case':path.stem,'input':info,'output_sha256':outputs,'all_outputs_official_match':True,'samples_ms':samples,'median_ms':med,'ratio_to_O3':{n:v/med['O3']for n,v in med.items()},'paired_median_ratio_to_O3':{n:statistics.median(v)for n,v in paired.items()},'paired_wins_out_of_7':{n:sum(x<1 for x in v)for n,v in paired.items()},'warmup':2,'measured':7};report['cases'].append(row);(W/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(path.stem,med,row['ratio_to_O3'],row['paired_wins_out_of_7'],flush=True)
report['geomean_ratio_to_O3']={n:math.exp(statistics.mean(math.log(r['ratio_to_O3'][n])for r in report['cases']))for n in names};report['source_files_unchanged_after']={'body':sha((R/'Graph/LCA.cpp').read_bytes())==report['body_sha256'],'driver':sha((R/'Verify/current/drivers/lca_main.cpp').read_bytes())==report['driver_sha256'],'io':sha((R/'Verify/current/common/fast_io.hpp').read_bytes())==report['io_sha256']};assert all(report['source_files_unchanged_after'].values());report['status']='passed';report['completed_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/'results.json').write_text(json.dumps(report,indent=2)+'\n');print('FINAL',report['geomean_ratio_to_O3'],flush=True)
