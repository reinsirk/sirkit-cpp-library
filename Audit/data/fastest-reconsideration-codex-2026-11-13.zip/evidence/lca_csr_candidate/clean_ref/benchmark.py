from pathlib import Path
import hashlib,json,os,resource,statistics,subprocess,time,sys
R=Path('/home/reinsirk/Atcoder_Env');P=Path('/tmp/sirkit_fastest_review_20261113');W=P/'lca_csr_candidate/clean_ref';os.sched_setaffinity(0,{10});resource.setrlimit(resource.RLIMIT_STACK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY));sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
for d in ['inputs','bin','results']:(W/d).mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();official=json.loads((W/'official/hash.json').read_text());(W/'official/params.h').write_text('constexpr int N_MIN=2,N_MAX=500000,Q_MIN=1,Q_MAX=500000;\n');cases=[];genmeta=[]
for name,seed in [('max_random',1),('max_line',0),('binary',0),('almost_line',1)]:
 src=W/'official/gen'/(name+'.cpp');exe=W/'official'/name;cmd=['/usr/bin/g++','-std=c++23','-O2',str(src),'-o',str(exe)];subprocess.run(cmd,check=True,capture_output=True,timeout=120);inp=W/'inputs'/f'{name}_{seed:02}.in'
 with inp.open('wb')as f:subprocess.run([str(exe),str(seed)],stdout=f,check=True,timeout=90)
 assert sha(inp.read_bytes())==official[inp.name],(name,'official input hash mismatch');cases.append({'path':str(inp),'official':True,'input_sha256':sha(inp.read_bytes()),'official_output_sha256':official[inp.with_suffix('.out').name]});genmeta.append({'name':name,'seed':seed,'source_url':'https://raw.githubusercontent.com/yosupo06/library-checker-problems/master/tree/lca/gen/'+src.name,'source_sha256':sha(src.read_bytes()),'compile_command':cmd,'input_sha256':sha(inp.read_bytes()),'official_hash_match':True})
for shape in ['small','random','line','binary']:
 p=P/'lca_hld/inputs'/f'lca_{shape}.in';cases.append({'path':str(p),'official':False,'small':shape=='small','input_sha256':sha(p.read_bytes())})
(W/'official/generation.json').write_text(json.dumps({'source_info_url':'https://raw.githubusercontent.com/yosupo06/library-checker-problems/master/tree/lca/info.toml','hash_url':'https://raw.githubusercontent.com/yosupo06/library-checker-problems/master/tree/lca/hash.json','random_source_url':'https://raw.githubusercontent.com/yosupo06/library-checker-problems/master/common/random.h','random_sha256':sha((W/'official/gen/random.h').read_bytes()),'hash_file_sha256':sha((W/'official/hash.json').read_bytes()),'generators':genmeta},indent=2)+'\n')
sources=json.loads((W/'sources.json').read_text());entry=sources['entry'];control='''// SPDX-License-Identifier: CC0-1.0
#include "Verify/current/common/fast_io.hpp"
#include <vector>
int main(){
 int n,q;verify_in>>n>>q;
 LCA lca=[&]{
  std::vector<std::vector<int>> graph(n);std::vector<int> parent(n),degree(n);
  for(int i=1;i<n;++i){verify_in>>parent[i];++degree[parent[i]];++degree[i];}
  for(int v=0;v<n;++v)graph[v].reserve(degree[v]);
  for(int i=1;i<n;++i){graph[parent[i]].push_back(i);graph[i].push_back(parent[i]);}
  return LCA(graph);
 }();
 while(q--){int u,v;verify_in>>u>>v;verify_out<<lca.get(u,v)<<'\\n';}
}
''';data,_=pv.render(entry,source_overrides={'Graph/LCA.cpp':(W/'baseline_library.cpp').read_bytes()},driver_override=control,skip_runtime_checks=True);(W/'baseline_release_graph.cpp').write_bytes(data);sources['programs']['baseline_release_graph']={'path':str(W/'baseline_release_graph.cpp'),'sha256':sha(data)};sources['memory_lifetime_control']='baseline_release_graph: unchanged body/API/graph construction, only destroy adjacency and parent/degree before queries';(W/'sources.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n')
sources['programs']={name:info for name,info in sources['programs'].items()if name in ['baseline','csr_program']}
report={'format':1,'status':'running','cpu':10,'flags':['-std=c++23','-O2','-Wall','-Wextra'],'source_metadata':sources,'cases':cases,'results':[],'notes':['Preserve actual current per-entry GCC pragma and SKIP setting. No whole-input I/O replacement.','Final const-reference source remeasurement. Existing-API/control effects remain in parent results.json and binary_equivalence.json; the old-API final binary was byte-identical.','2 warmup +9 interleaved measurements, order reversed/rotated; peak RSS from separate process. No online submissions.']};(W/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for label,command in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 binaries={};builds={}
 for name,info in sources['programs'].items():
  src=Path(info['path']);assert sha(src.read_bytes())==info['sha256'];exe=W/'bin'/f'{label}_{name}';cmd=[*command,*report['flags'],str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True,timeout=180);assert p.returncode==0,p.stderr;binaries[name]=exe;builds[name]={'command':cmd,'source_sha256':info['sha256'],'diagnostics':p.stderr}
 for case in cases:
  path=Path(case['path']);assert sha(path.read_bytes())==case['input_sha256'];ref=None;outsha={}
  for name,exe in binaries.items():
   with path.open('rb')as f:r=subprocess.run([str(exe)],stdin=f,capture_output=True,check=True,timeout=90)
   if ref is None:ref=r.stdout
   assert ref==r.stdout,(name,path,'output differs');outsha[name]=sha(r.stdout)
   if case['official']:assert outsha[name]==case['official_output_sha256'],(name,path,'official output differs')
   if case.get('small'):assert r.stdout.split()==path.with_suffix('.expected').read_bytes().split()
  names=list(binaries);samples={n:[]for n in names}
  for iteration in range(11):
   order=names if iteration%2==0 else names[::-1];shift=(iteration//2)%len(order);order=order[shift:]+order[:shift]
   for name in order:
    with path.open('rb')as f:
     t=time.perf_counter_ns();subprocess.run([str(binaries[name])],stdin=f,stdout=subprocess.DEVNULL,check=True);elapsed=(time.perf_counter_ns()-t)/1e6
    if iteration>=2:samples[name].append(elapsed)
  median={n:statistics.median(v)for n,v in samples.items()};rss={}
  for name,exe in binaries.items():
   raw=W/'results'/f'{label}_{path.stem}_{name}_rss.txt'
   with path.open('rb')as f:subprocess.run(['/usr/bin/time','-f','%M','-o',str(raw),str(exe)],stdin=f,stdout=subprocess.DEVNULL,check=True,timeout=90)
   rss[name]=int(raw.read_text())
  row={'compiler':label,'builds':builds,'input':case,'all_outputs_equal':True,'output_sha256':outsha,'median_ms':median,'ratio_to_baseline':{n:v/median['baseline']for n,v in median.items()},'samples_ms':samples,'warmup':2,'measured':9,'peak_rss_kib':rss};report['results'].append(row);(W/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(label,path.stem,{n:round(v,3)for n,v in row['ratio_to_baseline'].items()},rss,flush=True)
report['status']='passed';(W/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('FINAL PASS',len(report['results']),'compiler/input cases',flush=True)
