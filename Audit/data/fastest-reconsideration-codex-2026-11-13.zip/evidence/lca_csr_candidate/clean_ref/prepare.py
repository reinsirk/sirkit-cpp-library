from pathlib import Path
import difflib,hashlib,json,sys
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/lca_csr_candidate/clean_ref');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
source=(R/'Graph/LCA.cpp').read_text();(W/'baseline_library.cpp').write_text(source)
adapter='''#ifndef SIRKIT_LCA_CSR_GRAPH_DEFINED
#define SIRKIT_LCA_CSR_GRAPH_DEFINED
namespace reinsirk::detail {
class LcaCsrGraph {
    std::unique_ptr<int[]> arcs_;
    std::vector<std::span<const int>> rows_;
public:
    LcaCsrGraph(int n, std::span<const std::pair<int,int>> edges) {
        if (n < 0) throw std::length_error("LCA: negative vertex count");
        const auto count = static_cast<std::size_t>(n);
        if (count > rows_.max_size() || count >= std::vector<std::size_t>{}.max_size()
            || edges.size() > static_cast<std::size_t>(std::numeric_limits<std::ptrdiff_t>::max()) / (2 * sizeof(int)))
            throw std::length_error("LCA: CSR capacity exceeded");
        std::vector<std::size_t> begin(count + 1);
        for (const auto& [u,v] : edges) {
#ifndef SKIP_RUNTIME_CHECKS
            if (static_cast<unsigned>(u) >= static_cast<unsigned>(n)
                || static_cast<unsigned>(v) >= static_cast<unsigned>(n))
                throw std::out_of_range("LCA: endpoint out of range");
#endif
            ++begin[static_cast<std::size_t>(u) + 1];
            ++begin[static_cast<std::size_t>(v) + 1];
        }
        for (std::size_t i = 1; i <= count; ++i) begin[i] += begin[i-1];
        arcs_ = std::make_unique_for_overwrite<int[]>(std::max(std::size_t{1}, 2 * edges.size()));
        rows_.resize(count);
        for (std::size_t v = 0; v < count; ++v)
            rows_[v] = std::span<const int>(arcs_.get() + begin[v], begin[v+1] - begin[v]);
        for (const auto& [u,v] : edges) {
            arcs_[begin[u]++] = v;
            arcs_[begin[v]++] = u;
        }
    }
    LcaCsrGraph(const LcaCsrGraph&) = delete;
    LcaCsrGraph& operator=(const LcaCsrGraph&) = delete;
    std::size_t size() const noexcept { return rows_.size(); }
    std::span<const int> operator[](int v) const noexcept { return rows_[v]; }
};
}
#endif

'''
source=source.replace('#include <stdexcept>','#include <stdexcept>\n#include <span>')
a=source.index('#ifndef SIRKIT_LCA_LADDER_DEFINED');source=source[:a]+adapter+source[a:]
old='    void build_impl(const std::vector<std::vector<int>>& graph, int root) {';assert old in source;source=source.replace(old,'    template<class GraphLike, bool endpoints_validated = false>\n    void build_impl(const GraphLike& graph, int root) {')
old='''                    if (static_cast<unsigned int>(to) >= static_cast<unsigned int>(size_)) {
                        throw std::out_of_range("LCA: endpoint out of range");
                    }''';assert old in source;source=source.replace(old,'''                    if constexpr (!endpoints_validated) {
                        if (static_cast<unsigned int>(to) >= static_cast<unsigned int>(size_))
                            throw std::out_of_range("LCA: endpoint out of range");
                    }''')
needle='    LCA(const LCA& other)';assert needle in source;source=source.replace(needle,'''    LCA(int n, std::span<const std::pair<int,int>> edges, int root = 0) {
        reinsirk::detail::LcaCsrGraph graph(n, edges);
        build_impl<reinsirk::detail::LcaCsrGraph, true>(graph, root);
    }

'''+needle,1)
needle='    std::size_t size() const noexcept { return static_cast<std::size_t>(size_); }';assert needle in source;source=source.replace(needle,'''    void build(int n, std::span<const std::pair<int,int>> edges, int root = 0) {
        LCA replacement(n, edges, root);
        swap(replacement);
    }

'''+needle,1)
source=source.replace('// コピー後の再構築', '// LCA(n, edges, root=0)/build(n, edges, root=0): 無向辺pair列からCSR構築。全端点を構築時に検査。\n// コピー後の再構築',1)
(W/'candidate_library.cpp').write_text(source);(W/'library.diff').write_text(''.join(difflib.unified_diff((W/'baseline_library.cpp').read_text().splitlines(True),source.splitlines(True),fromfile='baseline',tofile='candidate')))
driver=(R/'Verify/current/drivers/lca_main.cpp').read_text();(W/'baseline_main.cpp').write_text(driver)
new='''// SPDX-License-Identifier: CC0-1.0
#include "Verify/current/common/fast_io.hpp"
#include <utility>
#include <vector>
int main(){
    int n,q;verify_in>>n>>q;
    std::vector<std::pair<int,int>> edges;edges.reserve(n-1);
    for(int v=1;v<n;++v){int p;verify_in>>p;edges.emplace_back(p,v);}
    LCA lca(n,edges);
    while(q--){int u,v;verify_in>>u>>v;verify_out<<lca.get(u,v)<<'\\n';}
}
''';(W/'candidate_main.cpp').write_text(new)
entry=next(e for e in pv.collect()if e['id']=='lca');metadata={'entry':entry,'programs':{},'core_effect_control':'baseline and adapter_old_api use same existing graph main; csr_program changes only adjacency construction/API boundary, same input/output/compiler/pragma'}
for name,body,main in [('baseline',(W/'baseline_library.cpp').read_bytes(),driver),('adapter_old_api',source.encode(),driver),('csr_program',source.encode(),new)]:
 data,_=pv.render(entry,source_overrides={'Graph/LCA.cpp':body},driver_override=main,skip_runtime_checks=True);p=W/(name+'.cpp');p.write_bytes(data);metadata['programs'][name]={'path':str(p),'sha256':hashlib.sha256(data).hexdigest()}
metadata['baseline_body_sha256']=hashlib.sha256((W/'baseline_library.cpp').read_bytes()).hexdigest();metadata['candidate_body_sha256']=hashlib.sha256(source.encode()).hexdigest();metadata['io_sha256']=hashlib.sha256((R/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest();(W/'sources.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n');print('prepared',W)
