from pathlib import Path
import hashlib,json,os,subprocess,time
W=Path('/tmp/sirkit_fastest_review_20261113/lca_csr_candidate');C=W/'clean_ref';os.sched_setaffinity(0,{10});(C/'bin').mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for label,prefix in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for name in ['baseline','adapter_old_api','csr_program']:
  exe=C/'bin'/f'{label}_{name}';src=C/(name+'.cpp');cmd=[*prefix,'-std=c++23','-O2','-Wall','-Wextra',str(src),'-o',str(exe)];r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);assert r.returncode==0,r.stderr;old=W/'bin'/f'{label}_{name}';rows.append({'compiler':label,'program':name,'command':cmd,'diagnostics':r.stderr,'final_source_sha256':sha(src),'measured_old_source_sha256':json.loads((W/'sources.json').read_text())['programs'][name]['sha256'],'final_binary_sha256':sha(exe),'measured_old_binary_sha256':sha(old),'binary_bytes_identical':exe.read_bytes()==old.read_bytes()});print(label,name,'binary identical',rows[-1]['binary_bytes_identical'],flush=True)
(C/'binary_equivalence.json').write_text(json.dumps(rows,indent=2)+'\n')
results=[]
for label,prefix in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  for fallback in [False,True]:
   exe=C/'bin'/f'light_{label}_{skip}_{fallback}';cmd=[*prefix,'-std=c++23','-O2','-Wall','-Wextra','-DSIRKIT_LCA_SOURCE="'+str(C/'candidate_library.cpp')+'"']
   if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
   if fallback:cmd+=['-U__SIZEOF_INT128__','-DSIRKIT_DISABLE_SIMD','-DSIRKIT_FORCE_STANDARD_ARITHMETIC']
   cmd += [str(C/'lca_edge_list_test.cpp'),'-o',str(exe)];r=subprocess.run(cmd,capture_output=True,text=True,timeout=120);assert r.returncode==0,r.stderr;t=time.monotonic();run=subprocess.run([str(exe)],capture_output=True,text=True,timeout=30);results.append({'kind':'lightweight','compiler':label,'skip':skip,'fallback':fallback,'command':cmd,'diagnostics':r.stderr,'returncode':run.returncode,'stdout':run.stdout,'stderr':run.stderr,'seconds':time.monotonic()-t});print('light',label,skip,fallback,run.stdout.strip(),flush=True);assert run.returncode==0
for skip in [False,True]:
 exe=C/'bin'/f'light_asan_{skip}';cmd=['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-std=c++23','-O1','-fsanitize=address,undefined','-fno-omit-frame-pointer','-DSIRKIT_LCA_SOURCE="'+str(C/'candidate_library.cpp')+'"']
 if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
 cmd += [str(C/'lca_edge_list_test.cpp'),'-o',str(exe)];r=subprocess.run(cmd,capture_output=True,text=True,timeout=120);assert r.returncode==0,r.stderr;r=subprocess.run([str(exe)],capture_output=True,text=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0'),timeout=60);results.append({'kind':'lightweight_sanitized','skip':skip,'command':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,r.stderr;print('sanitizers',skip,'PASS',flush=True)
for label,prefix in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 exe=C/'bin'/f'example_{label}';cmd=[*prefix,'-std=c++23','-O2','-Wall','-Wextra',str(C/'example_test.cpp'),'-o',str(exe)];r=subprocess.run(cmd,capture_output=True,text=True,timeout=120);assert r.returncode==0,r.stderr;r=subprocess.run([str(exe)],capture_output=True,text=True,timeout=30);expected='1 3\n0 0\n1 1\n-1 2\n1 2 5\n3 3\n1\n1 3\n0\n0 -1\n1\n';assert r.returncode==0 and r.stdout==expected,(r.returncode,r.stdout);results.append({'kind':'example','compiler':label,'command':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});print('example',label,'PASS',flush=True)
(C/'final_test_results.json').write_text(json.dumps(results,indent=2)+'\n');print('FINAL PASS',len(results),'extra configurations; all binaries identical',all(r['binary_bytes_identical']for r in rows),flush=True)
