# 残りのライブラリの最適化

当初の101ソースはCodexの検討・測定・独立照合を完了し、Graph17件の旧提出ソースはFableの検討後に再提出済みです。提出時のLibrary Checker10件は本文照合済みAC、AtCoder7件は画像ACで実提出全文の確認待ちです。別枠のZ Algorithm（416725）も現行ソース照合済みACです。

| 現在版の次の状態 | 件数 | 内訳 |
| --- | ---: | --- |
| `complete` | 10 | LC9件＋別枠のZ1件。現行ソース照合済みAC |
| `confirm_source` | 7 | AtCoder7件。画像AC、実提出全文は未照合。再提出要求は出さない |
| `codex` | 1 | Dijkstraの辺列API・main変更後の現行ソース。再検討と再提出が必要 |
| `claude` | 84 | 元のFable待ち。Data 34件は上限で中断、その他50件は未実行 |

Fable完了17件は旧Graph提出時の実績です。変更したDijkstraの旧AC・SHA・receiptはJSONの`historical`へ保存し、現在版へ引き継いでいません。

Fable 5.2は5時間枠の上限に達したため停止しています。通常リセットは11月13日19:40（日本時間）。追加課金・無料リセット・別アカウントへの切り替えは行っていません。Proの期間限定枠は11月17日16:59までです（[公式案内](https://support.claude.com/en/articles/17506494-claude-fable-5-2-launch-offers)）。

入力・出力とGCC設定も全体の測定で確認し、31件にO3またはループ展開を選びました。実行時assertを含む提出ではNDEBUGも生成します。本体だけの効果、mainの効果、入出力や設定の効果は区別しています。

通常版229件はGCC15.2とClang21の検査有効・無効で通過し、Clangは標準代替経路も確認しました。変更に関係する生成版は、最新版156提出コード・256サンプルを確認しています。

[件別の状態と提出コードSHA](remaining-2026-11-13.json)で、再提出済み17件（Dijkstraは旧版）と元のFable待ち84件を区別します。AtCoder7件は画像のサイズが17件ZIP内ソースのCRLF換算サイズと一致しますが、それだけで全文一致や現在版ACとは扱いません。待機中84件のSHAは維持しており、Fableの検討後に変わる可能性があります。

Fastest検討のうち、Dijkstraの辺列APIと対応mainだけを採用しました。現在版は未提出で、Codex再検討待ちです。他の候補は未採用です。

再開時は、実行前にアカウント・モデル・残量・期間を確認し、保存した提出コードSHAと現在版を照合します。入力は小さく分け、API・main・差分・hot pathから読み、必要な全文だけ追加します。`is_error=true`の実行は、`subtype=success`でも完了として記録しません。

[詳しい測定・判断・検証記録](../../Audit/remaining-library-optimization-2026-11-13.json) · [再現用の固定ソースと資料](../../Audit/data/remaining-library-optimization-2026-11-13.zip)
