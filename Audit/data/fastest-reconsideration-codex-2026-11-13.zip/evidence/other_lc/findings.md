# LC 5件：Fastestとの差の再考

公式v3 APIで最新自分提出とFastestを取得した読み取り専用の比較。全5件でAC・is_latest=true、ケース名集合も一致した。時刻・ソースSHA・全case時間は[review.json](review.json)へ固定した。

| 対象 | 自分 | Fastest | 自分の位置 |
|---|---:|---:|---|
| dijkstra | [141ms](https://judge.yosupo.jp/submission/416737) | [28ms](https://judge.yosupo.jp/submission/415573) | 先頭50外 |
| low_link_biconnected | [140ms](https://judge.yosupo.jp/submission/416745) | [68ms](https://judge.yosupo.jp/submission/287412) | 先頭50内28位 |
| low_link_two_edge | [31ms](https://judge.yosupo.jp/submission/416746) | [25ms](https://judge.yosupo.jp/submission/412935) | 先頭50内11位 |
| scc | [49ms](https://judge.yosupo.jp/submission/416748) | [9ms](https://judge.yosupo.jp/submission/413708) | 先頭50内22位 |
| two_sat | [80ms](https://judge.yosupo.jp/submission/416749) | [38ms](https://judge.yosupo.jp/submission/405839) | 先頭50内3位 |

langは全てcpp。現在の公式catalogはGCC15.2だが、過去提出の実際のcompiler build/再判定時刻/CPUはAPIから確定できない。オンライン値を同条件の本体性能とは扱わない。スコアは最大caseであり、最大を取るcaseが異なる点にも注意する。

## Dijkstra

最大のline_00は、公式固定commitのgenerator・seed=0で再生成し、公式hash.jsonのSHAに一致した。N=500000、M=499999、重みは全て10^9、頂点置換と辺shuffleがある。整列ラベルの線とは条件が異なる。

同じ独立WGraph engineで全距離188.65ms/target-only187.27ms、CSR radixでは60.00/60.87msだった。targetが線の最後なので停止しても処理量は減らない。現行も初期の一本道では既にヒープを省略するため、141対28msをtarget-only/DAG queueだけの差とは結論できない。近いtargetの対照では早期停止は有効だった。

今回の追加bulk API候補は既存engineをGraphLikeで再利用し、全距離契約を保ったままtuple/spanから内部CSRを作る。公式caseではGCC201.72→115.74ms、Clang209.84→111.17ms。入力構築・配置・内部weight32bit化の複合効果で、アルゴリズム変更とは区別した。既存WGraph版の検査範囲は変えず、新版だけ全辺を構築時に検査する。

候補は親がrootへ採用したが未提出。現body/main/IOでpragmaのみを変えた最終比較も終了し、公式line/random/DAGで最良のO3を維持する。[設定確認](dijkstra_flags/recommendations.json)。2045 case×10構成の独立参照、2 compilerの例、4構成の確保失敗/所有検証が通過。[候補詳細](dijkstra_bulk_candidate/final_report.json)・[測定](dijkstra_bulk_candidate/benchmark_results.json)。

## SCC

Fastestは次数0削除・圧縮・関数グラフ処理に加え、固定ISA/手書きASM・arena・専用parse/出力を組み合わせた全体専用設計。同じTarjanの単純な書換えとの差ではない。

外付けの次数判定やsource削除は一般caseで回帰した。既存の必須degree countを再利用した関数グラフ経路は、公式large_cycle_00で28.23→16.73ms（API順序も維持）。max_random系はほぼ元の速度なので、49ms全体が40%短縮するという意味ではない。helper分離後もGCC15.2で27.55→16.37ms、Clang21で26.39→15.29ms。一般DAG/乱数/密graphはGCCで同等、Clangで−1.6〜+0.3%に収まった。GCC/Clang×checked/skip×4独立テストの16構成も成功したため、親が本体を採用した（このagentはrepo未編集）。[最終候補](scc/separated_final_report.json)。

## LowLink 2種

点二重連結のFastestは木をDSUで確定できれば入力辺をそのまま2頂点ブロックとして出す。独立候補も50万頂点の線46.95→19.33ms、星42.78→14.31msだったが、一般乱数/閉路で小さな回帰があるので無条件には採用しない。Fastest先頭のOfast/target指定はコメントであり、有効な最適化設定ではなかった。

二辺連結は31対25ms・11位で、複数caseでは自分がrank1より速い。reserve追加さえ一貫して速くならず、今の汎用low-linkを劣悪と評価する根拠はない。

## TwoSAT

80msで3位。38msの上位2件と大きな差がある一方、一般的なSCC方式の上位とは近い。調べた最速は仕事量制限付きの含意伝播→SCC fallbackと、compact/consume可能な入力所有を使う。現行にもSCC確定時の早期矛盾検出はある。

独立のbounded trialは密乱数28.65→18.91ms、planted SAT30.25→22.49msだが、繰返しrollbackを誘う鎖では5.25→6.60ms（大きい予算だと9.13ms）へ回帰。これは単なる同一kernelの高速化ではなくsolver戦略の差で、既定への一律追加は支持されない。

## 再現・原典の扱い

測定はCPU11・GCC15.2、元の提出prefix/IOを固定し、2 warmup＋9回の交互比較。Dijkstra追加候補のみClang21でも同様に比較した。小グラフはBellman-Ford/Floyd/全真偽割当など独立参照で確認し、大caseは解の有効性と元提出の結果を照合した。

Fastest原文は比較用の/tmpキャッシュに留め、repoへコピー・コンパイルしていない。公式generatorはApache-2.0で、固定commit/URL/SHAとLICENSEを保存。既存DijkstraのCC0/参考出典は保持し、今回のCSR adapterは独立に記述した。

追加で新経路の確保失敗を各compiler/検査設定で15箇所ずつ注入し、既存結果・参照先・所有が保たれ、漏れ0を確認した。既存独立テストへ関数グラフと近傍620ケースを追加する小さなCI案も8構成で成功。[補足](scc/followup_final_report.json)。

SCCの最終helper/main/IOでも実pragma3種を確認し、現O3,unroll-loopsを維持する。O3単独は関数グラフで僅かに速いが、最大側の一般乱数/DAGでは現設定が同等以上で、一貫した切替利益はない。[設定比較](scc_flags/recommendations.json)。
