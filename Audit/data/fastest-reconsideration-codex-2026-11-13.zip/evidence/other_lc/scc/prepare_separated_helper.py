from pathlib import Path
import hashlib,json
W=Path(__file__).parent;source=(W/'original_header.hpp').read_text();old=source
helper='''// 既存CSR用の次数配列を調べる。通常のm!=nでは呼ばれない。
template<class Index>
#if defined(__GNUC__) || defined(__clang__)
[[gnu::noinline]]
#endif
inline bool outdegrees_all_one(const std::vector<Index>& degree) {
    for(auto it=degree.begin()+1;it!=degree.end();++it)if(*it!=1)return false;
    return true;
}

// 出次数が全て1なら、閉路と流入木を反復的に分解する。
#if defined(__GNUC__) || defined(__clang__)
[[gnu::noinline]]
#endif
inline std::pair<int,std::vector<int>> functional_component_ids(
        int n,const std::vector<std::pair<int,int>>& edges) {
    auto successor=std::make_unique_for_overwrite<int[]>(edges.size());
    for(auto [u,v]:edges)successor[u]=v;
    std::vector<int> ids(n,-1),path;path.reserve(n);int count=0;
    for(int root=0;root<n;++root) {
        if(ids[root]>=0)continue;
        int v=root;
        while(ids[v]==-1){ids[v]=-2;path.push_back(v);v=successor[v];}
        if(ids[v]==-2){int member;do{member=path.back();path.pop_back();ids[member]=count;}while(member!=v);++count;}
        while(!path.empty()){ids[path.back()]=count++;path.pop_back();}
    }
    for(auto& id:ids)id=count-1-id;
    return {count,std::move(ids)};
}

'''
source=source.replace('namespace reinsirk::detail {\n','namespace reinsirk::detail {\n'+helper,1)
marker='    for (auto [u, v] : edges) { (void)v; ++begin[static_cast<std::size_t>(u) + 1]; }\n';assert source.count(marker)==1
source=source.replace(marker,marker+'''    if(edges.size()==static_cast<std::size_t>(n) && outdegrees_all_one(begin))
        return functional_component_ids(n,edges);
''');(W/'separated_header.hpp').write_text(source)
(W/'separated_provenance.json').write_text(json.dumps({'original_source':'original_header.hpp','original_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_source':'separated_header.hpp','candidate_sha256':hashlib.sha256(source.encode()).hexdigest(),'changes':'Independent functional-graph decomposition and degree predicate are noinline internal helpers. Existing required degree count reused; generic m!=n takes only header comparison, m=n rejects at first non-one degree without an added edge pass.','contract':'All SCC ids in topological order. Functional graph path preserves the same postorder component numbering as Tarjan, including in-trees. All ownership/guards/public APIs unchanged.','sharing':'Graph/Two_SAT.cpp has a separate contradiction-detecting two_sat_component_ids kernel/guard, not this helper. Mixed-header independent tests check coexistence.','external_source_reuse':False},indent=2)+'\n');print('separated helper ready')
