from pathlib import Path
import subprocess,json,hashlib,sys
R=Path('/home/reinsirk/Atcoder_Env');W=Path(__file__).parent;header=W/'separated_header.hpp';rows=[]
followup='--followup' in sys.argv
names=['scc_functional_allocation_test','scc_index_paths_test_candidate'] if followup else ['scc_acl_api_test','scc_index_paths_test','new_scc_two_sat_reference_test','scc_condensation_test']
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for mode,flags in [('checked',[]),('skip',['-DSKIP_RUNTIME_CHECKS'])]:
  for name in names:
   src=(W if followup else R/'Verify/current/tests')/f'{name}.cpp';exe=W/f'separated-{cc}-{mode}-{name}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',*flags,'-DSIRKIT_SCC_TEST_SOURCE="'+str(header)+'"','-DSCC_SOURCE="'+str(header)+'"',str(src),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);row={'compiler':cc,'mode':mode,'test':name,'command':cmd,'source_sha256':hashlib.sha256(header.read_bytes()).hexdigest(),'compile_ok':p.returncode==0,'diagnostics':p.stderr};assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','11',str(exe)],text=True,capture_output=True);row.update(passed=p.returncode==0,stdout=p.stdout,stderr=p.stderr);rows.append(row);(W/('followup_test_results.json' if followup else 'separated_test_results.json')).write_text(json.dumps(rows,indent=2)+'\n');print(cc,mode,name,p.stdout[:160].strip(),flush=True);assert p.returncode==0,p.stderr
