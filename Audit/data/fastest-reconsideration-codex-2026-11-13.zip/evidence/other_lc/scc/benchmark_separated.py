from pathlib import Path
import json, subprocess, hashlib, time, statistics, random, shutil, ast
D=Path(__file__).parent; W=D.parent
original=(W/'scc_own.cpp').read_text(); old=(D/'original_header.hpp').read_text(); new=(D/'separated_header.hpp').read_text(); assert old in original
sources={'own':original,'helper':original.replace(old,new)};records=[]
tree=ast.parse((W/'bench_scc.py').read_text());fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='decode');ns={};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<checker>','exec'),ns);decode=ns['decode']
def save(): (D/'separated_benchmark_results.json').write_text(json.dumps({'scope':'same own submitted prefix/main/I/O, O2 CLI, 2 warm + 9 randomized alternating, CPU11','source_sha256':{k:hashlib.sha256(s.encode()).hexdigest() for k,s in sources.items()},'results':records},indent=2)+'\n')
for compiler,cc in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 bins={}
 for label,s in sources.items():
  src=D/f'separated_bench_{compiler}_{label}.cpp';src.write_text(s);exe=src.with_suffix('');cmd=['taskset','-c','11',*cc,'-std=c++23','-O2',str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;bins[label]=exe;records.append({'kind':'build','compiler':compiler,'label':label,'command':cmd,'passed':True});save()
 for inp in [D/'dag.in',D/'critical_random.in',D/'dense_random.in',D/'functional_random.in',W/'official_generator/scc_large_cycle_00.in']:
  fields=list(map(int,inp.read_text().split()));n,m=fields[:2];edges=list(zip(fields[2::2],fields[3::2]));expected=None
  for label,exe in bins.items():
   p=subprocess.run(['taskset','-c','11',str(exe)],input=inp.read_bytes(),capture_output=True);assert p.returncode==0,p.stderr;got=decode(p.stdout.decode(),n,edges);expected=got if expected is None else expected;assert got==expected
  raw={k:[] for k in bins};rng=random.Random(113935)
  for rep in range(11):
   order=list(bins);rng.shuffle(order)
   for label in order:
    active=D/'separated_active';shutil.copyfile(bins[label],active);active.chmod(0o755)
    with inp.open('rb') as fi,open('/dev/null','wb') as fo:
     start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','11',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
    assert p.returncode==0,p.stderr
    if rep>=2:raw[label].append(elapsed)
  med={k:statistics.median(v) for k,v in raw.items()};records.append({'kind':'timing','compiler':compiler,'case':inp.stem,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'canonical_partition_and_topology_equal':True,'raw_ns':raw,'median_ns':med});save();print(compiler,inp.stem,{k:round(v/1e6,3) for k,v in med.items()},flush=True)
