from pathlib import Path
import json,sys,subprocess,hashlib,random,time,statistics,shutil,re
R=Path('/home/reinsirk/Atcoder_Env');W=Path(__file__).parent;P=W.parent;sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
entry=next(e for e in pv.collect() if e['id']=='scc');sources={};records=[]
for label,opt in [('O2',None),('O3','O3'),('O3_unroll','O3,unroll-loops')]:
 e=dict(entry);e.pop('gcc_optimization',None)
 if opt:e['gcc_optimization']=opt
 sources[label]=pv.render(e,skip_runtime_checks=True)[0]
strip=lambda s:re.sub(rb'#if defined\(__GNUC__\) && !defined\(__clang__\)\n#pragma GCC optimize\([^\n]+\)\n#endif\n',b'',s)
assert len({hashlib.sha256(strip(s)).hexdigest() for s in sources.values()})==1
base={'cpu':11,'compiler':subprocess.check_output(['/usr/bin/g++','--version'],text=True).splitlines()[0],'scope':'Current adopted SCC functional-helper body/main and common I/O held byte-identical, actual generated pragma only; CLI O2 in all; 2 warm + 9 randomized alternating.','entry':entry,'source_sha256':{k:hashlib.sha256(v).hexdigest() for k,v in sources.items()},'nonpragma_bytes_identical':True,'n_debug_same':all((b'#define NDEBUG' in v)==(b'#define NDEBUG' in sources['O2']) for v in sources.values()),'library_sha256':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in entry['libraries']},'driver_sha256':hashlib.sha256((R/entry['driver']).read_bytes()).hexdigest(),'results':records}
def save():(W/'results.json').write_text(json.dumps(base,indent=2)+'\n')
bins={}
for label,s in sources.items():
 src=W/(label+'.cpp');src.write_bytes(s);exe=W/label;cmd=['taskset','-c','11','/usr/bin/g++','-std=c++23','-O2',str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;bins[label]=exe;records.append({'kind':'build','label':label,'command':cmd,'passed':True});save()
for inp in [P/'official_generator/scc_large_cycle_00.in',P/'scc/functional_random.in',P/'scc/critical_random.in',P/'scc/dag.in',P/'scc/dense_random.in']:
 outputs={}
 for label,exe in bins.items():
  p=subprocess.run(['taskset','-c','11',str(exe)],input=inp.read_bytes(),capture_output=True);assert p.returncode==0,p.stderr;outputs[label]=p.stdout
 assert len(set(outputs.values()))==1
 raw={k:[] for k in bins};rng=random.Random(819873)
 for rep in range(11):
  order=list(bins);rng.shuffle(order)
  for label in order:
   active=W/'active';shutil.copyfile(bins[label],active);active.chmod(0o755)
   with inp.open('rb') as fi,open('/dev/null','wb') as fo:
    start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','11',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
   assert p.returncode==0,p.stderr
   if rep>=2:raw[label].append(elapsed)
 med={k:statistics.median(v) for k,v in raw.items()};records.append({'kind':'timing','case':inp.stem,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'output_byte_identical':True,'output_sha256':hashlib.sha256(outputs['O2']).hexdigest(),'raw_ns':raw,'median_ns':med});save();print(inp.stem,{k:round(v/1e6,3) for k,v in med.items()},flush=True)
