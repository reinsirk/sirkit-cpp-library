// SPDX-License-Identifier: CC0-1.0
#include <cstdlib>
#include <cstdio>
#include <new>
#include <cstddef>
static std::ptrdiff_t budget=-1;static std::size_t live=0,checks=0;
void* operator new(std::size_t n){if(budget==0)throw std::bad_alloc();if(budget>0)--budget;if(void*p=std::malloc(n?n:1)){++live;return p;}throw std::bad_alloc();}
void* operator new[](std::size_t n){return ::operator new(n);}
void operator delete(void*p)noexcept{if(p)--live;std::free(p);}void operator delete[](void*p)noexcept{::operator delete(p);}void operator delete(void*p,std::size_t)noexcept{::operator delete(p);}void operator delete[](void*p,std::size_t)noexcept{::operator delete(p);}
#include "../Graph/Dijkstra.cpp"
static void check(bool x){++checks;if(!x)std::abort();}
int main(){std::size_t failures=0,successes=0;const auto original_live=live;{
 std::vector<std::tuple<int,int,std::int64_t>> edges;for(int v=0;v<4999;++v)edges.emplace_back(v,v+1,1000000000);for(int v=1;v<5000;v+=2)edges.emplace_back(0,v,1);
 for(int at=0;at<64;++at){std::vector<std::int64_t>d{77};std::vector<int>p{66};const auto before=live;bool success=false;
  budget=at;try{Dijkstra(5000,edges,d,0,4999,p);budget=-1;success=true;}catch(const std::bad_alloc&){budget=-1;++failures;
#ifndef SKIP_RUNTIME_CHECKS
   check(d==std::vector<std::int64_t>{77}&&p==std::vector<int>{66});
#endif
  }
  check(live==before);if(success){check(d[0]==0&&d[4999]==1&&p.front()==0&&p.back()==4999);++successes;break;}
 }
 }
 check(live==original_live&&failures>=3&&successes==1);std::printf("PASS CSR allocation failures=%zu checks=%zu live_delta=%td\n",failures,checks,std::ptrdiff_t(live)-std::ptrdiff_t(original_live));}
