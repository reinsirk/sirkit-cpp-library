// SPDX-License-Identifier: CC0-1.0
#include <cstdint>
#include <vector>
#ifdef BENCH_PREDEFINED_EDGE
#define SIRKIT_GRAPH_TYPES_DEFINED
struct Edge {int to;std::int64_t w;Edge()=delete;Edge(int to_,std::int64_t w_):to(to_),w(w_){};};
using WGraph=std::vector<std::vector<Edge>>;
#endif
#include "../Graph/Dijkstra.cpp"
#include "../Graph/Dijkstra.cpp"
#include <cstdio>
#include <cstdlib>
#include <random>
#include <tuple>
#include <algorithm>
#include <queue>
using Input=std::vector<std::tuple<int,int,std::int64_t>>;
static std::uint64_t checks=0,cases=0;
static void check(bool x){++checks;if(!x)std::abort();}
static std::vector<std::int64_t> bellman(int n,const Input& edges,int s){
 std::vector<std::int64_t>d(n,INF);d[s]=0;
 for(int iteration=0;iteration<n;++iteration){bool changed=false;for(auto[u,v,w]:edges)if(d[u]!=INF&&d[u]+w<d[v]){d[v]=d[u]+w;changed=true;}if(!changed)break;}
 return d;
}
static std::vector<std::int64_t> heap_reference(int n,const Input& edges,int s){
 std::vector<std::vector<std::pair<int,std::int64_t>>>g(n);for(auto[u,v,w]:edges)g[u].emplace_back(v,w);
 using Item=std::pair<std::int64_t,int>;std::priority_queue<Item,std::vector<Item>,std::greater<Item>>q;std::vector<std::int64_t>d(n,INF);d[s]=0;q.emplace(0,s);
 while(!q.empty()){auto[distance,v]=q.top();q.pop();if(d[v]!=distance)continue;for(auto[to,w]:g[v])if(distance+w<d[to]){d[to]=distance+w;q.emplace(d[to],to);}}
 return d;
}
static void path_ok(const WGraph& g,const std::vector<int>& path,int s,int t,const std::vector<std::int64_t>&d){
 if(d[t]==INF){check(path.empty());return;}check(!path.empty()&&path.front()==s&&path.back()==t);std::int64_t total=0;
 for(std::size_t i=1;i<path.size();++i){check(0<=path[i]&&path[i]<int(g.size()));auto weight=INF;for(const auto&e:g[path[i-1]])if(e.to==path[i])weight=std::min(weight,e.w);check(weight!=INF);total+=weight;}
 check(total==d[t]);
}
static void inspect(int n,const Input& edges,int s,int t,bool small){
 ++cases;const auto before=edges;WGraph g(n);for(auto[u,v,w]:edges)g[u].emplace_back(v,w);const auto want=small?bellman(n,edges,s):heap_reference(n,edges,s);std::vector<std::int64_t>d{-17};std::vector<int>path{-17};
 Dijkstra(g,d,s);check(d==want);Dijkstra(g,d,s,t,path);check(d==want);path_ok(g,path,s,t,d);
 Dijkstra(n,edges,d,s);check(d==want);Dijkstra(n,edges,d,s,t,path);check(d==want);path_ok(g,path,s,t,d);
 const auto frozen=edges;Dijkstra(n,frozen,d,s,t,path);check(d==want);path_ok(g,path,s,t,d);check(edges==before);
 // Far vertices still receive exact distances even when target=start.
 Dijkstra(n,edges,d,s,s,path);check(d==want);check(path.size()==1&&path[0]==s);
}
template<class Error,class F> static void rejects(F f){bool caught=false;try{f();}catch(const Error&){caught=true;}check(caught);}
int main(){
 std::mt19937_64 random(0xD1A5C5A20261113ULL);
 for(int rep=0;rep<2000;++rep){int n=1+random()%80;Input edges;for(int i=0,m=random()%(5*n+1);i<m;++i){auto w=rep%4==0?0:rep%4==1?1:rep%4==2?1000000000:std::int64_t(random()%1000000001);edges.emplace_back(random()%n,random()%n,w);}inspect(n,edges,random()%n,random()%n,true);}
 for(int n:{1,2,255,256,257,4095,4096,4097,20000}){
  Input chain;for(int i=1;i<n;++i)chain.emplace_back(i-1,i,1000000000);inspect(n,chain,0,n-1,n<=257);inspect(n,chain,0,0,n<=257);inspect(n,chain,n-1,0,n<=257);
  Input star;for(int i=1;i<n;++i){star.emplace_back(0,i,i%2?0:1000000000);star.emplace_back(0,i,1000000000);}inspect(n,star,0,n-1,n<=257);
  Input mixed;for(int i=0;i<5*n;++i)mixed.emplace_back(random()%n,random()%n,random()%1000000001);inspect(n,mixed,random()%n,random()%n,n<=257);
 }
 {std::vector<std::int64_t>d{9};rejects<std::length_error>([&]{Dijkstra(-1,Input{},d,0);});check(d==std::vector<std::int64_t>{9});}
#ifndef SKIP_RUNTIME_CHECKS
 {Input broken{{1,7,0}};std::vector<std::int64_t>d{9};std::vector<int>path{8};rejects<std::out_of_range>([&]{Dijkstra(3,broken,d,0,0,path);});check(d==std::vector<std::int64_t>{9}&&path==std::vector<int>{8});}
 for(Input broken:{Input{{-1,0,0}},Input{{0,-1,0}},Input{{3,0,0}},Input{{0,3,0}},Input{{0,1,-1}},Input{{0,1,1000000001}}}){std::vector<std::int64_t>d;rejects<std::out_of_range>([&]{Dijkstra(3,broken,d,0);});}
 {std::vector<std::int64_t>d;rejects<std::out_of_range>([&]{Dijkstra(0,Input{},d,0);});rejects<std::out_of_range>([&]{Dijkstra(2,Input{},d,-1);});std::vector<int>path;rejects<std::out_of_range>([&]{Dijkstra(2,Input{},d,0,2,path);});}
 // The original graph overload still ignores invalid edges in unreachable rows.
 {WGraph g(3);g[1].emplace_back(7,-1);std::vector<std::int64_t>d;Dijkstra(g,d,0);check(d==std::vector<std::int64_t>({0,INF,INF}));}
#endif
 std::printf("PASS bulk/WGraph Bellman-Ford/heap/path contracts: cases=%ju checks=%ju\n",static_cast<std::uintmax_t>(cases),static_cast<std::uintmax_t>(checks));
}
