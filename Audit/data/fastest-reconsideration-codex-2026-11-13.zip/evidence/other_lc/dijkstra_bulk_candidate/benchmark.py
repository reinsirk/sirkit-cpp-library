from pathlib import Path
import sys,json,hashlib,subprocess,time,statistics,random,shutil
R=Path('/home/reinsirk/Atcoder_Env');W=Path(__file__).parent;P=W.parent;D=P/'dijkstra';G=P/'official_generator';(W/'bin').mkdir(exist_ok=True);(W/'submissions').mkdir(exist_ok=True);records=[]
sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
entry=next(e for e in pv.collect() if e['id']=='dijkstra');oldbody=(W/'frozen_before/Graph/Dijkstra.cpp').read_text();newbody=(W/'Graph/Dijkstra.cpp').read_text();own=(P/'dijkstra_own.cpp').read_text();assert oldbody in own;regression=own.replace(oldbody,newbody)
old='''    WGraph graph(n);
    for (int i=0;i<m;++i) { int u{},v{}; std::int64_t w{}; verify_in>>u>>v>>w; graph[u].emplace_back(v,w); }''';new='''    std::vector<std::tuple<int,int,std::int64_t>> edges(m);
    for(auto& [u,v,w]:edges)verify_in>>u>>v>>w;''';assert old in regression;bulk=regression.replace(old,new).replace('Dijkstra(graph,distance,s,t,path);','Dijkstra(n,edges,distance,s,t,path);');assert bulk!=regression
sources={'original_wgraph':own,'candidate_wgraph':regression,'candidate_bulk':bulk}
for label,source in sources.items():(W/'submissions'/f'{label}.cpp').write_text(source)
(W/'Verify_driver_candidate.cpp').write_text((R/entry['driver']).read_text().replace(old,new).replace('Dijkstra(graph,distance,s,t,path);','Dijkstra(n,edges,distance,s,t,path);'))
def save():(W/'benchmark_results.json').write_text(json.dumps({'cpu':11,'flags':'C++23 O2 CLI; original submitted GCC O3 pragma retained in all programs; SKIP_RUNTIME_CHECKS same in all; Clang ignores GCC-only pragma.','scope':'Original all-distance WGraph API vs same API in templated candidate vs new span/tuple bulk API; same I/O/output and full-distance engine. No target-only exit or new DAG scheduling in candidate.','results':records},indent=2)+'\n')
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 bins={}
 for label,source in sources.items():
  src=W/'submissions'/f'{label}.cpp';exe=W/'bin'/f'{cc}-{label}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',str(src),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);records.append({'kind':'build','compiler':cc,'label':label,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'passed':p.returncode==0,'diagnostics':p.stderr});save();assert p.returncode==0,p.stderr;bins[label]=exe
  for sample in entry['samples']:
   p=subprocess.run(['taskset','-c','11',str(exe)],input=sample['input'],text=True,capture_output=True);assert p.returncode==0 and pv.matches(entry,sample,p.stdout),(cc,label,p.stdout)
 cases=[D/(name+'.in') for name in ['line_end','line_target_near','cycle','star','dag','random_sparse','disconnected','random_reachable']]+[G/'line_00.in',G/'line_target_near_control.in']
 for inp in cases:
  data=inp.read_text();checks={};expected=None
  for label,exe in bins.items():
   p=subprocess.run(['taskset','-c','11',str(exe)],input=data,text=True,capture_output=True);assert p.returncode==0,p.stderr
   if expected is None:expected=p.stdout
   same=p.stdout==expected;assert same or pv.matches(entry,{'input':data,'output':expected},p.stdout),(cc,label,inp.name);checks[label]={'byte_identical':same,'sha256':hashlib.sha256(p.stdout.encode()).hexdigest(),'bytes':len(p.stdout)}
  raw={label:[] for label in bins};order=list(bins);r=random.Random(287251)
  for rep in range(11):
   r.shuffle(order)
   for label in order:
    active=W/'bin/active';shutil.copyfile(bins[label],active);active.chmod(0o755)
    with inp.open('rb') as fi,open('/dev/null','wb') as fo:
     start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','11',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);ns=time.perf_counter_ns()-start
    assert p.returncode==0,p.stderr
    if rep>=2:raw[label].append(ns)
  med={k:statistics.median(v) for k,v in raw.items()};records.append({'kind':'timing','compiler':cc,'case':inp.stem,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'raw_ns':raw,'median_ns':med,'candidate_wgraph_ratio':med['candidate_wgraph']/med['original_wgraph'],'bulk_ratio':med['candidate_bulk']/med['original_wgraph'],'output_checks':checks});save();print(cc,inp.stem,{k:round(v/1e6,2) for k,v in med.items()},flush=True)
