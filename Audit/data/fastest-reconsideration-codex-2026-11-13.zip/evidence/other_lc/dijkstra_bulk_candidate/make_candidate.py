from pathlib import Path
import re,json,hashlib
R=Path('/home/reinsirk/Atcoder_Env');W=Path(__file__).parent;source=(W/'frozen_before/Graph/Dijkstra.cpp').read_text();original=source
source=source.replace('#include <type_traits>','#include <type_traits>\n#include <tuple>')
marker='inline void Dijkstra(const WGraph &graph,';cut=source.index(marker);private,public=source[:cut],source[cut:]
changes={
 'template <bool RestorePath, bool MayOverflow>':'template <bool RestorePath, bool MayOverflow, class GraphLike = WGraph>',
 'template <bool RestorePath, bool MayOverflow, class InitialRange>':'template <bool RestorePath, bool MayOverflow, class InitialRange, class GraphLike = WGraph>',
 'template <bool RestorePath, bool MayOverflow, bool Adaptive, bool PruneTerminal = true, bool RecordInitialChain = false>':'template <bool RestorePath, bool MayOverflow, bool Adaptive, bool PruneTerminal = true, bool RecordInitialChain = false, class GraphLike = WGraph>',
 'template <bool RestorePath, bool MayOverflow, bool PruneTerminal>':'template <bool RestorePath, bool MayOverflow, bool PruneTerminal, class GraphLike = WGraph>',
 'template <bool RestorePath, bool MayOverflow, bool PruneTerminal = true>':'template <bool RestorePath, bool MayOverflow, bool PruneTerminal = true, class GraphLike = WGraph>',
 'template <bool RestorePath>':'template <bool RestorePath, class GraphLike = WGraph>'}
for old,new in changes.items():assert private.count(old)==1,old;private=private.replace(old,new)
private=private.replace('const WGraph& graph','const GraphLike& graph').replace('const WGraph &graph','const GraphLike &graph')
csr='''// バルク入力専用。行spanはowned arcs_を参照し、コピー/移動しない。
class DijkstraCsrGraph {
    struct Arc {
        int to;
        std::uint32_t w;
        Arc() noexcept {} // 全要素を下の散布で上書きするため先行初期化不要。
    };
    std::vector<Arc> arcs_;
    std::vector<std::span<const Arc>> rows_;
public:
    DijkstraCsrGraph(int n, std::span<const std::tuple<int,int,std::int64_t>> input) {
        if(n<0) throw std::length_error("Dijkstra: negative vertex count");
        if(input.size()>arcs_.max_size() || static_cast<std::size_t>(n)>rows_.max_size())
            throw std::length_error("Dijkstra: CSR capacity exceeded");
        std::vector<std::size_t> begin(static_cast<std::size_t>(n)+1);
        for(const auto& [u,v,w]:input) {
#ifndef SKIP_RUNTIME_CHECKS
            if(u<0 || u>=n || v<0 || v>=n)
                throw std::out_of_range("Dijkstra: invalid bulk endpoint");
            if(w<0 || w>1'000'000'000)
                throw std::out_of_range("Dijkstra: weight must be in [0, 1e9]");
#endif
            ++begin[static_cast<std::size_t>(u)+1];
        }
        for(int v=0;v<n;++v)begin[v+1]+=begin[v];
        arcs_.resize(input.size());
        rows_.reserve(n);
        for(int v=0;v<n;++v) {
            const auto length=begin[v+1]-begin[v];
            if(length==0) rows_.emplace_back();
            else rows_.emplace_back(arcs_.data()+begin[v],length);
        }
        // beginを直接cursorへ変え、次数配列のコピーを省く。
        for(const auto& [u,v,w]:input) {
            auto& arc=arcs_[begin[u]++];arc.to=v;arc.w=static_cast<std::uint32_t>(w);
        }
    }
    DijkstraCsrGraph(const DijkstraCsrGraph&)=delete;
    DijkstraCsrGraph& operator=(const DijkstraCsrGraph&)=delete;
    DijkstraCsrGraph(DijkstraCsrGraph&&)=delete;
    DijkstraCsrGraph& operator=(DijkstraCsrGraph&&)=delete;
    std::size_t size() const noexcept{return rows_.size();}
    const auto& operator[](std::size_t v) const noexcept{return rows_[v];}
    const auto* data() const noexcept{return rows_.data();}
};

'''
private=private.replace('namespace reinsirk::detail {\n','namespace reinsirk::detail {\n'+csr,1)
# CSR construction has already checked every edge; preserve old WGraph checks.
checks=0
def wrap(m):
 global checks
 text=m.group(1)
 if 'invalid destination vertex' not in text:return m.group(0)
 checks+=1
 return '#ifndef SKIP_RUNTIME_CHECKS\n        if constexpr (!std::is_same_v<GraphLike, DijkstraCsrGraph>) {\n'+text+'\n        }\n#endif'
private=re.sub(r'#ifndef SKIP_RUNTIME_CHECKS\n(.*?)#endif',wrap,private,flags=re.S)
private=private.replace('constexpr std::int64_t max_weight =', '[[maybe_unused]] constexpr std::int64_t max_weight =').replace('    const int n = static_cast<int>(graph.size());','    [[maybe_unused]] const int n = static_cast<int>(graph.size());')
# Reuse the exact existing dispatch choices for both bulk overloads.
first=public.index('inline void Dijkstra(');second=public.index('inline void Dijkstra(',first+1);end=public.rfind('\n#endif');a=public[first:second].rstrip();b=public[second:end].rstrip()
a=a.replace('inline void Dijkstra(const WGraph &graph,','inline void Dijkstra(int n, std::span<const std::tuple<int,int,std::int64_t>> edges,').replace('{\n','{\n    const reinsirk::detail::DijkstraCsrGraph graph(n,edges);\n',1)
b=b.replace('inline void Dijkstra(const WGraph &graph,','inline void Dijkstra(int n, std::span<const std::tuple<int,int,std::int64_t>> edges,').replace('{\n','{\n    const reinsirk::detail::DijkstraCsrGraph graph(n,edges);\n',1)
public=public[:end]+'\n// 辺列入力版も全頂点の距離を返す。CSR構築後は上と同じengineを使う。\n'+a+'\n\n'+b+'\n'+public[end:]
source=private+public
old='// 両版ともO(V+E log(E+1))時間・O(V+E)追加領域。\n// SKIP_RUNTIME_CHECKSを定義すると入力検査を省く。\n// 検査は始点・終点と処理中に参照する辺のみ。未到達成分は走査しない。'
new='''// Dijkstra(n, edges, distances, start_index[, target_index, path]): (始点,終点,int64重み)のtuple列を\n// span<const tuple<int,int,int64_t>>で受け、内部CSRを作って全頂点の距離を返す。vectorからも渡せる。\n// 全版O(V+E log(E+1))時間・O(V+E)追加領域。辺列版のCSR構築はO(V+E)。\n// SKIP_RUNTIME_CHECKSを定義すると入力検査を省く。\n// WGraph版の検査は始点・終点と処理中に参照する辺のみ。未到達成分は走査しない。\n// 辺列版は構築時に全辺を参照し、両端点と重みを検査する。n<0・容量超過はlength_error。'''
assert old in source;source=source.replace(old,new);(W/'Graph/Dijkstra.cpp').write_text(source)
(W/'provenance.json').write_text(json.dumps({'original_source':'/home/reinsirk/Atcoder_Env/Graph/Dijkstra.cpp','original_sha256':hashlib.sha256(original.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(source.encode()).hexdigest(),'license':'Existing CC0-1.0 and original reference URL retained without changes. New CSR adapter and template adaptation independently authored; no fastest-solution implementation text reused.','checked_edge_blocks_skipped_after_bulk_validation':checks,'bulk_weight_storage':'Private uint32 weights are valid for documented [0,1e9] domain; public Edge/int64 and WGraph unchanged. Internal Arc is fully overwritten before any read.','ownership':'CSR owns vectors, row spans refer only to its own arc vector; all copy/move deleted; no direct new expressions.','contracts':'All-distance for all overloads; old WGraph validation traversal unchanged. Bulk validates all endpoints/weights while constructing; after construction duplicate engine edge checks removed only for private CSR type.'},ensure_ascii=False,indent=2)+'\n');print('candidate generated bytes',len(source),'edge blocks',checks)
