from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,time,unittest
p=Path(__file__).resolve().parent;file=p/'Scripts/tests/test_dijkstra_bulk_runtime.py';spec=importlib.util.spec_from_file_location('bulk_ci_proposal',file);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
rows=[];original=mod.DijkstraBulkRuntimeTests.run_command

def measured(self,command,phase,timeout):
 start=time.perf_counter();value=original(self,command,phase,timeout)
 rows.append({'test':self.id(),'phase':phase,'command':list(map(str,command)),'elapsed_seconds':time.perf_counter()-start,'stdout':value.stdout,'stderr':value.stderr,'returncode':value.returncode});return value
mod.DijkstraBulkRuntimeTests.run_command=measured
with (p/'gcc15_clang21.log').open('w')as log:
 start=time.perf_counter();result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(mod.DijkstraBulkRuntimeTests));elapsed=time.perf_counter()-start
report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':result.wasSuccessful(),'tests_run':result.testsRun,'total_seconds':elapsed,'versions':{c:subprocess.check_output([c,'--version'],text=True).splitlines()[0]for c in ['/usr/bin/g++','/usr/bin/clang++']},'first_trial':{'compiler':'/usr/local/bin/g++ (GCC 15.3.0) and Clang21','total_seconds':10.152,'passed':True,'note':'Initial development trial only; final validation below uses system GCC15.2.'},'source_sha256':hashlib.sha256((p/'Graph/Dijkstra.cpp').read_bytes()).hexdigest(),'steps':rows};(p/'runtime_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('PASS'if result.wasSuccessful()else'FAIL','tests',result.testsRun,'seconds',elapsed)
if not result.wasSuccessful():raise SystemExit(1)
