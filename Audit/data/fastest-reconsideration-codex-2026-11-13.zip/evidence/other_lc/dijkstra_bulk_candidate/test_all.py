from pathlib import Path
import subprocess,json,hashlib
W=Path(__file__).parent;R=Path('/home/reinsirk/Atcoder_Env');results=[]
compilers={'gcc':['/usr/bin/g++'],'clang':['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']}
for cc,compiler in compilers.items():
 for mode,flags in [('checked',[]),('skip',['-DSKIP_RUNTIME_CHECKS']),('standard',['-DSKIP_RUNTIME_CHECKS','-DSIRKIT_DISABLE_SIMD']),('external_edge_checked',['-DBENCH_PREDEFINED_EDGE']),('external_edge_skip',['-DBENCH_PREDEFINED_EDGE','-DSKIP_RUNTIME_CHECKS'])]:
  src=W/'tests/reference.cpp';exe=W/'tests'/f'{cc}-{mode}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2','-Wall','-Wextra',*flags,str(src),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);row={'compiler':cc,'mode':mode,'command':cmd,'compile_ok':p.returncode==0,'diagnostics':p.stderr};assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','11',str(exe)],text=True,capture_output=True);row.update(passed=p.returncode==0,stdout=p.stdout,stderr=p.stderr);results.append(row);(W/'test_results.json').write_text(json.dumps(results,indent=2)+'\n');print(cc,mode,p.stdout.strip(),flush=True);assert p.returncode==0,p.stderr
 for mode,src in [('example',W/'Examples/dijkstra_example.cpp')]:
  exe=W/'tests'/f'{cc}-{mode}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',str(src),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','11',str(exe)],text=True,capture_output=True);assert p.returncode==0 and p.stdout.endswith('5 4\n');results.append({'compiler':cc,'mode':mode,'command':cmd,'passed':True,'stdout':p.stdout});(W/'test_results.json').write_text(json.dumps(results,indent=2)+'\n')
# Source shape/guards and default Edge independence are also tested by the
# external_edge modes; the owning private CSR has no direct new expression.
source=(W/'Graph/Dijkstra.cpp').read_text();assert not __import__('re').search(r'\bnew\s+(?:\w|\[)',source);print('PASS all candidate configurations',len(results))
