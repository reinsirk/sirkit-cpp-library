# Verify専用入力の一括読み込み比較

最終判断: 共通I/Oを変更しない。リポジトリの本体・main・生成物・記録は編集していない。
現行 `Verify/current/common/fast_io.hpp` のSHA-256は
`87641ba841cb2c15df2886c1289b45df20c6925cb6cf78506d505fa7a70f2aab`。
親が管理するFable 84件のsnapshotへ波及させない。

## 対象と比較条件

- LCA、HLD 4件、Dijkstra、SCC、2SAT、LowLink 2件の10 ID・36入力。
- 大入力31件、小入力5件。random、line/chain、binary/cycle等の退化を含む。
- 最新自分の提出全文を固定し、VerifyInputだけを変更。VerifyOutput・本体・mainは同一。
- GCC15.2 `/usr/bin/g++ -std=c++23 -O2 -Wall -Wextra`。提出内の既存pragmaとSKIP設定を維持。
- CPU10、同一入力で2回warmup後9回ずつ交互実行。出力をbyte単位で照合。
- 小入力は独立モデルとも照合。RSSは別実行の `/usr/bin/time %M`。
- 全体時間はI/O込み。本体改善の成果には含めない。環境負荷の変動があるため、別実験間の絶対時間は比較しない。

## 自作した候補と結果

第三者Fastestの実装はコピーしていない。既存の自作入力のAPI・数値変換意味を基に独立に記述した。
整数型幅、bool、符号、EOF、char/string、浮動小数点の意味を保つ。
所有freadはunique_ptr、mappingはunique_ptrのdeleterによるmunmap。raw newなし。
容量・pointer差分上限のチェックをSKIP時も維持。

|候補|ディレクトリ|大入力31件の幾何平均 候補/現行|判断|
|---|---|---:|---|
|所有bufferを倍増、番兵＋pointer走査|このディレクトリ|1.088|不採用|
|regular FILEの残量予約で再確保を回避|hinted|1.035|不採用|
|さらに整数cursorを局所変数化|local_cursor|1.014|不採用|
|Linux regular FILEのみ独立mmap・全走査で末尾判定|mapped|0.981|共通採用を見送り|

mmapではHLD系が概ね2〜5%、LowLink chainが約8%短縮したが、LCA random約4.6%、2SAT planted約8.3%の回帰が混在。
差が小さい項目や実行変動もあり、一律変更の根拠にしない。入力保持により最大約17MiBのpeak RSS増。
今回はmmap失敗・pipe・他OSを所有freadへ戻す実験版。仮に将来採用する場合は現行streaming freadへのfallbackが必要。
mapping成功とRAII解除、pipe fallbackは `mapped/probe.json` の未計時診断で確認した。
`strace` は環境のptrace制限により利用できず、診断ソースを別に作成した。計時ソースは変更していない。
一括入力はEOFまで読むbatch専用。FILEは非所有だが先読み時点・外部のFILE位置は現行streamと異なり、入力方式の混用は対象外。

## 正しさの検証

`extended_boundary_results.json`: 36構成、計1,640,700項目に合格。
GCC15.2/Clang21のchecked/skip、サイズ予約/mmapを無効にする標準経路、Clang ASan+UBSanを含む。
独立期待値と現行実装の両方に照合し、以下を確認した。

- 8/16/32/64bit符号あり/なし、bool、最小/最大、負数、20桁超、先頭0、invalid時の保持。
- 空・容量ちょうど・容量前後のEOF、全256byte、長い文字列、nan/inf/負の0/浮動変換失敗。
- FILEの非ゼロ開始位置、stdio内部に既読bufferがある状態、非seekable pipe、所有権維持。

## 再現

基点は `/tmp/sirkit_fastest_review_20261113/bulk_input`。
`environment.json` にOS/CPU/compiler、各 `sources.json` に提出URL、凍結全文と入力のpath/SHA/bytes、
`results/<ID>.json` に全サンプル・出力SHA・中央値・RSSを保存。
本体/main/出力を除いたframe SHAも残した。

```sh
python3 /tmp/sirkit_fastest_review_20261113/bulk_input/extended_tests.py
SIRKIT_BENCH_RESULT_DIR=results_repeat python3 /tmp/sirkit_fastest_review_20261113/bulk_input/benchmark.py
SIRKIT_BENCH_RESULT_DIR=results_repeat python3 /tmp/sirkit_fastest_review_20261113/bulk_input/hinted/benchmark.py
SIRKIT_BENCH_RESULT_DIR=results_repeat python3 /tmp/sirkit_fastest_review_20261113/bulk_input/local_cursor/benchmark.py
SIRKIT_BENCH_RESULT_DIR=results_repeat python3 /tmp/sirkit_fastest_review_20261113/bulk_input/mapped/benchmark.py
python3 /tmp/sirkit_fastest_review_20261113/bulk_input/mapped/probe.py
```

同じCPU10で同時に複数の計時を実行しない。通常のresultsは初回原データとして保持する。
入力原データはsources.jsonの絶対path。LCA/HLD生成器は `../lca_hld/generate_inputs.py`、
composite公式worst再現は `../lca_hld/official_worst_benchmark.py`。
他Graphは `../other_lc/` の親が固定した入力をそのまま使用。
統合JSONは `review.json`。候補単体header/classと生成・計時・テストのscriptも各ディレクトリに保存した。
