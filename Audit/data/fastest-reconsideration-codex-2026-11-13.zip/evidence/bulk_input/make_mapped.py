from pathlib import Path
import shutil
W=Path('/tmp/sirkit_fastest_review_20261113/bulk_input');H=W/'local_cursor';L=W/'mapped';L.mkdir(exist_ok=True)
s=(H/'VerifyInput.cpp').read_text();s=s.replace('class VerifyInput {','''#if defined(__linux__) && !defined(SIRKIT_DISABLE_MMAP_INPUT)
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#endif
class VerifyInput {''',1)
s=s.replace('    std::unique_ptr<unsigned char[]> storage_;','''    std::unique_ptr<unsigned char[]> storage_;
#if defined(__linux__) && !defined(SIRKIT_DISABLE_MMAP_INPUT)
    struct MappingDeleter {
        std::size_t length = 0;
        void operator()(unsigned char* pointer) const noexcept {
            if (pointer != nullptr) ::munmap(pointer, length);
        }
    };
    std::unique_ptr<unsigned char, MappingDeleter> mapping_{nullptr, MappingDeleter{}};
#endif''',1)
a=s.index('    void load(std::FILE* file) {')
s=s[:a]+'''#if defined(__linux__) && !defined(SIRKIT_DISABLE_MMAP_INPUT)
    bool try_map(std::FILE* file) {
        struct stat info;
        const auto position = std::ftell(file);
        const int fd = ::fileno(file);
        if (position < 0 || fd < 0 || ::fstat(fd, &info) != 0
            || !S_ISREG(info.st_mode) || info.st_size <= position) return false;
        const auto remaining = static_cast<std::uintmax_t>(info.st_size)
                             - static_cast<std::uintmax_t>(position);
        if (remaining > input_limit()) throw std::length_error("VerifyInput: input too large");
        const auto page_size = ::sysconf(_SC_PAGESIZE);
        if (page_size <= 0) return false;
        const auto prefix = static_cast<std::uintmax_t>(position) % static_cast<std::uintmax_t>(page_size);
        if (prefix > input_limit() - remaining) return false;
        const auto length = static_cast<std::size_t>(remaining + prefix);
        const auto offset = static_cast<off_t>(static_cast<std::uintmax_t>(position) - prefix);
        void* const region = ::mmap(nullptr, length, PROT_READ, MAP_PRIVATE, fd, offset);
        if (region == MAP_FAILED) return false;
        mapping_ = {static_cast<unsigned char*>(region), MappingDeleter{length}};
        cursor_ = mapping_.get() + static_cast<std::size_t>(prefix);
        end_ = cursor_ + static_cast<std::size_t>(remaining);
        return true;
    }
#endif
'''+s[a:]
s=s.replace('    void load(std::FILE* file) {','''    void load(std::FILE* file) {
#if defined(__linux__) && !defined(SIRKIT_DISABLE_MMAP_INPUT)
        if (try_map(file)) return;
#endif''',1)
old='''        while (*cursor_ <= ' ') {
            if (cursor_ == end_) { good_ = false; return EOF; }
            ++cursor_;
        }
        return *cursor_;'''
new='''        while (cursor_ != end_ && *cursor_ <= ' ') ++cursor_;
        if (cursor_ == end_) { good_ = false; return EOF; }
        return *cursor_;'''
assert old in s;s=s.replace(old,new)
s=s.replace("while (*cursor == '0')", "while (cursor != end_ && *cursor == '0')").replace("while (static_cast<unsigned>(*cursor - '0') < 10)", "while (cursor != end_ && static_cast<unsigned>(*cursor - '0') < 10)").replace("while (*cursor_ > ' ')", "while (cursor_ != end_ && *cursor_ > ' ')")
(L/'VerifyInput.cpp').write_text(s)
header=(H/'bulk_fast_io.hpp').read_text();old=(H/'VerifyInput.cpp').read_text();assert old in header;header=header.replace(old,s);(L/'bulk_fast_io.hpp').write_text(header)
for name in ['baseline_fast_io.hpp','boundary_test.cpp']:shutil.copyfile(H/name,L/name)
for name in ['test.py','freeze.py','benchmark.py']:(L/name).write_text((H/name).read_text().replace('bulk_input/local_cursor','bulk_input/mapped'))
print(L)
