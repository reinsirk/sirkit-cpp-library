from pathlib import Path
import hashlib,json,re
ROOT=Path('/tmp/sirkit_fastest_review_20261113');W=ROOT/'bulk_input/local_cursor'
(W/'programs').mkdir(exist_ok=True);header=(W/'baseline_fast_io.hpp').read_text();a=header.index('class VerifyInput {');b=header.index('// VerifyOutput(file=stdout)');old_class=header[a:b].rstrip();new_class='#include <memory>\n#include <utility>\n'+(W/'VerifyInput.cpp').read_text().rstrip();entries={}
ids=['lca','hld_jump','hld_path_prod','hld_vertex_add_path_sum','hld_path_composite','dijkstra','scc','two_sat','low_link_biconnected','low_link_two_edge']
paths={
'lca':[ROOT/'lca_hld/inputs'/f'lca_{shape}.in'for shape in ['small','random','line','binary']],
'hld_jump':[ROOT/'lca_hld/inputs'/f'jump_{shape}.in'for shape in ['small','random','line','binary']],
'hld_path_prod':[ROOT/'lca_hld/inputs'/f'sum_{shape}.in'for shape in ['small','random','line','binary']],
'hld_vertex_add_path_sum':[ROOT/'lca_hld/inputs'/f'sum_{shape}.in'for shape in ['small','random','line','binary']],
'hld_path_composite':[ROOT/'lca_hld/inputs'/f'composite_{shape}.in'for shape in ['small','random','line','binary','official_worst_00']],
'dijkstra':[ROOT/'other_lc/dijkstra'/f'{shape}.in'for shape in ['random_reachable','line_end','line_target_near']],
'scc':[ROOT/'other_lc/scc'/f'{shape}.in'for shape in ['critical_random','dag','empty']],
 'two_sat':[ROOT/'other_lc/two_sat'/f'{shape}.in'for shape in ['planted_sat','random_sparse','cycle_unsat']],
'low_link_biconnected':[ROOT/'other_lc/lowlink'/f'{shape}.in'for shape in ['random','chain','cycle']],
'low_link_two_edge':[ROOT/'other_lc/lowlink'/f'{shape}.in'for shape in ['random','chain','cycle']]}
for ident in ids:
 snapshot=json.loads((ROOT/'own_api'/f'{ident}.json').read_text());source=snapshot['source'].replace('\r\n','\n');at=source.index('class VerifyInput {');assert source[at:at+len(old_class)]==old_class,(ident,'input class differs');end=at+len(old_class);bulk=source[:at]+new_class+source[end:];assert bulk[:at]+old_class+bulk[at+len(new_class):]==source
 output=source[source.index('class VerifyOutput {'):];assert bulk[bulk.index('class VerifyOutput {'):]==output
 info={'id':ident,'submitted_url':f'https://judge.yosupo.jp/submission/{snapshot["overview"]["id"]}','only_input_class_replaced':True,'output_unchanged':True,'frame_sha256':hashlib.sha256((source[:at]+'/*INPUT CLASS*/'+source[end:]).encode()).hexdigest(),'source_pragmas':re.findall(r'^#pragma GCC [^\n]+',source,re.M),'programs':{},'inputs':[]}
 for name,s in [('base',source),('bulk',bulk)]:
  path=W/'programs'/f'{ident}_{name}.cpp';path.write_text(s);info['programs'][name]={'path':str(path),'sha256':hashlib.sha256(s.encode()).hexdigest()}
 for path in paths[ident]:
  data=path.read_bytes();info['inputs'].append({'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'small':path.stem.endswith('_small')})
 entries[ident]=info
(W/'sources.json').write_text(json.dumps(entries,indent=2)+'\n');print('frozen',len(entries),'program pairs',sum(len(e['inputs'])for e in entries.values()),'cases')
