from pathlib import Path
import json,os,subprocess
W=Path('/tmp/sirkit_fastest_review_20261113/bulk_input');os.sched_setaffinity(0,{10});rows=[]
extra='''
 for(int n:{131071,131072,131073,262143,262144,262145,1048575,1048576,1048577}) {
  number_case<std::int64_t>(std::string(n-1,' ')+"7",7,true,"unchanged");
  number_case<std::int64_t>(std::string(n,'0'),0,true,"unchanged");
  check(string_trace<BaselineInput>(std::string(n,'x'))==string_trace<BulkInput>(std::string(n,'x')));
 }
 // fgetc has filled FILE's private buffer: ftell is the logical stream position.
 {auto*f=make_file("ignore 123");for(int i=0;i<7;++i)check(std::fgetc(f)!=EOF);{BulkInput in(f);int x=0;in>>x;check(bool(in)&&x==123);}std::fclose(f);}
'''
for variant in ['', 'hinted','local_cursor','mapped']:
 D=W/variant
 original=(D/'boundary_test.cpp').read_text();at=original.index(' std::printf("PASS');(D/'extended_boundary_test.cpp').write_text(original[:at]+extra+original[at:])
 modes=[('gcc15_2','/usr/bin/g++',False,False),('gcc15_2','/usr/bin/g++',True,False),('clang','/usr/bin/clang++',False,False),('clang','/usr/bin/clang++',True,False)]
 if variant in ['local_cursor','mapped']:modes += [('clang','/usr/bin/clang++',False,True),('clang','/usr/bin/clang++',True,True)]
 for label,compiler,skip,sanitize in modes:
  fallbacks=[False,True]if variant in ['hinted','local_cursor','mapped'] else [False]
  for fallback in fallbacks:
   exe=D/f'extended_{label}_{skip}_{fallback}_{sanitize}';cmd=[compiler,'-std=c++23','-O2','-Wall','-Wextra']
   if label=='clang':cmd+=['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
   if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
   if fallback:cmd+=['-DSIRKIT_DISABLE_FILE_SIZE_HINT','-DSIRKIT_DISABLE_MMAP_INPUT']
   if sanitize:cmd+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
   cmd += [str(D/'extended_boundary_test.cpp'),'-o',str(exe)];r=subprocess.run(cmd,capture_output=True,text=True,timeout=120);assert r.returncode==0,r.stderr
   env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0');r=subprocess.run([str(exe)],stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=120,env=env);row={'variant':variant or 'standard','skip':skip,'fallback':fallback,'sanitizers':sanitize,'command':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr};rows.append(row);(W/'extended_boundary_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(variant or 'standard',label,skip,fallback,sanitize,r.returncode,r.stdout.strip(),flush=True);assert r.returncode==0,r.stderr
