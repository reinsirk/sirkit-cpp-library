// SPDX-License-Identifier: CC0-1.0
#include <algorithm>
#include <array>
#include <charconv>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <vector>

#ifndef SIRKIT_VERIFY_FAST_IO_DEFINED
#define SIRKIT_VERIFY_FAST_IO_DEFINED

// VerifyInput(file=stdin): 非所有のFILEから読む。別の入力方式と混用しない。
// >> 整数: 64bit以下の十進整数を読む。検査省略時は値域内の正しい入力を前提とする。
// >> char/string: 空白を飛ばし、1文字／空白までの文字列を読む。
// >> 浮動小数点: 十進文字列を変換する。通常のCロケールで使う。
// bool / !: 直前までの読み取りが成功しているか／失敗したかを返す。
#include <memory>
#include <utility>
#if (defined(__unix__) || defined(__APPLE__)) && !defined(SIRKIT_DISABLE_FILE_SIZE_HINT)
#include <sys/stat.h>
#include <unistd.h>
#endif
class VerifyInput {
    static constexpr std::size_t initial_capacity = 1 << 17;
    std::unique_ptr<unsigned char[]> storage_;
    unsigned char* cursor_ = nullptr; // storage_内への非所有参照。
    const unsigned char* end_ = nullptr;
    bool good_ = true;

    static constexpr std::size_t input_limit() noexcept {
        return static_cast<std::size_t>(std::numeric_limits<std::ptrdiff_t>::max()) - 1;
    }
    void load(std::FILE* file) {
        constexpr auto limit = input_limit();
        std::size_t capacity = std::min(initial_capacity, limit), size = 0;
#if (defined(__unix__) || defined(__APPLE__)) && !defined(SIRKIT_DISABLE_FILE_SIZE_HINT)
        // FILEの論理位置を使い、既にバッファ済みの入力も含めた残量だけを予約する。
        struct stat info;
        const auto position = std::ftell(file);
        if (position >= 0 && ::fstat(::fileno(file), &info) == 0
            && S_ISREG(info.st_mode) && info.st_size >= position) {
            const auto remaining = static_cast<std::uintmax_t>(info.st_size)
                                 - static_cast<std::uintmax_t>(position);
            if (remaining > limit) throw std::length_error("VerifyInput: input too large");
            capacity = std::max(capacity, static_cast<std::size_t>(remaining));
        }
#endif
        auto buffer = std::make_unique_for_overwrite<unsigned char[]>(capacity + 1);
        for (;;) {
            const auto count = std::fread(buffer.get() + size, 1, capacity - size, file);
            size += count;
            if (size != capacity) break;
            // ちょうど容量分でEOFなら、不要な倍増とコピーをしない。
            const int next = std::fgetc(file);
            if (next == EOF) break;
            if (capacity == limit) throw std::length_error("VerifyInput: input too large");
            const auto grown = capacity > limit - capacity ? limit : capacity * 2;
            auto replacement = std::make_unique_for_overwrite<unsigned char[]>(grown + 1);
            std::memcpy(replacement.get(), buffer.get(), size);
            buffer = std::move(replacement);
            capacity = grown;
            buffer[size++] = static_cast<unsigned char>(next);
        }
        buffer[size] = 0; // 数字でも空白を越える文字でもない番兵。
        storage_ = std::move(buffer);
        cursor_ = storage_.get();
        end_ = cursor_ + size;
    }
    int current() const noexcept { return cursor_ == end_ ? EOF : *cursor_; }
    int skip_space() noexcept {
        while (*cursor_ <= ' ') {
            if (cursor_ == end_) { good_ = false; return EOF; }
            ++cursor_;
        }
        return *cursor_;
    }
public:
    // FILEは非所有。構築時に残りをすべて読み、各抽出の成否は従来どおり遅延更新する。
    explicit VerifyInput(std::FILE* file = stdin) { load(file); }
    VerifyInput(const VerifyInput&) = delete;
    VerifyInput& operator=(const VerifyInput&) = delete;
    explicit operator bool() const noexcept { return good_; }
    bool operator!() const noexcept { return !good_; }

    template<class T>
        requires (std::is_integral_v<T> && sizeof(T) <= sizeof(std::uint64_t)
                  && !std::is_same_v<T, char>)
    VerifyInput& operator>>(T& result) {
        if (!good_) return *this;
        int c = skip_space();
        if (c == EOF) return *this;
        bool negative = false;
        if (c == '-' || c == '+') {
            negative = c == '-';
            ++cursor_;
            c = current();
        }
        if (c == EOF) { good_ = false; return *this; }
#ifndef SKIP_RUNTIME_CHECKS
        if (c < '0' || c > '9') { good_ = false; return *this; }
        while (*cursor_ == '0') ++cursor_;
        std::uint64_t previous = 0;
        unsigned last_digit = 0;
        std::size_t digits = 0;
#endif
        std::uint64_t value = 0;
        while (static_cast<unsigned>(*cursor_ - '0') < 10) {
#ifndef SKIP_RUNTIME_CHECKS
            previous = value;
            last_digit = static_cast<unsigned>(*cursor_ - '0');
            if (digits <= 20) ++digits;
#endif
            value = value * 10 + static_cast<unsigned>(*cursor_ - '0');
            ++cursor_;
        }
#ifndef SKIP_RUNTIME_CHECKS
        c = current();
        constexpr auto maximum = std::numeric_limits<std::uint64_t>::max();
        if ((c != EOF && c > ' ') || digits > 20
            || (digits == 20 && (previous > maximum / 10
                || (previous == maximum / 10 && last_digit > maximum % 10)))) {
            good_ = false;
            return *this;
        }
        std::uint64_t limit = static_cast<std::uint64_t>(std::numeric_limits<T>::max());
        if constexpr (std::is_signed_v<T>) limit += negative;
        else if (negative && value != 0) good_ = false;
        if (value > limit) good_ = false;
        if (!good_) return *this;
#endif
        if constexpr (std::is_signed_v<T>) {
            constexpr std::uint64_t minimum_magnitude =
                static_cast<std::uint64_t>(std::numeric_limits<T>::max()) + 1;
            result = negative
                ? (value == minimum_magnitude ? std::numeric_limits<T>::min()
                                  : static_cast<T>(-static_cast<T>(value)))
                : static_cast<T>(value);
        } else result = static_cast<T>(value);
        return *this;
    }
    VerifyInput& operator>>(char& result) {
        if (!good_) return *this;
        const int c = skip_space();
        if (c != EOF) result = static_cast<char>(*cursor_++);
        return *this;
    }
    VerifyInput& operator>>(std::string& result) {
        if (!good_ || skip_space() == EOF) return *this;
        const auto* first = cursor_;
        while (*cursor_ > ' ') ++cursor_;
        result.assign(reinterpret_cast<const char*>(first), static_cast<std::size_t>(cursor_ - first));
        return *this;
    }
    template<class T> requires std::is_floating_point_v<T>
    VerifyInput& operator>>(T& result) {
        std::string token;
        *this >> token;
        if (!good_) return *this;
#ifndef SKIP_RUNTIME_CHECKS
        char* end = nullptr;
        const long double value = std::strtold(token.c_str(), &end);
        if (end != token.c_str() + token.size()) good_ = false;
        else result = static_cast<T>(value);
#else
        result = static_cast<T>(std::strtold(token.c_str(), nullptr));
#endif
        return *this;
    }
};


// VerifyOutput(file=stdout): 非所有のFILEへ書く。破棄時にflushし、FILEは閉じない。
// << 整数/char/文字列/浮動小数点: 値を出力する。整数は64bit以下に対応する。
// fixed(digits): 浮動小数点を小数点以下digits桁で出力する（digits>=0）。
// flush(): バッファの内容をFILEへ渡す。bool / !で書き込み失敗を確認できる。
class VerifyOutput {
    static constexpr std::size_t buffer_size = 1 << 17;
    std::FILE* file_;
    std::array<char, buffer_size> buffer_;
    std::size_t size_ = 0;
    int precision_ = 6;
    bool fixed_ = false, good_ = true;

    void write(std::string_view text) {
        while (!text.empty() && good_) {
            if (size_ == buffer_.size()) flush();
            const auto count = std::min(text.size(), buffer_.size() - size_);
            std::memcpy(buffer_.data() + size_, text.data(), count);
            size_ += count;
            text.remove_prefix(count);
        }
    }

public:
    explicit VerifyOutput(std::FILE* file = stdout) : file_(file) {}
    VerifyOutput(const VerifyOutput&) = delete;
    VerifyOutput& operator=(const VerifyOutput&) = delete;
    ~VerifyOutput() { flush(); }

    explicit operator bool() const noexcept { return good_; }
    bool operator!() const noexcept { return !good_; }

    VerifyOutput& fixed(int digits) {
        if (digits < 0) throw std::invalid_argument("negative output precision");
        fixed_ = true;
        precision_ = digits;
        return *this;
    }

    void flush() noexcept {
        std::size_t written = 0;
        while (written < size_ && good_) {
            const auto count = std::fwrite(buffer_.data() + written, 1, size_ - written, file_);
            if (count == 0) good_ = false;
            written += count;
        }
        size_ = 0;
    }

    template<class T>
        requires (std::is_integral_v<T> && sizeof(T) <= sizeof(std::uint64_t)
                  && !std::is_same_v<T, char>)
    VerifyOutput& operator<<(T value) {
        if constexpr (std::is_same_v<T, bool>) return *this << static_cast<char>('0' + value);
        else {
            constexpr std::size_t capacity = std::numeric_limits<std::uint64_t>::digits10 + 3;
            if (buffer_.size() - size_ < capacity) flush();
            if (!good_) return *this;
            const auto end = std::to_chars(buffer_.data() + size_, buffer_.data() + size_ + capacity, value).ptr;
            size_ = static_cast<std::size_t>(end - buffer_.data());
            return *this;
        }
    }

    VerifyOutput& operator<<(char value) {
        if (size_ == buffer_.size()) flush();
        if (good_) buffer_[size_++] = value;
        return *this;
    }

    VerifyOutput& operator<<(std::string_view value) { write(value); return *this; }
    VerifyOutput& operator<<(const std::string& value) { write(value); return *this; }
    VerifyOutput& operator<<(const char* value) { write(value); return *this; }

    template<class T> requires std::is_floating_point_v<T>
    VerifyOutput& operator<<(T value) {
        char local[128];
        const char* format = fixed_ ? "%.*Lf" : "%.*Lg";
        const int count = std::snprintf(local, sizeof(local), format, precision_,
                                        static_cast<long double>(value));
        if (count < 0) good_ = false;
        else if (static_cast<std::size_t>(count) < sizeof(local))
            write(std::string_view(local, static_cast<std::size_t>(count)));
        else {
            std::vector<char> text(static_cast<std::size_t>(count) + 1);
            std::snprintf(text.data(), text.size(), format, precision_, static_cast<long double>(value));
            write(std::string_view(text.data(), static_cast<std::size_t>(count)));
        }
        return *this;
    }
};

inline VerifyInput verify_in;
inline VerifyOutput verify_out;
#endif
