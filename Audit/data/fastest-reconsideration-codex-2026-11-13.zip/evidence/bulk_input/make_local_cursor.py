from pathlib import Path
import shutil
W=Path('/tmp/sirkit_fastest_review_20261113/bulk_input');H=W/'hinted';L=W/'local_cursor';L.mkdir(exist_ok=True)
s=(H/'VerifyInput.cpp').read_text();a=s.index('        bool negative = false;');b=s.index('    VerifyInput& operator>>(char& result)');part=s[a:b];part='        auto* cursor = cursor_;\n'+part;part=part.replace('++cursor_;','++cursor;').replace('*cursor_','*cursor').replace('c = current();','c = cursor == end_ ? EOF : *cursor;');part=part.replace('        if constexpr (std::is_signed_v<T>) {\n            constexpr std::uint64_t minimum_magnitude', '        cursor_ = cursor;\n        if constexpr (std::is_signed_v<T>) {\n            constexpr std::uint64_t minimum_magnitude');s=s[:a]+part+s[b:];(L/'VerifyInput.cpp').write_text(s)
header=(H/'bulk_fast_io.hpp').read_text();old=(H/'VerifyInput.cpp').read_text();assert old in header;header=header.replace(old,s);(L/'bulk_fast_io.hpp').write_text(header)
for name in ['baseline_fast_io.hpp','boundary_test.cpp']:shutil.copyfile(H/name,L/name)
for name in ['test.py','freeze.py','benchmark.py']:(L/name).write_text((H/name).read_text().replace("bulk_input/hinted","bulk_input/local_cursor"))
print(L)
