from pathlib import Path
import shutil
W=Path('/tmp/sirkit_fastest_review_20261113/bulk_input');H=W/'hinted';H.mkdir(exist_ok=True)
includes='''#include <memory>
#include <utility>
#if (defined(__unix__) || defined(__APPLE__)) && !defined(SIRKIT_DISABLE_FILE_SIZE_HINT)
#include <sys/stat.h>
#include <unistd.h>
#endif
'''
s=(W/'VerifyInput.cpp').read_text()
old='        std::size_t capacity = std::min(initial_capacity, limit), size = 0;'
new=old+'''
#if (defined(__unix__) || defined(__APPLE__)) && !defined(SIRKIT_DISABLE_FILE_SIZE_HINT)
        // FILEの論理位置を使い、既にバッファ済みの入力も含めた残量だけを予約する。
        struct stat info;
        const auto position = std::ftell(file);
        if (position >= 0 && ::fstat(::fileno(file), &info) == 0
            && S_ISREG(info.st_mode) && info.st_size >= position) {
            const auto remaining = static_cast<std::uintmax_t>(info.st_size)
                                 - static_cast<std::uintmax_t>(position);
            if (remaining > limit) throw std::length_error("VerifyInput: input too large");
            capacity = std::max(capacity, static_cast<std::size_t>(remaining));
        }
#endif'''
assert old in s;s=s.replace(old,new)
(H/'VerifyInput.cpp').write_text(includes+s)
base=(W/'baseline_fast_io.hpp').read_text();a=base.index('class VerifyInput {');b=base.index('// VerifyOutput(file=stdout)');header=base[:a]+includes+s+'\n\n'+base[b:];(H/'bulk_fast_io.hpp').write_text(header)
for name in ['baseline_fast_io.hpp','boundary_test.cpp']:shutil.copyfile(W/name,H/name)
for name in ['test.py','freeze.py','benchmark.py']:
 t=(W/name).read_text().replace("W=ROOT/'bulk_input'","W=ROOT/'bulk_input/hinted'").replace("Path('/tmp/sirkit_fastest_review_20261113/bulk_input')","Path('/tmp/sirkit_fastest_review_20261113/bulk_input/hinted')")
 (H/name).write_text(t)
print(H)
