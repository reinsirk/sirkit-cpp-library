#include <memory>
#include <utility>
#if (defined(__unix__) || defined(__APPLE__)) && !defined(SIRKIT_DISABLE_FILE_SIZE_HINT)
#include <sys/stat.h>
#include <unistd.h>
#endif
#if defined(__linux__) && !defined(SIRKIT_DISABLE_MMAP_INPUT)
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#endif
class VerifyInput {
    static constexpr std::size_t initial_capacity = 1 << 17;
    std::unique_ptr<unsigned char[]> storage_;
#if defined(__linux__) && !defined(SIRKIT_DISABLE_MMAP_INPUT)
    struct MappingDeleter {
        std::size_t length = 0;
        void operator()(unsigned char* pointer) const noexcept {
            if (pointer != nullptr) ::munmap(pointer, length);
        }
    };
    std::unique_ptr<unsigned char, MappingDeleter> mapping_{nullptr, MappingDeleter{}};
#endif
    unsigned char* cursor_ = nullptr; // storage_内への非所有参照。
    const unsigned char* end_ = nullptr;
    bool good_ = true;

    static constexpr std::size_t input_limit() noexcept {
        return static_cast<std::size_t>(std::numeric_limits<std::ptrdiff_t>::max()) - 1;
    }
#if defined(__linux__) && !defined(SIRKIT_DISABLE_MMAP_INPUT)
    bool try_map(std::FILE* file) {
        struct stat info;
        const auto position = std::ftell(file);
        const int fd = ::fileno(file);
        if (position < 0 || fd < 0 || ::fstat(fd, &info) != 0
            || !S_ISREG(info.st_mode) || info.st_size <= position) return false;
        const auto remaining = static_cast<std::uintmax_t>(info.st_size)
                             - static_cast<std::uintmax_t>(position);
        if (remaining > input_limit()) throw std::length_error("VerifyInput: input too large");
        const auto page_size = ::sysconf(_SC_PAGESIZE);
        if (page_size <= 0) return false;
        const auto prefix = static_cast<std::uintmax_t>(position) % static_cast<std::uintmax_t>(page_size);
        if (prefix > input_limit() - remaining) return false;
        const auto length = static_cast<std::size_t>(remaining + prefix);
        const auto offset = static_cast<off_t>(static_cast<std::uintmax_t>(position) - prefix);
        void* const region = ::mmap(nullptr, length, PROT_READ, MAP_PRIVATE, fd, offset);
        if (region == MAP_FAILED) return false;
        mapping_ = {static_cast<unsigned char*>(region), MappingDeleter{length}};
        cursor_ = mapping_.get() + static_cast<std::size_t>(prefix);
        end_ = cursor_ + static_cast<std::size_t>(remaining);
        return true;
    }
#endif
    void load(std::FILE* file) {
#if defined(__linux__) && !defined(SIRKIT_DISABLE_MMAP_INPUT)
        if (try_map(file)) return;
#endif
        constexpr auto limit = input_limit();
        std::size_t capacity = std::min(initial_capacity, limit), size = 0;
#if (defined(__unix__) || defined(__APPLE__)) && !defined(SIRKIT_DISABLE_FILE_SIZE_HINT)
        // FILEの論理位置を使い、既にバッファ済みの入力も含めた残量だけを予約する。
        struct stat info;
        const auto position = std::ftell(file);
        if (position >= 0 && ::fstat(::fileno(file), &info) == 0
            && S_ISREG(info.st_mode) && info.st_size >= position) {
            const auto remaining = static_cast<std::uintmax_t>(info.st_size)
                                 - static_cast<std::uintmax_t>(position);
            if (remaining > limit) throw std::length_error("VerifyInput: input too large");
            capacity = std::max(capacity, static_cast<std::size_t>(remaining));
        }
#endif
        auto buffer = std::make_unique_for_overwrite<unsigned char[]>(capacity + 1);
        for (;;) {
            const auto count = std::fread(buffer.get() + size, 1, capacity - size, file);
            size += count;
            if (size != capacity) break;
            // ちょうど容量分でEOFなら、不要な倍増とコピーをしない。
            const int next = std::fgetc(file);
            if (next == EOF) break;
            if (capacity == limit) throw std::length_error("VerifyInput: input too large");
            const auto grown = capacity > limit - capacity ? limit : capacity * 2;
            auto replacement = std::make_unique_for_overwrite<unsigned char[]>(grown + 1);
            std::memcpy(replacement.get(), buffer.get(), size);
            buffer = std::move(replacement);
            capacity = grown;
            buffer[size++] = static_cast<unsigned char>(next);
        }
        buffer[size] = 0; // 数字でも空白を越える文字でもない番兵。
        storage_ = std::move(buffer);
        cursor_ = storage_.get();
        end_ = cursor_ + size;
    }
    int current() const noexcept { return cursor_ == end_ ? EOF : *cursor_; }
    int skip_space() noexcept {
        while (cursor_ != end_ && *cursor_ <= ' ') ++cursor_;
        if (cursor_ == end_) { good_ = false; return EOF; }
        return *cursor_;
    }
public:
    // FILEは非所有。構築時に残りをすべて読み、各抽出の成否は従来どおり遅延更新する。
    explicit VerifyInput(std::FILE* file = stdin) { load(file); }
    VerifyInput(const VerifyInput&) = delete;
    VerifyInput& operator=(const VerifyInput&) = delete;
    explicit operator bool() const noexcept { return good_; }
    bool operator!() const noexcept { return !good_; }

    template<class T>
        requires (std::is_integral_v<T> && sizeof(T) <= sizeof(std::uint64_t)
                  && !std::is_same_v<T, char>)
    VerifyInput& operator>>(T& result) {
        if (!good_) return *this;
        int c = skip_space();
        if (c == EOF) return *this;
        auto* cursor = cursor_;
        bool negative = false;
        if (c == '-' || c == '+') {
            negative = c == '-';
            ++cursor;
            c = cursor == end_ ? EOF : *cursor;
        }
        if (c == EOF) { good_ = false; return *this; }
#ifndef SKIP_RUNTIME_CHECKS
        if (c < '0' || c > '9') { good_ = false; return *this; }
        while (cursor != end_ && *cursor == '0') ++cursor;
        std::uint64_t previous = 0;
        unsigned last_digit = 0;
        std::size_t digits = 0;
#endif
        std::uint64_t value = 0;
        while (cursor != end_ && static_cast<unsigned>(*cursor - '0') < 10) {
#ifndef SKIP_RUNTIME_CHECKS
            previous = value;
            last_digit = static_cast<unsigned>(*cursor - '0');
            if (digits <= 20) ++digits;
#endif
            value = value * 10 + static_cast<unsigned>(*cursor - '0');
            ++cursor;
        }
#ifndef SKIP_RUNTIME_CHECKS
        c = cursor == end_ ? EOF : *cursor;
        constexpr auto maximum = std::numeric_limits<std::uint64_t>::max();
        if ((c != EOF && c > ' ') || digits > 20
            || (digits == 20 && (previous > maximum / 10
                || (previous == maximum / 10 && last_digit > maximum % 10)))) {
            good_ = false;
            return *this;
        }
        std::uint64_t limit = static_cast<std::uint64_t>(std::numeric_limits<T>::max());
        if constexpr (std::is_signed_v<T>) limit += negative;
        else if (negative && value != 0) good_ = false;
        if (value > limit) good_ = false;
        if (!good_) return *this;
#endif
        cursor_ = cursor;
        if constexpr (std::is_signed_v<T>) {
            constexpr std::uint64_t minimum_magnitude =
                static_cast<std::uint64_t>(std::numeric_limits<T>::max()) + 1;
            result = negative
                ? (value == minimum_magnitude ? std::numeric_limits<T>::min()
                                  : static_cast<T>(-static_cast<T>(value)))
                : static_cast<T>(value);
        } else result = static_cast<T>(value);
        return *this;
    }
    VerifyInput& operator>>(char& result) {
        if (!good_) return *this;
        const int c = skip_space();
        if (c != EOF) result = static_cast<char>(*cursor_++);
        return *this;
    }
    VerifyInput& operator>>(std::string& result) {
        if (!good_ || skip_space() == EOF) return *this;
        const auto* first = cursor_;
        while (cursor_ != end_ && *cursor_ > ' ') ++cursor_;
        result.assign(reinterpret_cast<const char*>(first), static_cast<std::size_t>(cursor_ - first));
        return *this;
    }
    template<class T> requires std::is_floating_point_v<T>
    VerifyInput& operator>>(T& result) {
        std::string token;
        *this >> token;
        if (!good_) return *this;
#ifndef SKIP_RUNTIME_CHECKS
        char* end = nullptr;
        const long double value = std::strtold(token.c_str(), &end);
        if (end != token.c_str() + token.size()) good_ = false;
        else result = static_cast<T>(value);
#else
        result = static_cast<T>(std::strtold(token.c_str(), nullptr));
#endif
        return *this;
    }
};
