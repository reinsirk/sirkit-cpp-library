from pathlib import Path
import json,os,subprocess,time
W=Path('/tmp/sirkit_fastest_review_20261113/bulk_input/mapped');os.sched_setaffinity(0,{10});rows=[]
for compiler,label in [('/usr/bin/g++','gcc15_2'),('/usr/bin/clang++','clang')]:
 for skip in [False,True]:
  exe=W/f'test_{label}_{skip}';cmd=[compiler,'-std=c++23','-O2','-Wall','-Wextra']
  if label=='clang':cmd+=['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
  if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
  cmd+=[str(W/'boundary_test.cpp'),'-o',str(exe)];built=subprocess.run(cmd,capture_output=True,text=True,timeout=120);assert built.returncode==0,built.stderr;begin=time.perf_counter();run=subprocess.run([str(exe)],stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=120);rows.append({'compiler':compiler,'skip_runtime_checks':skip,'command':cmd,'diagnostics':built.stderr,'returncode':run.returncode,'stdout':run.stdout,'stderr':run.stderr,'seconds':time.perf_counter()-begin});print(label,skip,run.returncode,run.stdout,run.stderr,flush=True)
(W/'boundary_results.json').write_text(json.dumps(rows,indent=2)+'\n')
assert all(r['returncode']==0 for r in rows)
