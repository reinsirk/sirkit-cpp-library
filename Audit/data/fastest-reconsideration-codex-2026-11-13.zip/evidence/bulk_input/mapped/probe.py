from pathlib import Path
import json,subprocess
W=Path('/tmp/sirkit_fastest_review_20261113/bulk_input/mapped');source=(W/'programs/lca_bulk.cpp').read_text();source=source.replace('if (pointer != nullptr) ::munmap(pointer, length);','if (pointer != nullptr) { std::fprintf(stderr,"unmap %zu bytes\\n",length); ::munmap(pointer, length); }');old='        end_ = cursor_ + static_cast<std::size_t>(remaining);\n        return true;';assert old in source;source=source.replace(old,'        end_ = cursor_ + static_cast<std::size_t>(remaining);\n        std::fprintf(stderr,"map-success %zu bytes\\n",length);\n        return true;');(W/'probe.cpp').write_text(source);cmd=['/usr/bin/g++','-std=c++23','-O2',str(W/'probe.cpp'),'-o',str(W/'probe')];subprocess.run(cmd,check=True,capture_output=True,timeout=120);p=Path('/tmp/sirkit_fastest_review_20261113/lca_hld/inputs/lca_small.in');rows=[]
for mode in ['regular','pipe']:
 if mode=='regular':
  with p.open('rb')as f:r=subprocess.run([str(W/'probe')],stdin=f,capture_output=True,check=True)
 else:r=subprocess.run([str(W/'probe')],input=p.read_bytes(),capture_output=True,check=True)
 assert r.stdout.split()==p.with_suffix('.expected').read_bytes().split();rows.append({'mode':mode,'diagnostic_stderr':r.stderr.decode(),'output_matches_independent_model':True});assert (b'map-success' in r.stderr)==(mode=='regular');assert (b'unmap' in r.stderr)==(mode=='regular')
(W/'probe.json').write_text(json.dumps({'command':cmd,'note':'Untimed diagnostic source adds stderr markers only; benchmark source/header unchanged; strace unavailable due environment ptrace restriction','results':rows},indent=2)+'\n');print(rows)
