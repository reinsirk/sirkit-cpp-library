from pathlib import Path
import hashlib,json,os,resource,statistics,subprocess,time
W=Path('/tmp/sirkit_fastest_review_20261113/bulk_input');os.sched_setaffinity(0,{10});resource.setrlimit(resource.RLIMIT_STACK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY));entries=json.loads((W/'sources.json').read_text());(W/'bin').mkdir(exist_ok=True);RESULTS=W/os.environ.get('SIRKIT_BENCH_RESULT_DIR','results');RESULTS.mkdir(exist_ok=True)
for ident,entry in entries.items():
 output=RESULTS/f'{ident}.json'
 if output.exists():print('already measured',ident,flush=True);continue
 result={'id':ident,'compiler':'GCC15.2 (/usr/bin/g++)','cpu':10,'flags':['-std=c++23','-O2','-Wall','-Wextra'],'frame':entry,'builds':{},'cases':[]};binaries={}
 for name,info in entry['programs'].items():
  source=Path(info['path']);assert hashlib.sha256(source.read_bytes()).hexdigest()==info['sha256'];binary=W/'bin'/f'{ident}_{name}';cmd=['/usr/bin/g++',*result['flags'],str(source),'-o',str(binary)];r=subprocess.run(cmd,capture_output=True,text=True,timeout=120);assert r.returncode==0,(ident,name,r.stderr);binaries[name]=binary;result['builds'][name]={'command':cmd,'diagnostics':r.stderr}
 for case in entry['inputs']:
  path=Path(case['path']);assert hashlib.sha256(path.read_bytes()).hexdigest()==case['sha256'];reference=None;out_sha={}
  for name,exe in binaries.items():
   with path.open('rb')as inp:r=subprocess.run([str(exe)],stdin=inp,capture_output=True,check=True,timeout=90)
   if reference is None:reference=r.stdout
   assert r.stdout==reference,(ident,name,path,'output mismatch')
   if case['small']:assert r.stdout.split()==path.with_suffix('.expected').read_bytes().split(),(ident,name,'independent model mismatch')
   out_sha[name]=hashlib.sha256(r.stdout).hexdigest()
  samples={name:[]for name in binaries}
  for iteration in range(11):
   for name in ['base','bulk']if iteration%2==0 else['bulk','base']:
    with path.open('rb')as inp:
     begin=time.perf_counter_ns();subprocess.run([str(binaries[name])],stdin=inp,stdout=subprocess.DEVNULL,check=True);ms=(time.perf_counter_ns()-begin)/1e6
    if iteration>=2:samples[name].append(ms)
  med={name:statistics.median(values)for name,values in samples.items()};rss={}
  for name,exe in binaries.items():
   record=RESULTS/f'{ident}_{path.stem}_{name}_rss.txt'
   with path.open('rb')as inp:subprocess.run(['/usr/bin/time','-f','%M','-o',str(record),str(exe)],stdin=inp,stdout=subprocess.DEVNULL,check=True,timeout=90)
   rss[name]=int(record.read_text().strip())
  row={'input':str(path),'input_bytes':case['bytes'],'input_sha256':case['sha256'],'small':case['small'],'all_outputs_equal':True,'output_sha256':out_sha,'median_ms':med,'bulk_over_base':med['bulk']/med['base'],'samples_ms':samples,'warmup':2,'measured':9,'peak_rss_kib':rss,'bulk_extra_peak_rss_kib':rss['bulk']-rss['base']};result['cases'].append(row);print(ident,path.stem,round(row['bulk_over_base'],3),med,'rss',rss,flush=True)
 output.write_text(json.dumps(result,indent=2)+'\n')
