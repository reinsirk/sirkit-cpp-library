#include <algorithm>
#include <array>
#include <bit>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <random>
#include <string>
#include <type_traits>
#include <unistd.h>
#define VerifyInput BaselineInput
#define VerifyOutput BaselineOutput
#define verify_in unused_baseline_input
#define verify_out unused_baseline_output
#include "baseline_fast_io.hpp"
#undef VerifyInput
#undef VerifyOutput
#undef verify_in
#undef verify_out
#undef SIRKIT_VERIFY_FAST_IO_DEFINED
#define VerifyInput BulkInput
#define VerifyOutput BulkOutput
#define verify_in unused_bulk_input
#define verify_out unused_bulk_output
#include "bulk_fast_io.hpp"
#undef VerifyInput
#undef VerifyOutput
#undef verify_in
#undef verify_out
std::uint64_t checks=0;
void check(bool ok){++checks;if(!ok){std::fprintf(stderr,"boundary failure at check %llu\n",static_cast<unsigned long long>(checks));std::abort();}}
std::FILE* make_file(const std::string& text){auto*f=std::tmpfile();check(f!=nullptr);check(std::fwrite(text.data(),1,text.size(),f)==text.size());std::rewind(f);return f;}
template<class T> struct NumberOutcome{T value;bool good,failed,eof_good;T after;std::string tail;};
template<class Input,class T>NumberOutcome<T> number_read(const std::string& text){auto*f=make_file(text);NumberOutcome<T>r;{Input input(f);check(static_cast<bool>(input));check(!(!input));r.value=T{1};input>>r.value;r.good=static_cast<bool>(input);r.failed=!input;r.tail="unchanged";input>>r.tail;r.after=T{1};input>>r.after;r.eof_good=static_cast<bool>(input);char ch='?';input>>ch;check(ch=='?');}check(std::fseek(f,0,SEEK_SET)==0);std::fclose(f);return r;}
template<class T>void number_case(std::string text,T value,bool good,std::string tail="TAIL"){
 auto a=number_read<BaselineInput,T>(text),b=number_read<BulkInput,T>(text);check(a.value==b.value&&a.good==b.good&&a.failed==b.failed&&a.eof_good==b.eof_good&&a.after==b.after&&a.tail==b.tail);check(b.good==good);check(b.failed==!good);check(b.value==(good?value:T{1}));check(!b.eof_good);check(b.after==T{1});check(b.tail==(good?tail:"unchanged"));}
template<class T>std::string decimal(T x){char b[64];auto end=std::to_chars(b,b+64,x).ptr;return {b,end};}
template<class T>void integer_tests(std::mt19937_64&rng){
 for(auto value:{T{0},T{1},std::numeric_limits<T>::min(),std::numeric_limits<T>::max()}){
  auto s=decimal(value);number_case<T>(s+" TAIL",value,true);number_case<T>(" \r\n\t"+s,value,true,"unchanged");if(value>=0)number_case<T>("+"+s+" TAIL",value,true);
 }
 for(int i=0;i<250;++i){T v;if constexpr(std::is_same_v<T,bool>)v=bool(rng()&1);else{using U=std::make_unsigned_t<T>;v=std::bit_cast<T>(static_cast<U>(rng()));}number_case<T>(decimal(v)+" TAIL",v,true);}
#ifndef SKIP_RUNTIME_CHECKS
 for(auto s:{"", " \n\t", "+", "-", "++1", "--1", "x", "12junk", "18446744073709551616", "99999999999999999999999999999999999999"})number_case<T>(s,T{},false);
 if constexpr(std::is_unsigned_v<T>)number_case<T>("-1 TAIL",T{},false);
 number_case<T>(std::string(400000,'0')+"1 TAIL",T{1},true);
 number_case<T>("-"+std::string(400000,'0')+" TAIL",T{0},true);
#endif
}
// bool is not supported by to_chars: cover it directly.
void bool_tests(){for(auto s:{"0 TAIL","+0 TAIL","-0 TAIL","000 TAIL"})number_case<bool>(s,false,true);for(auto s:{"1 TAIL","+1 TAIL","001 TAIL"})number_case<bool>(s,true,true);
#ifndef SKIP_RUNTIME_CHECKS
 for(auto s:{"2 TAIL","-1 TAIL","true TAIL"})number_case<bool>(s,false,false);
#endif
}
template<class Input>std::string character_trace(const std::string&text){auto*f=make_file(text);std::string result;{Input in(f);for(int i=0;i<12;++i){char c='?';in>>c;result+=static_cast<char>(static_cast<bool>(in));result+=c;}}std::fclose(f);return result;}
template<class Input>std::string string_trace(const std::string&text){auto*f=make_file(text);std::string result;{Input in(f);for(int i=0;i<12;++i){std::string s="unchanged";in>>s;result+=std::to_string(static_cast<bool>(in))+":"+std::to_string(s.size())+":"+s;}}std::fclose(f);return result;}
template<class Input>std::pair<long double,bool>float_read(const std::string&text){auto*f=make_file(text);std::pair<long double,bool>r{42,false};{Input in(f);in>>r.first;r.second=static_cast<bool>(in);}std::fclose(f);return r;}
int main(){std::mt19937_64 rng(982334113);integer_tests<std::int8_t>(rng);integer_tests<std::uint8_t>(rng);integer_tests<std::int16_t>(rng);integer_tests<std::uint16_t>(rng);integer_tests<std::int32_t>(rng);integer_tests<std::uint32_t>(rng);integer_tests<std::int64_t>(rng);integer_tests<std::uint64_t>(rng);bool_tests();
 for(int n:{0,1,2,7,8,31,32,127,128,131071,131072,131073,262143,262144,262145,1048575,1048576,1048577}){
  for(int variant=0;variant<3;++variant){std::string s(n,variant==0?' ':variant==1?'0':'x');if(variant==0)s+="-17 TAIL";else if(variant==1)s+="1 TAIL";else s+=" TAIL";
   if(variant<2)number_case<std::int64_t>(s,variant==0?-17:1,true);
   check(character_trace<BaselineInput>(s)==character_trace<BulkInput>(s));check(string_trace<BaselineInput>(s)==string_trace<BulkInput>(s));}
 }
 std::string all_bytes;for(int c=0;c<256;++c)all_bytes+=static_cast<char>(c);check(character_trace<BaselineInput>(all_bytes)==character_trace<BulkInput>(all_bytes));check(string_trace<BaselineInput>(all_bytes)==string_trace<BulkInput>(all_bytes));
 for(int i=0;i<300;++i){std::string s(rng()%400,'\0');for(char&c:s)c=static_cast<char>(rng());check(character_trace<BaselineInput>(s)==character_trace<BulkInput>(s));check(string_trace<BaselineInput>(s)==string_trace<BulkInput>(s));}
 for(auto s:{"", "  ", "-", "1.25", "-0", "+0", "3.1415926535897932384626", "1e5000", "nan", "-inf", "0x1.4p+3", "1.25x"}){auto a=float_read<BaselineInput>(s),b=float_read<BulkInput>(s);check(a.second==b.second);check((std::isnan(a.first)&&std::isnan(b.first))||a.first==b.first);if(a.first==0&&b.first==0)check(std::signbit(a.first)==std::signbit(b.first));}
 // The caller retains the FILE and can begin reading from a nonzero initial position.
 {auto*f=make_file("ignore 123");check(std::fseek(f,7,SEEK_SET)==0);{BulkInput in(f);int x=0;in>>x;check(bool(in)&&x==123);}check(std::fseek(f,0,SEEK_SET)==0);std::fclose(f);}
 // A nonseekable stream follows the same owned-buffer route.
 {int fds[2];check(::pipe(fds)==0);const char s[]="-123 WORD";check(::write(fds[1],s,sizeof(s)-1)==sizeof(s)-1);::close(fds[1]);auto*f=::fdopen(fds[0],"rb");check(f!=nullptr);{BulkInput in(f);int x=0;std::string word;in>>x>>word;check(bool(in)&&x==-123&&word=="WORD");in>>x;check(!in&&x==-123);}std::fclose(f);}
 std::printf("PASS %llu bulk/stream/independent range+EOF+all-byte+growth checks\n",static_cast<unsigned long long>(checks));}
