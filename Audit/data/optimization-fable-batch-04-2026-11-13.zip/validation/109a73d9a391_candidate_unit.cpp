#include "/tmp/sirkit_remaining_20261113/treap_main_candidates/body_fixed_seed.hpp"
// SPDX-License-Identifier: CC0-1.0

#include <cstdint>

// 列の左から順に一次関数を適用する、非可換な集約。
struct VerifyFunctionComposition {
    static constexpr std::uint64_t mod = 998244353;
    struct S { std::uint32_t a, b; };
    struct F {};
    static S op(S x, S y) {
        return {std::uint32_t(std::uint64_t(y.a) * x.a % mod),
                std::uint32_t((std::uint64_t(y.a) * x.b + y.b) % mod)};
    }
    static S e() { return {1, 0}; }
    static S mapping(F, S x) { return x; }
    static F composition(F, F) { return {}; }
    static F id() { return {}; }
};


#include <cassert>
#include <random>
#include <iostream>
#include <algorithm>
using A=VerifyFunctionComposition;
using Treap=lazy_implicit_treap<A::S,A::op,A::e,A::F,A::mapping,A::composition,A::id>;
static std::uint64_t evaluated(const std::vector<A::S>&v,int l,int r,std::uint64_t x){for(int i=l;i<r;++i)x=(std::uint64_t(v[i].a)*x+v[i].b)%A::mod;return x;}
int main(){
 std::mt19937_64 rng(77118);std::vector<A::S> ref;Treap tree;tree.reserve(256);std::size_t checks=0;
 auto check=[&](int l,int r){auto f=tree.prod(l,r);for(std::uint64_t x:{0,1,998244352}){assert((std::uint64_t(f.a)*x+f.b)%A::mod==evaluated(ref,l,r,x));++checks;}};
 for(int step=0;step<30000;++step){int n=int(ref.size()),kind=rng()%8,l=rng()%(n+1),r=rng()%(n+1);if(l>r)std::swap(l,r);
  if(n==0||((kind==0||kind==1)&&n<200)){A::S f{static_cast<decltype(A::S::a)>(step%5? rng()%A::mod:A::mod-1),static_cast<decltype(A::S::b)>(step%7?rng()%A::mod:A::mod-1)};if(kind&1){tree.push_back(f);ref.push_back(f);}else{tree.push_front(f);ref.insert(ref.begin(),f);}}
  else if(kind==2){tree.pop_front();ref.erase(ref.begin());}
  else if(kind==3){tree.pop_back();ref.pop_back();}
  else if(kind==4){tree.reverse(l,r);std::reverse(ref.begin()+l,ref.begin()+r);}
  else if(kind==5){auto copy=tree;auto moved=std::move(copy);assert(copy.empty());auto f=moved.all_prod();assert((std::uint64_t(f.a)*998244352+f.b)%A::mod==evaluated(ref,0,ref.size(),998244352));++checks;}
  else if(kind==6){tree.apply(l,r,{});}
  check(0,ref.size());n=ref.size();l=rng()%(n+1);r=rng()%(n+1);if(l>r)std::swap(l,r);check(l,r);check(l,l);assert(tree.size()==ref.size());
 }
 std::cout<<"30000 noncommutative composition/deque/reverse/empty/copy/move operations, checks="<<checks<<'\n';
}
