# Treap main2候補

* dequeのSをuint32x2へ縮める案は採用推奨。実NodeはGCC/Clangとも80→56B、非compactのまま。3seedでGCC成長/前挿入は約1〜2%短縮、低占有は誤差内。Clangは約6〜10%短縮し、50万queryでも維持した。
* affine加算の条件減算は不採用。64B compact経路は維持し正しさも通ったが、GCC random約8%・退化約9%回帰。Clangの改善と両立しない。

本体と共通IOは固定し、Tree優先度seedだけ両比較へ同じ値を注入した。候補actionを直接使う独立vector16構成と、実mainのchecked/skip/default/fallback32構成（Python small/境界64出力比較）は全成功。製品のprivate Node公開APIは追加していない。repoは未編集。

[全資料](final_report.json)。各driver候補と詳細測定は各IDのフォルダへ保存した。

親がdeque候補driverを採用した。採用後の実pragma3設定比較も全出力一致し、通常randomでO3が最良、他ケースはunrollと小差にとどまるため現O3を維持する。[最終設定比較](deque_flags/recommendations.json)。製品の時計seed・本体・IOは維持されている。
