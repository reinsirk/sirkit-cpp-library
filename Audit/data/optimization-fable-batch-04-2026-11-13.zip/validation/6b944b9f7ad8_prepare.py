from pathlib import Path
import json,sys,hashlib,shutil,random
R=Path('/home/reinsirk/Atcoder_Env');W=Path(__file__).parent;sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
body=((W/'body_original.hpp') if (W/'body_original.hpp').exists() else R/'DataStructure/implicit_treap.cpp').read_text();needle='return static_cast<std::uint64_t>(std::chrono::steady_clock::now().time_since_epoch().count());';assert body.count(needle)==1;controlled=body.replace(needle,'return UINT64_C(0x89157139d9aa61c5);');(W/'body_original.hpp').write_text(body);(W/'body_fixed_seed.hpp').write_text(controlled);metadata=[]
for ident in ['implicit_treap_deque','implicit_treap_affine']:
 d=W/ident;d.mkdir(exist_ok=True);(d/'sources').mkdir(exist_ok=True);(d/'inputs').mkdir(exist_ok=True)
 e=next(e for e in pv.collect() if e['id']==ident);old=((d/'baseline_driver.cpp') if (d/'baseline_driver.cpp').exists() else R/e['driver']).read_text()
 if ident.endswith('deque'):
  candidate=old.replace('static constexpr std::int64_t mod','static constexpr std::uint64_t mod').replace('struct S { std::int64_t a, b; };','struct S { std::uint32_t a, b; };').replace('return {y.a * x.a % mod, (y.a * x.b + y.b) % mod};','return {std::uint32_t(std::uint64_t(y.a) * x.a % mod),\n                std::uint32_t((std::uint64_t(y.a) * x.b + y.b) % mod)};').replace('(f.a * x + f.b) % A::mod','(std::uint64_t(f.a) * x + f.b) % A::mod')
 else:
  candidate=old.replace('static S op(S x, S y) { return {(x.sum + y.sum) % mod, x.count + y.count}; }','static S op(S x, S y) {\n        const std::int64_t sum = x.sum + y.sum;\n        return {sum >= mod ? sum - mod : sum, x.count + y.count};\n    }')
 assert old!=candidate
 (d/'baseline_driver.cpp').write_text(old);(d/'candidate_driver.cpp').write_text(candidate);hashes={}
 for label,driver in [('baseline',old),('candidate',candidate)]:
  hashes[label]={}
  for skip in [False,True]:
   src=pv.render(e,skip_runtime_checks=skip,source_overrides={'DataStructure/implicit_treap.cpp':controlled.encode()},driver_override=driver)[0];p=d/'sources'/f'{label}_{"skip" if skip else "checked"}.cpp';p.write_bytes(src);hashes[label][str(skip)]=hashlib.sha256(src).hexdigest()
 for p in (Path('/tmp/sirkit_remaining_20261113/data/inputs')/ident).glob('*'):shutil.copyfile(p,d/'inputs'/p.name)
 metadata.append({'id':ident,'entry':e,'baseline_driver_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_driver_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'sources_sha256':hashes})
(W/'metadata.json').write_text(json.dumps({'original_body_sha256':hashlib.sha256(body.encode()).hexdigest(),'controlled_body_sha256':hashlib.sha256(controlled.encode()).hexdigest(),'seed':'0x89157139d9aa61c5','scope':'Same one fixed treap seed injected into both temporary benchmark/validation full programs; repository library unchanged. Only drivers differ between baseline and candidate.','programs':metadata},indent=2)+'\n')
# Fixed low occupancy control: many operations, at most2nodes; q reservation unchanged.
rng=random.Random(91881);d=W/'implicit_treap_deque';q=150000;ops=[]
for i in range(q//5):
 a,b=rng.randrange(998244353),rng.randrange(998244353);ops += [f'0 {a} {b}',f'1 {b} {a}',f'4 {998244352}', '2','3']
(d/'inputs/low_occupancy.in').write_text(str(len(ops))+'\n'+'\n'.join(ops)+'\n')

def make_large_deque_inputs():
    rng=random.Random(331169);q=500000;mod=998244353;d=W/'implicit_treap_deque/inputs'
    for kind in ['large_growth','large_prepend']:
        length=0
        with (d/(kind+'.in')).open('w') as f:
            f.write(str(q)+'\n')
            for i in range(q):
                t=(0 if i<q//2 else 4) if kind=='large_prepend' else [0,1,0,1,2,3,4,4][rng.randrange(8)]
                if length==0:t=0
                if t<2:f.write(f'{t} {rng.randrange(mod)} {rng.randrange(mod)}\n');length+=1
                elif t<4:f.write(str(t)+'\n');length-=1
                else:f.write(f'4 {rng.randrange(mod)}\n')
make_large_deque_inputs()
