from pathlib import Path
import subprocess,json,hashlib,random
W=Path(__file__).parent;rows=[];(W/'bin').mkdir(exist_ok=True);MOD=998244353
# Each driver candidate uses its exact action definition in a direct-vector oracle.
import sys
if '--main-only' not in sys.argv:
 for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for mode,flags in [('checked',[]),('skip',['-DSKIP_RUNTIME_CHECKS']),('standard_checked',['-DSIRKIT_DISABLE_SIMD']),('standard_skip',['-DSKIP_RUNTIME_CHECKS','-DSIRKIT_DISABLE_SIMD'])]:
   for ident in ['implicit_treap_deque','implicit_treap_affine']:
    src=W/ident/'candidate_unit.cpp';exe=W/'bin'/f'{cc}_{mode}_{ident}_unit';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',*flags,str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','11',str(exe)],capture_output=True,text=True);rows.append({'kind':'unit','compiler':cc,'mode':mode,'id':ident,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'passed':p.returncode==0,'stdout':p.stdout,'stderr':p.stderr});(W/'test_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,mode,ident,p.stdout.strip()[:150],flush=True);assert p.returncode==0,p.stderr

if '--main-only' in sys.argv:
 for ident in ['implicit_treap_deque','implicit_treap_affine']:
  d=W/ident
  if ident.endswith('deque'):
   ops=['4 998244352','0 998244352 998244352','4 998244352','1 0 998244352','4 998244352','2','4 998244352','3','4 998244352','0 2 3','1 5 7','4 11','2','3','4 11'];data=str(len(ops))+'\n'+'\n'.join(ops)+'\n'
  else:
   ops=['4 0 0','4 0 7','3 0 0 998244352 998244352','2 0 0','3 0 7 998244352 998244352','4 0 7','2 0 7','0 0 998244352','4 0 8','1 7','3 1 7 0 998244352','4 0 7','4 7 7'];data=f'7 {len(ops)}\n'+' '.join(['998244352']*7)+'\n'+'\n'.join(ops)+'\n'
  (d/'inputs/boundary.in').write_text(data)
 def model(ident,inp):
  lines=inp.read_text().splitlines();values=[];out=[]
  if ident.endswith('affine'):values=list(map(int,lines[1].split()));ops=lines[2:]
  else:ops=lines[1:]
  for line in ops:
   a=list(map(int,line.split()));t=a[0]
   if ident.endswith('deque'):
    if t==0:values.insert(0,(a[1],a[2]))
    elif t==1:values.append((a[1],a[2]))
    elif t==2:values.pop(0)
    elif t==3:values.pop()
    else:
     x=a[1]
     for p,q in values:x=(p*x+q)%MOD
     out.append(x)
   else:
    l=a[1]
    if t==0:values.insert(l,a[2])
    elif t==1:values.pop(l)
    elif t==2:values[l:a[2]]=values[l:a[2]][::-1]
    elif t==3:
     r,b,c=a[2:];values[l:r]=[(b*x+c)%MOD for x in values[l:r]]
    else:out.append(sum(values[l:a[2]])%MOD)
  return ''.join(str(x)+'\n' for x in out).encode()
 for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for mode,flags,skip in [('checked',[],False),('skip',[],True),('standard_checked',['-DSIRKIT_DISABLE_SIMD'],False),('standard_skip',['-DSIRKIT_DISABLE_SIMD'],True)]:
   for ident in ['implicit_treap_deque','implicit_treap_affine']:
    for label in ['baseline','candidate']:
     src=W/ident/'sources'/f'{label}_{"skip" if skip else "checked"}.cpp';exe=W/'bin'/f'{cc}_{mode}_{ident}_{label}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',*flags,str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;checks=[]
     for name in ['small','boundary']:
      inp=W/ident/'inputs'/f'{name}.in';data=inp.read_bytes();expected=model(ident,inp);p=subprocess.run(['taskset','-c','11',str(exe)],input=data,capture_output=True);ok=p.returncode==0 and p.stdout==expected;assert ok,(ident,label,name,p.stdout,p.stderr);checks.append({'case':name,'input_sha256':hashlib.sha256(data).hexdigest(),'output_sha256':hashlib.sha256(expected).hexdigest(),'python_vector_equal':True})
     rows.append({'compiler':cc,'mode':mode,'id':ident,'label':label,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'passed':True,'cases':checks});(W/'main_test_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,mode,ident,label,'Python small/boundary PASS',flush=True)
