# Rollback Union Find main：採用推奨

現行head/next版から、葉unite+undoとquery/rootのexitフレームだけを省略。本体・共通I/O・compiler設定は固定。repo未適用。

| compiler | input | 初回比 | 確認比 |
| --- | --- | ---: | ---: |
| gcc | random | 0.9666 | 0.9667 |
| gcc | degenerate | 0.9597 | 0.9823 |
| gcc | line | 1.0085 | 1.0011 |
| gcc | star | 0.9479 | 0.9626 |
| gcc | query_parent_deep | 0.9639 | 0.9544 |
| clang | random | 0.9319 | 0.9486 |
| clang | degenerate | 0.9384 | 0.9426 |
| clang | line | 0.9068 | 0.8659 |
| clang | star | 0.8774 | 0.8900 |
| clang | query_parent_deep | 0.9040 | 0.8984 |

比は候補/現行。CPU12、GCC15.2/Clang21、CLI O2と現行GCC O3 pragma。同IOで初回2warm+9交互、確認は開始順反転2warm+15交互。GCC lineはほぼ同等。他の主要入力は両回で短縮。query_parent_deepは通常契約より強いローカル補足。

GCC/Clang×checked/skip×baseline/candidate計8構成で295小入力（root/union親187、query親108）を独立Python永続ラベルモデルへ照合。n1/自己/重複union/葉/深鎖/分岐を含む。6万query親深鎖も同モデルに一致し、line/starは閉形式に一致。

sameはconstで圧縮・履歴更新なし。非葉uniteは成功/失敗にかかわらず履歴1件を作るため、exit1件でundoを1回。葉union版は参照する子も出力もなく、結果が観測されない。詳しい不変条件はcorrectness_notes.md。
