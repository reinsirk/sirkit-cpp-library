# Rollback mainのGCC設定：両方O3維持

採用済みmain、本体、I/O、検査設定を固定し、実生成GCC pragmaだけを変更。CLIはすべてC++23 O2。CPU12、GCC15.2、2warm+7交互回転順。出力は全件bytes一致、pragmaを除くソースも一致。

| ID | input | 無pragma/O3 | unroll/O3 |
| --- | --- | ---: | ---: |
| rollback_union_find | random | 1.0779 | 1.0130 |
| rollback_union_find | line | 1.0773 | 1.0036 |
| rollback_union_find | star | 1.1374 | 1.0075 |
| rollback_weighted_union_find_rollback | random | 1.0727 | 1.0006 |
| rollback_weighted_union_find_rollback | line | 1.0557 | 1.0012 |
| rollback_weighted_union_find_rollback | star | 1.0775 | 0.9800 |

unweightedはunrollが全入力でやや遅い。weightedはstarだけ約2%短縮するがrandom/lineはほぼ同じで、微小混在のため現O3を維持。repo設定変更なし。
