from pathlib import Path
import subprocess,json,hashlib,random,time,statistics,shutil,sys
W=Path(__file__).parent;rows=[]
def save():(W/('confirmation_results.json' if '--confirm' in sys.argv else 'benchmark_results.json')).write_text(json.dumps({'cpu':11,'scope':'Only one driver change per pair; identical frozen treap body/commonI/O/generated pragma/NDEBUG/SKIP. Same paired treap seed for tree-shape control: initial0x89157139d9aa61c5; confirmation seeds are recorded per row. CLI C++23 O2;2warm+9 randomized alternating copies at one executable path. Binaries reused from successful exact driver checked/skip validation.','results':rows},indent=2)+'\n')
if '--confirm' not in sys.argv:
 for cc in ['gcc','clang']:
  for ident in ['implicit_treap_deque','implicit_treap_affine']:
   bins={k:W/'bin'/f'{cc}_skip_{ident}_{k}' for k in ['baseline','candidate']};assert all(p.exists() for p in bins.values())
   for inp in sorted((W/ident/'inputs').glob('*.in')):
    outputs={}
    for label,exe in bins.items():
     p=subprocess.run(['taskset','-c','11',str(exe)],input=inp.read_bytes(),capture_output=True);assert p.returncode==0,p.stderr;outputs[label]=p.stdout
    assert outputs['baseline']==outputs['candidate']
    raw={k:[] for k in bins};rng=random.Random(828117)
    for rep in range(11):
     order=list(raw);rng.shuffle(order)
     for label in order:
      active=W/'bin/active';shutil.copyfile(bins[label],active);active.chmod(0o755)
      with inp.open('rb') as fi,open('/dev/null','wb') as fo:
       start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','11',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
      assert p.returncode==0,p.stderr
      if rep>=2:raw[label].append(elapsed)
    med={k:statistics.median(v) for k,v in raw.items()};rows.append({'compiler':cc,'id':ident,'case':inp.stem,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'baseline_candidate_output_equal':True,'output_sha256':hashlib.sha256(outputs['baseline']).hexdigest(),'raw_ns':raw,'median_ns':med,'ratio':med['candidate']/med['baseline']});save();print(cc,ident,inp.stem,{k:round(v/1e6,3) for k,v in med.items()},flush=True)

if '--confirm' in sys.argv:
 ident='implicit_treap_deque'
 for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for seed in ['0x0000000000000001','0x9e3779b97f4a7c15']:
   bins={}
   for label in ['baseline','candidate']:
    base=(W/ident/'sources'/f'{label}_skip.cpp').read_text();needle='return UINT64_C(0x89157139d9aa61c5);';assert base.count(needle)==1;src=W/ident/'sources'/f'{label}_{seed}.cpp';src.write_text(base.replace(needle,'return UINT64_C('+seed+');'));exe=W/'bin'/f'{cc}_{label}_{seed}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;bins[label]=exe;rows.append({'kind':'build','compiler':cc,'id':ident,'seed':seed,'label':label,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'passed':True});save()
   for name in ['random','degenerate','low_occupancy','large_growth','large_prepend']:
    inp=W/ident/'inputs'/f'{name}.in';outputs={}
    for label,exe in bins.items():
     p=subprocess.run(['taskset','-c','11',str(exe)],input=inp.read_bytes(),capture_output=True);assert p.returncode==0,p.stderr;outputs[label]=p.stdout
    assert outputs['baseline']==outputs['candidate'];raw={k:[] for k in bins};rng=random.Random(817103)
    for rep in range(11):
     order=list(raw);rng.shuffle(order)
     for label in order:
      active=W/'bin/confirm_active';shutil.copyfile(bins[label],active);active.chmod(0o755)
      with inp.open('rb') as fi,open('/dev/null','wb') as fo:
       start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','11',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
      assert p.returncode==0,p.stderr
      if rep>=2:raw[label].append(elapsed)
    med={k:statistics.median(v) for k,v in raw.items()};rows.append({'kind':'timing','compiler':cc,'id':ident,'seed':seed,'case':name,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'baseline_candidate_output_equal':True,'output_sha256':hashlib.sha256(outputs['baseline']).hexdigest(),'raw_ns':raw,'median_ns':med,'ratio':med['candidate']/med['baseline']});save();print(cc,seed,name,{k:round(v/1e6,3) for k,v in med.items()},flush=True)
