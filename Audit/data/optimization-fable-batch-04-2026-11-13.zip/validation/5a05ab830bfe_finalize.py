from pathlib import Path
import json,hashlib
w=Path(__file__).resolve().parent;r=Path('/home/reinsirk/Atcoder_Env')
p=json.loads((w/'provenance.json').read_text());tests=json.loads((w/'validation_results.json').read_text());a=json.loads((w/'benchmark_results.json').read_text());b=json.loads((w/'confirmation_results.json').read_text())
workload_stats=[]
for workload in tests[0]['workloads']:
 path=Path(workload['input']);it=iter(map(int,path.read_bytes().split()));n,q=next(it),next(it);ops=[tuple(next(it)for _ in range(4))for _ in range(q)];has_child=[False]*(q+1)
 for t,k,u,v in ops:has_child[k+1]=True
 unions=sum(t==0 for t,k,u,v in ops);nonleaf=sum(t==0 and has_child[i+1] for i,(t,k,u,v)in enumerate(ops))
 workload_stats.append({'input':str(path),'n':n,'q':q,'baseline_unite_and_undo_calls':unions,'candidate_unite_and_undo_calls':nonleaf,'baseline_exit_frames':q+1,'candidate_exit_frames':nonleaf,'query_parent_refs':sum(k>=0 and ops[k][0]==1 for t,k,u,v in ops)})
report={'decision':'accept','recommendation_only':True,'repository_modified':False,'fable_invoked':False,'scope':'main_only','cpu':12,'compilers':a['compilers'],'flags':a['flags'],
 'reason':'random/退化列は両compiler・両roundで短縮、starも改善。GCCの純lineは初回+0.85%、確認+0.11%でほぼ同等、Clang lineは両roundで改善。主要random/退化の非回帰条件を満たし、出力と状態復元の独立照合に問題なし。',
 'validation':{'all_passed':all(row['passed']for row in tests),'configurations':len(tests),'small_cases_per_configuration':tests[0]['small_cases'],'root_or_union_parent_cases':tests[0]['small_official_parent_contract'],'stronger_query_parent_cases':tests[0]['small_with_query_parents'],'model':'各版に連結成分ラベルの不変tupleを持つPython永続モデル。union時に全ラベル置換、query版は親状態を継承。rollbackや木の親配列を使わない。','large':'既存smallと6万query親深鎖は永続モデル。line/starは独立閉形式。既存random/退化はbaseline出力bytes一致として区別。','results':str(w/'validation_results.json')},
 'proof':str(w/'correctness_notes.md'),'workload_stats':workload_stats,
 'measurements':a['results'],'confirmation_measurements':b['results'],'protocol':{'initial':a['protocol'],'confirmation':b['protocol']},
 'source':p,'body_still_current':all(hashlib.sha256((r/name).read_bytes()).hexdigest()==digest for name,digest in p['body_sha256'].items()),
 'baseline_driver_still_current':hashlib.sha256((r/p['entry']['driver']).read_bytes()).hexdigest()==p['driver_sha256'],
 'candidate_main':str(w/'candidate_main.cpp'),'patch':str(w/'candidate.patch'),
 'reproduction':{name:str(w/name)for name in ['prepare.py','validate.py','benchmark.py','confirm.py','small_cases.json']},
 'online_submission_performed':False,'core_optimization_claimed':False,
}
(w/'final_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
lines=['# Rollback Union Find main：採用推奨','','現行head/next版から、葉unite+undoとquery/rootのexitフレームだけを省略。本体・共通I/O・compiler設定は固定。repo未適用。','', '| compiler | input | 初回比 | 確認比 |','| --- | --- | ---: | ---: |']
for row in a['results']:
 c=next(x for x in b['results']if(x['compiler'],x['case'])==(row['compiler'],row['case']))
 lines.append(f"| {row['compiler']} | {row['case']} | {row['candidate_ratio']:.4f} | {c['candidate_ratio']:.4f} |")
lines+=['','比は候補/現行。CPU12、GCC15.2/Clang21、CLI O2と現行GCC O3 pragma。同IOで初回2warm+9交互、確認は開始順反転2warm+15交互。GCC lineはほぼ同等。他の主要入力は両回で短縮。query_parent_deepは通常契約より強いローカル補足。','', 'GCC/Clang×checked/skip×baseline/candidate計8構成で295小入力（root/union親187、query親108）を独立Python永続ラベルモデルへ照合。n1/自己/重複union/葉/深鎖/分岐を含む。6万query親深鎖も同モデルに一致し、line/starは閉形式に一致。','', 'sameはconstで圧縮・履歴更新なし。非葉uniteは成功/失敗にかかわらず履歴1件を作るため、exit1件でundoを1回。葉union版は参照する子も出力もなく、結果が観測されない。詳しい不変条件はcorrectness_notes.md。','']
(w/'summary.md').write_text('\n'.join(lines));print(json.dumps({'decision':report['decision'],'configurations':len(tests),'small_cases':tests[0]['small_cases'],'body_still_current':report['body_still_current'],'baseline_main_still_current':report['baseline_driver_still_current'],'report':str(w/'final_report.json')},indent=2))
