from pathlib import Path
import json,sys,hashlib,subprocess,random,re,time,statistics,shutil
W=Path(__file__).parent;P=W.parent;R=Path('/home/reinsirk/Atcoder_Env');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
entry=next(e for e in pv.collect() if e['id']=='implicit_treap_deque');body=(R/'DataStructure/implicit_treap.cpp').read_bytes();assert body==(P/'body_original.hpp').read_bytes();driver=(R/entry['driver']).read_bytes();assert driver==(P/'implicit_treap_deque/candidate_driver.cpp').read_bytes();fixed=(P/'body_fixed_seed.hpp').read_bytes();sources={};rows=[];bins={}
for label,option in [('O2',None),('O3','O3'),('O3_unroll','O3,unroll-loops')]:
 e=dict(entry);e.pop('gcc_optimization',None)
 if option:e['gcc_optimization']=option
 sources[label]=pv.render(e,skip_runtime_checks=True,source_overrides={'DataStructure/implicit_treap.cpp':fixed})[0]
strip=lambda s:re.sub(rb'#if defined\(__GNUC__\) && !defined\(__clang__\)\n#pragma GCC optimize\([^\n]+\)\n#endif\n',b'',s)
assert len({hashlib.sha256(strip(s)).hexdigest() for s in sources.values()})==1
report={'cpu':11,'compiler':subprocess.check_output(['/usr/bin/g++','--version'],text=True).splitlines()[0],'entry':entry,'body_original_sha256':hashlib.sha256(body).hexdigest(),'body_fixed_seed_sha256':hashlib.sha256(fixed).hexdigest(),'driver_sha256':hashlib.sha256(driver).hexdigest(),'source_sha256':{k:hashlib.sha256(v).hexdigest() for k,v in sources.items()},'nonpragma_bytes_identical':True,'scope':'Actual generated no pragma/O3/O3,unroll-loops; CLI C++23 O2 all. Same adopted uint32deque main/body/I/O/NDEBUG/SKIP and temporary fixed treap seed0x89157139d9aa61c5. Production clock seed unchanged.2warm+9 shuffled alternating fixed executable path.','results':rows}
def save():(W/'results.json').write_text(json.dumps(report,indent=2)+'\n')
for label,data in sources.items():
 src=W/(label+'.cpp');src.write_bytes(data);exe=W/label;cmd=['taskset','-c','11','/usr/bin/g++','-std=c++23','-O2',str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;bins[label]=exe;rows.append({'kind':'build','label':label,'command':cmd,'passed':True});save()
for case in ['random','large_prepend','low_occupancy']:
 inp=P/'implicit_treap_deque/inputs'/f'{case}.in';outputs={}
 for label,exe in bins.items():
  p=subprocess.run(['taskset','-c','11',str(exe)],input=inp.read_bytes(),capture_output=True);assert p.returncode==0,p.stderr;outputs[label]=p.stdout
 assert len(set(outputs.values()))==1
 raw={k:[] for k in bins};rng=random.Random(712965)
 for rep in range(11):
  order=list(raw);rng.shuffle(order)
  for label in order:
   active=W/'active';shutil.copyfile(bins[label],active);active.chmod(0o755)
   with inp.open('rb') as fi,open('/dev/null','wb') as fo:
    start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','11',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
   assert p.returncode==0,p.stderr
   if rep>=2:raw[label].append(elapsed)
 med={k:statistics.median(v) for k,v in raw.items()};rows.append({'kind':'timing','case':case,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'output_byte_identical':True,'output_sha256':hashlib.sha256(outputs['O2']).hexdigest(),'raw_ns':raw,'median_ns':med});save();print(case,{k:round(v/1e6,3) for k,v in med.items()},flush=True)
