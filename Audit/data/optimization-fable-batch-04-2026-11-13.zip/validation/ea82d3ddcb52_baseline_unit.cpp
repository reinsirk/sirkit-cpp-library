#include "/tmp/sirkit_remaining_20261113/treap_main_candidates/body_fixed_seed.hpp"
// SPDX-License-Identifier: CC0-1.0

#include <cstdint>
#include <vector>

// 問題用の法998244353での区間アフィン写像。ACLには依存しない。
struct VerifyAffineSum {
    static constexpr std::int64_t mod = 998244353;
    struct S { std::int64_t sum, count; };
    struct F { std::int64_t a, b; };
    static S op(S x, S y) { return {(x.sum + y.sum) % mod, x.count + y.count}; }
    static S e() { return {0, 0}; }
    static S mapping(F f, S x) { return {(f.a * x.sum + f.b * x.count) % mod, x.count}; }
    static F composition(F f, F g) { return {f.a * g.a % mod, (f.a * g.b + f.b) % mod}; }
    static F id() { return {1, 0}; }
};

#include <cassert>
#include <random>
#include <iostream>
using Treap=lazy_implicit_treap<VerifyAffineSum::S,VerifyAffineSum::op,VerifyAffineSum::e,VerifyAffineSum::F,VerifyAffineSum::mapping,VerifyAffineSum::composition,VerifyAffineSum::id,true>;
int main(){
{ Treap edge(std::vector<VerifyAffineSum::S>(7,{VerifyAffineSum::mod-1,1}));
 assert(edge.prod(0,0).sum==0&&edge.prod(0,7).sum==VerifyAffineSum::mod-7);
 edge.apply(0,0,{VerifyAffineSum::mod-1,VerifyAffineSum::mod-1});
 edge.apply(0,7,{VerifyAffineSum::mod-1,VerifyAffineSum::mod-1});
 assert(edge.all_prod().sum==0);edge.reverse(0,7);assert(edge.prod(7,7).sum==0); }

 std::mt19937_64 rng(371912);
 std::vector<std::int64_t> ref;std::vector<VerifyAffineSum::S> initial;
 for(int i=0;i<2048;++i){auto x=i%5==0?std::int64_t(VerifyAffineSum::mod-1):std::int64_t(rng()%VerifyAffineSum::mod);ref.push_back(x);initial.push_back({x,1});}
 Treap tree(initial);
 for(int z=0;z<50000;++z){
  int n=int(ref.size()),l=int(rng()%(n+1)),r=int(rng()%(n+1));if(l>r)std::swap(l,r);
  int kind=int(rng()%5);
  if(kind==0||n==0){auto x=std::int64_t(rng()%VerifyAffineSum::mod);ref.insert(ref.begin()+l,x);tree.insert_at(l,{x,1});}
  else if(kind==1){int k=int(rng()%n);ref.erase(ref.begin()+k);tree.erase_at(k);}
  else if(kind==2){if(z%7==0){l=0;r=n;}else if(z%7==1)l=0;else if(z%7==2)r=n;std::reverse(ref.begin()+l,ref.begin()+r);tree.reverse(l,r);}
  else if(kind==3){auto a=std::int64_t(rng()%VerifyAffineSum::mod),b=std::int64_t(rng()%VerifyAffineSum::mod);for(int i=l;i<r;++i)ref[i]=(a*ref[i]+b)%VerifyAffineSum::mod;tree.apply(l,r,{a,b});}
  else{std::int64_t sum=0;for(int i=l;i<r;++i)sum=(sum+ref[i])%VerifyAffineSum::mod;assert(tree.prod(l,r).sum==sum);}
  assert(tree.size()==int(ref.size()));
  if(z%101==0){auto v=tree.to_vector();assert(v.size()==ref.size());std::int64_t sum=0;for(std::size_t i=0;i<ref.size();++i){assert(v[i].sum==ref[i]&&v[i].count==1);sum=(sum+ref[i])%VerifyAffineSum::mod;}assert(tree.all_prod().sum==sum);}
 }
 std::cout<<"50000 affine-sum operations against an independent vector passed\n";
}
