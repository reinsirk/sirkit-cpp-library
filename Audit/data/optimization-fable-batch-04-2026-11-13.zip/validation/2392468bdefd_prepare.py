from pathlib import Path
import sys,json,hashlib,difflib
r=Path('/home/reinsirk/Atcoder_Env');w=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'Scripts'));import prepare_verify as pv
entry=next(e for e in pv.collect()if e['id']=='rollback_union_find')
base=(r/entry['driver']).read_text();body={name:(r/name).read_bytes()for name in entry['libraries']}
old='''        if(exit){if(i!=0&&queries[i][0]==0)uf.undo();continue;}
        if(i!=0){const auto& a=queries[i];if(a[0]==0)uf.unite(a[1],a[2]);else answers[i]=uf.same(a[1],a[2]);}
        stack.push_back({i,true});for(int child=head[i];child!=-1;child=next[child])stack.push_back({child,false});'''
new='''        if(exit){uf.undo();continue;}
        if(i!=0){const auto& a=queries[i];
            if(a[0]!=0)answers[i]=uf.same(a[1],a[2]);
            else if(head[i]!=-1){uf.unite(a[1],a[2]);stack.push_back({i,true});}
            else continue;}
        for(int child=head[i];child!=-1;child=next[child])stack.push_back({child,false});'''
assert old in base;candidate=base.replace(old,new)
for name,data in [('baseline_main.cpp',base),('candidate_main.cpp',candidate)]: (w/name).write_text(data)
for name,data in body.items():(w/Path(name).name).write_bytes(data)
(w/'candidate.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),candidate.splitlines(True),fromfile=entry['driver'],tofile=entry['driver'])))
report={'scope':'main_only','entry':entry,'body_sha256':{name:hashlib.sha256(data).hexdigest()for name,data in body.items()},'driver_sha256':hashlib.sha256(base.encode()).hexdigest(),'candidate_driver_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'io_sha256':hashlib.sha256((r/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest(),'sources':{}}
for variant,driver in [('baseline',base),('candidate',candidate)]:
 for mode,skip in [('checked',False),('skip',True)]:
  data,_=pv.render(entry,source_overrides=body,driver_override=driver,skip_runtime_checks=skip)
  name=variant+'_'+mode+'.cpp';(w/name).write_bytes(data);report['sources'][name]=hashlib.sha256(data).hexdigest()
(w/'provenance.json').write_text(json.dumps(report,indent=2)+'\n')
