from pathlib import Path
import subprocess,json,hashlib
W=Path(__file__).parent;rows=[];(W/'layouts').mkdir(exist_ok=True)
for ident in ['implicit_treap_deque','implicit_treap_affine']:
 for label in ['baseline','candidate']:
  src=W/ident/'sources'/f'{label}_skip.cpp'
  for cc,compiler,flags in [('gcc',['/usr/bin/g++'],['-fdump-lang-class='+str(W/'layouts'/f'{ident}_{label}_gcc.txt')]),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'],['-Xclang','-fdump-record-layouts'])]:
   cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2','-fsyntax-only',*flags,str(src)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;raw=W/'layouts'/f'{ident}_{label}_{cc}.txt'
   if cc=='clang':raw.write_text(p.stdout)
   text=raw.read_text();chunks=text.split('\n\n') if cc=='gcc' else text.split('*** Dumping AST Record Layout\n');selected=[]
   for chunk in chunks:
    if not chunk.strip():continue
    first=chunk.splitlines()[0] if cc=='gcc' else next((x for x in chunk.splitlines() if '0 |' in x),'')
    if ((first.startswith('Class lazy_implicit_treap<') if cc=='gcc' else bool(__import__('re').search(r'\| struct lazy_implicit_treap<',first))) and any(first.endswith(x) for x in ['::Node','::CompactNode','::CompactNodeLayout'])):selected.append(chunk[:3000])
   rows.append({'id':ident,'label':label,'compiler':cc,'command':cmd,'passed':True,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'raw':str(raw),'selected':selected});(W/'layout_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(ident,label,cc,len(selected),'node records',flush=True)

import re
summary=[]
for r in rows:
    sizes=[]
    for chunk in r['selected']:
        first=chunk.splitlines()[0]
        size=re.search(r'size=(\d+) align=(\d+)',chunk) if r['compiler']=='gcc' else re.search(r'\[sizeof=(\d+),.*?\balign=(\d+)',chunk,re.S)
        if size:sizes.append({'type':first.split('::')[-1],'bytes':int(size[1]),'align':int(size[2])})
    summary.append({'id':r['id'],'label':r['label'],'compiler':r['compiler'],'types':sizes})
(W/'layout_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
