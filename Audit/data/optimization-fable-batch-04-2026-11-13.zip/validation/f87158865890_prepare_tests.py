from pathlib import Path
W=Path(__file__).parent;R=Path('/home/reinsirk/Atcoder_Env')
for ident in ['implicit_treap_deque','implicit_treap_affine']:
 d=W/ident
 for label in ['baseline','candidate']:
  driver=(d/f'{label}_driver.cpp').read_text();action=driver[:driver.index('int main()')].replace('#include "Verify/current/common/fast_io.hpp"','')
  prefix='#include "'+str(W/'body_fixed_seed.hpp')+'"\n'+action
  if ident.endswith('affine'):
   raw=(R/'Verify/current/tests/implicit_treap_affine_test.cpp').read_text();main=raw[raw.index('int main()'):].replace('Affine::','VerifyAffineSum::');main=main.replace('auto x=std::int64_t(rng()%VerifyAffineSum::mod);','auto x=i%5==0?std::int64_t(VerifyAffineSum::mod-1):std::int64_t(rng()%VerifyAffineSum::mod);',1)
   alias='using Treap=lazy_implicit_treap<VerifyAffineSum::S,VerifyAffineSum::op,VerifyAffineSum::e,VerifyAffineSum::F,VerifyAffineSum::mapping,VerifyAffineSum::composition,VerifyAffineSum::id,true>;\n'
   extra='''{ Treap edge(std::vector<VerifyAffineSum::S>(7,{VerifyAffineSum::mod-1,1}));
 assert(edge.prod(0,0).sum==0&&edge.prod(0,7).sum==VerifyAffineSum::mod-7);
 edge.apply(0,0,{VerifyAffineSum::mod-1,VerifyAffineSum::mod-1});
 edge.apply(0,7,{VerifyAffineSum::mod-1,VerifyAffineSum::mod-1});
 assert(edge.all_prod().sum==0);edge.reverse(0,7);assert(edge.prod(7,7).sum==0); }
''';main=main.replace('int main(){','int main(){\n'+extra)
   text=prefix+'\n#include <cassert>\n#include <random>\n#include <iostream>\n'+alias+main
  else:
   text=prefix+'''
#include <cassert>
#include <random>
#include <iostream>
#include <algorithm>
using A=VerifyFunctionComposition;
using Treap=lazy_implicit_treap<A::S,A::op,A::e,A::F,A::mapping,A::composition,A::id>;
static std::uint64_t evaluated(const std::vector<A::S>&v,int l,int r,std::uint64_t x){for(int i=l;i<r;++i)x=(std::uint64_t(v[i].a)*x+v[i].b)%A::mod;return x;}
int main(){
 std::mt19937_64 rng(77118);std::vector<A::S> ref;Treap tree;tree.reserve(256);std::size_t checks=0;
 auto check=[&](int l,int r){auto f=tree.prod(l,r);for(std::uint64_t x:{0,1,998244352}){assert((std::uint64_t(f.a)*x+f.b)%A::mod==evaluated(ref,l,r,x));++checks;}};
 for(int step=0;step<30000;++step){int n=int(ref.size()),kind=rng()%8,l=rng()%(n+1),r=rng()%(n+1);if(l>r)std::swap(l,r);
  if(n==0||((kind==0||kind==1)&&n<200)){A::S f{static_cast<decltype(A::S::a)>(step%5? rng()%A::mod:A::mod-1),static_cast<decltype(A::S::b)>(step%7?rng()%A::mod:A::mod-1)};if(kind&1){tree.push_back(f);ref.push_back(f);}else{tree.push_front(f);ref.insert(ref.begin(),f);}}
  else if(kind==2){tree.pop_front();ref.erase(ref.begin());}
  else if(kind==3){tree.pop_back();ref.pop_back();}
  else if(kind==4){tree.reverse(l,r);std::reverse(ref.begin()+l,ref.begin()+r);}
  else if(kind==5){auto copy=tree;auto moved=std::move(copy);assert(copy.empty());auto f=moved.all_prod();assert((std::uint64_t(f.a)*998244352+f.b)%A::mod==evaluated(ref,0,ref.size(),998244352));++checks;}
  else if(kind==6){tree.apply(l,r,{});}
  check(0,ref.size());n=ref.size();l=rng()%(n+1);r=rng()%(n+1);if(l>r)std::swap(l,r);check(l,r);check(l,l);assert(tree.size()==ref.size());
 }
 std::cout<<"30000 noncommutative composition/deque/reverse/empty/copy/move operations, checks="<<checks<<'\\n';
}
'''
  (d/f'{label}_unit.cpp').write_text(text)
