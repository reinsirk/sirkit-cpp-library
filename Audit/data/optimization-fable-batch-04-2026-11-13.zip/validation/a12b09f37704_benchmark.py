from pathlib import Path
import json,hashlib,sys,re,subprocess,statistics,time,shutil
w=Path(__file__).resolve().parent;r=Path('/home/reinsirk/Atcoder_Env');d=Path('/tmp/sirkit_remaining_20261113/data/inputs')
sys.path.insert(0,str(r/'Scripts'));import prepare_verify as pv
entries={e['id']:e for e in pv.collect()}
source_dirs={'rollback_union_find':w.parent/'batch_04/rollback_main_candidate','rollback_weighted_union_find_rollback':w.parent/'batch_05/weighted_rollback_main_candidate'}
records=[];report={'compiler':subprocess.check_output(['/usr/bin/g++','--version'],text=True).splitlines()[0],'cpu':12,'scope':'Adopted current rollback mains: only actual generated GCC pragma varies; core/commonIO/main/skip/NDEBUG fixed. No repository settings changed.','protocol':'CLI C++23 O2 all variants. 2warm+7 rotating order triplets per input, same executable pathname.','programs':{},'results':records}
def save():(w/'results.json').write_text(json.dumps(report,indent=2)+'\n')
pattern=rb'#if defined\(__GNUC__\) && !defined\(__clang__\)\n#pragma GCC optimize\([^\n]*\)\n#endif\n'
for identity,previous in source_dirs.items():
 entry=entries[identity];actual=(r/entry['driver']).read_bytes()
 expected=previous/('selected_main.cpp'if'weighted'in identity else'candidate_main.cpp')
 assert actual==expected.read_bytes()
 sources={}
 for name,option in [('none',None),('O3','O3'),('O3_unroll','O3,unroll-loops')]:
  e=dict(entry);e.pop('gcc_optimization',None)
  if option:e['gcc_optimization']=option
  sources[name]=pv.render(e,skip_runtime_checks=True)[0]
 strip=lambda source:re.sub(pattern,b'',source)
 assert len({hashlib.sha256(strip(s)).hexdigest()for s in sources.values()})==1
 assert len({b'#define NDEBUG'in s for s in sources.values()})==1
 assert entry.get('gcc_optimization')=='O3'
 report['programs'][identity]={'current_setting':entry.get('gcc_optimization'),'driver_sha256':hashlib.sha256(actual).hexdigest(),'library_sha256':{name:hashlib.sha256((r/name).read_bytes()).hexdigest()for name in entry['libraries']},'shared_io_sha256':hashlib.sha256((r/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest(),'nonpragma_bytes_identical':True,'source_sha256':{name:hashlib.sha256(s).hexdigest()for name,s in sources.items()}}
 bins={}
 for name,s in sources.items():
  src=w/(identity+'_'+name+'.cpp');src.write_bytes(s);exe=w/(identity+'_'+name)
  cmd=['taskset','-c','12','/usr/bin/g++','-std=c++23','-O2',str(src),'-o',str(exe)]
  p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr
  bins[name]=exe;records.append({'kind':'build','id':identity,'variant':name,'command':cmd,'passed':True,'diagnostics':p.stderr});save()
 for case,inp in [('random',d/identity/'random.in'),('line',previous/'line.in'),('star',previous/'star.in')]:
  outputs={}
  for name,exe in bins.items():
   with inp.open('rb')as fi:p=subprocess.run(['taskset','-c','12',str(exe)],stdin=fi,capture_output=True)
   assert p.returncode==0,p.stderr;outputs[name]=p.stdout
  assert len(set(outputs.values()))==1
  raw={name:[]for name in bins};names=list(bins)
  for rep in range(9):
   offset=rep%3;order=names[offset:]+names[:offset]
   if rep%2:order.reverse()
   for name in order:
    active=w/'active';shutil.copyfile(bins[name],active);active.chmod(0o755)
    with inp.open('rb')as fi,open('/dev/null','wb')as fo:
     start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','12',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
    assert p.returncode==0,p.stderr
    if rep>=2:raw[name].append(elapsed)
  med={name:statistics.median(values)for name,values in raw.items()}
  row={'kind':'timing','id':identity,'case':case,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(outputs['none']).hexdigest(),'output_byte_identical':True,'raw_ns':raw,'median_ns':med,'ratio_to_current_O3':{name:value/med['O3']for name,value in med.items()}}
  records.append(row);save();print(identity,case,'ms',{k:round(v/1e6,3)for k,v in med.items()},'ratios',{k:round(v,4)for k,v in row['ratio_to_current_O3'].items()},flush=True)
