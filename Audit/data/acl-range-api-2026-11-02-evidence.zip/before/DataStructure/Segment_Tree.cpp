// SPDX-License-Identifier: CC0-1.0
// 参考（モノイドと区間積）: https://info.atcoder.jp/entry/algorithm_lectures/range_query_monoid_design
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/segment_tree.md
//
// API一覧
// [SegmentTree<T, Op=std::plus<T>>]
// SegmentTree(n=0, identity=T{}, op=Op{})/SegmentTree(vector<T>,identity=T{},op=Op{}): 単位元の列/列から構築。O(n+1)時間・領域。
// Op(a,b)はconst呼出可能かつ結合的、identityは左右の単位元。非可換演算も可。演算/コピーをO(1)とし、添字0始まり・区間は半開。
// size()/empty(): 要素数/空か、O(1)。get(i): const T&（T=boolは値）を返す、O(1)。参照は変更・再構築・移動で無効になり得る。
// set(i,value)/transform(i,f): 1点をvalue/f(現在値)へ更新。O(log(n+1))。prod(l,r): [l,r)を左から積算、O(log(n+1))。
// all_prod(): 全体の積へのconst T&（T=boolは値）。O(1)。空区間のprodと空列の全積はidentity。
// max_right(l,pred)/min_left(r,pred): predが真の最大の右端/最小の左端、O(log(n+1))。pred(identity)==trueと境界の単調性が前提。
// values(): 列のコピー、O(n+1)。assign(vector<T>)/reset(n)/reset(): 列を再構築/n要素/現在の長さを単位元にする。O(旧n+n+1)。
// clear()/swap(other): 空にして容量保持/内容交換。O(旧n+1)/O(1)。コピーは独立、移動元は空。演算・値のコピー等が投げた場合、内容の強い保証はしない。

#include <algorithm>
#include <cstddef>
#include <functional>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

#ifndef SIRKIT_SEGMENT_TREE_DEFINED
#define SIRKIT_SEGMENT_TREE_DEFINED
template<class T, class Op = std::plus<T>>
class SegmentTree {
    [[no_unique_address]] Op op_;
    T identity_;
    std::size_t n_ = 0, base_ = 1;
    std::vector<T> data_;
    static std::size_t leaf_base(std::size_t n) {
        if (n == 0) return 1;
        const auto limit = std::vector<T>{}.max_size() / 2;
        std::size_t base = 1;
        while (base < n) {
            if (base > limit / 2) throw std::length_error("SegmentTree: size");
            base *= 2;
        }
        if (base > limit) throw std::length_error("SegmentTree: size");
        return base;
    }
    void check_index(std::size_t i) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (i >= n_) throw std::out_of_range("SegmentTree: index");
#else
        (void)i;
#endif
    }
    void check_range(std::size_t l, std::size_t r) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (l > r || r > n_) throw std::out_of_range("SegmentTree: range");
#else
        (void)l; (void)r;
#endif
    }
    void rebuild() {
        for (auto p = base_; p > 1;) {
            --p;
            data_[p] = op_(data_[2 * p], data_[2 * p + 1]);
        }
    }
    void update_ancestors(std::size_t p) {
        for (p >>= 1; p; p >>= 1) data_[p] = op_(data_[2 * p], data_[2 * p + 1]);
    }
public:
    using const_reference = typename std::vector<T>::const_reference;
    explicit SegmentTree(std::size_t n = 0, const T& identity = T{}, Op op = Op{})
        : op_(std::move(op)), identity_(identity), n_(n), base_(leaf_base(n)),
          data_(n ? 2 * base_ : 0, identity_) {}
    explicit SegmentTree(const std::vector<T>& values, const T& identity = T{}, Op op = Op{})
        : SegmentTree(values.size(), identity, std::move(op)) {
        if (!n_) return;
        std::copy(values.begin(), values.end(), data_.begin() + base_);
        rebuild();
    }
    SegmentTree(const SegmentTree&) = default;
    SegmentTree& operator=(const SegmentTree& other) {
        if (this != &other) { SegmentTree replacement(other); swap(replacement); }
        return *this;
    }
    SegmentTree(SegmentTree&& other)
        : op_(other.op_), identity_(other.identity_), n_(other.n_), base_(other.base_), data_(std::move(other.data_)) {
        other.n_ = 0; other.base_ = 1; other.data_.clear();
    }
    SegmentTree& operator=(SegmentTree&& other) {
        if (this != &other) { SegmentTree replacement(std::move(other)); swap(replacement); }
        return *this;
    }
    std::size_t size() const noexcept { return n_; }
    bool empty() const noexcept { return n_ == 0; }
    const_reference get(std::size_t i) const { check_index(i); return data_[base_ + i]; }
    void set(std::size_t i, const T& value) {
        check_index(i);
        const auto p = base_ + i;
        data_[p] = value;
        update_ancestors(p);
    }
    template<class F> void transform(std::size_t i, F&& f) {
        check_index(i);
        const auto p = base_ + i;
        data_[p] = std::invoke(std::forward<F>(f), std::as_const(data_)[p]);
        update_ancestors(p);
    }
    T prod(std::size_t l, std::size_t r) const {
        check_range(l, r);
        T left = identity_, right = identity_;
        if (l == r) return left;
        for (l += base_, r += base_; l < r; l >>= 1, r >>= 1) {
            if (l & 1) left = op_(left, data_[l++]);
            if (r & 1) right = op_(data_[--r], right);
        }
        return op_(left, right);
    }
    const_reference all_prod() const noexcept { return n_ ? data_[1] : identity_; }
    template<class Pred> std::size_t max_right(std::size_t l, Pred pred) const {
        check_range(l, l);
#ifndef SKIP_RUNTIME_CHECKS
        if (!pred(identity_)) throw std::invalid_argument("SegmentTree: predicate(identity)");
#endif
        if (l == n_) return n_;
        T accumulated = identity_;
        auto node = base_ + l;
        while (true) {
            while (!(node & 1)) node >>= 1;
            T candidate = op_(accumulated, data_[node]);
            if (!pred(candidate)) {
                while (node < base_) {
                    node *= 2;
                    T next = op_(accumulated, data_[node]);
                    if (pred(next)) { accumulated = std::move(next); ++node; }
                }
                return std::min(n_, node - base_);
            }
            accumulated = std::move(candidate);
            ++node;
            if ((node & (node - 1)) == 0) return n_;
        }
    }
    template<class Pred> std::size_t min_left(std::size_t r, Pred pred) const {
        check_range(r, r);
#ifndef SKIP_RUNTIME_CHECKS
        if (!pred(identity_)) throw std::invalid_argument("SegmentTree: predicate(identity)");
#endif
        if (r == 0) return 0;
        T accumulated = identity_;
        auto node = base_ + r;
        while (true) {
            --node;
            while (node > 1 && (node & 1)) node >>= 1;
            T candidate = op_(data_[node], accumulated);
            if (!pred(candidate)) {
                while (node < base_) {
                    node = 2 * node + 1;
                    T next = op_(data_[node], accumulated);
                    if (pred(next)) { accumulated = std::move(next); --node; }
                }
                return node + 1 - base_;
            }
            accumulated = std::move(candidate);
            if ((node & (node - 1)) == 0) return 0;
        }
    }
    std::vector<T> values() const {
        if (!n_) return {};
        return std::vector<T>(data_.begin() + base_, data_.begin() + base_ + n_);
    }
    void assign(const std::vector<T>& values) {
        SegmentTree replacement(values, identity_, op_); swap(replacement);
    }
    void reset(std::size_t n) {
        SegmentTree replacement(n, identity_, op_); swap(replacement);
    }
    void reset() { std::fill(data_.begin(), data_.end(), identity_); }
    void clear() noexcept { data_.clear(); n_ = 0; base_ = 1; }
    void swap(SegmentTree& other) noexcept(std::is_nothrow_swappable_v<Op> && std::is_nothrow_swappable_v<T>) {
        using std::swap;
        swap(op_, other.op_); swap(identity_, other.identity_);
        swap(n_, other.n_); swap(base_, other.base_); data_.swap(other.data_);
    }
};
#endif
