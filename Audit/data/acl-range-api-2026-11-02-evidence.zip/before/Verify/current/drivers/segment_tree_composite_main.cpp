// SPDX-License-Identifier: CC0-1.0
#include "Verify/current/common/fast_io.hpp"
#include <cstdint>
#include <vector>
struct PointAffineFunction { std::uint64_t a = 1, b = 0; };
struct PointAffineComposition {
    PointAffineFunction operator()(const PointAffineFunction& left, const PointAffineFunction& right) const {
        return {left.a * right.a % 998244353, (left.b * right.a + right.b) % 998244353};
    }
};
int main() {
    int n{}, q{}; verify_in >> n >> q;
    std::vector<PointAffineFunction> a(n);
    for (auto& f : a) verify_in >> f.a >> f.b;
    SegmentTree<PointAffineFunction, PointAffineComposition> tree(a, PointAffineFunction{});
    while (q--) {
        int type{}; verify_in >> type;
        if (type == 0) {
            int p{}; PointAffineFunction f; verify_in >> p >> f.a >> f.b;
            tree.set(p, f);
        } else {
            int l{}, r{}; std::uint64_t x{}; verify_in >> l >> r >> x;
            const auto f = tree.prod(l, r);
            verify_out << (f.a * x + f.b) % 998244353 << '\n';
        }
    }
}
