// SPDX-License-Identifier: CC0-1.0
#include "Verify/current/common/fast_io.hpp"
#include <cstdint>
#include <vector>
struct RangeAffineUpdate { std::uint64_t a = 1, b = 0; };
struct RangeAffineSum {
    std::uint64_t operator()(std::uint64_t a, std::uint64_t b) const { return (a + b) % 998244353; }
};
struct RangeAffineMapping {
    std::uint64_t operator()(const RangeAffineUpdate& f, std::uint64_t sum, std::size_t length) const {
        return (f.a * sum + f.b * length) % 998244353;
    }
};
struct RangeAffineComposition {
    RangeAffineUpdate operator()(const RangeAffineUpdate& newer, const RangeAffineUpdate& older) const {
        return {newer.a * older.a % 998244353, (newer.a * older.b + newer.b) % 998244353};
    }
};
int main() {
    int n{}, q{}; verify_in >> n >> q;
    std::vector<std::uint64_t> a(n);
    for (auto& x : a) verify_in >> x;
    LazySegmentTree<std::uint64_t, RangeAffineUpdate, RangeAffineSum, RangeAffineMapping, RangeAffineComposition> tree(a, 0, RangeAffineUpdate{});
    while (q--) {
        int type{}, l{}, r{}; verify_in >> type >> l >> r;
        if (type == 0) {
            RangeAffineUpdate f; verify_in >> f.a >> f.b;
            tree.apply(l, r, f);
        } else verify_out << tree.prod(l, r) << '\n';
    }
}
