// SPDX-License-Identifier: CC0-1.0
#include "Verify/current/common/fast_io.hpp"
#include <cstdint>
#include <vector>
int main() {
    int n{}, q{}; verify_in >> n >> q;
    std::vector<std::int64_t> a(n);
    for (auto& x : a) verify_in >> x;
    SegmentTree<std::int64_t> tree(a);
    while (q--) {
        int type{}, p{}; std::int64_t x{}; verify_in >> type >> p >> x;
        if (type == 0) tree.transform(p, [&](auto value) { return value + x; });
        else verify_out << tree.prod(p, static_cast<std::size_t>(x)) << '\n';
    }
}
