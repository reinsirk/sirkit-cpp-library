# Fenwick Tree

`fenwick_tree<T>`はACLと同じ名前・呼び出し形式で点加算と区間和を扱う。公開型はグローバルに定義するため、`atcoder::`は付けない。`fenwick_tree(int n)`はn要素の0の列、既定構築は空列になる。`add(int p,T x)`で点加算し、`sum(int l,int r)`で半開区間[l,r)の和を値で返す。構築はO(n+1)、操作はO(log(n+1))、領域はO(n)。要素数はintの範囲と内部容量に収める。

bool以外の整数型は符号なしの同幅型で保存・加減算し、型幅のmod 2^bitで計算する。符号付き型でも内部の符号付きオーバーフローを起こさず、ACLと同じ剰余に対応する値を返す。GCC/Clangの128ビット整数拡張が使える場合も同様に扱う。modintや独自型は、`T{}`が単位元になる可換加法群を使い、演算がその型で正しく定義されること。演算とコピーの費用をO(1)とする。

追加機能として、`vector<T>`からO(n+1)で構築できる。`get(p)`は点の値、`set(p,x)`は点代入で、O(log(n+1))。`size()`はintの要素数、`empty()`は空かをO(1)で返す。先頭からの和も`sum(0,r)`、全体の和も`sum(0,size())`へ統一する。

`lower_bound(x)`は`sum(0,i+1)>=x`となる最小のint添字、`upper_bound(x)`は`sum(0,i+1)>x`となる最小のint添字をO(log(n+1))で返す。該当位置がなければ`size()`。非正のlower_boundと負のupper_boundは0を返す。境界探索中は全要素が非負で、途中の和がTの範囲に収まり、加算と順序が整合すること。剰余によって和が周回する列では境界探索を使えない。この条件を検査する全要素走査は行わない。

`values()`は列をO(n+1)時間・追加O(n)で復元する。`reset(n)`は旧列の破棄も含めO(旧n+n+1)でn要素の0の列に置き換え、`reset()`は現在の長さを0に戻す。`clear()`は容量を保持して空にし、`swap`はO(1)で内容を交換する。コピーは独立、移動元も空の列として使用可能。

ACLがassertで確認する無効な添字などは、この実装では例外で通知する。`SKIP_RUNTIME_CHECKS`で入力検査を除外できる。容量・添字のオーバーフロー対策は維持する。`sum`はACLと同じ非constメンバ関数である。

[使用例](../Examples/fenwick_tree_example.cpp)。[ACLのAPI仕様](https://atcoder.github.io/ac-library/production/document_ja/fenwicktree.html)と[Nyaanのデータ構造解説](https://nyaannyaan.github.io/library/data-structure/binary-indexed-tree.hpp)を参照。実装はこのライブラリ用に組み立てたCC0コード。動的座標が必要なら[動的Fenwick Tree](dynamic_fenwick.md)を使う。
