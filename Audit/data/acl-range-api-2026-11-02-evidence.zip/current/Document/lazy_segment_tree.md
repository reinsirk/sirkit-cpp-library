# Lazy Segment Tree

半開区間へ同じ作用を適用し、区間積を求める。公開名はグローバルの`lazy_segtree<S, op, e, F, mapping, composition, id>`。型引数・コンストラクタ・基本操作・境界探索の呼び方は[ACLのAPI](https://atcoder.github.io/ac-library/production/document_ja/lazysegtree.html)に揃える。値と作用の型、演算関数は利用側で用意する。旧名や同じ操作の別名は公開しない。

`lazy_segtree()`は空列、`lazy_segtree(n)`は`e()`をn個並べた列、`lazy_segtree(vector<S>)`は渡した列から構築する。`n`・添字・区間端・境界探索の戻り値は`int`で、列長は`INT_MAX`以下かつ内部容量にも収まる必要がある。演算・値や作用のコピーをO(1)として、構築はO(n+1)時間・領域。

- `S op(S left, S right)`は結合的で、`S e()`が左右の単位元。非可換でも左からの順序を保つ。
- `S mapping(F f, S value)`は値へ作用させる関数。`mapping(f, op(x,y)) == op(mapping(f,x), mapping(f,y))`を満たすこと。
- `F composition(F newer, F older)`はolderを先に、newerを後に適用する作用。`mapping(composition(f,g),x) == mapping(f,mapping(g,x))`。
- `F id()`は恒等作用を返し、値を変えない。作用型Fに等値比較は要求しない。

区間和へのアフィン作用`x -> a*x+b`では、Sに和と要素数を持たせる。`op`は両方を加算し、`e()`は`{0,0}`、`mapping`は`{a*sum+b*length,length}`を返す。各要素を`{値,1}`として列から構築する。`lazy_segtree(n)`や`reset()`はSの単位元を並べるため、この例では要素数フィールドも0になる。合成は`{a_new*a_old, a_new*b_old+b_new}`。`a=0`で区間代入、`a=1`で区間加算も表せる。算術は利用する型の範囲へ収める。

追加の形として、`mapping(F,S,std::size_t length)`も指定できる。2引数形が呼べる場合はそちらを優先する。3引数形のlengthは作用させる区間の実要素数で、作用は区間の結合と整合し、長さを変えないこと。内部の2冪へのパディングを含む節点へ直接タグを付けない。

`set(int p,S x)`、`apply(int p,F f)`、`apply(int l,int r,F f)`、`get(int p)`、`prod(int l,int r)`はO(log(n+1))。`get`・`prod`はSの値を返す。`all_prod()`は全積のS値をO(1)で返す。空区間・空列の積は`e()`。タグの有無は別配列で持ち、保留されていない作用の伝播を省く。`get`・`prod`・境界探索・`values`は遅延タグを伝播するため非constである。

`max_right<pred>(int l)`・`min_left<pred>(int r)`は関数`bool pred(S)`を指定する。`max_right(l,pred)`・`min_left(r,pred)`は関数オブジェクトを渡す形。同じ値には同じ結果を返し、`pred(e())`が真、区間を延ばすと真から偽へ一度だけ変わることが前提。どちらもO(log(n+1))で`int`の境界を返す。単調性の確認のために全要素を走査しない。

追加操作の`size()`・`empty()`はO(1)。`values()`は全点へ伝播しO(n+1)で列をコピーする。`assign(values)`・`reset(int n)`は旧列の破棄も含めO(旧n+n+1)、`reset()`は現在の長さを単位元へ戻す。`clear()`は容量を保って空にし、`swap`はO(1)で交換する。コピーは独立、移動元は空の列として再利用できる。値・作用のコピーや演算が例外を投げた場合、内容の強い保証は行わない。

添字・区間・述語の単位元条件は既定で例外により検査する。この無効入力時の扱いはACLのassertとは異なる。`SKIP_RUNTIME_CHECKS`で入力検査を除く。容量・内部添字・`int`での列長表現に関する保護は残す。

[使用例](../Examples/lazy_segment_tree_example.cpp)。数学的参考は[AtCoder Algorithm Lecturesのモノイド設計](https://info.atcoder.jp/entry/algorithm_lectures/range_query_monoid_design)。公開APIの仕様を参照し、木と遅延伝播はこのライブラリ用のCC0実装を使用する。
