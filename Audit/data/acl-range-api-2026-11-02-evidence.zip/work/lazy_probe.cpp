#include "/home/reinsirk/Atcoder_Env/DataStructure/Lazy_Segment_Tree.cpp"
#include "/home/reinsirk/Atcoder_Env/DataStructure/Lazy_Segment_Tree.cpp"
#include <cassert>
#include <random>
#include <string>
struct V { std::int64_t x; int n; friend bool operator==(const V&,const V&)=default; };
struct F { std::int64_t a,b; };
V op(V a,V b){return{a.x+b.x,a.n+b.n};} V e(){return{0,0};}
V map(F f,V s){return{f.a*s.x+f.b*s.n,s.n};} F comp(F f,F g){return{f.a*g.a,f.a*g.b+f.b};} F id(){return{1,0};}
bool pred(V s){return s.x<=20;}
using Tree=lazy_segtree<V,op,e,F,map,comp,id>;
std::int64_t add(std::int64_t a,std::int64_t b){return a+b;}std::int64_t zero(){return 0;}std::int64_t map3(F f,std::int64_t s,std::size_t n){return f.a*s+f.b*static_cast<std::int64_t>(n);}
bool bop(bool a,bool b){return a!=b;}bool bzero(){return false;}bool bmap(bool f,bool a,std::size_t n){return a!=(f&&(n%2));}
struct ND { int x; ND()=delete; explicit ND(int y):x(y){} };ND no(ND a,ND b){return ND(a.x+b.x);}ND ne(){return ND(0);}ND nm(F f,ND a,std::size_t n){return ND(f.a*a.x+f.b*n);}
int main(){
 static_assert(std::is_same_v<decltype(std::declval<Tree>().all_prod()),V>);
 static_assert(std::is_same_v<decltype(std::declval<Tree>().max_right<pred>(0)),int>);
 Tree z;assert(z.empty()&&z.all_prod()==e());
 std::mt19937 r(17);
 for(int n=0;n<=91;++n){std::vector<V>a(n);for(auto&x:a)x={static_cast<std::int64_t>(r()%11),1};Tree t(a);
 for(int k=0;k<400;++k){int l=r()%(n+1),rr=r()%(n+1);if(l>rr)std::swap(l,rr);if(k%3==0){F f{static_cast<std::int64_t>(r()%2),static_cast<std::int64_t>(r()%4)};t.apply(l,rr,f);for(int j=l;j<rr;++j)a[j]=map(f,a[j]);}else{V s=e();for(int j=l;j<rr;++j)s=op(s,a[j]);assert(t.prod(l,rr)==s);}
 int x=l;V s=e();while(x<n&&pred(op(s,a[x])))s=op(s,a[x++]);assert(t.max_right<pred>(l)==x);x=rr;s=e();while(x>0&&pred(op(a[x-1],s)))s=op(a[--x],s);assert(t.min_left<pred>(rr)==x);
 }
 assert(t.values()==a);auto cp=t;auto mv=std::move(cp);assert(cp.empty()&&mv.values()==a);cp=std::move(mv);assert(mv.empty()&&cp.values()==a);
 }
 lazy_segtree<std::int64_t,add,zero,F,map3,comp,id> ext(91);ext.apply(0,91,{1,3});assert(ext.all_prod()==273);ext.apply(4,{0,19});assert(ext.get(4)==19);
 lazy_segtree<bool,bop,bzero,bool,bmap,bop,bzero> bits(std::vector<bool>{true,false,true});bits.apply(0,3,true);assert(bits.values()==std::vector<bool>({false,true,false}));
 lazy_segtree<ND,no,ne,F,nm,comp,id> nd(3);nd.apply(0,3,{1,2});assert(nd.all_prod().x==6);
#ifndef SKIP_RUNTIME_CHECKS
 bool bad=false;try{Tree neg(-1);}catch(const std::invalid_argument&){bad=true;}assert(bad);
 bad=false;try{z.apply(-1,0,F{1,1});}catch(const std::out_of_range&){bad=true;}assert(bad);
#endif
}
