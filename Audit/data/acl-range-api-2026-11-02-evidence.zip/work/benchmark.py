from pathlib import Path
import subprocess,json,random,statistics,hashlib,shutil
ROOT=Path('.').resolve();D=Path('/tmp/sirkit_acl_api_20261102');fixture=ROOT/'Audit/Benchmarks/fast_storage.cpp';names=['Fenwick_Tree.cpp','Segment_Tree.cpp','Lazy_Segment_Tree.cpp'];builds=[];rows=[];rng=random.Random(907236)
for compiler in ['gcc','clang']:
 for kind,name in enumerate(names):
  for label in ['before','after']:
   source=(D/'before/DataStructure'/name if label=='before' else ROOT/'DataStructure'/name)
   cmd=['/usr/bin/g++'] if compiler=='gcc' else ['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
   exe=D/f'bench_{compiler}_{kind}_{label}';cmd+=['-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS','-DSTORAGE_KIND='+str(kind),'-DSTORAGE_LIBRARY="'+str(source)+'"']
   if label=='before':cmd+=['-DSIRKIT_LEGACY_RANGE_API']
   cmd +=[str(fixture),'-o',str(exe)];subprocess.run(['taskset','-c','2',*cmd],check=True);builds.append({'compiler':compiler,'kind':kind,'label':label,'command':cmd,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest()})
  for n in [32,262144]:
   for op in [0,1]:
    for rep in range(9):
     labels=['before','control','after'];rng.shuffle(labels);checks=[]
     for label in labels:
      exe=D/f'bench_{compiler}_{kind}_{"before" if label=="control" else label}';shutil.copyfile(exe,D/'active_bench');(D/'active_bench').chmod(0o700)
      r=json.loads(subprocess.check_output(['taskset','-c','12',str(D/'active_bench'),str(n),'300000',str(29+rep%3),str(op)]));checks.append(r['checksum']);rows.append({**r,'compiler':compiler,'kind':kind,'n':n,'q':300000,'op':op,'label':label,'rep':rep})
     assert len(set(checks))==1,(compiler,kind,n,op,checks)
    med={l:statistics.median(r['operation_cpu_ns'] for r in rows if r['compiler']==compiler and r['kind']==kind and r['n']==n and r['op']==op and r['label']==l) for l in labels};print(compiler,kind,n,op,{l:round(v/med['before'],3) for l,v in med.items()},flush=True)
    (D/'benchmark_raw.json').write_text(json.dumps(rows));(D/'benchmark_builds.json').write_text(json.dumps(builds,indent=2))
