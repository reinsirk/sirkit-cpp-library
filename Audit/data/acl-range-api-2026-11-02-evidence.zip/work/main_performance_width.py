from pathlib import Path
import hashlib,json,random,shutil,statistics,subprocess
ROOT=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_acl_api_20261102');sha=lambda b:hashlib.sha256(b).hexdigest()
s=(ROOT/'Audit/Benchmarks/fast_storage.cpp').read_text();assert 'struct Query { std::size_t left, right, point; I value; unsigned kind; };' in s
pad='struct Query { int left; std::uint32_t pad_left; int right; std::uint32_t pad_right; std::size_t point; I value; unsigned kind; };\nstatic_assert(sizeof(Query)==40);'
(D/'main_performance_size_width.cpp').write_text(s)
(D/'main_performance_int_width.cpp').write_text(s.replace('struct Query { std::size_t left, right, point; I value; unsigned kind; };',pad))
before=D/'before/DataStructure/Segment_Tree.cpp';after=D/'main_performance_segment_after.hpp';after.write_bytes((ROOT/'DataStructure/Segment_Tree.cpp').read_bytes())
records=[];build=[];rng=random.Random(0x51738252)
for compiler in ['gcc','clang']:
 for width in ['size','int']:
  for label in ['old','new']:
   lib=before if label=='old' else after
   exe=D/f'main_performance_synthetic_{compiler}_{width}_{label}'
   cmd=['/usr/bin/g++'] if compiler=='gcc' else ['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
   cmd+=['-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS','-DSTORAGE_KIND=1','-DSTORAGE_LIBRARY="'+str(lib)+'"']
   if label=='old':cmd+=['-DSIRKIT_LEGACY_RANGE_API']
   cmd+=[str(D/f'main_performance_{width}_width.cpp'),'-o',str(exe)]
   subprocess.run(['taskset','-c','2',*cmd],check=True);build.append({'compiler':compiler,'width':width,'label':label,'command':cmd,'library_sha256':sha(lib.read_bytes()),'fixture_sha256':sha((D/f'main_performance_{width}_width.cpp').read_bytes()),'binary_sha256':sha(exe.read_bytes())})
for compiler in ['gcc','clang']:
 for width in ['size','int']:
  for operation in [0,1]:
   for rep in range(9):
    labels=['old','control','new'];rng.shuffle(labels);checks=[]
    for label in labels:
     exe=D/f'main_performance_synthetic_{compiler}_{width}_{"old" if label=="control" else label}'
     active=D/'main_performance_synthetic_active';shutil.copyfile(exe,active);active.chmod(0o700)
     result=json.loads(subprocess.check_output(['taskset','-c','12',str(active),'500000','500000',str(734021+rep%3),str(operation)]));checks.append(result['checksum']);records.append({**result,'compiler':compiler,'width':width,'operation':operation,'rep':rep,'label':label})
    assert len(set(checks))==1
   med={l:statistics.median(r['operation_cpu_ns'] for r in records if r['compiler']==compiler and r['width']==width and r['operation']==operation and r['label']==l) for l in labels}
   print(compiler,width,operation,{l:round(v/1e6,4) for l,v in med.items()},'new/old',round(med['new']/med['old'],4),'control/old',round(med['control']/med['old'],4),flush=True)
   (D/'main_performance_width.json').write_text(json.dumps({'same_stride_bytes':40,'n':500000,'q':500000,'after_source_sha256':sha(after.read_bytes()),'build':build,'measurements':records},indent=2))
