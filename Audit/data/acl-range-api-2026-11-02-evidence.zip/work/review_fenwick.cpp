#include "/home/reinsirk/Atcoder_Env/DataStructure/Fenwick_Tree.cpp"
#include "/home/reinsirk/Atcoder_Env/DataStructure/Fenwick_Tree.cpp"
#include <cassert>
#include <cstdint>
#include <random>
#include <vector>
#include <limits>
struct G { std::uint32_t x=0,y=0; G&operator+=(G b){x+=b.x;y+=b.y;return*this;}G&operator-=(G b){x-=b.x;y-=b.y;return*this;}friend G operator+(G a,G b){return a+=b;}friend G operator-(G a,G b){return a-=b;}friend bool operator==(G,G)=default;};
template<class T>void run(){using U=typename reinsirk::detail::FenwickStorage<T>::type;std::mt19937_64 r(32817);for(int n:{0,1,2,3,7,8,9,63,64,65,128,129,257}){std::vector<T>a(n);for(auto&v:a)v=static_cast<T>(r());fenwick_tree<T>f(a);assert(f.values()==a);for(int k=0;k<1000;++k){int l=r()%(n+1),rr=r()%(n+1);if(l>rr)std::swap(l,rr);U sum{};for(int j=l;j<rr;++j)sum+=static_cast<U>(a[j]);assert(f.sum(l,rr)==static_cast<T>(sum));if(n){int p=r()%n;T x=static_cast<T>(r());if(k%2){f.add(p,x);a[p]=static_cast<T>(static_cast<U>(a[p])+static_cast<U>(x));}else{f.set(p,x);a[p]=x;}assert(f.get(p)==a[p]);}if(k%8==0)assert(f.values()==a);}}}
int main(){run<std::int8_t>();run<std::uint8_t>();run<std::int16_t>();run<std::uint16_t>();run<std::int32_t>();run<std::uint32_t>();run<std::int64_t>();run<std::uint64_t>();
#if defined(__SIZEOF_INT128__)
run<__int128>();run<unsigned __int128>();
#endif
std::vector<G>a{{1,2},{3,4},{5,6}};fenwick_tree<G>f(a);assert(f.sum(0,3)==G(9,12));f.set(1,{9,11});assert(f.get(1)==G(9,11));assert(f.values()==std::vector<G>({{1,2},{9,11},{5,6}}));
}
