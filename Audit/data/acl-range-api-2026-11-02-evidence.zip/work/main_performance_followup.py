from pathlib import Path
import hashlib,json,os,random,shutil,statistics,subprocess,sys,time
ROOT=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_acl_api_20261102');sys.path.insert(0,str(ROOT/'Scripts'))
import prepare_verify
E=next(e for e in prepare_verify.collect() if e['id']=='segment_tree')
sha=lambda b:hashlib.sha256(b).hexdigest()
records=[];build=[];randomizer=random.Random(0x20261102)
for compiler in ['gcc','clang']:
 for label in ['old','new']:
  prefix=D/'before' if label=='old' else ROOT
  lib=(prefix/'DataStructure/Segment_Tree.cpp').read_bytes()
  driver=(prefix/'Verify/current/drivers/segment_tree_main.cpp').read_text()
  data,_=prepare_verify.render(E,source_overrides={'DataStructure/Segment_Tree.cpp':lib},driver_override=driver)
  src=D/f'main_performance_{compiler}_{label}.cpp';exe=D/f'main_performance_{compiler}_{label}';src.write_bytes(data)
  command=['/usr/bin/g++'] if compiler=='gcc' else ['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
  command+=['-std=c++23','-O2',str(src),'-o',str(exe)]
  subprocess.run(['taskset','-c','2',*command],check=True)
  build.append({'compiler':compiler,'label':label,'command':command,'library_sha256':sha(lib),'driver_sha256':sha(driver.encode()),'rendered_sha256':sha(data),'binary_sha256':sha(exe.read_bytes())})
for compiler in ['gcc','clang']:
 for mode in ['mixed','query']:
  inp=Path('/tmp/sirkit_fenwick_normal_20261102')/f'500000_{mode}.in'
  for rep in range(9):
   labels=['old','control','new'];randomizer.shuffle(labels);hashes=[]
   for label in labels:
    source=D/f'main_performance_{compiler}_{"old" if label=="control" else label}'
    target=D/'main_performance_active';shutil.copyfile(source,target);target.chmod(0o700)
    with inp.open('rb') as inf,(D/'main_performance_output.txt').open('wb') as outf:
     begin=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(target)],stdin=inf,stdout=outf)
     _,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status);assert p.returncode==0
     wall=time.perf_counter_ns()-begin
    output_hash=sha((D/'main_performance_output.txt').read_bytes());hashes.append(output_hash)
    records.append({'compiler':compiler,'mode':mode,'label':label,'rep':rep,'user_ns':round(usage.ru_utime*1e9),'system_ns':round(usage.ru_stime*1e9),'cpu_ns':round((usage.ru_utime+usage.ru_stime)*1e9),'wall_ns':wall,'output_sha256':output_hash})
   assert len(set(hashes))==1,(compiler,mode,rep)
  med={k:statistics.median(r['cpu_ns'] for r in records if r['compiler']==compiler and r['mode']==mode and r['label']==k) for k in labels}
  print(compiler,mode,{k:round(v/1e6,4) for k,v in med.items()},'new/old',round(med['new']/med['old'],4),'control/old',round(med['control']/med['old'],4),flush=True)
  (D/'main_performance_followup.json').write_text(json.dumps({'n':500000,'q':500000,'affinity':12,'native':False,'repetitions':9,'input_files':{mode: {'path':str(inp),'sha256':sha(inp.read_bytes())}},'build':build,'measurements':records},indent=2))
