// SPDX-License-Identifier: CC0-1.0
#include <atomic>
#include <cstddef>
#include <cstdlib>
#include <new>
namespace {
std::atomic<std::ptrdiff_t> budget{-1};std::atomic<std::size_t> live{0};std::size_t checks=0,failures=0;
void check(bool value){++checks;if(!value)std::abort();}
}
[[gnu::noinline]]void* operator new(std::size_t n){if(budget==0)throw std::bad_alloc();if(budget>0)--budget;if(void*p=std::malloc(n?n:1)){++live;return p;}throw std::bad_alloc();}
[[gnu::noinline]]void operator delete(void*p)noexcept{if(p){--live;std::free(p);}}
[[gnu::noinline]]void operator delete(void*p,std::size_t)noexcept{::operator delete(p);}
[[gnu::noinline]]void* operator new[](std::size_t n){return ::operator new(n);}
[[gnu::noinline]]void operator delete[](void*p)noexcept{::operator delete(p);}
[[gnu::noinline]]void operator delete[](void*p,std::size_t)noexcept{::operator delete(p);}
#ifndef Z_HEADER
#define Z_HEADER "../../../String/Z_Algorithm.cpp"
#endif
#ifndef MANACHER_HEADER
#define MANACHER_HEADER "../../../String/Manacher.cpp"
#endif
#ifndef SUFFIX_HEADER
#define SUFFIX_HEADER "../../../String/Suffix_Array.cpp"
#endif
#ifndef NTT_HEADER
#define NTT_HEADER "../../../Math/NTT.cpp"
#endif
#include Z_HEADER
#include MANACHER_HEADER
#include SUFFIX_HEADER
#include NTT_HEADER
#include <cstdio>
#include <string>
int main(){const auto initial_live=live.load();{
 const std::string s(129,'a'),pattern(33,'a');const std::vector<std::int64_t>numbers(129,-7);const std::vector<std::uint32_t>a(129,1),b(97,1);const auto saved_a=a,saved_b=b;
 for(int kind=0;kind<10;++kind)for(int allowance=0;allowance<80;++allowance){const auto owned=live.load();budget=allowance;try{
  if(kind==0){auto z=ZAlgorithm(s);budget=-1;check(z[0]==129&&z.back()==1);}
  if(kind==1){auto matches=ZMatches(pattern,s);budget=-1;check(matches.size()==97&&matches.front()==0&&matches.back()==96);}
  if(kind==2){PalindromeRadii p(s);budget=-1;check(p.count()==129*130/2);}
  if(kind==3){auto lengths=PalindromicLengths(s);budget=-1;check(lengths.size()==257&&lengths[128]==129);}
  if(kind==4){auto sa=SuffixArray(s);budget=-1;check(sa.size()==129&&sa[0]==128&&sa.back()==0);}
  if(kind==5){auto sa=SuffixArray(numbers);budget=-1;check(sa.size()==129&&sa[0]==128&&sa.back()==0);}
  if(kind==6){NTT<> e;auto c=e.convolution(a,b);budget=-1;check(c.size()==225&&c[0]==1&&c[96]==97&&c.back()==1);}
  if(kind==7){NTT<> e;auto c=e.square(a);budget=-1;check(c.size()==257&&c[128]==129&&c.back()==1);}
  if(kind==8){auto sa=SuffixArray(s);auto lcp=LCPArray(s,sa);budget=-1;check(lcp.size()==128&&lcp[0]==1&&lcp.back()==128);}
  if(kind==9){auto c=ConvolutionMod(a,b);budget=-1;check(c.size()==225&&c[0]==1&&c[96]==97&&c.back()==1);}
 }catch(const std::bad_alloc&){budget=-1;++failures;}check(live.load()==owned);check(a==saved_a&&b==saved_b);}
 for(int allowance=0;allowance<4;++allowance){PalindromeRadii p(std::string("abba"));const auto old_odd=p.odd,old_even=p.even;budget=allowance;try{p.assign(s);budget=-1;check(p.size()==129);}catch(const std::bad_alloc&){budget=-1;++failures;check(p.odd==old_odd&&p.even==old_even);}}
 NTT<>e;e.prepare(16);const auto old_roots=e.roots_capacity();budget=0;try{e.prepare(512);budget=-1;check(false);}catch(const std::bad_alloc&){budget=-1;++failures;check(e.roots_capacity()==old_roots);}auto c=e.convolution(a,b);check(c.size()==225&&c[96]==97);
}check(live.load()==initial_live);std::printf("allocation checks=%zu failures=%zu live_delta=%zu\n",checks,failures,live.load()-initial_live);}
