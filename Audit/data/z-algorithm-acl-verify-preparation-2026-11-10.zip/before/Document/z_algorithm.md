# Z配列と文字列検索

`String/Z_Algorithm.cpp`は、列の各接尾辞と先頭部分が何要素一致するかを線形時間で求める。文字列、整数vectorなど、`size()`・添字アクセス・等値比較が使える列に対応する。`ZAlgorithm(s)`の先頭は列長、空列の結果は空。比較がO(1)なら時間・領域はO(n)。

`PrefixMatches(pattern,text)`はtextの各位置とpatternの共通接頭辞長、`ZMatches(pattern,text)`は完全一致する開始位置を返す。文字列を連結せず、patternのZ配列と一致範囲を使うため、特殊な区切り文字は必要ない。全バイト値や任意の整数を扱える。時間はO(n+m)、補助領域はpattern長と返却配列に比例する。空patternは全境界0..nに一致する。

列長はINT_MAX未満が前提で、上限確認は検査省略時にも残す。元の列は変更しない。入力要素の値に制約はなく、検査専用の全走査は行わない。

[使用例](../Examples/z_algorithm_example.cpp)、[Library Checker](https://judge.yosupo.jp/problem/zalgorithm)を参照。
