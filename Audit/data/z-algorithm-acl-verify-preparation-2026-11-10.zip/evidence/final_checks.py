# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,sys,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_z_api_20261110');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as p;e=next(x for x in p.collect()if x['id']=='z_algorithm');rows=[]
for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 binaries={}
 for label in ['before','after']:
  overrides={'String/Z_Algorithm.cpp':(D/'before/String/Z_Algorithm.cpp').read_bytes()}if label=='before'else{};driver=(D/'before/Verify/current/drivers/z_algorithm_main.cpp').read_text()if label=='before'else(R/e['driver']).read_text();data,_=p.render(e,source_overrides=overrides,driver_override=driver);src=D/f'{label}.cpp';src.write_bytes(data);exe=D/f'{cc}_{label}';cmd=['taskset','-c','6',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(src),'-o',str(exe)];subprocess.run(cmd,check=True);binaries[label]=exe
  for sample in e['samples']:
   x=subprocess.run([str(exe)],input=sample['input'],text=True,capture_output=True);assert x.returncode==0 and not x.stderr and p.matches(e,sample,x.stdout)
 texts=[]
 for exe in binaries.values():
  f=exe.with_suffix('.text');subprocess.run(['objcopy','--dump-section',f'.text={f}',str(exe)],check=True);texts.append(f.read_bytes())
 ex=D/f'{cc}_example';subprocess.run(['taskset','-c','6',*args,'-std=c++23','-O2',str(R/'Examples/z_algorithm_example.cpp'),'-o',str(ex)],check=True);x=subprocess.run([str(ex)],text=True,capture_output=True);assert x.returncode==0 and x.stdout=='5 0 3 0 1 \n0 2 \n3\n'and not x.stderr
 rows.append(dict(compiler=cc,old_and_new_samples_pass=True,text_identical=texts[0]==texts[1],before_text_sha256=hashlib.sha256(texts[0]).hexdigest(),after_text_sha256=hashlib.sha256(texts[1]).hexdigest(),example_output=x.stdout));print(cc,'samples/example PASS; text_identical',texts[0]==texts[1],flush=True)
(D/'final_checks.json').write_text(json.dumps(rows,indent=2)+'\n')
old=(D/'before/String/Z_Algorithm.cpp').read_text();now=(R/'String/Z_Algorithm.cpp').read_text();body=lambda s,name:s.split(name,1)[1].split('    return z;\n}',1)[0];assert body(old,'std::vector<int> ZAlgorithm(const Sequence& s) {').replace('ZAlgorithm:','z_algorithm:')==body(now,'std::vector<int> z_algorithm_impl(const Sequence& s) {');assert(D/'before/Verify/current/drivers/z_algorithm_main.cpp').read_text().replace('ZAlgorithm(', 'z_algorithm(')==(R/e['driver']).read_text();assert(D/'before/Verify/current/common/fast_io.hpp').read_bytes()==(R/'Verify/current/common/fast_io.hpp').read_bytes();print('Algorithm/main/IO preservation proofs PASS',flush=True)
