# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,os,json,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_z_api_20261110');rows=[]
for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for test in ['z_algorithm_acl_api_test','string_algorithms_reference_test','string_math_allocation_test']:
  for skip in ([False,True]if test!='string_math_allocation_test'else[False]):
   src=R/f'Verify/current/tests/{test}.cpp';exe=D/f'{cc}_{test}_{int(skip)}';cmd=['taskset','-c','4',*args,'-std=c++23','-O2']+(['-fsanitize=address,undefined','-fno-omit-frame-pointer']if test!='string_math_allocation_test'else[])+(['-DSKIP_RUNTIME_CHECKS']if skip else[])+[str(src),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','4',str(exe)],text=True,capture_output=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'});assert p.returncode==0 and not p.stderr,(test,p.returncode,p.stderr);rows.append(dict(compiler=cc,test=test,skip_runtime_checks=skip,command=cmd,stdout=p.stdout,returncode=p.returncode,stderr=p.stderr,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest()));(D/'tests.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,test,skip,p.stdout.strip(),flush=True)
