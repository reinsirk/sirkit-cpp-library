from pathlib import Path
import sys,subprocess,json,random,statistics,time,os,resource,shutil
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_fenwick_normal_20261102');e=next(x for x in prepare_verify.collect() if x['id']=='fenwick_tree');e['submission_urls']=['https://judge.yosupo.jp/submission/414659']
labels=['old','add0','zero','zero_common'];build=[]
for k in labels:
 text,_=prepare_verify.render(e,source_overrides={'DataStructure/Fenwick_Tree.cpp':(D/('s3_'+k+'.hpp')).read_bytes()})
 src=D/('main_'+k+'.cpp');src.write_bytes(text);cmd=['/usr/bin/g++','-std=c++23','-O2',str(src),'-o',str(D/('main_'+k))];subprocess.run(cmd,check=True);build.append({'label':k,'cmd':cmd})
(D/'main_build.json').write_text(json.dumps(build,indent=2))
cases=[]
for n,q in [(32,200000),(4096,300000),(262144,400000),(500000,500000),(1048576,500000)]:
 for mode in ['mixed','query','update','short','prefix']:
  name=f'{n}_{mode}';path=D/(name+'.in');rng=random.Random(5789+n)
  if not path.exists():
   with path.open('w') as f:
    f.write(f'{n} {q}\n');f.write(' '.join(str(rng.randrange(1000)) for i in range(n))+'\n')
    for i in range(q):
     if mode=='update' or (mode=='mixed' and rng.randrange(2)==0):f.write(f'0 {rng.randrange(n)} {rng.randrange(8)}\n')
     else:
      if mode=='short':l=rng.randrange(n);r=min(n,l+1+rng.randrange(16))
      elif mode=='prefix':l=0;r=rng.randrange(n+1)
      else:l=rng.randrange(n+1);r=rng.randrange(n+1);l,r=min(l,r),max(l,r)
      f.write(f'1 {l} {r}\n')
  cases.append({'name':name,'n':n,'q':q,'mode':mode,'path':str(path)})
print('INPUTS BUILT',flush=True);rng=random.Random(196583);rows=[]
for c in cases:
 for rep in range(7):
  ks=['old','control','add0','zero','zero_common'];rng.shuffle(ks);cks=[]
  for k in ks:
   shutil.copyfile(D/('main_'+('old' if k=='control' else k)),D/'active_main');(D/'active_main').chmod(0o700)
   with open(c['path'],'rb') as inp,open(D/'bench.out','wb') as out:
    begin=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active_main')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-begin
   import hashlib
   ck=hashlib.sha256((D/'bench.out').read_bytes()).hexdigest();cks.append(ck)
   rows.append({**{k:v for k,v in c.items() if k!='path'},'label':k,'rep':rep,'user_ns':round(ru.ru_utime*1e9),'system_ns':round(ru.ru_stime*1e9),'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'output_sha256':ck})
  assert len(set(cks))==1,c
 ms={k:statistics.median(r['cpu_ns'] for r in rows if r['name']==c['name'] and r['label']==k) for k in ks}
 print(c['name'],{k:round(v/ms['old'],3) for k,v in ms.items()},flush=True);(D/'main_raw.json').write_text(json.dumps(rows))
