from pathlib import Path
import subprocess,json,random,statistics
D=Path('/tmp/sirkit_fenwick_normal_20261102');s=(D/'normal_before.cpp').read_text();a=(D/'add0.hpp').read_text()
common='''        T right{}, left{};
        while (l < r) { right += tree_[r]; r &= r - 1; }
        while (r < l) { left += tree_[l]; l &= l - 1; }
        return right - left;'''
z=a.replace('return n == 0 ? 0 : n + 1;', 'return n;').replace('return tree_.empty() ? 0 : tree_.size() - 1;', 'return tree_.size();')
old='''    explicit FenwickTree(const std::vector<T>& values) : tree_(storage_size(values.size()), T{}) {
        const auto n = values.size();
        for (std::size_t i = 1; i <= n; ++i) {
            tree_[i] += values[i - 1];
            const auto step = lowbit(i);
            if (step <= n - i) tree_[i + step] += tree_[i];
        }
    }'''
new='''    explicit FenwickTree(const std::vector<T>& values) : tree_(values) {
        const auto n = values.size();
        for (std::size_t i = 0; i < n; ++i) {
            const auto parent = i | (i + 1);
            if (parent < n) tree_[parent] += tree_[i];
        }
    }'''
assert old in z;z=z.replace(old,new)
z=z.replace('tree_[r]', 'tree_[r - 1]').replace('tree_[node]','tree_[node - 1]').replace('tree_[i + 1]','tree_[i]').replace('tree_[next]','tree_[next - 1]')
z=z.replace('std::vector<T> result(tree_.begin() + 1, tree_.end());','std::vector<T> result(tree_);')
z=z.replace('r -= lowbit(r)','r &= r - 1').replace('node -= lowbit(node)','node &= node - 1')
# Separate sums preserve the traversal order within each side.
variants={'old':s,'add0':a,'common':a.replace('        return prefix_unchecked(r) - prefix_unchecked(l);',common),'zero':z,'zero_common':z.replace('        return prefix_unchecked(r) - prefix_unchecked(l);',common.replace('tree_[r]','tree_[r - 1]').replace('tree_[l]','tree_[l - 1]'))}
for k,v in variants.items():
 (D/('s3_'+k+'.hpp')).write_text(v)
 subprocess.run(['/usr/bin/g++','-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS','-DBENCH_LIBRARY="'+str(D/('s3_'+k+'.hpp'))+'"',str(D/'bench.cpp'),'-o',str(D/('s3_'+k))],check=True)
print('BUILT GCC15.2',flush=True)
rows=[];rng=random.Random(14566)
for n in [32,4096,262144,500000,1048576]:
 for op in range(8):
  for rep in range(5):
   keys=list(variants);rng.shuffle(keys);checks=[]
   for k in keys:
    d=json.loads(subprocess.check_output(['taskset','-c','12',str(D/('s3_'+k)),str(n),'400000',str(op),str(3+rep%3)]));checks.append(d['checksum']);d.update(label=k,n=n,op=op,rep=rep);rows.append(d)
   assert len(set(checks))==1,(n,op,checks)
  med={k:statistics.median(r['op_ns'] for r in rows if r['n']==n and r['op']==op and r['label']==k) for k in variants}
  print(n,op,{k:round(v/med['old'],3) for k,v in med.items()},flush=True)
  (D/'screen3.json').write_text(json.dumps(rows))
