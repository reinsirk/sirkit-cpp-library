from pathlib import Path
import json,subprocess,statistics,random,shutil,os,time,sys
D=Path('/tmp/sirkit_fenwick_normal_20261102');s=(D/'add1.hpp').read_text().replace('if (n == std::numeric_limits<std::size_t>::max() || n + 1 > std::vector<T>{}.max_size())','if (n > (std::numeric_limits<std::size_t>::max() >> 1) || n + 1 > std::vector<T>{}.max_size())');(D/'add1_guard.hpp').write_text(s)
sys.path.insert(0,'Scripts');import prepare_verify
e=next(x for x in prepare_verify.collect() if x['id']=='fenwick_tree');body,_=prepare_verify.render(e,source_overrides={'DataStructure/Fenwick_Tree.cpp':s.encode()});(D/'main_add1.cpp').write_bytes(body)
subprocess.run(['taskset','-c','2','/usr/bin/g++','-std=c++23','-O2',str(D/'main_add1.cpp'),'-o',str(D/'main_add1')],check=True)
for op in [0,1,5]:
 cmd=['taskset','-c','2','/usr/bin/g++','-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS','-DBENCH_OPERATION='+str(op),'-DBENCH_LIBRARY="'+str(D/'add1_guard.hpp')+'"','Audit/Benchmarks/fenwick_tree.cpp','-o',str(D/f'add1_{op}')];subprocess.run(cmd,check=True)
rng=random.Random(485129);rs=[]
for n in [4096,262144,500000,1048576]:
 for op in [0,1,5]:
  for rep in range(15):
   labels=['old','control','add1'];rng.shuffle(labels);checks=[]
   for l in labels:
    exe=D/f'add1_{op}' if l=='add1' else D/f'adopted_gcc_{op}_old';shutil.copyfile(exe,D/'active_add1');(D/'active_add1').chmod(0o700)
    r=json.loads(subprocess.check_output(['taskset','-c','12',str(D/'active_add1'),str(n),'700000',str(op),str(17+rep%5)]));checks.append(r['checksum']);rs.append({**r,'label':l,'n':n,'op':op,'rep':rep})
   assert len(set(checks))==1
  med={l:statistics.median(x['op_ns'] for x in rs if x['n']==n and x['op']==op and x['label']==l) for l in labels};print(n,op,{l:round(v/med['old'],4) for l,v in med.items()},flush=True)
  (D/'add1_recheck.json').write_text(json.dumps(rs))
