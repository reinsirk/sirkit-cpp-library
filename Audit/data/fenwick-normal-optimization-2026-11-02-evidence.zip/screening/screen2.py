from pathlib import Path
import subprocess,json,random,statistics
D=Path('/tmp/sirkit_fenwick_normal_20261102');s=(D/'normal_before.cpp').read_text();add0=(D/'add0.hpp').read_text()
# Every r-=lowbit(r) prefix is mathematically equal to r&=r-1 for unsigned r.
bits=lambda x:x.replace('r -= lowbit(r)','r &= r - 1').replace('node -= lowbit(node)','node &= node - 1')
variants={'old':s,'add0':add0,'bits':bits(s),'bits_add0':bits(add0)}
for shift in [8,10,12]:
 v=bits(add0)
 v=v.replace('n + 1 > std::vector<T>{}.max_size()',f'n > (std::numeric_limits<std::size_t>::max() >> 1) || n + (n >> {shift}) + 1 > std::vector<T>{{}}.max_size()')
 v=v.replace('return n == 0 ? 0 : n + 1;',f'return n == 0 ? 0 : n + (n >> {shift}) + 1;')
 v=v.replace('std::vector<T> tree_;','std::vector<T> tree_;\n    std::size_t n_ = 0;')
 v=v.replace('tree_(storage_size(n), T{}) {}','tree_(storage_size(n), T{}), n_(n) {}')
 v=v.replace('tree_(storage_size(values.size()), T{}) {','tree_(storage_size(values.size()), T{}), n_(values.size()) {')
 v=v.replace('return tree_.empty() ? 0 : tree_.size() - 1;', 'return n_;')
 import re
 # only benchmark APIs construction/add/sum/get/bounds, ownership/values not used in screen.
 v=re.sub(r'tree_\[([^\[\]]+)\]',lambda m:f'tree_[({m[1]}) + (({m[1]}) >> {shift})]',v)
 variants['pad'+str(shift)]=v
build='''        const auto n = values.size();
        for (std::size_t i = 1; i <= n; ++i) {
            tree_[i] += values[i - 1];
            const auto step = lowbit(i);
            if (step <= n - i) tree_[i + step] += tree_[i];
        }'''
copy='''        const auto n = values.size();
        std::copy(values.begin(), values.end(), tree_.begin() + !values.empty());
        for (std::size_t i = 1; i <= n; ++i) {
            const auto parent = i | (i - 1);
            if (parent < n) tree_[parent + 1] += tree_[i];
        }'''
variants['copy']=bits(add0).replace(build,copy)
for k,v in variants.items():
 (D/('s2_'+k+'.hpp')).write_text(v)
 subprocess.run(['g++','-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS','-DBENCH_LIBRARY="'+str(D/('s2_'+k+'.hpp'))+'"',str(D/'bench.cpp'),'-o',str(D/('s2_'+k))],check=True)
print('BUILT',flush=True)
rows=[];rng=random.Random(52688)
for n in [32,4096,262144,500000,1048576]:
 for op in [0,1,2,3,4,5,6,7]:
  for rep in range(5):
   keys=list(variants);rng.shuffle(keys);checks=[]
   for k in keys:
    d=json.loads(subprocess.check_output(['taskset','-c','12',str(D/('s2_'+k)),str(n),'400000',str(op),str(3+rep%3)]));checks.append(d['checksum']);d.update(label=k,n=n,op=op,rep=rep);rows.append(d)
   assert len(set(checks))==1,(n,op,checks)
  med={k:statistics.median(r['op_ns'] for r in rows if r['n']==n and r['op']==op and r['label']==k) for k in variants}
  print(n,op,{k:round(v/med['old'],3) for k,v in med.items()},flush=True)
  (D/'screen2.json').write_text(json.dumps(rows))
