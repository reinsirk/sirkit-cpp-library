from pathlib import Path
import subprocess,json,random,statistics
D=Path('/tmp/sirkit_fenwick_normal_20261102')
s=(D/'normal_before.cpp').read_text()
add='''        for (++i; i <= n;) {
            tree_[i] += delta;
            const auto step = lowbit(i);
            if (step > n - i) break;
            i += step;
        }'''
a0='''        for (; i < n; i |= i + 1) tree_[i + 1] += delta;'''
a1='''        for (++i; i < tree_.size(); i += lowbit(i)) tree_[i] += delta;'''
sum0='''        return prefix_unchecked(r) - prefix_unchecked(l);'''
sum1='''        T result{};
        while (l < r) { result += tree_[r]; r -= lowbit(r); }
        while (r < l) { result -= tree_[l]; l -= lowbit(l); }
        return result;'''
sum2='''        T right{}, left{};
        while (l && r) { right += tree_[r]; left += tree_[l]; r -= lowbit(r); l -= lowbit(l); }
        for (; r; r -= lowbit(r)) right += tree_[r];
        for (; l; l -= lowbit(l)) left += tree_[l];
        return right - left;'''
variants={'old':s,'add0':s.replace(add,a0),'add1':s.replace(add,a1),'sum_common':s.replace(sum0,sum1),'sum_pair':s.replace(sum0,sum2),'common_add0':s.replace(add,a0).replace(sum0,sum1),'pair_add0':s.replace(add,a0).replace(sum0,sum2)}
for k,v in variants.items():
 (D/(k+'.hpp')).write_text(v)
 subprocess.run(['g++','-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS','-DBENCH_LIBRARY="'+str(D/(k+'.hpp'))+'"',str(D/'bench.cpp'),'-o',str(D/k)],check=True)
print('BUILT',flush=True)
rows=[]
rng=random.Random(8239)
for n in [32,4096,262144,1048576]:
 for op in range(8):
  for rep in range(5):
   keys=list(variants);rng.shuffle(keys);checks=[]
   for k in keys:
    d=json.loads(subprocess.check_output(['taskset','-c','12',str(D/k),str(n),'400000',str(op),str(3+rep%3)]));checks.append(d['checksum']);d.update(label=k,n=n,op=op,rep=rep);rows.append(d)
   assert len(set(checks))==1,(n,op,checks)
  med={k:statistics.median(r['op_ns'] for r in rows if r['n']==n and r['op']==op and r['label']==k) for k in variants}
  print(n,op,{k:round(v/med['old'],3) for k,v in med.items()},flush=True)
  (D/'screen.json').write_text(json.dumps(rows))
