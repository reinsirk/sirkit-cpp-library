// SPDX-License-Identifier: CC0-1.0
// 参考（データ構造・検証問題）: https://nyaannyaan.github.io/library/data-structure/binary-indexed-tree.hpp
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/fenwick_tree.md
//
// API一覧
// [FenwickTree<T>]
// FenwickTree(n=0)/FenwickTree(vector<T>): 0初期化/列から構築。O(n+1)時間・領域。T{}が加法単位元の可換群を使う。
// size()/empty(): 要素数/空か。O(1)。添字は0始まり、区間は半開。加減算がTに収まり、演算/コピーをO(1)とする。
// add(i,delta)/set(i,value): 1点に加算/代入。get(i): 1点の値。O(log(n+1))。
// prefix_sum(r)/sum(l,r)/all_sum(): [0,r)/[l,r)/全区間の和。O(log(n+1))、空区間はT{}。
// lower_bound(target)/upper_bound(target): prefix_sum(i+1)>=target/>targetとなる最小i、なければn。O(log(n+1))。
// 境界探索は全要素が非負で、加算と順序が整合すること。検査のために全要素を走査しない。
// values(): 列を復元して返す。O(n+1)時間・追加O(n)。reset(n)/reset(): n要素/現在の要素数を0にする。O(旧n+n+1)。
// clear()/swap(other): 空にして容量保持/交換。O(旧n+1)/O(1)。コピーは独立、移動元は空として使える。

#include <algorithm>
#include <bit>
#include <cstddef>
#include <limits>
#include <stdexcept>
#include <utility>
#include <vector>

#ifndef SIRKIT_FENWICK_TREE_DEFINED
#define SIRKIT_FENWICK_TREE_DEFINED
template<class T>
class FenwickTree {
    std::vector<T> tree_;
    std::size_t n_ = 0;
    static std::size_t storage_size(std::size_t n) {
        if (n == std::numeric_limits<std::size_t>::max() || n > (std::numeric_limits<std::size_t>::max() >> 1) || n + (n >> 10) + 1 > std::vector<T>{}.max_size())
            throw std::length_error("FenwickTree: size");
        return n == 0 ? 0 : n + (n >> 10) + 1;
    }
    static std::size_t lowbit(std::size_t x) noexcept { return x & (~x + 1); }
    void check_index(std::size_t i) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (i >= size()) throw std::out_of_range("FenwickTree: index");
#else
        (void)i;
#endif
    }
    void check_range(std::size_t l, std::size_t r) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (l > r || r > size()) throw std::out_of_range("FenwickTree: range");
#else
        (void)l; (void)r;
#endif
    }
    T prefix_unchecked(std::size_t r) const {
        T result{};
        for (; r; r &= r - 1) result += tree_[(r) + ((r) >> 10)];
        return result;
    }
public:
    FenwickTree() = default;
    explicit FenwickTree(std::size_t n) : tree_(storage_size(n), T{}), n_(n) {}
    explicit FenwickTree(const std::vector<T>& values) : tree_(storage_size(values.size()), T{}), n_(values.size()) {
        const auto n = values.size();
        for (std::size_t i = 1; i <= n; ++i) {
            tree_[(i) + ((i) >> 10)] += values[i - 1];
            const auto step = lowbit(i);
            if (step <= n - i) tree_[(i + step) + ((i + step) >> 10)] += tree_[(i) + ((i) >> 10)];
        }
    }
    FenwickTree(const FenwickTree&) = default;
    FenwickTree& operator=(const FenwickTree&) = default;
    FenwickTree(FenwickTree&& other) noexcept : tree_(std::move(other.tree_)) { other.tree_.clear(); }
    FenwickTree& operator=(FenwickTree&& other) noexcept {
        if (this != &other) { tree_ = std::move(other.tree_); other.tree_.clear(); }
        return *this;
    }
    std::size_t size() const noexcept { return n_; }
    bool empty() const noexcept { return size() == 0; }
    void add(std::size_t i, const T& delta) {
        check_index(i);
        const auto n = size();
        for (; i < n; i |= i + 1) tree_[(i + 1) + ((i + 1) >> 10)] += delta;
    }
    T get(std::size_t i) const {
        check_index(i);
        auto node = i + 1;
        T result = tree_[(node) + ((node) >> 10)];
        const auto begin = node - lowbit(node);
        for (--node; node > begin; node &= node - 1) result -= tree_[(node) + ((node) >> 10)];
        return result;
    }
    void set(std::size_t i, const T& value) { add(i, value - get(i)); }
    T prefix_sum(std::size_t r) const { check_range(0, r); return prefix_unchecked(r); }
    T sum(std::size_t l, std::size_t r) const {
        check_range(l, r);
        return prefix_unchecked(r) - prefix_unchecked(l);
    }
    T all_sum() const { return prefix_unchecked(size()); }
    std::size_t lower_bound(const T& target) const {
        if (!(T{} < target)) return 0;
        const auto n = size();
        std::size_t index = 0;
        T current{};
        for (auto jump = std::bit_floor(n); jump; jump >>= 1) {
            if (jump <= n - index) {
                const auto next = index + jump;
                T candidate = current + tree_[(next) + ((next) >> 10)];
                if (candidate < target) { current = std::move(candidate); index = next; }
            }
        }
        return index;
    }
    std::size_t upper_bound(const T& target) const {
        if (target < T{}) return 0;
        const auto n = size();
        std::size_t index = 0;
        T current{};
        for (auto jump = std::bit_floor(n); jump; jump >>= 1) {
            if (jump <= n - index) {
                const auto next = index + jump;
                T candidate = current + tree_[(next) + ((next) >> 10)];
                if (!(target < candidate)) { current = std::move(candidate); index = next; }
            }
        }
        return index;
    }
    std::vector<T> values() const {
        if (tree_.empty()) return {};
        std::vector<T> result(tree_.begin() + 1, tree_.end());
        const auto n = size();
        for (auto i = n; i; --i) {
            const auto step = lowbit(i);
            if (step <= n - i) result[i + step - 1] -= result[i - 1];
        }
        return result;
    }
    void reset(std::size_t n) {
        std::vector<T> replacement(storage_size(n), T{});
        tree_.swap(replacement);
    }
    void reset() { std::fill(tree_.begin(), tree_.end(), T{}); }
    void clear() noexcept { tree_.clear(); }
    void swap(FenwickTree& other) noexcept { tree_.swap(other.tree_); }
};
#endif
