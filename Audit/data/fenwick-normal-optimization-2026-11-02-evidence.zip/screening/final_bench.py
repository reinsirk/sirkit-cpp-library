from pathlib import Path
import subprocess,json,random,statistics,hashlib,shutil
D=Path('/tmp/sirkit_fenwick_normal_20261102');fixture=Path('Audit/Benchmarks/fenwick_tree.cpp').resolve();after=Path('DataStructure/Fenwick_Tree.cpp').resolve()
rows=[];builds=[];rng=random.Random(192671)
for compiler in ['gcc','clang']:
 for op in range(8):
  for label,source in [('old',D/'normal_before.cpp'),('new',after)]:
   exe=D/f'final_{compiler}_{op}_{label}'
   cmd=['/usr/bin/g++'] if compiler=='gcc' else ['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
   cmd+=['-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS','-DBENCH_OPERATION='+str(op),'-DBENCH_LIBRARY="'+str(source)+'"',str(fixture),'-o',str(exe)]
   subprocess.run(['taskset','-c','2',*cmd],check=True);builds.append({'compiler':compiler,'op':op,'label':label,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'command':cmd,'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()})
  for n in [32,4096,262144,500000,1048576]:
   for rep in range(9):
    labels=['old','control','new'];rng.shuffle(labels);checks=[]
    for label in labels:
     original=D/f'final_{compiler}_{op}_{"old" if label=="control" else label}';shutil.copyfile(original,D/'active_operation');(D/'active_operation').chmod(0o700)
     r=json.loads(subprocess.check_output(['taskset','-c','12',str(D/'active_operation'),str(n),'500000',str(op),str(3+rep%3)]));checks.append(r['checksum']);rows.append({**r,'compiler':compiler,'op':op,'n':n,'q':500000,'rep':rep,'label':label})
    assert len(set(checks))==1
   med={label:statistics.median(r['op_ns'] for r in rows if r['compiler']==compiler and r['op']==op and r['n']==n and r['label']==label) for label in ['old','control','new']}
   print(compiler,op,n,{label:round(v/med['old'],3) for label,v in med.items()},flush=True)
   (D/'final_raw.json').write_text(json.dumps(rows));(D/'final_builds.json').write_text(json.dumps(builds,indent=2))
