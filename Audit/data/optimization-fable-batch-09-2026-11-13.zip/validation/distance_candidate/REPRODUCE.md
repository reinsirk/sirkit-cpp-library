# Point–segment distance: reject

Canonical input is `Geometry/components/linear_functions.inc`, generated into `Geometry/geometory.cpp` and `Geometry/Line_Segment.cpp` by `Scripts/generate_geometry.py`. Frozen baseline and candidate components and all generated outputs are under `baseline/` and `candidate/`. Only the integer point/segment distance branch changes; the floating scaled path remains the same. `candidate.diff` is the patch. No repository file was edited.

The proposal moves endpoint projection tests before normalization, replaces integer endpoint hypot with direct square root, and uses abs(cross)/length for interior distance. The exponent guard safely bounds square sums for signed64 and narrower coordinate types. Unsigned64 is not supported by the existing Point static assertion, and both versions are compile-rejected in tests.

Run in this directory:

```sh
python3 test.py
python3 main_check.py
python3 bench.py
python3 recheck_interior.py
```

GCC15.2 is `/usr/bin/g++`; Clang21 uses GCC15 standard headers. CPU10 must be available. `test.py` executes 16 baseline/candidate checked/skip and normal/standard configurations using independent cpp_int/cpp_dec_float_100 references, including segment–segment calls with exact Big predicates. Huge-coordinate tiny-distance tests use the existing input-scale rounding allowance; no unsupported absolute 1e-12 claim is made for them. The ordinary problem-input main tests compare against 100-digit decimal at 1e-12, plus all3 official samples, across both generated forms and compilers. Saved JSONs include exact build commands and outputs.

`bench.py` is the existing geometry benchmark frozen with count set uniformly to262144. It uses unchanged data, main, flags and output for both bodies. Setup and IO are outside the measured core loop. Two warmups and11 alternating repetitions give candidate/baseline ratios:

| Compiler | random | interior | endpoint |
| --- | --- | --- | --- |
| GCC15.2 | .493 | .805 | .268 |
| Clang21 | .589 | 1.132 | .449 |

`recheck_interior.py` repeats Clang interior with2 warmups and21 alternating repetitions:3.2134→3.63091ms, ratio1.12993. Raw samples are in `recheck_interior.json`. The clear13% regression fails the proposal's all-case nonregression condition, so the original proposal is rejected despite strong gains elsewhere. No compiler-specific revised proposal was attempted. The online main has only one query; functional validation of the full program is retained, and these core timing gains are not represented as end-to-end improvements.
