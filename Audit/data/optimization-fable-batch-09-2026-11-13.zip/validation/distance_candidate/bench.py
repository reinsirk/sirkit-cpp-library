from pathlib import Path
import subprocess,json,statistics
p=Path(__file__).resolve().parent
s=(p/'frozen/Verify/current/tests/geometry_performance_benchmark.cpp').read_text().replace('const int n=mode=="circle"?262144:524288;','const int n=262144;')
(p/'bench.cpp').write_text(s);r={'builds':[],'cases':{}}
for cc,base in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for v in ['baseline','candidate']:
  cmd=base+['-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_GEOMETRY_TEST_HEADER="{p/v/"generated/Geometry/geometory.cpp"}"',str(p/'bench.cpp'),'-o',str(p/f'{cc}_{v}_bench')]
  subprocess.run(cmd,check=True,capture_output=True,timeout=120);r['builds'].append(cmd)
 for shape in ['random','interior','endpoint']:
  raw={v:[]for v in ['baseline','candidate']};sums={v:[]for v in raw}
  for t in range(13):
   for v in (['baseline','candidate']if t%2 else ['candidate','baseline']):
    q=subprocess.run(['taskset','-c','10',str(p/f'{cc}_{v}_bench'),'distance',shape],check=True,capture_output=True,text=True,timeout=30);fields=q.stdout.split()
    if t>=2:raw[v].append(float(fields[0]));sums[v].append(fields[2])
  med={v:statistics.median(x)for v,x in raw.items()};r['cases'][cc+'_'+shape]={'raw_ms':raw,'medians_ms':med,'ratio':med['candidate']/med['baseline'],'sums':sums};(p/'bench.json').write_text(json.dumps(r,indent=2));print(cc,shape,r['cases'][cc+'_'+shape]['ratio'],flush=True)
