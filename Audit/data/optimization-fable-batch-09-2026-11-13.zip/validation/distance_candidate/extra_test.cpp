#include <bit>
#define main existing_geometry_distance_main
#include "reference_with_explicit_return.cpp"
#undef main
#include <iomanip>
using I=std::int64_t;
void extra_integer_cases(){
 const I lo=std::numeric_limits<I>::min(), hi=std::numeric_limits<I>::max();
 std::mt19937_64 rng(0x1E97);
 for(int i=0;i<450;++i){const auto pt=[&]{return geo::PointI{std::bit_cast<I>(rng()),std::bit_cast<I>(rng())};};integer_case(pt(),pt(),pt());}
 for(I k:{I(1),I(17),I(1000000000),hi/4}){
  integer_case({-k,k},{0,0},{k,k}); // foot exactly first endpoint
  integer_case({0,2*k},{0,0},{k,k}); // foot exactly last endpoint
  integer_case({1,k},{0,0},{k,0});
  integer_case({k-1,k},{0,0},{k,k-1});
 }
 integer_case({lo,hi},{hi,lo},{hi,lo});
 integer_case({hi,hi-1},{lo,lo},{hi,hi});
}
void segment_cases(){
 using P=geo::Point<I,Big>;using S=geo::Segment<I,Big>;
 const auto refseg=[](P a,P b,P c,P d){
  const auto orient=[](P p,P q,P r) -> Big {return (Big(q.x)-p.x)*(Big(r.y)-p.y)-(Big(q.y)-p.y)*(Big(r.x)-p.x);};
  const auto sign=[](const Big&x){return (x>0)-(x<0);};
  const auto on=[&](P p,P a,P b){return orient(a,b,p)==0&&std::min(a.x,b.x)<=p.x&&p.x<=std::max(a.x,b.x)&&std::min(a.y,b.y)<=p.y&&p.y<=std::max(a.y,b.y);};
  const Big x=orient(a,b,c),y=orient(a,b,d),z=orient(c,d,a),w=orient(c,d,b);
  if((sign(x)*sign(y)<0&&sign(z)*sign(w)<0)||on(a,c,d)||on(b,c,d)||on(c,a,b)||on(d,a,b))return Reference{Decimal(0),Decimal(0)};
  auto cv=[](P p){return geo::PointI{p.x,p.y};};auto r=integer_reference(cv(a),cv(c),cv(d));
  for(auto v:{integer_reference(cv(b),cv(c),cv(d)),integer_reference(cv(c),cv(a),cv(b)),integer_reference(cv(d),cv(a),cv(b))}){r.distance=std::min(r.distance,v.distance);r.span=std::max(r.span,v.span);}return r;
 };
 std::mt19937_64 random(0x5E67);
 for(int i=0;i<600;++i){auto pt=[&]{if(i<300)return P{std::bit_cast<I>(random()),std::bit_cast<I>(random())};return P{I(random()%2000000001)-1000000000,I(random()%2000000001)-1000000000};};auto a=pt(),b=i%13?pt():a,c=pt(),d=i%19?pt():c;distance_result(geo::distance(S{a,b},S{c,d},{0,0}),refseg(a,b,c,d));}
}
int main(){existing_geometry_distance_main();context="full-width/endpoint";extra_integer_cases();context="segment segment exact Big predicates";segment_cases();std::cout<<"EXTRA PASS total_checks="<<checks<<'\n';}
