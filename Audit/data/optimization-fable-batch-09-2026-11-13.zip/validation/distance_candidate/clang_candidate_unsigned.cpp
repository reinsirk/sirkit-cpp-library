#include <cstdint>
#include "/tmp/sirkit_fastest_review_20261113/distance_candidate/candidate/generated/Geometry/Line_Segment.cpp"
int main(){geo::Point<std::uint64_t> p;geo::Segment<std::uint64_t>s;return geo::distance(p,s)!=0;}
