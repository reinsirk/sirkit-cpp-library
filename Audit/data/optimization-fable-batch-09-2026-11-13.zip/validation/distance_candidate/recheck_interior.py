from pathlib import Path
import subprocess,json,statistics
p=Path(__file__).resolve().parent;r={};raw={v:[] for v in ['baseline','candidate']}
for i in range(23):
 for v in (['baseline','candidate']if i%2 else ['candidate','baseline']):
  q=subprocess.run(['taskset','-c','10',str(p/f'clang_{v}_bench'),'distance','interior'],capture_output=True,text=True,check=True,timeout=20)
  if i>=2:raw[v].append(float(q.stdout.split()[0]))
med={v:statistics.median(x)for v,x in raw.items()};r={'raw_ms':raw,'medians_ms':med,'ratio':med['candidate']/med['baseline'],'warmups':2,'alternating_repetitions':21};(p/'recheck_interior.json').write_text(json.dumps(r,indent=2));print(r)
