from pathlib import Path
import subprocess,json
p=Path(__file__).resolve().parent;r={'tests':[],'unsigned_rejections':[]}
for cc,base in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  for std in [False,True]:
   for v in ['baseline','candidate']:
    name=f'{cc}_{skip}_{std}_{v}';header=p/v/'generated/Geometry/Line_Segment.cpp';exe=p/(name+'_test')
    cmd=base+['-std=c++23','-O2','-Wall','-Wextra']+(['-DSKIP_RUNTIME_CHECKS']if skip else [])+(['-DSIRKIT_FORCE_STANDARD_ARITHMETIC','-DSIRKIT_DISABLE_SIMD','-U__SIZEOF_INT128__']if std else [])+[f'-DSIRKIT_DISTANCE_TEST_HEADER="{header}"',str(p/'extra_test.cpp'),'-o',str(exe)]
    build=subprocess.run(cmd,capture_output=True,text=True,timeout=180);(p/(name+'.build.log')).write_text(build.stdout+build.stderr)
    row={'name':name,'command':cmd,'build_returncode':build.returncode};r['tests'].append(row)
    if build.returncode:row['diagnostic']=build.stderr[-2000:];(p/'test_results.json').write_text(json.dumps(r,indent=2));raise RuntimeError(row)
    q=subprocess.run(['taskset','-c','10',str(exe)],capture_output=True,text=True,timeout=120);row.update({'returncode':q.returncode,'stdout':q.stdout,'stderr':q.stderr});(p/'test_results.json').write_text(json.dumps(r,indent=2));print(name,q.returncode,q.stdout.strip(),flush=True)
    if q.returncode:raise RuntimeError(row)
 for v in ['baseline','candidate']:
  header=p/v/'generated/Geometry/Line_Segment.cpp';src=p/f'{cc}_{v}_unsigned.cpp';src.write_text('#include <cstdint>\n#include "'+str(header)+'"\nint main(){geo::Point<std::uint64_t> p;geo::Segment<std::uint64_t>s;return geo::distance(p,s)!=0;}\n')
  cmd=base+['-std=c++23','-c',str(src),'-o',str(src.with_suffix('.o'))];q=subprocess.run(cmd,capture_output=True,text=True,timeout=120);assert q.returncode!=0 and ('static assertion' in q.stderr or 'static_assert' in q.stderr);r['unsigned_rejections'].append({'compiler':cc,'variant':v,'command':cmd,'returncode':q.returncode,'diagnostic':q.stderr[:3000]})
(p/'test_results.json').write_text(json.dumps(r,indent=2))
