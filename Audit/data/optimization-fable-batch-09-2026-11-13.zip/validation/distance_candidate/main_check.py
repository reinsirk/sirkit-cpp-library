from pathlib import Path
import sys,subprocess,json,random,decimal,hashlib
p=Path(__file__).resolve().parent;root=Path('/home/reinsirk/Atcoder_Env');sys.path.insert(0,str(root/'Scripts'));import prepare_verify as pv
r={'builds':[],'tests':[]};decimal.getcontext().prec=100;D=decimal.Decimal;rng=random.Random(177)
data=[]
for i in range(72):
 pts=[(rng.randint(-10**9,10**9),rng.randint(-10**9,10**9))for _ in range(3)]
 if i%13==0:pts[2]=pts[1]
 data.append(('\n'.join(f'{x} {y}'for x,y in pts)+'\n',pts))
def ref(pts):
 (px,py),(ax,ay),(bx,by)=pts;dx=bx-ax;dy=by-ay;ux=px-ax;uy=py-ay;den=dx*dx+dy*dy;dot=ux*dx+uy*dy
 if den==0 or dot<=0:return D(ux*ux+uy*uy).sqrt()
 if dot>=den:return D((px-bx)**2+(py-by)**2).sqrt()
 return abs(D(ux*dy-uy*dx))/D(den).sqrt()
for e in pv.collect():
 if e['id'] not in ['geometry_point_segment_distance_full','geometry_point_segment_distance_split']:continue
 for cc,base in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for v in ['baseline','candidate']:
   source=pv.render(e,source_overrides={name:(p/v/'generated'/name).read_bytes()for name in e['libraries']})[0];name=e['id']+'_'+cc+'_'+v;src=p/(name+'.cpp');src.write_bytes(source);exe=p/name;cmd=base+['-std=c++23','-O2',str(src),'-o',str(exe)];subprocess.run(cmd,check=True,capture_output=True,timeout=120);r['builds'].append({'name':name,'command':cmd,'source_sha':hashlib.sha256(source).hexdigest()})
   for i,(inp,pts) in enumerate(data):
    q=subprocess.run(['taskset','-c','10',str(exe)],input=inp,text=True,capture_output=True,check=True,timeout=10);out=D(q.stdout.strip());expected=ref(pts);assert abs(out-expected)<=D('1e-12')*max(1,abs(expected)),(name,i,q.stdout,expected)
   for sample in e['samples']:
    q=subprocess.run(['taskset','-c','10',str(exe)],input=sample['input'],text=True,capture_output=True,check=True,timeout=10);out=D(q.stdout.strip());expected=D(sample['output'].strip());assert abs(out-expected)<=D('1e-9')*max(1,abs(expected))
   r['tests'].append({'name':name,'random':72,'samples':3,'status':'PASS'});(p/'main_results.json').write_text(json.dumps(r,indent=2));print(name,'75 PASS',flush=True)
