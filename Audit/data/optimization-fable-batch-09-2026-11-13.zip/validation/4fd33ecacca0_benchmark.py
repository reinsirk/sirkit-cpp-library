from pathlib import Path
import subprocess,json,hashlib,statistics,time,random,shutil
W=Path(__file__).parent;rows=[];meta=json.loads((W/'metadata.json').read_text());(W/'inputs').mkdir(exist_ok=True)
for i,s in enumerate(next(x['entry']['samples'] for x in meta if x['label']=='baseline' and x['id'].endswith('full'))):(W/'inputs'/f'sample{i}.in').write_text(s['input'])
(W/'inputs/translated3.in').write_text('-9223372036854775808 9223372036854775807\n-9223372036854775791 9223372036854775807\n-9223372036854775808 9223372036854775796\n')
def exact(inp):
 a=list(map(int,inp.read_text().split()));p=list(zip(a[::2],a[1::2]));n=len(p);twice=abs(sum(p[i][0]*p[(i+1)%n][1]-p[i][1]*p[(i+1)%n][0] for i in range(n)));return (str(twice//2)+('.500000000000\n' if twice%2 else '.000000000000\n')).encode()
def save():(W/'benchmark_results.json').write_text(json.dumps({'cpu':11,'scope':'Only canonical signed_area2 integer-C128 branch differs; actual triangle Verify main/commonI/O/compilerprefix fixed. C++23 O2 CLI all. Core uses same actual compilerprefix and frozen old geometry_body_benchmark area random/zig100calls, plus262144distinct3-point inputs with vector size known3 and independent int64shoelace sum. Constructor/generation/reference and output excluded from chrono interval.2warm+9 shuffled alternating copies at fixed executable path.','results':rows},indent=2)+'\n')
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for profile,ident,lib in [('full','geometry_triangle_area_full','Geometry/geometory.cpp'),('split','geometry_triangle_area_split','Geometry/Polygon.cpp')]:
  bins={}
  for kind in ['main','core','small','standard_core','standard_small']:
   bins[kind]={}
   for label in ['baseline','candidate']:
    src=W/label/(ident+'.cpp') if kind=='main' else W/('existing_core.cpp' if kind.endswith('core') else 'small_core.cpp');exe=W/'bin'/f'{cc}_{profile}_{label}_{kind}';flags=[] if kind=='main' else ['-include',str(W/label/(profile+'_prefix.hpp')),'-DSIRKIT_GEOMETRY_TEST_HEADER="'+str(W/label/lib)+'"'];flags+=['-DSIRKIT_FORCE_STANDARD_ARITHMETIC'] if kind.startswith('standard') else [];cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',*flags,str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;bins[kind][label]=exe;rows.append({'kind':'build','compiler':cc,'profile':profile,'label':label,'scope':kind,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'library_sha256':hashlib.sha256((W/label/lib).read_bytes()).hexdigest(),'passed':True});save()
  jobs=[('main',p.stem,[],p) for p in sorted((W/'inputs').glob('*.in'))]+[('core',shape+'_'+str(n),['area',shape,str(n)],None) for n in [32,262144] for shape in ['random','zig']]+[('small','n3',[],None)]+[('standard_core',shape+'_262144',['area',shape,'262144'],None) for shape in ['random','zig']]+[('standard_small','n3',[],None)]
  for kind,name,args,inp in jobs:
   raw={k:[] for k in ['baseline','candidate']};checks={};rng=random.Random(292913);input_data=inp.read_bytes() if inp else None
   for rep in range(11):
    order=list(raw);rng.shuffle(order)
    for label in order:
     active=W/'bin/area_active';shutil.copyfile(bins[kind][label],active);active.chmod(0o755)
     if kind=='main':
      start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','11',str(active)],input=input_data,capture_output=True);elapsed=time.perf_counter_ns()-start;assert p.returncode==0 and p.stdout==exact(inp),(cc,profile,kind,label,p.stdout,p.stderr)
     else:
      p=subprocess.run(['taskset','-c','11',str(active),*args],capture_output=True,text=True);assert p.returncode==0,p.stderr;a=p.stdout.split();elapsed=round(float(a[0])*1000000) if kind.endswith('core') else int(a[0]);checks[label]=a[1:];assert len({tuple(x) for x in checks.values()})==1
     if rep>=2:raw[label].append(elapsed)
   med={k:statistics.median(v) for k,v in raw.items()};rows.append({'kind':'timing','compiler':cc,'profile':profile,'scope':kind,'case':name,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest() if inp else None,'output_reference_equal':True,'checksums':checks,'raw_ns':raw,'median_ns':med,'ratio':med['candidate']/med['baseline']});save();print(cc,profile,kind,name,{k:round(v/1e6,4) for k,v in med.items()},flush=True)
