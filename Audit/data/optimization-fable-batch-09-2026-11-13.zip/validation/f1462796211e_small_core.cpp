// SPDX-License-Identifier: CC0-1.0
#include SIRKIT_GEOMETRY_TEST_HEADER
#include <array>
#include <chrono>
#include <cinttypes>
#include <cstdio>
#include <cstdlib>
#include <random>
#include <vector>
int main(){
 using P=geo::PointI;std::mt19937_64 rng(882519);std::vector<std::array<P,3>> inputs(262144);long double expected=0;
 for(auto& tri:inputs){for(auto&p:tri)p={std::int64_t(rng()%2000001)-1000000,std::int64_t(rng()%2000001)-1000000};std::int64_t twice=0;for(int i=0;i<3;++i)twice+=tri[i].x*tri[(i+1)%3].y-tri[i].y*tri[(i+1)%3].x;expected+=std::abs(static_cast<long double>(twice))/2;}
 std::vector<P> triangle(3);long double result=0;const auto start=std::chrono::steady_clock::now();
 for(const auto& t:inputs){triangle[0]=t[0];triangle[1]=t[1];triangle[2]=t[2];result+=geo::area(triangle);}
 const auto elapsed=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count();if(result!=expected)std::abort();
 std::printf("%" PRId64 " %.21Lg\n",std::int64_t(elapsed),result);
}
