from pathlib import Path
import shutil,json,hashlib,sys,subprocess
R=Path('/home/reinsirk/Atcoder_Env');W=Path(__file__).parent;old=(R/'Geometry/components/polygon.inc').read_text();marker='    if (poly.size() < 3) return C{0};\n';assert old.count(marker)==1
addition='''#if defined(__SIZEOF_INT128__) && !defined(GEO_DISABLE_INT128) && !defined(SIRKIT_FORCE_STANDARD_ARITHMETIC)
    if constexpr (std::is_integral_v<T> && sizeof(T) <= 8 && std::is_same_v<C, __int128_t>) {
        // 生座標の拡幅積を符号なしで累積し、2^128を法として真値を保つ。
        __uint128_t result = 0;
        const auto* end = poly.data() + poly.size();
        const auto* previous = end - 1;
        for (const auto* current = poly.data(); current != end; previous = current++)
            result += static_cast<__uint128_t>(C(previous->x) * C(current->y)) -
                      static_cast<__uint128_t>(C(previous->y) * C(current->x));
        return static_cast<C>(result);
    }
#endif
''';new=old.replace(marker,marker+addition,1);rows=[];sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
for label,source in [('baseline',old),('candidate',new)]:
 d=W/label;shutil.copytree(R/'Geometry/components',d/'components',dirs_exist_ok=True);(d/'components/polygon.inc').write_text(source);p=subprocess.run([sys.executable,str(R/'Scripts/generate_geometry.py'),'--components-dir',str(d/'components'),'--output-dir',str(d)],capture_output=True,text=True);assert p.returncode==0,p.stderr
 for ident in ['geometry_triangle_area_full','geometry_triangle_area_split']:
  e=next(e for e in pv.collect() if e['id']==ident);lib=e['libraries'][0];data=pv.render(e,source_overrides={lib:(d/lib).read_bytes()})[0];(d/(ident+'.cpp')).write_bytes(data);rows.append({'label':label,'id':ident,'entry':e,'component_sha256':hashlib.sha256(source.encode()).hexdigest(),'library_sha256':hashlib.sha256((d/lib).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(data).hexdigest()})
(W/'metadata.json').write_text(json.dumps(rows,indent=2)+'\n')
ref=(R/'Verify/current/tests/geometry_area_reference_test.cpp').read_text();extra='''void raw_prefix_boundary() {
 using P=geo::PointI;
 const auto low=std::numeric_limits<std::int64_t>::lowest(),high=std::numeric_limits<std::int64_t>::max();
 // 途中の生靴紐和は2^127だが、三角扇と最終値2*(2^64-1)は128bitに収まる。
 integer_variants(std::vector<P>{{low,low},{high,low},{high,low+1},{low,low+1}},false);
 // 標準64bit経路でも、原点差分は小さく収まる平行移動を確認する。
 integer_variants(std::vector<P>{{low,high},{low+17,high},{low+17,high-11},{low,high-11}},false);
}
''';ref=ref.replace('int main() {',extra+'\nint main() {\n    raw_prefix_boundary();',1);(W/'reference_test.cpp').write_text(ref)
shutil.copyfile('/tmp/sirkit_remaining_20261113/geometry/geometry_body_benchmark.cpp',W/'existing_core.cpp')
# Reuse actual compiler prefixes in the exact production Verify source.
for label in ['baseline','candidate']:
 for profile,ident in [('full','geometry_triangle_area_full'),('split','geometry_triangle_area_split')]:
  source=(W/label/(ident+'.cpp')).read_text();prefix=source.split('// Verify:',1)[0];(W/label/(profile+'_prefix.hpp')).write_text(prefix)
