// SPDX-License-Identifier: CC0-1.0
#include SIRKIT_GEOMETRY_TEST_HEADER
#include <chrono>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
int main(int argc,char**argv){
 if(argc!=4)return 1;const bool zig=std::string(argv[2])=="zig";const int n=std::stoi(argv[3]);std::vector<geo::PointI> poly;
 for(int i=0;i<n/2;++i)poly.push_back({i,zig?(i%2)*200000:200000});
 for(int i=n/2-1;i>=0;--i)poly.push_back({i,-100000});
 long double real=0;const auto start=std::chrono::steady_clock::now();
 for(int k=0;k<100;++k){poly[0].x=k;real+=geo::area(poly);}
 const auto end=std::chrono::steady_clock::now();std::cout<<std::chrono::duration<double,std::milli>(end-start).count()<<' '<<0<<' '<<std::setprecision(20)<<real<<'\n';
}
