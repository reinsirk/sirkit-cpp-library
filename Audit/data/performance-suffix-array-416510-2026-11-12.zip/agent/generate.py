#!/usr/bin/env python3
"""Generate isolated suffix-array allocation candidates; never compile or execute them."""
from pathlib import Path
import hashlib
import json

SOURCE = Path('/home/reinsirk/Atcoder_Env/String/Suffix_Array.cpp')
OUT = Path(__file__).resolve().parent
EXPECTED_SHA256 = '1a2e92cdeb08614a7dd2995cee9fd1971e7733c6d0a7ad19ce4004137dc93644'

original_bytes = SOURCE.read_bytes()
assert hashlib.sha256(original_bytes).hexdigest() == EXPECTED_SHA256
original = original_bytes.decode()

OLD_RECURSIVE = '''    std::vector<int> reduced_order(count);
    if (name + 1 == count) {
        for (int i = 0; i < count; ++i) reduced_order[reduced[i]] = i;
    } else reduced_order = suffix_induced(reduced, name);
'''
NEW_RECURSIVE = '''    const bool distinct_names = name + 1 == count;
    auto reduced_order = distinct_names ? std::vector<int>(count) : suffix_induced(reduced, name);
    if (distinct_names) {
        for (int i = 0; i < count; ++i) reduced_order[reduced[i]] = i;
    }
'''
OLD_ORDER = '''    std::vector<int> final_order(count);
    for (int i = 0; i < count; ++i) final_order[i] = selected[reduced_order[i]];
    induce(final_order, true);
'''
NEW_ORDER = '''    for (int& position : reduced_order) position = selected[position];
    induce(reduced_order, true);
'''
assert original.count(OLD_RECURSIVE) == 1
assert original.count(OLD_ORDER) == 1

candidates = {
    'recursive_alloc.hpp': original.replace(OLD_RECURSIVE, NEW_RECURSIVE),
    'order_reuse.hpp': original.replace(OLD_ORDER, NEW_ORDER),
    'combined.hpp': original.replace(OLD_RECURSIVE, NEW_RECURSIVE).replace(OLD_ORDER, NEW_ORDER),
}
metadata = {
    'source': str(SOURCE),
    'source_sha256': EXPECTED_SHA256,
    'candidate_execution': False,
    'compilation': False,
    'benchmark': False,
    'candidates': {},
}
for name, content in candidates.items():
    payload = content.encode()
    (OUT / name).write_bytes(payload)
    metadata['candidates'][name] = {
        'sha256': hashlib.sha256(payload).hexdigest(),
        'bytes': len(payload),
        'recursive_allocation_elision': name != 'order_reuse.hpp',
        'final_order_reuse': name != 'recursive_alloc.hpp',
    }
(OUT / 'metadata.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
