# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,subprocess,os,random,fcntl,shutil,statistics,hashlib
D=Path('/tmp/sirkit_suffix_416510');fixtures=json.loads((D/'fixtures.json').read_text())
raw=[];summary=[];rng=random.Random(416510)
def run(cc,identifier,label,fixture):
    shutil.copyfile(D/f'{cc}_{label}_{identifier}',D/'active');(D/'active').chmod(0o700)
    with Path(fixture['path']).open('rb')as fi,(D/'output').open('wb')as fo:
        p=subprocess.Popen(['setarch','x86_64','-R','taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo)
        _,status,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status);assert p.returncode==0
    digest=hashlib.sha256((D/'output').read_bytes()).hexdigest();expected=fixture['oracles'].get(identifier,{}).get('expected_sha256')
    if expected:assert digest==expected
    return dict(cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),output_sha256=digest)
def main():
    with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        for cc in ['gcc','clang']:
            for identifier in ['suffix_array','suffix_array_substrings']:
                for fixture in fixtures:
                    kinds=['combined']*9+['control']*3;rng.shuffle(kinds);local=[]
                    for rep,kind in enumerate(kinds):
                        values=[run(cc,identifier,label,fixture)for label in ['base','combined'if kind=='combined'else'base','base']]
                        assert len({v['output_sha256']for v in values})==1
                        b0,t,b1=[v['cpu_ns']for v in values];drift=max(b0,b1)/min(b0,b1)
                        row=dict(compiler=cc,id=identifier,case=fixture['name'],rep=rep,kind=kind,before=values[0],target=values[1],after=values[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b0,b1]))
                        raw.append(row);local.append(row)
                    ratios={kind:[r['ratio']for r in local if r['kind']==kind and r['calibration_valid']]for kind in ['combined','control']}
                    row=dict(compiler=cc,id=identifier,case=fixture['name'],n=fixture['n'],valid_counts={k:len(v)for k,v in ratios.items()},ratios={k:statistics.median(v)if v else None for k,v in ratios.items()},sufficient=len(ratios['combined'])>=5 and len(ratios['control'])>=2)
                    summary.append(row);print(row,flush=True)
                    (D/'paired_raw.json').write_text(json.dumps(raw));(D/'paired_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print('Completed',len(raw),'triplets',len(raw)*3,'executions',flush=True)

if __name__ == '__main__':
    main()
