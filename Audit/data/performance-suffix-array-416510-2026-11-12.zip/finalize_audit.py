# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,statistics,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_suffix_416510')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,a):p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
validation=load(D/'final_validation.json');assert validation['all_passed'] and validation['passed_jobs']==32
for row in validation['jobs']:assert row['source_sha256']==sha(Path(row['source']))
assert sha(R/'String/Suffix_Array.cpp')==sha(D/'final.hpp')
fixtures=load(D/'fixtures.json');whole_rows=load(D/'paired_summary.json');core_rows=load(D/'paired_core_summary.json')
assert len(whole_rows)==300 and all(r['sufficient']for r in whole_rows)
assert len(core_rows)==144 and all(r['sufficient']for r in core_rows)
whole=[];core=[]
for cc in ['gcc','clang']:
 for identifier in ['suffix_array','suffix_array_substrings']:
  a=[r for r in whole_rows if r['compiler']==cc and r['id']==identifier and r['n']>=200000]
  whole.append(dict(compiler=cc,id=identifier,cases=len(a),candidate_geometric_mean_ratio=statistics.geometric_mean(r['ratios']['combined']for r in a),identical_control_geometric_mean_ratio=statistics.geometric_mean(r['ratios']['control']for r in a),worst_candidate_ratio=max(r['ratios']['combined']for r in a)))
 for setting in ['checked','skip']:
  a=[r for r in core_rows if r['compiler']==cc and r['setting']==setting and r['n']==500000]
  core.append(dict(compiler=cc,setting=setting,cases=len(a),candidate_geometric_mean_ratio=statistics.geometric_mean(r['ratios']['combined']for r in a),identical_control_geometric_mean_ratio=statistics.geometric_mean(r['ratios']['control']for r in a),worst_candidate_ratio=max(r['ratios']['combined']for r in a)))
frozen={}
for p in ['Verify/current/drivers/suffix_array_main.cpp','Verify/current/drivers/suffix_array_substrings_main.cpp','Verify/current/common/fast_io.hpp','Document/suffix_array.md','Examples/suffix_array_example.cpp']:
 assert (R/p).read_bytes()==(D/'before'/p).read_bytes();frozen[p]=sha(R/p)
base=(D/'base.hpp').read_text();final=(D/'final.hpp').read_text();marker='#ifndef SIRKIT_SUFFIX_ARRAY_DEFINED';assert base[base.index(marker):]==final[final.index(marker):]
profiles=load(next((D/'profiles/runs').glob('*.json')));assert profiles['counts']=={'LOCAL_SAMPLE_PASS':14}
correspondence=load(D/'current_correspondence.json');assert len(correspondence)==4 and all(r['current_text_matches_measured_combined']for r in correspondence)
raw=load(D/'paired_raw.json');raw_core=load(D/'paired_core_raw.json')
audit=dict(date='2026-11-12',library='String/Suffix_Array.cpp',decision='adopt_conditional_recursive_allocation_and_in_place_final_order',required_resubmission=['Verify/current/submissions/suffix_array.cpp','Verify/current/submissions/suffix_array_substrings.cpp'],online_evidence='Audit/online-suffix-array-416510-416509-2026-11-12.json',online_scope='416510のAC48msと416509のAC46msは改修前通常版の記録。本体改修後の現行版と派生版は未提出。',source_sha256=dict(before=sha(D/'base.hpp'),after=sha(D/'final.hpp')),frozen_main_IO_document_examples=frozen,public_API_vector_shortcuts_LCP_checks_and_search_unchanged=True,changes=[
 '縮約列のLMS名が重複するとき、再帰先から返る順列を直接受け取る。直後に上書きするreduced_order(count)の確保・ゼロ初期化を省く。名前が全て異なる場合だけcount個を確保して逆順位表を作る。',
 '縮約順列の各要素をselected[旧値]へ置き換え、同じvectorを最終誘導へ渡す。別のfinal_orderを確保しない。selectedは別の所有配列で変更せず、各スロットの旧値だけを読むので変換同士は干渉しない。',
 '前回の度数集計統合、先頭要素が全て異なる汎用vectorの短縮経路、入力検査と内部の長さ上限を維持。公開APIを追加/改名しない。'
 ],ownership='vector/unique_ptrの所有を維持。直接new式や解放省略はなし。確保失敗試験の全4設定でlive_delta=0。',independent_review=(D/'agent/review.md').read_text(),measurement=dict(topology=load(D/'topology.json'),cpu_selection='CPU12、SMT sibling13、最大6GHzのP-Core。sysfs core_idは24。E-Coreの速度は測定していない。',compilers={'GCC':'15.2.0','Clang':'21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'},flags=['-std=c++23','-O2'],march_native=False,extra_pragmas=False,new_SIMD_or_CPU_dispatch=False,standard_CXX23_path=True,ASLR='setarch x86_64 -R for child only',lock='/tmp/sirkit_performance_cpu12.lock',compilation_during_timing=False,initial_screen='16入力・各7反復。GCCのperiodic3で同一baseが約14.5〜15.1msから10.1〜10.4msへ、binary_carryで約19〜20msから約27〜28msへ途中で変化。同一base/controlの全反復中央値だけの比率はこの区間で候補の採否に使わない。原因は特定していない。',paired_protocol='1組を旧版→候補→旧版とする。各入力9組の候補と3組の同一実行ファイル対照を決定的shuffle。同じactiveパス/入力/main/IOで、候補時間を直前直後の旧版の中央値で割る。',calibration='直前/直後の旧版が10%以内の組だけを使う基準を本測定前に固定。候補自身の時間を理由に除外しない。候補5組以上・対照2組以上を最低条件とし、不足した組種だけ最大3回・各3組追加。初回/補充のrawを両方保存。',whole_time='子プロセスのuser+system CPU時間。入力/出力は固定Verifyのまま。',whole_statistics=whole,whole_rows=len(whole_rows),whole_triplets=len(raw),whole_executions=3*len(raw),whole_rejected_reference_triplets=sum(not r['calibration_valid']for r in raw),large_selection='入力長20万以上の48ケース。小さい入力の起動費を平均改善率へ混ぜない。',fixture_rows=len(fixtures),byte_unique_inputs=len({f['sha256']for f in fixtures}),fixture_origin='Audit/data/performance-suffix-array-416380-2026-11-11.zipと同じ固定公開生成器/補助入力をSHAで対応。',official_revision='73876f1cbcf082d2b22722924b924d3d65a2f00e',fixture_scope='公開生成方法と固定seed・独立補助入力。制約外100万要素を含み、オンライン入力との同一性は主張しない。',all_whole_outputs_equal=True,core_time='std::clock()のプロセスCPU時間。作成/事前SA構築は外、APIの計算・全結果checksum・返却配列の破棄は内。事前SA構築後の確保状態は含む。',core_operations=['bounded narrow-alphabet SA','compressed int64 narrow-alphabet SA','vector<bool> SA','bounded permutation/large alphabet SA'],core_settings=['checked','SKIP_RUNTIME_CHECKS'],core_sizes=[32,4096,500000],core_statistics=core,core_rows=len(core_rows),core_triplets=len(raw_core),core_executions=3*len(raw_core),core_rejected_reference_triplets=sum(not r['calibration_valid']for r in raw_core),all_core_outputs_equal=True),candidate_scope='recursive_alloc/order_reuse/combinedを独立参照と初回screenで比較。組合せ版を、未使用確保と別配列の両方を省く候補として本測定へ進めた。',validation=dict(jobs=32,all_passed=True,compiler_and_checks='GCC/Clang × checked/SKIP_RUNTIME_CHECKS',tests=['ACL形式API・独立naive SA/LCP・整数極値/非コピー型/bool','短列SA・LCP・検索参照と全二進列','20万要素の独立doubling参照等','固有値/周期列の数式による大alphabet・256/257種類・境界長','確保失敗・所有権・入力不変性'],ownership_extension='繰り返すmississippi列で再帰側、LMSの先頭値が異なる列で直接順位付け側を追加。期待SAはsuffixをstd::string_viewで直接比較する独立整列で作る。各budget0..79で結果/解放/入力不変性を確認。',sanitizers='API/短列参照/度数集計参照をASAN+UBSANでも全4設定実行。hostのptrace制約によりdetect_leaks=0、解放は独立の確保カウンタで検証。',allocation_counters=[r['counters']for r in validation['jobs']if r['test']=='string_math_allocation_test'],variant_and_example_profiles=profiles,current_correspondence=correspondence),limits='追加の速度差は約1%と小さく、全CPU・全ての呼出し文脈での厳密な非後退やオンラインの所要時間は保証しない。',license='CC0-1.0独自実装。新しい外部コードを転記せず、数学的なSA-IS原論文とACL公開APIの参照を維持。公開問題生成器の本文は配布コード/証拠ZIPへ入れない。',evidence='Audit/data/performance-suffix-array-416510-2026-11-12.zip')
put(R/'Audit/performance-suffix-array-416510-2026-11-12.json',audit)
files=[p for p in D.iterdir()if p.is_file()and p.suffix in ['.json','.py','.hpp','.cpp']]
files += [p for p in (D/'agent').iterdir()if p.is_file()and p.suffix in ['.json','.py','.hpp','.txt','.md']]
for directory in ['before','after','profiles/runs']:
 files += [p for p in (D/directory).rglob('*')if p.is_file()and p.suffix in ['.json','.cpp','.hpp','.md']]
with zipfile.ZipFile(R/audit['evidence'],'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(set(files)):z.write(p,str(p.relative_to(D)))
print('audit/evidence ready',whole,core)
