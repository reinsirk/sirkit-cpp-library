# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,json,fcntl,statistics
D=Path('/tmp/sirkit_suffix_416510');sys.path.insert(0,str(D));import paired_whole as w;import paired_core as c
for stem,module in [('paired',w),('paired_core',c)]:
 rp=D/(stem+'_raw.json');sp=D/(stem+'_summary.json');raw=json.loads(rp.read_text());summary=json.loads(sp.read_text());(D/(stem+'_initial_raw.json')).write_bytes(rp.read_bytes());(D/(stem+'_initial_summary.json')).write_bytes(sp.read_bytes())
 with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  for row in summary:
   if row['sufficient']:continue
   if stem=='paired':
    def belongs(r):return (r['compiler'],r['id'],r['case'])==(row['compiler'],row['id'],row['case'])
    fixture=next(f for f in w.fixtures if f['name']==row['case'])
    def run(label):return w.run(row['compiler'],row['id'],label,fixture)
    field='kind'
   else:
    fields=['compiler','setting','kind','n','shape']
    def belongs(r):return all(r[k]==row[k]for k in fields)
    def run(label):return c.run(row['compiler'],row['setting'],label,row['kind'],row['n'],row['shape'])
    field='target_kind'
   local=[r for r in raw if belongs(r)]
   for attempt in range(3):
    missing=[k for k,minimum in [('combined',5),('control',2)]if sum(r['calibration_valid']and r[field]==k for r in local)<minimum]
    if not missing:break
    for kind in missing:
     for extra in range(3):
      values=[run(label)for label in ['base','combined'if kind=='combined'else'base','base']];key='output_sha256'if stem=='paired'else'digest';assert len({v[key]for v in values})==1
      b0,t,b1=[v['cpu_ns']for v in values];drift=max(b0,b1)/min(b0,b1);r={k:row[k]for k in (['compiler','id','case']if stem=='paired'else fields)};r.update(rep=len(local),repair=True,before=values[0],target=values[1],after=values[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b0,b1]));r[field]=kind;local.append(r);raw.append(r)
   ratios={k:[r['ratio']for r in local if r[field]==k and r['calibration_valid']]for k in ['combined','control']};row.update(valid_counts={k:len(v)for k,v in ratios.items()},ratios={k:statistics.median(v)if v else None for k,v in ratios.items()},sufficient=len(ratios['combined'])>=5 and len(ratios['control'])>=2,calibration_repaired=True);print(stem,row,flush=True)
  rp.write_text(json.dumps(raw));sp.write_text(json.dumps(summary,indent=2)+'\n')
 print(stem,'sufficient',sum(r['sufficient']for r in summary),'of',len(summary),flush=True)
