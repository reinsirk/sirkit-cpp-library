// SPDX-License-Identifier: CC0-1.0
// Public-API-only fixed-input kernel comparison; inputs/build/destruction excluded from loop CPU time.
#include HLD_SOURCE
#include FW_SOURCE
#include SEG_SOURCE
#ifdef BENCH_ACL_BIT
#include ACL_FW_SOURCE
#endif
#include <algorithm>
#include <bit>
#include <chrono>
#include <cinttypes>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <numeric>
#include <random>
#include <string>
#include <vector>
using I=std::int64_t;
#ifdef BENCH_ACL_BIT
using BitBackend=atcoder::fenwick_tree<I>;
#else
using BitBackend=fenwick_tree<I>;
#endif
constexpr std::uint64_t mod=998244353;
struct Affine { std::uint64_t a,b; };
Affine compose(Affine x,Affine y){return {x.a*y.a%mod,(x.b*y.a+y.b)%mod};}
Affine identity(){return {1,0};}
struct Query { int u,v;std::int64_t k; };
int main(int argc,char**argv){
 if(argc!=4)return 2;int n=std::atoi(argv[1]),count=std::atoi(argv[3]);std::string shape=argv[2];
 std::mt19937_64 rng(8404320501ULL);std::vector<int> label(n);std::iota(label.begin(),label.end(),0);std::shuffle(label.begin(),label.end(),rng);
 Graph graph(n);const int group=shape=="forest"?std::max(1,n/8):n;
 for(int i=1;i<n;++i){if(i%group==0)continue;int p=shape=="path"?i-1:shape=="star"?0:static_cast<int>(rng()%static_cast<unsigned>(i%group))+i/group*group;int u=label[i],v=label[p];graph[u].push_back(v);graph[v].push_back(u);}
 std::vector<Query> qs;qs.reserve(count);for(int i=0;i<count;++i){int a=static_cast<int>(rng()%n),begin=a/group*group,end=std::min(n,begin+group);int b=begin+static_cast<int>(rng()%static_cast<unsigned>(end-begin));qs.push_back({label[a],label[b],static_cast<std::int64_t>(rng()%128)});}
 std::uint64_t digest=0;auto timed=[&](const char* name,auto&& fn){auto c=std::clock();fn();double ms=1000.0*static_cast<double>(std::clock()-c)/CLOCKS_PER_SEC;std::printf("%s %.6f %016" PRIx64 "\n",name,ms,digest);};
 HeavyLightDecomposition h;const int build_reps=n<1000?2000:5;timed("build",[&]{for(int rep=0;rep<build_reps;++rep){h.build(graph,label[0]);digest^=static_cast<unsigned>(h.size());}});
 timed("lca",[&]{for(const auto q:qs)digest=std::rotl(digest,1)^static_cast<unsigned>(h.lca(q.u,q.v));});
 timed("jump",[&]{for(const auto q:qs)digest=std::rotl(digest,1)^static_cast<unsigned>(h.jump(q.u,q.v,q.k));});
 std::vector<Query> valid=qs;for(auto& q:valid)q.k%=static_cast<std::int64_t>(h.distance(q.u,q.v))+1;
 timed("jump_valid",[&]{for(const auto q:valid)digest=std::rotl(digest,1)^static_cast<unsigned>(h.jump(q.u,q.v,q.k));});
 // Order-independent vertex sums make checksums independent of equally valid heavy-child tie choices.
 const auto ordered=h.reorder(label);std::vector<I> prefix(n+1);for(int i=0;i<n;++i)prefix[i+1]=prefix[i]+ordered[i];
 timed("split",[&]{for(const auto q:qs){I sum=0;h.for_each_path(q.u,q.v,[&](int l,int r,bool){sum+=prefix[r]-prefix[l];});digest=std::rotl(digest,1)^static_cast<std::uint64_t>(sum);}});
 std::vector<I> values(n);for(int i=0;i<n;++i)values[i]=i%10000;auto bit=h.with_values<BitBackend>(values);
 timed("bit",[&]{for(int i=0;i<count;++i){const auto q=qs[i];if((i&7)==0)bit.add(q.u,1);else digest=std::rotl(digest,1)^static_cast<std::uint64_t>(bit.path_prod(q.u,q.v));}});
 std::vector<Affine> affine(n);for(int i=0;i<n;++i)affine[i]={static_cast<unsigned>(i+1),static_cast<unsigned>(i+7)};auto seg=h.with_values<segtree<Affine,compose,identity>,true>(affine);
 timed("affine",[&]{for(int i=0;i<count;++i){const auto q=qs[i];if((i&7)==0)seg.set(q.u,{static_cast<unsigned>(i+1),static_cast<unsigned>(i+7)});else {auto x=seg.path_prod(q.u,q.v);digest=std::rotl(digest,1)^x.a^(x.b<<32);}}});
}
