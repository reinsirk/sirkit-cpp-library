#!/usr/bin/env python3
# SPDX-License-Identifier: CC0-1.0
import argparse,concurrent.futures,hashlib,json,pathlib,re,subprocess,time
P=pathlib.Path(__file__).resolve().parent
B=P.parent/'history/baseline'; T=B/'Verify/current/tests'
a=argparse.ArgumentParser();a.add_argument('label');a.add_argument('header',type=pathlib.Path);a.add_argument('--jobs',type=int,default=2);a.add_argument('--quick',action='store_true');args=a.parse_args();header=args.header.resolve()
O=P/('tests-'+args.label);O.mkdir(exist_ok=True)
tests=['new_hld_reference_test','hld_helpers_test','hld_fenwick_path_test','hld_owned_allocation_test','hld_owned_test','hld_paired_update_test']
# Test copies only adjust include paths; assertions are unchanged.
for name in tests:
 s=(T/(name+'.cpp')).read_text()
 s=s.replace('#include "../../../Graph/Heavy_Light_Decomposition.cpp"','#include HLD_SOURCE')
 s=re.sub(r'#include "([^"\n]+)"',lambda m:'#include "'+str((T/m[1]).resolve())+'"' if (T/m[1]).exists() else m[0],s)
 (O/(name+'.cpp')).write_text(s)
work=[]
for cc in ['gcc','clang']:
 for skip in [False,True]:
  for fallback in [False,True]:
   for name in tests:
    work.append((cc,skip,fallback,name,False))
 for name in ['hld_helpers_test','hld_owned_test']:
  for skip in [False,True]:work.append((cc,skip,False,name,True))
if args.quick:work=[t for t in work if t[0]=='gcc' and not any([t[1],t[2],t[4]])]
def run(t):
 cc,skip,fallback,name,first=t;k=f'{cc}-{name}-'+('skip' if skip else 'checked')+('-fallback' if fallback else '')+('-rangesfirst' if first else '')
 exe=O/k;cmd=['/usr/bin/g++-15' if cc=='gcc' else '/usr/bin/clang++-21','-std=c++23','-O2','-Wall','-Wextra','-Werror','-I'+str(B/'Verify/current/vendor'),'-DHLD_SOURCE="'+str(header)+'"','-DPAIR_HLD_SOURCE="'+str(header)+'"']
 if cc=='clang':cmd+=['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-Wno-self-assign-overloaded']
 if cc=='gcc' and name=='hld_owned_allocation_test':cmd+=['-Wno-mismatched-new-delete']
 if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
 if fallback:cmd+=['-U__SIZEOF_INT128__','-DSIRKIT_DISABLE_SIMD']
 if first:cmd+=['-DSIRKIT_HLD_HELPERS_RANGES_FIRST','-DSIRKIT_HLD_OWNED_RANGES_FIRST','-DSIRKIT_HLD_PAIR_SEG_FIRST']
 cmd += [str(O/(name+'.cpp')),'-o',str(exe)]
 p=subprocess.run(cmd,text=True,capture_output=True);r=dict(case=k,compile_command=cmd,compile_exit=p.returncode,compile_output=p.stdout+p.stderr)
 if p.returncode==0:
  try:
   q=subprocess.run([str(exe)],text=True,capture_output=True,timeout=90);r.update(run_exit=q.returncode,run_output=q.stdout+q.stderr)
  except subprocess.TimeoutExpired:r.update(run_exit='timeout')
 (O/(k+'.json')).write_text(json.dumps(r,indent=2)); print(k,'compile',p.returncode,'run',r.get('run_exit'),flush=True);return r
start=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:results=list(pool.map(run,work))
record=dict(header=str(header),source_sha256=hashlib.sha256(header.read_bytes()).hexdigest(),elapsed_seconds=time.time()-start,results=results)
(O/'summary.json').write_text(json.dumps(record,indent=2)); print('DONE',len(results),sum(x.get('run_exit')==0 for x in results),flush=True)
