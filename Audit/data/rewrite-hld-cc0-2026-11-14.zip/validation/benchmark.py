#!/usr/bin/env python3
# SPDX-License-Identifier: CC0-1.0
import argparse,hashlib,json,pathlib,platform,random,statistics,subprocess,time
P=pathlib.Path(__file__).resolve().parent;B=P.parent/'history/baseline';a=argparse.ArgumentParser();a.add_argument('--new',type=pathlib.Path);a.add_argument('--baseline-header',type=pathlib.Path);a.add_argument('--acl-bit',action='store_true');a.add_argument('--sizes',type=int,nargs='+',default=[64,100000]);a.add_argument('--shapes',nargs='+',default=['path','star','random','forest']);a.add_argument('--out',default='bench-results');a.add_argument('--prepare-only',action='store_true');a.add_argument('--run-only',action='store_true');a.add_argument('--reps',type=int,default=5);args=a.parse_args()
headers={'old':args.baseline_header.resolve() if args.baseline_header else B/'Graph/Heavy_Light_Decomposition.cpp'}
if args.new:headers['new']=args.new.resolve()
out=P/args.out;out.mkdir(exist_ok=True);builds={}
for cc in ['gcc','clang']:
 for label,header in headers.items():
  exe=out/(cc+'-'+label);cmd=['/usr/bin/g++-15' if cc=='gcc' else '/usr/bin/clang++-21','-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS','-DNDEBUG','-DHLD_SOURCE="'+str(header)+'"','-DFW_SOURCE="'+str(B/'DataStructure/Fenwick_Tree.cpp')+'"','-DSEG_SOURCE="'+str(B/'DataStructure/Segment_Tree.cpp')+'"']
  if cc=='clang':cmd+=['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
  if args.acl_bit:cmd+=['-DBENCH_ACL_BIT','-DACL_FW_SOURCE="'+str(B/'Verify/current/vendor/atcoder/fenwicktree.hpp')+'"','-I'+str(B/'Verify/current/vendor')]
  cmd += [str(P/'bench.cpp'),'-o',str(exe)]
  if args.run_only:
   saved=json.loads((out/'builds.json').read_text())[cc+'-'+label]
   assert saved['header_sha256']==hashlib.sha256(header.read_bytes()).hexdigest() and saved['main_sha256']==hashlib.sha256((P/'bench.cpp').read_bytes()).hexdigest()
   builds[cc+'-'+label]=saved
   continue
  p=subprocess.run(cmd,text=True,capture_output=True);builds[cc+'-'+label]=dict(command=cmd,exit=p.returncode,output=p.stdout+p.stderr,header_sha256=hashlib.sha256(header.read_bytes()).hexdigest(),main_sha256=hashlib.sha256((P/'bench.cpp').read_bytes()).hexdigest(),fenwick_sha256=hashlib.sha256((B/'DataStructure/Fenwick_Tree.cpp').read_bytes()).hexdigest(),segment_sha256=hashlib.sha256((B/'DataStructure/Segment_Tree.cpp').read_bytes()).hexdigest())
  if p.returncode:print(p.stderr);raise SystemExit(1)
(out/'builds.json').write_text(json.dumps(builds,indent=2))
if args.prepare_only:raise SystemExit(0)
raw=[];tasks=[(cc,n,shape,rep,label) for cc in ['gcc','clang'] for n in args.sizes for shape in args.shapes for rep in range(args.reps) for label in headers];random.Random(10029).shuffle(tasks)
for cc,n,shape,rep,label in tasks:
 exe=out/(cc+'-'+label);cmd=['taskset','-c','12',str(exe),str(n),shape,'600000' if n==64 else '200000'];r=subprocess.run(cmd,text=True,capture_output=True)
 if r.returncode:raise RuntimeError(r.stderr)
 rows={}
 for line in r.stdout.splitlines():
  mode,ms,digest=line.split();rows[mode]=dict(cpu_ms=float(ms),digest=digest)
 raw.append(dict(compiler=cc,n=n,shape=shape,rep=rep,label=label,rows=rows));(out/'raw.json').write_text(json.dumps(raw,indent=2));print(cc,n,shape,rep,label,flush=True)
summary=[]
for cc in ['gcc','clang']:
 for n in args.sizes:
  for shape in args.shapes:
   for mode in ['build','lca','jump','jump_valid','split','bit','affine']:
    groups={label:[r['rows'][mode] for r in raw if (r['compiler'],r['n'],r['shape'],r['label'])==(cc,n,shape,label)] for label in headers}
    med={k:statistics.median(x['cpu_ms'] for x in v)for k,v in groups.items()};digests={x['digest'] for v in groups.values()for x in v}
    summary.append(dict(compiler=cc,n=n,shape=shape,mode=mode,median_cpu_ms=med,ratio=med.get('new',med['old'])/med['old'] if med['old'] else None,digests_match=len(digests)==1))
record=dict(builds=builds,environment=dict(platform=platform.platform(),cpu=subprocess.check_output(['lscpu'],text=True),compiler_gcc=subprocess.check_output(['/usr/bin/g++-15','--version'],text=True),compiler_clang=subprocess.check_output(['/usr/bin/clang++-21','--version'],text=True),affinity_cpu=12,flags='C++23 -O2 SKIP_RUNTIME_CHECKS NDEBUG',scope='Public-API kernels. Input generation, construction and destruction excluded from lca/jump/split/bit/affine CPU times; build measures 2000 rebuilds at n64 or 5 rebuilds at n100000 (including previous-state release). Identical main and fixed inputs for old/new. jump uses k in [0,127], including out-of-range requests; jump_valid reduces k modulo distance+1 before timing. No I/O in measured loop.',reps=args.reps,bit_backend='real atcoder::fenwick_tree' if args.acl_bit else 'own fenwick_tree'),summary=summary)
(out/'summary.json').write_text(json.dumps(record,indent=2));print('DONE',len(raw),len(summary),flush=True)
