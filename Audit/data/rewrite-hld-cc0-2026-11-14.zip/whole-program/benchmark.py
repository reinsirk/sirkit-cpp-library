#!/usr/bin/env python3
# SPDX-License-Identifier: CC0-1.0
"""HLDだけを置換し、同一main・入出力の提出全体を比較する。"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import random
import resource
import shutil
import statistics
import subprocess
import sys
import tempfile
import time

ROOT = Path('/home/reinsirk/Atcoder_Env')
WORK = Path(__file__).resolve().parent
IDS = ('hld_jump', 'hld_vertex_add_path_sum', 'hld_path_prod', 'hld_path_composite')
HLD = 'Graph/Heavy_Light_Decomposition.cpp'
MOD = 998244353


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def make_input(identity, shape, n, q):
    rng = random.Random(129731 + n * 19 + ('chain', 'star', 'random').index(shape))
    parent = [0] + [v - 1 if shape == 'chain' else 0 if shape == 'star' else rng.randrange(v) for v in range(1, n)]
    depth = [0] * n
    for v in range(1, n):
        depth[v] = depth[parent[v]] + 1
    def distance(u, v):
        if shape == 'chain':
            return abs(u - v)
        if shape == 'star':
            return 0 if u == v else (u != 0) + (v != 0)
        a, b, steps = u, v, 0
        while depth[a] > depth[b]:
            a = parent[a]; steps += 1
        while depth[b] > depth[a]:
            b = parent[b]; steps += 1
        while a != b:
            a = parent[a]; b = parent[b]; steps += 2
        return steps
    lines = [f'{n} {q}']
    if identity == 'hld_path_composite':
        lines.extend(f'{rng.randrange(MOD)} {rng.randrange(MOD)}' for _ in range(n))
    elif identity != 'hld_jump':
        lines.append(' '.join(str(rng.randrange(1_000_000_001)) for _ in range(n)))
    lines.extend(f'{parent[v]} {v}' for v in range(1, n))
    for t in range(q):
        u, v = rng.randrange(n), rng.randrange(n)
        if t % 17 == 0:
            v = u
        elif t % 19 == 0:
            u, v = 0, n - 1
        if identity == 'hld_jump':
            d = distance(u, v)
            k = rng.randrange(d + 1) if t % 2 == 0 else rng.randrange(n)
            lines.append(f'{u} {v} {k}')
        elif identity == 'hld_path_composite':
            if t % 3 == 0:
                lines.append(f'0 {u} {rng.randrange(MOD)} {rng.randrange(MOD)}')
            else:
                lines.append(f'1 {u} {v} {rng.randrange(MOD)}')
        elif t % 3 == 0:
            lines.append(f'0 {u} {rng.randrange(1_000_000_001)}')
        else:
            lines.append(f'1 {u} {v}')
    return ('\n'.join(lines) + '\n').encode()


def prepare():
    metadata = WORK / 'baseline.json'
    if metadata.exists():
        raise RuntimeError('baseline.json already exists; immutable baseline was not overwritten')
    (WORK / 'baseline').mkdir(parents=True, exist_ok=True)
    old = (ROOT / HLD).read_bytes()
    (WORK / 'baseline/Heavy_Light_Decomposition.cpp').write_bytes(old)
    manifest = json.loads((ROOT / 'Verify/current/manifest.json').read_text())
    report = {'prepared_at_utc': utc(), 'old_hld_sha256': sha(old), 'entries': {}, 'inputs': [],
              'small': {'n': 64, 'q': 4096}, 'large': {'n': 100000, 'q': 200000},
              'input_kind': '正規の木。加算値0..1e9、合成係数・入力0..998244352。jumpは0<=k<n。'}
    for identity in IDS:
        entry = next(e for e in manifest['entries'] if e['id'] == identity)
        source = (ROOT / entry['submission']).read_bytes()
        assert source.count(old) == 1, identity
        prefix, suffix = source.split(old)
        assert b'#define SKIP_RUNTIME_CHECKS' in source
        (WORK / f'baseline/{identity}.cpp').write_bytes(source)
        report['entries'][identity] = {
            'submission': entry['submission'], 'old_submission_sha256': sha(source),
            'non_hld_prefix_sha256': sha(prefix), 'non_hld_suffix_sha256': sha(suffix),
            'driver': entry['driver'], 'driver_sha256': sha((ROOT / entry['driver']).read_bytes()),
            'io_sha256': sha((ROOT / 'Verify/current/common/fast_io.hpp').read_bytes()),
            'support_source_sha256': {p: sha((ROOT / p).read_bytes()) for p in entry['libraries'] if p != HLD},
            'problem_url': entry['problem_url'], 'samples': entry.get('samples', []),
            'pragmas': [line.decode() for line in source.splitlines() if b'#pragma' in line],
        }
        for shape in ('chain', 'star', 'random'):
            for scale, n, q in [('small', 64, 4096), ('large', 100000, 200000)]:
                path = WORK / f'inputs/{identity}_{shape}_{scale}.in'
                path.parent.mkdir(parents=True, exist_ok=True)
                data = make_input(identity, shape, n, q)
                path.write_bytes(data)
                report['inputs'].append({'id': identity, 'shape': shape, 'scale': scale, 'n': n, 'q': q,
                                         'path': str(path.relative_to(WORK)), 'bytes': len(data), 'sha256': sha(data)})
    save(metadata, report)
    print(json.dumps({'prepared': True, 'cases': len(report['inputs']), 'old_hld_sha256': sha(old),
                      'cpp_compilation_executed': False, 'measurement_executed': False}, ensure_ascii=False))


def execute(binary, input_path):
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    started = time.perf_counter()
    with open(input_path, 'rb') as input_file, tempfile.TemporaryFile() as output:
        run = subprocess.run([str(binary)], stdin=input_file, stdout=output, stderr=subprocess.PIPE, timeout=60)
        elapsed = time.perf_counter() - started
        after = resource.getrusage(resource.RUSAGE_CHILDREN)
        output.seek(0); data = output.read()
    if run.returncode:
        raise RuntimeError(f'{binary}: exit={run.returncode}; stderr={run.stderr.decode(errors="replace")[:1000]}')
    user = after.ru_utime - before.ru_utime
    system = after.ru_stime - before.ru_stime
    return data, {'cpu_s': user + system, 'user_cpu_s': user, 'system_cpu_s': system,
                  'wall_s': elapsed, 'stdout_sha256': sha(data), 'stdout_bytes': len(data)}


def measure(args):
    base = json.loads((WORK / 'baseline.json').read_text())
    candidate = args.candidate.read_bytes()
    assert sha(candidate) == args.candidate_sha256, 'candidate SHA changed or was not explicitly frozen'
    old = (WORK / 'baseline/Heavy_Light_Decomposition.cpp').read_bytes()
    assert sha(old) == base['old_hld_sha256']
    assert args.repetitions >= 3
    out = WORK / 'runs' / args.label
    out.mkdir(parents=True, exist_ok=False)
    (out / 'sources').mkdir()
    (out / 'Heavy_Light_Decomposition.cpp').write_bytes(candidate)
    report = {'started_at_utc': utc(), 'candidate_hld_sha256': sha(candidate), 'old_hld_sha256': sha(old),
              'comparison_scope': 'main・入出力を含む全体。HLD以外の本文は完全同一。旧新で同じ入力・flags・pragma・SKIP/NDEBUG設定。',
              'cpu': args.cpu, 'repetitions': args.repetitions, 'flags': ['-std=c++23', '-O2', '-DNDEBUG'],
              'samples': [], 'compilers': {}, 'sources': {}, 'cases': [], 'binaries': {}, 'completed': False,
              'candidate_source_path': str(args.candidate.resolve()), 'measurement_executed': False}
    for identity, e in base['entries'].items():
        before = (WORK / f'baseline/{identity}.cpp').read_bytes()
        assert sha(before) == e['old_submission_sha256']
        assert sha((ROOT / e['driver']).read_bytes()) == e['driver_sha256'], 'driver changed'
        assert sha((ROOT / 'Verify/current/common/fast_io.hpp').read_bytes()) == e['io_sha256'], 'I/O changed'
        for path, expected in e['support_source_sha256'].items():
            assert sha((ROOT / path).read_bytes()) == expected, f'support library changed: {path}'
        prefix, suffix = before.split(old)
        after = prefix + candidate + suffix
        assert sha(prefix) == e['non_hld_prefix_sha256'] and sha(suffix) == e['non_hld_suffix_sha256']
        assert after.replace(candidate, old, 1) == before
        (out / f'sources/{identity}_old.cpp').write_bytes(before)
        (out / f'sources/{identity}_new.cpp').write_bytes(after)
        report['sources'][identity] = dict(e, new_submission_sha256=sha(after), candidate_hld_sha256=sha(candidate),
                                            non_hld_body_identical=True)
    assert args.cpu in os.sched_getaffinity(0), 'requested CPU unavailable'
    os.sched_setaffinity(0, {args.cpu})
    for compiler, major in [('g++', '15'), ('clang++', '21')]:
        path = shutil.which(compiler)
        assert path
        version = subprocess.check_output([path, '--version'], text=True).splitlines()[0]
        assert (major + '.') in version, version
        extra = ['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'] if compiler == 'clang++' else []
        report['compilers'][compiler] = {'path': path, 'version': version, 'flags': [*extra, *report['flags']]}
        binaries = {}
        for identity in IDS:
            binaries[identity] = {}
            for variant in ('old', 'new'):
                binary = out / f'{identity}_{compiler.replace("+", "p")}_{variant}'
                cmd = [path, *extra, *report['flags'], str(out / f'sources/{identity}_{variant}.cpp'), '-o', str(binary)]
                build = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
                (out / (binary.name + '.build.log')).write_bytes(build.stdout + build.stderr)
                assert build.returncode == 0, cmd
                binaries[identity][variant] = binary
            for no, sample in enumerate(base['entries'][identity]['samples']):
                sample_input = out / f'{identity}_sample_{no}.in'; sample_input.write_text(sample['input'])
                actual = {}
                for variant in ('old', 'new'):
                    data, details = execute(binaries[identity][variant], sample_input)
                    assert data.split() == sample['output'].encode().split(), f'sample failed {identity} {variant}'
                    actual[variant] = data
                assert actual['old'] == actual['new']
                report['samples'].append({'id': identity, 'compiler': compiler, 'sample': no, 'correct': True,
                                           'stdout_identical': True, 'stdout_sha256': sha(actual['old'])})
        report['binaries'][compiler] = {identity: {variant: {'path': str(binary), 'sha256': sha(binary.read_bytes())}
                                                  for variant, binary in pair.items()}
                                         for identity, pair in binaries.items()}
        save(out / 'report.json', report)
        if args.build_only:
            print('build and samples complete', compiler, flush=True)
            continue
        for case in base['inputs']:
            input_path = WORK / case['path']
            assert sha(input_path.read_bytes()) == case['sha256']
            pair = binaries[case['id']]
            reference, _ = execute(pair['old'], input_path)
            warm_new, _ = execute(pair['new'], input_path)
            assert warm_new == reference, f'warmup mismatch {case}'
            timings = {'old': [], 'new': []}; rounds = []
            for trial in range(args.repetitions):
                order = ('old', 'new') if trial % 2 == 0 else ('new', 'old')
                records = {'trial': trial, 'order': list(order)}
                for variant in order:
                    data, details = execute(pair[variant], input_path)
                    assert data == reference, f'full stdout bytes mismatch {case} {variant}'
                    records[variant] = details
                    timings[variant].append(details['cpu_s'])
                rounds.append(records)
            medians = {v: statistics.median(t) for v, t in timings.items()}
            report['cases'].append(dict(case, compiler=compiler, stdout_identical_all_bytes=True,
                                         stdout_sha256=sha(reference), stdout_bytes=len(reference),
                                         median_cpu_s=medians, new_over_old=medians['new'] / medians['old'], rounds=rounds))
            save(out / 'report.json', report)
            print(compiler, case['id'], case['shape'], case['scale'], f"new/old={medians['new']/medians['old']:.4f}", flush=True)
    assert sha(args.candidate.read_bytes()) == args.candidate_sha256, 'candidate changed during comparison'
    if args.build_only:
        report['build_completed'] = True; report['build_finished_at_utc'] = utc()
        save(out / 'report.json', report)
        print('build-only report', out / 'report.json')
        return
    report['measurement_executed'] = True
    report['completed'] = True; report['finished_at_utc'] = utc()
    save(out / 'report.json', report)
    print('report', out / 'report.json')


def resume_measure(path):
    report = json.loads(path.read_text())
    assert report['build_completed'] and not report['completed']
    assert not report['cases'], 'use a fresh run if prior measurements were interrupted'
    base = json.loads((WORK / 'baseline.json').read_text())
    candidate_path = Path(report['candidate_source_path'])
    assert sha(candidate_path.read_bytes()) == report['candidate_hld_sha256']
    assert report['cpu'] in os.sched_getaffinity(0)
    os.sched_setaffinity(0, {report['cpu']})
    report['measurement_started_at_utc'] = utc()
    for compiler, entries in report['binaries'].items():
        binaries = {}
        for identity, pair in entries.items():
            binaries[identity] = {}
            for variant, record in pair.items():
                binary = Path(record['path']); assert sha(binary.read_bytes()) == record['sha256']
                binaries[identity][variant] = binary
        for case in base['inputs']:
            input_path = WORK / case['path']; assert sha(input_path.read_bytes()) == case['sha256']
            pair = binaries[case['id']]
            reference, _ = execute(pair['old'], input_path)
            warm_new, _ = execute(pair['new'], input_path)
            assert warm_new == reference, f'warmup mismatch {case}'
            timings = {'old': [], 'new': []}; rounds = []
            for trial in range(report['repetitions']):
                order = ('old', 'new') if trial % 2 == 0 else ('new', 'old')
                records = {'trial': trial, 'order': list(order)}
                for variant in order:
                    data, details = execute(pair[variant], input_path)
                    assert data == reference, f'full stdout bytes mismatch {case} {variant}'
                    records[variant] = details; timings[variant].append(details['cpu_s'])
                rounds.append(records)
            medians = {v: statistics.median(t) for v, t in timings.items()}
            report['cases'].append(dict(case, compiler=compiler, stdout_identical_all_bytes=True,
                                         stdout_sha256=sha(reference), stdout_bytes=len(reference),
                                         median_cpu_s=medians, new_over_old=medians['new'] / medians['old'], rounds=rounds))
            save(path, report)
            print(compiler, case['id'], case['shape'], case['scale'], f"new/old={medians['new']/medians['old']:.4f}", flush=True)
    assert sha(candidate_path.read_bytes()) == report['candidate_hld_sha256']
    report['measurement_executed'] = True; report['completed'] = True; report['finished_at_utc'] = utc()
    save(path, report)
    print('report', path)


def check_canonical(path):
    report = json.loads(path.read_text())
    assert report['completed']
    actual = sha((ROOT / HLD).read_bytes())
    checks = {'checked_at_utc': utc(), 'report': str(path), 'canonical_hld_sha256': actual,
              'hld_matches': actual == report['candidate_hld_sha256'], 'submissions': {}}
    for identity, entry in report['sources'].items():
        digest = sha((ROOT / entry['submission']).read_bytes())
        checks['submissions'][identity] = {'canonical_sha256': digest, 'measured_new_sha256': entry['new_submission_sha256'],
                                           'matches': digest == entry['new_submission_sha256']}
    checks['all_match'] = checks['hld_matches'] and all(x['matches'] for x in checks['submissions'].values())
    save(path.parent / 'canonical-source-match.json', checks)
    print(json.dumps(checks, ensure_ascii=False))
    assert checks['all_match'], 'canonical generation differs from measured source'


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--prepare', action='store_true')
    action.add_argument('--measure', action='store_true')
    action.add_argument('--resume-measure', type=Path)
    action.add_argument('--check-canonical', type=Path)
    parser.add_argument('--candidate', type=Path)
    parser.add_argument('--candidate-sha256')
    parser.add_argument('--label')
    parser.add_argument('--build-only', action='store_true')
    parser.add_argument('--repetitions', type=int, default=7)
    parser.add_argument('--cpu', type=int, default=12)
    args = parser.parse_args()
    if args.prepare:
        prepare()
    elif args.check_canonical:
        check_canonical(args.check_canonical)
    elif args.resume_measure:
        resume_measure(args.resume_measure)
    else:
        if not (args.candidate and args.candidate_sha256 and args.label):
            parser.error('--measure requires --candidate, --candidate-sha256 and --label')
        measure(args)
