HLD再実装の検証記録（2026-11-14）

current/ は検証した新実装。API参考は reference/ のNyaan CC0固定版。
旧HLDは複製していない。リポジトリの以下の版から復元できる。
  git show a75a165416cf8556f2c2924239441454c3957e7d:Graph/Heavy_Light_Decomposition.cpp
旧HLDのSHA-256:
  21c6d1562e484c9217134f11a70d6757a66b295d1f334f44861251f0905576bb

validation/ のrun_tests.py・bench.cpp・benchmark.pyは試験と本体比較。
history/baseline/ に同commitの依存ソースと試験を復元して使う。
必要なパスとSHAは validation/test-source-manifest.json と各summaryに記録。
whole-program/ はmain・I/Oを含む比較。benchmark.pyで固定入力を生成する。
program-parts/ のprefix + 旧/新HLD + suffixで、測定した提出を再構成できる。
固定CPUとcompiler/stdlibの絶対パスは記録環境用。他環境では調整が必要。

旧新間の同条件比較を行った。本体比較と全体比較はGCCのパッチ版が異なる。
両測定の比を直接差し引いてI/Oなどの寄与と解釈しない。
全条件での高速化は主張しない。後退した条件もsummaryに記録している。
ローカル結果をオンラインACと扱わない。
