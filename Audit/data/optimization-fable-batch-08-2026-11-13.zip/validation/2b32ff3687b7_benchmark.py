from pathlib import Path
import json,subprocess,hashlib,random,statistics,time,shutil
W=Path(__file__).parent;rows=[];variants=['baseline','histogram','unique'];wholecases=['random_262144','collinear_262144','duplicate_262144','sorted_262144','sparse_duplicate_262144','random_16383','random_16384','random_16385','duplicate_16384','span32_262144','negative_262144'];corecases=['random_262144','collinear_262144','duplicate_262144','sorted_262144','sparse_duplicate_262144','random_16383','random_16384','random_16385','span32_262144']
def save():(W/'benchmark_results.json').write_text(json.dumps({'cpu':11,'scope':'Canonical polygon component alternatives separately compared to frozen baseline; same public template/main/commonI/O/compile flags. Wholeprogram uses actual rendered sources. Core excludes fixture generation/reference stdsort and I/O: same moved vector, chrono around convex_hull only, independently checked result. All use C++23 O2, SKIP;2warm+9 shuffled interleaved copies at one executable path.','results':rows},indent=2)+'\n')
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for profile,ident,lib in [('full','geometry_convex_hull_full','Geometry/geometory.cpp'),('split','geometry_convex_hull_split','Geometry/Polygon.cpp')]:
  bins={kind:{} for kind in ['whole','core']}
  for kind in bins:
   for variant in variants:
    src=W/variant/(ident+'.cpp') if kind=='whole' else W/'core.cpp';exe=W/'bin'/f'bench_{cc}_{profile}_{kind}_{variant}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',*(['-DSKIP_RUNTIME_CHECKS','-DHULL_HEADER="'+str(W/variant/lib)+'"'] if kind=='core' else []),str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;bins[kind][variant]=exe;rows.append({'kind':'build','compiler':cc,'profile':profile,'scope':kind,'variant':variant,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'library_sha256':hashlib.sha256((W/variant/lib).read_bytes()).hexdigest(),'passed':True});save()
  for kind,cases in [('whole',wholecases),('core',corecases)]:
   for name in cases:
    n=int(name.rsplit('_',1)[1]);mode=name.rsplit('_',1)[0];inp=W/'inputs'/f'{name}.in';expected=(W/'inputs'/f'{name}.expected').read_bytes();raw={k:[] for k in variants};rng=random.Random(928841);answers={}
    if kind=='whole':
     for variant in variants:
      p=subprocess.run(['taskset','-c','11',str(bins[kind][variant])],input=inp.read_bytes(),capture_output=True);assert p.returncode==0 and p.stdout==expected,(cc,profile,kind,name,variant,p.stderr)
    for rep in range(11):
     order=list(variants);rng.shuffle(order)
     for variant in order:
      active=W/'bin/bench_active';shutil.copyfile(bins[kind][variant],active);active.chmod(0o755)
      if kind=='whole':
       with inp.open('rb') as fi,open('/dev/null','wb') as fo:
        start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','11',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
      else:
       p=subprocess.run(['taskset','-c','11',str(active),str(n),mode],capture_output=True);assert p.returncode==0,p.stderr;elapsed,h,count=map(int,p.stdout.split());answer=(h,count);answers[variant]=answer;assert len(set(answers.values()))==1
      assert p.returncode==0,p.stderr
      if rep>=2:raw[variant].append(elapsed)
    med={k:statistics.median(v) for k,v in raw.items()};rows.append({'kind':'timing','compiler':cc,'profile':profile,'scope':kind,'case':name,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'expected_sha256':hashlib.sha256(expected).hexdigest(),'independent_reference_equal':True,'raw_ns':raw,'median_ns':med,'ratios':{k:med[k]/med['baseline'] for k in variants}});save();print(cc,profile,kind,name,{k:round(v/1e6,3) for k,v in med.items()},flush=True)
