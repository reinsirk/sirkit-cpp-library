from pathlib import Path
import shutil,json,sys,subprocess,hashlib
R=Path('/home/reinsirk/Atcoder_Env');W=Path(__file__).parent;old=(R/'Geometry/components/polygon.inc').read_text();versions={'baseline':old}
first=old.index('                    std::uint64_t varying = 0;');end=old.index('                    for (unsigned shift = 0;',first)
keygen='''                    std::uint64_t varying = 0;
                    std::array<std::array<std::uint32_t, 256>, 8> counts{};
                    const unsigned bound = (std::bit_width(span_x) + 7) / 8 + (std::bit_width(span_y) + 7) / 8;
                    const bool combined = points.size() >= 16384 && points.size() <= std::numeric_limits<std::uint32_t>::max() && bound >= 6;
                    const auto first = ((std::uint64_t(points.front().x) - std::uint64_t(min_x)) << 32) |
                                       (std::uint64_t(points.front().y) - std::uint64_t(min_y));
'''
loop='''                    for (std::size_t i = 0; i < points.size(); ++i) {
                        const auto key = ((std::uint64_t(points[i].x) - std::uint64_t(min_x)) << 32) |
                                         (std::uint64_t(points[i].y) - std::uint64_t(min_y));
                        keys[i] = key;
                        varying |= key ^ first;
BODY                    }
'''
hist=''.join(f'                        ++counts[{k}][(key >> {k*8}) & 255];\n' for k in range(8))
# Explicit2loops avoids a condition in every key iteration.
keygen+='                    if (combined) {\n'+''.join('    '+l for l in loop.replace('BODY',hist).splitlines(True))+'                    } else {\n'+''.join('    '+l for l in loop.replace('BODY','').splitlines(True))+'                    }\n                    std::vector<std::uint64_t> temp(keys.size());\n'
versions['histogram']=old[:first]+keygen+old[end:]
a=old.index('                    // 座標へ戻す前に、同じ点を表すキーを除く。');b=old.index('\n                } else std::sort',a)
unique='''                    std::size_t count = 0;
                    std::uint64_t previous = ~keys[0];
                    for (const auto key : keys) {
                        points[count].x = static_cast<T>(std::int64_t(min_x) + std::int64_t(key >> 32));
                        points[count].y = static_cast<T>(std::int64_t(min_y) + std::int64_t(std::uint32_t(key)));
                        count += key != previous;
                        previous = key;
                    }
                    points.resize(count);
                    radix_unique = true;'''
versions['unique']=old[:a]+unique+old[b:]
metadata=[];sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
for label,s in versions.items():
 d=W/label;components=d/'components';shutil.copytree(R/'Geometry/components',components,dirs_exist_ok=True);(components/'polygon.inc').write_text(s);p=subprocess.run([sys.executable,str(R/'Scripts/generate_geometry.py'),'--components-dir',str(components),'--output-dir',str(d)],capture_output=True,text=True);assert p.returncode==0,p.stderr
 for ident in ['geometry_convex_hull_full','geometry_convex_hull_split']:
  e=next(e for e in pv.collect() if e['id']==ident);library=e['libraries'][0];data=pv.render(e,source_overrides={library:(d/library).read_bytes()})[0];(d/(ident+'.cpp')).write_bytes(data);metadata.append({'id':ident,'variant':label,'entry':e,'component_sha256':hashlib.sha256(s.encode()).hexdigest(),'library_sha256':hashlib.sha256((d/library).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(data).hexdigest()})
(W/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n');shutil.copyfile(R/'Verify/current/tests/convex_hull_test.cpp',W/'gift_reference_test.cpp')
