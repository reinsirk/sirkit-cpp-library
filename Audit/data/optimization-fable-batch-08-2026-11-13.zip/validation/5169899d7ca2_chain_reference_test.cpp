// SPDX-License-Identifier: CC0-1.0
#include HULL_HEADER
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <limits>
#include <random>
#include <string>
#include <vector>
using P=geo::PointI;
static std::uint64_t checks=0,cases=0;
static void check(bool value){++checks;if(!value)std::abort();}
static __int128 turn(P a,P b,P c){return (__int128(b.x)-a.x)*(__int128(c.y)-a.y)-(__int128(b.y)-a.y)*(__int128(c.x)-a.x);}
static std::vector<P> reference(std::vector<P> p){
 std::sort(p.begin(),p.end(),[](P a,P b){return a.x<b.x||(a.x==b.x&&a.y<b.y);});
 p.erase(std::unique(p.begin(),p.end(),[](P a,P b){return a.x==b.x&&a.y==b.y;}),p.end());if(p.size()<2)return p;
 std::vector<P> lower,upper;
 for(P x:p){while(lower.size()>=2&&turn(lower[lower.size()-2],lower.back(),x)<=0)lower.pop_back();lower.push_back(x);}
 for(auto i=p.rbegin();i!=p.rend();++i){while(upper.size()>=2&&turn(upper[upper.size()-2],upper.back(),*i)<=0)upper.pop_back();upper.push_back(*i);}
 lower.pop_back();upper.pop_back();lower.insert(lower.end(),upper.begin(),upper.end());return lower;
}
static std::vector<P> fixture(std::size_t n,const std::string&mode){
 std::mt19937_64 rng(291171+n);std::vector<P> p;p.reserve(n);
 for(std::size_t i=0;i<n;++i){std::int64_t x=std::int64_t(rng()%2000000001)-1000000000,y=std::int64_t(rng()%2000000001)-1000000000;
  if(mode=="collinear"){x=std::int64_t(rng()%2000001)-1000000;y=3*x+2;}
  if(mode=="duplicate"){x=std::int64_t(i%31)-15;y=std::int64_t((i/31)%31)-15;}
  if(mode=="sparse_duplicate"){x=(i&1)?16777216:0;y=(i&2)?16777216:0;}
  if(mode=="same"){x=-71;y=19;}
  if(mode=="horizontal")y=-7;
  if(mode=="vertical")x=-5;
  if(mode=="span32"){x=std::int64_t(rng()%UINT64_C(4294967296))-INT64_C(2147483648);y=std::int64_t(rng()%65536)-32768;if(i<4){x=(i&1)?2147483647:INT64_C(-2147483648);y=(i&2)?32767:-32768;}}
  if(mode=="negative"){x=std::numeric_limits<std::int64_t>::min()+1000000000+x;y=std::numeric_limits<std::int64_t>::max()-1000000000+y;}
  p.push_back({x,y});
 }
 if(mode=="sorted")std::sort(p.begin(),p.end());else std::shuffle(p.begin(),p.end(),rng);return p;
}
static std::vector<std::pair<std::string,std::vector<P>>> all_cases(){
 std::vector<std::pair<std::string,std::vector<P>>> all;
 for(const char*mode:{"random","collinear","duplicate","sorted","sparse_duplicate","same","horizontal","vertical","span32","negative"})all.push_back({std::string(mode)+"_262144",fixture(262144,mode)});
 for(std::size_t n:{2047,2048,2049,16383,16384,16385})for(const char*mode:{"random","duplicate","sparse_duplicate","span32"})all.push_back({std::string(mode)+"_"+std::to_string(n),fixture(n,mode)});
 for(std::size_t n:{0,1,2,3,63,64,65})for(const char*mode:{"random","same","horizontal"})all.push_back({std::string(mode)+"_"+std::to_string(n),fixture(n,mode)});
 return all;
}
int main(int argc,char**argv){
 auto all=all_cases();
 for(auto&[name,p]:all){auto expected=reference(p);
  if(argc==2){std::ofstream in(std::string(argv[1])+"/"+name+".in"),out(std::string(argv[1])+"/"+name+".expected");in<<1<<'\n'<<p.size()<<'\n';for(P x:p)in<<x.x<<' '<<x.y<<'\n';out<<expected.size()<<'\n';for(P x:expected)out<<x.x<<' '<<x.y<<'\n';}
  else {check(geo::convex_hull(p)==expected);std::sort(p.begin(),p.end());check(::convex_hull_sorted(p)==expected);++cases;}
 }
 std::printf("PASS stdsort+unique+two-chain reference cases=%ju checks=%ju\n",static_cast<std::uintmax_t>(cases),static_cast<std::uintmax_t>(checks));
}
