from pathlib import Path
import json,subprocess,hashlib
W=Path(__file__).parent;rows=[];(W/'bin').mkdir(exist_ok=True)
for variant in ['histogram','unique']:
 for profile,lib in [('full','Geometry/geometory.cpp'),('split','Geometry/Polygon.cpp')]:
  for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
   for mode,flags in [('checked',[]),('skip',['-DSKIP_RUNTIME_CHECKS']),('standard_checked',['-DSIRKIT_FORCE_STANDARD_ARITHMETIC']),('standard_skip',['-DSIRKIT_FORCE_STANDARD_ARITHMETIC','-DSKIP_RUNTIME_CHECKS'])]:
    for name in ['chain_reference_test','gift_reference_test']:
     src=W/(name+'.cpp');exe=W/'bin'/f'{variant}_{profile}_{cc}_{mode}_{name}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',*flags,'-DHULL_HEADER="'+str(W/variant/lib)+'"',str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','11',str(exe)],capture_output=True,text=True);row={'variant':variant,'profile':profile,'compiler':cc,'mode':mode,'test':name,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'library_sha256':hashlib.sha256((W/variant/lib).read_bytes()).hexdigest(),'component_sha256':hashlib.sha256((W/variant/'components/polygon.inc').read_bytes()).hexdigest(),'passed':p.returncode==0,'stdout':p.stdout,'stderr':p.stderr};rows.append(row);(W/'test_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(variant,profile,cc,mode,name,p.stdout.strip()[:150],flush=True);assert p.returncode==0,p.stderr
