from pathlib import Path
import hashlib,json,os,random,statistics,subprocess,time
w=Path('/tmp/sirkit_remaining_20261113');os.sched_setaffinity(0,{9});old=(w/'files_before/Verify/current/common/fast_io.hpp').read_bytes();new=(w/'candidate_fast_io.hpp').read_bytes();rng=random.Random(20261113);cases=[]
def save(id,label,s):
 p=w/f'input_{id}_{label}.txt';p.write_text(s);cases.append((id,label,p))
for n in [2000,200000]:
 save('lis',str(n),str(n)+'\n'+' '.join(str(rng.randrange(-10**9,10**9)) for _ in range(n))+'\n')
 save('union_find',str(n),f'{n} {n}\n'+''.join(f'{i%2} {rng.randrange(n)} {rng.randrange(n)}\n' for i in range(n)))
 save('sparse_table',str(n),f'{n} {n}\n'+' '.join(str(rng.randrange(10**9)) for _ in range(n))+'\n'+''.join(f'{a} {b+1}\n' for a,b in (sorted((rng.randrange(n),rng.randrange(n))) for _ in range(n))))
for n in [1000,500000]:
 for label,s in [('random',''.join(rng.choice('abcd') for _ in range(n))),('equal','a'*n)]:
  for id in ['manacher','suffix_array']:save(id,f'{label}_{n}',s+'\n')
commands=[];bins={};results=[]
for compiler in ['g++','clang++']:
 for id in sorted({x[0] for x in cases}):
  source=(w/'baseline'/f'{id}.cpp').read_bytes();assert source.count(old)==1,id
  for stage,s in [('before',source),('candidate',source.replace(old,new))]:
   path=w/f'io_{id}_{stage}.cpp';path.write_bytes(s);exe=w/f'io_{id}_{compiler}_{stage}';cmd=[compiler,'-std=c++23','-O2','-Wall','-Wextra']
   if compiler=='clang++':cmd+=['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
   cmd+=[str(path),'-o',str(exe)];r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,r.stderr;commands.append({'command':cmd,'diagnostics':r.stderr});bins[compiler,id,stage]=exe
 for id,label,path in cases:
  out=[]
  for stage in ['before','candidate']:
   with path.open('rb') as f:out.append(subprocess.run([str(bins[compiler,id,stage])],stdin=f,capture_output=True,check=True).stdout)
  assert out[0]==out[1],(compiler,id,label)
  samples={x:[] for x in ['before','candidate']}
  for iteration in range(13):
   for stage in (['before','candidate'] if iteration%2==0 else ['candidate','before']):
    with path.open('rb') as f:
     t=time.perf_counter_ns();subprocess.run([str(bins[compiler,id,stage])],stdin=f,stdout=subprocess.DEVNULL,check=True);elapsed=(time.perf_counter_ns()-t)/1e6
    if iteration>=2:samples[stage].append(elapsed)
  med={v:statistics.median(s) for v,s in samples.items()};row={'compiler':compiler,'id':id,'case':label,'median_ms':med,'candidate_over_before':med['candidate']/med['before'],'samples_ms':samples,'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(out[0]).hexdigest()};results.append(row);print(compiler,id,label,round(row['candidate_over_before'],3),flush=True)
(w/'shared_io_benchmark.json').write_text(json.dumps({'scope':'whole_program_common_io_only','cpu':9,'warmup':2,'measured':11,'before_sha256':hashlib.sha256(old).hexdigest(),'candidate_sha256':hashlib.sha256(new).hexdigest(),'commands':commands,'results':results},indent=2)+'\n')
