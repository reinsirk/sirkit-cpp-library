from pathlib import Path
import os,subprocess,json,statistics
W=Path('/tmp/sirkit_remaining_20261113');D=W/'data';os.sched_setaffinity(0,{10});report=[]
headers={'baseline':W/'files_before/DataStructure/Fenwick_Tree.cpp','fenwick32':D/'fenwick32.cpp','fenwick_common':D/'fenwick_common.cpp'}
for compiler in ['g++','clang++']:
 bins={}
 for name,header in headers.items():
  binary=D/'bin'/f'core_{name}_{compiler}';cmd=[compiler,'-std=c++23','-O2','-Wall','-Wextra',f'-DFENWICK_HEADER="{header}"',str(D/'fenwick_core.cpp'),'-o',str(binary)]
  if compiler=='clang++':cmd.insert(1,'--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15')
  subprocess.run(cmd,check=True);bins[name]=binary
 for args in [['16'],['100000'],['100000','deg']]:
  values={name:[] for name in bins};checksum=None
  for repeat in range(7):
   for name in list(bins) if repeat%2==0 else list(reversed(bins)):
    r=subprocess.run([str(bins[name])]+args,capture_output=True,text=True,check=True).stdout.split();v=list(map(float,r[:2]));check=r[2]
    if checksum is None:checksum=check
    assert checksum==check
    if repeat:values[name].append(v)
  med={name:[statistics.median(v[i] for v in vals) for i in range(2)] for name,vals in values.items()};report.append({'compiler':compiler,'args':args,'median_add_sum_ms':med,'samples':values,'checksum':checksum});print(compiler,args,med,flush=True)
(D/'fenwick_core_benchmark.json').write_text(json.dumps(report,indent=2)+'\n')
