from pathlib import Path
import json,sys
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_remaining_20261113');D=W/'data';sys.path.insert(0,str(R/'Scripts'));import prepare_verify as p
sys.path.insert(0,str(D));import cases
for ident in ['binary_trie','compressed_binary_trie']:
 for kind in ['small','random','degenerate']:
  s,e=cases.make(ident,kind);path=D/'inputs'/ident/f'{kind}.in';path.write_text(s)
  if e is not None:path.with_suffix('.expected').write_text(e)
entries={e['id']:e for e in p.collect()};candidate={};sources={}
fen=(W/'files_before/DataStructure/Fenwick_Tree.cpp').read_text()
old='''        const auto n = static_cast<std::size_t>(size());
        for (++i; i <= n;) {
            tree_[i] += delta;
            const auto step = lowbit(i);
            if (step > n - i) break;
            i += step;
        }'''
new='''        // n<=INT_MAXなので、次の祖先もunsignedの範囲に収まる。
        const auto n = static_cast<unsigned>(size());
        for (auto node = static_cast<unsigned>(i) + 1; node <= n; node += node & (0U - node))
            tree_[node] += delta;'''
assert old in fen;fen32=fen.replace(old,new)
oldsum='''        return static_cast<T>(prefix_unchecked(static_cast<std::size_t>(r)) - prefix_unchecked(static_cast<std::size_t>(l)));'''
newsum='''        if (l == r) return T{};
        auto first = static_cast<unsigned>(l), last = static_cast<unsigned>(r);
        const auto common = (first & last) & (0U - std::bit_floor(first ^ last));
        Storage result{};
        for (; last != common; last -= last & (0U - last)) result += tree_[last];
        for (; first != common; first -= first & (0U - first)) result -= tree_[first];
        return static_cast<T>(result);'''
assert oldsum in fen32
for name,data in [('fenwick32',fen32),('fenwick_common',fen32.replace(oldsum,newsum))]:
 path=D/f'{name}.cpp';path.write_text(data);sources[name]=str(path)
for ident,entry in cases.entries.items():
 driver=(W/'files_before'/entry['driver']).read_text();changed=driver
 if ident=='hash_map':changed=changed.replace("else verify_out << table[key] << '\\n';","else { const auto it = table.find(key); verify_out << (it == table.end() ? 0 : it->second) << '\\n'; }")
 if ident=='internal_hash_map':changed=changed.replace("else verify_out << table[key] << '\\n';","else { const auto* value = table.find(key); verify_out << (value ? *value : 0) << '\\n'; }")
 if ident=='implicit_treap_affine':changed=changed.replace('sequence(initial);','sequence(initial);\n    sequence.reserve(static_cast<std::size_t>(n) + static_cast<std::size_t>(q));')
 if ident=='implicit_treap_deque':changed=changed.replace(' sequence;',' sequence;\n    sequence.reserve(static_cast<std::size_t>(q));')
 if ident=='compressed_binary_trie':changed=changed.replace(' trie;',' trie;\n    trie.reserve(static_cast<std::size_t>(q));')
 if ident=='dynamic_union_find':changed=changed.replace('DynamicUnionFind uf;','DynamicUnionFind uf(static_cast<std::size_t>(n));')
 if ident=='erasable_priority_queue_double':
  changed=changed.replace('    ErasablePriorityQueue<std::int64_t> low;\n    ErasablePriorityQueue<std::int64_t, false> high;\n    auto add = [&](std::int64_t x) { low.push(x); high.push(x); };\n    while (n--) { std::int64_t x{}; verify_in >> x; add(x); }','    std::vector<std::int64_t> initial(n);\n    for (auto& value : initial) verify_in >> value;\n    ErasablePriorityQueue<std::int64_t> low(initial);\n    ErasablePriorityQueue<std::int64_t, false> high(std::move(initial));\n    auto add = [&](std::int64_t x) { low.push(x); high.push(x); };')
  changed=changed.replace('auto x = low.top(); low.pop();','auto x = *low.extract_top();').replace('auto x = high.top(); high.pop();','auto x = *high.extract_top();').replace('#include <cstdint>','#include <cstdint>\n#include <utility>\n#include <vector>')
 if ident in ['rollback_union_find','rollback_weighted_union_find_rollback']:
  changed=changed.replace('std::vector<std::vector<int>> children(q+1);','std::vector<int> head(q+1,-1), next(q+1);').replace('std::vector<std::vector<int>> children(q + 1);','std::vector<int> head(q + 1, -1), next(q + 1);').replace('children[k+1].push_back(i);','next[i]=head[k+1];head[k+1]=i;').replace('children[k + 1].push_back(i);','next[i] = head[k + 1]; head[k + 1] = i;').replace('for(int child:children[i])','for(int child=head[i];child!=-1;child=next[child])').replace('for (int child : children[frame.vertex])','for (int child = head[frame.vertex]; child != -1; child = next[child])')
 variants={}
 if changed!=driver:
  path=D/'candidate_drivers'/Path(entry['driver']).name;path.parent.mkdir(exist_ok=True);path.write_text(changed);variants['driver']={'driver':str(path)}
 if ident=='fenwick_tree':variants.update({name:{'library':src} for name,src in sources.items()})
 candidate[ident]=variants
 for name,overrides in variants.items():
  libs={lib:(W/'files_before'/lib).read_bytes() for lib in entry['libraries']}
  if 'library' in overrides:libs[entry['libraries'][0]]=Path(overrides['library']).read_bytes()
  program=p.render(entries[ident],source_overrides=libs,driver_override=Path(overrides['driver']).read_text() if 'driver'in overrides else driver)[0]
  out=D/'programs'/f'{ident}_{name}.cpp';out.parent.mkdir(exist_ok=True);out.write_bytes(program)
(D/'candidates.json').write_text(json.dumps(candidate,indent=2)+'\n')
print('candidate IDs',sum(bool(x) for x in candidate.values()))
