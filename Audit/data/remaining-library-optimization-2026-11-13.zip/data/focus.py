from pathlib import Path
import json,difflib
W=Path('/tmp/sirkit_remaining_20261113');D=W/'data';report=json.loads((D/'codex_review.json').read_text())
ranges={
'Binary_Trie.cpp':[(170,205),(233,272),(276,350)],
'Compressed_Binary_Trie.cpp':[(168,236),(276,333)],
'Disjoint_Sparse_Table.cpp':[(43,86)],
'Fenwick_Tree.cpp':[(90,137),(149,153)],
'Hash_map.cpp':[(215,268),(321,351),(542,558)],
'Hash_set.cpp':[(201,242),(295,334),(486,510)],
'Lazy_Segment_Tree.cpp':[(87,118),(159,222)],
'Node.cpp':[(43,58),(109,136),(246,279)],
'Segment_Tree.cpp':[(105,136),(177,247)],
'Sparse_Table.cpp':[(35,52),(66,114)],
'Wavelet_Matrix.cpp':[(157,211),(225,244),(281,310),(317,330),(417,439)],
'dynamic-binary-indexed-tree.cpp':[(1310,1368),(1830,1870),(1894,1950)],
'dynamic-binary-indexed-tree-2d.cpp':[(2108,2169),(2170,2228),(2269,2303)],
'dynamic-li-chao-tree.cpp':[(211,298)],
'dynamic-union-find.cpp':[(324,391),(445,467)],
'erasable-priority-queue.cpp':[(65,109),(145,181),(200,233),(350,360)],
'heap.cpp':[(36,108),(134,161),(176,191)],
'implicit_treap.cpp':[(225,318),(366,386),(522,541),(689,695)],
'line-container-2d.cpp':[(545,576),(662,706),(814,843),(855,875),(900,903)],
'line-container.cpp':[(106,135),(214,290),(333,354),(362,378)],
'persistent-union-find.cpp':[(223,242),(258,271),(293,324),(364,376)],
'rollback-union-find.cpp':[(89,94),(169,210)],
'rollback-union-findw.cpp':[(213,242),(263,287),(337,399),(532,566)],
'union_find.cpp':[(40,48),(95,125)],
'union_find_w.cpp':[(77,104),(123,130),(178,210)],
'Nyaan_hash_map_min.cpp':[(117,192),(218,278)]}
bylib={}
for e in report['entries']:bylib.setdefault(e['libraries'][0],[]).append(e)
assert len(bylib)==26
items=[]
for lib,entries in sorted(bylib.items()):
 src=W/'files_before'/lib;lines=src.read_text().splitlines();hot=ranges[Path(lib).name];assert sum(b-a+1 for a,b in hot)<=180,(lib,hot);assert all(1<=a<=b<=len(lines)for a,b in hot)
 api_end=next((i for i,line in enumerate(lines,1)if line.startswith('#include ')),min(65,len(lines)))-1
 diffs=[]
 for e in entries:
  if e['final_driver_changed']:
   before=(W/'files_before'/e['driver']).read_text();after=Path(e['frozen_driver_source']).read_text();diff=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before/'+e['driver'],tofile='codex/'+e['driver']));path=D/f'{e["id"]}_driver.diff';path.write_text(diff);diffs.append({'id':e['id'],'path':str(path),'lines':len(diff.splitlines()),'final_driver':e['frozen_driver_source']})
 summaries=[]
 for e in entries:
  measurements=e['measurement_summary'];selected='driver' if e['final_driver_changed'] else 'baseline'
  row={'id':e['id'],'small_reference':'PASS (Python independent model, GCC/Clang)','changed':'driver only'if e['final_driver_changed']else'none'}
  for shape in ['random','degenerate']:
   vals=[]
   for compiler in ['g++','clang++']:
    m=next(x for x in measurements if x['kind']==shape and x['compiler']==compiler);b=m['median_ms']['baseline'];f=m['median_ms'][selected];vals.append(f'{compiler} {b:.3f}->{f:.3f} ms ({f/b:.3f}x)')
   row[shape]='; '.join(vals)
  summaries.append(row)
 snippet=D/'focus_excerpts'/f'{Path(lib).stem}.txt';snippet.parent.mkdir(exist_ok=True);text=[f'Source: {src}\nAPI lines 1-{api_end}\n']+['\n'.join(f'{i}: {lines[i-1]}'for i in range(1,api_end+1))]
 for a,b in hot:text.extend([f'\nHot path lines {a}-{b}\n','\n'.join(f'{i}: {lines[i-1]}'for i in range(a,b+1))])
 snippet.write_text('\n'.join(text)+'\n')
 items.append({'library':lib,'ids':[e['id']for e in entries],'full_frozen_source':str(src),'source_sha256':entries[0]['final_library_sha256'][lib],'api_range':{'start':1,'end':api_end},'hot_path_ranges':[{'start':a,'end':b}for a,b in hot],'hot_path_lines':sum(b-a+1 for a,b in hot),'focus_excerpt':str(snippet),'codex_analysis':entries[0]['analysis'],'codex_decision':entries[0]['decision'],'driver_diffs':diffs,'measurement_summary':summaries,'more_detail_if_needed':[e['validation']['measurements']for e in entries]})
out={'format':1,'stage':'Codex to Fable','libraries':26,'ids':34,'review_policy':'Read API + driver diffs + these hot paths first. Full immutable source is available if context or correctness requires it. No need to repeat the entire measurement log. All final library cores are unchanged from baseline.','measurement_condition':'CPU10, GCC15/Clang21, C++23 -O2 -Wall -Wextra, unchanged common I/O and identical inputs; lower ratio is faster. Synthetic local wall time only.','entries':items,'complete_review':str(D/'codex_review.json')}
(D/'fable_focus.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(D/'fable_focus.json'),'libraries':len(items),'ids':sum(len(i['ids'])for i in items),'max_hot_path_lines':max(i['hot_path_lines']for i in items),'total_api_hot_path_lines':sum(i['api_range']['end']+i['hot_path_lines']for i in items)}))
