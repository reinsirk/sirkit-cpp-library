from pathlib import Path
import subprocess,json,os,time
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_remaining_20261113/data');os.sched_setaffinity(0,{10});results=[]
tests=['fenwick_tree_reference_test','fenwick_tree_operations_test','segment_tree_reference_test','segment_tree_carried_types_test','lazy_segment_tree_reference_test','lazy_segment_tree_query_types_test','sparse_table_simd_test','disjoint_sparse_table_storage_test','disjoint_sparse_table_owned_rows_test','wavelet_matrix_reference_test','wavelet_matrix_all_widths_test','dynamic_fenwick_test','dynamic_fenwick_2d_test','dynamic_fenwick_2d_overflow_test','dynamic_li_chao_test','dynamic_union_find_test','hash_map_test','hash_map_boundary_test','internal_hash_reference_test','internal_hash_value_exception_test','hash_set_test','hash_set_string_test','heap_test','erasable_priority_queue_test','implicit_treap_affine_test','implicit_treap_noncommutative_test','implicit_treap_round2_exhaustive_test','line_container_test','line_container_2d_reuse_test','binary_trie_reference_test','binary_trie_stride_boundary_test','union_reuse_test','puf_reference_test','ruf_reference_test','rwuf_reference_test','node_reference_test']
out=W/'local_test_results.json'
for test in tests:
 for compiler,flags in [('g++',[]),('clang++',['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-DSKIP_RUNTIME_CHECKS','-DSIRKIT_DISABLE_SIMD'])]:
  name=f'{test}_{compiler}';binary=W/'bin'/name;cmd=[compiler,'-std=c++23','-O2','-Wall','-Wextra',*flags,str(R/'Verify/current/tests'/f'{test}.cpp'),'-o',str(binary)];build=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
  row={'test':test,'compiler':compiler,'command':cmd,'build_returncode':build.returncode,'build_diagnostics':build.stderr}
  if build.returncode==0:
   begin=time.perf_counter();run=subprocess.run([str(binary)],capture_output=True,text=True,timeout=90);row.update(returncode=run.returncode,stdout=run.stdout,stderr=run.stderr,seconds=time.perf_counter()-begin)
  results.append(row);out.write_text(json.dumps(results,indent=2)+'\n');print(name,row.get('returncode',build.returncode),row.get('stdout','').strip()[:160],flush=True)
print('PASS',sum(r.get('returncode')==0 for r in results),'TOTAL',len(results),flush=True)
