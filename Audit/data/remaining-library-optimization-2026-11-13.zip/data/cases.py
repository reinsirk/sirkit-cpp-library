from pathlib import Path
import random,json,heapq
ROOT=Path('/tmp/sirkit_remaining_20261113');WORK=ROOT/'data';MOD=998244353
baseline=json.loads((ROOT/'baseline.json').read_text());entries={k:v for k,v in baseline.items() if v['libraries'][0].startswith(('DataStructure/','Internal/'))}
class DSU:
 def __init__(self,n):self.p=list(range(n))
 def root(self,x):
  while self.p[x]!=x:x=self.p[x]
  return x
 def same(self,a,b):return self.root(a)==self.root(b)
 def merge(self,a,b):self.p[self.root(a)]=self.root(b)
def make(identifier,kind):
 small=kind=='small';deg=kind=='degenerate';rng=random.Random(839123+sum(map(ord,identifier)));n=24 if small else 100000;q=160 if small else 150000;lines=[];out=[]
 def write(*xs):lines.append(' '.join(map(str,xs)))
 def answer(v):
  if small:out.append(str(v))
 def interval(length):
  if deg:return 0,length
  l=rng.randrange(length);return l,rng.randrange(l+1,length+1)
 if identifier in ['fenwick_tree','segment_tree','dynamic_fenwick_range']:
  a=[rng.randrange(1000) for _ in range(n)];write(n,q);write(*a)
  for i in range(q):
   if i%3==0:
    p=0 if deg else rng.randrange(n);x=rng.randrange(1000);write(0,p,x)
    if small:a[p]+=x
   else:
    l,r=interval(n);write(1,l,r);answer(sum(a[l:r]) if small else 0)
 elif identifier in ['sparse_table','disjoint_sparse_table','wavelet_frequency','wavelet_kth','segment_tree_composite','lazy_segment_tree']:
  if identifier=='segment_tree_composite':
   a=[(1,1) if deg else (rng.randrange(MOD),rng.randrange(MOD)) for _ in range(n)];write(n,q)
   for f in a:write(*f)
   for i in range(q):
    if i%3==0:
     p=0 if deg else rng.randrange(n);f=(rng.randrange(MOD),rng.randrange(MOD));write(0,p,*f)
     if small:a[p]=f
    else:
     l,r=interval(n);x=rng.randrange(MOD);write(1,l,r,x)
     if small:
      for b,c in a[l:r]:x=(b*x+c)%MOD
      answer(x)
  else:
   a=[7 if deg else rng.randrange(1<<20) for _ in range(n)];write(n,q);write(*a)
   for i in range(q):
    l,r=interval(n)
    if identifier=='wavelet_frequency':
     x=7 if deg else rng.randrange(1<<20);write(l,r,x);answer(a[l:r].count(x) if small else 0)
    elif identifier=='wavelet_kth':
     k=(r-l)//2;write(l,r,k);answer(sorted(a[l:r])[k] if small else 0)
    elif identifier=='lazy_segment_tree':
     if i%3:
      write(1,l,r);answer(sum(a[l:r])%MOD if small else 0)
     else:
      b,c=rng.randrange(MOD),rng.randrange(MOD);write(0,l,r,b,c)
      if small:a[l:r]=[(b*x+c)%MOD for x in a[l:r]]
    else:write(l,r);answer(min(a[l:r]) if small else 0)
 elif identifier in ['hash_map','internal_hash_map']:
  write(q);table={}
  for i in range(q):
   key=0 if deg else rng.randrange(1<<40)
   if i%3==0:
    value=rng.randrange(1<<50);write(0,key,value)
    if small:table[key]=value
   else:write(1,key);answer(table.get(key,0))
 elif identifier in ['union_find','dynamic_union_find','weighted_union_find','rollback_weighted_union_find']:
  write(n,q);dsu=DSU(n);potential=[rng.randrange(MOD) for _ in range(n)]
  weighted='weighted' in identifier
  for i in range(q):
   a,b=(0,0) if deg else (rng.randrange(n),rng.randrange(n));t=int(i%3!=0)
   if weighted:
    value=(potential[a]-potential[b])%MOD
    if not t:
     write(t,a,b,value);answer(1)
     if small:dsu.merge(a,b)
    else:write(t,a,b);answer(value if dsu.same(a,b) else -1)
   else:
    write(t,a,b)
    if t:answer(int(dsu.same(a,b)))
    elif small:dsu.merge(a,b)
 elif identifier in ['persistent_union_find','rollback_union_find','rollback_weighted_union_find_rollback']:
  n=24 if small else 30000;q=160 if small else 60000;write(n,q);versions=[list(range(n))] if small else None;available=[-1]
  for i in range(q):
   t=int(i%3!=0);k=available[-1] if deg else rng.choice(available);a,b=rng.randrange(n),rng.randrange(n);write(t,k,a,b)
   if small:
    dsu=DSU(n);dsu.p=versions[k+1].copy()
    if not t:dsu.merge(a,b)
    else:answer(int(dsu.same(a,b)))
    versions.append(dsu.p if not t else None)
   if not t:available.append(i)
 elif identifier in ['binary_trie','compressed_binary_trie']:
  write(q);values=set();current=[]
  for i in range(q):
   if not current or i%4<2:
    x=7 if deg else rng.randrange(1<<29);write(0,x)
    if x not in values:values.add(x);current.append(x)
   elif i%4==2:
    j=rng.randrange(len(current));x=current[j];write(1,x);values.remove(x);current[j]=current[-1];current.pop()
   else:
    x=7 if deg else rng.randrange(1<<29);write(2,x);answer(min(v^x for v in values) if small else 0)
 elif identifier in ['line_container_min','line_container_2d_min','dynamic_lichao_line','dynamic_lichao_segment']:
  n=12 if small else 1500;q=160 if small else 50000;segment=identifier=='dynamic_lichao_segment';write(n,q);active=[]
  def add(initial=False,index=0):
   a,b=(7,3) if deg else (rng.randrange(-100000,100001),rng.randrange(-10**9,10**9));l,r=sorted([rng.randrange(-10**8,10**8),rng.randrange(-10**8,10**8)]);r+=1
   vals=(l,r,a,b) if segment else (a,b)
   if initial:write(*vals)
   else:write(0,*vals)
   if small:active.append((l,r,a,b))
  for i in range(n):add(True,i)
  for i in range(q):
   if i%3==0:add(False,i)
   else:
    x=0 if deg else rng.randrange(-10**8,10**8);write(1,x)
    if small:
     found=[a*x+b for l,r,a,b in active if not segment or l<=x<r];answer(min(found) if found else 'INFINITY')
 elif identifier in ['dynamic_fenwick_rectangle','dynamic_fenwick_2d_rectangle']:
  n=24 if small else 4000;q=160 if small else 12000;write(n,q);points=[]
  for _ in range(n):
   x,y=(0,0) if deg else (rng.randrange(1<<20),rng.randrange(1<<20));v=rng.randrange(1000);write(x,y,v)
   if small:points.append((x,y,v))
  for i in range(q):
   if i%3==0:
    x,y=(0,0) if deg else (rng.randrange(1<<20),rng.randrange(1<<20));v=rng.randrange(1000);write(0,x,y,v)
    if small:points.append((x,y,v))
   else:
    l,r=(0,1<<20) if deg else sorted([rng.randrange(1<<20),rng.randrange(1<<20)]);d,u=(0,1<<20) if deg else sorted([rng.randrange(1<<20),rng.randrange(1<<20)]);r+=1;u+=1;write(1,l,d,r,u);answer(sum(v for x,y,v in points if l<=x<r and d<=y<u) if small else 0)
 elif identifier=='erasable_priority_queue_double':
  n=24 if small else 30000;q=160 if small else 90000;values=[7 if deg else rng.randrange(10**9) for _ in range(n)];write(n,q);write(*values);size=n
  for i in range(q):
   if size==0 or i%3==0:
    x=7 if deg else rng.randrange(10**9);write(0,x);size+=1
    if small:values.append(x)
   else:
    t=1+i%2;write(t);size-=1
    if small:
     x=min(values) if t==1 else max(values);answer(x);values.remove(x)
 elif identifier=='heap_priority_queue':
  k=n//3;write(n,k);a=list(range(1,n+1));
  if not deg:rng.shuffle(a)
  write(*a);h=[]
  if small:
   for x in a:
    heapq.heappush(h,x)
    if len(h)>k:heapq.heappop(h)
    if len(h)==k:answer(h[0])
 elif identifier=='hash_set_membership':
  size=5 if small else 100;arrays=[[7 if deg else rng.randrange(1000000) for _ in range(size)] for i in range(3)]
  for a in arrays:write(size);write(*a)
  write(q)
  sums={x+y+z for x in arrays[0] for y in arrays[1] for z in arrays[2]} if small else set()
  for i in range(q):
   x=21 if deg else rng.randrange(3000000);write(x);answer('Yes' if x in sums else 'No')
 elif identifier in ['hash_set_toggle','hash_set_strings']:
  write(n);seen=set()
  for i in range(n):
   x=('same' if deg else ''.join(rng.choice('abcdefghijklmnopqrstuvwxyz') for _ in range(10))) if identifier.endswith('strings') else (7 if deg else rng.randrange(n));write(x)
   if identifier.endswith('toggle') and x in seen:seen.remove(x)
   else:seen.add(x)
  answer(len(seen))
 elif identifier=='node_reachable':
  start=1;write(n,start);a=[i+2 for i in range(n-1)]+[1]
  if deg:a=list(range(1,n+1))
  else:rng.shuffle(a)
  write(*a);seen=set();p=0
  while p not in seen:seen.add(p);p=a[p]-1
  answer(len(seen))
 elif identifier=='implicit_treap_affine':
  n=24 if small else 12000;q=160 if small else 50000;values=[rng.randrange(MOD) for _ in range(n)];write(n,q);write(*values);length=n
  for i in range(q):
   t=i%5
   if t==0:
    p=0 if deg else rng.randrange(length+1);x=rng.randrange(MOD);write(0,p,x);length+=1
    if small:values.insert(p,x)
   elif t==1:
    p=0 if deg else rng.randrange(length);write(1,p);length-=1
    if small:values.pop(p)
   else:
    l,r=interval(length)
    if t==2:
     write(2,l,r)
     if small:values[l:r]=values[l:r][::-1]
    elif t==3:
     b,c=rng.randrange(MOD),rng.randrange(MOD);write(3,l,r,b,c)
     if small:values[l:r]=[(b*x+c)%MOD for x in values[l:r]]
    else:write(4,l,r);answer(sum(values[l:r])%MOD if small else 0)
 elif identifier=='implicit_treap_deque':
  write(q);values=[];length=0
  for i in range(q):
   t=(0 if i<q//2 else 4) if deg else [0,1,0,1,2,3,4,4][rng.randrange(8)]
   if length==0:t=0
   if t<2:
    a,b=rng.randrange(MOD),rng.randrange(MOD);write(t,a,b);length+=1
    if small:values.insert(0,(a,b)) if t==0 else values.append((a,b))
   elif t<4:
    write(t);length-=1
    if small:values.pop(0 if t==2 else -1)
   else:
    x=rng.randrange(MOD);write(4,x)
    if small:
     for a,b in values:x=(a*x+b)%MOD
     answer(x)
 else:raise ValueError(identifier)
 return '\n'.join(lines)+'\n', ('\n'.join(out)+'\n' if out else '') if small else None
if __name__=='__main__':
 info={}
 for identifier in entries:
  info[identifier]=[]
  for kind in ['small','random','degenerate']:
   data,expected=make(identifier,kind);p=WORK/'inputs'/identifier/f'{kind}.in';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
   if expected is not None:p.with_suffix('.expected').write_text(expected)
   info[identifier].append(str(p))
  print(identifier,flush=True)
 (WORK/'cases.json').write_text(json.dumps(info,indent=2)+'\n')
