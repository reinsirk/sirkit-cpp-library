from pathlib import Path
import json,os,sys,subprocess,time,statistics,hashlib
from cases import entries
W=Path('/tmp/sirkit_remaining_20261113');D=W/'data';os.sched_setaffinity(0,{10});candidates=json.loads((D/'candidates.json').read_text());resultdir=D/'measurements';resultdir.mkdir(exist_ok=True)
ids=sys.argv[1:] or list(entries)
for ident in ids:
 if (resultdir/f'{ident}.json').exists():print('existing',ident,flush=True);continue
 programs={'baseline':W/'baseline'/f'{ident}.cpp'}
 for name in candidates[ident]:programs[name]=D/'programs'/f'{ident}_{name}.cpp'
 report={'id':ident,'cpu':10,'scope':'whole_program_same_frozen_common_io','source_sha256':{name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in programs.items()},'builds':[],'cases':[]}
 for compiler in ['g++','clang++']:
  binaries={}
  for name,path in programs.items():
   exe=D/'bin'/f'{ident}_{compiler}_{name}';exe.parent.mkdir(exist_ok=True);cmd=[compiler,'-std=c++23','-O2','-Wall','-Wextra']
   if compiler=='clang++':cmd+=['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
   cmd+=[str(path),'-o',str(exe)];built=subprocess.run(cmd,capture_output=True,text=True,timeout=120) if not exe.exists() else subprocess.CompletedProcess(cmd,0,'','cached executable')
   if built.returncode:raise RuntimeError(ident+' '+name+'\n'+built.stderr)
   binaries[name]=exe;report['builds'].append({'compiler':compiler,'variant':name,'command':cmd,'warnings':built.stderr})
  for kind in ['small','random','degenerate'] + (['build_heavy'] if (D/'inputs'/ident/'build_heavy.in').exists() else []):
   path=D/'inputs'/ident/f'{kind}.in';outputs={}
   for name,exe in binaries.items():
    with path.open('rb') as inp:ran=subprocess.run([str(exe)],stdin=inp,capture_output=True,timeout=60)
    if ran.returncode:raise RuntimeError(f'{ident} {compiler} {name} {kind} return {ran.returncode}: {ran.stderr!r}')
    outputs[name]=ran.stdout
    if kind=='small' and ran.stdout.decode().strip()!=path.with_suffix('.expected').read_text().strip():
     (D/'failed_actual.txt').write_bytes(ran.stdout);raise RuntimeError(f'{ident} {compiler} {name} independent mismatch')
   if any(v!=outputs['baseline'] for v in outputs.values()):raise RuntimeError(f'{ident} {compiler} {kind} baseline mismatch')
   repeats=9 if len(programs)>1 else 4;warmup=2 if len(programs)>1 else 1;times={name:[] for name in binaries}
   for repeat in range(repeats):
    for name in list(binaries) if repeat%2==0 else list(reversed(binaries)):
     with path.open('rb') as inp:
      t=time.perf_counter_ns();subprocess.run([str(binaries[name])],stdin=inp,stdout=subprocess.DEVNULL,check=True);ms=(time.perf_counter_ns()-t)/1e6
     if repeat>=warmup:times[name].append(ms)
   med={k:statistics.median(v) for k,v in times.items()};row={'compiler':compiler,'kind':kind,'median_ms':med,'over_baseline':{k:v/med['baseline'] for k,v in med.items()},'times_ms':times,'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(outputs['baseline']).hexdigest(),'output_tokens':len(outputs['baseline'].split()),'independent_reference':kind=='small'};report['cases'].append(row);print(ident,compiler,kind,med,row['over_baseline'],flush=True)
 (resultdir/f'{ident}.json').write_text(json.dumps(report,indent=2)+'\n')
