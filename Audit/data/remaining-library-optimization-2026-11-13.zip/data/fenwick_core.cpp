#define SKIP_RUNTIME_CHECKS
#include FENWICK_HEADER
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
int main(int argc,char**argv){int n=argc>1?std::atoi(argv[1]):100000;bool deg=argc>2;fenwick_tree<std::uint64_t> f(n);std::uint64_t random=918233,result=0;const int q=2000000;
auto next=[&](){random^=random<<13;random^=random>>7;random^=random<<17;return random;};
auto t=std::chrono::steady_clock::now();for(int i=0;i<q;++i)f.add(deg?0:next()%n,1);auto m=std::chrono::steady_clock::now();for(int i=0;i<q;++i){int l=deg?0:next()%n,r=deg?n:l+next()%(n-l+1);result+=f.sum(l,r);}auto end=std::chrono::steady_clock::now();std::printf("%.6f %.6f %llu\n",std::chrono::duration<double,std::milli>(m-t).count(),std::chrono::duration<double,std::milli>(end-m).count(),static_cast<unsigned long long>(result));}
