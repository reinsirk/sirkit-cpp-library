from pathlib import Path
import sys,json
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_remaining_20261113');D=W/'data';sys.path.insert(0,str(R/'Scripts'));import prepare_verify as p
es={e['id']:e for e in p.collect()};cs=json.loads((D/'candidates.json').read_text())
def add(ident,name,source=None,driver=None):
 e=es[ident];libs={lib:(W/'files_before'/lib).read_bytes() for lib in e['libraries']};meta={}
 if source:
  path=D/f'{ident}_{name}_library.cpp';path.write_text(source);libs[e['libraries'][0]]=source.encode();meta['library']=str(path)
 if driver:
  path=D/f'{ident}_{name}_driver.cpp';path.write_text(driver);meta['driver']=str(path)
 program=p.render(e,source_overrides=libs,driver_override=driver or (W/'files_before'/e['driver']).read_text())[0];(D/'programs'/f'{ident}_{name}.cpp').write_bytes(program);cs[ident][name]=meta
 old=D/'measurements'/f'{ident}.json'
 if old.exists():old.rename(old.with_name(f'{ident}_baseline_initial.json'))
ident='segment_tree';e=es[ident];driver=(W/'files_before'/e['driver']).read_text();driver=driver.replace('tree.set(p, tree.get(p) + x);','tree.transform(p, [x](std::int64_t value) { return value + x; });');add(ident,'transform',driver=driver)
ident='sparse_table';e=es[ident];source=(W/'files_before'/e['libraries'][0]).read_text();add(ident,'portable',source='#define SIRKIT_DISABLE_SIMD\n'+source)
ident='disjoint_sparse_table';e=es[ident];source=(W/'files_before'/e['libraries'][0]).read_text();source=source.replace('std::is_integral_v<T> && !std::is_same_v<T, bool> && sizeof(T) >= 4;','false;');add(ident,'copy_rows',source=source)
ident='lazy_segment_tree';e=es[ident];source=(W/'files_before'/e['libraries'][0]).read_text();source=source.replace('if (r & (length - 1)) push((r - 1) >> level, length);','if ((r & (length - 1)) && (!(l & (length - 1)) || (l >> level) != ((r - 1) >> level)))\n                push((r - 1) >> level, length);');add(ident,'distinct_boundary',source=source)
(D/'candidates.json').write_text(json.dumps(cs,indent=2)+'\n')
