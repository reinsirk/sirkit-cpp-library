// SPDX-License-Identifier: CC0-1.0
#include "Verify/current/common/fast_io.hpp"
#include <cstdint>
#include <utility>
#include <vector>

int main() {
    int n{}, q{}; if (!(verify_in >> n >> q)) return 0;
    std::vector<std::int64_t> initial(n);
    for (auto& value : initial) verify_in >> value;
    ErasablePriorityQueue<std::int64_t> low(initial);
    ErasablePriorityQueue<std::int64_t, false> high(std::move(initial));
    auto add = [&](std::int64_t x) { low.push(x); high.push(x); };
    while (q--) {
        int t{}; verify_in >> t;
        if (t == 0) { std::int64_t x{}; verify_in >> x; add(x); }
        else if (t == 1) {
            auto x = *low.extract_top(); high.erase(x); verify_out << x << '\n';
        } else {
            auto x = *high.extract_top(); low.erase(x); verify_out << x << '\n';
        }
    }
}
