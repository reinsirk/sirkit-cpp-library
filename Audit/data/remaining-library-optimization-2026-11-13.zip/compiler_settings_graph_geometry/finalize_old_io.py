from pathlib import Path
import json,statistics,struct,hashlib
p=Path(__file__).resolve().parent;f=p/'recommendations.json';x=json.loads(f.read_text());rows=json.loads((p/'measurements.json').read_text());byid={e['id']:e for e in x['entries']}
# Preserve initial automatic decisions before evaluating equivalent generated binaries.
(p/'automatic_recommendations.json').write_text(json.dumps(x,indent=2)+'\n')
def section(path,name):
 b=path.read_bytes();start=struct.unpack_from('<Q',b,40)[0];size,count,names=struct.unpack_from('<HHH',b,58);ns=start+size*names;off,length=struct.unpack_from('<QQ',b,ns+24);strings=b[off:off+length]
 for i in range(count):
  h=start+size*i;k=struct.unpack_from('<I',b,h)[0];end=strings.find(b'\0',k)
  if strings[k:end].decode()==name:
   off,length=struct.unpack_from('<QQ',b,h+24);return hashlib.sha256(b[off:off+length]).hexdigest()
for name in ['geometry_convex_hull','geometry_contains_atcoder']:
 ids=[name+'_full',name+'_split'];proof={}
 for mode in x['modes']:
  proof[mode]={s:section(p/'bin'/f'{ids[0]}_{mode}',s)for s in ['.text','.rodata']}
  assert all(proof[mode][s]==section(p/'bin'/f'{ids[1]}_{mode}',s)for s in proof[mode])
 cases=[r for r in rows if r['id']in ids and not r['profile'].startswith('sample_')];pooled={}
 for profile in {r['profile']for r in cases}:pooled[profile]={m:statistics.median([v for r in cases if r['profile']==profile for v in r['samples_ns'][m]])for m in x['modes']}
 sums={m:sum(v[m]for v in pooled.values())for m in x['modes']};best=min(sums,key=sums.get)
 if sums[best]<sums['O2']*.98:
  for id in ids:
   e=byid[id];e['recommended_mode']=best;e['recommended_flags']=x['modes'][best];e['reason']='Full/split .text and .rodata are byte-identical at all settings. Pooled 18-trial medians establish a >2% gain; retain consistent compiler selection for equivalent binaries.';e['equivalent_binary_pooled']={'ids':ids,'section_sha256':proof,'median_ns':pooled,'aggregate_ratio':{m:sums[m]/sums['O2']for m in x['modes']}}
# The largest LCA workload has a stable benefit even though aggregate gain is <2%.
e=byid['lca'];e['recommended_mode']='O3';e['recommended_flags']=['-O3'];e['reason']='Heavy random-tree maximum median improves 3.2% (7/9 paired wins), aggregate improves 1.6%; prioritize the largest workload. Small graph-time variations remain in raw data.'
x['selection'] += ' Final review also pools byte-identical full/split binaries, and permits LCA O3 based on the heavier random-tree case.'
x['measurements_file']=str(p/'measurements.json');x['sources_file']=str(p/'sources.json');x['reproduction']=str(p/'run.py');x['followup']='Validate selected settings as actual generated GCC pragma with current new I/O and command-line -O2 before adoption.'
f.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print('selected',sum(e['recommended_mode']!='O2'for e in x['entries']))
