from pathlib import Path
import json,statistics,struct,hashlib
p=Path(__file__).resolve().parent;f=p/'recommendations.json';x=json.loads(f.read_text());rows=json.loads((p/'measurements.json').read_text());old=json.loads((p.parent/'recommendations.json').read_text());byid={e['id']:e for e in x['entries']}
(p/'automatic_recommendations.json').write_text(json.dumps(x,indent=2)+'\n')
def section(path,name):
 b=path.read_bytes();start=struct.unpack_from('<Q',b,40)[0];size,count,names=struct.unpack_from('<HHH',b,58);ns=start+size*names;off,length=struct.unpack_from('<QQ',b,ns+24);strings=b[off:off+length]
 for i in range(count):
  h=start+size*i;k=struct.unpack_from('<I',b,h)[0];end=strings.find(b'\0',k)
  if strings[k:end].decode()==name:
   off,length=struct.unpack_from('<QQ',b,h+24);return hashlib.sha256(b[off:off+length]).hexdigest()
for group in ['geometry_convex_hull','geometry_contains_atcoder']:
 ids=[group+'_full',group+'_split'];proof={}
 for mode in ['no_pragma','pragma']:
  proof[mode]={name:section(p/'bin'/f'{ids[0]}_{mode}',name)for name in ['.text','.rodata']};assert all(h==section(p/'bin'/f'{ids[1]}_{mode}',s)for s,h in proof[mode].items())
 cs=[r for r in rows if r['id']in ids];pooled={profile:{mode:statistics.median([v for row in cs if row['profile']==profile for v in row['samples_ns'][mode]])for mode in ['no_pragma','pragma']}for profile in {r['profile']for r in cs}};sums={m:sum(r[m]for r in pooled.values())for m in ['no_pragma','pragma']};maxima={m:max(r[m]for r in pooled.values())for m in ['no_pragma','pragma']};ratio=sums['pragma']/sums['no_pragma'];mx=maxima['pragma']/maxima['no_pragma'];adopt=ratio<.99 and mx<1.03
 for id in ids:
  e=byid[id];e['equivalent_binary_pooled']={'ids':ids,'section_sha256':proof,'samples_per_mode_per_profile':18,'median_ns':pooled,'aggregate_ratio':ratio,'maximum_ratio':mx};e['adopted']=adopt;e['gcc_optimization']=('O3,unroll-loops'if e['old_io_recommended_mode']=='O3_unroll'else'O3')if adopt else None;e['reason']='Full/split machine-code and rodata are identical. Pooling 18 trials yields '+str(round((1-ratio)*100,2))+'% aggregate improvement; '+('adopt consistent flags.'if adopt else'no clear >=1% aggregate benefit, retain no pragma for both.')
x['recommended_gcc_optimization']={e['id']:e['gcc_optimization']for e in x['entries']if e['adopted']};x['no_pragma_after_validation']={e['id']:e['reason']for e in x['entries']if not e['adopted']};x['not_selected_in_old_io']=[e['id']for e in old['entries']if e['recommended_mode']=='O2'];x['all_34_flag_map']={e['id']:x['recommended_gcc_optimization'].get(e['id'])for e in old['entries']};x['old_io_comparison']=str(p.parent/'recommendations.json');x['selection_note']='Only settings initially recommended from old-I/O CLI measurements were retested. Generated full/split binaries with identical .text/.rodata are pooled and assigned identical settings. Empty/null means omit gcc_optimization.';f.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print('final pragma flags',len(x['recommended_gcc_optimization']));print(json.dumps(x['recommended_gcc_optimization'],indent=2))
