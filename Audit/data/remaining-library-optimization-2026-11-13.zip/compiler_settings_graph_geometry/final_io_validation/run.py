from pathlib import Path
import sys,json,subprocess,hashlib,time,statistics,os
sys.dont_write_bytecode=True
p=Path(__file__).resolve().parent;parent=p.parent;r=Path('/home/reinsirk/Atcoder_Env');sys.path.insert(0,str(r/'Scripts'));import prepare_verify
es={e['id']:e for e in prepare_verify.collect()};old=json.loads((parent/'recommendations.json').read_text());inputs=json.loads((parent/'inputs.json').read_text());selected=[x for x in old['entries']if x['recommended_mode']!='O2'];(p/'sources').mkdir(exist_ok=True);(p/'bin').mkdir(exist_ok=True)
rows=[];recs=[];io_hash=hashlib.sha256((r/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest();version=subprocess.check_output(['/usr/bin/g++','--version'],text=True).splitlines()[0]
for decision in selected:
 id=decision['id'];entry=dict(es[id]);entry.pop('gcc_optimization',None);normal,hashes=prepare_verify.render(entry);mode=decision['recommended_mode'];optimization='O3,unroll-loops'if mode=='O3_unroll'else'O3';entry['gcc_optimization']=optimization;pragma,hashes2=prepare_verify.render(entry);options=', '.join(json.dumps(s)for s in optimization.split(','));stanza=('#if defined(__GNUC__) && !defined(__clang__)\n#pragma GCC optimize('+options+')\n#endif\n').encode();assert stanza in pragma;assert pragma.replace(stanza,b'',1)==normal,(id,'more than pragma changed');assert hashes==hashes2
 frozen={'no_pragma':normal,'pragma':pragma};programs={};source_meta={}
 for key,source in frozen.items():
  file=p/'sources'/f'{id}_{key}.cpp';file.write_bytes(source);exe=p/'bin'/f'{id}_{key}';cmd=['/usr/bin/g++','-std=c++23','-O2',str(file),'-o',str(exe)];q=subprocess.run(cmd,capture_output=True,text=True)
  if q.returncode:raise RuntimeError((id,key,q.stderr))
  programs[key]=exe;source_meta[key]={'path':str(file),'sha256':hashlib.sha256(source).hexdigest(),'compiler':cmd}
 local=[]
 cases=[c for c in inputs[id]if not c['kind'].startswith('sample_')]
 if not cases:cases=inputs[id]
 for case in cases:
  inp=Path(case['input']);checks={}
  for key,exe in programs.items():
   with inp.open('rb')as f:out=subprocess.check_output([str(exe)],stdin=f)
   checks[key]=hashlib.sha256(out).hexdigest()
  assert len(set(checks.values()))==1,(id,case['kind'],checks)
  for exe in programs.values():
   with inp.open('rb')as f:subprocess.run([str(exe)],stdin=f,stdout=subprocess.DEVNULL,check=True)
  samples={k:[]for k in programs};order=list(programs)
  for rep in range(9):
   for key in (order if rep%2==0 else order[::-1]):
    with inp.open('rb')as f:
     start=time.perf_counter_ns();subprocess.run([str(programs[key])],stdin=f,stdout=subprocess.DEVNULL,check=True);samples[key].append(time.perf_counter_ns()-start)
  row={'id':id,'profile':case['kind'],'input':str(inp),'output_sha256':checks['no_pragma'],'warmups':2,'trials':9,'samples_ns':samples,'median_ns':{k:statistics.median(v)for k,v in samples.items()}};rows.append(row);local.append(row);(p/'measurements.json').write_text(json.dumps(rows,indent=2)+'\n')
 sums={k:sum(row['median_ns'][k]for row in local)for k in programs};maxima={k:max(row['median_ns'][k]for row in local)for k in programs};aggregate=sums['pragma']/sums['no_pragma'];worst=maxima['pragma']/maxima['no_pragma'];adopt=aggregate<.99 and worst<1.03;reason='At least 1% aggregate gain with <=3% change in maximum measured median.'if adopt else'No clear aggregate gain under actual pragma/new I/O, or maximum median regression; retain no pragma.'
 # The LCA-heavy case can justify a small aggregate difference.
 if id=='lca'and worst<.98 and aggregate<1.01:adopt=True;reason='Largest random-tree workload improves >=2% with no aggregate regression beyond 1%.'
 rec={'id':id,'old_io_recommended_mode':mode,'gcc_optimization':optimization if adopt else None,'adopted':adopt,'reason':reason,'sources':source_meta,'common_io_sha256':io_hash,'pragma_only_difference_verified':True,'library_hashes':hashes,'driver_sha256':hashlib.sha256((r/entry['driver']).read_bytes()).hexdigest(),'aggregate_ratio':aggregate,'maximum_ratio':worst,'median_ns_by_profile':[{k:v for k,v in row.items()if k in ['profile','median_ns']}for row in local]};recs.append(rec)
 output={'compiler':'/usr/bin/g++','compiler_realpath':os.path.realpath('/usr/bin/g++'),'version':version,'cli_flags':['-std=c++23','-O2'],'cpu':12,'common_io_sha256':io_hash,'note':'Current rendered library/main/new I/O; only actual generated pragma differs. Prefix NDEBUG and all program bytes except pragma stanza are identical. Two warmups plus nine alternating trials. All measured output SHA match. Repository groups/settings not changed.','entries':recs,'measurements':str(p/'measurements.json'),'reproduction':str(p/'run.py')};(p/'recommendations.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n');print(id,'=>',optimization if adopt else'none','aggregate',round(aggregate,4),'maximum',round(worst,4),flush=True)
print('COMPLETE',len(recs),'selected IDs checked',flush=True)
