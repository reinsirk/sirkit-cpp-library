from pathlib import Path
import subprocess,json,time,statistics,hashlib,os
p=Path(__file__).resolve().parent;sources=json.loads((p/'sources.json').read_text())['entries'];inputs=json.loads((p/'inputs.json').read_text());modes={'O2':['-O2'],'O3':['-O3'],'O3_unroll':['-O3','-funroll-loops']};rows=[];recommend=[]
version=subprocess.check_output(['/usr/bin/g++','--version'],text=True).splitlines()[0]
fixed_names=['orientation_atcoder','segment_intersection_atcoder','triangle_area','circle_relation','point_segment_distance']
for id,entry in sources.items():
 binaries={}
 for mode,flags in modes.items():
  exe=p/'bin'/f'{id}_{mode}';cmd=['/usr/bin/g++','-std=c++23',*flags,entry['source'],'-o',str(exe)];q=subprocess.run(cmd,capture_output=True,text=True)
  if q.returncode:raise RuntimeError((id,mode,q.stderr))
  binaries[mode]=exe
 local=[]
 for case in inputs[id]:
  profile=case['kind'];inp=Path(case['input']);checks={}
  # First output validation run also serves as warmup 1.
  for mode,exe in binaries.items():
   with inp.open('rb')as f:out=subprocess.check_output([str(exe)],stdin=f)
   checks[mode]=hashlib.sha256(out).hexdigest()
  assert len(set(checks.values()))==1,(id,profile,checks)
  for exe in binaries.values():
   with inp.open('rb')as f:subprocess.run([str(exe)],stdin=f,stdout=subprocess.DEVNULL,check=True)
  samples={mode:[]for mode in modes};order=list(modes)
  for rep in range(9):
   for mode in order[rep%3:]+order[:rep%3]:
    with inp.open('rb')as f:
     start=time.perf_counter_ns();subprocess.run([str(binaries[mode])],stdin=f,stdout=subprocess.DEVNULL,check=True);samples[mode].append(time.perf_counter_ns()-start)
  row={'id':id,'profile':profile,'input':str(inp),'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'output_sha256':checks['O2'],'samples_ns':samples,'median_ns':{m:statistics.median(v)for m,v in samples.items()},'warmups':2,'timed_trials':9};rows.append(row);local.append(row)
  (p/'measurements.json').write_text(json.dumps(rows,indent=2)+'\n')
 heavy=[r for r in local if not r['profile'].startswith('sample_')];fixed=any(s in id for s in fixed_names)
 if not heavy:heavy=local
 sums={m:sum(r['median_ns'][m]for r in heavy)for m in modes};maxima={m:max(r['median_ns'][m]for r in heavy)for m in modes};winner=min(sums,key=sums.get);chosen='O2';reason='No measured benefit beyond timing noise.'
 if fixed:reason='Fixed-size problem: whole-process time is dominated by process startup and I/O; retain O2.'
 elif maxima['O2']<2_000_000:reason='All measured full programs below 2 ms; startup/I/O noise limits flag selection, retain O2.'
 elif winner!='O2' and sums[winner]<sums['O2']*.98 and maxima[winner]<maxima['O2']*1.05:
  chosen=winner;reason='At least 2% lower aggregate large-profile median and no >5% regression in maximum measured median.'
 rec={'id':id,'scope':entry['scope'],'source_sha256':entry['sha256'],'source':entry['source'],'recommended_mode':chosen,'recommended_flags':modes[chosen],'aggregate_large_profile_ns':sums,'maximum_large_profile_ns':maxima,'aggregate_ratio_vs_O2':{m:sums[m]/sums['O2']for m in modes},'profiles':[r['profile']for r in local],'reason':reason,'numerical_options_unchanged':True};recommend.append(rec)
 result={'compiler':'/usr/bin/g++','compiler_realpath':os.path.realpath('/usr/bin/g++'),'version':version,'cpu':12,'cpu_model':'Intel Core i9-14900K','note':'Old I/O and exact main/library source frozen before global I/O adoption; only compiler optimization flags differ. Two warmups plus nine Latin-rotated timed trials. All output SHA match. No fast-math or numeric type changes. Recommendations are advisory only; repository settings unchanged.','selection':'Choose >=2% aggregate median gain on non-sample profiles with max median no worse than 5%; fixed-size or <2ms problems retain O2 due launch/I/O noise. All raw values supplied for parent review.','modes':modes,'entries':recommend}
 (p/'recommendations.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(id,'=>',chosen,{m:round(sums[m]/sums['O2'],3)for m in modes},flush=True)
print('COMPLETE',len(recommend),'IDs',version,flush=True)
