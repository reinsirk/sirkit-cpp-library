from pathlib import Path
import json,random
p=Path(__file__).resolve().parent;w=p.parent;r=Path('/home/reinsirk/Atcoder_Env');meta=json.loads((p/'sources.json').read_text())['entries'];rng=random.Random(813297);result={};group={}
for f in(r/'Verify/current/groups').glob('*.json'):
 for e in json.loads(f.read_text()).get('entries',[]):group[e['id']]=e
for id in meta:
 cases=[]
 for i,s in enumerate(group[id].get('samples',[])[:2]):
  f=p/'inputs'/f'{id}_sample_{i}.txt';f.write_text(s['input']);cases.append({'kind':'sample_'+str(i),'input':str(f)})
 result[id]=cases

def add(id,kind,text):
 f=p/'inputs'/f'{id}_{kind}.txt';f.write_text(text);result[id].append({'kind':kind,'input':str(f)})
def use(id,kind,f):result[id].append({'kind':kind,'input':str(f)})
g=w/'graph/fable_candidates'
for id in ['scc','low_link_two_edge','low_link_biconnected']:
 n=500000 if id=='scc'else 200000
 for kind in ['chain','cycle','random']:use(id,kind,g/f'input_{id}_{n}_{kind}.txt')
 if id=='low_link_biconnected':use(id,'dense',g/'input_low_link_biconnected_632_dense.txt')
for kind in ['mixed_forced','mixed_cycle']:use('two_sat',kind,g/f'input_two_sat_{kind}_500000.txt')
for id in ['lca','hld_jump','hld_vertex_add_path_sum','hld_path_prod','hld_path_composite']:
 n=200000 if id=='hld_path_composite'else 500000
 for kind in ['chain','star','random','binary']:use(id,kind,g/f'input_{id}_{n}_{kind}.txt')
for kind,n,m in [('chain',500000,499999),('random',200000,500000)]:
 edges=[(i-1,i,1)for i in range(1,n)]
 edges += [(rng.randrange(n),rng.randrange(n),rng.randrange(1000))for _ in range(m-len(edges))]
 add('dijkstra',kind,f'{n} {m} 0 {n-1}\n'+''.join(f'{u} {v} {d}\n'for u,v,d in edges))
for kind in ['forward','negative_cycle']:
 n=2500;m=5000;es=[(v-1,v,1001)for v in range(1,n)]
 if kind=='negative_cycle':es.append((n//2,n//2,1001))
 while len(es)<m:
  u=rng.randrange(n-1);v=rng.randrange(u+1,n);es.append((u,v,rng.randrange(2001)))
 data=f'{n} {m} 1000\n'+''.join(f'{u+1} {v+1} {c}\n'for u,v,c in es)
 for id in ['bellman_ford','spfa']:add(id,kind,data)
for kind in ['dense','chain']:
 n=300;es=[(u,v,1+rng.randrange(1000))for u in range(n)for v in range(u+1,n)]if kind=='dense'else[(v-1,v,1)for v in range(1,n)]
 add('floyd_warshall',kind,f'{n} {len(es)}\n'+''.join(f'{u+1} {v+1} {d}\n'for u,v,d in es))
for id,n in [('topological',100000),('topological_lexicographical',200000)]:
 for kind in ['chain','star','random']:
  es={(v-1 if kind=='chain'else 0,v)for v in range(1,n)}if kind!='random'else set()
  while len(es)<n:
   u=rng.randrange(n-1);v=rng.randrange(u+1,n);es.add((u,v))
  add(id,kind,f'{n} {len(es)}\n'+''.join(f'{u+1} {v+1}\n'for u,v in sorted(es)))
for kind in ['full','random']:
 n=100;board=[''.join('.'if kind=='full'or rng.random()>.3 else'#'for j in range(n))for i in range(n)]
 add('max_flow_grid',kind,f'{n} {n}\n'+'\n'.join(board)+'\n')
n=100;data=f'{n} 5\n'+' '.join(str(i%17)for i in range(n))+'\n'
for i in range(n):
 choices=rng.sample([j+1 for j in range(n)if i!=j],8);data+='8 '+' '.join(map(str,choices))+'\n'
add('project_selection','dependencies',data)
geo=w/'geometry'
for id in ['nearest_two_points','angle_sort','angle_sort_std']:
 for kind in ['random','duplicate','axis','sorted']:use(id,kind,geo/f'input_{id}_200000_{kind}.txt')
for kind in ['random','collinear','sorted']:
 n=500000;pts=[(rng.randrange(-1000000000,1000000001),rng.randrange(-1000000000,1000000001))for _ in range(n)]if kind!='collinear'else[(i,i)for i in range(n)]
 if kind=='sorted':pts.sort()
 data=f'1\n{n}\n'+''.join(f'{x} {y}\n'for x,y in pts)
 for id in ['geometry_convex_hull_full','geometry_convex_hull_split']:add(id,kind,data)
for kind in ['straight','zig']:
 n=100000;pts=[(i,100000 if kind=='straight'else(i%2)*100000)for i in range(n//2)]+[(i,-100000)for i in range(n//2-1,-1,-1)];data=str(n)+'\n'+''.join(f'{x} {y}\n'for x,y in pts)+f'{n//4-1} 50000\n'
 for id in ['geometry_contains_atcoder_full','geometry_contains_atcoder_split']:add(id,kind,data)
(p/'inputs.json').write_text(json.dumps(result,indent=2)+'\n');print('prepared',len(result),'IDs',sum(map(len,result.values())),'input profiles')
