from pathlib import Path
import json
w=Path('/tmp/sirkit_remaining_20261113');out=w/'fable_data';d=json.loads((w/'data/fable_focus.json').read_text());index=json.loads((out/'index.json').read_text());rows=[];parts=[];chunk=''
for e in d['entries']:
 row={k:e[k] for k in ['library','ids','codex_analysis','codex_decision','measurement_summary']};full=out/'full'/e['library'];full.parent.mkdir(parents=True,exist_ok=True);full.write_bytes(Path(e['full_frozen_source']).read_bytes());row['full_frozen_source']=str(full);row['source_sha256']=e['source_sha256'];rows.append(row)
 text='\n// HOT PATHS AND API: '+e['library']+'\n'+Path(e['focus_excerpt']).read_text()+'\n'
 if chunk.count('\n')+text.count('\n')>1600 and chunk:parts.append(chunk);chunk=''
 chunk+=text
root=Path('/home/reinsirk/Atcoder_Env')
for name in sorted({e['driver'] for e in index['entries'].values()}):
 text='\n// MAIN: '+name+'\n'+(root/name).read_text()+'\n'
 if chunk.count('\n')+text.count('\n')>1600 and chunk:parts.append(chunk);chunk=''
 chunk+=text
if chunk:parts.append(chunk)
for path in out.glob('source_part_*.txt'):path.unlink()
for i,text in enumerate(parts,1):(out/f'focus_part_{i:02}.txt').write_text(text)
index['source_parts']=[f'focus_part_{i:02}.txt' for i in range(1,len(parts)+1)];index['review_mode']='API/main/diffs/hot paths first, inspect immutable full source only as needed';(out/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2));(out/'focus_summary.json').write_text(json.dumps({'libraries':rows,'common_io':'Common I/O changes have a separate completed Fable review. They are not included in this body/driver snapshot and will be tested after integration.'},ensure_ascii=False,indent=2))
prompt=(out/'prompt.txt').read_text();a=prompt.index('最初にAGENTS.md');b=prompt.index('あなた自身も');prompt=prompt[:a]+'''最初にindex.json、focus_summary.json、changes.diffを読み、indexに列挙されたfocus_partを全て読んでください。API説明・全main・変更diff・各本体のhot pathを、Codexが全文と独立参照/測定を確認してから選んでいます。不要な全文の重複読込を避けます。判断に別箇所が必要ならfocus_summaryのfull_frozen_sourceをReadで参照してください。ユーザー方針は公開API維持、C++23、独自namespaceに公開型を置かず、所有にvector/unique_ptr、検査省略時も容量計算の整合性を維持、main/IO全体最速、速度効果は同条件実測、未測定変更を勝手に採用しないことです。詳細AGENTS.mdは必要時のみ読んでください。既存I/Oと本体だけの成果を混同しません。\n'''+prompt[b:];(out/'prompt.txt').write_text(prompt);print('focus_parts',len(parts),'lines',sum(x.count('\n') for x in parts))
