from pathlib import Path
import hashlib,json,os,statistics,subprocess,sys,time
ROOT=Path('/tmp/sirkit_remaining_20261113');REPO=Path('/home/reinsirk/Atcoder_Env');WORK=ROOT/'compiler_settings/pragma_validation';DATA=ROOT/'data';sys.path.insert(0,str(REPO/'Scripts'));import prepare_verify as verify
os.sched_setaffinity(0,{10});cli=json.loads((ROOT/'compiler_settings/recommendations.json').read_text());ids=sorted({e['id']for e in cli['entries']if e['recommended_gcc_flags']!='-O2'}|{'hash_map','internal_hash_map','hash_set_membership'});entries={e['id']:e for e in verify.collect()};profiles={'O2':None,'O3':'O3','O3_unroll':'O3,unroll-loops'}
for directory in ['sources','bin','results']:(WORK/directory).mkdir(exist_ok=True)
manifest=WORK/'sources.json'
if not manifest.exists():
 sources={}
 for ident in ids:
  entry=dict(entries[ident]);entry.pop('gcc_optimization',None);base=verify.render(entry)[0];prefix=b'#define SKIP_RUNTIME_CHECKS\n';assert base.startswith(prefix)
  if base[len(prefix):].startswith(b'#define NDEBUG\n'):prefix+=b'#define NDEBUG\n'
  sources[ident]={'libraries':entry['libraries'],'driver':entry['driver'],'source_hashes':verify.render(entry)[1],'driver_sha256':verify.digest((REPO/entry['driver']).read_bytes()),'base_sha256':verify.digest(base),'programs':{}}
  for name,profile in profiles.items():
   additions=(('#if defined(__GNUC__) && !defined(__clang__)\n#pragma GCC optimize('+', '.join(json.dumps(v)for v in profile.split(','))+')\n#endif\n').encode()if profile else b'');data=prefix+additions+base[len(prefix):];copy=dict(entry)
   if profile:copy['gcc_optimization']=profile
   assert data==verify.render(copy)[0],(ident,name,'generated pragma differs')
   source=WORK/'sources'/f'{ident}_{name}.cpp';source.write_bytes(data);sources[ident]['programs'][name]={'path':str(source),'sha256':verify.digest(data)}
 manifest.write_text(json.dumps(sources,indent=2)+'\n')
else:sources=json.loads(manifest.read_text())
for compiler_label,compiler in [('gcc15_2','/usr/bin/g++'),('gcc15_3','/usr/local/bin/g++')]:
 version=subprocess.check_output([compiler,'--version'],text=True).splitlines()[0]
 for ident in ids:
  output=WORK/'results'/f'{ident}_{compiler_label}.json'
  if output.exists():print('already measured',ident,compiler_label,flush=True);continue
  result={'id':ident,'compiler':compiler,'version':version,'cpu':10,'scope':'current_frozen_program_with_generated_gcc_pragmas','programs':sources[ident]['programs'],'builds':{},'cases':[]};binaries={}
  for name,info in sources[ident]['programs'].items():
   source=Path(info['path']);assert verify.digest(source.read_bytes())==info['sha256'];binary=WORK/'bin'/f'{ident}_{compiler_label}_{name}';cmd=[compiler,'-std=c++23','-O2','-Wall','-Wextra',str(source),'-o',str(binary)];begin=time.perf_counter();built=subprocess.run(cmd,capture_output=True,text=True,timeout=120);assert built.returncode==0,(ident,version,name,built.stderr);binaries[name]=binary;result['builds'][name]={'command':cmd,'seconds':time.perf_counter()-begin,'diagnostics':built.stderr}
  for kind in ['small','random','degenerate']:
   path=DATA/'inputs'/ident/f'{kind}.in';data=path.read_bytes();ref=None
   for name,binary in binaries.items():
    stdout=subprocess.run([str(binary)],input=data,capture_output=True,check=True,timeout=60).stdout
    if ref is None:ref=stdout
    assert stdout==ref,(ident,version,name,kind,'output mismatch')
    if kind=='small':assert stdout.decode().strip()==path.with_suffix('.expected').read_text().strip(),(ident,version,name,'independent mismatch')
   samples={name:[]for name in binaries};names=list(binaries)
   for iteration in range(11):
    order=names if iteration%2==0 else names[::-1];rotate=(iteration//2)%len(names);order=order[rotate:]+order[:rotate]
    for name in order:
     with path.open('rb')as inp:
      t=time.perf_counter_ns();subprocess.run([str(binaries[name])],stdin=inp,stdout=subprocess.DEVNULL,check=True);ms=(time.perf_counter_ns()-t)/1e6
     if iteration>=2:samples[name].append(ms)
   median={name:statistics.median(t)for name,t in samples.items()};row={'kind':kind,'input_sha256':verify.digest(data),'output_sha256':verify.digest(ref),'output_equal':True,'median_ms':median,'ratio_to_O2':{name:ms/median['O2']for name,ms in median.items()},'samples_ms':samples,'warmup':2,'measured':9};result['cases'].append(row);print(compiler_label,ident,kind,{k:round(v,3)for k,v in row['ratio_to_O2'].items()},flush=True)
  output.write_text(json.dumps(result,indent=2)+'\n')
