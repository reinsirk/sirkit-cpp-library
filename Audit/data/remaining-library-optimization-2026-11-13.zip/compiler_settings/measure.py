from pathlib import Path
import hashlib,json,math,os,random,re,statistics,subprocess,sys,time
ROOT=Path('/tmp/sirkit_remaining_20261113');WORK=ROOT/'compiler_settings';DATA=ROOT/'data';os.sched_setaffinity(0,{10});review=json.loads((DATA/'codex_review.json').read_text());COMPILER=subprocess.check_output(['g++','--version'],text=True).splitlines()[0]
for name in ['sources','bin','results']:(WORK/name).mkdir(exist_ok=True)
chosen=set(sys.argv[1:]);entries=[e for e in review['entries']if not chosen or e['id']in chosen]
for entry in entries:
 ident=entry['id'];output=WORK/'results'/f'{ident}.json'
 if output.exists():print('already measured',ident,flush=True);continue
 data=Path(entry['frozen_submission']).read_bytes();assert hashlib.sha256(data).hexdigest()==entry['final_submission_sha256'];source=WORK/'sources'/f'{ident}.cpp';source.write_bytes(data)
 assert_count=len(re.findall(rb'\bassert\s*\(',data));variants={'O2':['-O2'],'O3':['-O3'],'O3_unroll':['-O3','-funroll-loops']}
 if assert_count:variants.update({name+'_NDEBUG':flags+['-DNDEBUG']for name,flags in list(variants.items())})
 report={'format':1,'id':ident,'compiler':COMPILER,'cpu':10,'program':str(source),'source_sha256':hashlib.sha256(data).hexdigest(),'assert_calls':assert_count,'scope':'full_program_compiler_settings_only','builds':{},'cases':[]};binaries={}
 for name,flags in variants.items():
  binary=WORK/'bin'/f'{ident}_{name}';cmd=['g++','-std=c++23',*flags,'-Wall','-Wextra',str(source),'-o',str(binary)];begin=time.perf_counter();built=subprocess.run(cmd,capture_output=True,text=True,timeout=120);assert built.returncode==0,(ident,name,built.stderr)
  binaries[name]=binary;report['builds'][name]={'command':cmd,'compile_seconds':time.perf_counter()-begin,'diagnostics':built.stderr,'binary_bytes':binary.stat().st_size}
 for kind in ['small','random','degenerate']:
  path=DATA/'inputs'/ident/f'{kind}.in';inp=path.read_bytes();reference=None
  for name,binary in binaries.items():
   r=subprocess.run([str(binary)],input=inp,capture_output=True,check=True,timeout=60)
   if reference is None:reference=r.stdout
   assert r.stdout==reference,(ident,kind,name,'different output')
   if kind=='small':assert r.stdout.decode().strip()==path.with_suffix('.expected').read_text().strip(),(ident,name,'independent mismatch')
  times={name:[]for name in variants};names=list(variants)
  for repeat in range(11):
   order=names if repeat%2==0 else names[::-1]
   # 各設定が先頭/末尾に固定されないよう、反転に加えて順番を回す。
   rotation=(repeat//2)%len(names);order=order[rotation:]+order[:rotation]
   for name in order:
    with path.open('rb')as handle:
     begin=time.perf_counter_ns();subprocess.run([str(binaries[name])],stdin=handle,stdout=subprocess.DEVNULL,check=True);ms=(time.perf_counter_ns()-begin)/1e6
    if repeat>=2:times[name].append(ms)
  med={name:statistics.median(v)for name,v in times.items()};report['cases'].append({'kind':kind,'input':str(path),'input_sha256':hashlib.sha256(inp).hexdigest(),'output_sha256':hashlib.sha256(reference).hexdigest(),'output_tokens':len(reference.split()),'status':'all_outputs_equal','independent_reference':kind=='small','median_ms':med,'ratio_to_O2':{name:t/med['O2']for name,t in med.items()},'samples_ms':times,'warmup':2,'measured':9});print(ident,kind,{name:round(ms/med['O2'],3)for name,ms in med.items()},flush=True)
 output.write_text(json.dumps(report,indent=2)+'\n')
