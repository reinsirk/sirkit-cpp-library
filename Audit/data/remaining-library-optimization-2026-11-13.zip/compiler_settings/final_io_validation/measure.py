from pathlib import Path
import hashlib,json,os,statistics,subprocess,sys,time
R=Path('/home/reinsirk/Atcoder_Env');ROOT=Path('/tmp/sirkit_remaining_20261113');W=ROOT/'compiler_settings/final_io_validation';DATA=ROOT/'data';sys.path.insert(0,str(R/'Scripts'));import prepare_verify as verify
os.sched_setaffinity(0,{10});prior=json.loads((ROOT/'compiler_settings/pragma_validation/recommendations.json').read_text());profiles=prior['recommended_online_gcc_15_2_profiles'];assert len(profiles)==19;entries={e['id']:e for e in verify.collect()};compiler='/usr/bin/g++';version=subprocess.check_output([compiler,'--version'],text=True).splitlines()[0]
for directory in ['sources','bin','results']:(W/directory).mkdir(exist_ok=True)
manifest=W/'sources.json'
if not manifest.exists():
 frozen={}
 for ident,profile in profiles.items():
  entry=dict(entries[ident]);entry.pop('gcc_optimization',None);base,hashes=verify.render(entry);candidate=dict(entry,gcc_optimization=profile);recommended,recommended_hashes=verify.render(candidate);assert hashes==recommended_hashes
  block=('#if defined(__GNUC__) && !defined(__clang__)\n#pragma GCC optimize('+', '.join(json.dumps(option)for option in profile.split(','))+')\n#endif\n').encode();assert recommended.count(block)==1;assert recommended.replace(block,b'',1)==base,(ident,'frame mismatch')
  row={'id':ident,'profile':profile,'libraries':entry['libraries'],'driver':entry['driver'],'library_source_hashes':hashes,'driver_sha256':verify.digest((R/entry['driver']).read_bytes()),'common_io_sha256':verify.digest((R/verify.FAST_IO).read_bytes()),'support_source_hashes':verify.common_source_hashes((R/entry['driver']).read_text()),'frame_equal_after_removing_pragma':True,'frame_sha256':verify.digest(base),'pragma':block.decode(),'programs':{}}
  for name,program in [('base',base),('recommended',recommended)]:
   path=W/'sources'/f'{ident}_{name}.cpp';path.write_bytes(program);row['programs'][name]={'path':str(path),'sha256':verify.digest(program)}
  frozen[ident]=row
 manifest.write_text(json.dumps(frozen,indent=2)+'\n')
else:frozen=json.loads(manifest.read_text())
for ident,frame in frozen.items():
 output=W/'results'/f'{ident}.json'
 if output.exists():print('already measured',ident,flush=True);continue
 result={'id':ident,'profile':frame['profile'],'compiler':compiler,'version':version,'cpu':10,'frame':frame,'builds':{},'cases':[]};binaries={}
 for name,info in frame['programs'].items():
  source=Path(info['path']);assert verify.digest(source.read_bytes())==info['sha256'];binary=W/'bin'/f'{ident}_{name}';flags=['-std=c++23','-O2','-Wall','-Wextra'];cmd=[compiler,*flags,str(source),'-o',str(binary)];built=subprocess.run(cmd,capture_output=True,text=True,timeout=120);assert built.returncode==0,(ident,name,built.stderr);binaries[name]=binary;result['builds'][name]={'command':cmd,'flags':flags,'diagnostics':built.stderr}
 assert result['builds']['base']['flags']==result['builds']['recommended']['flags']
 for kind in ['random','degenerate']:
  path=DATA/'inputs'/ident/f'{kind}.in';data=path.read_bytes();outputs={name:subprocess.run([str(exe)],input=data,capture_output=True,check=True,timeout=60).stdout for name,exe in binaries.items()};assert outputs['base']==outputs['recommended'],(ident,kind,'output mismatch');samples={name:[]for name in binaries}
  for iteration in range(11):
   for name in ['base','recommended']if iteration%2==0 else ['recommended','base']:
    with path.open('rb')as inp:
     begin=time.perf_counter_ns();subprocess.run([str(binaries[name])],stdin=inp,stdout=subprocess.DEVNULL,check=True);ms=(time.perf_counter_ns()-begin)/1e6
    if iteration>=2:samples[name].append(ms)
  median={name:statistics.median(values)for name,values in samples.items()};row={'kind':kind,'input':str(path),'input_sha256':verify.digest(data),'output_sha256':verify.digest(outputs['base']),'all_outputs_equal':True,'median_ms':median,'recommended_over_base':median['recommended']/median['base'],'samples_ms':samples,'warmup':2,'measured':9};result['cases'].append(row);print(ident,frame['profile'],kind,round(row['recommended_over_base'],3),median,flush=True)
 output.write_text(json.dumps(result,indent=2)+'\n')
