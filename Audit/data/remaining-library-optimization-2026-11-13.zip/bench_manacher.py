from pathlib import Path
import hashlib,json,os,random,statistics,subprocess,time
w=Path('/tmp/sirkit_remaining_20261113');os.sched_setaffinity(0,{9});before=(w/'files_before/String/Manacher.cpp').read_bytes();candidate=(w/'manacher_candidate.cpp').read_bytes();source=(w/'baseline/manacher.cpp').read_bytes();assert source.count(before)==1;rng=random.Random(20261113);inputs=[]
for n in [1000,500000]:
 for name,s in [('random',''.join(rng.choice('abcdefghijklmnopqrstuvwxyz') for _ in range(n))),('binary',''.join(rng.choice('ab') for _ in range(n))),('equal','a'*n),('periodic',('abacaba'*((n+6)//7))[:n])]:
  path=w/f'manacher_{name}_{n}.in';path.write_text(s+'\n');inputs.append((name,n,path))
results=[]
for c in ['g++','clang++']:
 bins={}
 for stage,body in [('before',before),('candidate',candidate)]:
  src=w/f'manacher_{stage}_full.cpp';src.write_bytes(source.replace(before,body));exe=w/f'manacher_{c}_{stage}';cmd=[c,'-std=c++23','-O2','-Wall','-Wextra']
  if c=='clang++':cmd+=['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
  r=subprocess.run(cmd+[str(src),'-o',str(exe)],capture_output=True,text=True);assert r.returncode==0,r.stderr;bins[stage]=exe
 for name,n,path in inputs:
  outputs=[]
  for stage in bins:
   with path.open('rb') as f:outputs.append(subprocess.run([str(bins[stage])],stdin=f,capture_output=True,check=True).stdout)
  assert outputs[0]==outputs[1]
  times={k:[] for k in bins}
  for i in range(23):
   for stage in (['before','candidate'] if i%2==0 else ['candidate','before']):
    with path.open('rb') as f:
     t=time.perf_counter_ns();subprocess.run([str(bins[stage])],stdin=f,stdout=subprocess.DEVNULL,check=True);elapsed=(time.perf_counter_ns()-t)/1e6
    if i>=2:times[stage].append(elapsed)
  med={k:statistics.median(v) for k,v in times.items()};row={'compiler':c,'case':name,'n':n,'median_ms':med,'candidate_over_before':med['candidate']/med['before'],'samples_ms':times};results.append(row);print(c,name,n,round(row['candidate_over_before'],3),flush=True)
(w/'manacher_core_benchmark.json').write_text(json.dumps({'cpu':9,'scope':'whole_program_with_same_main_io_only_body_changed','results':results,'source_sha256':{'before':hashlib.sha256(before).hexdigest(),'candidate':hashlib.sha256(candidate).hexdigest()}},indent=2)+'\n')
