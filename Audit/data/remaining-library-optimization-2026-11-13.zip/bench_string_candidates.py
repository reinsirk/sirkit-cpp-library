from pathlib import Path
import hashlib,json,os,random,statistics,subprocess,time
w=Path('/tmp/sirkit_remaining_20261113');os.sched_setaffinity(0,{9});rng=random.Random(1611);tasks=[]
for id in ['manacher','suffix_array','rolling_hash','trie_dictionary']:
 source=(w/'baseline'/f'{id}.cpp').read_bytes()
 if id=='rolling_hash':old=(w/'files_before/String/RollingHash.cpp').read_bytes();new=(w/'rolling_candidate.cpp').read_bytes()
 else:
  main='trie_gacha_main.cpp' if id=='trie_dictionary' else f'{id}_main.cpp';old=(w/'files_before/Verify/current/drivers'/main).read_bytes();new=(w/('trie_driver_candidate.cpp' if id=='trie_dictionary' else f'{id}_driver_candidate.cpp')).read_bytes()
 if id != "rolling_hash":old=b"\n".join(old.split(b"\n")[2:]);new=b"\n".join(new.split(b"\n")[2:])
 assert source.count(old)==1,id;candidate=source.replace(old,new);inputs=[]
 for n in [1000,100000]:
  if id=='trie_dictionary':
   for name,words in [('random',[''.join(rng.choice('abcdefgh') for _ in range(10)) for _ in range(n)]),('equal',['aaaaaaaaaa']*n),('mixed',['abcde'+str(i%10000) for i in range(n)])]:
    p=w/f'string_{id}_{name}_{n}.in';p.write_text(str(n)+'\n'+'\n'.join(words)+'\n');inputs.append((name,n,p))
  else:
   for name,s in [('random',''.join(rng.choice('abcdefghijklmnopqrstuvwxyz') for _ in range(n))),('binary',''.join(rng.choice('ab') for _ in range(n))),('equal','a'*n),('periodic',('abacaba'*((n+6)//7))[:n])]:
    p=w/f'string_{id}_{name}_{n}.in';p.write_text(s+'\n');inputs.append((name,n,p))
 tasks.append((id,source,candidate,inputs))
results=[]
for c in ['g++','clang++']:
 for id,before,candidate,inputs in tasks:
  bins={}
  for stage,source in [('before',before),('candidate',candidate)]:
   p=w/f'string_{id}_{stage}.cpp';p.write_bytes(source);exe=w/f'string_{id}_{c}_{stage}';cmd=[c,'-std=c++23','-O2','-Wall','-Wextra']
   if c=='clang++':cmd+=['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
   r=subprocess.run(cmd+[str(p),'-o',str(exe)],capture_output=True,text=True);assert r.returncode==0,r.stderr;bins[stage]=exe
  for name,n,path in inputs:
   out=[]
   for stage in bins:
    with path.open('rb') as f:out.append(subprocess.run([str(bins[stage])],stdin=f,capture_output=True,check=True).stdout)
   assert out[0]==out[1],(c,id,name)
   times={k:[] for k in bins}
   for i in range(15):
    for stage in (['before','candidate'] if i%2==0 else ['candidate','before']):
     with path.open('rb') as f:
      t=time.perf_counter_ns();subprocess.run([str(bins[stage])],stdin=f,stdout=subprocess.DEVNULL,check=True);elapsed=(time.perf_counter_ns()-t)/1e6
     if i>=2:times[stage].append(elapsed)
   med={k:statistics.median(x) for k,x in times.items()};row={'id':id,'compiler':c,'case':name,'n':n,'median_ms':med,'ratio':med['candidate']/med['before'],'samples_ms':times};results.append(row);print(id,c,name,n,round(row['ratio'],3),flush=True)
(w/'string_candidates_benchmark.json').write_text(json.dumps({'cpu':9,'scope':'same main+IO for rolling body candidate; same body+IO for other driver candidates','warmup':2,'measured':13,'results':results},indent=2)+'\n')
