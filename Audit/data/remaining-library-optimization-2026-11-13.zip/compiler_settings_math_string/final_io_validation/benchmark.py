from pathlib import Path
import sys,json,subprocess,hashlib,re,statistics,time,math,shutil,datetime
R=Path('/home/reinsirk/Atcoder_Env');W=Path(__file__).parent;P=W.parent;CPU='11';COMPILER='/usr/bin/g++'
sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
for name in ['sources','files','bin','results','output_check']:(W/name).mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def file_sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
prior=json.loads((P/'recommendations.json').read_text());oldmanifest=json.loads((P/'manifest.json').read_text());oldentries={e['id']:e for e in oldmanifest['entries']};choices={r['id']:r['gcc_optimization'] for r in prior['recommendations'] if r['gcc_optimization']!='O2'};assert len(choices)==6
E={e['id']:e for e in pv.collect()};version=subprocess.check_output([COMPILER,'--version'],text=True).splitlines()[0];assert '15.2.0' in version
manifest_path=W/'manifest.json'
if not manifest_path.exists():
 common=(R/pv.FAST_IO).read_bytes();assert sha(common).startswith('87641ba8'),sha(common);allfiles={p for id in choices for p in E[id]['libraries']}|{E[id]['driver'] for id in choices};frozen={p:(R/p).read_bytes() for p in sorted(allfiles)}
 for p,data in {**frozen,pv.FAST_IO:common}.items():f=W/'files'/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 rows=[]
 for id,choice in choices.items():
  baseline=dict(E[id]);baseline.pop('gcc_optimization',None);candidate={**baseline,'gcc_optimization':choice};kwargs={'source_overrides':frozen,'driver_override':frozen[E[id]['driver']].decode()};a,hashes=pv.render(baseline,**kwargs);b,_=pv.render(candidate,**kwargs)
  pattern=rb'^#if defined\(__GNUC__\) && !defined\(__clang__\)\n#pragma GCC optimize\([^\n]+\)\n#endif\n';without,count=re.subn(pattern,b'',b,flags=re.M);assert count==1 and without==a,(id,'different code other than chosen pragma')
  assert (R/pv.FAST_IO).read_bytes()==common,'common I/O changed during snapshot'
  sources={}
  for kind,src in [('no_pragma',a),('chosen_pragma',b)]:f=W/'sources'/f'{id}-{kind}.cpp';f.write_bytes(src);sources[kind]={'path':str(f),'sha256':sha(src)}
  cases=[c for c in oldentries[id]['cases'] if c['kind']=='large'];assert len(cases)>=3
  rows.append({'id':id,'chosen_optimization':choice,'sources':sources,'only_pragma_diff':True,'ndebug':bool(re.search(rb'^#define NDEBUG',a,re.M)),'library_sha256':hashes,'driver':E[id]['driver'],'driver_sha256':sha(frozen[E[id]['driver']]),'common_fast_io_sha256':sha(common),'cases':cases,'samples':E[id]['samples']})
 manifest={'format':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'new common I/O and chosen GCC pragma interaction only','compiler_path':COMPILER,'compiler_version':version,'cpu':11,'cli_flags':['-std=c++23','-O2'],'entries':rows};manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
else:manifest=json.loads(manifest_path.read_text())

def run(exe,inp,out):
 with Path(inp).open('rb') as fin,open(out,'wb') as fout:
  start=time.perf_counter_ns();p=subprocess.run(['taskset','-c',CPU,str(exe)],stdin=fin,stdout=fout,stderr=subprocess.PIPE);ns=time.perf_counter_ns()-start
 assert p.returncode==0,p.stderr;return ns
for e in manifest['entries']:
 id=e['id'];result=W/'results'/f'{id}.json'
 if result.exists() and json.loads(result.read_text()).get('status')=='complete':print('REUSE',id,flush=True);continue
 row={'id':id,'chosen_optimization':e['chosen_optimization'],'status':'running','builds':{},'samples':{},'cases':[]};bins={}
 for kind,src in e['sources'].items():
  assert file_sha(src['path'])==src['sha256'];exe=W/'bin'/f'{id}-{kind}';cmd=['taskset','-c',CPU,COMPILER,'-std=c++23','-O2',src['path'],'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr;row['builds'][kind]={'command':cmd,'source_sha256':src['sha256'],'passed':True,'binary_sha256':file_sha(exe),'diagnostics':p.stderr};bins[kind]=exe
  for sample in e['samples']:
   p=subprocess.run(['taskset','-c',CPU,str(exe)],input=sample['input'],text=True,capture_output=True);assert p.returncode==0 and pv.matches(E[id],sample,p.stdout),(id,kind,p.stdout)
  row['samples'][kind]={'passed':True,'count':len(e['samples'])}
 for case in e['cases']:
  assert file_sha(case['path'])==case['sha256'];checks={};expected=None
  for kind,exe in bins.items():
   out=W/'output_check'/f'{id}.out';run(exe,case['path'],out);proof={'sha256':file_sha(out),'bytes':out.stat().st_size};expected=expected or proof;assert proof==expected;checks[kind]=proof
  raw={k:[] for k in bins};order=list(bins);active=W/'bin/active'
  for rep in range(11):
   for kind in order if rep%2==0 else list(reversed(order)):
    shutil.copyfile(bins[kind],active);active.chmod(0o755);ns=run(active,case['path'],'/dev/null')
    if rep>=2:raw[kind].append(ns)
  med={k:statistics.median(v) for k,v in raw.items()};ratio=med['chosen_pragma']/med['no_pragma'];row['cases'].append({**case,'full_output':checks,'raw_ns':raw,'median_ns':med,'chosen_ratio':ratio});result.write_text(json.dumps(row,indent=2)+'\n');print(id,case['name'],round(ratio,5),flush=True)
 row['status']='complete';result.write_text(json.dumps(row,indent=2)+'\n')
rows=[];groups={}
for e in manifest['entries']:
 row=json.loads((W/'results'/f"{e['id']}.json").read_text());assert row['status']=='complete';ratios=[c['chosen_ratio'] for c in row['cases']];aggregate=math.exp(sum(map(math.log,ratios))/len(ratios));worst=max(ratios);accept=aggregate<=0.98 and worst<=1.02;choice=e['chosen_optimization'] if accept else None;groups.setdefault(choice or 'no_pragma',[]).append(e['id']);rows.append({'id':e['id'],'gcc_optimization':choice,'previous_candidate':e['chosen_optimization'],'retained':accept,'geomean_ratio':aggregate,'worst_case_ratio':worst,'case_ratios':{c['name']:c['chosen_ratio'] for c in row['cases']},'ndebug':e['ndebug'],'only_pragma_diff':e['only_pragma_diff'],'sources':e['sources'],'common_fast_io_sha256':e['common_fast_io_sha256'],'raw_result_path':str(W/'results'/f"{e['id']}.json"),'correctness':'Every full output byte-identical and every sample passed for both settings.'})
summary={'format':1,'status':'complete','scope':'Final new shared I/O + selected GCC optimize pragma interaction, separate from library/body optimization.','compiler':version,'compiler_path':COMPILER,'cpu':11,'cli_flags':['-std=c++23','-O2'],'warmups_per_case_setting':2,'measured_per_case_setting':9,'order':'Alternating settings, same active executable path; executable copies excluded from timers.','source_equality':'Removing precisely one generated GCC pragma block makes chosen source byte-identical to no-pragma source. NDEBUG is automatically identical from prepare_verify.render.','selection_policy':'Keep prior chosen pragma only if >=2% geometric mean improvement and no >2% representative large-case regression vs new-I/O no-pragma baseline. Null means no gcc_optimization entry should be added.','recommended_groups':groups,'recommendations':rows,'programs':len(rows),'builds':12,'full_output_comparisons':sum(len(e['cases'])*2 for e in manifest['entries']),'repository_edits':False,'fable_invoked':False,'manifest':{'path':str(manifest_path),'sha256':file_sha(manifest_path)},'reproduction_script':{'path':str(Path(__file__)),'sha256':file_sha(Path(__file__))},'online_verification':'not performed'}
(W/'recommendations.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print('FINAL',groups,flush=True)
