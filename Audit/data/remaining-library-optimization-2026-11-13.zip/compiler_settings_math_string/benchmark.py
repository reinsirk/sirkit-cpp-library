from pathlib import Path
import sys,json,hashlib,subprocess,time,random,statistics,math,shutil,datetime,re
R=Path('/home/reinsirk/Atcoder_Env');P=Path('/tmp/sirkit_remaining_20261113');W=P/'compiler_settings_math_string';A=P/'math_algorithms';CPU='11';COMPILER='/usr/bin/g++';SETTINGS={'O2':['-O2'],'O3':['-O3'],'O3,unroll-loops':['-O3','-funroll-loops']}
sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
sha=lambda b:hashlib.sha256(b).hexdigest()
def file_sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1<<20),b''):h.update(block)
 return h.hexdigest()
for directory in ['sources','files','inputs','bin','results','output_check']:(W/directory).mkdir(exist_ok=True)
B=json.loads((P/'baseline.json').read_text());ids=[k for k,b in B.items() if any(l.startswith(('Math/','Algorithm/')) for l in b['libraries'])]+['manacher','suffix_array','suffix_array_substrings','trie_dictionary','rolling_hash'];assert len(ids)==33
E={e['id']:e for e in pv.collect()};rng=random.Random(20261113);manifest_path=W/'manifest.json'

def materialize_inputs(id):
 cases=[]
 def add(case,data=None,src=None,kind='large'):
  f=W/'inputs'/f'{id}-{case}.in'
  if src is not None:shutil.copyfile(src,f)
  else:f.write_text(data)
  cases.append({'name':case,'kind':kind,'path':str(f),'sha256':file_sha(f),'bytes':f.stat().st_size})
 def seq(a):return ' '.join(map(str,a))+'\n'
 if id in ['ntt_convolution','lis','eratosthenes']:
  for f in sorted((A/'inputs').glob(id+'-*.in')):
   small=(f.stat().st_size<50000) if id!='eratosthenes' else ('100000000-' not in f.name)
   add(f.stem.removeprefix(id+'-'),src=f,kind='small' if small else 'large')
  if id=='ntt_convolution':
   n=262144;add('262144-zero',f'{n} {n}\n'+seq([0]*n)+seq([0]*n));add('1-262144',f'1 {n}\n7\n'+seq([rng.randrange(998244353) for _ in range(n)]))
 elif id.startswith('zeta_') and 'sieve_factorize' not in id:
  full=id.removesuffix('_split')+'_full' if id.endswith('_split') else id
  for f in sorted((A/'inputs').glob(full+'-*.in')):add(f.stem.removeprefix(full+'-'),src=f,kind='small' if f.stat().st_size<50000 else 'large')
 elif id.startswith('zeta_sieve_factorize'):
  for name,n in [('small',1),('power',1<<39),('large',10**12),('prime-like',9999999967)]:add(name,str(n)+'\n',kind='small' if n==1 else 'large')
 elif id in ['binomial_prime_split','binomial_integer_prime_mod_split','binomial_modint_prime_mod_split']:
  for name in ['zero','small','large','smallprime','zeros']:add(name,src=A/'binomial_main'/f'{name}.in',kind='small' if name in ['zero','small'] else 'large')
 elif id in ['binomial_integer_split','binomial_modint_split']:
  add('small','3 2\n0 0\n1 0\n1 1\n',kind='small')
  for name,p,kind in [('random-composite',1000000,'random'),('random-prime',999983,'random'),('degenerate',1000000,'zero')]:
   pairs=[]
   for _ in range(50000):
    n=rng.randrange(10**18);k=rng.randrange(64) if kind=='random' else 0;pairs.append((n,min(k,n)))
   add(name,f'{len(pairs)} {p}\n'+''.join(f'{n} {k}\n' for n,k in pairs))
 elif id=='primality':
  add('sample-small','8\n0\n1\n2\n3\n4\n7\n9\n18446744073709551557\n',kind='small')
  for f in sorted((A/'small_main_candidates').glob('*.in')):add(f.stem,src=f)
 elif id in ['fraction_sort','radix_sort','radix_sort_uint32']:
  sizes=[4,200000]
  for n in sizes:
   for kind in ['random','equal','ordered']:
    if id=='fraction_sort':
     pairs=[(rng.randrange(1,10**9+1),rng.randrange(1,10**9+1)) if kind=='random' else (7,13) if kind=='equal' else (i+1,n-i) for i in range(n)];data=str(n)+'\n'+''.join(f'{a} {b}\n' for a,b in pairs)
    else:
     a=[rng.randrange(1,1000001) if kind=='random' else 7 if kind=='equal' else i+1 for i in range(n)];data=str(n)+'\n'+seq(a)
    add(f'{n}-{kind}',data,kind='small' if n==4 else 'large')
 elif id=='fraction_arithmetic':
  for n,k in [(1,1),(5,3),(100000,1),(100000,50000),(100000,100000)]:add(f'{n}-{k}',f'{n} {k}\n',kind='small' if n<=5 else 'large')
 elif id=='next_combination':
  add('small','2 1 100\n1 2 7\n',kind='small')
  for kind in ['random','zero']:
   edges=[(i,j,rng.randrange(10**15) if kind=='random' else 0) for i in range(1,9) for j in range(i+1,9)];add(kind,'8 28 1000000000000000\n'+''.join(f'{i} {j} {v}\n' for i,j,v in edges))
 elif id in ['matrix_rotate','matrix_rotate_grid']:
  for n in [1,100]:
   for kind in ['random','equal']:
    if id=='matrix_rotate':data=str(n)+'\n'+''.join(seq([rng.randrange(2) if kind=='random' else 0 for _ in range(n)]) for _ in range(2*n))
    else:data=str(n)+'\n'+''.join(''.join(rng.choice('.#') if kind=='random' else '.' for _ in range(n))+'\n' for _ in range(2*n))
    add(f'{n}-{kind}',data,kind='small' if n==1 else 'large')
 elif id in ['manacher','suffix_array','suffix_array_substrings','trie_dictionary','rolling_hash']:
  prefix='suffix_array' if id=='suffix_array_substrings' else id
  for f in sorted(P.glob('string_'+prefix+'_*in')):add(f.stem.removeprefix('string_'+prefix+'_'),src=f,kind='small' if f.stem.endswith('_1000') else 'large')
  # Each setting also receives an actual tiny judge sample.
  add('sample-small',E[id]['samples'][0]['input'],kind='small')
 else:raise ValueError(id)
 assert any(c['kind']=='small' for c in cases),id
 assert any(c['kind']=='large' for c in cases),id
 return cases

if not manifest_path.exists():
 oldio=(P/'files_before'/pv.FAST_IO).read_bytes();all_paths={p for id in ids for p in E[id]['libraries']}|{E[id]['driver'] for id in ids};frozen={name:(R/name).read_bytes() for name in sorted(all_paths)}
 for name,data in frozen.items():f=W/'files'/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 f=W/'files'/pv.FAST_IO;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(oldio)
 original_expand=pv.expand_common
 def frozen_expand(source,hashes=None):
  if hashes is not None and pv.FAST_IO_INCLUDE in source:hashes[pv.FAST_IO]=sha(oldio)
  return original_expand(source.replace(pv.FAST_IO_INCLUDE,'// Frozen old common I/O\n'+oldio.decode()),hashes)
 pv.expand_common=frozen_expand
 rows=[]
 for id in ids:
  entry=dict(E[id]);previous=entry.pop('gcc_optimization',None);source,libhash=pv.render(entry,source_overrides=frozen,driver_override=frozen[entry['driver']].decode());assert not re.search(rb'^#pragma GCC optimize',source,re.M),id
  src=W/'sources'/f'{id}.cpp';src.write_bytes(source);rows.append({'id':id,'problem_url':entry['problem_url'],'source_path':str(src),'source_sha256':sha(source),'driver':entry['driver'],'driver_sha256':sha(frozen[entry['driver']]),'library_sha256':libhash,'old_common_fast_io_sha256':sha(oldio),'ndebug':bool(re.search(rb'^#define NDEBUG',source,re.M)),'ignored_previous_gcc_optimization':previous,'cases':materialize_inputs(id),'samples':entry['samples']})
 env=subprocess.check_output([COMPILER,'--version'],text=True).splitlines()[0];assert '15.2.0' in env,env
 m={'format':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compiler_path':COMPILER,'compiler_version':env,'cpu':11,'common_io_changed':False,'source_stage':'Current repository libraries/main frozen before compilation, old shared I/O fixed. Entry-specific GCC prefix disabled for all variants. NDEBUG inserted only when source contains runtime assert, and identical in all variants.','entries':rows};manifest_path.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
else:m=json.loads(manifest_path.read_text())

def execute(exe,inp,out):
 with Path(inp).open('rb') as fin,open(out,'wb') as fout:
  start=time.perf_counter_ns();p=subprocess.run(['taskset','-c',CPU,str(exe)],stdin=fin,stdout=fout,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
 assert p.returncode==0,(exe,p.stderr.decode(errors='replace'));return elapsed

for entry in m['entries']:
 id=entry['id'];record=W/'results'/f'{id}.json'
 if record.exists() and json.loads(record.read_text()).get('status')=='complete':print('REUSE',id,flush=True);continue
 src=Path(entry['source_path']);assert file_sha(src)==entry['source_sha256'];row=json.loads(record.read_text()) if record.exists() else {'id':id,'source_sha256':entry['source_sha256'],'compiler':m['compiler_version'],'cpu':11,'status':'running','builds':{},'cases':[]};assert row['source_sha256']==entry['source_sha256'];bins={}
 for setting,flags in SETTINGS.items():
  binary=W/'bin'/f'{id}-{setting.replace(",","-")}'
  if setting in row['builds'] and row['builds'][setting]['passed'] and binary.exists() and file_sha(binary)==row['builds'][setting]['binary_sha256']:
   bins[setting]=binary;continue
  cmd=['taskset','-c',CPU,COMPILER,'-std=c++23',*flags,str(src),'-o',str(binary)];p=subprocess.run(cmd,capture_output=True,text=True);row['builds'][setting]={'command':cmd,'passed':p.returncode==0,'diagnostics':p.stderr,'binary_sha256':file_sha(binary) if p.returncode==0 else None};record.write_text(json.dumps(row,indent=2)+'\n');assert p.returncode==0,p.stderr;bins[setting]=binary
 # Existing online examples are checked for every complete program/settings.
 row['sample_checks']={}
 for setting,binary in bins.items():
  samples=[]
  for sample in entry['samples']:
   p=subprocess.run(['taskset','-c',CPU,str(binary)],input=sample['input'],text=True,capture_output=True);ok=p.returncode==0 and pv.matches(E[id],sample,p.stdout);samples.append(ok);assert ok,(id,setting,p.stdout,sample)
  row['sample_checks'][setting]=samples
 for case in entry['cases']:
  if any(c['name']==case['name'] and c['sha256']==case['sha256'] and all(len(v)==9 for v in c['raw_ns'].values()) for c in row['cases']):continue
  inp=case['path'];assert file_sha(Path(inp))==case['sha256'];check={};expected=None
  for setting,binary in bins.items():
   outfile=W/'output_check'/f'{id}.out';execute(binary,inp,outfile);h=file_sha(outfile);size=outfile.stat().st_size;check[setting]={'sha256':h,'bytes':size};expected=(h,size) if expected is None else expected;assert (h,size)==expected,(id,case['name'],check)
  raw={s:[] for s in SETTINGS};settings=list(SETTINGS);active=W/'bin/active'
  # Warmups and measured runs use the same executable path; copies are outside timers.
  for rep in range(11):
   order=settings[rep%3:]+settings[:rep%3]
   if rep%2:order=list(reversed(order))
   for setting in order:
    shutil.copyfile(bins[setting],active);active.chmod(0o755);ns=execute(active,inp,'/dev/null')
    if rep>=2:raw[setting].append(ns)
  med={s:statistics.median(v) for s,v in raw.items()};ratio={s:v/med['O2'] for s,v in med.items()};row['cases'].append({**case,'full_output':check,'raw_ns':raw,'median_ns':med,'ratio_to_O2':ratio});record.write_text(json.dumps(row,indent=2)+'\n');print(id,case['name'],{s:round(r,4) for s,r in ratio.items()},flush=True)
 row['status']='complete';record.write_text(json.dumps(row,indent=2)+'\n');print('COMPLETE',id,flush=True)
