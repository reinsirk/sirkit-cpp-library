# 最大流

`Graph/Max_Flow.cpp`の`MaxFlow<Capacity>`は、非負整数容量の有向グラフを扱う。Capacityはbool以外の整数型で、既定は`std::int64_t`。`add_edge`は追加順の辺番号を返す。自己辺・多重辺・逆向きの元辺もそのまま追加できる。

`flow(s,t)`は現在の残余グラフへ追加で流せる量を返し、`flow(s,t,limit)`は追加量を制限する。同じ始点・終点で継続できる。戻り値は追加量であり、累積流量ではない。型の最大値を既定limitとするため、真の総流量が型に収まらない場合も複数回に分けて流せる。累積値の保持は利用側で十分に広い型を使う。始点と終点が同じ場合は、このAPIでは0を返す。

BFSで距離を決め、距離が増える残余辺だけを使ってblocking flowを計算するDinic法。DFSの実行状態をvectorのスタックに保存し、再帰しない。一般グラフの最悪O(N²M)時間、グラフと作業領域はO(N+M)。元辺の位置表で`get_edge`・`change_edge`をO(1)、`edges`をO(M)で扱う。

`min_cut(s)`は現在の残余グラフで到達可能な頂点のbool配列を返す。最大流を最後まで流し、tへ到達できない状態なら、この集合がs-t最小カットを与える。limitで途中停止した状態では最小カットとは限らない。

`change_edge(id,capacity,flow)`は指定した元辺だけを書き換える。0≤flow≤capacityが前提で、他の頂点の流量保存を壊さないことは利用側で保証する。たとえば全辺のflowを0へ戻してから再計算できる。コピーは現在の残余状態を独立所有し、ムーブ元は空になる。

入力検査は追加・変更・照会時だけ行い、`SKIP_RUNTIME_CHECKS`で除く。添字上限と残余量・追加量の差の安全な計算は維持する。`flow`の作業スタックの確保は残余更新前に行う。元辺追加の確保失敗でも、途中までの片方向辺を残さない。

[ACLのAPI説明](https://atcoder.github.io/ac-library/production/document_ja/maxflow.html)は問題と理論上の参考であり、再帰実装の転記ではない。[使用例](../Examples/max_flow_example.cpp) · [独立参照](../Verify/current/tests/new_max_flow_reference_test.cpp) · [AtCoder practice2 D](https://atcoder.jp/contests/practice2/tasks/practice2_d)
