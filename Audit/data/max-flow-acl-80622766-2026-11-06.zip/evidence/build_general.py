# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json
D=Path('/tmp/sirkit_maxflow_80622766');rows=[]
for label in ['old','api','early']:
 header=D/('before/Graph/Max_Flow.cpp'if label=='old'else'api_only.hpp'if label=='api'else'early.hpp')
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror','-DSKIP_RUNTIME_CHECKS',f'-DFLOW_SOURCE="{header}"',f'-DFLOW_TYPE={"MaxFlow"if label=="old"else"mf_graph"}',str(D/'general_bench.cpp'),'-o',str(D/f'{cc}_graph_{label}')];subprocess.run(cmd,check=True);rows.append(dict(compiler=cc,label=label,command=cmd));print(cc,label,'ready',flush=True)
(D/'general_builds.json').write_text(json.dumps(rows,indent=2)+'\n')
