// SPDX-License-Identifier: CC0-1.0
#include FLOW_SOURCE
#include "/home/reinsirk/Atcoder_Env/Verify/current/common/fast_io.hpp"
#include <cstdint>
#include <ctime>
#include <cstdio>
#include <vector>
template<class E>std::int64_t cap_of(E e){if constexpr(requires{e.cap;})return e.cap;else return e.capacity;}
int main(){
 int n{},m{},s{},t{};verify_in>>n>>m>>s>>t;FLOW_TYPE<std::int64_t> g(n);
 for(int i=0;i<m;++i){int u{},v{};std::int64_t c{};verify_in>>u>>v>>c;g.add_edge(u,v,c);}
 const auto start=std::clock();const auto value=g.flow(s,t);const auto finish=std::clock();
 const auto edges=g.edges();const auto cut=g.min_cut(s);std::vector<std::int64_t> balance(n);std::int64_t capacity=0;
 for(const auto e:edges){const auto cap=cap_of(e);if(e.flow<0||e.flow>cap)return 2;balance[e.from]-=e.flow;balance[e.to]+=e.flow;if(cut[e.from]&&!cut[e.to])capacity+=cap;}
 if(!cut[s]||cut[t]||capacity!=value)return 3;
 for(int v=0;v<n;++v)if(balance[v]!=(v==s?-value:v==t?value:0))return 4;
 verify_out<<value<<'\n';std::fprintf(stderr,"flow_cpu_ms=%.6f\n",1000.0*static_cast<double>(finish-start)/CLOCKS_PER_SEC);
}
