# SPDX-License-Identifier: CC0-1.0
"""自作最大流の比較入力。外部実装・外部生成器を使わない。"""
from pathlib import Path
from collections import deque
import hashlib
import json
import random

D = Path(__file__).resolve().parent
I = D / 'fixtures' / 'inputs'
I.mkdir(parents=True, exist_ok=True)
ROWS = []
SEED = 20261106080622766

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save_metadata():
    (D / 'fixtures.json').write_text(json.dumps(ROWS, ensure_ascii=False, indent=2) + '\n')
    (D / 'fixtures' / 'fixtures.json').write_text(json.dumps(ROWS, ensure_ascii=False, indent=2) + '\n')

def edmonds_karp(n, edges, source, sink):
    if source == sink:
        return 0
    residual = [[0] * n for _ in range(n)]
    for u, v, cap in edges:
        residual[u][v] += cap
    result = 0
    while True:
        before = [-1] * n
        before[source] = source
        todo = deque([source])
        while todo and before[sink] == -1:
            u = todo.popleft()
            for v, cap in enumerate(residual[u]):
                if cap and before[v] == -1:
                    before[v] = u
                    todo.append(v)
        if before[sink] == -1:
            return result
        amount = None
        v = sink
        while v != source:
            u = before[v]
            amount = residual[u][v] if amount is None else min(amount, residual[u][v])
            v = u
        v = sink
        while v != source:
            u = before[v]
            residual[u][v] -= amount
            residual[v][u] += amount
            v = u
        result += amount

def all_cuts(n, edges, source, sink):
    rest = [v for v in range(n) if v not in (source, sink)]
    best = None
    for mask in range(1 << len(rest)):
        chosen = {source}
        chosen.update(v for k, v in enumerate(rest) if mask >> k & 1)
        value = sum(cap for u, v, cap in edges if u in chosen and v not in chosen)
        best = value if best is None else min(best, value)
    return best

def grid_edges(board):
    height, width = len(board), len(board[0])
    source, sink = height * width, height * width + 1
    edges = []
    for i, row in enumerate(board):
        for j, cell in enumerate(row):
            if cell != '.':
                continue
            v = i * width + j
            if (i + j) & 1:
                edges.append((v, sink, 1))
            else:
                edges.append((source, v, 1))
                for di, dj in [(1, 0), (0, 1), (-1, 0), (0, -1)]:
                    ni, nj = i + di, j + dj
                    if 0 <= ni < height and 0 <= nj < width and board[ni][nj] == '.':
                        edges.append((v, ni * width + nj, 1))
    return sink + 1, edges, source, sink

def add_grid(name, board, expected=None, reference=None, seed=None):
    height, width = len(board), len(board[0])
    assert all(len(row) == width and set(row) <= {'#', '.'} for row in board)
    n, edges, source, sink = grid_edges(board)
    if n <= 70:
        independent = edmonds_karp(n, edges, source, sink)
        assert expected is None or expected == independent
        expected = independent
        reference = 'Independent Edmonds-Karp on a residual capacity matrix, from the grid network'
    path = I / (name + '.in')
    path.write_text(f'{height} {width}\n' + '\n'.join(board) + '\n')
    row = dict(name=name, kind='grid', problem='practice2_d', format='height width, then height grid rows', path=str(path), filename=path.name, height=height, width=width, n=n, m=len(edges), source=source, sink=sink, bytes=path.stat().st_size, sha256=sha(path), seed=seed, expected_flow=expected, reference=reference or 'No independent expected value; compare before/after and validate matching reconstruction', oracle='independent' if reference and 'Independent' in reference else 'known_construction' if expected is not None else 'before_after_only')
    ROWS.append(row)
    save_metadata()
    print(name, 'grid', height, width, 'expected', expected, flush=True)

def add_graph(name, n, edges, source=0, sink=None, expected=None, reference=None, seed=None):
    sink = n - 1 if sink is None else sink
    assert 0 <= source < n and 0 <= sink < n
    assert all(0 <= u < n and 0 <= v < n and 0 <= cap <= (1 << 63) - 1 for u, v, cap in edges)
    source_bound = sum(cap for u, v, cap in edges if u == source and v != source)
    assert source_bound <= (1 << 63) - 1
    if n <= 32:
        independent = edmonds_karp(n, edges, source, sink)
        if n <= 8 and source != sink:
            assert independent == all_cuts(n, edges, source, sink)
        assert expected is None or expected == independent
        expected = independent
        reference = 'Independent Edmonds-Karp residual matrix' + (' and exhaustive cut enumeration' if n <= 8 and source != sink else '')
    path = I / (name + '.in')
    with path.open('w') as f:
        f.write(f'{n} {len(edges)} {source} {sink}\n')
        for u, v, cap in edges:
            f.write(f'{u} {v} {cap}\n')
    row = dict(name=name, kind='graph', problem=None, format='n m source sink, then m lines: from to int64_capacity', path=str(path), filename=path.name, n=n, m=len(edges), source=source, sink=sink, bytes=path.stat().st_size, sha256=sha(path), seed=seed, source_capacity_bound=source_bound, expected_flow=expected, reference=reference or 'No independent expected value; before/after comparison only', oracle='independent' if reference and 'Independent' in reference else 'known_construction' if expected is not None else 'before_after_only')
    ROWS.append(row)
    save_metadata()
    print(name, 'graph', n, len(edges), 'expected', expected, flush=True)

def walls(height, width, percentage, seed):
    rng = random.Random(seed)
    return [''.join('#' if rng.randrange(100) < percentage else '.' for _ in range(width)) for _ in range(height)]

add_grid('grid_official_3x3', ['#..', '..#', '...'], expected=3)
add_grid('grid_open_1x1', ['.'], expected=0, reference='A single cell has no adjacent cell')
add_grid('grid_blocked_1x1', ['#'], expected=0, reference='No usable cell')
add_grid('grid_open_1x100', ['.' * 100], expected=50, reference='A full row has floor(width/2) disjoint adjacent pairs and that is the vertex-count upper bound')
add_grid('grid_random_8x8', walls(8, 8, 35, SEED + 8), seed=SEED + 8)
add_grid('grid_open_100x100', ['.' * 100 for _ in range(100)], expected=5000, reference='Pair horizontal neighboring cells; reaches half the number of cells')
add_grid('grid_checker_blocked_100x100', [''.join('#' if (i + j) & 1 else '.' for j in range(100)) for i in range(100)], expected=0, reference='All usable cells have the same grid parity, so no usable adjacent pair exists')
for p in [10, 35, 65]:
    add_grid(f'grid_random{p}_100x100', walls(100, 100, p, SEED + p), seed=SEED + p)
add_grid('grid_open_300x300', ['.' * 300 for _ in range(300)], expected=45000, reference='Pair horizontal neighboring cells; reaches half the number of cells')
add_grid('grid_random35_300x300', walls(300, 300, 35, SEED + 30035), seed=SEED + 30035)

add_graph('graph_zero_capacity_2', 2, [(0, 1, 0), (0, 0, 13), (1, 1, 17)], expected=0)
add_graph('graph_parallel_reverse_loops_4', 4, [(0, 1, 7), (0, 1, 11), (1, 0, 5), (1, 2, 9), (1, 3, 8), (2, 3, 6), (0, 2, 4), (0, 0, 91), (1, 1, 27), (3, 3, 12), (0, 3, 0)])
large = ((1 << 63) - 1) // 16
add_graph('graph_large_capacities_4', 4, [(0, 1, large), (0, 2, large), (1, 2, 1), (1, 3, large), (2, 3, large), (2, 2, large)])
for n in [2, 8, 24]:
    seed = SEED + 1000 + n
    rng = random.Random(seed)
    capacities = [0, 1, 2, 19, 1000000000000]
    edges = [(rng.randrange(n), rng.randrange(n), rng.choice(capacities)) for _ in range(n * 7)]
    add_graph(f'graph_random_small_{n}', n, edges, seed=seed)

n = 350000
edges = [(v - 1, v, 3) for v in range(1, n)]
for v in range(0, n, 10007):
    edges.append((v, v, 1000000000000))
    if v + 1 < n:
        edges.append((v, v + 1, 0))
add_graph('graph_chain_350000', n, edges, expected=3, reference='The chain supplies a path of capacity 3; its first cut has total capacity 3. Self-loops and zero-capacity parallel arcs do not change it')

n = 100000
capacities = [1, 7, 1000000000000]
for connected in [False, True]:
    edges = []
    expected = 0
    for v in range(1, n - 1):
        c = capacities[v % len(capacities)]
        edges.append((0, v, c))
        if connected:
            edges.append((v, n - 1, c))
            expected += c
    edges += [(0, 0, 17), (n - 1, n - 1, 19), (0, 1, 0)]
    add_graph('graph_star_' + ('connected' if connected else 'unreachable') + '_100000', n, edges, expected=expected, reference='Sum of independent two-edge source-to-sink branches; disconnected variant has no incoming sink arc')

n = 10000
seed = SEED + 2200
rng = random.Random(seed)
edges = [(v - 1, v, rng.choice([1, 17, 1000000000])) for v in range(1, n)]
for _ in range(n * 7):
    u = rng.randrange(n - 1)
    v = rng.randrange(u + 1, n)
    edges.append((u, v, rng.choice([0, 1, 13, 1000000000000])))
add_graph('graph_random_dag_10000', n, edges, seed=seed)

n = 300
seed = SEED + 2300
rng = random.Random(seed)
edges = []
for u in range(n):
    for v in range(n):
        if rng.randrange(3) == 0:
            edges.append((u, v, rng.choice([0, 1, 3, 77, 1000000000000])))
for _ in range(100):
    u, v = rng.randrange(n), rng.randrange(n)
    edges.append((u, v, rng.choice([0, 1, 1000000000000])))
add_graph('graph_dense_directed_300', n, edges, seed=seed)

width, layers = 100, 100
n = width * layers + 2
sink = n - 1
seed = SEED + 2400
rng = random.Random(seed)
edges = [(0, 1 + j, 1) for j in range(width)]
edges += [(1 + (layers - 1) * width + j, sink, 1) for j in range(width)]
for layer in range(layers - 1):
    for j in range(width):
        u = 1 + layer * width + j
        edges.append((u, 1 + (layer + 1) * width + j, 1))
        for _ in range(3):
            k = rng.randrange(width)
            edges.append((u, 1 + (layer + 1) * width + k, rng.choice([0, 1, 9, 1000000000000])))
add_graph('graph_layered_10002', n, edges, expected=width, reference='100 disjoint straight columns each carry 1, and the source cut has capacity 100', seed=seed)

n = 10000
seed = SEED + 2500
rng = random.Random(seed)
edges = [(v - 1, v, 1 + v % 29) for v in range(1, n - 1)]
for _ in range(3 * n):
    u, v = rng.randrange(n - 1), rng.randrange(n - 1)
    edges.append((u, v, rng.choice([0, 1, 1000000000000])))
add_graph('graph_unreachable_sink_10000', n, edges, expected=0, reference='The sink is isolated; every other vertex is connected to the source by the positive chain', seed=seed)

n = 100000
edges = [(0, 1, 7)] + [(0, v, 1000000000000) for v in range(2, n)]
edges += [(v, v + 1, 1) for v in range(2, n - 1)]
edges += [(n - 1, n - 1, 1000000000000), (0, 1, 0)]
add_graph('graph_close_sink_large_branches_100000', n, edges, sink=1, expected=7, reference='The only positive incoming sink arc is the direct edge of capacity 7; it realizes that upper bound')

assert len({r['name'] for r in ROWS}) == len(ROWS)
assert all(Path(r['path']).stat().st_size == r['bytes'] and sha(Path(r['path'])) == r['sha256'] for r in ROWS)
metadata = dict(seed=SEED, provenance='Independently written input generator and Edmonds-Karp/all-cut references; no external library or generator source', fixture_count=len(ROWS), grids=sum(r['kind'] == 'grid' for r in ROWS), graphs=sum(r['kind'] == 'graph' for r in ROWS), independent=sum(r['oracle'] == 'independent' for r in ROWS), known_construction=sum(r['oracle'] == 'known_construction' for r in ROWS), before_after_only=sum(r['oracle'] == 'before_after_only' for r in ROWS), total_bytes=sum(r['bytes'] for r in ROWS))
(D / 'fixtures' / 'generation.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(metadata, ensure_ascii=False), flush=True)
