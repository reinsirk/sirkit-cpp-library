# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,subprocess,json,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_maxflow_80622766');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as p;e=next(x for x in p.collect()if x['id']=='max_flow_grid');rows=[]
for label in ['old','api','early']:
 header=D/('before/Graph/Max_Flow.cpp'if label=='old'else'api_only.hpp'if label=='api'else'early.hpp');driver=(D/'before/Verify/current/drivers/max_flow_grid_main.cpp').read_text()if label=='old'else(R/e['driver']).read_text();data,_=p.render(e,source_overrides={'Graph/Max_Flow.cpp':header.read_bytes()},driver_override=driver);src=D/f'grid_{label}.cpp';src.write_bytes(data)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  exe=D/f'{cc}_grid_{label}';cmd=['taskset','-c','4',*args,'-std=c++23','-O2',str(src),'-o',str(exe)];subprocess.run(cmd,check=True)
  for sample in e['samples']:
   r=subprocess.run([str(exe)],input=sample['input'],text=True,capture_output=True);assert r.returncode==0 and not r.stderr and p.matches(e,sample,r.stdout),(label,r.stdout,r.stderr)
  rows.append(dict(label=label,compiler=cc,command=cmd,source_sha256=hashlib.sha256(data).hexdigest()));print(cc,label,'sample PASS',flush=True)
(D/'builds.json').write_text(json.dumps(rows,indent=2)+'\n')
