# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,sys,subprocess,hashlib,re
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_maxflow_80622766');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();strip=lambda s:'\n'.join(x for x in s.splitlines()if not x.lstrip().startswith('//'))
tested=(D/'early.hpp').read_text().replace('型の最大値/指定上限','型の最大値/非負の指定上限');(D/'tested.hpp').write_text(tested);rows=json.loads((D/'tests.json').read_text());assert len(rows)==10;assert {x['library_sha256']for x in rows}=={sha(D/'tested.hpp')};assert strip(tested)==strip((R/'Graph/Max_Flow.cpp').read_text());assert strip((D/'early.hpp').read_text())==strip((R/'Graph/Max_Flow.cpp').read_text())
old=(D/'before/Verify/current/drivers/max_flow_grid_main.cpp').read_text();assert old.replace('MaxFlow<int>','mf_graph<int>')==(R/'Verify/current/drivers/max_flow_grid_main.cpp').read_text();assert(R/'Verify/current/common/fast_io.hpp').read_bytes()==(D/'before/Verify/current/common/fast_io.hpp').read_bytes()
sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv;e=next(x for x in pv.collect()if x['id']=='max_flow_grid');data,_=pv.render(e);src=D/'final_grid.cpp';src.write_bytes(data);checks=[]
for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 exe=D/f'{cc}_final_grid';cmd=['taskset','-c','6',*args,'-std=c++23','-O2',str(src),'-o',str(exe)];subprocess.run(cmd,check=True);blobs=[]
 for binary in [D/f'{cc}_grid_early',exe]:
  section=binary.with_suffix('.final.text');subprocess.run(['objcopy','--dump-section',f'.text={section}',str(binary)],check=True);blobs.append(section.read_bytes())
 assert blobs[0]==blobs[1],cc
 for sample in e['samples']:
  r=subprocess.run([str(exe)],input=sample['input'],text=True,capture_output=True);assert r.returncode==0 and not r.stderr and pv.matches(e,sample,r.stdout)
 checks.append(dict(compiler=cc,scope='actual frozen grid main except class-name replacement',command=cmd,text_matches_measured=True,text_sha256=hashlib.sha256(blobs[0]).hexdigest(),samples_pass=True))
 example=R/'Examples/max_flow_example.cpp';prog=D/f'{cc}_example';cmd=['taskset','-c','6',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(example),'-o',str(prog)];subprocess.run(cmd,check=True);r=subprocess.run([str(prog)],text=True,capture_output=True);assert r.returncode==0 and not r.stderr and r.stdout=='5\n';checks.append(dict(compiler=cc,scope='example',command=cmd,stdout=r.stdout))
 prog=D/f'{cc}_standard_api';cmd=['taskset','-c','6',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror','-pedantic-errors','-U__SIZEOF_INT128__',str(R/'Verify/current/tests/max_flow_acl_api_test.cpp'),'-o',str(prog)];subprocess.run(cmd,check=True);r=subprocess.run([str(prog)],text=True,capture_output=True);assert r.returncode==0 and not r.stderr;checks.append(dict(compiler=cc,scope='strict standard C++23',command=cmd,stdout=r.stdout));print(cc,'final frozen main/sample/example/strict standard passed',flush=True)
(D/'final_checks.json').write_text(json.dumps(checks,indent=2)+'\n');(D/'source_proofs.json').write_text(json.dumps(dict(canonical_sha256=sha(R/'Graph/Max_Flow.cpp'),measured_candidate_sha256=sha(D/'early.hpp'),tested_sha256=sha(D/'tested.hpp'),source_delta='API説明コメントのみ。最終の実行コードは計測済み候補とbyte一致。',driver_change='型名MaxFlow<int>をmf_graph<int>へ1箇所だけ置換。その他byte一致。',io_sha256=sha(R/'Verify/current/common/fast_io.hpp'),io_unchanged=True),ensure_ascii=False,indent=2)+'\n')
