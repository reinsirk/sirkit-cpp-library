# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,datetime,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_sparse_followup_20261103')
a=json.loads((D/'414928.json').read_text());p=R/'Verify/current/submissions/sparse_table.cpp';s=a['source']
def norm(s):return '\n'.join(x.rstrip() for x in s.splitlines() if x.strip() and not x.startswith('// Submission:'))
assert norm(s)==norm(p.read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
o=a['overview'];record={'id':'sparse_table','status':o['status'],'url':'https://judge.yosupo.jp/submission/414928','time_ms':round(o['time']*1000),'memory_bytes':o['memory'],'submission_time':o['submission_time'],'language':o['lang'],'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'case_results':a['case_results'],'submission_sha256':sha(p.read_bytes()),'uploaded_source_sha256':sha(s.encode()),'source_hashes':{'DataStructure/Sparse_Table.cpp':sha((R/'DataStructure/Sparse_Table.cpp').read_bytes())},'driver_sha256':sha((R/'Verify/current/drivers/sparse_table_main.cpp').read_bytes()),'io_source_hashes':{'Verify/current/common/fast_io.hpp':sha((R/'Verify/current/common/fast_io.hpp').read_bytes())},'io_mode':'shared_fast_io','matched_current_generation':True,'needs_resubmission':False,'source_match':'改行・空行・行末空白・Submission注記を除いて本体・main・共通I/Oが現行版と一致。','evidence_file':'Audit/online-sparse-table-414928-2026-11-03.json'}
assert o['status']=='AC'
old=json.loads((R/'Audit/online-sparse-table-414927-2026-11-03.json').read_text())['record'];oldcases={c['case']:c for c in old['case_results']}
comp={'previous':old['url'],'current':record['url'],'old_ms':old['time_ms'],'new_ms':record['time_ms'],'reduction_percent':100*(1-record['time_ms']/old['time_ms']),'case_results':[{'case':c['case'],'old_ms':round(oldcases[c['case']]['time']*1000),'new_ms':round(c['time']*1000)} for c in a['case_results']],'scope':'同じmainと共通I/O。オンライン各1回の値であり環境揺らぎを含む。'}
report={'scope':'通常版SparseTableの現行AVX2構築経路を含む本体に対応するオンラインAC。派生版のACとはしない。','endpoint':'https://v3.api.judge.yosupo.jp/submissions/414928','record':record,'comparison':comp}
(R/record['evidence_file']).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
jp=R/'Verify/current/judgements.json';j=json.loads(jp.read_text());records=[x for x in j['entries'] if x.get('id')=='sparse_table'];assert len(records)==1
j['entries']=[record if x.get('id')=='sparse_table' else x for x in j['entries']];jp.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(R/'Audit/data/sparse-table-online-414928-2026-11-03.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.write(D/'414928.json','public_api_response.json');z.write(D/'uploaded.cpp','uploaded.cpp')
print('AC',record['time_ms'],'reduction_percent',comp['reduction_percent'],'matches_current',True)
