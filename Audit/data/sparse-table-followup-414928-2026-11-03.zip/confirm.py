# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,random,statistics,shutil,os,time,json,hashlib,fcntl
D=Path('/tmp/sirkit_sparse_followup_20261103');P=Path('/tmp/sirkit_sparse_speed_20261103')
cases=['official_max_random_'+str(i) for i in range(5)]+['official_small_width_query_'+str(i) for i in range(5)]+['official_random_2','official_small_values_0','32_build','4096_build','500000_build']
rng=random.Random(88210);raw=[]
with open('/tmp/sirkit_performance_cpu12.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for case in cases:
   inp=P/((case if case.startswith('official') else 'input_'+case)+'.in')
   for rep in range(11):
    order=['base','control','unroll_attr','hoist'];rng.shuffle(order)
    for label in order:
     shutil.copyfile(D/f'{cc}_{"base" if label=="control" else label}',D/'active');(D/'active').chmod(0o700)
     with inp.open('rb') as fi,(D/'output').open('wb') as fo:
      st=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,status,r=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status);assert p.returncode==0
      cpu=round((r.ru_utime+r.ru_stime)*1e9);wall=time.perf_counter_ns()-st
     raw.append(dict(compiler=cc,case=case,rep=rep,label=label,cpu_ns=cpu,wall_ns=wall,sha256=hashlib.sha256((D/'output').read_bytes()).hexdigest()))
   rows=[x for x in raw if x['compiler']==cc and x['case']==case];assert len({x['sha256'] for x in rows})==1
   m={l:statistics.median(x['cpu_ns'] for x in rows if x['label']==l) for l in order};print(cc,case,{k:round(val/m['base'],4) for k,val in m.items()},flush=True)
   (D/'confirm_raw.json').write_text(json.dumps(raw))
