# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,statistics,hashlib,datetime,subprocess,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_sparse_followup_20261103');P=Path('/tmp/sirkit_sparse_speed_20261103')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
host={}
for label,cmd in [('cpu',['lscpu','-J']),('topology',['lscpu','-e=CPU,CORE,MAXMHZ,MINMHZ,ONLINE']),('gcc',['/usr/bin/g++','--version']),('clang',['/usr/bin/clang++','--version'])]:
 p=subprocess.run(cmd,capture_output=True,text=True,check=True);host[label]={'command':cmd,'stdout':p.stdout}
host['sysfs_core_id']=(Path('/sys/devices/system/cpu/cpu12/topology/core_id')).read_text().strip()
host['siblings']=Path('/sys/devices/system/cpu/cpu12/topology/thread_siblings_list').read_text().strip()
host['governor']=Path('/sys/devices/system/cpu/cpu12/cpufreq/scaling_governor').read_text().strip()
(D/'host.json').write_text(json.dumps(host,ensure_ascii=False,indent=2)+'\n')
summary={}
for phase,count in [('screen',630),('confirm',1320)]:
 a=json.loads((D/(phase+'_raw.json')).read_text());assert len(a)==count
 out=[]
 for cc in ['gcc','clang']:
  for case in sorted({x['case'] for x in a}):
   rs=[x for x in a if x['compiler']==cc and x['case']==case];assert len({x['sha256'] for x in rs})==1
   med={label:statistics.median(x['cpu_ns'] for x in rs if x['label']==label) for label in sorted({x['label'] for x in rs})}
   out.append({'compiler':cc,'case':case,'median_process_cpu_ms':{k:v/1e6 for k,v in med.items()},'over_base':{k:v/med['base'] for k,v in med.items()},'output_sha256':rs[0]['sha256']})
 summary[phase]=out
source=R/'DataStructure/Sparse_Table.cpp';assert source.read_bytes()==(D/'base.hpp').read_bytes()
frozen={'library_sha256':sha(source),'driver_sha256':sha(R/'Verify/current/drivers/sparse_table_main.cpp'),'io_sha256':sha(R/'Verify/current/common/fast_io.hpp')}
assert frozen['library_sha256']=='5fe4f399b54ad43af1c74f3db9682ea1be1b90495441665fe11bf8ad8e62929a'
assert frozen['driver_sha256']=='6601da375131716c6d0f278d95c6ed17b3d4191bf4edc3aca9aeedfdb8be87e5'
assert frozen['io_sha256']=='291bf8dbc56a1d691f6256fe95b4714183c2cf5d9e55e4bef240e31d1eb178c1'
e=R/'Audit/data/sparse-table-followup-414928-2026-11-03.zip'
with zipfile.ZipFile(e,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(D.iterdir()):
  if p.is_file() and p.suffix in {'.py','.hpp','.cpp','.json','.log','.stderr'}:z.write(p,p.name)
 z.write(P/'official_metadata.json','inputs_metadata.json')
report={
 'date_jst':'2026-11-03','decision':'提出414928の本体を維持。追加候補は採用しない。再提出不要。',
 'online_evidence':'online-sparse-table-414928-2026-11-03.json',
 'online':{'previous_url':'https://judge.yosupo.jp/submission/414927','previous_ms':75,'url':'https://judge.yosupo.jp/submission/414928','status':'AC','time_ms':63,'reduction_percent':16,'source_match':'改行・空行・行末空白・Submission注記以外、本体・main・共通IOが現行版と一致。','scope':'各1回のオンライン測定。CPU/測定揺らぎを含み、16%全てを命令単独の効果とはしない。'},
 'unchanged':frozen,
 'benchmark':{'host':'Intel Core i9-14900K','performance_cpu':12,'core_kind':'P-Core','lscpu_core_index':6,'kernel_core_id':host['sysfs_core_id'],'sibling_logical_cpu':13,'flags':['-std=c++23','-O2'],'march_native':False,'clang_extra':'--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','checks':'SKIP_RUNTIME_CHECKS','governor':'powersave','frequency_fixed':False,'metric':'プロセス全体のuser+system CPU時間。wallも保存。main・IO固定、実行ファイル名を統一して同一P-Coreへ固定。','control':'baseと同じバイナリを別ラベルで実行。','order':'反復ごとにラベル順を混ぜる。screen seed828310、confirm seed88210。','screen_runs':630,'screen_repetitions':7,'confirm_runs':1320,'confirm_repetitions':11,'scope':'公式生成器の既存入力と自作入力を再利用。出力SHAは全ラベル・反復で一致。小規模プロセスは起動/I/O比が高いため構築単体時間とは扱わない。','interference':'CPU12を使用する他の性能測定は行わず、ベンチマーク中のコンパイルなし。confirm中に小さいJSON/Verifyメタデータ生成処理が約1秒重なった。同一版controlと反復間の揺らぎを併記し、細かい差を採用根拠にしない。'},
 'candidate_notes':{
 'unroll2/unroll4/unroll8':'AVX2の行結合ループにGCC unroll pragma。一部GCCケースは速いがClang構築で約3〜8%退行。採用しない。',
 'unroll_attr':'GCC専用関数にO3とunroll-loops。caseごとに符号が異なり、再測定のGCC random_02で約2.5%遅い。採用しない。',
 'hoist':'CPU判定をループ前に1回へ移す。反復を増やしても安定した上積みがなく、Clang random_02約2.3%遅い。採用しない。候補のuse_simdはSIMD除外時にも残るため、仮に採用するなら宣言も同じ#ifで囲む必要がある。',
 'hoist_unroll4':'上記2案の組合せ。Clangの大規模構築で退行し採用しない。',
 'countl':'bit_widthの式をcountl_zeroに置換。Clangで退行。候補sizeof(size_t)*8は8bit byteを仮定するため標準経路に不適切。仮に採用するならnumeric_limits<size_t>::digitsを使う必要がある。'},
 'results':summary,
 'review':'別エージェントによる読み取りレビュー。hoistのn>=257はcount>=256と同値。Op順序・回数、型要件、容量計算、所有権は維持。未使用状態の除外とcountlのbit幅表現について上記注意。性能測定・ソース編集は委任しない。',
 'validation':'本体・main・共通IOに変更なし。現行ハッシュのオンラインAC確認を記録。実験候補は測定用だけであり本体へ反映しない。既存の単体・型・所有権・SIMD有無の検証はperformance-sparse-table-avx2-build-2026-11-03.json。',
 'evidence':{'file':'data/'+e.name,'sha256':sha(e),'bytes':e.stat().st_size,'scope':'自作の比較ソース・スクリプト・測定・公開提出情報を保存。バイナリ・大きい入力・公式生成器ソースは含めない。'},
 'resubmit':[]}
p=R/'Audit/performance-sparse-table-followup-414928-2026-11-03.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('audit',p.name,'evidence_bytes',e.stat().st_size,'no_library_changes',True)
