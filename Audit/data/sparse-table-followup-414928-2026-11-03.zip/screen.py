# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,subprocess,random,statistics,shutil,os,time,json,hashlib,fcntl
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_sparse_followup_20261103');P=Path('/tmp/sirkit_sparse_speed_20261103')
sys.path.insert(0,str(R/'Scripts'));import prepare_verify
s=(R/'DataStructure/Sparse_Table.cpp').read_text();v={'base':s}
loop='        for (std::size_t i = 0; i < count; ++i) target[i] = T(op(left[i], right[i]));'
assert loop in s
for k in [2,4,8]:v['unroll'+str(k)]=s.replace(loop,'#pragma GCC unroll '+str(k)+'\n'+loop)
v['unroll_attr']=s.replace('gnu::optimize("O3")','gnu::optimize("O3", "unroll-loops")')
guard='#if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__i386__) || defined(__x86_64__))'
typeexpr='''            using Result = decltype(op_(std::declval<const std::vector<T>&>()[std::size_t{}],
                                        std::declval<const std::vector<T>&>()[std::size_t{}]));
            if constexpr (std::is_integral_v<T> && !std::is_same_v<T, bool> && sizeof(T) <= 4 &&
                          std::is_same_v<std::remove_cvref_t<Result>, T>) {'''
assert typeexpr in s
pref='''        bool use_simd = false;
'''+guard+'\n'+typeexpr.replace('            ','        ',1)+'''
                use_simd = n >= 257 && supports_avx2();
            }
#endif
'''
h=s.replace('        for (std::size_t width = 2; width <= n;) {',pref+'        for (std::size_t width = 2; width <= n;) {').replace('if (count >= 256 && supports_avx2())','if (use_simd && count >= 256)')
v['hoist']=h
v['hoist_unroll4']=h.replace(loop,'#pragma GCC unroll 4\n'+loop)
v['countl']=s.replace('const auto k = std::bit_width(r - l) - 1;', 'const auto k = sizeof(std::size_t) * 8 - 1 - std::countl_zero(r - l);')
e=next(e for e in prepare_verify.collect() if e['id']=='sparse_table')
for label,src in v.items():
 (D/f'{label}.hpp').write_text(src);data,_=prepare_verify.render(e,source_overrides={'DataStructure/Sparse_Table.cpp':src.encode()});(D/f'{label}.cpp').write_bytes(data)
 for cc,cmd in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  q=subprocess.run(['taskset','-c','2',*cmd,'-std=c++23','-O2',str(D/f'{label}.cpp'),'-o',str(D/f'{cc}_{label}')],capture_output=True,text=True);assert q.returncode==0,q.stderr
  if q.stderr:print('compile',cc,label,q.stderr[:250])
print('BUILT',flush=True)
cases=['official_max_random_0','official_small_width_query_0','official_small_width_query_3','4096_random','500000_build']
rng=random.Random(828310);raw=[]
with open('/tmp/sirkit_performance_cpu12.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for case in cases:
   inp=P/((case if case.startswith('official') else 'input_'+case)+'.in')
   for rep in range(7):
    order=list(v)+['control'];rng.shuffle(order)
    for label in order:
     shutil.copyfile(D/f'{cc}_{"base" if label=="control" else label}',D/'active');(D/'active').chmod(0o700)
     with inp.open('rb') as fi,(D/'output').open('wb') as fo:
      st=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,status,r=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status);assert p.returncode==0
      cpu=round((r.ru_utime+r.ru_stime)*1e9);wall=time.perf_counter_ns()-st
     raw.append(dict(compiler=cc,case=case,rep=rep,label=label,cpu_ns=cpu,wall_ns=wall,sha256=hashlib.sha256((D/'output').read_bytes()).hexdigest()))
   rows=[x for x in raw if x['compiler']==cc and x['case']==case];assert len({x['sha256'] for x in rows})==1
   m={l:statistics.median(x['cpu_ns'] for x in rows if x['label']==l) for l in order};print(cc,case,{k:round(val/m['base'],4) for k,val in m.items()},flush=True)
   (D/'screen_raw.json').write_text(json.dumps(raw))
