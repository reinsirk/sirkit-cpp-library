# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,hashlib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_owned_20261104/performance');rows=[]
s=(R/'Graph/Heavy_Light_Decomposition.cpp').read_bytes();assert s==(D/'current_ctorfix.hpp').read_bytes()
for cc in ['gcc','clang']:
 for backend in ['bit','seg']:
  hashes=[]
  for label in ['owned','ctorfix']:
   exe=D/f'{cc}_{backend}_{label}';obj=D/f'{cc}_{backend}_{label}.text';subprocess.run(['objcopy','--dump-section',f'.text={obj}',str(exe)],check=True);hashes.append(hashlib.sha256(obj.read_bytes()).hexdigest())
  assert hashes[0]==hashes[1],(cc,backend)
  rows.append(dict(compiler=cc,backend=backend,source_sha256=hashlib.sha256(s).hexdigest(),original_bench_program_sha256=hashlib.sha256((D/'bench_owned.cpp').read_bytes()).hexdigest(),final_bench_program_sha256=hashlib.sha256((D/'bench_ctorfix.cpp').read_bytes()).hexdigest(),original_text_sha256=hashes[0],final_text_sha256=hashes[1],exact_text_match=True,benchmark_label='owned'))
(D/'final_benchmark_mapping.json').write_text(json.dumps(rows,indent=2)+'\n');print('All4final owner GCC/Clang BIT/Segtree .text match measured owned binaries')
