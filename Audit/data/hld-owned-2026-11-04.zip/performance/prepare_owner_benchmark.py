# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_owned_20261104/performance');B=D.parent/'before'
sha=lambda b:hashlib.sha256(b).hexdigest()
common=r'''
#include <cstdint>
#include <vector>
std::int64_t combine_sum(std::int64_t a,std::int64_t b){return a+b;}
std::int64_t empty_sum(){return 0;}
#ifdef BENCH_SEG
using Range=segtree<std::int64_t,combine_sum,empty_sum>;
#else
using Range=fenwick_tree<std::int64_t>;
#endif
#ifdef BENCH_OWNER
using BenchTree=HeavyLightValues<Range>;
#else
struct BenchTree{
 HeavyLightDecomposition layout;
 Range range;
 BenchTree(const Graph& graph,const std::vector<std::int64_t>& values):layout(graph),range(layout.reorder(values)){}
 std::int64_t get(int v){return range.get(layout.index(v));}
 void set(int v,std::int64_t x){range.set(layout.index(v),x);}
 std::int64_t path_prod(int u,int v){return layout.path_prod(u,v,range);}
};
#endif
int main(){
 int n{},q{};verify_in>>n>>q;std::vector<std::int64_t> values(n);for(auto& x:values)verify_in>>x;Graph graph(n);
 for(int i=1;i<n;++i){int u{},v{};verify_in>>u>>v;graph[u].push_back(v);graph[v].push_back(u);}
 BenchTree tree(graph,values);
 while(q--){int type{};verify_in>>type;if(type==0){int v{};std::int64_t delta{};verify_in>>v>>delta;tree.set(v,tree.get(v)+delta);}else{int u{},v{};verify_in>>u>>v;verify_out<<tree.path_prod(u,v)<<'\n';}}
}
'''
rows=[]
for label in ['separated','owned']:
 root=B if label=='separated'else R
 core=(root/'Graph/Heavy_Light_Decomposition.cpp').read_bytes()
 src=D/f'bench_{label}.cpp';src.write_text('#define SKIP_RUNTIME_CHECKS\n'+core.decode()+'\n'+(B/'DataStructure/Fenwick_Tree.cpp').read_text()+'\n'+(B/'DataStructure/Segment_Tree.cpp').read_text()+'\n'+(B/'Verify/current/common/fast_io.hpp').read_text()+'\n'+common)
 for cc,prefix in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for backend in ['bit','seg']:
   exe=D/f'{cc}_{backend}_{label}';cmd=['taskset','-c','4',*prefix,'-std=c++23','-O2','-Wall','-Wextra','-Werror'];cmd+=['-DBENCH_OWNER']if label=='owned'else[];cmd+=['-DBENCH_SEG']if backend=='seg'else[];cmd+=[str(src),'-o',str(exe)];subprocess.run(cmd,check=True);obj=D/f'{cc}_{backend}_{label}.text';subprocess.run(['objcopy','--dump-section',f'.text={obj}',str(exe)],check=True);rows.append(dict(label=label,compiler=cc,backend=backend,compile_command=cmd,source_sha256=sha(core),program_sha256=sha(src.read_bytes()),text_sha256=sha(obj.read_bytes())))
(D/'owner_benchmark_builds.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Owner and separated benchmark binaries built',flush=True)
