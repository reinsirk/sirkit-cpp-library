#define SKIP_RUNTIME_CHECKS
// SPDX-License-Identifier: CC0-1.0
// 参考（重軽分解の理論）: https://info.atcoder.jp/entry/algorithm_lectures/heavy_light_decomposition
// 参考（API設計）: https://ei1333.github.io/library/graph/tree/heavy-light-decomposition.hpp.html
// https://github.com/hitonanode/cplib-cpp/blob/master/tree/heavy_light_decomposition.hpp
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/heavy_light_decomposition.md
//
// API一覧
// [値を持つHLD: HeavyLightValues<Range,Ordered=false>]
// with_values<Range,Ordered>(values): 頂点番号順のvectorから分解と集計器を独立所有するHLDを返す。
// 一時HLDなら分解を移動、既存HLDならコピー。RangeはBIT/ACL形式Segtree/Lazy。値の型はRangeから推論。
// HeavyLightValues(g,values,root=0)/build(g,values,root=0): 分解と値を同時に構築/再構築。失敗時は元を保持。
// 構築は分解O(N+M)+集計器のvector構築。vector構築なしのBITはN回add。所有状態を1回確保する。
// get(v)/set(v,x)/add(v,x): 頂点番号で取得/代入/加算。addは対応BITのみ。通常の集計器ではO(log N)。
// apply(v,f)/path_apply(u,v,f,edges=false)/subtree_apply(v,f,edges=false): 点/経路/部分木へ作用。
// path_prod(u,v,edges=false)/subtree_prod(v,edges=false): 所有集計器で経路/部分木を集計。通常O(log²N)/O(log N)。
// Ordered=falseは可換専用。trueは逆順用も所有し、非可換でも通行順に集計。領域と各更新は集計器2本分。
// values(): 元の頂点順へ復元。Range.valuesがあればO(N)の並べ直し、なければN回点照会。
// clear()/swap(other): 空へ/交換。コピーは独立、move元は空。build/コピー失敗時は元を保持。
// 分解情報・reorder/restore/for_each_path/pathも同名で取得可能。対応applyを持つRangeでのみ作用APIを使用できる。
// 値の更新中の例外では変更は巻き戻さない。Ordered=trueでは例外後にclear/buildで再構築すること。
// [分解だけを持つHLD: HeavyLightDecomposition]
// HeavyLightDecomposition(g,root=0)/build(g,root=0): 無向森を反復DFSで分解。O(n+m)時間・領域。
// 頂点番号[0,n)。隣接リストの対称性は前提。rootの木から、残りは最小未訪問頂点から構築する。
// 失敗時は元を保持。空のgにはroot=0。閉路・自己辺・多重辺は検査有効時に例外。
// size()/empty()/root()/component_count(): 頂点数/空か/指定根（空なら-1）/木の数。O(1)。
// parent(v)/depth(v)/component(v)/root_of(v): 親（根は-1）/深さ/木の番号/木の根。O(1)。
// index(v)/vertex_at(i)/order(): heavy優先DFS添字/対応頂点/順序配列へのconst参照。O(1)。
// same_component(u,v)/is_ancestor(u,v): 同じ木か/祖先か（自身を含む）。O(1)。
// subtree_range(v,edges=false): 部分木の半開区間。edges=trueは根vを除き子側の頂点で辺を表す。O(1)。
// subtree_size(v): 部分木の頂点数。O(1)。lca(u,v)/distance(u,v): LCA/辺数、異なる木は-1。O(log n)。
// kth_ancestor(v,k): k個上の頂点。k<0/根を越すと-1。jump(u,v,k): u→vのk番目、範囲外/異なる木は-1。O(log n)。
// for_each_path(u,v,fn,edges=false): 通行順にfn(left,right,reversed)を呼ぶ。接続ならtrue、異なる木はfalse。
// reversed=trueはright-1からleftへ読む。区間は半開。edges=trueはLCAを除く。O(log n)、ヒープ確保なし。
// path(u,v,edges=false): 同じ順序のInterval{left,right,reversed}配列を返す。異なる木は空。O(log n)時間・領域。
// clear()/swap(other): 空に戻す/O(1)交換。コピーは独立所有、ムーブ元は空。検査はSKIP_RUNTIME_CHECKSで除く。
// reorder(values)/restore(ordered): 長さNのvectorをDFS添字順/元の頂点順へコピー。O(N)時間・領域。
// path_prod(u,v,bit,edges=false): sumを持つBITの和。単位元はT{}、整数は型幅で周回。O(log N)回照会。
// path_prod(u,v,seg,edges=false): ACL形式のSegtreeからop/eを推論した可換積。Segはconst可、Lazyは非const。
// path_prod(u,v,identity,query,op,edges=false): queryはprod/sum、2引数関数なら可換、3引数(l,r,reversed)なら向き対応。
// path_prod(u,v,seg,reverse,edges=false)/汎用版のop直後にreverse指定: 正しい逆順集約を返す非可換積。
// subtree_prod(v,query,edges=false): 部分木のDFS添字昇順の積。区間照会1回。非可換も可。
// path_apply(u,v,range,f,edges=false)/subtree_apply(v,range,f,edges=false): range.apply(l,r,f)で更新。O(log N)/1回。
// prod/applyのrangeは同じDFS添字順で用意する。path_prod/path_applyは同じ木が前提、検査時は別木を例外。

#include <algorithm>
#include <array>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <memory>
#include <optional>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

#ifndef SIRKIT_UNWEIGHTED_GRAPH_DEFINED
#define SIRKIT_UNWEIGHTED_GRAPH_DEFINED
using Graph = std::vector<std::vector<int>>;
#endif

#ifndef SIRKIT_HLD_QUERY_HELPERS_DEFINED
#define SIRKIT_HLD_QUERY_HELPERS_DEFINED
namespace reinsirk::detail {
template<class Q>
concept HldRangeQuery = requires(Q& q) { q.prod(0, 0); }
    || requires(Q& q) { q.sum(0, 0); }
    || std::is_invocable_v<Q&, int, int, bool> || std::is_invocable_v<Q&, int, int>;
template<class Q>
inline constexpr bool hld_directional_query = !requires(Q& q) { q.prod(0, 0); }
    && !requires(Q& q) { q.sum(0, 0); } && std::is_invocable_v<Q&, int, int, bool>;
template<HldRangeQuery Q>
decltype(auto) hld_read_range(Q& query, int l, int r, bool reversed) {
    if constexpr (requires { query.prod(l, r); }) return query.prod(l, r);
    else if constexpr (requires { query.sum(l, r); }) return query.sum(l, r);
    else if constexpr (hld_directional_query<Q>) return std::invoke(query, l, r, reversed);
    else return std::invoke(query, l, r);
}
template<HldRangeQuery Q>
using HldRangeValue = std::remove_cvref_t<decltype(hld_read_range(std::declval<Q&>(), 0, 0, false))>;
struct HldAddition {
    template<class T> T operator()(T a, T b) const {
#if defined(__SIZEOF_INT128__) && (defined(__GNUC__) || defined(__clang__))
        if constexpr (std::is_same_v<T, __int128> || std::is_same_v<T, unsigned __int128>)
            return static_cast<T>(static_cast<unsigned __int128>(a) + static_cast<unsigned __int128>(b));
        else
#endif
        if constexpr (std::is_integral_v<T> && !std::is_same_v<T, bool>) {
            using U = std::make_unsigned_t<T>;
            return static_cast<T>(static_cast<U>(a) + static_cast<U>(b));
        } else return a + b;
    }
};
}
#endif

#ifndef SIRKIT_HEAVY_LIGHT_VALUES_FORWARD_DEFINED
#define SIRKIT_HEAVY_LIGHT_VALUES_FORWARD_DEFINED
template<class Range, bool Ordered = false> class HeavyLightValues;
#endif

#ifndef SIRKIT_HEAVY_LIGHT_DECOMPOSITION_DEFINED
#define SIRKIT_HEAVY_LIGHT_DECOMPOSITION_DEFINED
class HeavyLightDecomposition {
public:
    struct Interval { int left; int right; bool reversed; };
private:
    int root_ = -1;
    std::vector<int> parent_, depth_, component_, roots_, subtree_, heavy_, head_, index_, order_;
#ifndef SKIP_RUNTIME_CHECKS
    void vertex(int v) const {
        if (v < 0 || v >= size()) throw std::out_of_range("HLD: vertex out of range");
    }
#endif
    void prepare(const Graph& graph, int root) {
        if (graph.size() > static_cast<std::size_t>(std::numeric_limits<int>::max()))
            throw std::length_error("HLD: too many vertices");
        const int n = static_cast<int>(graph.size());
#ifndef SKIP_RUNTIME_CHECKS
        if ((n == 0 && root != 0) || (n != 0 && (root < 0 || root >= n)))
            throw std::out_of_range("HLD: root out of range");
#endif
        if (n == 0) return;
        root_ = root;
        parent_.assign(n, -2); depth_.resize(n); component_.resize(n); subtree_.assign(n, 1);
        heavy_.assign(n, -1); head_.resize(n); index_.resize(n); order_.resize(n);
        std::vector<int> stack;
        stack.reserve(n);
        // 部分木集計まではorder_を探索順の保存に使う。
        std::size_t visited_count = 0;
        const auto discover = [&](int start) {
            const int id = static_cast<int>(roots_.size()); roots_.push_back(start);
            parent_[start] = -1; component_[start] = id; stack.push_back(start);
            while (!stack.empty()) {
                const int v = stack.back(); stack.pop_back(); order_[visited_count++] = v;
#ifndef SKIP_RUNTIME_CHECKS
                bool parent_seen = false;
#endif
                for (int u : graph[v]) {
#ifndef SKIP_RUNTIME_CHECKS
                    vertex(u);
#endif
                    if (u == parent_[v]) {
#ifndef SKIP_RUNTIME_CHECKS
                        if (parent_seen) throw std::invalid_argument("HLD: parallel edge");
                        parent_seen = true;
#endif
                        continue;
                    }
#ifndef SKIP_RUNTIME_CHECKS
                    if (parent_[u] != -2) throw std::invalid_argument("HLD: input must be a forest");
#endif
                    parent_[u] = v; depth_[u] = depth_[v] + 1;
                    component_[u] = id; stack.push_back(u);
                }
            }
        };
        discover(root);
        for (int v = 0; v < n; ++v) if (parent_[v] == -2) discover(v);
        for (std::size_t i = visited_count; i != 0;) {
            const int v = order_[--i], parent = parent_[v];
            if (parent != -1) {
                subtree_[parent] += subtree_[v];
                if (heavy_[parent] == -1 || subtree_[v] > subtree_[heavy_[parent]]) heavy_[parent] = v;
            }
        }
        int position = 0;
        for (int start : roots_) {
            stack.push_back(start);
            while (!stack.empty()) {
                const int first = stack.back(); stack.pop_back();
                for (int v = first; v != -1; v = heavy_[v]) {
                    head_[v] = first; index_[v] = position; order_[position++] = v;
                    const int parent = parent_[v], heavy = heavy_[v];
                    for (int u : graph[v]) if (u != parent && u != heavy) stack.push_back(u);
                }
            }
        }
    }
    template<class Identity, class Q, class Op, class Reverse>
    auto path_product_impl(int u, int v, Identity&& identity, Q& query, Op& op, Reverse& reverse, bool edges) const {
        using S = reinsirk::detail::HldRangeValue<Q>;
        S result(std::forward<Identity>(identity));
        constexpr bool directional = reinsirk::detail::hld_directional_query<Q>;
        constexpr bool reverse_value = !std::is_same_v<std::remove_cvref_t<Reverse>, std::identity>;
        static_assert(!directional || !reverse_value, "HLD: choose directional query or reverse, not both");
        const auto consume = [&](int l, int r, bool reversed) {
            S part = reinsirk::detail::hld_read_range(query, l, r, reversed);
            if constexpr (!directional && reverse_value)
                if (reversed) part = std::invoke(reverse, std::move(part));
            result = std::invoke(op, std::move(result), std::move(part));
        };
#if defined(__clang__)
        if constexpr (!directional && !reverse_value) {
            // 可換なら区間の通行順を保存せず、その場で集計できる。
#ifndef SKIP_RUNTIME_CHECKS
            vertex(u); vertex(v);
#endif
            if (roots_.size() != 1 && component_[u] != component_[v]) {
#ifndef SKIP_RUNTIME_CHECKS
                throw std::invalid_argument("HLD: path endpoints are disconnected");
#else
                return result;
#endif
            }
            while (head_[u] != head_[v]) {
                if (index_[u] >= index_[v]) {
                    consume(index_[head_[u]], index_[u] + 1, false); u = parent_[head_[u]];
                } else {
                    consume(index_[head_[v]], index_[v] + 1, false); v = parent_[head_[v]];
                }
            }
            const int left = std::min(index_[u], index_[v]) + static_cast<int>(edges);
            const int right = std::max(index_[u], index_[v]) + 1;
            if (left < right) consume(left, right, false);
            return result;
        }
#endif
        const bool connected = for_each_path(u, v, consume, edges);
#ifndef SKIP_RUNTIME_CHECKS
        if (!connected) throw std::invalid_argument("HLD: path endpoints are disconnected");
#else
        (void)connected;
#endif

        return result;
    }
public:
    template<class Range, bool Ordered = false, class T>
    HeavyLightValues<Range, Ordered> with_values(const std::vector<T>& values) const &;
    template<class Range, bool Ordered = false, class T>
    HeavyLightValues<Range, Ordered> with_values(const std::vector<T>& values) &&;
    HeavyLightDecomposition() = default;
    explicit HeavyLightDecomposition(const Graph& graph, int root = 0) { prepare(graph, root); }
    HeavyLightDecomposition(const HeavyLightDecomposition&) = default;
    HeavyLightDecomposition(HeavyLightDecomposition&& other) noexcept { swap(other); }
    HeavyLightDecomposition& operator=(HeavyLightDecomposition other) noexcept { swap(other); return *this; }
    void swap(HeavyLightDecomposition& other) noexcept {
        std::swap(root_, other.root_); parent_.swap(other.parent_); depth_.swap(other.depth_);
        component_.swap(other.component_); roots_.swap(other.roots_); subtree_.swap(other.subtree_);
        heavy_.swap(other.heavy_); head_.swap(other.head_); index_.swap(other.index_); order_.swap(other.order_);
    }
    void clear() noexcept { HeavyLightDecomposition replacement; swap(replacement); }
    void build(const Graph& graph, int root = 0) { HeavyLightDecomposition replacement(graph, root); swap(replacement); }
    int size() const noexcept { return static_cast<int>(parent_.size()); }
    bool empty() const noexcept { return parent_.empty(); }
    int root() const noexcept { return root_; }
    int component_count() const noexcept { return static_cast<int>(roots_.size()); }
    int parent(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return parent_[v];
    }
    int depth(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return depth_[v];
    }
    int component(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return component_[v];
    }
    int root_of(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return roots_[component_[v]];
    }
    int index(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return index_[v];
    }
    int vertex_at(int i) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(i);
#endif
        return order_[i];
    }
    const std::vector<int>& order() const noexcept { return order_; }
    bool same_component(int u, int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        return component_[u] == component_[v];
    }
    bool is_ancestor(int u, int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        // 部分木区間には他の成分の頂点が入らない。
        return index_[u] <= index_[v] && index_[v] < index_[u] + subtree_[u];
    }
    std::pair<int, int> subtree_range(int v, bool edges = false) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return {index_[v] + static_cast<int>(edges), index_[v] + subtree_[v]};
    }
    int subtree_size(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return subtree_[v];
    }
    int lca(int u, int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        if (component_[u] != component_[v]) return -1;
        while (head_[u] != head_[v]) {
            if (depth_[head_[u]] > depth_[head_[v]]) u = parent_[head_[u]];
            else v = parent_[head_[v]];
        }
        return depth_[u] < depth_[v] ? u : v;
    }
    int distance(int u, int v) const {
        const int w = lca(u, v);
        return w == -1 ? -1 : (depth_[u] - depth_[w]) + (depth_[v] - depth_[w]);
    }
    int kth_ancestor(int v, std::int64_t k) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        if (k < 0 || k > depth_[v]) return -1;
        for (;;) {
            const int within = depth_[v] - depth_[head_[v]];
            if (k <= within) return order_[index_[v] - static_cast<int>(k)];
            k -= static_cast<std::int64_t>(within) + 1; v = parent_[head_[v]];
        }
    }
    int jump(int u, int v, std::int64_t k) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        if ((roots_.size() != 1 && component_[u] != component_[v]) || k < 0) return -1;
        // 同じ重鎖内では添字の差がそのまま経路長になる。
        if (head_[u] == head_[v]) {
            const int delta = index_[v] - index_[u];
            if (k > (delta >= 0 ? delta : -delta)) return -1;
            const int step = static_cast<int>(k);
            return order_[index_[u] + (delta >= 0 ? step : -step)];
        }
        if (k > static_cast<std::int64_t>(depth_[u]) + depth_[v]) return -1;
        // u側の区間内に答えがあれば、その場で返して再走査を省く。
        const int destination = v;
        while (head_[u] != head_[v]) {
            if (index_[u] >= index_[v]) {
                const int within = depth_[u] - depth_[head_[u]];
                if (k <= within) return order_[index_[u] - static_cast<int>(k)];
                k -= static_cast<std::int64_t>(within) + 1;
                u = parent_[head_[u]];
            } else v = parent_[head_[v]];
        }
        if (index_[u] >= index_[v]) {
            const int within = depth_[u] - depth_[v];
            if (k <= within) return order_[index_[u] - static_cast<int>(k)];
            k -= within;
            const int downward = depth_[destination] - depth_[v];
            return k > downward ? -1 : kth_ancestor(destination, downward - k);
        }
        const int within = depth_[v] - depth_[u];
        if (k <= within) return order_[index_[u] + static_cast<int>(k)];
        const int downward = depth_[destination] - depth_[u];
        return k > downward ? -1 : kth_ancestor(destination, downward - k);
    }
    template<class Fn>
    bool for_each_path(int u, int v, Fn&& visit, bool edges = false) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        if (roots_.size() != 1 && component_[u] != component_[v]) return false;
        std::array<Interval, std::numeric_limits<unsigned int>::digits + 1> downward;
        std::size_t count = 0;
        while (head_[u] != head_[v]) {
#if defined(__GNUC__) && !defined(__clang__)
            if (index_[u] >= index_[v]) {
#else
            if (depth_[head_[u]] >= depth_[head_[v]]) {
#endif
                visit(index_[head_[u]], index_[u] + 1, true); u = parent_[head_[u]];
            } else {
                downward[count++] = {index_[head_[v]], index_[v] + 1, false}; v = parent_[head_[v]];
            }
        }
        if (index_[u] >= index_[v]) {
            const int left = index_[v] + static_cast<int>(edges), right = index_[u] + 1;
            if (left < right) visit(left, right, true);
        } else {
            const int left = index_[u] + static_cast<int>(edges), right = index_[v] + 1;
            if (left < right) downward[count++] = {left, right, false};
        }
        while (count != 0) { const auto part = downward[--count]; visit(part.left, part.right, part.reversed); }
        return true;
    }
    std::vector<Interval> path(int u, int v, bool edges = false) const {
        std::vector<Interval> result;
        for_each_path(u, v, [&](int left, int right, bool reverse) { result.push_back({left, right, reverse}); }, edges);
        return result;
    }
    template<class T>
    std::vector<T> reorder(const std::vector<T>& values) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (values.size() != order_.size()) throw std::invalid_argument("HLD: value count mismatch");
#endif
        std::vector<T> result; result.reserve(order_.size());
        for (int v : order_) result.push_back(values[v]);
        return result;
    }
    template<class T>
    std::vector<T> restore(const std::vector<T>& ordered) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (ordered.size() != order_.size()) throw std::invalid_argument("HLD: value count mismatch");
#endif
        std::vector<T> result; result.reserve(order_.size());
        for (int v = 0; v < size(); ++v) result.push_back(ordered[index_[v]]);
        return result;
    }
    template<class Identity, reinsirk::detail::HldRangeQuery Q, class Op, class Reverse>
        requires std::is_invocable_r_v<reinsirk::detail::HldRangeValue<Q>, Op&,
                     reinsirk::detail::HldRangeValue<Q>, reinsirk::detail::HldRangeValue<Q>>
            && std::is_invocable_r_v<reinsirk::detail::HldRangeValue<Q>, Reverse&, reinsirk::detail::HldRangeValue<Q>>
            && std::is_constructible_v<reinsirk::detail::HldRangeValue<Q>, Identity&&>
            && (!reinsirk::detail::hld_directional_query<Q>
                || std::is_same_v<std::remove_cvref_t<Reverse>, std::identity>)
    auto path_prod(int u, int v, Identity&& identity, Q&& query, Op&& op, Reverse&& reverse, bool edges = false) const {
        return path_product_impl(u, v, std::forward<Identity>(identity), query, op, reverse, edges);
    }
    template<class Identity, reinsirk::detail::HldRangeQuery Q, class Op>
        requires std::is_invocable_r_v<reinsirk::detail::HldRangeValue<Q>, Op&,
                     reinsirk::detail::HldRangeValue<Q>, reinsirk::detail::HldRangeValue<Q>>
            && std::is_constructible_v<reinsirk::detail::HldRangeValue<Q>, Identity&&>
    auto path_prod(int u, int v, Identity&& identity, Q&& query, Op&& op, bool edges = false) const {
        std::identity reverse;
        return path_product_impl(u, v, std::forward<Identity>(identity), query, op, reverse, edges);
    }
    template<class Range>
        requires requires(Range& range) { range.sum(0, 0); }
            && (!requires(Range& range) { range.prod(0, 0); })
    auto path_prod(int u, int v, Range& range, bool edges = false) const {
        using S = std::remove_cvref_t<decltype(range.sum(0, 0))>;
        return path_prod(u, v, S{}, range, reinsirk::detail::HldAddition{}, edges);
    }
    template<template<class, auto, auto> class Range, class S, auto Op, auto E>
        requires requires(const Range<S, Op, E>& range) { { range.prod(0, 0) } -> std::same_as<S>; }
    S path_prod(int u, int v, const Range<S, Op, E>& range, bool edges = false) const {
        return path_prod(u, v, std::invoke(E), range, Op, edges);
    }
    template<template<class, auto, auto> class Range, class S, auto Op, auto E, class Reverse>
        requires std::is_invocable_r_v<S, Reverse&, S>
            && requires(const Range<S, Op, E>& range) { { range.prod(0, 0) } -> std::same_as<S>; }
    S path_prod(int u, int v, const Range<S, Op, E>& range, Reverse&& reverse, bool edges = false) const {
        return path_prod(u, v, std::invoke(E), range, Op, std::forward<Reverse>(reverse), edges);
    }
    template<template<class, auto, auto, class, auto, auto, auto> class Range,
             class S, auto Op, auto E, class F, auto Mapping, auto Composition, auto Id>
        requires requires(Range<S, Op, E, F, Mapping, Composition, Id>& range) { { range.prod(0, 0) } -> std::same_as<S>; }
    S path_prod(int u, int v, Range<S, Op, E, F, Mapping, Composition, Id>& range, bool edges = false) const {
        return path_prod(u, v, std::invoke(E), range, Op, edges);
    }
    template<template<class, auto, auto, class, auto, auto, auto> class Range,
             class S, auto Op, auto E, class F, auto Mapping, auto Composition, auto Id, class Reverse>
        requires std::is_invocable_r_v<S, Reverse&, S>
            && requires(Range<S, Op, E, F, Mapping, Composition, Id>& range) { { range.prod(0, 0) } -> std::same_as<S>; }
    S path_prod(int u, int v, Range<S, Op, E, F, Mapping, Composition, Id>& range, Reverse&& reverse, bool edges = false) const {
        return path_prod(u, v, std::invoke(E), range, Op, std::forward<Reverse>(reverse), edges);
    }
    template<reinsirk::detail::HldRangeQuery Q>
    auto subtree_prod(int v, Q&& query, bool edges = false) const {
        const auto [l, r] = subtree_range(v, edges);
        return reinsirk::detail::hld_read_range(query, l, r, false);
    }
    template<class Range, class F>
    void path_apply(int u, int v, Range& range, const F action, bool edges = false) const {
        const bool connected = for_each_path(u, v, [&](int l, int r, bool) { range.apply(l, r, action); }, edges);
#ifndef SKIP_RUNTIME_CHECKS
        if (!connected) throw std::invalid_argument("HLD: path endpoints are disconnected");
#else
        (void)connected;
#endif
    }
    template<class Range, class F>
    void subtree_apply(int v, Range& range, const F action, bool edges = false) const {
        const auto [l, r] = subtree_range(v, edges);
        if (l < r) range.apply(l, r, action);
    }
};
#endif

#ifndef SIRKIT_HLD_OWNED_RANGE_TRAITS_DEFINED
#define SIRKIT_HLD_OWNED_RANGE_TRAITS_DEFINED
namespace reinsirk::detail {
struct HldNoReverseRange {};
template<class Range> struct HldOwnedRangeTraits {
    using Value = HldRangeValue<Range>;
    static Value identity() { return Value{}; }
    static Value combine(Value a, Value b) { return HldAddition{}(std::move(a), std::move(b)); }
};
template<template<class, auto, auto> class Range, class S, auto Op, auto E>
struct HldOwnedRangeTraits<Range<S, Op, E>> {
    using Value = S;
    static S identity() { return std::invoke(E); }
    static S combine(S a, S b) { return std::invoke(Op, std::move(a), std::move(b)); }
};
template<template<class, auto, auto, class, auto, auto, auto> class Range,
         class S, auto Op, auto E, class F, auto Mapping, auto Composition, auto Id>
struct HldOwnedRangeTraits<Range<S, Op, E, F, Mapping, Composition, Id>> {
    using Value = S;
    static S identity() { return std::invoke(E); }
    static S combine(S a, S b) { return std::invoke(Op, std::move(a), std::move(b)); }
};
struct HldDifference {
    template<class T> T operator()(T a, T b) const {
#if defined(__SIZEOF_INT128__) && (defined(__GNUC__) || defined(__clang__))
        if constexpr (std::is_same_v<T, __int128> || std::is_same_v<T, unsigned __int128>)
            return static_cast<T>(static_cast<unsigned __int128>(a) - static_cast<unsigned __int128>(b));
        else
#endif
        if constexpr (std::is_integral_v<T> && !std::is_same_v<T, bool>) {
            using U = std::make_unsigned_t<T>;
            return static_cast<T>(static_cast<U>(a) - static_cast<U>(b));
        } else return a - b;
    }
};
}
#endif

#ifndef SIRKIT_HEAVY_LIGHT_VALUES_DEFINED
#define SIRKIT_HEAVY_LIGHT_VALUES_DEFINED
template<class Range, bool Ordered>
class HeavyLightValues {
    using Traits = reinsirk::detail::HldOwnedRangeTraits<Range>;
public:
    using value_type = typename Traits::Value;
private:
    static Range make_range(const std::vector<value_type>& values) {
        if constexpr (std::is_constructible_v<Range, const std::vector<value_type>&>) return Range(values);
        else {
            static_assert(std::is_constructible_v<Range, int> && requires(Range& r, value_type x) { r.add(0, x); },
                          "HLD: Range needs a vector constructor or an int constructor and add");
            Range result(static_cast<int>(values.size()));
            for (int i = 0; i < static_cast<int>(values.size()); ++i) result.add(i, values[i]);
            return result;
        }
    }
    struct State {
        HeavyLightDecomposition layout;
        Range range;
        [[no_unique_address]] std::conditional_t<Ordered, std::optional<Range>, reinsirk::detail::HldNoReverseRange> reversed;
        State(HeavyLightDecomposition tree, std::vector<value_type> ordered)
            : layout(std::move(tree)), range(make_range(ordered)) {
            if constexpr (Ordered) { std::reverse(ordered.begin(), ordered.end()); reversed.emplace(make_range(ordered)); }
        }
    };
    std::unique_ptr<State> state_;
    const HeavyLightDecomposition& layout() const noexcept {
        if (state_) return state_->layout;
        static const HeavyLightDecomposition empty;
        return empty;
    }
    Range& range() {
#ifndef SKIP_RUNTIME_CHECKS
        if (!state_) throw std::out_of_range("HLD: empty values");
#endif
        return state_->range;
    }
    static value_type read_point(Range& r, int p) {
        if constexpr (requires { r.get(p); }) return r.get(p);
        else return r.sum(p, p + 1);
    }
    static void set_point(Range& r, int p, const value_type& value) {
        if constexpr (requires { r.set(p, value); }) r.set(p, value);
        else r.add(p, reinsirk::detail::HldDifference{}(value, read_point(r, p)));
    }
public:
    HeavyLightValues() = default;
    HeavyLightValues(const HeavyLightDecomposition& tree, const std::vector<value_type>& values) {
        auto ordered = tree.reorder(values);
        state_ = std::make_unique<State>(tree, std::move(ordered));
    }
    HeavyLightValues(HeavyLightDecomposition&& tree, const std::vector<value_type>& values) {
        auto ordered = tree.reorder(values);
        state_ = std::make_unique<State>(std::move(tree), std::move(ordered));
    }
    HeavyLightValues(const Graph& graph, const std::vector<value_type>& values, int root = 0)
        : HeavyLightValues(HeavyLightDecomposition(graph, root), values) {}
    HeavyLightValues(const HeavyLightValues& other) {
        if (other.state_) state_ = std::make_unique<State>(*other.state_);
    }
    HeavyLightValues(HeavyLightValues&&) noexcept = default;
    HeavyLightValues& operator=(HeavyLightValues other) noexcept { swap(other); return *this; }
    void swap(HeavyLightValues& other) noexcept { state_.swap(other.state_); }
    void clear() noexcept { state_.reset(); }
    void build(const Graph& graph, const std::vector<value_type>& values, int root = 0) {
        HeavyLightValues replacement(graph, values, root); swap(replacement);
    }
    int size() const noexcept { return layout().size(); }
    bool empty() const noexcept { return layout().empty(); }
    int root() const noexcept { return layout().root(); }
    int component_count() const noexcept { return layout().component_count(); }
    int parent(int v) const { return layout().parent(v); }
    int depth(int v) const { return layout().depth(v); }
    int component(int v) const { return layout().component(v); }
    int root_of(int v) const { return layout().root_of(v); }
    int index(int v) const { return layout().index(v); }
    int vertex_at(int p) const { return layout().vertex_at(p); }
    const std::vector<int>& order() const noexcept { return layout().order(); }
    bool same_component(int u, int v) const { return layout().same_component(u, v); }
    bool is_ancestor(int u, int v) const { return layout().is_ancestor(u, v); }
    auto subtree_range(int v, bool edges = false) const { return layout().subtree_range(v, edges); }
    int subtree_size(int v) const { return layout().subtree_size(v); }
    int lca(int u, int v) const { return layout().lca(u, v); }
    int distance(int u, int v) const { return layout().distance(u, v); }
    int kth_ancestor(int v, std::int64_t k) const { return layout().kth_ancestor(v, k); }
    int jump(int u, int v, std::int64_t k) const { return layout().jump(u, v, k); }
    template<class Fn> bool for_each_path(int u, int v, Fn&& fn, bool edges = false) const {
        return layout().for_each_path(u, v, std::forward<Fn>(fn), edges);
    }
    auto path(int u, int v, bool edges = false) const { return layout().path(u, v, edges); }
    template<class T> std::vector<T> reorder(const std::vector<T>& values) const { return layout().reorder(values); }
    template<class T> std::vector<T> restore(const std::vector<T>& values) const { return layout().restore(values); }
    value_type get(int v) requires (requires(Range& r) { r.get(0); } || requires(Range& r) { r.sum(0, 1); }) {
        const int p = layout().index(v); return read_point(range(), p);
    }
    void set(int v, const value_type value)
        requires (requires(Range& r, value_type x) { r.set(0, x); }
               || requires(Range& r, value_type x) { r.add(0, x); x - x; }) {
        const int p = layout().index(v); set_point(range(), p, value);
        if constexpr (Ordered) set_point(*state_->reversed, size() - 1 - p, value);
    }
    void add(int v, const value_type delta) requires requires(Range& r, value_type x) { r.add(0, x); } {
        const int p = layout().index(v); range().add(p, delta);
        if constexpr (Ordered) state_->reversed->add(size() - 1 - p, delta);
    }
    template<class F> void apply(int v, const F action) requires requires(Range& r, const F& f) { r.apply(0, f); } {
        const int p = layout().index(v); range().apply(p, action);
        if constexpr (Ordered) state_->reversed->apply(size() - 1 - p, action);
    }
    value_type path_prod(int u, int v, bool edges = false) {
        auto& forward = range();
        if constexpr (!Ordered) return layout().path_prod(u, v, forward, edges);
        else return layout().path_prod(u, v, Traits::identity(), [&](int l, int r, bool reverse) {
            return reverse ? reinsirk::detail::hld_read_range(*state_->reversed, size() - r, size() - l, false)
                           : reinsirk::detail::hld_read_range(forward, l, r, false);
        }, Traits::combine, edges);
    }
    value_type subtree_prod(int v, bool edges = false) { return layout().subtree_prod(v, range(), edges); }
    template<class F> void path_apply(int u, int v, const F action, bool edges = false)
        requires requires(Range& r, const F& f) { r.apply(0, 0, f); } {
        if constexpr (!Ordered) layout().path_apply(u, v, range(), action, edges);
        else {
            auto& forward = range();
            const bool connected = layout().for_each_path(u, v, [&](int l, int r, bool) {
                forward.apply(l, r, action); state_->reversed->apply(size() - r, size() - l, action);
            }, edges);
#ifndef SKIP_RUNTIME_CHECKS
            if (!connected) throw std::invalid_argument("HLD: path endpoints are disconnected");
#else
            (void)connected;
#endif
        }
    }
    template<class F> void subtree_apply(int v, const F action, bool edges = false)
        requires requires(Range& r, const F& f) { r.apply(0, 0, f); } {
        const auto [l, r] = layout().subtree_range(v, edges);
        if (l < r) { range().apply(l, r, action); if constexpr (Ordered) state_->reversed->apply(size() - r, size() - l, action); }
    }
    std::vector<value_type> values() {
        if (!state_) return {};
        if constexpr (requires(Range& r) { r.values(); }) return layout().restore(range().values());
        else {
            std::vector<value_type> result; result.reserve(size());
            for (int v = 0; v < size(); ++v) result.push_back(get(v));
            return result;
        }
    }
};

template<class Range, bool Ordered, class T>
HeavyLightValues<Range, Ordered> HeavyLightDecomposition::with_values(const std::vector<T>& values) const & {
    return HeavyLightValues<Range, Ordered>(*this, values);
}
template<class Range, bool Ordered, class T>
HeavyLightValues<Range, Ordered> HeavyLightDecomposition::with_values(const std::vector<T>& values) && {
    return HeavyLightValues<Range, Ordered>(std::move(*this), values);
}

#endif

// SPDX-License-Identifier: CC0-1.0
// 参考（データ構造・検証問題）: https://nyaannyaan.github.io/library/data-structure/binary-indexed-tree.hpp
// 参考（公開API）: https://atcoder.github.io/ac-library/production/document_ja/fenwicktree.html
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/fenwick_tree.md
//
// API一覧
// [fenwick_tree<T>]
// fenwick_tree()/fenwick_tree(int n)/fenwick_tree(vector<T>): 空列/n要素の0/列から構築。O(n+1)時間・領域。
// add(int p,T x): 点加算。sum(int l,int r): 半開区間[l,r)の和をT値で返す。O(log(n+1))、空区間はT{}。
// 点添字は0<=p<size()、区間は0<=l<=r<=size()。
// ACL形式の公開APIをグローバルに定義する。bool以外の整数は内部を符号なしにして型幅のmod 2^bitで計算する。
// その他のTはT{}が単位元の可換加法群とし、加減算・コピーをO(1)とする。要素数はintの範囲内。
// size()/empty(): 要素数/空か、O(1)。get(int p)/set(int p,T value): 点取得/代入、O(log(n+1))。
// lower_bound(target)/upper_bound(target): sum(0,i+1)>=target/>targetとなる最小int添字、なければsize()。O(log(n+1))。
// 境界探索は全要素が非負で、途中の和がTに収まり、加算と順序が整合すること。全要素の検査はしない。
// values(): 列を復元して返す。O(n+1)時間・追加O(n)。reset(int n)/reset(): n要素/現在の長さを0にする。O(旧n+n+1)。
// clear()/swap(other): 空にして容量保持/交換。O(旧n+1)/O(1)。コピーは独立、移動元は空として使える。
// 添字・区間は既定で検査しSKIP_RUNTIME_CHECKSで除く。容量・添字のオーバーフロー対策は残す。

#include <algorithm>
#include <bit>
#include <cstddef>
#include <limits>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

#ifndef SIRKIT_FENWICK_STORAGE_TYPE_DEFINED
#define SIRKIT_FENWICK_STORAGE_TYPE_DEFINED
namespace reinsirk::detail {
template<class T, bool = std::is_integral_v<T> && !std::is_same_v<T, bool>>
struct FenwickStorage { using type = T; };
template<class T>
struct FenwickStorage<T, true> { using type = std::make_unsigned_t<T>; };
#if defined(__SIZEOF_INT128__)
template<> struct FenwickStorage<__int128> { using type = unsigned __int128; };
template<> struct FenwickStorage<unsigned __int128> { using type = unsigned __int128; };
#endif
}
#endif

#ifndef SIRKIT_FENWICK_TREE_DEFINED
#define SIRKIT_FENWICK_TREE_DEFINED
template<class T>
class fenwick_tree {
    using Storage = typename reinsirk::detail::FenwickStorage<T>::type;
    std::vector<Storage> tree_;
    static decltype(auto) to_storage(const T& value) {
        if constexpr (std::is_same_v<T, Storage>) return (value);
        else return static_cast<Storage>(value);
    }
    static decltype(auto) from_storage(Storage& value) {
        if constexpr (std::is_same_v<T, Storage>) return (value);
        else return static_cast<T>(value);
    }
    static std::size_t checked_size(int n) {
#ifndef SKIP_RUNTIME_CHECKS
        if (n < 0) throw std::invalid_argument("fenwick_tree: negative size");
#endif
        return static_cast<std::size_t>(n);
    }
    static std::size_t storage_size(std::size_t n) {
        if (n > static_cast<std::size_t>(std::numeric_limits<int>::max())
            || n + 1 > std::vector<Storage>{}.max_size())
            throw std::length_error("fenwick_tree: size");
        return n == 0 ? 0 : n + 1;
    }
    static std::size_t lowbit(std::size_t x) noexcept { return x & (~x + 1); }
    void check_index(int i) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (i < 0 || i >= size()) throw std::out_of_range("fenwick_tree: index");
#else
        (void)i;
#endif
    }
    void check_range(int l, int r) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (l < 0 || l > r || r > size()) throw std::out_of_range("fenwick_tree: range");
#else
        (void)l; (void)r;
#endif
    }
    Storage prefix_unchecked(std::size_t r) const {
        Storage result{};
        for (; r; r -= lowbit(r)) result += tree_[r];
        return result;
    }
    Storage get_unchecked(std::size_t i) const {
        auto node = i + 1;
        Storage result = tree_[node];
        const auto begin = node - lowbit(node);
        for (--node; node > begin; node -= lowbit(node)) result -= tree_[node];
        return result;
    }
    void add_unchecked(std::size_t i, const Storage& delta) {
        const auto n = static_cast<std::size_t>(size());
        for (++i; i <= n;) {
            tree_[i] += delta;
            const auto step = lowbit(i);
            if (step > n - i) break;
            i += step;
        }
    }
public:
    fenwick_tree() = default;
    explicit fenwick_tree(int n) : tree_(storage_size(checked_size(n)), Storage{}) {}
    template<class Values> requires std::is_same_v<Values, std::vector<T>>
    explicit fenwick_tree(const Values& values) : tree_(storage_size(values.size()), Storage{}) {
        const auto n = values.size();
        for (std::size_t i = 1; i <= n; ++i) {
            tree_[i] += to_storage(values[i - 1]);
            const auto step = lowbit(i);
            if (step <= n - i) tree_[i + step] += tree_[i];
        }
    }
    fenwick_tree(const fenwick_tree&) = default;
    fenwick_tree& operator=(const fenwick_tree&) = default;
    fenwick_tree(fenwick_tree&& other) noexcept : tree_(std::move(other.tree_)) { other.tree_.clear(); }
    fenwick_tree& operator=(fenwick_tree&& other) noexcept {
        if (this != &other) { tree_ = std::move(other.tree_); other.tree_.clear(); }
        return *this;
    }
    int size() const noexcept { return tree_.empty() ? 0 : static_cast<int>(tree_.size() - 1); }
    bool empty() const noexcept { return size() == 0; }
    void add(int i, T delta) {
        check_index(i);
        add_unchecked(static_cast<std::size_t>(i), to_storage(delta));
    }
    T get(int i) const { check_index(i); return static_cast<T>(get_unchecked(static_cast<std::size_t>(i))); }
    void set(int i, T value) {
        check_index(i);
        const Storage delta = to_storage(value) - get_unchecked(static_cast<std::size_t>(i));
        add_unchecked(static_cast<std::size_t>(i), delta);
    }
    T sum(int l, int r) {
        check_range(l, r);
        return static_cast<T>(prefix_unchecked(static_cast<std::size_t>(r)) - prefix_unchecked(static_cast<std::size_t>(l)));
    }
    int lower_bound(const T& target) const {
        if (!(T{} < target)) return 0;
        const auto n = static_cast<std::size_t>(size());
        std::size_t index = 0;
        Storage current{};
        for (auto jump = std::bit_floor(n); jump; jump >>= 1) {
            if (jump <= n - index) {
                const auto next = index + jump;
                Storage candidate = current + tree_[next];
                if (from_storage(candidate) < target) { current = std::move(candidate); index = next; }
            }
        }
        return static_cast<int>(index);
    }
    int upper_bound(const T& target) const {
        if (target < T{}) return 0;
        const auto n = static_cast<std::size_t>(size());
        std::size_t index = 0;
        Storage current{};
        for (auto jump = std::bit_floor(n); jump; jump >>= 1) {
            if (jump <= n - index) {
                const auto next = index + jump;
                Storage candidate = current + tree_[next];
                if (!(target < from_storage(candidate))) { current = std::move(candidate); index = next; }
            }
        }
        return static_cast<int>(index);
    }
    std::vector<T> values() const {
        if (tree_.empty()) return {};
        std::vector<T> result(tree_.begin() + 1, tree_.end());
        const auto n = static_cast<std::size_t>(size());
        for (auto i = n; i; --i) {
            const auto step = lowbit(i);
            if (step <= n - i) {
                if constexpr (std::is_same_v<T, Storage>) result[i + step - 1] -= result[i - 1];
                else {
                    const Storage difference = static_cast<Storage>(result[i + step - 1]) - static_cast<Storage>(result[i - 1]);
                    result[i + step - 1] = static_cast<T>(difference);
                }
            }
        }
        return result;
    }
    void reset(int n) {
        std::vector<Storage> replacement(storage_size(checked_size(n)), Storage{});
        tree_.swap(replacement);
    }
    void reset() { std::fill(tree_.begin(), tree_.end(), Storage{}); }
    void clear() noexcept { tree_.clear(); }
    void swap(fenwick_tree& other) noexcept { tree_.swap(other.tree_); }
};
#endif

// SPDX-License-Identifier: CC0-1.0
#include <algorithm>
#include <array>
#include <charconv>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <vector>

#ifndef SIRKIT_VERIFY_FAST_IO_DEFINED
#define SIRKIT_VERIFY_FAST_IO_DEFINED

// VerifyInput(file=stdin): 非所有のFILEから読む。別の入力方式と混用しない。
// >> 整数: 64bit以下の十進整数を読む。検査省略時は値域内の正しい入力を前提とする。
// >> char/string: 空白を飛ばし、1文字／空白までの文字列を読む。
// >> 浮動小数点: 十進文字列を変換する。通常のCロケールで使う。
// bool / !: 直前までの読み取りが成功しているか／失敗したかを返す。
class VerifyInput {
    static constexpr std::size_t buffer_size = 1 << 17;
    std::FILE* file_;
    std::array<unsigned char, buffer_size> buffer_;
    std::size_t position_ = 0, size_ = 0;
    bool good_ = true;

    int peek() {
        if (position_ == size_) {
            size_ = std::fread(buffer_.data(), 1, buffer_.size(), file_);
            position_ = 0;
            if (size_ == 0) return EOF;
        }
        return buffer_[position_];
    }

    int skip_space() {
        int c;
        while ((c = peek()) != EOF && c <= ' ') ++position_;
        if (c == EOF) good_ = false;
        return c;
    }

public:
    explicit VerifyInput(std::FILE* file = stdin) : file_(file) {}
    VerifyInput(const VerifyInput&) = delete;
    VerifyInput& operator=(const VerifyInput&) = delete;

    explicit operator bool() const noexcept { return good_; }
    bool operator!() const noexcept { return !good_; }

    template<class T>
        requires (std::is_integral_v<T> && sizeof(T) <= sizeof(std::uint64_t)
                  && !std::is_same_v<T, char>)
    VerifyInput& operator>>(T& result) {
        if (!good_) return *this;
        int c = skip_space();
        if (c == EOF) return *this;
        bool negative = false;
        if (c == '-' || c == '+') {
            negative = c == '-';
            ++position_;
            c = peek();
        }
        if (c == EOF) {
            good_ = false;
            return *this;
        }
#ifndef SKIP_RUNTIME_CHECKS
        if (c < '0' || c > '9') {
            good_ = false;
            return *this;
        }
        // 先頭の0を除けば、20桁以下の末尾直前の値はuint64_tに収まる。
        while (c == '0') {
            ++position_;
            c = peek();
        }
        std::uint64_t previous = 0;
        unsigned last_digit = 0;
        std::size_t digits = 0;
#endif
        std::uint64_t value = 0;
        while (c >= '0' && c <= '9') {
#ifndef SKIP_RUNTIME_CHECKS
            previous = value;
            last_digit = static_cast<unsigned>(c - '0');
            if (digits <= 20) ++digits;
#endif
            value = value * 10 + static_cast<unsigned>(c - '0');
            ++position_;
            c = peek();
        }
#ifndef SKIP_RUNTIME_CHECKS
        constexpr auto maximum = std::numeric_limits<std::uint64_t>::max();
        if ((c != EOF && c > ' ') || digits > 20
            || (digits == 20 && (previous > maximum / 10
                || (previous == maximum / 10 && last_digit > maximum % 10)))) {
            good_ = false;
            return *this;
        }
        std::uint64_t limit = static_cast<std::uint64_t>(std::numeric_limits<T>::max());
        if constexpr (std::is_signed_v<T>) limit += negative;
        else if (negative && value != 0) good_ = false;
        if (value > limit) good_ = false;
        if (!good_) return *this;
#endif
        if constexpr (std::is_signed_v<T>) {
            constexpr std::uint64_t minimum_magnitude =
                static_cast<std::uint64_t>(std::numeric_limits<T>::max()) + 1;
            // -(最小値)は評価せず、絶対値が最大値+1のときだけ最小値を使う。
            result = negative
                ? (value == minimum_magnitude ? std::numeric_limits<T>::min()
                                  : static_cast<T>(-static_cast<T>(value)))
                : static_cast<T>(value);
        } else result = static_cast<T>(value);
        return *this;
    }

    VerifyInput& operator>>(char& result) {
        if (!good_) return *this;
        const int c = skip_space();
        if (c != EOF) {
            result = static_cast<char>(c);
            ++position_;
        }
        return *this;
    }

    VerifyInput& operator>>(std::string& result) {
        if (!good_) return *this;
        int c = skip_space();
        if (c == EOF) return *this;
        result.clear();
        do {
            result.push_back(static_cast<char>(c));
            ++position_;
            c = peek();
        } while (c != EOF && c > ' ');
        return *this;
    }

    template<class T> requires std::is_floating_point_v<T>
    VerifyInput& operator>>(T& result) {
        std::string token;
        *this >> token;
        if (!good_) return *this;
#ifndef SKIP_RUNTIME_CHECKS
        char* end = nullptr;
        const long double value = std::strtold(token.c_str(), &end);
        if (end != token.c_str() + token.size()) good_ = false;
        else result = static_cast<T>(value);
#else
        result = static_cast<T>(std::strtold(token.c_str(), nullptr));
#endif
        return *this;
    }
};

// VerifyOutput(file=stdout): 非所有のFILEへ書く。破棄時にflushし、FILEは閉じない。
// << 整数/char/文字列/浮動小数点: 値を出力する。整数は64bit以下に対応する。
// fixed(digits): 浮動小数点を小数点以下digits桁で出力する（digits>=0）。
// flush(): バッファの内容をFILEへ渡す。bool / !で書き込み失敗を確認できる。
class VerifyOutput {
    static constexpr std::size_t buffer_size = 1 << 17;
    std::FILE* file_;
    std::array<char, buffer_size> buffer_;
    std::size_t size_ = 0;
    int precision_ = 6;
    bool fixed_ = false, good_ = true;

    void write(std::string_view text) {
        while (!text.empty() && good_) {
            if (size_ == buffer_.size()) flush();
            const auto count = std::min(text.size(), buffer_.size() - size_);
            std::memcpy(buffer_.data() + size_, text.data(), count);
            size_ += count;
            text.remove_prefix(count);
        }
    }

public:
    explicit VerifyOutput(std::FILE* file = stdout) : file_(file) {}
    VerifyOutput(const VerifyOutput&) = delete;
    VerifyOutput& operator=(const VerifyOutput&) = delete;
    ~VerifyOutput() { flush(); }

    explicit operator bool() const noexcept { return good_; }
    bool operator!() const noexcept { return !good_; }

    VerifyOutput& fixed(int digits) {
        if (digits < 0) throw std::invalid_argument("negative output precision");
        fixed_ = true;
        precision_ = digits;
        return *this;
    }

    void flush() noexcept {
        std::size_t written = 0;
        while (written < size_ && good_) {
            const auto count = std::fwrite(buffer_.data() + written, 1, size_ - written, file_);
            if (count == 0) good_ = false;
            written += count;
        }
        size_ = 0;
    }

    template<class T>
        requires (std::is_integral_v<T> && sizeof(T) <= sizeof(std::uint64_t)
                  && !std::is_same_v<T, char>)
    VerifyOutput& operator<<(T value) {
        if constexpr (std::is_same_v<T, bool>) return *this << static_cast<char>('0' + value);
        else {
            char digits[std::numeric_limits<std::uint64_t>::digits10 + 3];
            const auto end = std::to_chars(digits, digits + sizeof(digits), value).ptr;
            write(std::string_view(digits, static_cast<std::size_t>(end - digits)));
            return *this;
        }
    }

    VerifyOutput& operator<<(char value) {
        if (size_ == buffer_.size()) flush();
        if (good_) buffer_[size_++] = value;
        return *this;
    }

    VerifyOutput& operator<<(std::string_view value) { write(value); return *this; }
    VerifyOutput& operator<<(const std::string& value) { write(value); return *this; }
    VerifyOutput& operator<<(const char* value) { write(value); return *this; }

    template<class T> requires std::is_floating_point_v<T>
    VerifyOutput& operator<<(T value) {
        char local[128];
        const char* format = fixed_ ? "%.*Lf" : "%.*Lg";
        const int count = std::snprintf(local, sizeof(local), format, precision_,
                                        static_cast<long double>(value));
        if (count < 0) good_ = false;
        else if (static_cast<std::size_t>(count) < sizeof(local))
            write(std::string_view(local, static_cast<std::size_t>(count)));
        else {
            std::vector<char> text(static_cast<std::size_t>(count) + 1);
            std::snprintf(text.data(), text.size(), format, precision_, static_cast<long double>(value));
            write(std::string_view(text.data(), static_cast<std::size_t>(count)));
        }
        return *this;
    }
};

inline VerifyInput verify_in;
inline VerifyOutput verify_out;
#endif

// SPDX-License-Identifier: CC0-1.0

#include <cstdint>
#include <vector>
int main(){
 int n{},q{};verify_in>>n>>q;std::vector<std::int64_t> values(n);for(auto& value:values)verify_in>>value;Graph graph(n);
 for(int i=1;i<n;++i){int u{},v{};verify_in>>u>>v;graph[u].push_back(v);graph[v].push_back(u);}
 HeavyLightDecomposition hld(graph);std::vector<std::int64_t> ordered(n);for(int v=0;v<n;++v)ordered[hld.index(v)]=values[v];fenwick_tree<std::int64_t> sums(ordered);
 while(q--){int type{};verify_in>>type;if(type==0){int v{};std::int64_t delta{};verify_in>>v>>delta;sums.add(hld.index(v),delta);}else{int u{},v{};verify_in>>u>>v;std::int64_t answer=0;hld.for_each_path(u,v,[&](int l,int r,bool){answer+=sums.sum(l,r);});verify_out<<answer<<'\n';}}
}
