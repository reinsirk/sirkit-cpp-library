# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,subprocess,os,statistics,random,fcntl,shutil,hashlib
D=Path('/tmp/sirkit_hld_owned_20261104/performance');P=Path('/tmp/sirkit_hld_20261104/fixtures');rng=random.Random(202611042);raw=[]
names=['custom_vertex_add_path_sum_32_random','custom_vertex_add_path_sum_4096_random','official_vertex_add_path_sum_max_random_0','official_vertex_add_path_sum_long-path-decomposition_killer_0','official_vertex_add_path_sum_line_0','custom_vertex_add_path_sum_250000_balanced','custom_vertex_add_path_sum_250000_random']
fixtures={f['name']:f for f in json.loads((P/'fixtures.json').read_text())}
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for backend in ['bit','seg']:
   for case in names:
    for rep in range(7):
     labels=['separated','control','owned'];rng.shuffle(labels)
     for label in labels:
      shutil.copyfile(D/f'{cc}_{backend}_{"separated"if label=="control"else label}',D/'active');(D/'active').chmod(0o700)
      with Path(fixtures[case]['path']).open('rb')as fi,(D/'output').open('wb')as fo:
       p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0
      raw.append(dict(compiler=cc,backend=backend,case=case,rep=rep,label=label,cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),max_rss_bytes=ru.ru_maxrss*1024,sha256=hashlib.sha256((D/'output').read_bytes()).hexdigest()))
    rr=[r for r in raw if r['compiler']==cc and r['backend']==backend and r['case']==case];assert len({r['sha256']for r in rr})==1;m={l:statistics.median(r['cpu_ns']for r in rr if r['label']==l)for l in labels};print(cc,backend,case,{k:round(x/m['separated'],4)for k,x in m.items()},flush=True);(D/'owner_benchmark_raw.json').write_text(json.dumps(raw))
ratios=[]
for cc in ['gcc','clang']:
 for backend in ['bit','seg']:
  for case in names:
   rr=[r for r in raw if r['compiler']==cc and r['backend']==backend and r['case']==case];m={l:statistics.median(r['cpu_ns']for r in rr if r['label']==l)for l in ['separated','control','owned']};ratios.append(dict(compiler=cc,backend=backend,case=case,median_cpu_ns=m,owned_over_separated=m['owned']/m['separated'],control_over_separated=m['control']/m['separated']))
(D/'owner_benchmark_summary.json').write_text(json.dumps(ratios,indent=2)+'\n')
