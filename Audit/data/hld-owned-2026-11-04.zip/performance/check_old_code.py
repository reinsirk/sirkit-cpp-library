# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,hashlib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_owned_20261104/performance');B=D.parent/'before';rows=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
for label in ['before','owned']:
 core=(B if label=='before'else R)/'Graph/Heavy_Light_Decomposition.cpp'
 for problem,driver in [('jump','hld_jump_main.cpp'),('sum','hld_vertex_add_path_sum_main.cpp')]:
  main=(B/'Verify/current/drivers'/driver).read_bytes();assert main==(R/'Verify/current/drivers'/driver).read_bytes()
  io=(B/'Verify/current/common/fast_io.hpp').read_bytes();assert io==(R/'Verify/current/common/fast_io.hpp').read_bytes()
  fenwick=(B/'DataStructure/Fenwick_Tree.cpp').read_bytes();assert fenwick==(R/'DataStructure/Fenwick_Tree.cpp').read_bytes()
  code='#define SKIP_RUNTIME_CHECKS\n'+core.read_text()+'\n'+(fenwick.decode()+'\n'if problem=='sum'else'')+io.decode()+'\n'+main.decode().replace('#include "Verify/current/common/fast_io.hpp"','');src=D/f'{problem}_{label}.cpp';src.write_text(code)
  for cc,prefix in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
   exe=D/f'{cc}_{problem}_{label}';cmd=['taskset','-c','4',*prefix,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(src),'-o',str(exe)];subprocess.run(cmd,check=True);obj=D/f'{cc}_{problem}_{label}.text';subprocess.run(['objcopy','--dump-section',f'.text={obj}',str(exe)],check=True);rows.append(dict(label=label,compiler=cc,problem=problem,compile_command=cmd,source_sha256=sha(core.read_bytes()),driver_sha256=sha(main),io_sha256=sha(io),text_sha256=sha(obj.read_bytes())))
for cc in ['gcc','clang']:
 for problem in ['jump','sum']:
  assert (D/f'{cc}_{problem}_before.text').read_bytes()==(D/f'{cc}_{problem}_owned.text').read_bytes(),(cc,problem)
(D/'old_main_equivalence.json').write_text(json.dumps(rows,indent=2)+'\n');print('Existing jump/sum main: GCC/Clang before/after .text identical',flush=True)
