# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_owned_20261104');T=Path('/tmp/sirkit_hld_owned_tests');sha=lambda x:hashlib.sha256(x).hexdigest()
def executable_text(b):return b'\n'.join(x for x in b.splitlines()if not x.lstrip().startswith(b'//'))
s=(R/'Graph/Heavy_Light_Decomposition.cpp').read_bytes();t=(T/'tested.hpp').read_bytes();assert executable_text(s)==executable_text(t)
rows=[dict(scope='canonical_header_vs_sanitizer_snapshot',current_sha256=sha(s),tested_sha256=sha(t),comment_line_free_sha256=sha(executable_text(s)),result='Only full-line comments differ')]
for name in ['hld_jump','hld_vertex_add_path_sum','hld_path_prod','hld_path_composite']:
 a=(R/'Verify/current/submissions'/f'{name}.cpp').read_bytes();b=(D/'tested_submissions'/f'{name}.cpp').read_bytes();assert executable_text(a)==executable_text(b);rows.append(dict(scope=name,current_sha256=sha(a),tested_sha256=sha(b),comment_line_free_sha256=sha(executable_text(a)),result='Only full-line comments differ'))
for p in ['Verify/current/drivers/hld_jump_main.cpp','Verify/current/drivers/hld_vertex_add_path_sum_main.cpp','Verify/current/common/fast_io.hpp','DataStructure/Fenwick_Tree.cpp','DataStructure/Segment_Tree.cpp','DataStructure/Lazy_Segment_Tree.cpp']:
 assert (R/p).read_bytes()==(D/'before'/p).read_bytes(),p
core_before=(D/'before/Graph/Heavy_Light_Decomposition.cpp').read_text().split('class HeavyLightDecomposition {',1)[1].rstrip()
core_after=s.decode().split('class HeavyLightDecomposition {',1)[1].split('#ifndef SIRKIT_HLD_OWNED_RANGE_TRAITS_DEFINED',1)[0]
decl='''    template<class Range, bool Ordered = false, class T>
    HeavyLightValues<Range, Ordered> with_values(const std::vector<T>& values) const &;
    template<class Range, bool Ordered = false, class T>
    HeavyLightValues<Range, Ordered> with_values(const std::vector<T>& values) &&;
'''
assert core_after.count(decl)==1;assert core_after.replace(decl,'').rstrip()==core_before
rows.append(dict(scope='existing_complete_HLD_class',result='All original method definitions and data fields byte-identical; only 2 new factory declarations added'))
(D/'source_equivalence.json').write_text(json.dumps(rows,indent=2)+'\n');print('Existing core unchanged; tested/final source differs only by added API comment')
