# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib,os
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_owned_20261104');rows=[]
for compiler,args in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  exe=D/f'allocation_{compiler}_{int(skip)}';src=R/'Verify/current/tests/hld_owned_allocation_test.cpp';cmd=['taskset','-c','6',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror']+(['-DSKIP_RUNTIME_CHECKS']if skip else[])+[str(src),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','6',str(exe)],text=True,capture_output=True);assert p.returncode==0 and not p.stderr,p.stderr;rows.append(dict(compiler=compiler,skip_runtime_checks=skip,compile_command=cmd,stdout=p.stdout,returncode=p.returncode,stderr=p.stderr,source_sha256=hashlib.sha256((R/'Graph/Heavy_Light_Decomposition.cpp').read_bytes()).hexdigest(),test_sha256=hashlib.sha256(src.read_bytes()).hexdigest()));(D/'allocation_checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(compiler,skip,p.stdout.strip(),flush=True)
