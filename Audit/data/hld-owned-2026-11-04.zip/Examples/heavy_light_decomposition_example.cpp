// SPDX-License-Identifier: CC0-1.0
#include "../Graph/Heavy_Light_Decomposition.cpp"
#include "../DataStructure/Fenwick_Tree.cpp"
#include "../DataStructure/Segment_Tree.cpp"
#include "../DataStructure/Lazy_Segment_Tree.cpp"
#include <cassert>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>
namespace {
std::string concat(std::string a,const std::string& b){a+=b;return a;}
std::string empty_word(){return {};}
struct Total{std::int64_t sum;int length;};
Total combine(Total a,Total b){return {a.sum+b.sum,a.length+b.length};}
Total empty_total(){return {0,0};}
Total add_total(std::int64_t f,Total x){return {x.sum+f*x.length,x.length};}
std::int64_t compose_add(std::int64_t newer,std::int64_t older){return newer+older;}
std::int64_t zero_add(){return 0;}
}
int main(){
 Graph tree{{1,2},{0,3,4},{0},{1},{1}};
 std::vector<std::int64_t> value{1,2,3,4,5};
 auto hld=HeavyLightDecomposition(tree).with_values<fenwick_tree<std::int64_t>>(value);
 assert(hld.lca(3,4)==1&&hld.jump(3,2,2)==0&&hld.kth_ancestor(4,2)==0);
 assert(hld.path_prod(3,2)==10);
 hld.add(3,10);value[3]+=10;
 assert(hld.get(3)==14&&hld.path_prod(3,2)==20&&hld.subtree_prod(1)==21);
 assert(hld.values()==value);
 using Words=segtree<std::string,concat,empty_word>;
 auto words=HeavyLightDecomposition(tree).with_values<Words,true>(std::vector<std::string>{"a","b","c","d","e"});
 assert(words.path_prod(3,2)=="dbac");std::cout<<words.path_prod(3,2)<<'\n';
 words.set(3,"D");assert(words.path_prod(3,2)=="Dbac"&&words.path_prod(2,3)=="cabD");
 using Ranges=lazy_segtree<Total,combine,empty_total,std::int64_t,add_total,compose_add,zero_add>;
 std::vector<Total> initial;for(auto x:value)initial.push_back({x,1});
 auto ranges=HeavyLightDecomposition(tree).with_values<Ranges>(initial);
 ranges.path_apply(3,2,std::int64_t{2});assert(ranges.path_prod(3,2).sum==28);
 ranges.subtree_apply(1,std::int64_t{-1});assert(ranges.path_prod(3,2).sum==26);
 ranges.apply(4,std::int64_t{3});assert(ranges.get(4).sum==7);
}
