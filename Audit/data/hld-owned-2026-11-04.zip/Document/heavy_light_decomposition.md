# 重軽分解

`HeavyLightDecomposition`は木の経路・部分木を配列区間へ変換します。`with_values<Range>(values)`を付けると、指定したBIT／Segtreeも所有し、頂点番号で更新・集計できます。[本体](../Graph/Heavy_Light_Decomposition.cpp)・[使用例](../Examples/heavy_light_decomposition_example.cpp)。

```cpp
Graph tree{{1}, {0,2}, {1}};
std::vector<std::int64_t> value{10,20,30};
auto hld = HeavyLightDecomposition(tree)
    .with_values<fenwick_tree<std::int64_t>>(value);
hld.add(1, 5);
auto sum = hld.path_prod(0, 2);       // 65。
auto subtree = hld.subtree_prod(1);  // 55。
auto x = hld.get(1);                 // 25。
```

## 値を持つHLD

| API | 引数・戻り値 |
| --- | --- |
| `hld.with_values<Range,Ordered=false>(values)` | 頂点番号順の長さNのvectorを渡す。分解・並べ替え・集計器を独立所有する`HeavyLightValues`を返す。一時HLDからは分解を移動、既存HLDからはコピー。 |
| `get(v)` / `set(v,x)` / `add(v,x)` | 頂点の値／代入／加算。addは集計器にaddがある場合のみ。 |
| `apply(v,f)` / `path_apply(u,v,f,edges=false)` / `subtree_apply(v,f,edges=false)` | 点／経路／部分木への作用。対応するapplyを持つ集計器で使用できる。 |
| `path_prod(u,v,edges=false)` / `subtree_prod(v,edges=false)` | 経路／部分木の集計値。集計器の引数や添字変換は不要。 |
| `values()` | 元の頂点番号順のvectorを返す。 |
| `HeavyLightValues<Range,Ordered>(g,values,root=0)` / `HeavyLightValues<Range,Ordered>(layout,values)` | 直接構築も可。layoutはコピーし、std::move(layout)なら移動。 |
| `build(g,values,root=0)` / `clear()` / `swap(other)` | 分解と値を一緒に再構築／空にする／交換する。コピーは独立、move元は空。 |

Rangeには`fenwick_tree<T>`、ACL形式の`segtree<S,op,e>`／`lazy_segtree<S,op,e,F,mapping,composition,id>`を指定します。本体は使用する集計器と一緒に貼り付けます。実際のACLの型も使えます。Mintは利用側が用意します。

既定は可換な演算用です。文字列連結・関数合成などでは`with_values<Range,true>(values)`にすると、逆順用の集計器も内部で管理し、u→vの順に集計します。単位元・結合則は集計器の前提に従います。BITの整数和は型幅で周回します。部分木の積はDFS添字昇順です。

辺の値は親辺を子頂点の位置へ渡し、edges=trueにします。経路ではLCA、部分木では指定頂点を除きます。親・LCA・jumpなどの取得も同じオブジェクトから使えます。頂点更新のvも常に頂点番号です。

## 分解だけを使うAPI

| API | 引数・戻り値 |
| --- | --- |
| `HeavyLightDecomposition(g,root=0)` / `build(g,root=0)` | 対称な隣接リストの無向森を分解。頂点は0..N-1。 |
| `index(v)` / `vertex_at(i)` / `order()` / `reorder(values)` / `restore(ordered)` | 頂点→添字／添字→頂点／並びのconst参照／DFS添字順へコピー／頂点順へコピー。コピー可能なら既定構築は不要。 |
| `for_each_path(u,v,fn,edges=false)` / `path(u,v,edges=false)` | 通行順にfn(l,r,reversed)を呼ぶ／同じInterval配列を返す。別の木はfalse／空。 |
| `subtree_range(v,edges=false)` / `subtree_size(v)` | 部分木の半開区間／頂点数。 |
| `lca(u,v)` / `distance(u,v)` / `kth_ancestor(v,k)` / `jump(u,v,k)` | 最近共通祖先／辺数／k個上／u→vの0始まりk番目。別の木や範囲外の結果は-1。 |
| `parent(v)` / `depth(v)` / `component(v)` / `root_of(v)` | 親（根は-1）／深さ／木の番号／木の根。 |
| `same_component(u,v)` / `is_ancestor(u,v)` / `size()` / `empty()` / `root()` / `component_count()` | 同じ木か／祖先か（自身を含む）／頂点数／空か／指定根（空なら-1）／木の数。 |

区間は[l,r)、reversed=trueはr-1からlへ読みます。従来の外部集計器を渡す`path_prod(u,v,range)`・`subtree_prod(v,range)`・`path_apply(u,v,range,f)`・`subtree_apply(v,range,f)`も使えます。汎用経路積は`path_prod(u,v,identity,query,op[,reverse][,edges])`。queryはprod/sumを持つ集計器か、(l,r)／(l,r,reversed)から値を返す関数です。2引数は可換専用。非可換では向き対応queryか正しいreverseを渡し、併用しません（std::identityは除く）。結果型はqueryから決まります。

## 前提・所有権・計算量

経路集計・更新の両端は同じ木が前提で、検査時は別の木を例外にします。外部集計器を渡す形式では、対応する並び・長さを利用側で用意し、HLDは参照を保持しません。作用・集計器の更新中に例外が出た場合、変更は巻き戻しません。Ordered=trueでは、その後clear/buildで再構築してください。値を持つHLDのbuild・コピー代入失敗時は元を保持します。移動を指定した分解からの構築が失敗すると、移動元の分解が空になる場合があります。

分解・並べ替えはO(N+M)／O(N)。値の構築は集計器のvector構築費用、vector構築のないACL Fenwickは点加算でO(N log N)。通常のBIT／Segtreeでは点・部分木操作O(log N)、経路操作O(log²N)。Ordered=trueは集計器2本分の領域を使い、各更新を両方へ適用します。valuesは集計器のvaluesがあればO(N)で並べ直し、なければN回の点照会です。分解以外に所有状態を1回確保します。

LCA・距離・祖先・jumpはO(log N)、その他の分解情報の取得はO(1)。経路分解はO(log N)、for_each_path／path_prodはHLD側の照会ごとのヒープ確保なし。pathはO(log N)領域を使います。order参照は再構築・代入・破棄で無効になります。

指定根の木から、残りは最小未訪問頂点から構築します。空の入力にはroot=0。探索中に頂点範囲・自己辺・閉路・多重辺を検査し、対称性確認だけの全辺走査はしません。`SKIP_RUNTIME_CHECKS`で入力検査と検査専用状態を除きます。木の形を変える場合、値を持つHLDではbuildへ新しい値も渡します。

[理論参考](https://info.atcoder.jp/entry/algorithm_lectures/heavy_light_decomposition)・[分解の参照試験](../Verify/current/tests/new_hld_reference_test.cpp)・[所有版の参照試験](../Verify/current/tests/hld_owned_test.cpp)
