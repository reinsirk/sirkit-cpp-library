# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib,os
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_owned_tests');source=R/'Graph/Heavy_Light_Decomposition.cpp';test=R/'Verify/current/tests/hld_owned_test.cpp';header=D/'tested.hpp';header.write_bytes(source.read_bytes());rows=[]
for fallback in [False,True]:
 for cc,prefix in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for skip in [False,True]:
   for ranges_first in ([False]if fallback else[False,True]):
    exe=D/f'{cc}_{int(skip)}_{int(ranges_first)}_{int(fallback)}';cmd=['taskset','-c','6',*prefix,'-std=c++23','-O2','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(R/'Verify/current/vendor'),f'-DHLD_SOURCE="{header}"']
    if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
    if ranges_first:cmd+=['-DSIRKIT_HLD_OWNED_RANGES_FIRST']
    if fallback:cmd+=['-U__SIZEOF_INT128__']
    cmd+=[str(test),'-o',str(exe)];cp=subprocess.run(cmd,text=True,capture_output=True);assert cp.returncode==0,cp.stderr
    run=['taskset','-c','6',str(exe)];p=subprocess.run(run,text=True,capture_output=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'});row=dict(compiler=cc,skip_runtime_checks=skip,ranges_first=ranges_first,standard_fallback=fallback,compile_command=cmd,run_command=run,environment_overrides={'ASAN_OPTIONS':'detect_leaks=0'},returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,source_sha256=hashlib.sha256(header.read_bytes()).hexdigest(),test_sha256=hashlib.sha256(test.read_bytes()).hexdigest());rows.append(row);(D/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,skip,ranges_first,fallback,p.returncode,p.stdout.strip(),flush=True);assert p.returncode==0 and not p.stderr,p.stderr
