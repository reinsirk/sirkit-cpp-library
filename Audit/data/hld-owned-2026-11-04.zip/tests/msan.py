# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib,os
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_owned_tests');src=D/'tested.hpp';test=R/'Verify/current/tests/hld_owned_test.cpp';rows=[]
for skip in [False,True]:
 exe=D/f'MSan_{int(skip)}';cmd=['taskset','-c','6','/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-std=c++23','-O1','-Wall','-Wextra','-Werror','-fsanitize=memory','-fsanitize-memory-track-origins=2','-fno-omit-frame-pointer','-fPIE','-pie','-I'+str(R/'Verify/current/vendor'),f'-DHLD_SOURCE="{src}"']
 if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
 cmd+=[str(test),'-o',str(exe)];cp=subprocess.run(cmd,text=True,capture_output=True);assert cp.returncode==0,cp.stderr
 attempts=[];run=['taskset','-c','6',str(exe)];env={'MSAN_OPTIONS':'halt_on_error=1'}
 for attempt in range(8):
  p=subprocess.run(run,text=True,capture_output=True,env={**os.environ,**env});attempts.append(dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
  if p.returncode==0:break
  if 'out of application range'not in p.stderr and'can not mmap the shadow memory'not in p.stderr:break
 row=dict(skip_runtime_checks=skip,compile_command=cmd,run_command=run,environment_overrides=env,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),test_sha256=hashlib.sha256(test.read_bytes()).hexdigest(),attempts=attempts);rows.append(row);(D/'msan.json').write_text(json.dumps(rows,indent=2)+'\n');print(skip,p.returncode,p.stdout.strip(),flush=True);assert p.returncode==0 and not p.stderr,p.stderr
