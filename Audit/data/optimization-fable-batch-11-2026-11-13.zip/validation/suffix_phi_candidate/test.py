from pathlib import Path
import subprocess,json
p=Path(__file__).resolve().parent;r={'tests':[]}
for cc,base in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  for std in [False,True]:
   for v in ['baseline','candidate']:
    name=f'{cc}_{skip}_{std}_{v}';exe=p/(name+'_test');cmd=base+['-std=c++23','-O2','-Wall','-Wextra']+(['-DSKIP_RUNTIME_CHECKS']if skip else [])+(['-DSIRKIT_DISABLE_SIMD','-U__SIZEOF_INT128__']if std else [])+[f'-DSUFFIX_HEADER="{p/(v+".hpp")}"',str(p/'reference.cpp'),'-o',str(exe)];b=subprocess.run(cmd,capture_output=True,text=True,timeout=120);(p/(name+'.build.log')).write_text(b.stdout+b.stderr);assert b.returncode==0,(name,b.stderr)
    q=subprocess.run(['taskset','-c','10',str(exe)],capture_output=True,text=True,timeout=90);row={'name':name,'command':cmd,'returncode':q.returncode,'stdout':q.stdout,'stderr':q.stderr};r['tests'].append(row);(p/'test_results.json').write_text(json.dumps(r,indent=2));assert q.returncode==0,row;print(name,q.stdout.strip(),flush=True)
