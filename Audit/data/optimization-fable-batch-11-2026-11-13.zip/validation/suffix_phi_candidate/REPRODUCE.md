# Phi/PLCP LCP construction: reject

`baseline.hpp` freezes the current `String/Suffix_Array.cpp`. `candidate.hpp` changes only `suffix_lcp`: checked Phi initialized to-2, previous-SA index or-1 stored, text-order PLCP overwrites the same work array, final SA-order scatter fills LCP. `candidate.diff` contains the complete patch. Suffix-array construction is identical, and the separate symbol-width proposal was not included. No repository file was edited.

The checked size, range and duplicate checks, exception messages and skipped-check ownership remain intact. Length overflow checks are unchanged. The API assumes SA is lexicographically correct and still only validates permutation form.

Run from this directory:

```sh
python3 test.py
python3 large_test.py
python3 bench.py
```

GCC15.2 is `/usr/bin/g++`; Clang21 uses GCC15 headers. Timed runs pin CPU10. Saved commands and stdout are in `test_results.json`, `large_results.json` and `bench_results.json`. `test.py` combines a frozen existing ACL API test (explicit return0 added when renaming main) and independent naive SA/LCP checks. It covers all binary strings through length10, random bytes up to128, equal/periodic through1024, generic sequences, boolean proxies, narrow/wide numeric elements, and invalid permutation exceptions.16 configurations pass. The large independent histogram test adds four baseline/candidate compiler runs, through500000 elements and all known LCP values. Total:13,082,208 checks.

`bench.cpp` measures only LCP with SA/input creation outside timing. The actual submission main is separately frozen in `gcc_baseline_main.cpp`, `gcc_candidate_main.cpp`, `clang_baseline_main.cpp`, `clang_candidate_main.cpp`; both compilers use the same source bodies and common IO. The outer CLI uses C++23-O2; there is no per-entry pragma. `bench.py` regenerates these using prepare_verify and the saved body override; when repository driver/IO changes, compile the already-frozen full source files using commands from `bench_results.json` to reproduce this exact experiment.

Two warmups and9 alternating repetitions, candidate/baseline at n500000:

| Compiler | random core / whole | equal core / whole | smallalpha core / whole |
| --- | --- | --- | --- |
| GCC15.2 | .780 / .951 | 1.269 / 1.039 | .792 / .946 |
| Clang21 | .819 / .961 | 1.086 / 1.015 | .810 / .956 |

Both compilers also regress equal1024 core (GCC1.574, Clang1.046). Small full-program measurements are startup-dominated and are not interpreted as improvements. Baseline/candidate output matches for all18 timed full-program cases. The all-equal maximum answer is500000 as expected. Core timing includes result allocation/destruction and checksum use; full timing records child CPU and wall separately. Local timings are not converted into judge-time claims.

The proposal requires improvement without any case regressing. Clear all-equal regressions fail that gate, so Phi is rejected. Source API descriptions do not name Kasai. Document/suffix_array.md line28 currently names rank construction and would require neutral wording if this algorithm were adopted, but the rejected experiment requires no product-documentation change.
