from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
test=json.loads((p/'test_results.json').read_text())
large=json.loads((p/'large_results.json').read_text())
bench=json.loads((p/'bench_results.json').read_text())
small=sum(int(x['stdout'].split('independent checks=')[1])for x in test['tests'])
big=sum(int(x['stdout'].split('checks=')[1])for x in large['tests'])
r={
 'decision':'reject',
 'reason':'Phi improves random/small-alphabet LCP but regresses all-equal inputs on both compilers: GCC core+26.9%, full-program+3.9%; Clang core+8.6%, full-program+1.5% at n500000. Required all-case nonregression fails.',
 'id':'suffix_array_substrings',
 'scope':'suffix_lcp body only; suffix-array construction, driver, IO and flags frozen. Separate SA-width proposal not combined. No repository edits.',
 'source':{
  'path':'String/Suffix_Array.cpp',
  'baseline_sha':sha((p/'baseline.hpp').read_bytes()),
  'candidate_sha':sha((p/'candidate.hpp').read_bytes()),
  'repo_still_baseline':Path('/home/reinsirk/Atcoder_Env/String/Suffix_Array.cpp').read_bytes()==(p/'baseline.hpp').read_bytes(),
  'driver_sha':sha((p/'frozen/Verify/current/drivers/suffix_array_substrings_main.cpp').read_bytes()),
  'io_sha':sha((p/'frozen/Verify/current/common/fast_io.hpp').read_bytes())},
 'implementation':{
  'change':'Replace inverse-rank/Kasai-successor loop with phi predecessor, PLCP overwrite in text order, final SA-order scatter. One O(n) work array preserved. Checked sentinel -2, predecessor sentinel -1.',
  'capacity':'Original suffix_length_check retained in checked and skip; integer bounds and comparison-loop n-i/n-j checks unchanged.',
  'validation':'Size check before empty return, range/duplicate permutation checks before predecessor assignment, exception types/messages retained. No lexicographic correctness recheck added.',
  'ownership':'vector checked / make_unique_for_overwrite skip work array retained. Input s and sa stay read-only.'},
 'correctness':{
  'status':'PASS',
  'small_api_matrix':'baseline/candidate × GCC15.2/Clang21 × checked/skip × default/standard SIMD-disabled and int128-disabled',
  'small_api_build_runs':len(test['tests']),
  'small_api_checks':small,
  'small_reference':'Independent naive SA and pairwise LCP: all binary strings through length10;2500 random byte/small-alphabet strings up to128; equal/periodic through1024; string/view/span/vector; existing array/vector<bool>/noncopyable equality-proxy API tests; n0,1,2; exact invalid size/range/duplicate exception messages.',
  'large_build_runs':len(large['tests']),
  'large_checks':big,
  'large_reference':'Existing independent histogram test through500000: increasing/decreasing/shuffled distinct values and periods1/256/257; known SA and every adjacent LCP verified on int and wide vectors.',
  'total_checks':small+big,
  'raw':['test_results.json','large_results.json']},
 'measurements':{
  'conditions':bench['conditions'],
  'compilers':['/usr/bin/g++15.2','/usr/bin/clang++21 with GCC15 headers'],
  'sizes':[32,1024,500000],
  'shapes':['random26','equal','smallalphabet2'],
  'core':'steady_clock ns per lcp_array call including return-vector allocation/destruction and checksum consumption. Suffix_array construction and input generation outside timer. Same SA for both.',
  'whole':'Actual frozen main from prepare_verify.render source override, stdin file to stdout pipe. Child user+sys CPU nanoseconds and wall raw saved. No per-entry GCC pragma present. Same commonIO and flags.',
  'full_outputs':'Baseline/candidate outputs identical in all18 compiler/shape/size cases; large equal has expected answer500000.',
  'core_ratios':{k:v['ratio']for k,v in bench['core'].items()},
  'whole_ratios':{k:v['ratio']for k,v in bench['whole'].items()},
  'raw':'bench_results.json',
  'limits':'Small full-program durations dominated by process startup; tiny ratios around1 are not treated as improvement. Local timing is not an online-time prediction.'},
 'documentation':{
  'source_top':'Lists behavior, validation and O(n) only, no algorithm-name change needed.',
  'document':'Document/suffix_array.md line28 says rank構築中; would need a neutral 補助配列の構築中 wording if Phi adopted. Rejected candidate leaves production Document unchanged.',
  'examples':'API and outputs unchanged; no Example change would be needed.'},
 'artifacts':str(p),
 'reproduction':'REPRODUCE.md'}
(p/'review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
print(small,big,small+big)
