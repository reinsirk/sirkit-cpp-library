from pathlib import Path
import subprocess,json,statistics,sys,time,resource,hashlib
p=Path(__file__).resolve().parent;root=Path('/home/reinsirk/Atcoder_Env');sys.path.insert(0,str(root/'Scripts'));import prepare_verify as pv
entry=next(e for e in pv.collect()if e['id']=='suffix_array_substrings');(p/'entry.json').write_text(json.dumps(entry,indent=2));r={'builds':[],'core':{},'whole':{},'conditions':{'warmups':2,'repetitions':9,'cpu':10,'cli_flags':'C++23 -O2','full_source_settings':pv.gcc_optimization(entry)}}
inputs={}
for n in [32,1024,500000]:
 for shape in ['random','equal','smallalpha']:
  state=917;s=[]
  for _ in range(n):
   state^=(state<<13)&((1<<64)-1);state^=state>>7;state^=(state<<17)&((1<<64)-1);s.append(chr(97+(state%(26 if shape=='random'else 2)))if shape!='equal'else'a')
  f=p/f'{shape}_{n}.in';f.write_text(''.join(s)+'\n');inputs[shape,n]=f
for cc,base in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for v in ['baseline','candidate']:
  cmd=base+['-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS',f'-DHEADER="{p/(v+".hpp")}"',str(p/'bench.cpp'),'-o',str(p/f'{cc}_{v}_core')];subprocess.run(cmd,capture_output=True,check=True,timeout=120);r['builds'].append(cmd)
  data=pv.render(entry,source_overrides={'String/Suffix_Array.cpp':(p/(v+'.hpp')).read_bytes()})[0];src=p/f'{cc}_{v}_main.cpp';src.write_bytes(data);cmd=base+['-std=c++23','-O2',str(src),'-o',str(p/f'{cc}_{v}_main')];subprocess.run(cmd,capture_output=True,check=True,timeout=120);r['builds'].append(cmd)
 for (shape,n),inputfile in inputs.items():
  rep=10000 if n==32 else 1000 if n==1024 else 5
  raw={v:[]for v in ['baseline','candidate']};out=set()
  for i in range(11):
   for v in (['baseline','candidate']if i%2 else ['candidate','baseline']):
    q=subprocess.run(['taskset','-c','10',str(p/f'{cc}_{v}_core'),shape,str(n),str(rep)],capture_output=True,text=True,check=True,timeout=90);ns,sum_=q.stdout.split();out.add(sum_)
    if i>=2:raw[v].append(float(ns))
  assert len(out)==1;med={v:statistics.median(x)for v,x in raw.items()};r['core'][f'{cc}_{shape}_{n}']={'raw_ns':raw,'medians_ns':med,'ratio':med['candidate']/med['baseline'],'checksum':list(out)}
  raw={v:[]for v in ['baseline','candidate']};wall={v:[]for v in raw};out=set()
  for i in range(11):
   for v in (['baseline','candidate']if i%2 else ['candidate','baseline']):
    with inputfile.open('rb')as inp:
     before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.perf_counter_ns();q=subprocess.run(['taskset','-c','10',str(p/f'{cc}_{v}_main')],stdin=inp,capture_output=True,check=True,timeout=90);elapsed=time.perf_counter_ns()-start;after=resource.getrusage(resource.RUSAGE_CHILDREN)
    out.add(q.stdout.decode().strip())
    if i>=2:raw[v].append((after.ru_utime-before.ru_utime+after.ru_stime-before.ru_stime)*1e9);wall[v].append(elapsed)
  assert len(out)==1;med={v:statistics.median(x)for v,x in raw.items()};r['whole'][f'{cc}_{shape}_{n}']={'raw_cpu_ns':raw,'raw_wall_ns':wall,'median_cpu_ns':med,'ratio':med['candidate']/med['baseline'],'output':list(out),'input_sha':hashlib.sha256(inputfile.read_bytes()).hexdigest()};(p/'bench_results.json').write_text(json.dumps(r,indent=2));print(cc,shape,n,'core',r['core'][f'{cc}_{shape}_{n}']['ratio'],'whole',r['whole'][f'{cc}_{shape}_{n}']['ratio'],flush=True)
