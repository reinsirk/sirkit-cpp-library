#include <iostream>
#define main existing_suffix_api_main
#include "api_with_return.cpp"
#undef main
#include <random>
void string_case(const std::string&s){auto sa=naive_sa(s),expected=naive_lcp(s,sa);check(lcp_array(s,sa)==expected);check(lcp_array(std::string_view(s),sa)==expected);check(lcp_array(std::span<const char>(s),sa)==expected);std::vector<int> v;for(unsigned char c:s)v.push_back(c);check(lcp_array(v,sa)==expected);}
int main(){existing_suffix_api_main();
 for(int n=0;n<=10;++n)for(int mask=0;mask<(1<<n);++mask){std::string s(n,'a');for(int i=0;i<n;++i)s[i]=char('a'+((mask>>i)&1));string_case(s);}
 std::mt19937_64 rng(911);for(int trial=0;trial<2500;++trial){int n=int(rng()%129);std::string s(n,'a');for(auto&c:s)c=char(rng()%(trial%3==0?2:trial%3==1?4:256));string_case(s);}
 for(int n:{0,1,2,3,7,63,128,257,1024}){string_case(std::string(n,'a'));std::string s(n,'a');for(int i=0;i<n;++i)s[i]=char('a'+(i%7));string_case(s);}
#ifndef SKIP_RUNTIME_CHECKS
 auto invalid=[](std::string s,std::vector<int>sa,const char*msg){bool caught=false;try{(void)lcp_array(s,sa);}catch(const std::invalid_argument&e){caught=std::string(e.what())==msg;}check(caught);};
 invalid("",{0},"lcp_array: size");invalid("a",{},"lcp_array: size");invalid("a",{-1},"lcp_array: suffix permutation");invalid("a",{1},"lcp_array: suffix permutation");invalid("aaa",{2,2,0},"lcp_array: suffix permutation");invalid("aaa",{0,-1,2},"lcp_array: suffix permutation");invalid("aaa",{0,3,2},"lcp_array: suffix permutation");
#endif
 std::cout<<"independent checks="<<checks<<'\n';}
