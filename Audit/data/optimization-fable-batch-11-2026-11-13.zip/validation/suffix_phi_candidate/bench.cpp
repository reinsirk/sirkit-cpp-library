#include HEADER
#include <chrono>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>
int main(int argc,char**argv){if(argc!=4)return 2;const std::string shape=argv[1];int n=std::stoi(argv[2]),rep=std::stoi(argv[3]);std::string s(n,'a');std::uint64_t state=917;for(char&c:s){state^=state<<13;state^=state>>7;state^=state<<17;if(shape=="random")c=char('a'+state%26);if(shape=="smallalpha")c=char('a'+state%2);}const auto sa=suffix_array(s);std::uint64_t sum=0;const auto start=std::chrono::steady_clock::now();for(int r=0;r<rep;++r){auto lcp=lcp_array(s,sa);for(auto x:lcp)sum+=static_cast<std::uint64_t>(x);}const auto end=std::chrono::steady_clock::now();std::cout<<std::chrono::duration<double,std::nano>(end-start).count()/rep<<' '<<sum<<'\n';}
