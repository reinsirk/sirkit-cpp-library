from pathlib import Path
import subprocess,json
p=Path(__file__).resolve().parent;r={'tests':[]}
for cc,base in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for v in ['baseline','candidate']:
  exe=p/f'{cc}_{v}_histogram';cmd=base+['-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS',f'-DSUFFIX_HEADER="{p/(v+".hpp")}"',str(p/'frozen/Verify/current/tests/suffix_histogram_reference_test.cpp'),'-o',str(exe)];subprocess.run(cmd,capture_output=True,check=True,timeout=120);q=subprocess.run(['taskset','-c','10',str(exe)],capture_output=True,text=True,check=True,timeout=120);r['tests'].append({'name':cc+'_'+v,'command':cmd,'stdout':q.stdout,'returncode':q.returncode});print(cc,v,q.stdout.strip(),flush=True)
(p/'large_results.json').write_text(json.dumps(r,indent=2))
