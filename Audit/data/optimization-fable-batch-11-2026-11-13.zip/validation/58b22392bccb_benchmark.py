from pathlib import Path
import json,sys,subprocess,hashlib,re,random,time,statistics,shutil
W=Path(__file__).parent;P=W.parent;R=Path('/home/reinsirk/Atcoder_Env');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
rows=[];meta=[]
def save():(W/'results.json').write_text(json.dumps({'cpu':11,'compiler':subprocess.check_output(['/usr/bin/g++','--version'],text=True).splitlines()[0],'scope':'Actual generator no pragma/O3/O3,unroll-loops, same fixed SA16candidate/body/main/commonI/O/SKIP/NDEBUG. CLI C++23 O2 all.2warm+9 shuffled alternating copies at one executable path.','sources':meta,'results':rows},indent=2)+'\n')
for ident in ['suffix_array','suffix_array_substrings']:
 entry=next(e for e in pv.collect() if e['id']==ident);sources={};bins={}
 for label,opt in [('none',None),('O3','O3'),('O3_unroll','O3,unroll-loops')]:
  e=dict(entry);e.pop('gcc_optimization',None)
  if opt:e['gcc_optimization']=opt
  sources[label]=pv.render(e,source_overrides={'String/Suffix_Array.cpp':(P/'candidate.hpp').read_bytes()})[0]
 strip=lambda s:re.sub(rb'#if defined\(__GNUC__\) && !defined\(__clang__\)\n#pragma GCC optimize\([^\n]+\)\n#endif\n',b'',s)
 assert len({hashlib.sha256(strip(s)).hexdigest() for s in sources.values()})==1
 assert sources['none']==(P/(ident+'_candidate.cpp')).read_bytes()
 meta.append({'id':ident,'nonpragma_bytes_identical':True,'none_matches_frozen_submission':True,'source_sha256':{k:hashlib.sha256(v).hexdigest() for k,v in sources.items()}})
 for label,data in sources.items():
  src=W/f'{ident}_{label}.cpp';src.write_bytes(data);exe=W/f'{ident}_{label}';cmd=['taskset','-c','11','/usr/bin/g++','-std=c++23','-O2',str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;bins[label]=exe;rows.append({'kind':'build','id':ident,'label':label,'command':cmd,'passed':True});save()
 for case in ['random','equal','fibonacci','smallalpha']:
  inp=P/'inputs'/(case+'.in');outputs={}
  for label,exe in bins.items():
   p=subprocess.run(['taskset','-c','11',str(exe)],input=inp.read_bytes(),capture_output=True);assert p.returncode==0,p.stderr;outputs[label]=p.stdout
  assert len(set(outputs.values()))==1
  raw={k:[] for k in bins};rng=random.Random(191138)
  for rep in range(11):
   order=list(raw);rng.shuffle(order)
   for label in order:
    active=W/'active';shutil.copyfile(bins[label],active);active.chmod(0o755)
    with inp.open('rb') as fi,open('/dev/null','wb') as fo:
     start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','11',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
    assert p.returncode==0,p.stderr
    if rep>=2:raw[label].append(elapsed)
  med={k:statistics.median(v) for k,v in raw.items()};rows.append({'kind':'timing','id':ident,'case':case,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'output_byte_identical':True,'output_sha256':hashlib.sha256(outputs['none']).hexdigest(),'raw_ns':raw,'median_ns':med,'relative_to_none':{k:v/med['none'] for k,v in med.items()}});save();print(ident,case,{k:round(v/1e6,3) for k,v in med.items()},flush=True)
