# Adopted SA16 source with final GCC settings: local validation

`results.json` records24 passing C++23 build/sample configurations and36 passing sample executions. The adopted body SHA256 remains `5181f7ea403f75f5f9c3f8694d4ca8a5751ec6a3adabc0e1a5aaaf67ff20ac2a`.

The source generator now embeds GCC-only optimization pragmas: `suffix_array` uses `O3,unroll-loops`; `suffix_array_substrings` uses `O3`. Clang ignores these pragmas under the generator condition. The outer compile CLI remains C++23-O2. Body, both drivers and common IO hashes match the previous validation, which is retained unchanged under `../root_final_validation/`.

Normal2IDs × GCC15.2/Clang21 × checked/skip × default/standard fallback give16 configurations. These run `ci_verify.py --id suffix_array --id suffix_array_substrings --skip-sync`; generated-submission synchronization remains checked. The four generated submission profiles for both IDs add8 configurations. Fast builds retain their valid-input skip contract. The temporary profile helper copy adds CPU10 affinity, timeouts and compiler/command metadata; the original helper remains unchanged.

The four raw normal JSON files store tested-source hashes, flags, exact compiler commands and checker outcomes. `profiles/results.json` stores all eight generated-source hashes, compiler versions, commands and sample results; profile source copies remain in `profiles/`. `results.json` includes body, driver, IO, manifests, normal and profile source hashes before/after, the settings map and previous-validation comparison. All watched hashes remain unchanged during this run.

No repository file was edited. This is local build/sample validation and does not claim online AC. To reproduce the exact code, use the frozen profile source copies and commands in the raw results; normal sources are tied to their tested-source hash and root snapshot. `validate.py` checks the expected body and settings before starting and requires the `profiles/` output directory not to exist. Use a new output folder for a new run. All compile and runtime processes inherit CPU10 affinity.
