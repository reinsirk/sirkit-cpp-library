from pathlib import Path
import sys,random,json,subprocess,statistics,time,hashlib,os
sys.dont_write_bytecode=True;R=Path('/home/reinsirk/Atcoder_Env');sys.path.insert(0,str(R));from Scripts import prepare_verify as p
W=Path(__file__).parent;os.sched_setaffinity(0,{13});sha=lambda b:hashlib.sha256(b).hexdigest();e=next(e for e in p.collect() if e['id']=='trie_dictionary');driver=(R/e['driver']).read_text();candidate=driver.replace('    Trie dictionary;','    Trie dictionary;\n    dictionary.reserve_nodes(static_cast<std::size_t>(n) * 10 + 1);');assert candidate!=driver;(W/'candidate_driver.cpp').write_text(candidate)
rng=random.Random(20261113);cases={};n=200000
for k,words in [('random10',[''.join(rng.choices('abcdefghijklmnopqrstuvwxyz',k=10)) for _ in range(n)]),('duplicate',['aaaaaaaaaa']*n),('short',[''.join(rng.choices('abcdefghijklmnopqrstuvwxyz',k=2)) for _ in range(n)]),('mixed',['abcdefghij' if i%3 else str(i%1000) for i in range(n)]),('small',['a','b','a'])]:
 data=(str(len(words))+'\n'+'\n'.join(words)+'\n').encode();f=W/(k+'.in');f.write_bytes(data);cases[k]=(f,str(len(set(words))))
report={'baseline_driver_sha256':sha(driver.encode()),'candidate_driver_sha256':sha(candidate.encode()),'io_sha256':sha((R/'Verify/current/common/fast_io.hpp').read_bytes()),'cpu':13,'main_only':True,'repository_changed':False,'compiler':{},'correctness':[],'measurements':[]}
def save():(W/'report.json').write_text(json.dumps(report,indent=2)+'\n')
for c,cmd in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 report['compiler'][c]=subprocess.check_output([cmd[0],'--version'],text=True).splitlines()[0];bins={}
 for stage,d in [('baseline',driver),('candidate',candidate)]:
  for skip in [False,True]:
   data,_=p.render(e,driver_override=d,skip_runtime_checks=skip);src=W/(c+stage+str(skip)+'.cpp');src.write_bytes(data);exe=src.with_suffix('');q=subprocess.run([*cmd,'-std=c++23','-O2',str(src),'-o',str(exe)],capture_output=True,text=True);assert q.returncode==0,q.stderr
   for name,(f,expected) in cases.items():
    with f.open('rb') as inp:q=subprocess.run([str(exe)],stdin=inp,capture_output=True,text=True,check=True)
    assert q.stdout.strip()==expected;(report['correctness']).append({'compiler':c,'stage':stage,'skip':skip,'case':name,'passed':True})
   if skip:bins[stage]=exe
 for name,(f,expected) in cases.items():
  raw={s:[] for s in bins};rss={s:[] for s in bins}
  for i in range(11):
   for s in (list(bins) if i%2==0 else list(reversed(bins))):
    with f.open('rb') as inp:
     t=time.perf_counter_ns();subprocess.run([str(bins[s])],stdin=inp,stdout=subprocess.DEVNULL,check=True);t=time.perf_counter_ns()-t
    if i>=2:raw[s].append(t)
  for s in bins:
   for i in range(3):
    with f.open('rb') as inp:q=subprocess.run(['/usr/bin/time','-f','%M',str(bins[s])],stdin=inp,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True,check=True)
    rss[s].append(int(q.stderr.strip()))
  med={s:statistics.median(v)/1e6 for s,v in raw.items()};row={'compiler':c,'case':name,'input_sha256':sha(f.read_bytes()),'raw_ns':raw,'median_ms':med,'ratio':med['candidate']/med['baseline'],'rss_kib':rss};report['measurements'].append(row);save();print(c,name,round(row['ratio'],3),rss,flush=True)
report['finished']=True;save()
