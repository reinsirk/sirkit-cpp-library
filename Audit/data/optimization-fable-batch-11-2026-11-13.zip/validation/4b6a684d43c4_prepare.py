from pathlib import Path
import json,hashlib,shutil,sys,random
R=Path('/home/reinsirk/Atcoder_Env');W=Path(__file__).parent;old=((W/'baseline.hpp') if (W/'baseline.hpp').exists() else R/'String/Suffix_Array.cpp').read_text();s=old
s=s.replace('inline std::vector<int> suffix_induced(std::span<const int> symbols, int alphabet) {','template<class Symbol> std::vector<int> suffix_induced(std::span<const Symbol> symbols, int alphabet) {',1)
s=s.replace('suffix_induced(reduced, name)','suffix_induced(std::span<const int>(reduced), name)')
s=s.replace('auto encoded = std::make_unique_for_overwrite<int[]>(s.size() + 1);','auto encoded = std::make_unique_for_overwrite<std::uint16_t[]>(s.size() + 1);',1)
s=s.replace('encoded[i] = static_cast<unsigned char>(s[i]) + 1;','encoded[i] = static_cast<std::uint16_t>(static_cast<unsigned char>(s[i]) + 1);',1)
s=s.replace('std::span<const int>(encoded.get(), s.size() + 1), 256','std::span<const std::uint16_t>(encoded.get(), s.size() + 1), 256',1)
s=s.replace('suffix_induced(encoded, upper + 1)','suffix_induced(std::span<const int>(encoded), upper + 1)').replace('suffix_induced(encoded, static_cast<int>(alphabet.size()))','suffix_induced(std::span<const int>(encoded), static_cast<int>(alphabet.size()))').replace('suffix_induced(encoded, alphabet)','suffix_induced(std::span<const int>(encoded), alphabet)')
assert s[s.index('#ifndef SIRKIT_LCP_ARRAY_IMPL_DEFINED'):]==old[old.index('#ifndef SIRKIT_LCP_ARRAY_IMPL_DEFINED'):]
(W/'baseline.hpp').write_text(old);(W/'candidate.hpp').write_text(s)
for name in ['suffix_array_acl_api_test','suffix_histogram_reference_test']:shutil.copyfile(R/'Verify/current/tests'/f'{name}.cpp',W/'frozen_tests'/f'{name}.cpp')
large=(R/'Verify/current/tests/suffix_ntt_large_reference_test.cpp').read_text();large=large[:large.index('NTT<>engine')]+'''std::printf("large SA independent doubling checks=%ju\\n",static_cast<std::uintmax_t>(checks));}\n''';large=large.replace('#include NTT_HEADER','');(W/'frozen_tests/suffix_large_doubling_test.cpp').write_text(large)
sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv;meta=[]
for ident in ['suffix_array','suffix_array_substrings']:
 cached=json.loads((W/'metadata.json').read_text()) if (W/'metadata.json').exists() else []
 e=next((x['entry'] for x in cached if x['id']==ident and x['label']=='baseline'),None) or next(e for e in pv.collect() if e['id']==ident)
 for label in ['baseline','candidate']:
  data=pv.render(e,source_overrides={'String/Suffix_Array.cpp':(W/(label+'.hpp')).read_bytes()})[0];(W/(ident+'_'+label+'.cpp')).write_bytes(data);meta.append({'id':ident,'label':label,'entry':e,'library_sha256':hashlib.sha256((W/(label+'.hpp')).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(data).hexdigest()})
(W/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
D=Path('/tmp/sirkit_remaining_20261113');shutil.copyfile(D/'input_suffix_array_equal_500000.txt',W/'inputs/equal.in');shutil.copyfile(D/'input_suffix_array_random_500000.txt',W/'inputs/smallalpha.in')
rng=random.Random(123891);n=500000;(W/'inputs/random.in').write_text(''.join(chr(97+rng.randrange(26)) for _ in range(n))+'\n')
a,b='a','b'
while len(b)<n:a,b=b,a+b
(W/'inputs/fibonacci.in').write_text(b[:n]+'\n')
(W/'inputs/small.in').write_text('banana\n')
(W/'preservation.json').write_text(json.dumps({'baseline_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(s.encode()).hexdigest(),'lcp_and_search_public_tail_byte_identical':True,'symbol_storage':'Top string encoded(n+1) int4B→uint16_t2B, symbols1..256 plus unique sentinel0. Recursive reduced symbols and all integer paths remainint32.','inputs':'500000-byte maximum-family inputs: existing equal/smallalphabet files plus deterministic26-letter random and Fibonacci word prefix, stored with frozen hashes.'},indent=2)+'\n')
