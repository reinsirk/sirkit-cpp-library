from pathlib import Path
import sys,json,subprocess,os,hashlib
sys.dont_write_bytecode=True
R=Path('/home/reinsirk/Atcoder_Env');sys.path.insert(0,str(R));from Scripts import prepare_verify as p
W=Path(sys.argv[1]);ids=set(sys.argv[2:]);W.mkdir(parents=True,exist_ok=False);os.sched_setaffinity(0,{10})
entries={e['id']:e for e in p.collect()};profiles=[x for x in json.loads((R/'Variants/verify_manifest.json').read_text())['entries'] if x['id'] in ids];assert len(profiles)==len(ids)*4
rows=[];sha=lambda x:hashlib.sha256(x).hexdigest()
for v in profiles:
 name=v['id']+'_'+v['compiler']+('_fast' if v['fast'] else '_checkedbody');source=(R/v['path']).read_bytes();assert sha(source)==v['sha256'];cpp=W/(name+'.cpp');cpp.write_bytes(source);exe=W/name;cmd=['/usr/bin/g++'] if v['compiler']=='GCC' else ['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
 q=subprocess.run([*cmd,'-std=c++23','-O2','-Wall','-Wextra',str(cpp),'-o',str(exe)],capture_output=True,text=True,timeout=180);row={'id':v['id'],'path':v['path'],'compiler':v['compiler'],'fast':v['fast'],'source_sha256':sha(source),'compile_returncode':q.returncode,'compiler_stderr':q.stderr,'command':[*cmd,'-std=c++23','-O2','-Wall','-Wextra',str(cpp),'-o',str(exe)],'compiler_version':subprocess.check_output([cmd[0],'--version'],text=True).splitlines()[0],'skip_runtime_checks':source.startswith(b'#define SKIP_RUNTIME_CHECKS'),'samples':[]};assert q.returncode==0,row
 for sample in entries[v['id']]['samples']:
  q=subprocess.run([str(exe)],input=sample['input'],capture_output=True,text=True,timeout=60);row['samples'].append({'input':sample['input'],'output':q.stdout,'passed':q.returncode==0 and p.matches(entries[v['id']],sample,q.stdout)});assert row['samples'][-1]['passed'],row
 row['passed']=True;rows.append(row);(W/'results.json').write_text(json.dumps({'status':'running','rows':rows},indent=2)+'\n');print(name,'PASS',flush=True)
(W/'results.json').write_text(json.dumps({'status':'passed','build_configurations':len(rows),'sample_executions':sum(len(x['samples']) for x in rows),'rows':rows},indent=2)+'\n')
