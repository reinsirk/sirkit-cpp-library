from pathlib import Path
import subprocess,json,hashlib,sys
W=Path(__file__).parent;rows=[];(W/'bin').mkdir(exist_ok=True);quick='--quick' in sys.argv
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 if quick and cc!='gcc':continue
 for mode,flags in [('checked',[]),('skip',['-DSKIP_RUNTIME_CHECKS']),('standard_checked',['-DSIRKIT_DISABLE_SIMD','-DSIRKIT_FORCE_STANDARD_ARITHMETIC']),('standard_skip',['-DSIRKIT_DISABLE_SIMD','-DSIRKIT_FORCE_STANDARD_ARITHMETIC','-DSKIP_RUNTIME_CHECKS'])]:
  if quick and mode!='checked':continue
  sources=[W/'byte_reference_test.cpp',W/'frozen_tests/suffix_array_acl_api_test.cpp'] if quick else [W/'byte_reference_test.cpp',*sorted((W/'frozen_tests').glob('*.cpp'))]
  for src in sources:
   exe=W/'bin'/f'{cc}_{mode}_{src.stem}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',*flags,'-DSUFFIX_HEADER="'+str(W/'candidate.hpp')+'"',str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','11',str(exe)],capture_output=True,text=True);rows.append({'compiler':cc,'mode':mode,'command':cmd,'test':src.name,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((W/'candidate.hpp').read_bytes()).hexdigest(),'passed':p.returncode==0,'stdout':p.stdout,'stderr':p.stderr});(W/('quick_results.json' if quick else 'test_results.json')).write_text(json.dumps(rows,indent=2)+'\n');print(cc,mode,src.stem,p.stdout.strip()[:120],flush=True);assert p.returncode==0,p.stderr
