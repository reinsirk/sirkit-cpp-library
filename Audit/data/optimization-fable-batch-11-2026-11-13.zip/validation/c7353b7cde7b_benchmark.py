from pathlib import Path
import subprocess,json,hashlib,statistics,random,time,shutil
W=Path(__file__).parent;rows=[];cases=['random','equal','fibonacci','smallalpha','small']
def save():(W/'benchmark_results.json').write_text(json.dumps({'cpu':11,'scope':'Exact frozen suffix_array/suffix_array_substrings current Verify mains/commonI/O/compileprefix; only16-bit top string symbols differ, integer recursion and LCP source unchanged. C++23 O2 CLI,2warm+9 shuffled alternating copies at same executable path.','results':rows},indent=2)+'\n')
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for ident in ['suffix_array','suffix_array_substrings']:
  bins={}
  for label in ['baseline','candidate']:
   src=W/(ident+'_'+label+'.cpp');exe=W/'bin'/f'{cc}_{ident}_{label}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;bins[label]=exe;rows.append({'kind':'build','compiler':cc,'id':ident,'label':label,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'passed':True});save()
  for case in cases:
   inp=W/'inputs'/(case+'.in');data=inp.read_bytes();outputs={}
   for label,exe in bins.items():
    p=subprocess.run(['taskset','-c','11',str(exe)],input=data,capture_output=True);assert p.returncode==0,p.stderr;outputs[label]=p.stdout
   assert outputs['baseline']==outputs['candidate'],(cc,ident,case)
   raw={k:[] for k in bins};rng=random.Random(813617)
   for rep in range(11):
    order=list(raw);rng.shuffle(order)
    for label in order:
     active=W/'bin/active';shutil.copyfile(bins[label],active);active.chmod(0o755)
     with inp.open('rb') as fi,open('/dev/null','wb') as fo:
      start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','11',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
     assert p.returncode==0,p.stderr
     if rep>=2:raw[label].append(elapsed)
   med={k:statistics.median(v) for k,v in raw.items()};rows.append({'kind':'timing','compiler':cc,'id':ident,'case':case,'input_sha256':hashlib.sha256(data).hexdigest(),'output_sha256':hashlib.sha256(outputs['baseline']).hexdigest(),'output_byte_identical':True,'raw_ns':raw,'median_ns':med,'ratio':med['candidate']/med['baseline']});save();print(cc,ident,case,{k:round(v/1e6,3) for k,v in med.items()},flush=True)
