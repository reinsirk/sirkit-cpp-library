# SA文字列記号16bit化：採用

文字列の記号1..256と終端0だけuint16_tへ縮め、再帰列と整数版はintのままにした。公開API・LCP以下は不変で、他agentのLCP案は組み合わせていない。50万文字の先頭記号配列だけ約1MB削減し、SA全体の領域半減とは主張しない。

32構成の全API・全byte・整数500000長・周期境界・検索・独立doubling検証に全成功した。両Verifyの最大4種×GCC/Clang全16条件で約1.7〜4.3%短縮、全文出力一致。最大50万文字は[公式parameter](https://raw.githubusercontent.com/yosupo06/library-checker-problems/master/string/suffixarray/info.toml)で確認した。

GCC最終設定はsuffix_arrayがO3,unroll-loops、suffix_array_substringsがO3。実pragmaだけの比較で各選択はnoneより4種すべて短縮した。substringのunrollはrandomで回帰するため使わない。コンパイラ効果を本体の効果に混ぜない。

agentはrepo未編集。rootが候補5181f7ea...と設定を採用し、派生・最終検証を進めている。[SourceSHA・全測定・再現資料](final_report.json)。
