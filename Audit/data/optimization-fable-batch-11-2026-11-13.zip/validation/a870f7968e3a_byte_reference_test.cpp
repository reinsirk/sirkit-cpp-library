// SPDX-License-Identifier: CC0-1.0
#include SUFFIX_HEADER
#include <numeric>
#include <random>
#include <cstdio>
#include <cstdlib>
#include <cstring>
static std::uint64_t checks=0;
static void check(bool b){++checks;if(!b)std::abort();}
static std::vector<int> naive(std::string_view s){std::vector<int> sa(s.size());std::iota(sa.begin(),sa.end(),0);std::sort(sa.begin(),sa.end(),[&](int a,int b){return std::lexicographical_compare(s.begin()+a,s.end(),s.begin()+b,s.end(),[](char x,char y){return static_cast<unsigned char>(x)<static_cast<unsigned char>(y);});});return sa;}
static void one(std::string s,std::mt19937_64&rng){
 const auto expected=naive(s);check(suffix_array(s)==expected);check(suffix_array(std::string_view(s))==expected);
 const auto prefix=std::string_view(s.data(),std::strlen(s.c_str()));check(suffix_array(s.c_str())==naive(prefix));check(suffix_array(s.data())==naive(prefix));
 std::vector<int> values;std::vector<std::uint16_t> encoded;std::vector<unsigned char> bytes;for(unsigned char c:s){values.push_back(c);bytes.push_back(c);encoded.push_back(std::uint16_t(c)+1);}encoded.push_back(0);check(suffix_array(values,255)==expected);check(suffix_array(values)==expected);check(suffix_array(bytes)==expected);auto full=expected;full.insert(full.begin(),s.size());check(reinsirk::detail::suffix_induced(std::span<const std::uint16_t>(encoded),256)==full);
 const auto lcp=lcp_array(s,expected);check(lcp_array(std::span<const unsigned char>(bytes),expected)==lcp);for(std::size_t i=0;i<lcp.size();++i){int length=0;while(expected[i]+length<int(s.size())&&expected[i+1]+length<int(s.size())&&s[expected[i]+length]==s[expected[i+1]+length])++length;check(lcp[i]==length);}
 for(int trial=0;trial<6;++trial){std::string p;if(trial%2&&s.size()){auto a=rng()%s.size();p=s.substr(a,rng()%12);}else for(std::size_t i=0,n=rng()%12;i<n;++i)p.push_back(char(rng()%256));std::vector<unsigned char> pattern(p.begin(),p.end());int lower=0,match=0;for(int pos:expected){std::vector<unsigned char> suffix(s.begin()+pos,s.end());lower+=std::lexicographical_compare(suffix.begin(),suffix.end(),pattern.begin(),pattern.end());match+=suffix.size()>=pattern.size()&&std::equal(pattern.begin(),pattern.end(),suffix.begin());}check(SuffixArrayEqualRange(std::string_view(s),expected,std::string_view(p))==std::pair(lower,lower+match));}
}
int main(){std::mt19937_64 rng(81193);std::string all;for(int i=0;i<256;++i)all.push_back(char(i));one(all,rng);std::reverse(all.begin(),all.end());one(all,rng);for(int n=0;n<=2;++n)for(int c=0;c<256;++c)one(std::string(n,char(c)),rng);for(int i=0;i<2500;++i){std::string s(rng()%81,'a');for(char&c:s)c=char(rng()%256);if(i%5==0)for(std::size_t k=0;k<s.size();++k)s[k]="mississippi"[k%11];one(s,rng);}std::printf("PASS byte/API/span/pattern independent checks=%ju\n",static_cast<std::uintmax_t>(checks));}
