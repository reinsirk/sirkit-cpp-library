from pathlib import Path
import re,json,hashlib,difflib
p=Path(__file__).parent;root=Path('/home/reinsirk/Atcoder_Env');(p/'original').mkdir(exist_ok=True);(p/'instrumented').mkdir(exist_ok=True)
libs=[('ntt','Math/NTT.cpp',[(x,1)for x in ['vector_reduce','vector_add','vector_subtract','vector_multiply','vector_check','pointwise_avx2','naive_avx2','forward_avx2','backward_avx2']]),('matrix','Math/Matrix.cpp',[(x,1)for x in ['matrix_u32_tiled_avx2','matrix_u32_accumulate_avx2']]),('wavelet','DataStructure/Wavelet_Matrix.cpp',[('wavelet_hardware_popcount',2),('build_avx2',1)]),('floyd','Graph/Floyd-Warshall.cpp',[('FloydWarshallRelaxAvx2',1)]),('sieve','Math/Eratosthenes.cpp',[(x,1)for x in ['carry_save_avx2','popcount_lanes_avx2','load_words_avx2','popcount_words_carry_avx2','popcount_words_avx2']])];rows=[];counters=[]
for libid,(name,key,functions)in enumerate(libs):
 raw=(root/key).read_text();(p/'original'/f'{name}.cpp').write_text(raw);s=raw;patches=[]
 for feature in ['avx2','popcnt']:
  old=f'__builtin_cpu_supports("{feature}")';count=s.count(old)
  if count:
   new=f'::dispatch_qa::supports({libid},"{feature}")';s=s.replace(old,new);patches.append({'kind':'feature_probe','old':old,'new':new,'count':count})
 old='__builtin_cpu_init()';count=s.count(old)
 if count:
  new=f'::dispatch_qa::cpu_init({libid})';s=s.replace(old,new);patches.append({'kind':'probe_init','old':old,'new':new,'count':count})
 for function,expected in functions:
  pattern=re.compile(r'\b'+re.escape(function)+r'\s*\([^;{}]*\)\s*(?:const\s*)?(?:noexcept\s*)?\{');matches=list(pattern.finditer(s));assert len(matches)==expected,(name,function,len(matches));anchors=[]
  for occurrence,m in enumerate(matches):
   end=m.end();start=max(0,m.start()-160);old=s[start:end]
   while s.count(old)!=1:start=max(0,start-160);old=s[start:end]
   anchors.append((old,occurrence))
  for old,occurrence in anchors:
   assert s.count(old)==1;(counter_id:=len(counters));counters.append({'id':counter_id,'library':name,'function':function,'occurrence':occurrence});new=old+f' ::dispatch_qa::hit({counter_id}); ';s=s.replace(old,new,1);patches.append({'kind':'SIMD_entry_counter','function':function,'occurrence':occurrence,'counter_id':counter_id,'old':old,'new':new,'count':1})
 restored=s
 for change in reversed(patches):assert restored.count(change['new'])==change['count'];restored=restored.replace(change['new'],change['old'])
 assert restored==raw
 target=p/'instrumented'/f'{name}.cpp';target.write_text(s);rows.append({'name':name,'library_id':libid,'path':key,'raw_sha256':hashlib.sha256(raw.encode()).hexdigest(),'instrumented_sha256':hashlib.sha256(s.encode()).hexdigest(),'patches':patches,'reverse_patch_exact':True,'diff':''.join(difflib.unified_diff(raw.splitlines(keepends=True),s.splitlines(keepends=True),fromfile=key,tofile='instrumented/'+name+'.cpp'))})
(p/'instrumentation.json').write_text(json.dumps({'libraries':rows,'counters':counters},ensure_ascii=False,indent=2)+'\n')
(p/'counter_names.inc').write_text('inline constexpr const char* counter_names[]={'+','.join(json.dumps(x['library']+':'+x['function']+':'+str(x['occurrence']))for x in counters)+'};\ninline constexpr unsigned counter_libraries[]={'+','.join(str(next(r['library_id']for r in rows if r['name']==x['library']))for x in counters)+'};\n')
print('prepared',len(rows),'sources',len(counters),'SIMD entry counters; all reverse patches exact')
