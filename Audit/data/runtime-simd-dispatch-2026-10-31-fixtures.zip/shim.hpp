// SPDX-License-Identifier: CC0-1.0
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cassert>
namespace dispatch_qa {
inline std::uint64_t calls[64]{},probes[5]{},inits[5]{};
#include "counter_names.inc"
[[gnu::noinline]] inline unsigned mode() noexcept {const auto*p=std::getenv("SIRKIT_QA_FEATURES");return p?static_cast<unsigned>(std::strtoul(p,nullptr,10)):0;}
[[gnu::noinline]] inline int supports(unsigned library,const char*feature) noexcept {++probes[library];const auto bits=mode();return std::strcmp(feature,"avx2")==0?static_cast<int>(bits&1):std::strcmp(feature,"popcnt")==0?static_cast<int>(bits&2):0;}
[[gnu::noinline]] inline void cpu_init(unsigned library) noexcept {++inits[library];}
[[gnu::noinline]] inline void hit(unsigned id) noexcept {++calls[id];}
inline unsigned real_features() noexcept {__builtin_cpu_init();return (__builtin_cpu_supports("avx2")?1u:0u)|(__builtin_cpu_supports("popcnt")?2u:0u);}
inline std::uint64_t total(unsigned library) noexcept {std::uint64_t n=0;for(unsigned i=0;i<sizeof(counter_libraries)/sizeof(*counter_libraries);++i)if(counter_libraries[i]==library)n+=calls[i];return n;}
inline std::uint64_t named(const char*name) noexcept {std::uint64_t n=0;for(unsigned i=0;i<sizeof(counter_libraries)/sizeof(*counter_libraries);++i)if(std::strstr(counter_names[i],name))n+=calls[i];return n;}
#ifdef SIRKIT_DISABLE_SIMD
inline bool avx()noexcept{return false;}inline bool popcnt()noexcept{return false;}
#else
inline bool avx()noexcept{return mode()&1;}inline bool popcnt()noexcept{return mode()&2;}
#endif
inline void delta(unsigned lib,std::uint64_t before,bool expected){assert((total(lib)>before)==expected);}
}
