from pathlib import Path
import json,hashlib,subprocess,os,time,signal
p=Path(__file__).resolve().parent;root=Path('/home/reinsirk/Atcoder_Env');rows=[];builds=[]
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def pause():
 ack=False
 while(p/'pause').exists():
  if not ack:(p/'pause_ack').write_text(json.dumps({'pid':os.getpid(),'state':'no_active_subprocess'})+'\n');ack=True
  time.sleep(.2)
 if ack:(p/'pause_ack').unlink(missing_ok=True)
def child(command,env=None,timeout=180):
 pause();proc=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True,env=env)
 try:stdout,stderr=proc.communicate(timeout=timeout)
 except BaseException:
  os.killpg(proc.pid,signal.SIGKILL);proc.communicate();raise
 return {'command':command,'returncode':proc.returncode,'stdout':stdout,'stderr':stderr}
meta=json.loads((p/'instrumentation.json').read_text());source_hashes={r['path']:r['raw_sha256']for r in meta['libraries']}
for cc,prefix in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  for disabled in [False,True]:
   binary=p/f'{cc}_{skip}_{disabled}';flags=['-std=c++23','-O2','-Wall','-Wextra']+(['-DSKIP_RUNTIME_CHECKS']if skip else[])+(['-DSIRKIT_DISABLE_SIMD']if disabled else[]);compile_result=child(['taskset','-c','8',*prefix,*flags,str(p/'fixture.cpp'),'-o',str(binary)]);assert compile_result['returncode']==0,compile_result;builds.append({'compiler':cc,'skip':skip,'disabled':disabled,'result':compile_result,'binary_sha256':sha(binary)});(p/'builds.json').write_text(json.dumps(builds,indent=2)+'\n')
   for feature in ([3]if disabled else[0,1,2,3]):
    result=child(['taskset','-c','8',str(binary)],env=dict(os.environ,SIRKIT_QA_FEATURES=str(feature)),timeout=60);record={'compiler':cc,'skip':skip,'disabled':disabled,'features':feature,'result':result};rows.append(record);(p/'results.json').write_text(json.dumps(rows,indent=2)+'\n');assert result['returncode']==0,record;record['observed']=json.loads(result['stdout']);(p/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,'skip',skip,'disabled',disabled,'features',feature,'PASS',record['observed']['cases'],flush=True)
 for lib in meta['libraries']:
  target=p/'instrumented'/(lib['name']+'.cpp');q=child(['taskset','-c','8',*prefix,'-std=c++23','-DSIRKIT_DISABLE_SIMD','-E','-P','-x','c++',str(target)]);assert q['returncode']==0,q
  assert '::dispatch_qa::supports('not in q['stdout']and '::dispatch_qa::cpu_init('not in q['stdout']and '::dispatch_qa::hit('not in q['stdout'],(cc,lib['name']);(p/f'{cc}_{lib["name"]}_disabled_preprocessed.cpp').write_text(q['stdout'])
for key,expected in source_hashes.items():assert sha(root/key)==expected,('source drift',key)
(p/'summary.json').write_text(json.dumps({'conditions':len(rows),'builds':len(builds),'passed':len(rows),'source_hashes':source_hashes,'fixture_sha256':sha(p/'fixture.cpp'),'shim_sha256':sha(p/'shim.hpp'),'disabled_preprocessing_calls_absent':True,'snapshot_source_drift':{}},indent=2)+'\n');print('DISPATCH QA COMPLETE',len(rows),'runtime conditions',len(builds),'builds,5sources stable',flush=True)
