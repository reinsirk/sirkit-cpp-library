// SPDX-License-Identifier: CC0-1.0
#include "shim.hpp"
#include "instrumented/ntt.cpp"
#include "instrumented/matrix.cpp"
#include "instrumented/wavelet.cpp"
#include "instrumented/floyd.cpp"
#include "instrumented/sieve.cpp"
#include <array>
#include <bit>
#include <limits>
#include <random>
#include <type_traits>
#if defined(__AVX2__) || defined(__POPCNT__)
#error "Dispatch QA requires baseline compilation, not -march=native or explicit optional ISA"
#endif
static std::uint64_t cases=0;
std::uint32_t power(std::uint32_t a,std::uint32_t e,std::uint32_t mod){std::uint32_t r=1;while(e){if(e&1)r=static_cast<std::uint32_t>(std::uint64_t{r}*a%mod);a=static_cast<std::uint32_t>(std::uint64_t{a}*a%mod);e>>=1;}return r;}
template<std::uint32_t Mod,std::uint32_t Root>void ntt_cases(std::mt19937_64&rng){NTT<Mod,Root> engine;constexpr bool suitable=Mod<(1u<<30);
 for(std::size_t n:{0,1,2,4,8,16,32,64,128,256}){std::vector<std::uint32_t>a(n);for(auto&x:a)x=static_cast<std::uint32_t>(rng()%Mod);const auto original=a;auto before=dispatch_qa::total(0);engine.transform(a);dispatch_qa::delta(0,before,dispatch_qa::avx()&&suitable&&n>=16);
  if(n&&n<=32){const auto root=power(Root,(Mod-1)/static_cast<std::uint32_t>(n),Mod);for(std::size_t k=0;k<n;++k){std::uint32_t expected=0;for(std::size_t j=0;j<n;++j)expected=static_cast<std::uint32_t>((std::uint64_t{original[j]}*power(root,static_cast<std::uint32_t>(j*k),Mod)+expected)%Mod);assert(a[k]==expected);}}
  engine.transform(a,true);assert(a==original);++cases;
 }
 for(auto[m,n]:std::array<std::pair<std::size_t,std::size_t>,9>{{{0,5},{1,1},{1,14},{1,15},{8,8},{8,9},{32,33},{33,33},{65,77}}}){std::vector<std::uint32_t>a(m),b(n);for(auto&x:a)x=static_cast<std::uint32_t>(rng()%Mod);for(auto&x:b)x=static_cast<std::uint32_t>(rng()%Mod);std::vector<std::uint32_t>expected(m&&n?m+n-1:0);for(std::size_t i=0;i<m;++i)for(std::size_t j=0;j<n;++j)expected[i+j]=static_cast<std::uint32_t>((std::uint64_t{a[i]}*b[j]+expected[i+j])%Mod);const auto before=dispatch_qa::total(0);const auto result=engine.convolution_normalized(a,b);assert(result==expected);dispatch_qa::delta(0,before,dispatch_qa::avx()&&suitable&&!expected.empty()&&expected.size()>=16);++cases;}
}
void matrix_cases(std::mt19937_64&rng){for(auto shape:std::array<std::array<std::size_t,3>,11>{{{0,8,16},{3,21,16},{4,16,15},{4,16,16},{2,32,17},{3,65,64},{5,65,4032},{5,65,4033},{5,64,4097},{5,128,2048},{5,129,2048}}}){auto[m,k,n]=shape;Matrix<std::uint32_t>a(m,k),b(k,n);for(auto&x:a.values())x=static_cast<std::uint32_t>(rng());for(auto&x:b.values())x=static_cast<std::uint32_t>(rng());auto before=dispatch_qa::total(1),old_tile=dispatch_qa::named("matrix_u32_tiled_avx2"),old_full=dispatch_qa::named("matrix_u32_accumulate_avx2");auto c=a*b;for(std::size_t i=0;i<m;++i)for(std::size_t j=0;j<n;++j){std::uint32_t expected=0;for(std::size_t x=0;x<k;++x)expected=static_cast<std::uint32_t>(std::uint64_t{a(i,x)}*b(x,j)+expected);assert(c(i,j)==expected);}
#if defined(__clang__)
 const bool eligible=false;
#else
 const bool eligible=dispatch_qa::avx()&&m&&n>=16&&m*k>=64;
#endif
 dispatch_qa::delta(1,before,eligible);assert((dispatch_qa::named("matrix_u32_tiled_avx2")>old_tile)==(eligible&&k>64&&k*n>262144));assert((dispatch_qa::named("matrix_u32_accumulate_avx2")>old_full)==(eligible&&!(k>64&&k*n>262144)));++cases;
}}
template<class T>void wavelet_cases(std::mt19937_64&rng){for(std::size_t n:{0,1,63,64,65,127,128,129,193,257}){std::vector<T>a(n);for(auto&x:a){using U=std::make_unsigned_t<T>;const U v=static_cast<U>(rng());if constexpr(std::is_signed_v<T>)x=std::bit_cast<T>(v);else x=v;}if(n>1){a[0]=std::numeric_limits<T>::min();a[1]=std::numeric_limits<T>::max();}const auto before=dispatch_qa::named("wavelet:build_avx2");WaveletMatrix<T>w(a);assert(w.size()==n);const bool build_expected=dispatch_qa::avx()&&sizeof(T)>=4&&n>=128;assert((dispatch_qa::named("wavelet:build_avx2")>before)==build_expected);for(std::size_t i=0;i<n;++i)assert(w.access(i)==a[i]);for(int q=0;q<120;++q){std::size_t l=n?rng()%(n+1):0,r=n?rng()%(n+1):0;if(l>r)std::swap(l,r);T x=n?a[rng()%n]:T{};std::vector<T>ordered(a.begin()+l,a.begin()+r);std::sort(ordered.begin(),ordered.end());assert(w.count(l,r,x)==static_cast<std::size_t>(std::count(ordered.begin(),ordered.end(),x)));const auto less=std::lower_bound(ordered.begin(),ordered.end(),x);assert(w.count_less(l,r,x)==static_cast<std::size_t>(less-ordered.begin()));auto pred=w.predecessor(l,r,x),succ=w.successor(l,r,x);assert(pred==(less==ordered.begin()?std::optional<T>{}:std::optional<T>{*(less-1)}));assert(succ==(less==ordered.end()?std::optional<T>{}:std::optional<T>{*less}));if(l<r){const auto k=rng()%(r-l);assert(w.kth_smallest(l,r,k)==ordered[k]);assert(w.range_min(l,r)==ordered.front());assert(w.range_max(l,r)==ordered.back());}}++cases;}
 std::vector<T>a(128,T{7});const auto before=dispatch_qa::named("wavelet:build_avx2");WaveletMatrix<T>w(a);assert(w.count(0,128,T{7})==128);assert(dispatch_qa::named("wavelet:build_avx2")==before);++cases;
}
using Dist=std::vector<std::vector<std::int64_t>>;
Dist oracle_paths(const Dist&g,bool dag){const auto n=g.size();Dist result(n,std::vector<std::int64_t>(n,INF));for(std::size_t s=0;s<n;++s){result[s][s]=0;if(dag){for(std::size_t u=s;u<n;++u)if(result[s][u]!=INF)for(std::size_t v=u+1;v<n;++v)if(g[u][v]!=INF)result[s][v]=std::min(result[s][v],result[s][u]+g[u][v]);}else{std::vector<bool>done(n);for(std::size_t step=0;step<n;++step){auto at=n;for(std::size_t v=0;v<n;++v)if(!done[v]&&(at==n||result[s][v]<result[s][at]))at=v;if(at==n||result[s][at]==INF)break;done[at]=true;for(std::size_t v=0;v<n;++v)if(g[at][v]!=INF)result[s][v]=std::min(result[s][v],result[s][at]+g[at][v]);}}}return result;}
void floyd_cases(std::mt19937_64&rng){for(std::size_t n:{0,1,7,8,15,16,31,32,63,64,65})for(int kind=0;kind<3;++kind){Dist original(n,std::vector<std::int64_t>(n,INF));for(std::size_t i=0;i<n;++i){original[i][i]=0;for(std::size_t j=0;j<n;++j)if(i!=j&&(kind!=2||i<j)&&(kind==0||rng()%3==0))original[i][j]=kind==2?static_cast<std::int64_t>(rng()%15)-5:static_cast<std::int64_t>(rng()%17)+1;}const auto expected=oracle_paths(original,kind==2);for(bool path:{false,true}){auto dist=original;std::vector<std::vector<int>>next;const auto before=dispatch_qa::total(3);const bool negative=path?FloydWarshall(dist,next):FloydWarshall(dist);assert(!negative&&dist==expected);
#if defined(__clang__)
 const auto threshold=path?16u:32u;
#else
 const auto threshold=8u;
#endif
 dispatch_qa::delta(3,before,dispatch_qa::avx()&&n>=threshold);if(path&&n>1){auto answer=FloydWarshallPath(next,0,static_cast<int>(n-1));if(expected[0][n-1]==INF)assert(answer.empty());else{assert(!answer.empty()&&answer.front()==0&&answer.back()==static_cast<int>(n-1)&&answer.size()<=n);std::int64_t sum=0;for(std::size_t i=1;i<answer.size();++i){auto w=original[answer[i-1]][answer[i]];assert(w!=INF);sum+=w;}assert(sum==expected[0][n-1]);}}++cases;}}}
void sieve_cases(){std::vector<bool>prime(40001);for(std::size_t i=2;i<prime.size();++i){prime[i]=true;for(std::size_t d=2;d<=i/d;++d)if(i%d==0){prime[i]=false;break;}}for(std::uint64_t limit:{0,1,2,63,64,65,3968,3969,3970,32639,32640,32767,32768,40000}){PrimeSieve s(limit);std::uint64_t expected=0;for(std::uint64_t i=0;i<=limit;++i){assert(s.is_prime(i)==prime[i]);expected+=prime[i];}const auto before=dispatch_qa::total(4);assert(s.prime_count()==expected);dispatch_qa::delta(4,before,dispatch_qa::avx()&&limit>=3969);auto all=s.primes();assert(all.size()==expected);for(auto i:all)assert(i<=limit&&prime[i]);++cases;}}
int main(){const auto requested=dispatch_qa::mode(),real=dispatch_qa::real_features();if(requested&~real){std::printf("{\"skip_unsupported_positive\":true,\"requested\":%u,\"real\":%u}\n",requested,real);return 77;}std::mt19937_64 rng(0x883735);ntt_cases<998244353,3>(rng);ntt_cases<2013265921,31>(rng);matrix_cases(rng);wavelet_cases<std::uint16_t>(rng);wavelet_cases<std::uint32_t>(rng);wavelet_cases<std::uint64_t>(rng);wavelet_cases<std::int64_t>(rng);floyd_cases(rng);sieve_cases();
 assert((dispatch_qa::total(0)>0)==dispatch_qa::avx());
#if defined(__clang__)
 assert(dispatch_qa::total(1)==0);
#else
 assert((dispatch_qa::total(1)>0)==dispatch_qa::avx());
#endif
 assert((dispatch_qa::named("wavelet:wavelet_hardware_popcount")>0)==dispatch_qa::popcnt());assert((dispatch_qa::named("wavelet:build_avx2")>0)==dispatch_qa::avx());assert((dispatch_qa::total(3)>0)==dispatch_qa::avx());assert((dispatch_qa::total(4)>0)==dispatch_qa::avx());
#ifdef SIRKIT_DISABLE_SIMD
 for(auto x:dispatch_qa::probes)assert(x==0);for(auto x:dispatch_qa::inits)assert(x==0);for(auto x:dispatch_qa::calls)assert(x==0);
#endif
 std::printf("{\"cases\":%ju,\"requested\":%u,\"real\":%u,\"probes\":[",static_cast<std::uintmax_t>(cases),requested,real);for(unsigned i=0;i<5;++i)std::printf("%s%ju",i?",":"",static_cast<std::uintmax_t>(dispatch_qa::probes[i]));std::printf("],\"init_calls\":[");for(unsigned i=0;i<5;++i)std::printf("%s%ju",i?",":"",static_cast<std::uintmax_t>(dispatch_qa::inits[i]));std::printf("],\"entries\":[");for(unsigned i=0;i<sizeof(dispatch_qa::counter_libraries)/sizeof(*dispatch_qa::counter_libraries);++i)std::printf("%s%ju",i?",":"",static_cast<std::uintmax_t>(dispatch_qa::calls[i]));std::puts("]}");}
