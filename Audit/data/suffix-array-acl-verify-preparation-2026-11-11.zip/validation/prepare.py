# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import re,shutil,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_suffix_acl_20261111');files=['String/Suffix_Array.cpp','Document/suffix_array.md','Examples/suffix_array_example.cpp','Verify/current/drivers/suffix_array_main.cpp','Verify/current/drivers/suffix_array_substrings_main.cpp','Verify/current/groups/expansion_20261031.json','Distribution/manifest.json']+[str(p.relative_to(R))for p in (R/'Verify/current/tests').glob('*.cpp')if re.search(r'\b(?:SuffixArray|LCPArray)\b',p.read_text())]
for name in files:
 p=D/'before'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/name,p)
for name in files:
 if not name.endswith(('.cpp','.md')):continue
 p=R/name;s=p.read_text();s=re.sub(r'\bSuffixArray\b','suffix_array',s);s=re.sub(r'\bLCPArray\b','lcp_array',s);p.write_text(s)
p=R/'String/Suffix_Array.cpp';s=p.read_text().replace('#include <string_view>','#include <string>\n#include <string_view>')
# Move the byte-string builder into the existing private component unchanged.
a=s.index('inline std::vector<int> suffix_array(std::string_view s) {');b=s.index('\n}\n',a)+3;block=s[a:b];s=s[:a]+'''inline std::vector<int> suffix_array(const std::string& s) {
    return reinsirk::detail::suffix_string(s);
}
template<class View> requires std::same_as<View, std::string_view>
std::vector<int> suffix_array(View s) {
    return reinsirk::detail::suffix_string(s);
}
'''+s[b:]
block=block.replace('suffix_array(std::string_view s)','suffix_string(std::string_view s)');s=s.replace('template <class Sequence, class Pattern, class Convert>',block+'\ntemplate <class Sequence, class Pattern, class Convert>',1)
# Keep the old integral encoder; only newly supported element types take a new path.
a=s.index('template <std::integral T>\nstd::vector<int> suffix_array(');b=s.index('\n}\n#endif',a)+2
s=s[:a]+'''template <class T>
std::vector<int> suffix_array(const std::vector<T>& s) {
    reinsirk::detail::suffix_length_check(s.size());
    if constexpr (std::integral<T>) {
        std::vector<T> alphabet = s;
        std::sort(alphabet.begin(), alphabet.end());
        alphabet.erase(std::unique(alphabet.begin(), alphabet.end()), alphabet.end());
        std::vector<int> encoded(s.size() + 1);
        for (std::size_t i = 0; i < s.size(); ++i)
            encoded[i] = static_cast<int>(std::lower_bound(alphabet.begin(), alphabet.end(), s[i]) - alphabet.begin()) + 1;
        auto result = reinsirk::detail::suffix_induced(encoded, static_cast<int>(alphabet.size()));
        result.erase(result.begin());
        return result;
    } else {
        std::vector<int> positions(s.size()), encoded(s.size() + 1);
        for (std::size_t i = 0; i < s.size(); ++i) positions[i] = static_cast<int>(i);
        std::sort(positions.begin(), positions.end(), [&](int a, int b) { return s[a] < s[b]; });
        int alphabet = 0;
        for (std::size_t i = 0; i < positions.size(); ++i) {
            if (i == 0 || s[positions[i - 1]] < s[positions[i]]) ++alphabet;
            encoded[positions[i]] = alphabet;
        }
        auto result = reinsirk::detail::suffix_induced(encoded, alphabet);
        result.erase(result.begin());
        return result;
    }
}'''+s[b:]
# Preserve the generic LCP implementation and expose the exact ACL overloads.
a=s.index('#ifndef SIRKIT_LCP_ARRAY_DEFINED');b=s.index('\n#ifndef SIRKIT_SUFFIX_ARRAY_EQUAL_RANGE_DEFINED',a);block=s[a:b]
block=block.replace('SIRKIT_LCP_ARRAY_DEFINED','SIRKIT_LCP_ARRAY_IMPL_DEFINED').replace('template <class Sequence>','namespace reinsirk::detail {\ntemplate <class Sequence>',1).replace('lcp_array(const Sequence&','suffix_lcp(const Sequence&',1)
idx=block.rindex('#endif');block=block[:idx]+'}\n'+block[idx:]
wrappers='''
#ifndef SIRKIT_LCP_ARRAY_DEFINED
#define SIRKIT_LCP_ARRAY_DEFINED
template<class T>
std::vector<int> lcp_array(const std::vector<T>& s, const std::vector<int>& sa) {
    return reinsirk::detail::suffix_lcp(s, sa);
}
inline std::vector<int> lcp_array(const std::string& s, const std::vector<int>& sa) {
    return reinsirk::detail::suffix_lcp(s, sa);
}
template<class Sequence>
    requires requires(const Sequence& s) { s.size(); s[0] == s[0]; }
std::vector<int> lcp_array(const Sequence& s, const std::vector<int>& sa) {
    return reinsirk::detail::suffix_lcp(s, sa);
}
#endif
'''
s=s[:a]+block+wrappers+s[b:]
s=s.replace('// ドキュメント:', '// 参考（ACLの公開API）: https://atcoder.github.io/ac-library/production/document_ja/string.html\n// ドキュメント:',1)
s=s.replace('// suffix_array(string_view):','// suffix_array(const std::string&)/suffix_array(string_view):').replace('// suffix_array(vector<T>): 整数型Tを座標圧縮して構築。負数/uint64_t最大値も可、O(n log n)時間・O(n)領域。','// suffix_array<T>(const vector<T>&): Tの<で圧縮して構築。負数/uint64_t最大値も可、O(n log n)時間・O(n)領域。').replace('// lcp_array(s,sa):','// lcp_array(const string&,sa)/lcp_array<T>(const vector<T>&,sa):').replace('// 文字列版はO(n)時間・領域。','// upperは0以上INT_MAX-1未満。文字列版はO(n)時間・領域。').replace('// lcp_arrayのsaは','// 追加のlcp_array(sequence,sa)はstring_view/array等にも対応。\n// lcp_arrayのsaは')
p.write_text(s)
p=R/'Document/suffix_array.md';s=p.read_text().replace('空接尾辞は含まず、','グローバルの`suffix_array`・`lcp_array`は[ACL](https://atcoder.github.io/ac-library/production/document_ja/string.html)の引数・戻り値・呼び出し形式に合わせて使えます。空接尾辞は含まず、').replace('`suffix_array(string)`','`suffix_array(const std::string&)`').replace('`suffix_array(vector<Integer>)`','`suffix_array<T>(const vector<T>&)`').replace('値を座標圧縮して扱う。負数・UINT64_MAXも可。','Tの`<`で圧縮して扱う。負数・UINT64_MAXも可。').replace('upperが大きい場合は、','`string_view`のSA構築、`string_view`・`array`等のLCP構築も同名で使えます。Tの`<`は一貫した順序が前提です。空列のLCPは空配列を返します。\n\nupperは0以上INT_MAX-1未満。upperが大きい場合は、');p.write_text(s)
(D/'migrated_files.json').write_text(json.dumps(files,indent=2)+'\n')
