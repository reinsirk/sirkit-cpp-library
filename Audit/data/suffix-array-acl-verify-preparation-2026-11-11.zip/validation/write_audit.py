# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_suffix_acl_20261111')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
runs=sorted((D/'profiles/runs').glob('*.json'));profile=load(runs[-1]);assert profile['counts']=={'LOCAL_SAMPLE_PASS':14}
tests=[r for r in load(D/'tests.json')if r['test']!='suffix_array_acl_api_test']+load(D/'api_final_tests.json');manifest=load(R/'Verify/current/manifest.json');entries=[e for e in manifest['entries']if e['id']in['suffix_array','suffix_array_substrings']];assert all(e['judge_status']=='未提出'for e in entries)
audit={
 'date':'2026-11-11','status':'normal_suffix_array_verify_prepared_unsubmitted','library':'String/Suffix_Array.cpp',
 'purpose':'次の新規通常版Verifyとして接尾辞配列/隣接LCPの2問題を準備。既定方針に合わせACLの公開APIへ統一する。速度最適化の成果とは扱わない。',
 'API_reference':['https://atcoder.github.io/ac-library/production/document_ja/string.html','https://raw.githubusercontent.com/atcoder/ac-library/master/atcoder/string.hpp'],
 'changes':['global suffix_array(const std::string&)、suffix_array<T>(const vector<T>&)、suffix_array(const vector<int>&,int)をACLの型/引数/戻り値へ合わせる。','global lcp_array(const std::string&,const vector<int>&)、lcp_array<T>(const vector<T>&,const vector<int>&)をACL形式へ合わせる。','旧SuffixArray/LCPArrayという重複名は残さず、使用例/driver/依存テスト/Documentを新名へ移行。過去Auditの提出記録は変更しない。','string_view構築・汎用列LCP・空列LCP・unsigned byte順・SuffixArrayEqualRangeの追加機能は維持。','C文字列は同名のpointer templateで受け、余分なstd::string複製を避ける。nullptrは既定でO(1)検査し、SKIP時はcaller前提。pointer templateは空{}のACL形式を曖昧にしない。','非整数型vectorも<だけで座標圧縮する追加経路を用意。コピー不可の比較型も扱える。整数型の圧縮は旧経路を維持。'],
 'retained_implementation':load(D/'implementation_retention.json'),
 'behavior_notes':['SA-IS本体、バイト列符号化、整数圧縮、LCP演算/検査は維持。private helperへの移動とエラー文の関数名だけ変更。','型・呼出し形式はACLと共通。空列LCP、string_view/C文字列、一般の比較型vector等は追加対応。','列長INT_MAX-1未満、upperは0以上INT_MAX-1未満を保持。容量/添字保護はSKIP時も除かない。','LCPはrank構築にサイズ/添字/重複の検査を組込み、辞書順の全再検査はしない。検索も参照したsa添字だけ検査。'],
 'source_sha256':{'before':sha(D/'before/String/Suffix_Array.cpp'),'after':sha(R/'String/Suffix_Array.cpp'),'common_IO':sha(R/'Verify/current/common/fast_io.hpp')},
 'drivers':'2本ともAPI呼出名のみ変更。計算手順/順序/共通IOは維持。IOは直前のManacher AC記録のhashとも一致。',
 'verify_programs':[dict(id=e['id'],submission=e['submission'],problem_url=e['problem_url'],bytes=e['bytes'],submission_sha256=e['submission_sha256'],skip_runtime_checks=e['skip_runtime_checks'],judge_status=e['judge_status'])for e in entries],
 'dependencies':'提出コードは本体と共通IOを展開済み。ACL/自作別ファイルの外部include不要。全体512KiB未満。',
 'validation':{'compiler':{'GCC':'15.2.0','Clang':'21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'},'language':'C++23','tests':tests,'tests_scope':'ASan/UBSan付きGCC/Clang×checked/SKIPでAPI型・独立naive・独立doubling大規模参照を照合。確保失敗試験は専用global newフックを使いサニタイザなし。','API_result':'checked98/SKIP92 checksと5種類のexact function pointer static_assert。literal/空{}・view・整数極値/bool/highbyte/NUL・string/double/コピー不可<のみ・==だけのgenericLCP・invalid/巨大長・旧名不存在を確認。','independent_result':'文字列/整数列の独立参照5973836 checked/5973827 SKIP、別の20万要素doubling等の参照524326 checks。','allocation_result':'両コンパイラ2343 checks / 69 injected failures / live_delta=0。','normal_program_samples':load(D/'normal_programs.json'),'migrated_callsite_builds':load(D/'migrated_callsite_builds.json'),'profiles':{'run_file':'profiles/runs/'+runs[-1].name,'counts':profile['counts'],'scope':'コンパイラ別/速度優先の2プログラム8件と、通常GCC/Clang+派生4種の使用例6件。通常提出プログラムのGCC/Clang4件は別途normal_programs.json。'},'superseded_test_snapshot':'tests.jsonのAPI4件はC文字列/空{}補足前。api_final_tests.jsonの4件を最終結果とする。'},
 'performance':'SA-IS/文字列符号化/整数圧縮/LCP演算の保持をコードでも照合。新API全体の速度比較は未実施で、タイミング改善は主張しない。初回オンライン提出後に同じmain/IOで比較する。',
 'documentation':'Document/suffix_array.mdを既存構成のままAPI表/前提/短い例へ更新。比較型vectorの例はExamplesにも追加。README/Documentに変更履歴や性能記録を追加しない。',
 'license':'SPDX CC0-1.0を維持。SA-ISと追加圧縮/ラッパーは独自実装。ACLは公開APIの確認に参照し、本文のコピー/組込みはしない。参照ヘッダー本文は証跡ZIPへ収録しない。',
 'files_migrated':load(D/'migrated_files.json'),'evidence_zip':'Audit/data/suffix-array-acl-verify-preparation-2026-11-11.zip'
}
p=R/'Audit/suffix-array-acl-verify-preparation-2026-11-11.json';p.write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
old=R/'Audit/distribution-manifest-before-suffix-array-acl-2026-11-11.json';assert not old.exists();old.write_bytes((D/'before/Distribution/manifest.json').read_bytes())
files=[]
for f in D.iterdir():
 if f.is_file()and f.suffix in ['.json','.py','.cpp','.log']:files.append((f,'validation/'+f.name))
for f in (D/'agent_tests').iterdir():
 if f.is_file():files.append((f,'agent_tests/'+f.name))
for f in (D/'before').rglob('*'):
 if f.is_file():files.append((f,'before/'+str(f.relative_to(D/'before'))))
for f in (D/'profiles').rglob('*.json'):files.append((f,'profiles/'+str(f.relative_to(D/'profiles'))))
names=[n for n in load(D/'migrated_files.json')if n.endswith(('.cpp','.md'))]+['Verify/current/tests/suffix_array_acl_api_test.cpp','Verify/current/submissions/suffix_array.cpp','Verify/current/submissions/suffix_array_substrings.cpp','Audit/suffix-array-acl-verify-preparation-2026-11-11.json']
for n in names:files.append((R/n,'after/'+n))
with zipfile.ZipFile(R/audit['evidence_zip'],'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f,n in sorted(files,key=lambda v:v[1]):z.writestr(zipfile.ZipInfo(n,(2026,11,11,0,0,0)),f.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
print('audit/evidence',len(files),(R/audit['evidence_zip']).stat().st_size)
