// SPDX-License-Identifier: CC0-1.0
// 参考（数学的なSA-ISの原論文。コードは独自実装）:
// https://doi.org/10.1109/DCC.2009.42
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/suffix_array.md
//
// API一覧
// SuffixArray(string_view): 符号なしバイトの辞書順で接尾辞の開始位置を返す。空接尾辞は含めない。
// SuffixArray(vector<int>, upper): 全要素0..upperの整数列。SA-ISでO(n+upper)時間・領域。
// SuffixArray(vector<T>): 整数型Tを座標圧縮して構築。負数/uint64_t最大値も可、O(n log n)時間・O(n)領域。
// 文字列版はO(n)時間・領域。全版で列長はINT_MAX-1未満、空なら{}。返却添字はint。
// LCPArray(s,sa): 隣り合う接尾辞の共通接頭辞長を返す。n<2なら{}、それ以外はn-1個。O(n)時間・領域。
// LCPArrayのsaはsの正しい接尾辞配列が前提。既定検査はサイズ・添字・重複を確認し、辞書順までは再検査しない。
// SuffixArrayEqualRange(s,sa,pattern): patternを接頭辞に持つ接尾辞のsa内半開区間を返す。
// 検索はO((m+1)log(n+1))時間・追加O(1)。string_view版は符号なしバイト順、vector版はTの順序。
// 空patternは全接尾辞に一致。検索はsaの妥当性を全走査せず、実際に参照する添字だけ検査する。

#include <algorithm>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <string_view>
#include <utility>
#include <vector>

#ifndef SIRKIT_SUFFIX_ARRAY_DETAIL_DEFINED
#define SIRKIT_SUFFIX_ARRAY_DETAIL_DEFINED
namespace reinsirk::detail {
inline void suffix_length_check(std::size_t n) {
    if (n >= static_cast<std::size_t>(std::numeric_limits<int>::max() - 1))
        throw std::length_error("SuffixArray: sequence too long");
}

// 正の整数列に一意な終端0を付けた列を扱う。再帰先にも終端0を残す。
inline std::vector<int> suffix_induced(const std::vector<int>& symbols, int alphabet) {
    const int n = static_cast<int>(symbols.size());
    if (n == 1) return {0};
    std::vector<std::uint8_t> small(n), boundary(n);
    small[n - 1] = 1;
    for (int i = n - 2; i >= 0; --i)
        small[i] = symbols[i] < symbols[i + 1] ||
            (symbols[i] == symbols[i + 1] && small[i + 1]);
    std::vector<int> selected;
    selected.reserve(static_cast<std::size_t>(n / 2));
    for (int i = 1; i < n; ++i)
        if (small[i] && !small[i - 1]) { boundary[i] = 1; selected.push_back(i); }
    std::vector<int> starts(static_cast<std::size_t>(alphabet) + 1), ends(starts.size());
    for (int symbol : symbols) ++ends[symbol];
    int total = 0;
    for (int symbol = 0; symbol <= alphabet; ++symbol) {
        starts[symbol] = total; total += ends[symbol]; ends[symbol] = total;
    }
    std::vector<int> suffixes(n), cursor(ends.size());
    const auto induce = [&](const std::vector<int>& order) {
        std::fill(suffixes.begin(), suffixes.end(), -1);
        cursor = ends;
        for (auto it = order.rbegin(); it != order.rend(); ++it)
            suffixes[--cursor[symbols[*it]]] = *it;
        cursor = starts;
        for (int slot = 0; slot < n; ++slot) {
            const int before = suffixes[slot] - 1;
            if (before >= 0 && !small[before])
                suffixes[cursor[symbols[before]]++] = before;
        }
        cursor = ends;
        for (int slot = n - 1; slot >= 0; --slot) {
            const int before = suffixes[slot] - 1;
            if (before >= 0 && small[before])
                suffixes[--cursor[symbols[before]]] = before;
        }
    };
    induce(selected);
    const int count = static_cast<int>(selected.size());
    std::vector<int> reduced(count), selected_id(n, -1);
    for (int i = 0; i < count; ++i) selected_id[selected[i]] = i;
    int previous = -1, name = -1;
    for (int position : suffixes) {
        if (!boundary[position]) continue;
        bool different = previous < 0;
        if (!different) {
            int offset = 0;
            for (;;) {
                if (symbols[position + offset] != symbols[previous + offset] ||
                    small[position + offset] != small[previous + offset]) {
                    different = true; break;
                }
                if (offset > 0 && (boundary[position + offset] || boundary[previous + offset])) {
                    different = boundary[position + offset] != boundary[previous + offset]; break;
                }
                ++offset;
            }
        }
        if (different) ++name;
        reduced[selected_id[position]] = name;
        previous = position;
    }
    std::vector<int> reduced_order(count);
    if (name + 1 == count) {
        for (int i = 0; i < count; ++i) reduced_order[reduced[i]] = i;
    } else reduced_order = suffix_induced(reduced, name);
    std::vector<int> final_order(count);
    for (int i = 0; i < count; ++i) final_order[i] = selected[reduced_order[i]];
    induce(final_order);
    return suffixes;
}

template <class Sequence, class Pattern, class Convert>
std::pair<int, int> suffix_search(const Sequence& s, const std::vector<int>& sa,
                                 const Pattern& pattern, Convert convert) {
    suffix_length_check(s.size());
#ifndef SKIP_RUNTIME_CHECKS
    if (sa.size() != s.size()) throw std::invalid_argument("SuffixArrayEqualRange: size");
#endif
    const auto compare = [&](int slot) {
        const int position = sa[slot];
#ifndef SKIP_RUNTIME_CHECKS
        if (position < 0 || static_cast<std::size_t>(position) >= s.size())
            throw std::out_of_range("SuffixArrayEqualRange: suffix index");
#endif
        std::size_t offset = 0;
        const std::size_t remaining = s.size() - static_cast<std::size_t>(position);
        while (offset < pattern.size() && offset < remaining) {
            const auto a = convert(s[static_cast<std::size_t>(position) + offset]);
            const auto b = convert(pattern[offset]);
            if (a < b) return -1;
            if (b < a) return 1;
            ++offset;
        }
        return offset == pattern.size() ? 0 : -1;
    };
    int first = 0, last = static_cast<int>(sa.size());
    while (first < last) {
        const int middle = first + (last - first) / 2;
        if (compare(middle) < 0) first = middle + 1; else last = middle;
    }
    const int lower = first;
    last = static_cast<int>(sa.size());
    while (first < last) {
        const int middle = first + (last - first) / 2;
        if (compare(middle) <= 0) first = middle + 1; else last = middle;
    }
    return {lower, first};
}
}
#endif

#ifndef SIRKIT_SUFFIX_ARRAY_DEFINED
#define SIRKIT_SUFFIX_ARRAY_DEFINED
inline std::vector<int> SuffixArray(std::string_view s) {
    reinsirk::detail::suffix_length_check(s.size());
    std::vector<int> encoded(s.size() + 1);
    for (std::size_t i = 0; i < s.size(); ++i) encoded[i] = static_cast<unsigned char>(s[i]) + 1;
    auto result = reinsirk::detail::suffix_induced(encoded, 256);
    result.erase(result.begin());
    return result;
}

inline std::vector<int> SuffixArray(const std::vector<int>& s, int upper) {
    reinsirk::detail::suffix_length_check(s.size());
    if (upper < 0 || upper >= std::numeric_limits<int>::max() - 1)
        throw std::length_error("SuffixArray: alphabet too large");
    std::vector<int> encoded(s.size() + 1);
    for (std::size_t i = 0; i < s.size(); ++i) {
#ifndef SKIP_RUNTIME_CHECKS
        if (s[i] < 0 || s[i] > upper) throw std::out_of_range("SuffixArray: symbol");
#endif
        encoded[i] = s[i] + 1;
    }
    auto result = reinsirk::detail::suffix_induced(encoded, upper + 1);
    result.erase(result.begin());
    return result;
}

template <std::integral T>
std::vector<int> SuffixArray(const std::vector<T>& s) {
    reinsirk::detail::suffix_length_check(s.size());
    std::vector<T> alphabet = s;
    std::sort(alphabet.begin(), alphabet.end());
    alphabet.erase(std::unique(alphabet.begin(), alphabet.end()), alphabet.end());
    std::vector<int> encoded(s.size() + 1);
    for (std::size_t i = 0; i < s.size(); ++i)
        encoded[i] = static_cast<int>(std::lower_bound(alphabet.begin(), alphabet.end(), s[i]) - alphabet.begin()) + 1;
    auto result = reinsirk::detail::suffix_induced(encoded, static_cast<int>(alphabet.size()));
    result.erase(result.begin());
    return result;
}
#endif

#ifndef SIRKIT_LCP_ARRAY_DEFINED
#define SIRKIT_LCP_ARRAY_DEFINED
template <class Sequence>
std::vector<int> LCPArray(const Sequence& s, const std::vector<int>& sa) {
    reinsirk::detail::suffix_length_check(s.size());
#ifndef SKIP_RUNTIME_CHECKS
    if (sa.size() != s.size()) throw std::invalid_argument("LCPArray: size");
    std::vector<int> rank(s.size(), -1);
#else
    std::vector<int> rank(s.size());
#endif
    const int n = static_cast<int>(s.size());
    for (int i = 0; i < n; ++i) {
#ifndef SKIP_RUNTIME_CHECKS
        if (sa[i] < 0 || sa[i] >= n || rank[sa[i]] != -1)
            throw std::invalid_argument("LCPArray: suffix permutation");
#endif
        rank[sa[i]] = i;
    }
    if (n < 2) return {};
    std::vector<int> lcp(static_cast<std::size_t>(n - 1));
    int length = 0;
    for (int i = 0; i < n; ++i) {
        const int order = rank[i];
        if (order + 1 == n) { length = 0; continue; }
        const int j = sa[order + 1];
        while (length < n - i && length < n - j && s[i + length] == s[j + length]) ++length;
        lcp[order] = length;
        if (length != 0) --length;
    }
    return lcp;
}
#endif

#ifndef SIRKIT_SUFFIX_ARRAY_EQUAL_RANGE_DEFINED
#define SIRKIT_SUFFIX_ARRAY_EQUAL_RANGE_DEFINED
inline std::pair<int, int> SuffixArrayEqualRange(std::string_view s, const std::vector<int>& sa,
                                               std::string_view pattern) {
    return reinsirk::detail::suffix_search(s, sa, pattern, [](char c) { return static_cast<unsigned char>(c); });
}
template <std::integral T>
std::pair<int, int> SuffixArrayEqualRange(const std::vector<T>& s, const std::vector<int>& sa,
                                       const std::vector<T>& pattern) {
    return reinsirk::detail::suffix_search(s, sa, pattern, [](T value) { return value; });
}
#endif
