# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,hashlib,json,os,re
D=Path('/tmp/sirkit_suffix_416499');sys.path.insert(0,str(D));import validate_final as v
p=D/'final_validation.json';doc=json.loads(p.read_text());changed=[]
for row in doc['jobs']:
 if row['test']!='suffix_array_acl_api_test':continue
 row['source_sha256']=hashlib.sha256(Path(row['source']).read_bytes()).hexdigest();row['compile']=v.capture(row['compile_command']);assert row['compile']['returncode']==0,row
 env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=0:halt_on_error=1:abort_on_error=1';env['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1'
 row['run']=v.capture(row['run_command'],env=env);row['counters']={k:int(n)for k,n in re.findall(r'\b(checks|failures|live_delta)=(\d+)',row['run']['stdout'])};row['passed']=row['run']['returncode']==0 and not row['run']['stderr'] and row['counters'].get('checks',0)>0;changed.append(row);p.write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n');print(row['compiler'],row['mode'],row['sanitizer'],row['passed'],row['run']['stdout'],flush=True);assert row['passed'],row
assert len(changed)==8;doc['all_passed']=all(r['passed']for r in doc['jobs']);doc['passed_jobs']=sum(r['passed']for r in doc['jobs']);doc['API_extension']='bool tiny unique, signed/unsigned extrema, distinct strings/double/noncopy types added; only8 API jobs rerun, other24 unchanged';p.write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
