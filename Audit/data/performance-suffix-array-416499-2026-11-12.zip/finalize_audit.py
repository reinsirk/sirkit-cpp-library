# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,statistics,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_suffix_416499')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,a):p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
validation=load(D/'final_validation.json');assert validation['all_passed'] and validation['passed_jobs']==32
for row in validation['jobs']:assert row['source_sha256']==sha(Path(row['source']))
assert sha(R/'String/Suffix_Array.cpp')==sha(D/'final.hpp')
fixtures=load(D/'fixtures.json');ns={f['name']:f['n']for f in fixtures}
rows=load(D/'confirm_summary.json');assert len(rows)==300 and len(load(D/'confirm_raw.json'))==10500
whole=[]
for cc in ['gcc','clang']:
 for identifier in ['suffix_array','suffix_array_substrings']:
  a=[r for r in rows if r['compiler']==cc and r['id']==identifier and ns[r['case']]>=200000]
  whole.append(dict(compiler=cc,id=identifier,cases=len(a),geometric_mean_ratio=statistics.geometric_mean(r['ratios']['hist_fused']for r in a),worst_ratio=max(r['ratios']['hist_fused']for r in a)))
core=load(D/'generic_final_summary.json');assert len(core)==252
unique=[]
for cc in ['gcc','clang']:
 a=[r['ratios']['final']for r in core if r['compiler']==cc and r['kind']==6 and r['n']==500000]
 unique.append(dict(compiler=cc,type='vector<int64_t>',n=500000,settings=['checked','skip'],shapes=['ascending','descending','shuffled'],best_ratio=min(a),worst_ratio=max(a),geometric_mean_ratio=statistics.geometric_mean(a)))
frozen={}
for p in ['Verify/current/drivers/suffix_array_main.cpp','Verify/current/drivers/suffix_array_substrings_main.cpp','Verify/current/common/fast_io.hpp','Document/suffix_array.md','Examples/suffix_array_example.cpp']:
 assert (R/p).read_bytes()==(D/'before'/p).read_bytes();frozen[p]=sha(R/p)
profiles=load(next((D/'profiles/runs').glob('*.json')));assert profiles['counts']=={'LOCAL_SAMPLE_PASS':14}
correspondence=load(D/'current_correspondence.json');assert len(correspondence)==4 and all(r['current_text_matches_measured_final']for r in correspondence)
proof=load(D/'final_correspondence.json');assert len(proof)==4 and all(r['final_text_identical_to_measured_hist_fused']for r in proof)
audit=dict(date='2026-11-12',library='String/Suffix_Array.cpp',decision='adopt_fused_histogram_and_distinct_first_symbol_shortcuts',required_resubmission=['Verify/current/submissions/suffix_array.cpp','Verify/current/submissions/suffix_array_substrings.cpp'],online_evidence='Audit/online-suffix-array-416499-416500-2026-11-12.json',online_scope='416499と416500はいずれも変更前通常版のAC46ms。今回の本体改修と派生版は未提出。',source_sha256=dict(before=sha(D/'base.hpp'),after=sha(D/'final.hpp')),frozen_main_IO_document_examples=frozen,changes=[
 'S/L型判定の逆走査へ度数集計を組み込む。終端を一度数え、残りの位置を逆走査内で一度ずつ数える。分類後に全入力を再走査する処理を省く。',
 'vector<T>の既存の圧縮結果がn個の同値類を持つとき、接尾辞順は先頭要素だけで決まる。整数型はlower_boundの順位へ入力位置を置いて返す。非整数型は既に整列した位置列を返す。',
 '追加の入力検査や全走査はない。重複がある場合の圧縮・符号化経路を維持し、O(1)の同値類数判定を追加。公開API・検査ブロック・LCP・検索は維持。'
 ],ownership='vector/unique_ptrを使う通常版。直接new式・解放省略なし。確保失敗試験の全4設定でlive_delta=0。',independent_reviews=[load(D/'agent/fused_review.json'),load(D/'agent/unique_review.json')],measurement=dict(cpu='Intel Core i9-14900K CPU12/core6 P-Core; sibling13',E_core_measured=False,compilers={'GCC':'15.2.0','Clang':'21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'},flags=['-std=c++23','-O2'],march_native=False,extra_pragmas=False,new_SIMD_or_CPU_dispatch=False,standard_CXX23_path=True,ASLR='setarch x86_64 -R for child only',lock='/tmp/sirkit_performance_cpu12.lock',compilation_during_timing=False,whole='固定main/共通IOのuser+system CPU時間。同じactiveパスでbase/control/候補を決定的shuffle。controlはbaseと同じ実行ファイル。',whole_statistics=whole,whole_repetitions=7,whole_runs=10500,large_selection='入力長20万以上の48ケース。小さい入力の起動費を平均改善率へ混ぜない。',fixture_rows=len(fixtures),byte_unique_inputs=len({f['sha256']for f in fixtures}),fixture_origin='Audit/data/performance-suffix-array-416380-2026-11-11.zipと同じ固定公開生成器/補助入力をSHAで照合して再利用。',official_revision='73876f1cbcf082d2b22722924b924d3d65a2f00e',fixture_scope='固定公開生成方法/seedと独立作成ケース。制約外100万要素を含み、オンライン入力との同一性は主張しない。',all_variant_outputs_equal=True,core='steady_clock時間。入力作成/事前SA構築は外、結果を全要素checksumへ消費する部分は含む。事前SA構築後の確保状態も含む。',core_operations=['bounded narrow-alphabet SA','compressed int64 narrow-alphabet SA','vector<bool> SA','LCP reuse','equal range search','bounded permutation/large alphabet SA','compressed int64 permutation SA'],core_settings=['checked','SKIP_RUNTIME_CHECKS'],core_sizes=[32,4096,500000],core_repetitions=7,unique_statistics=unique,extra_followup='int64の小alphabet/全相異なる列を50万/100万要素・15反復で比較。上限つき全相異なる整数列も50万/100万要素・15反復で再測定。初回約2.5〜2.7%増加した条件で同程度の増加は再現しなかった。',core_output_hashes_equal=True),rejected_candidates=[
 dict(name='hist4',reason='4表へ分けた集計は正当性試験を通るが、追加配列3084Bを使い、GCCで走査統合との差は僅少。Clangでは平均の改善幅が小さいため採用しない。'),
 dict(name='hist8',reason='8表版は追加配列7196B。GCCで僅かに速い条件もあるが、Clangでは平均の改善幅が小さく、一部Fibに増加がある。追加配列のない共通の走査統合案を選択。')
 ],validation=dict(jobs=32,all_passed=True,compiler_and_checks='GCC/Clang × checked/SKIP_RUNTIME_CHECKS',tests=['ACL形式API/空列/bool/符号付き・符号なし極値/コピー不可型の独立naive参照','短列SA・LCP・検索参照と全二進列','20万要素の独立doubling参照等','固有値/周期列の数式による大alphabet・256/257種類・境界長の独立参照','確保失敗・所有権・入力不変性'],sanitizers='API/短列参照/新しい度数集計参照をASAN+UBSANでも全4設定実行。hostのptrace制約によりdetect_leaks=0、解放は独立の確保カウンタで検証。',API_extension='固有要素のbool/整数極値/文字列/double/コピー不可型を追加し、変更したAPI試験の8設定のみ追加再実行。他の24設定はソース/本体SHAが不変。',allocation_counters=[r['counters']for r in validation['jobs']if r['test']=='string_math_allocation_test'],variant_and_example_profiles=profiles,current_correspondence=correspondence,measured_code_correspondence=proof),limits='ローカルの測定条件の結果であり、全てのCPU・呼出し文脈・入力で厳密な非後退やオンラインの所要時間を保証しない。',license='CC0-1.0独自実装。新しい外部実装のコードは転記していない。数学的なSA-IS原論文とACLの公開APIの参照を維持。公開問題生成器の本文は一時領域だけで使い、配布コード/証拠ZIPへ入れない。',evidence='Audit/data/performance-suffix-array-416499-2026-11-12.zip')
put(R/'Audit/performance-suffix-array-416499-2026-11-12.json',audit)
files=[p for p in D.iterdir()if p.is_file()and p.suffix in ['.json','.py','.hpp','.cpp']]
files += [p for p in (D/'agent').iterdir()if p.is_file()and p.suffix in ['.json','.py','.hpp','.txt']]
for directory in ['before','after','profiles/runs']:
 files += [p for p in (D/directory).rglob('*')if p.is_file()and p.suffix in ['.json','.cpp','.hpp','.md']]
with zipfile.ZipFile(R/audit['evidence'],'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(set(files)):z.write(p,str(p.relative_to(D)))
print('audit/evidence ready',whole,unique)
