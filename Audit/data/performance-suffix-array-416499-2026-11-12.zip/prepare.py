# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
D=Path('/tmp/sirkit_suffix_416499');base=(D/'before/String/Suffix_Array.cpp').read_text();(D/'base.hpp').write_text(base)
block='    std::vector<int> starts(static_cast<std::size_t>(alphabet) + 1), ends(starts.size());\n    for (int symbol : symbols) ++ends[symbol];\n'
assert base.count(block)==1
fused=base.replace('    small[n - 1] = 1;','    std::vector<int> starts(static_cast<std::size_t>(alphabet) + 1), ends(starts.size());\n    ++ends[symbols[n - 1]];\n    small[n - 1] = 1;',1).replace('    for (int i = n - 2; i >= 0; --i) {\n        small[i]', '    for (int i = n - 2; i >= 0; --i) {\n        ++ends[symbols[i]];\n        small[i]',1).replace(block,'');(D/'hist_fused.hpp').write_text(fused)
old=Path('/tmp/sirkit_suffix_416494');(D/'fixtures.json').write_bytes((old/'fixtures.json').read_bytes())
for file in ['build.py','benchmark.py','test_candidates.py','validate_final.py']:
 s=(old/file).read_text().replace('/tmp/sirkit_suffix_416494','/tmp/sirkit_suffix_416499');(D/file).write_text(s)
