# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,fcntl,shutil,random,statistics
D=Path('/tmp/sirkit_suffix_416499')
rows=[];summary=[];rng=random.Random(416379)
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for setting in ['checked','skip']:
   for kind in [1,6]:
    for n in [500000,1000000]:
     for shape in range(3):
      local=[]
      for rep in range(15):
       labels=['base','control','hist_fused','hist4','hist8'];rng.shuffle(labels)
       for label in labels:
        shutil.copyfile(D/f'generic_{cc}_{setting}_{"base"if label=="control"else label}',D/'active');(D/'active').chmod(0o700)
        cmd=['setarch','x86_64','-R','taskset','-c','12',str(D/'active'),str(kind),str(n),str(shape),str(max(1,32768//n))]
        p=subprocess.run(cmd,check=True,capture_output=True,text=True);ns,digest=map(int,p.stdout.split());row=dict(compiler=cc,setting=setting,kind=kind,n=n,shape=shape,rep=rep,label=label,ns=ns,digest=digest);local.append(row);rows.append(row)
      assert len({r['digest']for r in local})==1
      b=statistics.median(r['ns']for r in local if r['label']in ['base','control']);m={l:statistics.median(r['ns']for r in local if r['label']==l)for l in labels};s=dict(compiler=cc,setting=setting,kind=kind,n=n,shape=shape,base_ns=b,medians=m,ratios={l:m[l]/b for l in labels});summary.append(s);print(s,flush=True)
      (D/'generic_targeted_raw.json').write_text(json.dumps(rows));(D/'generic_targeted_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
