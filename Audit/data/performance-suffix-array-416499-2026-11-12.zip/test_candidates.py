# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,os,sys
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_suffix_416499');rows=[]
for label in sys.argv[1:]:
 cmd=['taskset','-c','4','/usr/bin/g++','-std=c++23','-O2','-fsanitize=address,undefined','-fno-sanitize-recover=all',f'-DSUFFIX_HEADER="{D}/{label}.hpp"',str(R/'Verify/current/tests/string_algorithms_reference_test.cpp'),'-o',str(D/f'test_{label}')];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=0:halt_on_error=1';p=subprocess.run(['taskset','-c','4',str(D/f'test_{label}')],capture_output=True,text=True,env=env);row=dict(label=label,command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr);rows.append(row);(D/'candidate_tests.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,p.returncode,p.stdout,flush=True);assert p.returncode==0 and not p.stderr,row
