# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_suffix_416499/agent')
base=(R/'String/Suffix_Array.cpp').read_text()
old='    for (int symbol : symbols) ++ends[symbol];'
assert base.count(old)==1
metadata={'source':'String/Suffix_Array.cpp','source_sha256':hashlib.sha256(base.encode()).hexdigest(),'canonical_modified':False,'compiled_or_tested':False,'candidates':{}}
for width in [4,8]:
 lines=[
  '    if (alphabet <= 256 && n >= 4096) {',
  f'        std::array<std::array<int, 257>, {width-1}> counts{{}};',
  '        int i = 0;',
  f'        for (; i <= n - {width}; i += {width}) {{',
  '            ++ends[symbols[i]];',
 ]
 for lane in range(1,width):
  lines.append(f'            ++counts[{lane-1}][symbols[i + {lane}]];')
 lines += ['        }','        for (; i < n; ++i) ++ends[symbols[i]];','        for (int symbol = 0; symbol <= alphabet; ++symbol)']
 terms=' + '.join(f'counts[{lane}][symbol]'for lane in range(width-1))
 if width==4:
  lines.append(f'            ends[symbol] += {terms};')
 else:
  lines += ['            ends[symbol] += counts[0][symbol] + counts[1][symbol] + counts[2][symbol] +',
            '                counts[3][symbol] + counts[4][symbol] + counts[5][symbol] + counts[6][symbol];']
 lines += ['    } else {',old,'    }']
 replacement='\n'.join(lines)
 code=base.replace('#include <algorithm>','#include <algorithm>\n#include <array>',1).replace(old,replacement,1)
 # Includes and this histogram block are the only differences.
 assert code.replace('#include <array>\n','',1).replace(replacement,old,1)==base
 p=D/f'hist{width}.hpp';p.write_text(code)
 metadata['candidates'][p.name]={'sha256':hashlib.sha256(code.encode()).hexdigest(),'lanes':width,'additional_ints':(width-1)*257,'additional_bytes_if_int32':(width-1)*257*4,'branch':'alphabet <= 256 && n >= 4096','fallback':'original scalar histogram loop','API_classifier_induce_checks_and_ownership_unchanged':True}
(D/'metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(metadata,ensure_ascii=False,indent=2))
