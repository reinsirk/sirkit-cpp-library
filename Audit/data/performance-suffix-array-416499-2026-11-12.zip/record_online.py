# SPDX-License-Identifier: CC0-1.0
# 保存済み公開API応答と提出前スナップショットを照合する。ネット/コンパイル/本体編集なし。
from pathlib import Path
import datetime,hashlib,json
D=Path('/tmp/sirkit_suffix_416499')
AUDIT='Audit/online-suffix-array-416499-416500-2026-11-12.json'
JOBS=[('suffix_array',416499,'suffixarray'),('suffix_array_substrings',416500,'number_of_substrings')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s):
    return '\n'.join(line.rstrip() for line in s.replace('\r\n','\n').splitlines()
                     if line.strip() and not line.startswith('// Submission:'))
checked=datetime.datetime.now(datetime.timezone.utc).isoformat()
records=[];sources=[]
for identifier,submission,problem in JOBS:
    response=D/f'{submission}.json';saved=D/f'{submission}.cpp';a=json.loads(response.read_text());o=a['overview']
    assert o['id']==submission and o['problem_name']==problem
    assert saved.read_bytes()==a['source'].encode(),(identifier,'API source and saved cpp differ bytewise')
    snapshot=D/f'before/Verify/current/submissions/{identifier}.cpp'
    assert norm(a['source'])==norm(snapshot.read_text()),(identifier,'normalized source mismatch')
    driver=f'Verify/current/drivers/{identifier}_main.cpp';io='Verify/current/common/fast_io.hpp';library='String/Suffix_Array.cpp'
    record=dict(id=identifier,status=o['status'],url=f'https://judge.yosupo.jp/submission/{submission}',time_ms=round(o['time']*1000),memory_bytes=o['memory'],language=o['lang'],submission_time=o['submission_time'],checked_at_utc=checked,case_results=a['case_results'],submission_sha256=sha(snapshot),uploaded_source_sha256=sha(saved),source_hashes={library:sha(D/'before'/library)},driver_sha256=sha(D/'before'/driver),io_source_hashes={io:sha(D/'before'/io)},io_mode='shared_fast_io',matched_preoptimization_snapshot=True,source_match='空行・改行・行末空白・Submission注記のみ除いて、保存済み提出本文と変更前の本体/main/共通IOが一致。',evidence_file=AUDIT)
    records.append(record);sources.append(dict(id=identifier,endpoint=f'https://v3.api.judge.yosupo.jp/submissions/{submission}',response_file=str(response),response_sha256=sha(response),saved_source_file=str(saved),saved_source_sha256=sha(saved),preoptimization_snapshot=str(snapshot),is_latest_at_saved_API_snapshot=o.get('is_latest')))
output=dict(records=records,endpoints=[s['endpoint'] for s in sources],checked_at_utc=checked,normalization='CRLFをLFにし、空行・行末空白・先頭が // Submission: の注記のみ除く。他のコード/pragmaは除外しない。',source_snapshots=sources,scope='保存済み公開APIの今回のACと提出時の変更前スナップショット一致を確認。checked_atはローカル照合時刻でありAPI再取得時刻ではない。今後の高速化版や派生版のオンラインACを意味しない。')
(D/'online_records.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print([(r['id'],r['status'],r['time_ms'],r['matched_preoptimization_snapshot'])for r in records])
