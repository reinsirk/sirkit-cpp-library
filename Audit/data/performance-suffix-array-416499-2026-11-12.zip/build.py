# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,json,hashlib,subprocess
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_suffix_416499');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as p;rows=[]
for label in sys.argv[1:]:
 header=D/(label+'.hpp')
 for id in ['suffix_array','suffix_array_substrings']:
  e=next(x for x in p.collect()if x['id']==id);data,_=p.render(e,source_overrides={'String/Suffix_Array.cpp':header.read_bytes()});src=D/f'{label}_{id}.cpp';src.write_bytes(data)
  for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
   exe=D/f'{cc}_{label}_{id}';cmd=['taskset','-c','4',*args,'-std=c++23','-O2',str(src),'-o',str(exe)];subprocess.run(cmd,check=True)
   for sample in e['samples']:
    r=subprocess.run([str(exe)],input=sample['input'],text=True,capture_output=True);assert not r.stderr and p.matches(e,sample,r.stdout)
   rows.append(dict(label=label,id=id,compiler=cc,command=cmd,source_sha256=hashlib.sha256(data).hexdigest()));print(cc,label,id,'PASS',flush=True)
path=D/'builds.json';a=json.loads(path.read_text())if path.exists()else[];path.write_text(json.dumps(a+rows,indent=2)+'\n')
