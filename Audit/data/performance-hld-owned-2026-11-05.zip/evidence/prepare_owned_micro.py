# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json
D=Path('/tmp/sirkit_hld_opt_20261105');rows=[]
for cc in ['gcc','clang']:
 for vid in ['hld_path_prod','hld_path_composite','fenwick_tree']:
  cmd=['python3',str(D/'micro/build_micro.py'),'--id',vid,'--hld',str(D/'combined_candidate.hpp'),'--fenwick',str(D/'fenwick/owned_access_fw.hpp'),'--compiler',cc,'--name','owned_access'];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr;rows.append(dict(label='owned_access',id=vid,compiler=cc));print(cc,vid,'READY',flush=True)
(D/'micro/owned_recipes.json').write_text(json.dumps(rows,indent=2)+'\n')
