# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib,sys
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_opt_20261105');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv;es={e['id']:e for e in pv.collect()};rows=[]
recipes=[('fused_small','hld_path_composite',{'Graph/Heavy_Light_Decomposition.cpp':(D/'ordered/fused_small.hpp').read_bytes()}),('base','fenwick_tree',{})]
for label in ['mask_all','mask64','mask256','converge64']:
 for vid in ['hld_path_prod','fenwick_tree']:
  recipes.append((label,vid,{'DataStructure/Fenwick_Tree.cpp':(D/f'fenwick/{label}.hpp').read_bytes()}))
for label,vid,over in recipes:
 data,_=pv.render(es[vid],source_overrides=over);src=D/f'{vid}_{label}.cpp';src.write_bytes(data)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  exe=D/f'{cc}_{vid}_{label}';cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(src),'-o',str(exe)];subprocess.run(cmd,check=True);rows.append(dict(label=label,id=vid,compiler=cc,command=cmd,program_sha256=hashlib.sha256(data).hexdigest(),source_override_hashes={k:hashlib.sha256(v).hexdigest()for k,v in over.items()}))
(D/'more_builds.json').write_text(json.dumps(rows,indent=2)+'\n');print('More candidate binaries ready')
