# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,subprocess,fcntl,time
D=Path('/tmp/sirkit_hld_opt_20261105');M=D/'micro';F=D/'fixtures';out=M/'large_results';out.mkdir(exist_ok=True);f=json.loads((F/'fixtures.json').read_text())+json.loads((F/'point_fixtures.json').read_text());by={x['name']:x for x in f};recipes=json.loads((M/'large_recipes.json').read_text());summary=[]
sets={
 'hld_path_prod':['official_vertex_add_path_sum_max_random_0','official_vertex_add_path_sum_long-path-decomposition_killer_0','official_vertex_add_path_sum_line_0','custom_vertex_add_path_sum_250000_balanced','custom_vertex_add_path_sum_32_random_queryheavy','custom_vertex_add_path_sum_4096_random_queryheavy'],
 'hld_path_composite':['official_vertex_set_path_composite_max_random_0','official_vertex_set_path_composite_worst_for_path_decomposition_0','official_vertex_set_path_composite_line_0','custom_vertex_set_path_composite_250000_balanced','custom_vertex_set_path_composite_32_random_queryheavy','custom_vertex_set_path_composite_4096_random_queryheavy'],
 'fenwick_tree':[x['name']for x in f if x['problem']=='point_add_range_sum']}
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for r in recipes:
  vid,label=r['id'],r['label'];cc=r.get('compiler','gcc');exe=M/f'{cc}_{vid}_{label}'
  for case in sets[vid]:
   load=Path('/proc/loadavg').read_text().strip();cmd=['taskset','-c','12',str(exe),by[case]['path'],'2'];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,(cmd,p.stderr);v=json.loads(p.stdout);assert v['all_outputs_equal'];v['invocation']=dict(command=cmd,loadavg_before=load,loadavg_after=Path('/proc/loadavg').read_text().strip());file=out/f'{cc}_{vid}_{label}_{case}.json';file.write_text(json.dumps(v)+'\n');row=dict(compiler=cc,id=vid,label=label,case=case,file=str(file),total=v['total_ratios'],median=v['paired_median_ratios'],geomean=v['paired_geometric_mean_ratios']);summary.append(row);(M/'large_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(vid,label,case,'total',row['total'],'pairedmedian',row['median'],flush=True)
print('Micro complete cases=',len(summary),flush=True)
