# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_opt_20261105/fenwick');s=(R/'DataStructure/Fenwick_Tree.cpp').read_text()
old='''    T sum(int l, int r) {
        check_range(l, r);
        return static_cast<T>(prefix_unchecked(static_cast<std::size_t>(r)) - prefix_unchecked(static_cast<std::size_t>(l)));
    }''';assert old in s
rows=[]
for block in [32,64,256]:
 new='''    T sum(int l, int r) {
        check_range(l, r);
        if constexpr (std::is_floating_point_v<T>) {
            return static_cast<T>(prefix_unchecked(static_cast<std::size_t>(r)) - prefix_unchecked(static_cast<std::size_t>(l)));
        } else {
            if (l == r) return T{};
            auto a = static_cast<unsigned int>(l), b = static_cast<unsigned int>(r);
'''+f'''            if ((a ^ b) < {block}U) {{
                const auto shared = b & ~{block-1}U;
'''+'''                Storage left{}, right{};
                for (; b != shared; b &= b - 1U) right += tree_[b];
                for (; a != shared; a &= a - 1U) left += tree_[a];
                return static_cast<T>(right - left);
            }
            return static_cast<T>(prefix_unchecked(static_cast<std::size_t>(r)) - prefix_unchecked(static_cast<std::size_t>(l)));
        }
    }'''
 p=D/f'block{block}.hpp';p.write_text(s.replace(old,new));rows.append(dict(name=p.stem,block=block,path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(D/'block_candidates.json').write_text(json.dumps(rows,indent=2)+'\n');print('\n'.join(x['path']for x in rows))
