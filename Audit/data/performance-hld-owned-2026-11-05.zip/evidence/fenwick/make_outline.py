# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json,difflib
D=Path('/tmp/sirkit_hld_opt_20261105');src=D/'combined_candidate.hpp';s=src.read_text();method=s.index('    value_type path_prod(int u, int v, bool edges = false) {',s.index('class HeavyLightValues'))
needle='''                if (tree.size() > 4096) {''';a=s.index(needle,method);brace=s.index('{',a);depth=1;p=brace+1
while depth:
 if s[p]=='{':depth+=1
 elif s[p]=='}':depth-=1
 p+=1
body=s[brace+1:p-1]
body='\n'.join(line[12:]if line.startswith('            ')else line for line in body.splitlines()).strip()
helper='''#if defined(__GNUC__) && !defined(__clang__)
    [[gnu::noinline]] value_type path_sum_large(int u, int v, bool edges) {
        using Access = reinsirk::detail::HldFenwickAccess<Range>;
        auto& forward = state_->range;
        const auto& tree = state_->layout;
'''+body+'''
    }
#endif
'''
start=s.rfind('                const auto& tree',method,a) # original has 16? search fallback
if start<0:start=s.index('                const auto& tree = state_->layout;',method)
# Actual source indentation of this line is 16 spaces.
old=s[start:p]
new='''#if defined(__GNUC__) && !defined(__clang__)
                if (state_->layout.size() > 4096) return path_sum_large(u, v, edges);
#else
'''+old+'''
#endif'''
s=s[:start]+s[start:].replace(old,new,1)
marker='''public:
    HeavyLightValues() = default;''';assert s.count(marker)==1;s=s.replace(marker,helper+marker,1)
out=D/'combined_outline.hpp';out.write_text(s)
(D/'outline.patch').write_text(''.join(difflib.unified_diff(src.read_text().splitlines(True),s.splitlines(True),fromfile=str(src),tofile=str(out))))
(D/'outline_metadata.json').write_text(json.dumps(dict(base=str(src),base_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),candidate=str(out),candidate_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),scope='GCC-only noinline large Fenwick query extraction; unchanged math, Clang original public body retained'),indent=2)+'\n');print(out)
