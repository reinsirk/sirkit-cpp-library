# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib,os
D=Path('/tmp/sirkit_hld_opt_20261105/fenwick');rows=[]
for name in ['mask64_large','block64_large']:
 for compiler,args in [('GCC',['/usr/bin/g++'])]:
  source=D/f'{name}.hpp';exe=D/f'{compiler}_{name}';cmd=['taskset','-c','6',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',f'-DFW_SOURCE="{source}"',str(D/'large_reference_test.cpp'),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','6',str(exe)],capture_output=True,text=True);assert p.returncode==0 and not p.stderr,p.stderr;rows.append(dict(candidate=name,compiler=compiler,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),compile_command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));(D/'large_reference_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,compiler,p.stdout.strip(),flush=True)
