# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib
D=Path('/tmp/sirkit_hld_opt_20261105/fenwick');rows=[]
for cc,args in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 blobs=[]
 for label,header in [('prior',D/'before_float_fallback/mask64.hpp'),('float_fallback',D/'mask64.hpp')]:
  exe=D/f'{cc}_{label}';cmd=['taskset','-c','6',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',f'-DFW_SOURCE="{header}"',str(D/'reference_test.cpp'),'-o',str(exe)];subprocess.run(cmd,check=True);text=D/f'{cc}_{label}.text';subprocess.run(['objcopy','--dump-section',f'.text={text}',str(exe)],check=True);blobs.append(text.read_bytes());rows.append(dict(compiler=cc,label=label,kind='integer_code',command=cmd,source_sha256=hashlib.sha256(header.read_bytes()).hexdigest(),text_sha256=hashlib.sha256(text.read_bytes()).hexdigest()))
 assert blobs[0]==blobs[1],cc
 exe=D/f'{cc}_float';cmd=['taskset','-c','6',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(D/'float_test.cpp'),'-o',str(exe)];subprocess.run(cmd,check=True);p=subprocess.run(['taskset','-c','6',str(exe)],text=True,capture_output=True);assert p.returncode==0 and not p.stderr,p.stderr;rows.append(dict(compiler=cc,kind='float_original_comparison',command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));(D/'float_and_code.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,'integer .text unchanged;',p.stdout.strip(),flush=True)
