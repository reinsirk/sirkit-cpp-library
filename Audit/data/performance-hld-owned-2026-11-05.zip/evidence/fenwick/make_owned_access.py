# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_opt_20261105/fenwick');B=D.parent/'before'
fwd='''#ifndef SIRKIT_HLD_FENWICK_ACCESS_FORWARD_DEFINED
#define SIRKIT_HLD_FENWICK_ACCESS_FORWARD_DEFINED
namespace reinsirk::detail { template<class Range> struct HldFenwickAccess; }
#endif

'''
fw=(B/'DataStructure/Fenwick_Tree.cpp').read_text();marker='#ifndef SIRKIT_FENWICK_STORAGE_TYPE_DEFINED';assert fw.count(marker)==1;fw=fw.replace(marker,fwd+marker,1);marker='''class fenwick_tree {
''';assert fw.count(marker)==1;fw=fw.replace(marker,marker+'''    using HldFenwickTag = void;
    template<class> friend struct reinsirk::detail::HldFenwickAccess;
''',1)
helper='''#ifndef SIRKIT_HLD_FENWICK_ACCESS_DEFINED
#define SIRKIT_HLD_FENWICK_ACCESS_DEFINED
namespace reinsirk::detail {
template<class Range>
struct HldFenwickAccess {
    static constexpr bool enabled = [] {
        if constexpr (requires(Range& range) { typename Range::HldFenwickTag; range.sum(0, 0); }) {
            using Value = std::remove_cvref_t<decltype(std::declval<Range&>().sum(0, 0))>;
            return !std::is_floating_point_v<Value> && !std::is_same_v<Value, bool>;
        } else return false;
    }();
    static auto sum_original(Range& range, int l, int r) {
        using Value = decltype(range.sum(l, r));
        return static_cast<Value>(range.prefix_unchecked(static_cast<std::size_t>(r))
                                - range.prefix_unchecked(static_cast<std::size_t>(l)));
    }
    static auto sum_short(Range& range, int l, int r) {
        using Value = decltype(range.sum(l, r));
        if (r - l > 64) return sum_original(range, l, r);
        if (l == r) return Value{};
        auto a = static_cast<unsigned int>(l), b = static_cast<unsigned int>(r);
        const auto shared = b & ~((std::bit_floor(a ^ b) << 1) - 1U);
        typename Range::Storage left{}, right{};
        for (; b != shared; b &= b - 1U) right += range.tree_[b];
        for (; a != shared; a &= a - 1U) left += range.tree_[a];
        return static_cast<Value>(right - left);
    }
};
}
#endif

'''
hld=(B/'Graph/Heavy_Light_Decomposition.cpp').read_text();hld=hld.replace('#include <array>','#include <array>\n#include <bit>',1);marker='#ifndef SIRKIT_HEAVY_LIGHT_DECOMPOSITION_DEFINED';hld=hld.replace(marker,fwd+marker,1);marker='''private:
    int root_ = -1;''';assert marker in hld;hld=hld.replace(marker,'''private:
    template<class, bool> friend class HeavyLightValues;
    int root_ = -1;''',1);marker='#ifndef SIRKIT_HEAVY_LIGHT_VALUES_DEFINED';hld=hld.replace(marker,helper+marker,1)
old='''        if constexpr (!Ordered) return layout().path_prod(u, v, forward, edges);
        else return layout().path_prod(u, v, Traits::identity(), [&](int l, int r, bool reverse) {'''
new='''        if constexpr (!Ordered) {
            using Access = reinsirk::detail::HldFenwickAccess<Range>;
            if constexpr (Access::enabled) {
                const auto& tree = state_->layout;
                if (tree.size() > 4096) {
#ifndef SKIP_RUNTIME_CHECKS
                    tree.vertex(u); tree.vertex(v);
#endif
                    if (tree.head_[u] == tree.head_[v]) {
                        const int l = std::min(tree.index_[u], tree.index_[v]) + static_cast<int>(edges);
                        const int r = std::max(tree.index_[u], tree.index_[v]) + 1;
                        return l < r ? Access::sum_original(forward, l, r) : value_type{};
                    }
                    return tree.path_prod(u, v, value_type{}, [&](int l, int r) {
                        return Access::sum_short(forward, l, r);
                    }, reinsirk::detail::HldAddition{}, edges);
                }
            }
            return layout().path_prod(u, v, forward, edges);
        } else return layout().path_prod(u, v, Traits::identity(), [&](int l, int r, bool reverse) {'''
assert hld.count(old)==1;hld=hld.replace(old,new,1)
rows=[]
for name,s in [('owned_access_fw.hpp',fw),('owned_access_hld.hpp',hld)]:
 p=D/name;p.write_text(s);rows.append(dict(name=name,path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
# Exact original sum method remains intact.
getsum=lambda s:s[s.index('    T sum(int l, int r) {'):s.index('    int lower_bound',s.index('    T sum(int l, int r) {'))]
assert getsum(fw)==getsum((B/'DataStructure/Fenwick_Tree.cpp').read_text())
(D/'owned_access_candidates.json').write_text(json.dumps(rows,indent=2)+'\n');print('Owned access candidates ready; global Fenwick sum unchanged')
