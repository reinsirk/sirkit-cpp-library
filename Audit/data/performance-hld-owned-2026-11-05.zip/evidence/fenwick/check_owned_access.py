# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib,os
D=Path('/tmp/sirkit_hld_opt_20261105/fenwick');R=Path('/home/reinsirk/Atcoder_Env');B=D.parent/'before';rows=[]
for cc,args in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for flags in [[],['-DFW_FIRST'],['-DOLD_FW'],['-DFW_FIRST','-DOLD_FW'],['-DSKIP_RUNTIME_CHECKS']]:
  exe=D/f'owned_{cc}_{len(rows)}';cmd=['taskset','-c','6',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror','-I'+str(R/'Verify/current/vendor'),*flags,str(D/'owned_access_smoke.cpp'),'-o',str(exe)];subprocess.run(cmd,check=True);p=subprocess.run(['taskset','-c','6',str(exe)],text=True,capture_output=True);assert p.returncode==0 and not p.stderr,p.stderr;rows.append(dict(compiler=cc,kind='mixed_header_smoke',flags=flags,compile_command=cmd,returncode=p.returncode));print(cc,flags,'smoke PASS',flush=True)
 # Large and short interval arithmetic itself, ASan+UBSan on the private friend path.
 exe=D/f'owned_{cc}_reference';cmd=['taskset','-c','6',*args,'-std=c++23','-O1','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-omit-frame-pointer',f'-DFW_SOURCE="{D}/owned_access_fw.hpp"',str(D/'owned_access_reference.cpp'),'-o',str(exe)];subprocess.run(cmd,check=True);p=subprocess.run(['taskset','-c','6',str(exe)],text=True,capture_output=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'});assert p.returncode==0 and not p.stderr,p.stderr;rows.append(dict(compiler=cc,kind='friend_private_reference',compile_command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));print(cc,p.stdout.strip(),flush=True)
 blobs=[]
 for label,header in [('old',B/'DataStructure/Fenwick_Tree.cpp'),('friend',D/'owned_access_fw.hpp')]:
  src=D/f'point_{label}.cpp';src.write_text('#define SKIP_RUNTIME_CHECKS\n'+header.read_text()+'\n'+(B/'Verify/current/common/fast_io.hpp').read_text()+'\n'+(R/'Verify/current/drivers/fenwick_tree_main.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"',''));exe=D/f'point_{cc}_{label}';cmd=['taskset','-c','6',*args,'-std=c++23','-O2',str(src),'-o',str(exe)];subprocess.run(cmd,check=True);text=D/f'point_{cc}_{label}.text';subprocess.run(['objcopy','--dump-section',f'.text={text}',str(exe)],check=True);blobs.append(text.read_bytes());rows.append(dict(compiler=cc,kind='standalone_fenwick_code',label=label,compile_command=cmd,text_sha256=hashlib.sha256(text.read_bytes()).hexdigest()))
 assert blobs[0]==blobs[1],cc
 print(cc,'standalone Fenwick .text EXACT MATCH',flush=True)
 (D/'owned_access_results.json').write_text(json.dumps(rows,indent=2)+'\n')
