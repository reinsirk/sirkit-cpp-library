// SPDX-License-Identifier: CC0-1.0
#ifndef FW_SOURCE
#define FW_SOURCE "/home/reinsirk/Atcoder_Env/DataStructure/Fenwick_Tree.cpp"
#endif
#include FW_SOURCE
#include <cassert>
#include <cstdint>
#include <iostream>
#include <limits>
#include <random>
#include <vector>
namespace {
std::uint64_t checks=0;
template<class T>struct Unsigned{using type=std::make_unsigned_t<T>;};
#if defined(__SIZEOF_INT128__)
template<>struct Unsigned<__int128>{using type=unsigned __int128;};
template<>struct Unsigned<unsigned __int128>{using type=unsigned __int128;};
#endif
template<class T>void integer_test(){
 using U=typename Unsigned<T>::type;std::mt19937_64 random(20261105+sizeof(T));
 auto next=[&](){U x=static_cast<U>(random());if constexpr(sizeof(U)>8)x=(x<<64)|static_cast<U>(random());return x;};
 for(int n:{0,1,2,3,7,16,31,64,65,127,511,4096,4097,8192}){
  std::vector<T> initial;std::vector<U> expected;for(int i=0;i<n;++i){U x=next();initial.push_back(static_cast<T>(x));expected.push_back(x);}fenwick_tree<T> tree(initial);
  auto query=[&](int l,int r){U answer{};for(int i=l;i<r;++i)answer=static_cast<U>(answer+expected[i]);assert(static_cast<U>(tree.sum(l,r))==answer);++checks;};
  query(0,n);for(int i=0;i<=n;++i){query(i,i);if(i<n)query(i,i+1);}if(n<=64)for(int l=0;l<=n;++l)for(int r=l;r<=n;++r)query(l,r);
  for(int z=0;z<1500;++z){
   if(n&&z%4<2){int p=static_cast<int>(random()%n);U x=next();if(z%4==0){tree.add(p,static_cast<T>(x));expected[p]=static_cast<U>(expected[p]+x);}else{tree.set(p,static_cast<T>(x));expected[p]=x;}assert(static_cast<U>(tree.get(p))==expected[p]);++checks;}
   else{int l=static_cast<int>(random()%(n+1)),r=static_cast<int>(random()%(n+1));if(l>r)std::swap(l,r);query(l,r);}
  }
  auto values=tree.values();assert(values.size()==expected.size());for(int i=0;i<n;++i){assert(static_cast<U>(values[i])==expected[i]);++checks;}
#ifndef SKIP_RUNTIME_CHECKS
  bool caught=false;try{tree.sum(-1,n);}catch(const std::out_of_range&){caught=true;}assert(caught);++checks;
#endif
 }
}
struct Group{
 std::uint64_t x=0;
 Group()=default;explicit Group(std::uint64_t a):x(a){}
 Group& operator+=(const Group& b){x+=b.x;return *this;}
 friend Group operator-(const Group&a,const Group&b){return Group(a.x-b.x);}
 bool operator==(const Group&)const=default;
};
void group_test(){
 std::mt19937_64 random(14);std::vector<Group> initial;std::vector<std::uint64_t> expected;for(int i=0;i<257;++i){auto x=random();initial.emplace_back(x);expected.push_back(x);}fenwick_tree<Group> tree(initial);
 for(int z=0;z<5000;++z){if(z%3==0){int p=random()%257;auto delta=random();tree.add(p,Group(delta));expected[p]+=delta;}else{int l=random()%258,r=random()%258;if(l>r)std::swap(l,r);std::uint64_t sum=0;for(int i=l;i<r;++i)sum+=expected[i];assert(tree.sum(l,r).x==sum);++checks;}}
}
}
int main(){
 integer_test<std::int8_t>();integer_test<std::uint8_t>();integer_test<std::int16_t>();integer_test<std::uint16_t>();integer_test<std::int32_t>();integer_test<std::uint32_t>();integer_test<std::int64_t>();integer_test<std::uint64_t>();
#if defined(__SIZEOF_INT128__)
 integer_test<__int128>();integer_test<unsigned __int128>();
#endif
 group_test();std::cout<<"Fenwick reference checks="<<checks<<'\n';
}
