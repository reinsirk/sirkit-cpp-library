// SPDX-License-Identifier: CC0-1.0
#ifdef OLD_FW
#include "/home/reinsirk/Atcoder_Env/DataStructure/Fenwick_Tree.cpp"
#endif
#ifdef FW_FIRST
#include "/tmp/sirkit_hld_opt_20261105/fenwick/owned_access_fw.hpp"
#include "/tmp/sirkit_hld_opt_20261105/fenwick/owned_access_hld.hpp"
#else
#include "/tmp/sirkit_hld_opt_20261105/fenwick/owned_access_hld.hpp"
#include "/tmp/sirkit_hld_opt_20261105/fenwick/owned_access_fw.hpp"
#endif
#include "/home/reinsirk/Atcoder_Env/DataStructure/Segment_Tree.cpp"
#include "/home/reinsirk/Atcoder_Env/Verify/current/vendor/atcoder/fenwicktree.hpp"
#include <cassert>
#include <cstdint>
using I=std::int64_t;
I combine(I a,I b){return a+b;}I identity(){return 0;}
#ifdef OLD_FW
static_assert(!reinsirk::detail::HldFenwickAccess<fenwick_tree<I>>::enabled);
#else
static_assert(reinsirk::detail::HldFenwickAccess<fenwick_tree<I>>::enabled);
#endif
static_assert(!reinsirk::detail::HldFenwickAccess<fenwick_tree<float>>::enabled);
static_assert(!reinsirk::detail::HldFenwickAccess<fenwick_tree<bool>>::enabled);
static_assert(!reinsirk::detail::HldFenwickAccess<atcoder::fenwick_tree<I>>::enabled);
static_assert(!reinsirk::detail::HldFenwickAccess<segtree<I,combine,identity>>::enabled);
int main(){Graph graph(5000);for(int i=1;i<5000;++i){int p=(i-1)/2;graph[p].push_back(i);graph[i].push_back(p);}std::vector<I>a(5000,1);
 auto h=HeavyLightDecomposition(graph).with_values<fenwick_tree<I>>(a);auto acl=HeavyLightDecomposition(graph).with_values<atcoder::fenwick_tree<I>>(a);auto seg=HeavyLightDecomposition(graph).with_values<segtree<I,combine,identity>>(a);
 for(int u:{0,1,9,64,1024,4095,4999})for(int v:{0,1,8,63,1023,4096,4998}){assert(h.path_prod(u,v)==seg.path_prod(u,v));assert(h.path_prod(u,v,true)==acl.path_prod(u,v,true));}
 assert(h.path_prod(4099,4099)==1);assert(h.path_prod(4099,4099,true)==0);
#ifndef SKIP_RUNTIME_CHECKS
 bool caught=false;try{h.path_prod(-1,0);}catch(const std::out_of_range&){caught=true;}assert(caught);
#endif
}
