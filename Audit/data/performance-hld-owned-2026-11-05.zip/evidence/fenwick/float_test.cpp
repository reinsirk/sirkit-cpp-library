// SPDX-License-Identifier: CC0-1.0
#define fenwick_tree OriginalFenwick
#include "/home/reinsirk/Atcoder_Env/DataStructure/Fenwick_Tree.cpp"
#undef fenwick_tree
#undef SIRKIT_FENWICK_TREE_DEFINED
#ifndef FW_SOURCE
#define FW_SOURCE "/tmp/sirkit_hld_opt_20261105/fenwick/mask64.hpp"
#endif
#include FW_SOURCE
#include <bit>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <random>
std::uint64_t checks=0;
template<class F>void test(){std::mt19937 random(2718);std::vector<F> v(511);for(auto&x:v)x=std::ldexp(static_cast<F>(static_cast<int>(random()%201)-100),static_cast<int>(random()%161)-80);OriginalFenwick<F> old(v);fenwick_tree<F> candidate(v);
 for(int z=0;z<30000;++z){if(z%5==0){int p=random()%511;F delta=std::ldexp(static_cast<F>(static_cast<int>(random()%201)-100),static_cast<int>(random()%161)-80);old.add(p,delta);candidate.add(p,delta);}else{int l=random()%512,r=random()%512;if(l>r)std::swap(l,r);F a=old.sum(l,r),b=candidate.sum(l,r);if constexpr(sizeof(F)==4)assert(std::bit_cast<std::uint32_t>(a)==std::bit_cast<std::uint32_t>(b));else if constexpr(sizeof(F)==8)assert(std::bit_cast<std::uint64_t>(a)==std::bit_cast<std::uint64_t>(b));else assert((a==b||(std::isnan(a)&&std::isnan(b)))&&std::signbit(a)==std::signbit(b));++checks;}}
}
int main(){test<float>();test<double>();test<long double>();std::cout<<"Fenwick original-float checks="<<checks<<'\n';}
