# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_opt_20261105/fenwick');s=(R/'DataStructure/Fenwick_Tree.cpp').read_text()
old='''    T sum(int l, int r) {
        check_range(l, r);
        return static_cast<T>(prefix_unchecked(static_cast<std::size_t>(r)) - prefix_unchecked(static_cast<std::size_t>(l)));
    }'''
assert old in s
rows=[]
for name,threshold,strategy in [('mask_all',None,'mask'),('mask16',16,'mask'),('mask64',64,'mask'),('mask256',256,'mask'),('converge_all',None,'converge'),('converge64',64,'converge')]:
 pre='''    T sum(int l, int r) {
        check_range(l, r);
        if constexpr (std::is_floating_point_v<T>) {
            return static_cast<T>(prefix_unchecked(static_cast<std::size_t>(r)) - prefix_unchecked(static_cast<std::size_t>(l)));
        } else {
'''
 if threshold is not None:pre+=f'        if (r - l > {threshold})\n            return static_cast<T>(prefix_unchecked(static_cast<std::size_t>(r)) - prefix_unchecked(static_cast<std::size_t>(l)));\n'
 pre+='''        if (l == r) return T{};
        auto a = static_cast<unsigned int>(l), b = static_cast<unsigned int>(r);
        Storage left{}, right{};
'''
 if strategy=='mask':pre+='''        // 最高の相違bitより上は両prefixで共通なので、差分には不要。
        const auto shared = b & ~((std::bit_floor(a ^ b) << 1) - 1U);
        for (; b != shared; b &= b - 1U) right += tree_[b];
        for (; a != shared; a &= a - 1U) left += tree_[a];
'''
 else:pre+='''        // 単調に小さくなるprefixを共通の祖先まで読み、上側を相殺する。
        while (a != b) {
            if (a < b) { right += tree_[b]; b &= b - 1U; }
            else { left += tree_[a]; a &= a - 1U; }
        }
'''
 pre+='''        return static_cast<T>(right - left);
        }
    }'''
 marker='        } else {\n'; begin=pre.index(marker)+len(marker); end=pre.rfind('\n        }\n    }'); pre=pre[:begin]+''.join('    '+line+'\n'for line in pre[begin:end].splitlines()).rstrip('\n')+pre[end:]
 p=D/f'{name}.hpp';p.write_text(s.replace(old,pre));rows.append(dict(name=name,threshold=threshold,strategy=strategy,path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(D/'candidates.json').write_text(json.dumps(rows,indent=2)+'\n')
print('\n'.join(x['path']for x in rows))
