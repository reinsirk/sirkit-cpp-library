# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,os,random,statistics,shutil
D=Path('/tmp/sirkit_hld_opt_20261105');exe=D/'active_probe';shutil.copyfile(D/'gcc_hld_path_prod_base',exe);exe.chmod(0o700);inp=D/'fixtures/inputs/official_vertex_add_path_sum_max_random_0.in';rows=[];rng=random.Random(202611056)
for rep in range(7):
 cpus=[4,8,12,14];rng.shuffle(cpus)
 for cpu in cpus:
  freq=Path(f'/sys/devices/system/cpu/cpu{cpu}/cpufreq/scaling_cur_freq');start=freq.read_text().strip()
  with inp.open('rb')as fi,(D/'probe_output').open('wb')as fo:
   p=subprocess.Popen(['taskset','-c',str(cpu),str(exe)],stdin=fi,stdout=fo);_,st,r=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0
  rows.append(dict(cpu=cpu,rep=rep,cpu_ns=round((r.ru_utime+r.ru_stime)*1e9),freq_start=start,freq_end=freq.read_text().strip()))
(D/'core_probe.json').write_text(json.dumps(rows,indent=2)+'\n')
for cpu in [4,8,12,14]:
 a=[x['cpu_ns']/1e6 for x in rows if x['cpu']==cpu];print(cpu,[round(x,2)for x in a],'min/median/max',min(a),statistics.median(a),max(a),flush=True)
