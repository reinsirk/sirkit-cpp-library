# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,subprocess,os,statistics,random,fcntl,shutil,hashlib
D=Path('/tmp/sirkit_hld_opt_20261105');raw=[];rng=random.Random(20261105)
fixtures=json.loads((D/'fixtures/fixtures.json').read_text())+json.loads((D/'fixtures/point_fixtures.json').read_text());f={e['name']:e for e in fixtures}
sets={
'hld_path_prod':(['base','comm_all','state_direct','comm_direct','mask_all','mask64','mask256','converge64'],['official_vertex_add_path_sum_max_random_0','official_vertex_add_path_sum_long-path-decomposition_killer_0','official_vertex_add_path_sum_line_0','custom_vertex_add_path_sum_250000_balanced','custom_vertex_add_path_sum_250000_random','custom_vertex_add_path_sum_32_random_queryheavy','custom_vertex_add_path_sum_4096_random_queryheavy']),
'hld_path_composite':(['base','fused_small'],['official_vertex_set_path_composite_max_random_0','official_vertex_set_path_composite_worst_for_path_decomposition_0','official_vertex_set_path_composite_long-path-decomposition_killer_0','official_vertex_set_path_composite_line_0','custom_vertex_set_path_composite_250000_balanced','custom_vertex_set_path_composite_32_random_queryheavy','custom_vertex_set_path_composite_4096_random_queryheavy']),
'fenwick_tree':(['base','mask_all','mask64','mask256','converge64'],[])}
sets['fenwick_tree'][1].extend(e['name']for e in fixtures if e['problem']=='point_add_range_sum')
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for vid,(labels0,names)in sets.items():
  for cc in ['gcc','clang']:
   for case in names:
    inp=Path(f[case]['path']);inp.read_bytes()
    for rep in range(3):
     labels=labels0+['control'];rng.shuffle(labels)
     for label in labels:
      shutil.copyfile(D/f'{cc}_{vid}_{"base"if label=="control"else label}',D/'active');(D/'active').chmod(0o700)
      with inp.open('rb')as fi,(D/'output').open('wb')as fo:
       p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0,(vid,label,p.returncode)
      out_hash=hashlib.sha256((D/'output').read_bytes()).hexdigest()
      if f[case].get('expected_sha256'):assert out_hash==f[case]['expected_sha256'],(case,label)
      raw.append(dict(id=vid,compiler=cc,case=case,rep=rep,label=label,cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),rss_bytes=ru.ru_maxrss*1024,output_sha256=out_hash))
    rr=[x for x in raw if x['id']==vid and x['compiler']==cc and x['case']==case];assert len({x['output_sha256']for x in rr})==1;m={l:statistics.median(x['cpu_ns']for x in rr if x['label']==l)for l in labels};print(vid,cc,case,{l:round(m[l]/m['base'],4)for l in labels0+['control']},flush=True);(D/'screen_raw.json').write_text(json.dumps(raw))
summary=[]
for vid,(labels,names)in sets.items():
 for cc in ['gcc','clang']:
  for case in names:
   rr=[x for x in raw if x['id']==vid and x['compiler']==cc and x['case']==case];m={l:statistics.median(x['cpu_ns']for x in rr if x['label']==l)for l in labels+['control']};summary.append(dict(id=vid,compiler=cc,case=case,median_cpu_ns=m,ratios={l:m[l]/m['base']for l in m}))
(D/'screen_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('Screen complete runs=',len(raw),flush=True)
