# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_opt_20261105');strip=lambda s:'\n'.join(x for x in s.splitlines()if not x.lstrip().startswith('//'));sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
for name in ['Graph/Heavy_Light_Decomposition.cpp','DataStructure/Fenwick_Tree.cpp']:
 f=D/('combined_outline.hpp'if name.startswith('Graph')else'fenwick/owned_access_fw.hpp');assert strip((R/name).read_text())==strip(f.read_text());rows.append(dict(scope=name,result='Final source and validated/timed candidate differ only in full-line comments',canonical_sha256=sha((R/name).read_bytes()),candidate_sha256=sha(f.read_bytes())))
a=strip((D/'before/DataStructure/Fenwick_Tree.cpp').read_text()).split('class fenwick_tree {',1)[1];b=strip((R/'DataStructure/Fenwick_Tree.cpp').read_text()).split('class fenwick_tree {',1)[1];b=b.replace('    using HldFenwickTag = void;\n','').replace('    template<class> friend struct reinsirk::detail::HldFenwickAccess;\n','');assert a==b;rows.append(dict(scope='Fenwick class',result='All original fields and methods byte-identical; only private type alias and friend declaration added'))
def hldbody(p):return strip(p.read_text()).split('class HeavyLightDecomposition {',1)[1].split('#ifndef SIRKIT_HLD_OWNED_RANGE_TRAITS_DEFINED',1)[0].rstrip()
a=hldbody(D/'before/Graph/Heavy_Light_Decomposition.cpp');b=hldbody(R/'Graph/Heavy_Light_Decomposition.cpp').replace('    template<class, bool> friend class HeavyLightValues;\n','');assert a==b;rows.append(dict(scope='HeavyLightDecomposition class',result='All original fields and methods byte-identical; private owner friendship only'))
for name in ['Verify/current/drivers/hld_path_prod_main.cpp','Verify/current/drivers/hld_path_composite_main.cpp','Verify/current/drivers/hld_vertex_add_path_sum_main.cpp','Verify/current/drivers/hld_jump_main.cpp','Verify/current/common/fast_io.hpp']:
 assert(R/name).read_bytes()==(D/'before'/name).read_bytes();rows.append(dict(scope=name,sha256=sha((R/name).read_bytes()),result='Frozen byte-identical'))
(D/'source_proofs.json').write_text(json.dumps(rows,indent=2)+'\n');print('Source/body/main/IO preservation proofs passed')
