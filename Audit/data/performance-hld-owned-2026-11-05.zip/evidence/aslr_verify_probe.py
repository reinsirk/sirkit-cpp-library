# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,os,json,fcntl,random,statistics,shutil,hashlib
D=Path('/tmp/sirkit_hld_opt_20261105');fs={x['name']:x for x in json.loads((D/'fixtures/fixtures.json').read_text())};raw=[];rng=random.Random(2026110557)
cases=[('hld_path_prod','official_vertex_add_path_sum_max_random_0'),('hld_path_prod','official_vertex_add_path_sum_long-path-decomposition_killer_0'),('hld_path_prod','official_vertex_add_path_sum_line_0'),('hld_path_prod','custom_vertex_add_path_sum_250000_balanced'),('hld_path_composite','official_vertex_set_path_composite_worst_for_path_decomposition_0'),('hld_path_composite','official_vertex_set_path_composite_max_random_0'),('hld_path_composite','official_vertex_set_path_composite_line_0')]
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for vid,case in cases:
  for rep in range(7):
   labels=['base','control','owned_access'];rng.shuffle(labels)
   for label in labels:
    shutil.copyfile(D/f'gcc_{vid}_{"base"if label=="control"else label}',D/'active_aslr');(D/'active_aslr').chmod(0o700)
    cmd=['setarch','x86_64','-R','taskset','-c','12',str(D/'active_aslr')]
    with Path(fs[case]['path']).open('rb')as fi,(D/'aslr_output').open('wb')as fo:
     p=subprocess.Popen(cmd,stdin=fi,stdout=fo);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0
    raw.append(dict(id=vid,case=case,rep=rep,label=label,cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),rss_bytes=ru.ru_maxrss*1024,output_sha256=hashlib.sha256((D/'aslr_output').read_bytes()).hexdigest()))
  rr=[x for x in raw if x['id']==vid and x['case']==case];assert len({x['output_sha256']for x in rr})==1;m={l:statistics.median(x['cpu_ns']for x in rr if x['label']==l)for l in labels};print(vid,case,{l:round(m[l]/m['base'],4)for l in labels},'ms',{l:round(m[l]/1e6,2)for l in labels},flush=True);(D/'aslr_probe_raw.json').write_text(json.dumps(raw))
print('ASLR-off wholeVerify probe complete',len(raw),flush=True)
