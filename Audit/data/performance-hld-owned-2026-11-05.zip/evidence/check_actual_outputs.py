# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib
D=Path('/tmp/sirkit_hld_opt_20261105');fixtures=json.loads((D/'fixtures/fixtures.json').read_text())+json.loads((D/'fixtures/point_fixtures.json').read_text());rows=[]
for cc in ['gcc','clang']:
 for f in fixtures:
  vid={'vertex_add_path_sum':'hld_path_prod','vertex_set_path_composite':'hld_path_composite','point_add_range_sum':'fenwick_tree'}[f['problem']];hashes={}
  for label in ['base','owned_access']:
   exe=D/f'{cc}_{vid}_{label}'
   with Path(f['path']).open('rb')as fi,(D/'correctness_output').open('wb')as fo:p=subprocess.run(['taskset','-c','4',str(exe)],stdin=fi,stdout=fo)
   assert p.returncode==0,(cc,vid,label,f['name']);h=hashlib.sha256((D/'correctness_output').read_bytes()).hexdigest();hashes[label]=h
   if f.get('expected_sha256'):assert h==f['expected_sha256'],f['name']
  assert hashes['base']==hashes['owned_access'],(cc,vid,f['name']);rows.append(dict(compiler=cc,id=vid,case=f['name'],output_sha256=h,input_sha256=f['sha256'],independent_expected=bool(f.get('expected_sha256'))));(D/'actual_output_checks.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(cc,'all inputs exact output match',flush=True)
print('Actual frozen-main checks',len(rows),flush=True)
