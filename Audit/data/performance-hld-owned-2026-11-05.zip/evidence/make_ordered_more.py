# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
D=Path('/tmp/sirkit_hld_opt_20261105');s=(D/'ordered/fused_small.hpp').read_text();marker='''            value_type prefix = Traits::identity();
            std::optional<value_type> suffix;''';early='''            if (tree.head_[u] == tree.head_[v]) {
                const int l = std::min(tree.index_[u], tree.index_[v]) + static_cast<int>(edges);
                const int r = std::max(tree.index_[u], tree.index_[v]) + 1;
                if (l >= r) return Traits::identity();
                return tree.index_[u] >= tree.index_[v]
                    ? reinsirk::detail::hld_read_range(*state_->reversed, tree.size() - r, tree.size() - l, false)
                    : reinsirk::detail::hld_read_range(forward, l, r, false);
            }
''';assert marker in s;chain=s.replace(marker,early+marker,1);(D/'ordered/fused_chain.hpp').write_text(chain)
op=chain.replace('            value_type prefix = Traits::identity();','            std::optional<value_type> prefix;',1).replace('                prefix = Traits::combine(std::move(prefix), std::move(part));','                if (prefix) prefix.emplace(Traits::combine(std::move(*prefix), std::move(part)));\n                else prefix.emplace(std::move(part));',1).replace('            return suffix ? Traits::combine(std::move(prefix), std::move(*suffix)) : std::move(prefix);','''            if (prefix && suffix) return Traits::combine(std::move(*prefix), std::move(*suffix));
            if (prefix) return std::move(*prefix);
            if (suffix) return std::move(*suffix);
            return Traits::identity();''',1);assert op!=chain;(D/'ordered/fused_optional.hpp').write_text(op)
