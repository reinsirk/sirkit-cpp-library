# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json
D=Path('/tmp/sirkit_hld_opt_20261105');rows=[]
for label in ['mask64_large','block64_large']:
 for vid in ['hld_path_prod','fenwick_tree']:
  cmd=['python3',str(D/'micro/build_micro.py'),'--id',vid,'--fenwick',str(D/f'fenwick/{label}.hpp'),'--compiler','gcc','--name',label];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr;rows.append(dict(label=label,id=vid));print(vid,label,'READY',flush=True)
(D/'micro/large_recipes.json').write_text(json.dumps(rows,indent=2)+'\n')
