# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_opt_20261105/ordered')
s=(R/'Graph/Heavy_Light_Decomposition.cpp').read_text();(D/'base.hpp').write_text(s)
s=s.replace('class HeavyLightDecomposition {\npublic:','class HeavyLightDecomposition {\n    template<class, bool> friend class HeavyLightValues;\npublic:',1)
needle='''        if constexpr (!Ordered) return layout().path_prod(u, v, forward, edges);
        else return layout().path_prod(u, v, Traits::identity(), [&](int l, int r, bool reverse) {'''
replacement='''        if constexpr (!Ordered) return layout().path_prod(u, v, forward, edges);
        else if constexpr (std::is_trivially_copyable_v<value_type> && sizeof(value_type) <= 32) {
            const auto& tree = state_->layout;
#ifndef SKIP_RUNTIME_CHECKS
            tree.vertex(u); tree.vertex(v);
#endif
            if (tree.roots_.size() != 1 && tree.component_[u] != tree.component_[v]) {
#ifndef SKIP_RUNTIME_CHECKS
                throw std::invalid_argument("HLD: path endpoints are disconnected");
#else
                return Traits::identity();
#endif
            }
            value_type prefix = Traits::identity();
            std::optional<value_type> suffix;
            const auto append_left = [&](int l, int r) {
                auto part = reinsirk::detail::hld_read_range(*state_->reversed, tree.size() - r, tree.size() - l, false);
                prefix = Traits::combine(std::move(prefix), std::move(part));
            };
            const auto prepend_right = [&](int l, int r) {
                auto part = reinsirk::detail::hld_read_range(forward, l, r, false);
                if (suffix) suffix.emplace(Traits::combine(std::move(part), std::move(*suffix)));
                else suffix.emplace(std::move(part));
            };
            while (tree.head_[u] != tree.head_[v]) {
#if defined(__GNUC__) && !defined(__clang__)
                if (tree.index_[u] >= tree.index_[v]) {
#else
                if (tree.depth_[tree.head_[u]] >= tree.depth_[tree.head_[v]]) {
#endif
                    append_left(tree.index_[tree.head_[u]], tree.index_[u] + 1);
                    u = tree.parent_[tree.head_[u]];
                } else {
                    prepend_right(tree.index_[tree.head_[v]], tree.index_[v] + 1);
                    v = tree.parent_[tree.head_[v]];
                }
            }
            const int l = std::min(tree.index_[u], tree.index_[v]) + static_cast<int>(edges);
            const int r = std::max(tree.index_[u], tree.index_[v]) + 1;
            if (l < r) {
                if (tree.index_[u] >= tree.index_[v]) append_left(l, r);
                else prepend_right(l, r);
            }
            return suffix ? Traits::combine(std::move(prefix), std::move(*suffix)) : std::move(prefix);
        }
        else return layout().path_prod(u, v, Traits::identity(), [&](int l, int r, bool reverse) {'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
(D/'fused_small.hpp').write_text(s)
# Universal variant to allow measurement of the type restriction's necessity.
(D/'fused_all.hpp').write_text(s.replace('else if constexpr (std::is_trivially_copyable_v<value_type> && sizeof(value_type) <= 32)', 'else if constexpr (true)'))
print('fused_small.hpp and fused_all.hpp created')
