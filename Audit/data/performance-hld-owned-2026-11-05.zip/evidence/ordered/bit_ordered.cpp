// SPDX-License-Identifier: CC0-1.0
#ifndef HLD_SOURCE
#define HLD_SOURCE "/tmp/sirkit_hld_opt_20261105/ordered/fused_small.hpp"
#endif
#include HLD_SOURCE
#include "/home/reinsirk/Atcoder_Env/DataStructure/Fenwick_Tree.cpp"
#include <cassert>
#include <cstdint>
#include <limits>
#include <vector>
template<class T,class U>void run(){Graph g{{1},{0,2},{1,3},{2,4},{3,5},{4}};std::vector<T>a(6,std::numeric_limits<T>::max());auto h=HeavyLightDecomposition(g,3).template with_values<fenwick_tree<T>,true>(a);for(int q=0;q<600;++q){int u=q%6,v=(q*5+1)%6;U answer=0;for(int i=std::min(u,v);i<=std::max(u,v);++i)answer+=static_cast<U>(a[i]);assert(h.path_prod(u,v)==static_cast<T>(answer));T delta=static_cast<T>(q);h.add(u,delta);a[u]=static_cast<T>(static_cast<U>(a[u])+static_cast<U>(delta));assert(h.get(u)==a[u]);}}
int main(){run<std::int8_t,std::uint8_t>();run<std::int64_t,std::uint64_t>();
#if defined(__SIZEOF_INT128__)
run<__int128,unsigned __int128>();
#endif
}
