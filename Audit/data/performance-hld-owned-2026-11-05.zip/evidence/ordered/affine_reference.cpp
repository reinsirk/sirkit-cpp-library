// SPDX-License-Identifier: CC0-1.0
#ifndef HLD_SOURCE
#define HLD_SOURCE "/tmp/sirkit_hld_opt_20261105/ordered/fused_small.hpp"
#endif
#include HLD_SOURCE
#include "/home/reinsirk/Atcoder_Env/DataStructure/Segment_Tree.cpp"
#include "/home/reinsirk/Atcoder_Env/DataStructure/Lazy_Segment_Tree.cpp"
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <numeric>
#include <queue>
#include <random>
#include <vector>
namespace {
constexpr std::uint64_t mod=998244353;
struct Affine{std::uint32_t a,b;bool operator==(const Affine&)const=default;};
Affine append(Affine x,Affine y){return {static_cast<std::uint32_t>(std::uint64_t(y.a)*x.a%mod),static_cast<std::uint32_t>((std::uint64_t(y.a)*x.b+y.b)%mod)};}
Affine empty(){return {1,0};}
Affine scale(std::uint32_t f,Affine x,std::size_t n){(void)n;return {x.a,static_cast<std::uint32_t>(std::uint64_t(f)*x.b%mod)};}
std::uint32_t compose(std::uint32_t f,std::uint32_t g){return static_cast<std::uint32_t>(std::uint64_t(f)*g%mod);}
std::uint32_t identity(){return 1;}
using Seg=segtree<Affine,append,empty>;
using Lazy=lazy_segtree<Affine,append,empty,std::uint32_t,scale,compose,identity>;
std::vector<int> bfs_path(const Graph& g,int u,int v){std::vector<int> prev(g.size(),-1);std::queue<int> q;q.push(u);prev[u]=u;while(!q.empty()&&prev[v]<0){int p=q.front();q.pop();for(int x:g[p])if(prev[x]<0){prev[x]=p;q.push(x);}}if(prev[v]<0)return {};std::vector<int> out;for(int x=v;;x=prev[x]){out.push_back(x);if(x==u)break;}std::reverse(out.begin(),out.end());return out;}
}
int main(){
 std::mt19937_64 rng(871273412);std::uint64_t checks=0;
 for(int n:{1,2,7,31,100})for(int shape=0;shape<5;++shape){
  Graph g(n);std::vector<int> labels(n);std::iota(labels.begin(),labels.end(),0);std::shuffle(labels.begin(),labels.end(),rng);
  for(int i=1;i<n;++i){if(shape==4&&i%11==0)continue;int p=shape==0?i-1:shape==1?0:shape==2?(i-1)/2:rng()%i;int a=labels[i],b=labels[p];g[a].push_back(b);g[b].push_back(a);}
  const int root=rng()%n;std::vector<int> parent(n,-2),depth(n),comp(n,-1);int c=0;auto grow=[&](int start){std::queue<int> q;q.push(start);parent[start]=-1;comp[start]=c;while(!q.empty()){int u=q.front();q.pop();for(int v:g[u])if(parent[v]==-2){parent[v]=u;depth[v]=depth[u]+1;comp[v]=c;q.push(v);}}++c;};grow(root);for(int i=0;i<n;++i)if(parent[i]==-2)grow(i);
  auto lca=[&](int u,int v){while(depth[u]>depth[v])u=parent[u];while(depth[v]>depth[u])v=parent[v];while(u!=v){u=parent[u];v=parent[v];}return u;};
  std::vector<Affine> values(n);for(auto& x:values)x={std::uint32_t(rng()%mod),std::uint32_t(rng()%mod)};
  auto seg=HeavyLightDecomposition(g,root).with_values<Seg,true>(values);auto lazy=HeavyLightDecomposition(g,root).with_values<Lazy,true>(values);
  for(int it=0;it<2000;++it){int u=rng()%n,v=rng()%n;bool edge=it%2;if(comp[u]!=comp[v])continue;auto path=bfs_path(g,u,v);if(edge){int a=lca(u,v);path.erase(std::find(path.begin(),path.end(),a));}
   Affine answer=empty();for(int x:path)answer=append(answer,values[x]);assert(seg.path_prod(u,v,edge)==answer);assert(lazy.path_prod(u,v,edge)==answer);checks+=2;
   if(it%5==0){std::uint32_t f=rng()%mod;lazy.path_apply(u,v,f,edge);for(int x:path){values[x]=scale(f,values[x],1);seg.set(x,values[x]);}}
   else if(it%3==0){Affine f{std::uint32_t(rng()%mod),std::uint32_t(rng()%mod)};values[v]=f;seg.set(v,f);lazy.set(v,f);}
   assert(seg.get(v)==values[v]);assert(lazy.get(v)==values[v]);checks+=2;
  }
  assert(seg.values()==values);assert(lazy.values()==values);checks+=2;
 }
 std::printf("Affine ordered reference checks=%llu\n",static_cast<unsigned long long>(checks));
}
