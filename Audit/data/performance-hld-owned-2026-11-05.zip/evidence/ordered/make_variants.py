# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
D=Path('/tmp/sirkit_hld_opt_20261105/ordered');s=(D/'fused_small.hpp').read_text()
needle='''            value_type prefix = Traits::identity();
            std::optional<value_type> suffix;'''
replacement='''            if (tree.head_[u] == tree.head_[v]) {
                const int l = std::min(tree.index_[u], tree.index_[v]) + static_cast<int>(edges);
                const int r = std::max(tree.index_[u], tree.index_[v]) + 1;
                if (l >= r) return Traits::identity();
                return tree.index_[u] >= tree.index_[v]
                    ? reinsirk::detail::hld_read_range(*state_->reversed, tree.size() - r, tree.size() - l, false)
                    : reinsirk::detail::hld_read_range(forward, l, r, false);
            }
            value_type prefix = Traits::identity();
            std::optional<value_type> suffix;'''
assert s.count(needle)==1;s=s.replace(needle,replacement);(D/'fused_chain.hpp').write_text(s)
s=s.replace('            value_type prefix = Traits::identity();','            std::optional<value_type> prefix;',1)
s=s.replace('''                prefix = Traits::combine(std::move(prefix), std::move(part));''','''                if (prefix) prefix.emplace(Traits::combine(std::move(*prefix), std::move(part)));
                else prefix.emplace(std::move(part));''',1)
s=s.replace('''            return suffix ? Traits::combine(std::move(prefix), std::move(*suffix)) : std::move(prefix);''','''            if (!prefix) return suffix ? std::move(*suffix) : Traits::identity();
            return suffix ? Traits::combine(std::move(*prefix), std::move(*suffix)) : std::move(*prefix);''',1)
(D/'fused_optional.hpp').write_text(s)
print('chain and optional candidates ready')
