# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,subprocess,os
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_opt_20261105/ordered');rows=[]
for variant in ['fused_chain','fused_optional']:
 for cc,args in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for skip in [False,True]:
   for test,src in [('owned',R/'Verify/current/tests/hld_owned_test.cpp'),('affine',D/'affine_reference.cpp'),('bit',D/'bit_ordered.cpp')]:
    exe=D/f'{variant}_{test}_{cc}_{int(skip)}';header=D/f'{variant}.hpp';cmd=['taskset','-c','6',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(R/'Verify/current/vendor'),'-DHLD_SOURCE="'+str(header)+'"']+(['-DSKIP_RUNTIME_CHECKS']if skip else[])+[str(src),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','6',str(exe)],text=True,capture_output=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'});rows.append(dict(variant=variant,compiler=cc,skip=skip,test=test,command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,header_sha256=hashlib.sha256(header.read_bytes()).hexdigest(),test_sha256=hashlib.sha256(src.read_bytes()).hexdigest()));(D/'results_more.json').write_text(json.dumps(rows,indent=2)+'\n');print(variant,cc,skip,test,p.returncode,p.stdout.strip(),flush=True);assert p.returncode==0 and not p.stderr,p.stderr
