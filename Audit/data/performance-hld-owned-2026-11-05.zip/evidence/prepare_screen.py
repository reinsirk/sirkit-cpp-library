# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,sys,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_opt_20261105');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
src=(D/'before/Graph/Heavy_Light_Decomposition.cpp').read_text();heads={'base':src}
pat='#if defined(__clang__)\n        if constexpr (!directional && !reverse_value)';assert pat in src;heads['comm_all']=src.replace(pat,'#if 1\n        if constexpr (!directional && !reverse_value)',1)
pat2='return layout().path_prod(u, v, forward, edges);';assert pat2 in src;heads['state_direct']=src.replace(pat2,'return state_->layout.path_prod(u, v, forward, edges);',1)
heads['comm_direct']=heads['comm_all'].replace(pat2,'return state_->layout.path_prod(u, v, forward, edges);',1)
entries={x['id']:x for x in pv.collect()};rows=[]
for label,h in heads.items():
 (D/f'{label}.hpp').write_text(h)
 for vid in ['hld_path_prod','hld_path_composite']:
  b,_=pv.render(entries[vid],source_overrides={'Graph/Heavy_Light_Decomposition.cpp':h.encode()});p=D/f'{vid}_{label}.cpp';p.write_bytes(b)
  for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
   if vid=='hld_path_composite'and label!='base':continue
   exe=D/f'{cc}_{vid}_{label}';cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(p),'-o',str(exe)];subprocess.run(cmd,check=True);rows.append(dict(label=label,id=vid,compiler=cc,command=cmd,header_sha256=hashlib.sha256(h.encode()).hexdigest(),program_sha256=hashlib.sha256(b).hexdigest()))
(D/'screen_builds.json').write_text(json.dumps(rows,indent=2)+'\n');print('Screen binaries ready')
