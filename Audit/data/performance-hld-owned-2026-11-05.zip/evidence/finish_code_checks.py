# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib,sys
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_opt_20261105');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as p;es={x['id']:x for x in p.collect()};rows=[];sha=lambda b:hashlib.sha256(b).hexdigest();args={'gcc':['/usr/bin/g++'],'clang':['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']}
for vid in ['hld_path_prod','hld_path_composite','hld_jump','hld_vertex_add_path_sum','fenwick_tree']:
 for cc in ['gcc','clang']:
  data,_=p.render(es[vid]);src=D/f'final_{vid}.cpp';src.write_bytes(data);exe=D/f'final_{cc}_{vid}';cmd=['taskset','-c','4',*args[cc],'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(src),'-o',str(exe)];subprocess.run(cmd,check=True)
  for sample in es[vid]['samples']:
   r=subprocess.run(['taskset','-c','4',str(exe)],input=sample['input'],text=True,capture_output=True);assert r.returncode==0 and r.stdout.split()==sample['output'].split() and not r.stderr,(vid,r.stdout,r.stderr)
  rows.append(dict(compiler=cc,id=vid,command=cmd,program_sha256=sha(data),samples_pass=True))
(D/'final_builds.json').write_text(json.dumps(rows,indent=2)+'\n');mapping=[]
for cc,vid,reference in [('gcc','hld_path_prod','gcc_hld_path_prod_outline'),('clang','hld_path_prod','clang_hld_path_prod_owned_access'),('gcc','hld_path_composite','gcc_hld_path_composite_owned_access'),('clang','hld_path_composite','clang_hld_path_composite_base'),('gcc','fenwick_tree','gcc_fenwick_tree_base'),('clang','fenwick_tree','clang_fenwick_tree_base')]:
 blobs=[]
 for exe in [D/reference,D/f'final_{cc}_{vid}']:
  target=exe.with_suffix('.final.text');subprocess.run(['objcopy','--dump-section',f'.text={target}',str(exe)],check=True);blobs.append(target.read_bytes())
 assert blobs[0]==blobs[1],(cc,vid,reference)
 mapping.append(dict(compiler=cc,id=vid,reference=reference,final_executable=str(D/f'final_{cc}_{vid}'),text_sha256=sha(blobs[0]),identical=True))
for vid in ['hld_jump','hld_vertex_add_path_sum']:
 data,_=p.render(es[vid],source_overrides={x:(D/'before'/x).read_bytes()for x in ['Graph/Heavy_Light_Decomposition.cpp','DataStructure/Fenwick_Tree.cpp']});src=D/f'legacy_base_{vid}.cpp';src.write_bytes(data)
 for cc in ['gcc','clang']:
  exe=D/f'legacy_base_{cc}_{vid}';cmd=['taskset','-c','4',*args[cc],'-std=c++23','-O2',str(src),'-o',str(exe)];subprocess.run(cmd,check=True);blobs=[]
  for f in [exe,D/f'final_{cc}_{vid}']:
   t=f.with_suffix('.final.text');subprocess.run(['objcopy','--dump-section',f'.text={t}',str(f)],check=True);blobs.append(t.read_bytes())
  assert blobs[0]==blobs[1],(cc,vid);mapping.append(dict(compiler=cc,id=vid,scope='legacy main and IO unchanged, whole text identical',text_sha256=sha(blobs[0]),identical=True))
(D/'final_code_mapping.json').write_text(json.dumps(mapping,indent=2)+'\n');print('10 normal sample builds passed; 10 machine-code equivalence/mapping proofs passed',flush=True)
expected={(x['compiler'],x['id'],x['case']):x['output_sha256']for x in json.loads((D/'actual_output_checks.json').read_text())};fixtures=json.loads((D/'fixtures/fixtures.json').read_text())+json.loads((D/'fixtures/point_fixtures.json').read_text());checks=[]
for cc in ['gcc','clang']:
 for f in fixtures:
  vid={'vertex_add_path_sum':'hld_path_prod','vertex_set_path_composite':'hld_path_composite','point_add_range_sum':'fenwick_tree'}[f['problem']];exe=D/f'final_{cc}_{vid}'
  with Path(f['path']).open('rb')as fi,(D/'final_correctness_output').open('wb')as fo:r=subprocess.run(['taskset','-c','4',str(exe)],stdin=fi,stdout=fo)
  assert r.returncode==0;h=sha((D/'final_correctness_output').read_bytes());assert h==expected[cc,vid,f['name']],(cc,vid,f['name']);checks.append(dict(compiler=cc,id=vid,case=f['name'],output_sha256=h,independent_expected=bool(f.get('expected_sha256'))));(D/'final_output_checks.json').write_text(json.dumps(checks,indent=2)+'\n')
 print(cc,'all final outputs identical',flush=True)
