# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,sys,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_opt_20261105');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as p
es={x['id']:x for x in p.collect()};over={'Graph/Heavy_Light_Decomposition.cpp':(D/'combined_candidate.hpp').read_bytes(),'DataStructure/Fenwick_Tree.cpp':(D/'fenwick/owned_access_fw.hpp').read_bytes()};rows=[]
for vid in ['hld_path_prod','hld_path_composite','fenwick_tree']:
 data,_=p.render(es[vid],source_overrides=over);src=D/f'{vid}_owned_access.cpp';src.write_bytes(data)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  exe=D/f'{cc}_{vid}_owned_access';cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(src),'-o',str(exe)];subprocess.run(cmd,check=True);rows.append(dict(id=vid,compiler=cc,command=cmd,program_sha256=hashlib.sha256(data).hexdigest()))
(D/'combined_verify_builds.json').write_text(json.dumps(rows,indent=2)+'\n');print('Combined actual frozen Verify programs ready')
