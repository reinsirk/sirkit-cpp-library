# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,subprocess,os,statistics,random,fcntl,shutil,hashlib
D=Path('/tmp/sirkit_hld_opt_20261105');F=D/'fixtures';fs={x['name']:x for x in json.loads((F/'fixtures.json').read_text())};raw=[];rng=random.Random(2026110577)
sum_names=['official_vertex_add_path_sum_max_random_0','official_vertex_add_path_sum_max_random_1','official_vertex_add_path_sum_random_0','official_vertex_add_path_sum_line_0','official_vertex_add_path_sum_almost_line_0','official_vertex_add_path_sum_long-path-decomposition_killer_0','custom_vertex_add_path_sum_250000_balanced','custom_vertex_add_path_sum_250000_random','custom_vertex_add_path_sum_250000_star','custom_vertex_add_path_sum_32_random_queryheavy','custom_vertex_add_path_sum_4096_random_queryheavy']
cmp_names=['official_vertex_set_path_composite_max_random_0','official_vertex_set_path_composite_worst_for_path_decomposition_0','official_vertex_set_path_composite_line_0','official_vertex_set_path_composite_almost_line_0','official_vertex_set_path_composite_long-path-decomposition_killer_0','custom_vertex_set_path_composite_250000_balanced','custom_vertex_set_path_composite_250000_random','custom_vertex_set_path_composite_250000_star','custom_vertex_set_path_composite_32_random_queryheavy','custom_vertex_set_path_composite_4096_random_queryheavy','custom_vertex_set_path_composite_32_chain_queryheavy']
sets=[('gcc','hld_path_prod',sum_names),('clang','hld_path_prod',sum_names),('gcc','hld_path_composite',cmp_names)]
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc,vid,names in sets:
  for case in names:
   Path(fs[case]['path']).read_bytes()
   for rep in range(7):
    labels=['base','control','owned_access'];rng.shuffle(labels)
    for label in labels:
     shutil.copyfile(D/f'{cc}_{vid}_{"base"if label=="control"else label}',D/'active_final');(D/'active_final').chmod(0o700)
     cmd=['setarch','x86_64','-R','taskset','-c','12',str(D/'active_final')]
     with Path(fs[case]['path']).open('rb')as fi,(D/'final_output').open('wb')as fo:
      p=subprocess.Popen(cmd,stdin=fi,stdout=fo);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0
     h=hashlib.sha256((D/'final_output').read_bytes()).hexdigest()
     if fs[case].get('expected_sha256'):assert h==fs[case]['expected_sha256']
     raw.append(dict(compiler=cc,id=vid,case=case,rep=rep,label=label,cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),rss_bytes=ru.ru_maxrss*1024,output_sha256=h))
   rr=[x for x in raw if x['compiler']==cc and x['id']==vid and x['case']==case];assert len({x['output_sha256']for x in rr})==1;m={l:statistics.median(x['cpu_ns']for x in rr if x['label']==l)for l in labels};print(cc,vid,case,'candidate',round(m['owned_access']/m['base'],4),'control',round(m['control']/m['base'],4),flush=True);(D/'final_benchmark_raw.json').write_text(json.dumps(raw))
summary=[]
for cc,vid,names in sets:
 for case in names:
  rr=[x for x in raw if x['compiler']==cc and x['id']==vid and x['case']==case];m={l:statistics.median(x['cpu_ns']for x in rr if x['label']==l)for l in ['base','control','owned_access']};summary.append(dict(compiler=cc,id=vid,case=case,median_cpu_ns=m,candidate_ratio=m['owned_access']/m['base'],control_ratio=m['control']/m['base']))
(D/'final_benchmark_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('Final benchmark complete',len(raw),flush=True)
