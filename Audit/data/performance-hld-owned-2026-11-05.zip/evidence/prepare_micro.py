# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json
D=Path('/tmp/sirkit_hld_opt_20261105');recipes=[]
for label in ['mask64','block64','block256']:
 for vid in ['hld_path_prod','fenwick_tree']:recipes.append(dict(label=label,id=vid,fenwick=str(D/f'fenwick/{label}.hpp')))
recipes.append(dict(label='comm_direct',id='hld_path_prod',hld=str(D/'comm_direct.hpp')))
for label in ['fused_chain','fused_optional']:recipes.append(dict(label=label,id='hld_path_composite',hld=str(D/f'ordered/{label}.hpp')))
for r in recipes:
 cmd=['python3',str(D/'micro/build_micro.py'),'--id',r['id'],'--compiler','gcc','--name',r['label']]
 for k in ['hld','fenwick']:
  if k in r:cmd+=['--'+k,r[k]]
 p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr;print(r['id'],r['label'],'READY',flush=True)
(D/'micro/recipes.json').write_text(json.dumps(recipes,indent=2)+'\n')
