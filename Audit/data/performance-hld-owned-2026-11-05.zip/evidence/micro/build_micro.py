# SPDX-License-Identifier: CC0-1.0
"""Frozen Verifyを変えず、2名前空間の隣接block比較microbenchmarkを作る。"""
from pathlib import Path
import argparse,re,subprocess,json,hashlib
D=Path('/tmp/sirkit_hld_opt_20261105');M=D/'micro';M.mkdir(exist_ok=True)
p=argparse.ArgumentParser();p.add_argument('--id',choices=['hld_path_prod','hld_path_composite','fenwick_tree'],required=True);p.add_argument('--hld',type=Path,default=D/'base.hpp');p.add_argument('--fenwick',type=Path,default=D/'before/DataStructure/Fenwick_Tree.cpp');p.add_argument('--compiler',choices=['gcc','clang'],required=True);p.add_argument('--name');p.add_argument('--output',type=Path);p.add_argument('--cpu',type=int,default=4);a=p.parse_args();a.hld=a.hld.resolve();a.fenwick=a.fenwick.resolve()
base_hld=D/'base.hpp';base_fw=D/'before/DataStructure/Fenwick_Tree.cpp';seg=D/'before/DataStructure/Segment_Tree.cpp';sha=lambda b:hashlib.sha256(b).hexdigest()
baseline='\n'.join(x.read_text()for x in [base_hld,base_fw,seg]);candidate='\n'.join(x.read_text()for x in [a.hld,a.fenwick,seg]);guards=sorted(set(re.findall(r'^\s*#\s*define\s+(SIRKIT_\w+)\b',baseline,re.M)));undef='\n'.join('#undef '+x for x in guards)
name=a.name or re.sub(r'[^a-zA-Z0-9_]+','_',a.hld.stem+'_'+a.fenwick.stem);exe=(a.output or M/f'{a.compiler}_{a.id}_{name}').resolve();exe.parent.mkdir(parents=True,exist_ok=True);src=exe.with_suffix('.cpp')
metadata=dict(micro_id=a.id,micro_hld_sha=sha(a.hld.read_bytes()),micro_fw_sha=sha(a.fenwick.read_bytes()),micro_base_hld_sha=sha(base_hld.read_bytes()),micro_base_fw_sha=sha(base_fw.read_bytes()));defines='\n'.join('constexpr const char* '+k+'='+json.dumps(v)+';'for k,v in metadata.items());mode='#define MICRO_COMPOSITE\n'if a.id=='hld_path_composite'else'#define MICRO_POINT\n'if a.id=='fenwick_tree'else''
# 全標準headerをglobalで先に読む。名前空間内includeが独自stdを作ることを防ぐ。
program='// SPDX-License-Identifier: CC0-1.0\n#include <bits/stdc++.h>\n#include <time.h>\n#define SKIP_RUNTIME_CHECKS\n'+mode+defines+'\nnamespace baseline {\n'+baseline+'\n}\n'+undef+'\nnamespace candidate {\n'+candidate+'\n}\n'+(M/'kernel.cpp.in').read_text();src.write_text(program)
cc=['/usr/bin/g++']if a.compiler=='gcc'else['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'];cmd=['taskset','-c',str(a.cpu),*cc,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(src),'-o',str(exe)];result=subprocess.run(cmd,text=True,capture_output=True)
if result.returncode:raise RuntimeError(result.stderr)
record=dict(id=a.id,compiler=a.compiler,compile_command=cmd,executable=str(exe),source=str(src),source_sha256=sha(src.read_bytes()),headers={str(p):sha(p.read_bytes())for p in [base_hld,base_fw,seg,a.hld,a.fenwick]},metadata=metadata,usage=[str(exe),'INPUT_PATH','REPS']);exe.with_suffix('.build.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
