// SPDX-License-Identifier: CC0-1.0
#include <bits/stdc++.h>
#include <time.h>
#define SKIP_RUNTIME_CHECKS
#define MICRO_POINT
constexpr const char* micro_id="fenwick_tree";
constexpr const char* micro_hld_sha="c1fefecb87bb31c8fe466c2f2df23c40d43bac5f3dc920f63221c956f6b0ee3b";
constexpr const char* micro_fw_sha="52632acdf0e5b3752b37d005f0ef0d947e51915a8f77dc2877bd0a038c892a9c";
constexpr const char* micro_base_hld_sha="b373968fbcefc3071dadc01757db4b23dbdc8e72a18d546ec0d4ee5ef2c819c9";
constexpr const char* micro_base_fw_sha="55488b89ded2025c6006bc2343a743e2661fe20a9e728a4c9e1feca24339919e";
namespace baseline {
// SPDX-License-Identifier: CC0-1.0
// 参考（重軽分解の理論）: https://info.atcoder.jp/entry/algorithm_lectures/heavy_light_decomposition
// 参考（API設計）: https://ei1333.github.io/library/graph/tree/heavy-light-decomposition.hpp.html
// https://github.com/hitonanode/cplib-cpp/blob/master/tree/heavy_light_decomposition.hpp
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/heavy_light_decomposition.md
//
// API一覧
// [共通型] Graphはvector<vector<int>>。HeavyLightDecomposition::Intervalは{int left,right;bool reversed;}。
// [値を持つHLD: HeavyLightValues<Range,Ordered=false>]
// value_typeはBITのT/Segtree・LazyのS。HeavyLightValues()は空。コピー構築/代入は独立、移動構築はO(1)。
// operator=(other)は自身への参照を返す。代入/buildは旧状態の破棄費用も加わる。
// with_values<Range,Ordered>(values): values[v]を頂点vの値とする長さNのvectorから、分解と集計器を独立所有するHLDを返す。
// 元の値配列とは更新を共有しない。get/set/add/applyのvは頂点番号で、index(v)への変換は不要。
// 一時HLDなら分解を移動、既存HLDならコピー。RangeはBIT/ACL形式Segtree/Lazy。値の型はRangeから推論。
// HeavyLightValues(g,values,root=0)/build(g,values,root=0): 分解と値を同時に構築/再構築。失敗時は元を保持。
// HeavyLightValues(layout,values): 分解をコピー、std::move(layout)なら移動。移動後の失敗では元分解が空の場合あり。
// 構築は分解O(N+M)+集計器のvector構築。vector構築なしのBITはN回add。所有状態を1回確保する。
// get(v)/set(v,x)/add(v,x): 頂点番号で取得/代入/加算。addは対応BITのみ。通常の集計器ではO(log N)。
// apply(v,f)/path_apply(u,v,f,edges=false)/subtree_apply(v,f,edges=false): 点/経路/部分木へ作用。
// path_prod(u,v,edges=false)/subtree_prod(v,edges=false): 所有集計器で経路/部分木を集計。通常O(log²N)/O(log N)。
// Ordered=falseは和・最小値などの可換演算用。trueは文字列連結などをu→vの順に集計。領域と更新は集計器2本分。
// trueは値の並び順を守る設定で、個々の辺の値を逆元へ変える機能ではない。部分木の積はDFS添字昇順。
// 辺モードは子vに親辺の値を置き、各根には0/e()を置く。初期値はN個必要。edges=trueでLCA/部分木の指定頂点を除く。
// path_prod(v,v)は頂点の値、path_prod(v,v,true)や葉の辺部分木は空区間の単位元。空区間の更新は何もしない。
// values(): 元の頂点順へ復元。Range.valuesがあればO(N)の並べ直し、なければN回点照会。
// clear()/swap(other): 空へ/交換。コピーは独立、move元は空。build/コピー失敗時は元を保持。
// 分解情報・reorder/restore/for_each_path/pathも同名で取得可能。対応applyを持つRangeでのみ作用APIを使用できる。
// 所有型にInterval型別名・with_values・外部集計器を受けるオーバーロードはない。pathの要素型は上記Interval。
// 値の照会も非constの所有HLDから呼ぶ。根を変えて辺の値をbuildする場合は、新しい親子対応で値を配置し直す。
// 値の更新中の例外では変更は巻き戻さない。Ordered=trueでは例外後にclear/buildで再構築すること。
// [分解だけを持つHLD: HeavyLightDecomposition]
// HeavyLightDecomposition()は空、コピー構築はO(N)、移動構築はO(1)。operator=(other)は自身への参照を返す。
// コピー・移動代入とbuildは旧状態の破棄費用も加わる。
// HeavyLightDecomposition(g,root=0)/build(g,root=0): 無向森を反復DFSで分解。O(n+m)時間・領域。
// 頂点番号[0,n)。隣接リストの対称性は前提。rootの木から、残りは最小未訪問頂点から構築する。
// 失敗時は元を保持。空のgにはroot=0。閉路・自己辺・多重辺は検査有効時に例外。
// size()/empty()/root()/component_count(): 頂点数/空か/指定根（空なら-1）/木の数。O(1)。
// parent(v)/depth(v)/component(v)/root_of(v): 親（根は-1）/深さ/木の番号/木の根。O(1)。
// index(v)/vertex_at(i)/order(): heavy優先DFS添字/対応頂点/順序配列へのconst参照。O(1)。
// same_component(u,v)/is_ancestor(u,v): 同じ木か/祖先か（自身を含む）。O(1)。
// subtree_range(v,edges=false): 部分木の半開区間。edges=trueは根vを除き子側の頂点で辺を表す。O(1)。
// subtree_size(v): 部分木の頂点数。O(1)。lca(u,v)/distance(u,v): LCA/辺数、異なる木は-1。O(log n)。
// kth_ancestor(v,k): k個上の頂点。k<0/根を越すと-1。jump(u,v,k): u→vのk番目、範囲外/異なる木は-1。O(log n)。
// for_each_path(u,v,fn,edges=false): 通行順にfn(left,right,reversed)を呼ぶ。fnの戻り値は無視。接続ならtrue、異なる木はfalse。
// reversed=trueはright-1からleftへ読む。区間は半開。edges=trueはLCAを除く。O(log n)、ヒープ確保なし。
// path(u,v,edges=false): 同じ順序のInterval{left,right,reversed}配列を返す。異なる木は空。O(log n)時間・領域。
// clear()/swap(other): 空に戻す/O(1)交換。コピーは独立所有、ムーブ元は空。検査はSKIP_RUNTIME_CHECKSで除く。
// reorder(values)/restore(ordered): 長さNのvectorをDFS添字順/元の頂点順へコピー。O(N)時間・領域。
// path_prod(u,v,bit,edges=false): sumを持つBITの和。単位元はT{}、整数は型幅で周回。O(log N)回照会。
// path_prod(u,v,seg,edges=false): ACL形式のSegtreeからop/eを推論した可換積。Segはconst可、Lazyは非const。
// path_prod(u,v,identity,query,op,edges=false): queryはprod/sum、2引数関数なら可換、3引数(l,r,reversed)なら向き対応。
// path_prod(u,v,seg,reverse,edges=false)/汎用版のop直後にreverse指定: 正しい逆順集約を返す非可換積。
// subtree_prod(v,query,edges=false): 部分木のDFS添字昇順の積。区間照会1回。非可換も可。
// path_apply(u,v,range,f,edges=false)/subtree_apply(v,range,f,edges=false): range.apply(l,r,f)で更新。O(log N)/1回。
// prod/applyのrangeは同じDFS添字順で用意する。path_prod/path_applyは同じ木が前提、検査時は別木を例外。

#include <algorithm>
#include <array>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <memory>
#include <optional>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

#ifndef SIRKIT_UNWEIGHTED_GRAPH_DEFINED
#define SIRKIT_UNWEIGHTED_GRAPH_DEFINED
using Graph = std::vector<std::vector<int>>;
#endif

#ifndef SIRKIT_HLD_QUERY_HELPERS_DEFINED
#define SIRKIT_HLD_QUERY_HELPERS_DEFINED
namespace reinsirk::detail {
template<class Q>
concept HldRangeQuery = requires(Q& q) { q.prod(0, 0); }
    || requires(Q& q) { q.sum(0, 0); }
    || std::is_invocable_v<Q&, int, int, bool> || std::is_invocable_v<Q&, int, int>;
template<class Q>
inline constexpr bool hld_directional_query = !requires(Q& q) { q.prod(0, 0); }
    && !requires(Q& q) { q.sum(0, 0); } && std::is_invocable_v<Q&, int, int, bool>;
template<HldRangeQuery Q>
decltype(auto) hld_read_range(Q& query, int l, int r, bool reversed) {
    if constexpr (requires { query.prod(l, r); }) return query.prod(l, r);
    else if constexpr (requires { query.sum(l, r); }) return query.sum(l, r);
    else if constexpr (hld_directional_query<Q>) return std::invoke(query, l, r, reversed);
    else return std::invoke(query, l, r);
}
template<HldRangeQuery Q>
using HldRangeValue = std::remove_cvref_t<decltype(hld_read_range(std::declval<Q&>(), 0, 0, false))>;
struct HldAddition {
    template<class T> T operator()(T a, T b) const {
#if defined(__SIZEOF_INT128__) && (defined(__GNUC__) || defined(__clang__))
        if constexpr (std::is_same_v<T, __int128> || std::is_same_v<T, unsigned __int128>)
            return static_cast<T>(static_cast<unsigned __int128>(a) + static_cast<unsigned __int128>(b));
        else
#endif
        if constexpr (std::is_integral_v<T> && !std::is_same_v<T, bool>) {
            using U = std::make_unsigned_t<T>;
            return static_cast<T>(static_cast<U>(a) + static_cast<U>(b));
        } else return a + b;
    }
};
}
#endif

#ifndef SIRKIT_HEAVY_LIGHT_VALUES_FORWARD_DEFINED
#define SIRKIT_HEAVY_LIGHT_VALUES_FORWARD_DEFINED
template<class Range, bool Ordered = false> class HeavyLightValues;
#endif

#ifndef SIRKIT_HEAVY_LIGHT_DECOMPOSITION_DEFINED
#define SIRKIT_HEAVY_LIGHT_DECOMPOSITION_DEFINED
class HeavyLightDecomposition {
public:
    struct Interval { int left; int right; bool reversed; };
private:
    int root_ = -1;
    std::vector<int> parent_, depth_, component_, roots_, subtree_, heavy_, head_, index_, order_;
#ifndef SKIP_RUNTIME_CHECKS
    void vertex(int v) const {
        if (v < 0 || v >= size()) throw std::out_of_range("HLD: vertex out of range");
    }
#endif
    void prepare(const Graph& graph, int root) {
        if (graph.size() > static_cast<std::size_t>(std::numeric_limits<int>::max()))
            throw std::length_error("HLD: too many vertices");
        const int n = static_cast<int>(graph.size());
#ifndef SKIP_RUNTIME_CHECKS
        if ((n == 0 && root != 0) || (n != 0 && (root < 0 || root >= n)))
            throw std::out_of_range("HLD: root out of range");
#endif
        if (n == 0) return;
        root_ = root;
        parent_.assign(n, -2); depth_.resize(n); component_.resize(n); subtree_.assign(n, 1);
        heavy_.assign(n, -1); head_.resize(n); index_.resize(n); order_.resize(n);
        std::vector<int> stack;
        stack.reserve(n);
        // 部分木集計まではorder_を探索順の保存に使う。
        std::size_t visited_count = 0;
        const auto discover = [&](int start) {
            const int id = static_cast<int>(roots_.size()); roots_.push_back(start);
            parent_[start] = -1; component_[start] = id; stack.push_back(start);
            while (!stack.empty()) {
                const int v = stack.back(); stack.pop_back(); order_[visited_count++] = v;
#ifndef SKIP_RUNTIME_CHECKS
                bool parent_seen = false;
#endif
                for (int u : graph[v]) {
#ifndef SKIP_RUNTIME_CHECKS
                    vertex(u);
#endif
                    if (u == parent_[v]) {
#ifndef SKIP_RUNTIME_CHECKS
                        if (parent_seen) throw std::invalid_argument("HLD: parallel edge");
                        parent_seen = true;
#endif
                        continue;
                    }
#ifndef SKIP_RUNTIME_CHECKS
                    if (parent_[u] != -2) throw std::invalid_argument("HLD: input must be a forest");
#endif
                    parent_[u] = v; depth_[u] = depth_[v] + 1;
                    component_[u] = id; stack.push_back(u);
                }
            }
        };
        discover(root);
        for (int v = 0; v < n; ++v) if (parent_[v] == -2) discover(v);
        for (std::size_t i = visited_count; i != 0;) {
            const int v = order_[--i], parent = parent_[v];
            if (parent != -1) {
                subtree_[parent] += subtree_[v];
                if (heavy_[parent] == -1 || subtree_[v] > subtree_[heavy_[parent]]) heavy_[parent] = v;
            }
        }
        int position = 0;
        for (int start : roots_) {
            stack.push_back(start);
            while (!stack.empty()) {
                const int first = stack.back(); stack.pop_back();
                for (int v = first; v != -1; v = heavy_[v]) {
                    head_[v] = first; index_[v] = position; order_[position++] = v;
                    const int parent = parent_[v], heavy = heavy_[v];
                    for (int u : graph[v]) if (u != parent && u != heavy) stack.push_back(u);
                }
            }
        }
    }
    template<class Identity, class Q, class Op, class Reverse>
    auto path_product_impl(int u, int v, Identity&& identity, Q& query, Op& op, Reverse& reverse, bool edges) const {
        using S = reinsirk::detail::HldRangeValue<Q>;
        S result(std::forward<Identity>(identity));
        constexpr bool directional = reinsirk::detail::hld_directional_query<Q>;
        constexpr bool reverse_value = !std::is_same_v<std::remove_cvref_t<Reverse>, std::identity>;
        static_assert(!directional || !reverse_value, "HLD: choose directional query or reverse, not both");
        const auto consume = [&](int l, int r, bool reversed) {
            S part = reinsirk::detail::hld_read_range(query, l, r, reversed);
            if constexpr (!directional && reverse_value)
                if (reversed) part = std::invoke(reverse, std::move(part));
            result = std::invoke(op, std::move(result), std::move(part));
        };
#if defined(__clang__)
        if constexpr (!directional && !reverse_value) {
            // 可換なら区間の通行順を保存せず、その場で集計できる。
#ifndef SKIP_RUNTIME_CHECKS
            vertex(u); vertex(v);
#endif
            if (roots_.size() != 1 && component_[u] != component_[v]) {
#ifndef SKIP_RUNTIME_CHECKS
                throw std::invalid_argument("HLD: path endpoints are disconnected");
#else
                return result;
#endif
            }
            while (head_[u] != head_[v]) {
                if (index_[u] >= index_[v]) {
                    consume(index_[head_[u]], index_[u] + 1, false); u = parent_[head_[u]];
                } else {
                    consume(index_[head_[v]], index_[v] + 1, false); v = parent_[head_[v]];
                }
            }
            const int left = std::min(index_[u], index_[v]) + static_cast<int>(edges);
            const int right = std::max(index_[u], index_[v]) + 1;
            if (left < right) consume(left, right, false);
            return result;
        }
#endif
        const bool connected = for_each_path(u, v, consume, edges);
#ifndef SKIP_RUNTIME_CHECKS
        if (!connected) throw std::invalid_argument("HLD: path endpoints are disconnected");
#else
        (void)connected;
#endif

        return result;
    }
public:
    template<class Range, bool Ordered = false, class T>
    HeavyLightValues<Range, Ordered> with_values(const std::vector<T>& values) const &;
    template<class Range, bool Ordered = false, class T>
    HeavyLightValues<Range, Ordered> with_values(const std::vector<T>& values) &&;
    HeavyLightDecomposition() = default;
    explicit HeavyLightDecomposition(const Graph& graph, int root = 0) { prepare(graph, root); }
    HeavyLightDecomposition(const HeavyLightDecomposition&) = default;
    HeavyLightDecomposition(HeavyLightDecomposition&& other) noexcept { swap(other); }
    HeavyLightDecomposition& operator=(HeavyLightDecomposition other) noexcept { swap(other); return *this; }
    void swap(HeavyLightDecomposition& other) noexcept {
        std::swap(root_, other.root_); parent_.swap(other.parent_); depth_.swap(other.depth_);
        component_.swap(other.component_); roots_.swap(other.roots_); subtree_.swap(other.subtree_);
        heavy_.swap(other.heavy_); head_.swap(other.head_); index_.swap(other.index_); order_.swap(other.order_);
    }
    void clear() noexcept { HeavyLightDecomposition replacement; swap(replacement); }
    void build(const Graph& graph, int root = 0) { HeavyLightDecomposition replacement(graph, root); swap(replacement); }
    int size() const noexcept { return static_cast<int>(parent_.size()); }
    bool empty() const noexcept { return parent_.empty(); }
    int root() const noexcept { return root_; }
    int component_count() const noexcept { return static_cast<int>(roots_.size()); }
    int parent(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return parent_[v];
    }
    int depth(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return depth_[v];
    }
    int component(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return component_[v];
    }
    int root_of(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return roots_[component_[v]];
    }
    int index(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return index_[v];
    }
    int vertex_at(int i) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(i);
#endif
        return order_[i];
    }
    const std::vector<int>& order() const noexcept { return order_; }
    bool same_component(int u, int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        return component_[u] == component_[v];
    }
    bool is_ancestor(int u, int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        // 部分木区間には他の成分の頂点が入らない。
        return index_[u] <= index_[v] && index_[v] < index_[u] + subtree_[u];
    }
    std::pair<int, int> subtree_range(int v, bool edges = false) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return {index_[v] + static_cast<int>(edges), index_[v] + subtree_[v]};
    }
    int subtree_size(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return subtree_[v];
    }
    int lca(int u, int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        if (component_[u] != component_[v]) return -1;
        while (head_[u] != head_[v]) {
            if (depth_[head_[u]] > depth_[head_[v]]) u = parent_[head_[u]];
            else v = parent_[head_[v]];
        }
        return depth_[u] < depth_[v] ? u : v;
    }
    int distance(int u, int v) const {
        const int w = lca(u, v);
        return w == -1 ? -1 : (depth_[u] - depth_[w]) + (depth_[v] - depth_[w]);
    }
    int kth_ancestor(int v, std::int64_t k) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        if (k < 0 || k > depth_[v]) return -1;
        for (;;) {
            const int within = depth_[v] - depth_[head_[v]];
            if (k <= within) return order_[index_[v] - static_cast<int>(k)];
            k -= static_cast<std::int64_t>(within) + 1; v = parent_[head_[v]];
        }
    }
    int jump(int u, int v, std::int64_t k) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        if ((roots_.size() != 1 && component_[u] != component_[v]) || k < 0) return -1;
        // 同じ重鎖内では添字の差がそのまま経路長になる。
        if (head_[u] == head_[v]) {
            const int delta = index_[v] - index_[u];
            if (k > (delta >= 0 ? delta : -delta)) return -1;
            const int step = static_cast<int>(k);
            return order_[index_[u] + (delta >= 0 ? step : -step)];
        }
        if (k > static_cast<std::int64_t>(depth_[u]) + depth_[v]) return -1;
        // u側の区間内に答えがあれば、その場で返して再走査を省く。
        const int destination = v;
        while (head_[u] != head_[v]) {
            if (index_[u] >= index_[v]) {
                const int within = depth_[u] - depth_[head_[u]];
                if (k <= within) return order_[index_[u] - static_cast<int>(k)];
                k -= static_cast<std::int64_t>(within) + 1;
                u = parent_[head_[u]];
            } else v = parent_[head_[v]];
        }
        if (index_[u] >= index_[v]) {
            const int within = depth_[u] - depth_[v];
            if (k <= within) return order_[index_[u] - static_cast<int>(k)];
            k -= within;
            const int downward = depth_[destination] - depth_[v];
            return k > downward ? -1 : kth_ancestor(destination, downward - k);
        }
        const int within = depth_[v] - depth_[u];
        if (k <= within) return order_[index_[u] + static_cast<int>(k)];
        const int downward = depth_[destination] - depth_[u];
        return k > downward ? -1 : kth_ancestor(destination, downward - k);
    }
    template<class Fn>
    bool for_each_path(int u, int v, Fn&& visit, bool edges = false) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        if (roots_.size() != 1 && component_[u] != component_[v]) return false;
        std::array<Interval, std::numeric_limits<unsigned int>::digits + 1> downward;
        std::size_t count = 0;
        while (head_[u] != head_[v]) {
#if defined(__GNUC__) && !defined(__clang__)
            if (index_[u] >= index_[v]) {
#else
            if (depth_[head_[u]] >= depth_[head_[v]]) {
#endif
                visit(index_[head_[u]], index_[u] + 1, true); u = parent_[head_[u]];
            } else {
                downward[count++] = {index_[head_[v]], index_[v] + 1, false}; v = parent_[head_[v]];
            }
        }
        if (index_[u] >= index_[v]) {
            const int left = index_[v] + static_cast<int>(edges), right = index_[u] + 1;
            if (left < right) visit(left, right, true);
        } else {
            const int left = index_[u] + static_cast<int>(edges), right = index_[v] + 1;
            if (left < right) downward[count++] = {left, right, false};
        }
        while (count != 0) { const auto part = downward[--count]; visit(part.left, part.right, part.reversed); }
        return true;
    }
    std::vector<Interval> path(int u, int v, bool edges = false) const {
        std::vector<Interval> result;
        for_each_path(u, v, [&](int left, int right, bool reverse) { result.push_back({left, right, reverse}); }, edges);
        return result;
    }
    template<class T>
    std::vector<T> reorder(const std::vector<T>& values) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (values.size() != order_.size()) throw std::invalid_argument("HLD: value count mismatch");
#endif
        std::vector<T> result; result.reserve(order_.size());
        for (int v : order_) result.push_back(values[v]);
        return result;
    }
    template<class T>
    std::vector<T> restore(const std::vector<T>& ordered) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (ordered.size() != order_.size()) throw std::invalid_argument("HLD: value count mismatch");
#endif
        std::vector<T> result; result.reserve(order_.size());
        for (int v = 0; v < size(); ++v) result.push_back(ordered[index_[v]]);
        return result;
    }
    template<class Identity, reinsirk::detail::HldRangeQuery Q, class Op, class Reverse>
        requires std::is_invocable_r_v<reinsirk::detail::HldRangeValue<Q>, Op&,
                     reinsirk::detail::HldRangeValue<Q>, reinsirk::detail::HldRangeValue<Q>>
            && std::is_invocable_r_v<reinsirk::detail::HldRangeValue<Q>, Reverse&, reinsirk::detail::HldRangeValue<Q>>
            && std::is_constructible_v<reinsirk::detail::HldRangeValue<Q>, Identity&&>
            && (!reinsirk::detail::hld_directional_query<Q>
                || std::is_same_v<std::remove_cvref_t<Reverse>, std::identity>)
    auto path_prod(int u, int v, Identity&& identity, Q&& query, Op&& op, Reverse&& reverse, bool edges = false) const {
        return path_product_impl(u, v, std::forward<Identity>(identity), query, op, reverse, edges);
    }
    template<class Identity, reinsirk::detail::HldRangeQuery Q, class Op>
        requires std::is_invocable_r_v<reinsirk::detail::HldRangeValue<Q>, Op&,
                     reinsirk::detail::HldRangeValue<Q>, reinsirk::detail::HldRangeValue<Q>>
            && std::is_constructible_v<reinsirk::detail::HldRangeValue<Q>, Identity&&>
    auto path_prod(int u, int v, Identity&& identity, Q&& query, Op&& op, bool edges = false) const {
        std::identity reverse;
        return path_product_impl(u, v, std::forward<Identity>(identity), query, op, reverse, edges);
    }
    template<class Range>
        requires requires(Range& range) { range.sum(0, 0); }
            && (!requires(Range& range) { range.prod(0, 0); })
    auto path_prod(int u, int v, Range& range, bool edges = false) const {
        using S = std::remove_cvref_t<decltype(range.sum(0, 0))>;
        return path_prod(u, v, S{}, range, reinsirk::detail::HldAddition{}, edges);
    }
    template<template<class, auto, auto> class Range, class S, auto Op, auto E>
        requires requires(const Range<S, Op, E>& range) { { range.prod(0, 0) } -> std::same_as<S>; }
    S path_prod(int u, int v, const Range<S, Op, E>& range, bool edges = false) const {
        return path_prod(u, v, std::invoke(E), range, Op, edges);
    }
    template<template<class, auto, auto> class Range, class S, auto Op, auto E, class Reverse>
        requires std::is_invocable_r_v<S, Reverse&, S>
            && requires(const Range<S, Op, E>& range) { { range.prod(0, 0) } -> std::same_as<S>; }
    S path_prod(int u, int v, const Range<S, Op, E>& range, Reverse&& reverse, bool edges = false) const {
        return path_prod(u, v, std::invoke(E), range, Op, std::forward<Reverse>(reverse), edges);
    }
    template<template<class, auto, auto, class, auto, auto, auto> class Range,
             class S, auto Op, auto E, class F, auto Mapping, auto Composition, auto Id>
        requires requires(Range<S, Op, E, F, Mapping, Composition, Id>& range) { { range.prod(0, 0) } -> std::same_as<S>; }
    S path_prod(int u, int v, Range<S, Op, E, F, Mapping, Composition, Id>& range, bool edges = false) const {
        return path_prod(u, v, std::invoke(E), range, Op, edges);
    }
    template<template<class, auto, auto, class, auto, auto, auto> class Range,
             class S, auto Op, auto E, class F, auto Mapping, auto Composition, auto Id, class Reverse>
        requires std::is_invocable_r_v<S, Reverse&, S>
            && requires(Range<S, Op, E, F, Mapping, Composition, Id>& range) { { range.prod(0, 0) } -> std::same_as<S>; }
    S path_prod(int u, int v, Range<S, Op, E, F, Mapping, Composition, Id>& range, Reverse&& reverse, bool edges = false) const {
        return path_prod(u, v, std::invoke(E), range, Op, std::forward<Reverse>(reverse), edges);
    }
    template<reinsirk::detail::HldRangeQuery Q>
    auto subtree_prod(int v, Q&& query, bool edges = false) const {
        const auto [l, r] = subtree_range(v, edges);
        return reinsirk::detail::hld_read_range(query, l, r, false);
    }
    template<class Range, class F>
    void path_apply(int u, int v, Range& range, const F action, bool edges = false) const {
        const bool connected = for_each_path(u, v, [&](int l, int r, bool) { range.apply(l, r, action); }, edges);
#ifndef SKIP_RUNTIME_CHECKS
        if (!connected) throw std::invalid_argument("HLD: path endpoints are disconnected");
#else
        (void)connected;
#endif
    }
    template<class Range, class F>
    void subtree_apply(int v, Range& range, const F action, bool edges = false) const {
        const auto [l, r] = subtree_range(v, edges);
        if (l < r) range.apply(l, r, action);
    }
};
#endif

#ifndef SIRKIT_HLD_OWNED_RANGE_TRAITS_DEFINED
#define SIRKIT_HLD_OWNED_RANGE_TRAITS_DEFINED
namespace reinsirk::detail {
struct HldNoReverseRange {};
template<class Range> struct HldOwnedRangeTraits {
    using Value = HldRangeValue<Range>;
    static Value identity() { return Value{}; }
    static Value combine(Value a, Value b) { return HldAddition{}(std::move(a), std::move(b)); }
};
template<template<class, auto, auto> class Range, class S, auto Op, auto E>
struct HldOwnedRangeTraits<Range<S, Op, E>> {
    using Value = S;
    static S identity() { return std::invoke(E); }
    static S combine(S a, S b) { return std::invoke(Op, std::move(a), std::move(b)); }
};
template<template<class, auto, auto, class, auto, auto, auto> class Range,
         class S, auto Op, auto E, class F, auto Mapping, auto Composition, auto Id>
struct HldOwnedRangeTraits<Range<S, Op, E, F, Mapping, Composition, Id>> {
    using Value = S;
    static S identity() { return std::invoke(E); }
    static S combine(S a, S b) { return std::invoke(Op, std::move(a), std::move(b)); }
};
struct HldDifference {
    template<class T> T operator()(T a, T b) const {
#if defined(__SIZEOF_INT128__) && (defined(__GNUC__) || defined(__clang__))
        if constexpr (std::is_same_v<T, __int128> || std::is_same_v<T, unsigned __int128>)
            return static_cast<T>(static_cast<unsigned __int128>(a) - static_cast<unsigned __int128>(b));
        else
#endif
        if constexpr (std::is_integral_v<T> && !std::is_same_v<T, bool>) {
            using U = std::make_unsigned_t<T>;
            return static_cast<T>(static_cast<U>(a) - static_cast<U>(b));
        } else return a - b;
    }
};
}
#endif

#ifndef SIRKIT_HEAVY_LIGHT_VALUES_DEFINED
#define SIRKIT_HEAVY_LIGHT_VALUES_DEFINED
template<class Range, bool Ordered>
class HeavyLightValues {
    using Traits = reinsirk::detail::HldOwnedRangeTraits<Range>;
public:
    using value_type = typename Traits::Value;
private:
    static Range make_range(const std::vector<value_type>& values) {
        if constexpr (std::is_constructible_v<Range, const std::vector<value_type>&>) return Range(values);
        else {
            static_assert(std::is_constructible_v<Range, int> && requires(Range& r, value_type x) { r.add(0, x); },
                          "HLD: Range needs a vector constructor or an int constructor and add");
            Range result(static_cast<int>(values.size()));
            for (int i = 0; i < static_cast<int>(values.size()); ++i) result.add(i, values[i]);
            return result;
        }
    }
    struct State {
        HeavyLightDecomposition layout;
        Range range;
        [[no_unique_address]] std::conditional_t<Ordered, std::optional<Range>, reinsirk::detail::HldNoReverseRange> reversed;
        State(HeavyLightDecomposition tree, std::vector<value_type> ordered)
            : layout(std::move(tree)), range(make_range(ordered)) {
            if constexpr (Ordered) { std::reverse(ordered.begin(), ordered.end()); reversed.emplace(make_range(ordered)); }
        }
    };
    std::unique_ptr<State> state_;
    const HeavyLightDecomposition& layout() const noexcept {
        if (state_) return state_->layout;
        static const HeavyLightDecomposition empty;
        return empty;
    }
    Range& range() {
#ifndef SKIP_RUNTIME_CHECKS
        if (!state_) throw std::out_of_range("HLD: empty values");
#endif
        return state_->range;
    }
    static value_type read_point(Range& r, int p) {
        if constexpr (requires { r.get(p); }) return r.get(p);
        else return r.sum(p, p + 1);
    }
    static void set_point(Range& r, int p, const value_type& value) {
        if constexpr (requires { r.set(p, value); }) r.set(p, value);
        else r.add(p, reinsirk::detail::HldDifference{}(value, read_point(r, p)));
    }
public:
    HeavyLightValues() = default;
    HeavyLightValues(const HeavyLightDecomposition& tree, const std::vector<value_type>& values) {
        auto ordered = tree.reorder(values);
        state_ = std::make_unique<State>(tree, std::move(ordered));
    }
    HeavyLightValues(HeavyLightDecomposition&& tree, const std::vector<value_type>& values) {
        auto ordered = tree.reorder(values);
        state_ = std::make_unique<State>(std::move(tree), std::move(ordered));
    }
    HeavyLightValues(const Graph& graph, const std::vector<value_type>& values, int root = 0)
        : HeavyLightValues(HeavyLightDecomposition(graph, root), values) {}
    HeavyLightValues(const HeavyLightValues& other) {
        if (other.state_) state_ = std::make_unique<State>(*other.state_);
    }
    HeavyLightValues(HeavyLightValues&&) noexcept = default;
    HeavyLightValues& operator=(HeavyLightValues other) noexcept { swap(other); return *this; }
    void swap(HeavyLightValues& other) noexcept { state_.swap(other.state_); }
    void clear() noexcept { state_.reset(); }
    void build(const Graph& graph, const std::vector<value_type>& values, int root = 0) {
        HeavyLightValues replacement(graph, values, root); swap(replacement);
    }
    int size() const noexcept { return layout().size(); }
    bool empty() const noexcept { return layout().empty(); }
    int root() const noexcept { return layout().root(); }
    int component_count() const noexcept { return layout().component_count(); }
    int parent(int v) const { return layout().parent(v); }
    int depth(int v) const { return layout().depth(v); }
    int component(int v) const { return layout().component(v); }
    int root_of(int v) const { return layout().root_of(v); }
    int index(int v) const { return layout().index(v); }
    int vertex_at(int p) const { return layout().vertex_at(p); }
    const std::vector<int>& order() const noexcept { return layout().order(); }
    bool same_component(int u, int v) const { return layout().same_component(u, v); }
    bool is_ancestor(int u, int v) const { return layout().is_ancestor(u, v); }
    auto subtree_range(int v, bool edges = false) const { return layout().subtree_range(v, edges); }
    int subtree_size(int v) const { return layout().subtree_size(v); }
    int lca(int u, int v) const { return layout().lca(u, v); }
    int distance(int u, int v) const { return layout().distance(u, v); }
    int kth_ancestor(int v, std::int64_t k) const { return layout().kth_ancestor(v, k); }
    int jump(int u, int v, std::int64_t k) const { return layout().jump(u, v, k); }
    template<class Fn> bool for_each_path(int u, int v, Fn&& fn, bool edges = false) const {
        return layout().for_each_path(u, v, std::forward<Fn>(fn), edges);
    }
    auto path(int u, int v, bool edges = false) const { return layout().path(u, v, edges); }
    template<class T> std::vector<T> reorder(const std::vector<T>& values) const { return layout().reorder(values); }
    template<class T> std::vector<T> restore(const std::vector<T>& values) const { return layout().restore(values); }
    value_type get(int v) requires (requires(Range& r) { r.get(0); } || requires(Range& r) { r.sum(0, 1); }) {
        const int p = layout().index(v); return read_point(range(), p);
    }
    void set(int v, const value_type value)
        requires (requires(Range& r, value_type x) { r.set(0, x); }
               || requires(Range& r, value_type x) { r.add(0, x); x - x; }) {
        const int p = layout().index(v); set_point(range(), p, value);
        if constexpr (Ordered) set_point(*state_->reversed, size() - 1 - p, value);
    }
    void add(int v, const value_type delta) requires requires(Range& r, value_type x) { r.add(0, x); } {
        const int p = layout().index(v); range().add(p, delta);
        if constexpr (Ordered) state_->reversed->add(size() - 1 - p, delta);
    }
    template<class F> void apply(int v, const F action) requires requires(Range& r, const F& f) { r.apply(0, f); } {
        const int p = layout().index(v); range().apply(p, action);
        if constexpr (Ordered) state_->reversed->apply(size() - 1 - p, action);
    }
    value_type path_prod(int u, int v, bool edges = false) {
        auto& forward = range();
        if constexpr (!Ordered) return layout().path_prod(u, v, forward, edges);
        else return layout().path_prod(u, v, Traits::identity(), [&](int l, int r, bool reverse) {
            return reverse ? reinsirk::detail::hld_read_range(*state_->reversed, size() - r, size() - l, false)
                           : reinsirk::detail::hld_read_range(forward, l, r, false);
        }, Traits::combine, edges);
    }
    value_type subtree_prod(int v, bool edges = false) { return layout().subtree_prod(v, range(), edges); }
    template<class F> void path_apply(int u, int v, const F action, bool edges = false)
        requires requires(Range& r, const F& f) { r.apply(0, 0, f); } {
        if constexpr (!Ordered) layout().path_apply(u, v, range(), action, edges);
        else {
            auto& forward = range();
            const bool connected = layout().for_each_path(u, v, [&](int l, int r, bool) {
                forward.apply(l, r, action); state_->reversed->apply(size() - r, size() - l, action);
            }, edges);
#ifndef SKIP_RUNTIME_CHECKS
            if (!connected) throw std::invalid_argument("HLD: path endpoints are disconnected");
#else
            (void)connected;
#endif
        }
    }
    template<class F> void subtree_apply(int v, const F action, bool edges = false)
        requires requires(Range& r, const F& f) { r.apply(0, 0, f); } {
        const auto [l, r] = layout().subtree_range(v, edges);
        if (l < r) { range().apply(l, r, action); if constexpr (Ordered) state_->reversed->apply(size() - r, size() - l, action); }
    }
    std::vector<value_type> values() {
        if (!state_) return {};
        if constexpr (requires(Range& r) { r.values(); }) return layout().restore(range().values());
        else {
            std::vector<value_type> result; result.reserve(size());
            for (int v = 0; v < size(); ++v) result.push_back(get(v));
            return result;
        }
    }
};

template<class Range, bool Ordered, class T>
HeavyLightValues<Range, Ordered> HeavyLightDecomposition::with_values(const std::vector<T>& values) const & {
    return HeavyLightValues<Range, Ordered>(*this, values);
}
template<class Range, bool Ordered, class T>
HeavyLightValues<Range, Ordered> HeavyLightDecomposition::with_values(const std::vector<T>& values) && {
    return HeavyLightValues<Range, Ordered>(std::move(*this), values);
}

#endif

// SPDX-License-Identifier: CC0-1.0
// 参考（データ構造・検証問題）: https://nyaannyaan.github.io/library/data-structure/binary-indexed-tree.hpp
// 参考（公開API）: https://atcoder.github.io/ac-library/production/document_ja/fenwicktree.html
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/fenwick_tree.md
//
// API一覧
// [fenwick_tree<T>]
// fenwick_tree()/fenwick_tree(int n)/fenwick_tree(vector<T>): 空列/n要素の0/列から構築。O(n+1)時間・領域。
// add(int p,T x): 点加算。sum(int l,int r): 半開区間[l,r)の和をT値で返す。O(log(n+1))、空区間はT{}。
// 点添字は0<=p<size()、区間は0<=l<=r<=size()。
// ACL形式の公開APIをグローバルに定義する。bool以外の整数は内部を符号なしにして型幅のmod 2^bitで計算する。
// その他のTはT{}が単位元の可換加法群とし、加減算・コピーをO(1)とする。要素数はintの範囲内。
// size()/empty(): 要素数/空か、O(1)。get(int p)/set(int p,T value): 点取得/代入、O(log(n+1))。
// lower_bound(target)/upper_bound(target): sum(0,i+1)>=target/>targetとなる最小int添字、なければsize()。O(log(n+1))。
// 境界探索は全要素が非負で、途中の和がTに収まり、加算と順序が整合すること。全要素の検査はしない。
// values(): 列を復元して返す。O(n+1)時間・追加O(n)。reset(int n)/reset(): n要素/現在の長さを0にする。O(旧n+n+1)。
// clear()/swap(other): 空にして容量保持/交換。O(旧n+1)/O(1)。コピーは独立、移動元は空として使える。
// 添字・区間は既定で検査しSKIP_RUNTIME_CHECKSで除く。容量・添字のオーバーフロー対策は残す。

#include <algorithm>
#include <bit>
#include <cstddef>
#include <limits>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

#ifndef SIRKIT_FENWICK_STORAGE_TYPE_DEFINED
#define SIRKIT_FENWICK_STORAGE_TYPE_DEFINED
namespace reinsirk::detail {
template<class T, bool = std::is_integral_v<T> && !std::is_same_v<T, bool>>
struct FenwickStorage { using type = T; };
template<class T>
struct FenwickStorage<T, true> { using type = std::make_unsigned_t<T>; };
#if defined(__SIZEOF_INT128__)
template<> struct FenwickStorage<__int128> { using type = unsigned __int128; };
template<> struct FenwickStorage<unsigned __int128> { using type = unsigned __int128; };
#endif
}
#endif

#ifndef SIRKIT_FENWICK_TREE_DEFINED
#define SIRKIT_FENWICK_TREE_DEFINED
template<class T>
class fenwick_tree {
    using Storage = typename reinsirk::detail::FenwickStorage<T>::type;
    std::vector<Storage> tree_;
    static decltype(auto) to_storage(const T& value) {
        if constexpr (std::is_same_v<T, Storage>) return (value);
        else return static_cast<Storage>(value);
    }
    static decltype(auto) from_storage(Storage& value) {
        if constexpr (std::is_same_v<T, Storage>) return (value);
        else return static_cast<T>(value);
    }
    static std::size_t checked_size(int n) {
#ifndef SKIP_RUNTIME_CHECKS
        if (n < 0) throw std::invalid_argument("fenwick_tree: negative size");
#endif
        return static_cast<std::size_t>(n);
    }
    static std::size_t storage_size(std::size_t n) {
        if (n > static_cast<std::size_t>(std::numeric_limits<int>::max())
            || n + 1 > std::vector<Storage>{}.max_size())
            throw std::length_error("fenwick_tree: size");
        return n == 0 ? 0 : n + 1;
    }
    static std::size_t lowbit(std::size_t x) noexcept { return x & (~x + 1); }
    void check_index(int i) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (i < 0 || i >= size()) throw std::out_of_range("fenwick_tree: index");
#else
        (void)i;
#endif
    }
    void check_range(int l, int r) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (l < 0 || l > r || r > size()) throw std::out_of_range("fenwick_tree: range");
#else
        (void)l; (void)r;
#endif
    }
    Storage prefix_unchecked(std::size_t r) const {
        Storage result{};
        for (; r; r -= lowbit(r)) result += tree_[r];
        return result;
    }
    Storage get_unchecked(std::size_t i) const {
        auto node = i + 1;
        Storage result = tree_[node];
        const auto begin = node - lowbit(node);
        for (--node; node > begin; node -= lowbit(node)) result -= tree_[node];
        return result;
    }
    void add_unchecked(std::size_t i, const Storage& delta) {
        const auto n = static_cast<std::size_t>(size());
        for (++i; i <= n;) {
            tree_[i] += delta;
            const auto step = lowbit(i);
            if (step > n - i) break;
            i += step;
        }
    }
public:
    fenwick_tree() = default;
    explicit fenwick_tree(int n) : tree_(storage_size(checked_size(n)), Storage{}) {}
    template<class Values> requires std::is_same_v<Values, std::vector<T>>
    explicit fenwick_tree(const Values& values) : tree_(storage_size(values.size()), Storage{}) {
        const auto n = values.size();
        for (std::size_t i = 1; i <= n; ++i) {
            tree_[i] += to_storage(values[i - 1]);
            const auto step = lowbit(i);
            if (step <= n - i) tree_[i + step] += tree_[i];
        }
    }
    fenwick_tree(const fenwick_tree&) = default;
    fenwick_tree& operator=(const fenwick_tree&) = default;
    fenwick_tree(fenwick_tree&& other) noexcept : tree_(std::move(other.tree_)) { other.tree_.clear(); }
    fenwick_tree& operator=(fenwick_tree&& other) noexcept {
        if (this != &other) { tree_ = std::move(other.tree_); other.tree_.clear(); }
        return *this;
    }
    int size() const noexcept { return tree_.empty() ? 0 : static_cast<int>(tree_.size() - 1); }
    bool empty() const noexcept { return size() == 0; }
    void add(int i, T delta) {
        check_index(i);
        add_unchecked(static_cast<std::size_t>(i), to_storage(delta));
    }
    T get(int i) const { check_index(i); return static_cast<T>(get_unchecked(static_cast<std::size_t>(i))); }
    void set(int i, T value) {
        check_index(i);
        const Storage delta = to_storage(value) - get_unchecked(static_cast<std::size_t>(i));
        add_unchecked(static_cast<std::size_t>(i), delta);
    }
    T sum(int l, int r) {
        check_range(l, r);
        return static_cast<T>(prefix_unchecked(static_cast<std::size_t>(r)) - prefix_unchecked(static_cast<std::size_t>(l)));
    }
    int lower_bound(const T& target) const {
        if (!(T{} < target)) return 0;
        const auto n = static_cast<std::size_t>(size());
        std::size_t index = 0;
        Storage current{};
        for (auto jump = std::bit_floor(n); jump; jump >>= 1) {
            if (jump <= n - index) {
                const auto next = index + jump;
                Storage candidate = current + tree_[next];
                if (from_storage(candidate) < target) { current = std::move(candidate); index = next; }
            }
        }
        return static_cast<int>(index);
    }
    int upper_bound(const T& target) const {
        if (target < T{}) return 0;
        const auto n = static_cast<std::size_t>(size());
        std::size_t index = 0;
        Storage current{};
        for (auto jump = std::bit_floor(n); jump; jump >>= 1) {
            if (jump <= n - index) {
                const auto next = index + jump;
                Storage candidate = current + tree_[next];
                if (!(target < from_storage(candidate))) { current = std::move(candidate); index = next; }
            }
        }
        return static_cast<int>(index);
    }
    std::vector<T> values() const {
        if (tree_.empty()) return {};
        std::vector<T> result(tree_.begin() + 1, tree_.end());
        const auto n = static_cast<std::size_t>(size());
        for (auto i = n; i; --i) {
            const auto step = lowbit(i);
            if (step <= n - i) {
                if constexpr (std::is_same_v<T, Storage>) result[i + step - 1] -= result[i - 1];
                else {
                    const Storage difference = static_cast<Storage>(result[i + step - 1]) - static_cast<Storage>(result[i - 1]);
                    result[i + step - 1] = static_cast<T>(difference);
                }
            }
        }
        return result;
    }
    void reset(int n) {
        std::vector<Storage> replacement(storage_size(checked_size(n)), Storage{});
        tree_.swap(replacement);
    }
    void reset() { std::fill(tree_.begin(), tree_.end(), Storage{}); }
    void clear() noexcept { tree_.clear(); }
    void swap(fenwick_tree& other) noexcept { tree_.swap(other.tree_); }
};
#endif

// SPDX-License-Identifier: CC0-1.0
// 参考（モノイドと区間積）: https://info.atcoder.jp/entry/algorithm_lectures/range_query_monoid_design
// API仕様: https://atcoder.github.io/ac-library/production/document_ja/segtree.html
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/segment_tree.md
//
// API一覧
// [segtree<S, op, e>（ACL形式、グローバルに定義）]
// segtree()/segtree(int n)/segtree(vector<S>): 空列/n個の単位元/列から構築。0<=n<=INT_MAX、O(n+1)時間・領域。
// S op(S,S)は結合的、S e()は左右の単位元。同じ呼び出し形式の関数オブジェクトも可。演算/コピーはO(1)。
// 点添字は0<=p<size()、区間は0<=l<=r<=size()の半開区間。
// set(int p,S x): 点代入、O(log(n+1))。get(int p): 点のS値、O(1)。prod(int l,int r): 左からの区間積、O(log(n+1))。
// all_prod(): 全積のS値、O(1)。空区間・空列の積はe()。積は非可換でもよい。
// max_right<pred>(int l)/min_left<pred>(int r): bool pred(S)を使う境界探索。述語を第2引数に渡す形式も可。戻り値はint、O(log(n+1))。
// 探索はpred(e())==trueで、区間を延ばすと真から偽へ一度だけ変化すること。述語に副作用を持たせない。
// [追加機能]
// size()/empty(): intの要素数/空か、O(1)。transform(int p,f): 点をf(現在値)へ更新、O(log(n+1))。
// values(): 列のコピー、O(n+1)。assign(vector<S>)/reset(int n)/reset(): 列/n個/現在の長さの単位元へ再構築、O(旧n+n+1)。
// clear()/swap(other): 容量を保持して空へ/交換、O(旧n+1)/O(1)。コピーは独立、移動元は空。値の演算等が投げる場合は内容の強い保証なし。

#include <algorithm>
#include <bit>
#include <cstddef>
#include <functional>
#include <limits>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

#ifndef SIRKIT_SEGMENT_TREE_DEFINED
#define SIRKIT_SEGMENT_TREE_DEFINED
template<class S, auto op, auto e>
class segtree {
    static_assert(std::is_invocable_r_v<S, decltype(op), S, S>, "segtree: op(S,S) must return S");
    static_assert(std::is_invocable_r_v<S, decltype(e)>, "segtree: e() must return S");
    S identity_;
    std::size_t n_ = 0, base_ = 1;
    std::vector<S> data_;
    static std::size_t leaf_base(std::size_t n) {
        if (n == 0) return 1;
        const auto limit = std::vector<S>{}.max_size() / 2;
        std::size_t base = 1;
        while (base < n) {
            if (base > limit / 2) throw std::length_error("segtree: size");
            base *= 2;
        }
        if (base > limit) throw std::length_error("segtree: size");
        return base;
    }
    static std::size_t checked_size(int n) {
#ifndef SKIP_RUNTIME_CHECKS
        if (n < 0) throw std::invalid_argument("segtree: negative size");
#endif
        return static_cast<std::size_t>(n);
    }
    static int vector_size(const std::vector<S>& values) {
        if (values.size() > static_cast<std::size_t>(std::numeric_limits<int>::max()))
            throw std::length_error("segtree: int size overflow");
        return static_cast<int>(values.size());
    }
    void check_index(int i) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (i < 0 || static_cast<std::size_t>(i) >= n_) throw std::out_of_range("segtree: index");
#else
        (void)i;
#endif
    }
    void check_range(int l, int r) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (l < 0 || l > r || static_cast<std::size_t>(r) > n_) throw std::out_of_range("segtree: range");
#else
        (void)l; (void)r;
#endif
    }
    static unsigned aligned_node(unsigned value) {
        if (value == 0) std::unreachable();
        return value >> std::countr_zero(value);
    }
    void rebuild() {
        for (auto p = base_; p > 1;) {
            --p;
            data_[p] = std::invoke(op, data_[2 * p], data_[2 * p + 1]);
        }
    }
    void update_carried_ancestors(std::size_t p) {
        if (p <= 1) return;
        S value = std::as_const(data_)[p];
        while (p > 1) {
            const S sibling = std::as_const(data_)[p ^ 1];
            const S left = (p & 1) ? sibling : value;
            const S right = (p & 1) ? value : sibling;
            value = std::invoke(op, left, right);
            p >>= 1;
            data_[p] = std::as_const(value);
        }
    }
    void update_ancestors(std::size_t p) {
        if constexpr (std::is_trivially_copyable_v<S> && std::is_copy_constructible_v<S> &&
                      std::is_copy_assignable_v<S> && sizeof(S) <= 16 &&
                      std::is_invocable_r_v<S, decltype(op), const S&, const S&>) {
#if defined(__clang__)
            if constexpr (sizeof(S) > 8) {
                // 照会を含む呼び出し側のコードが膨らむのを抑える。
                [[clang::noinline]] update_carried_ancestors(p);
                return;
            }
#endif
            update_carried_ancestors(p);
        } else {
            for (p >>= 1; p; p >>= 1) data_[p] = std::invoke(op, data_[2 * p], data_[2 * p + 1]);
        }
    }
public:
    segtree() : segtree(0) {}
    explicit segtree(int n)
        : identity_(std::invoke(e)), n_(checked_size(n)), base_(leaf_base(n_)),
          data_(n_ ? 2 * base_ : 0, identity_) {}
    explicit segtree(const std::vector<S>& values) : segtree(vector_size(values)) {
        if (!n_) return;
        std::copy(values.begin(), values.end(), data_.begin() + base_);
        rebuild();
    }
    segtree(const segtree&) = default;
    segtree& operator=(const segtree& other) {
        if (this != &other) { segtree replacement(other); swap(replacement); }
        return *this;
    }
    segtree(segtree&& other)
        : identity_(other.identity_), n_(other.n_), base_(other.base_), data_(std::move(other.data_)) {
        other.n_ = 0; other.base_ = 1; other.data_.clear();
    }
    segtree& operator=(segtree&& other) {
        if (this != &other) { segtree replacement(std::move(other)); swap(replacement); }
        return *this;
    }
    int size() const noexcept { return static_cast<int>(n_); }
    bool empty() const noexcept { return n_ == 0; }
    S get(int i) const { check_index(i); return data_[base_ + static_cast<std::size_t>(i)]; }
    void set(int i, S value) {
        check_index(i);
        const auto p = base_ + static_cast<std::size_t>(i);
        data_[p] = std::move(value);
        update_ancestors(p);
    }
    template<class F> void transform(int i, F&& f) {
        check_index(i);
        const auto p = base_ + static_cast<std::size_t>(i);
        data_[p] = std::invoke(std::forward<F>(f), std::as_const(data_)[p]);
        update_ancestors(p);
    }
    S prod(int l, int r) const {
        check_range(l, r);
        if (l == r) return identity_;
        // n<=INT_MAXなので葉番号はunsignedに収まり、両端は常に正。
        unsigned first = static_cast<unsigned>(base_) + static_cast<unsigned>(l);
        unsigned last = static_cast<unsigned>(base_) + static_cast<unsigned>(r);
        auto step = first & (~first + 1);
        if (step > last - first) {
            // firstの整列幅より残りが短ければ、右端の下位bitを落としてfirstへ戻れる。
            S result = data_[aligned_node(last) - 1];
            last -= last & (~last + 1);
            while (first < last) {
                result = std::invoke(op, data_[aligned_node(last) - 1], result);
                last -= last & (~last + 1);
            }
            return result;
        }
        // 左から最大の整列ブロックを選ぶ。最初は節点をコピーし、単位元との積を省く。
        S left = data_[aligned_node(first)];
        first += step;
        if (first == last) return left;
        // 短い残区間では分割点の計算を省く。
        if (last - first <= 32) {
            while (first < last && (step = first & (~first + 1)) <= last - first) {
                left = std::invoke(op, left, data_[aligned_node(first)]);
                first += step;
            }
            if (first == last) return left;
            S right = data_[aligned_node(last) - 1];
            last -= last & (~last + 1);
            while (first < last) {
                right = std::invoke(op, data_[aligned_node(last) - 1], right);
                last -= last & (~last + 1);
            }
            return std::invoke(op, left, right);
        }
        // 左走査が止まる整列境界を先に求め、独立な左右の積を交互に進める。
        const unsigned stop = last & (0U - std::bit_floor((first - 1) ^ (last - 1)));
        if (stop == last) {
            while (first < stop) {
                left = std::invoke(op, left, data_[aligned_node(first)]);
                first += first & (~first + 1);
            }
            return left;
        }
        S right = data_[aligned_node(last) - 1];
        last -= last & (~last + 1);
        while (first < stop && last > stop) {
            left = std::invoke(op, left, data_[aligned_node(first)]);
            first += first & (~first + 1);
            right = std::invoke(op, data_[aligned_node(last) - 1], right);
            last -= last & (~last + 1);
        }
        while (first < stop) {
            left = std::invoke(op, left, data_[aligned_node(first)]);
            first += first & (~first + 1);
        }
        while (last > stop) {
            right = std::invoke(op, data_[aligned_node(last) - 1], right);
            last -= last & (~last + 1);
        }
        return std::invoke(op, left, right);
    }
    S all_prod() const { return n_ ? data_[1] : identity_; }
    template<bool (*Pred)(S)> int max_right(int l) const { return max_right(l, Pred); }
    template<class Pred> int max_right(int l, Pred pred) const {
        check_range(l, l);
#ifndef SKIP_RUNTIME_CHECKS
        if (!std::invoke(pred, identity_)) throw std::invalid_argument("segtree: predicate(e())");
#endif
        if (static_cast<std::size_t>(l) == n_) return size();
        S accumulated = identity_;
        auto node = base_ + static_cast<std::size_t>(l);
        while (true) {
            while (!(node & 1)) node >>= 1;
            S candidate = std::invoke(op, accumulated, data_[node]);
            if (!std::invoke(pred, candidate)) {
                while (node < base_) {
                    node *= 2;
                    S next = std::invoke(op, accumulated, data_[node]);
                    if (std::invoke(pred, next)) { accumulated = std::move(next); ++node; }
                }
                return static_cast<int>(std::min(n_, node - base_));
            }
            accumulated = std::move(candidate);
            ++node;
            if ((node & (node - 1)) == 0) return size();
        }
    }
    template<bool (*Pred)(S)> int min_left(int r) const { return min_left(r, Pred); }
    template<class Pred> int min_left(int r, Pred pred) const {
        check_range(r, r);
#ifndef SKIP_RUNTIME_CHECKS
        if (!std::invoke(pred, identity_)) throw std::invalid_argument("segtree: predicate(e())");
#endif
        if (r == 0) return 0;
        S accumulated = identity_;
        auto node = base_ + static_cast<std::size_t>(r);
        while (true) {
            --node;
            while (node > 1 && (node & 1)) node >>= 1;
            S candidate = std::invoke(op, data_[node], accumulated);
            if (!std::invoke(pred, candidate)) {
                while (node < base_) {
                    node = 2 * node + 1;
                    S next = std::invoke(op, data_[node], accumulated);
                    if (std::invoke(pred, next)) { accumulated = std::move(next); --node; }
                }
                return static_cast<int>(node + 1 - base_);
            }
            accumulated = std::move(candidate);
            if ((node & (node - 1)) == 0) return 0;
        }
    }
    std::vector<S> values() const {
        if (!n_) return {};
        return std::vector<S>(data_.begin() + base_, data_.begin() + base_ + n_);
    }
    void assign(const std::vector<S>& values) { segtree replacement(values); swap(replacement); }
    void reset(int n) { segtree replacement(n); swap(replacement); }
    void reset() { std::fill(data_.begin(), data_.end(), identity_); }
    void clear() noexcept { data_.clear(); n_ = 0; base_ = 1; }
    void swap(segtree& other) noexcept(std::is_nothrow_swappable_v<S>) {
        using std::swap;
        swap(identity_, other.identity_);
        swap(n_, other.n_); swap(base_, other.base_); data_.swap(other.data_);
    }
};
#endif

}
#undef SIRKIT_FENWICK_STORAGE_TYPE_DEFINED
#undef SIRKIT_FENWICK_TREE_DEFINED
#undef SIRKIT_HEAVY_LIGHT_DECOMPOSITION_DEFINED
#undef SIRKIT_HEAVY_LIGHT_VALUES_DEFINED
#undef SIRKIT_HEAVY_LIGHT_VALUES_FORWARD_DEFINED
#undef SIRKIT_HLD_OWNED_RANGE_TRAITS_DEFINED
#undef SIRKIT_HLD_QUERY_HELPERS_DEFINED
#undef SIRKIT_SEGMENT_TREE_DEFINED
#undef SIRKIT_UNWEIGHTED_GRAPH_DEFINED
namespace candidate {
// SPDX-License-Identifier: CC0-1.0
// 参考（重軽分解の理論）: https://info.atcoder.jp/entry/algorithm_lectures/heavy_light_decomposition
// 参考（API設計）: https://ei1333.github.io/library/graph/tree/heavy-light-decomposition.hpp.html
// https://github.com/hitonanode/cplib-cpp/blob/master/tree/heavy_light_decomposition.hpp
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/heavy_light_decomposition.md
//
// API一覧
// [共通型] Graphはvector<vector<int>>。HeavyLightDecomposition::Intervalは{int left,right;bool reversed;}。
// [値を持つHLD: HeavyLightValues<Range,Ordered=false>]
// value_typeはBITのT/Segtree・LazyのS。HeavyLightValues()は空。コピー構築/代入は独立、移動構築はO(1)。
// operator=(other)は自身への参照を返す。代入/buildは旧状態の破棄費用も加わる。
// with_values<Range,Ordered>(values): values[v]を頂点vの値とする長さNのvectorから、分解と集計器を独立所有するHLDを返す。
// 元の値配列とは更新を共有しない。get/set/add/applyのvは頂点番号で、index(v)への変換は不要。
// 一時HLDなら分解を移動、既存HLDならコピー。RangeはBIT/ACL形式Segtree/Lazy。値の型はRangeから推論。
// HeavyLightValues(g,values,root=0)/build(g,values,root=0): 分解と値を同時に構築/再構築。失敗時は元を保持。
// HeavyLightValues(layout,values): 分解をコピー、std::move(layout)なら移動。移動後の失敗では元分解が空の場合あり。
// 構築は分解O(N+M)+集計器のvector構築。vector構築なしのBITはN回add。所有状態を1回確保する。
// get(v)/set(v,x)/add(v,x): 頂点番号で取得/代入/加算。addは対応BITのみ。通常の集計器ではO(log N)。
// apply(v,f)/path_apply(u,v,f,edges=false)/subtree_apply(v,f,edges=false): 点/経路/部分木へ作用。
// path_prod(u,v,edges=false)/subtree_prod(v,edges=false): 所有集計器で経路/部分木を集計。通常O(log²N)/O(log N)。
// Ordered=falseは和・最小値などの可換演算用。trueは文字列連結などをu→vの順に集計。領域と更新は集計器2本分。
// trueは値の並び順を守る設定で、個々の辺の値を逆元へ変える機能ではない。部分木の積はDFS添字昇順。
// 辺モードは子vに親辺の値を置き、各根には0/e()を置く。初期値はN個必要。edges=trueでLCA/部分木の指定頂点を除く。
// path_prod(v,v)は頂点の値、path_prod(v,v,true)や葉の辺部分木は空区間の単位元。空区間の更新は何もしない。
// values(): 元の頂点順へ復元。Range.valuesがあればO(N)の並べ直し、なければN回点照会。
// clear()/swap(other): 空へ/交換。コピーは独立、move元は空。build/コピー失敗時は元を保持。
// 分解情報・reorder/restore/for_each_path/pathも同名で取得可能。対応applyを持つRangeでのみ作用APIを使用できる。
// 所有型にInterval型別名・with_values・外部集計器を受けるオーバーロードはない。pathの要素型は上記Interval。
// 値の照会も非constの所有HLDから呼ぶ。根を変えて辺の値をbuildする場合は、新しい親子対応で値を配置し直す。
// 値の更新中の例外では変更は巻き戻さない。Ordered=trueでは例外後にclear/buildで再構築すること。
// [分解だけを持つHLD: HeavyLightDecomposition]
// HeavyLightDecomposition()は空、コピー構築はO(N)、移動構築はO(1)。operator=(other)は自身への参照を返す。
// コピー・移動代入とbuildは旧状態の破棄費用も加わる。
// HeavyLightDecomposition(g,root=0)/build(g,root=0): 無向森を反復DFSで分解。O(n+m)時間・領域。
// 頂点番号[0,n)。隣接リストの対称性は前提。rootの木から、残りは最小未訪問頂点から構築する。
// 失敗時は元を保持。空のgにはroot=0。閉路・自己辺・多重辺は検査有効時に例外。
// size()/empty()/root()/component_count(): 頂点数/空か/指定根（空なら-1）/木の数。O(1)。
// parent(v)/depth(v)/component(v)/root_of(v): 親（根は-1）/深さ/木の番号/木の根。O(1)。
// index(v)/vertex_at(i)/order(): heavy優先DFS添字/対応頂点/順序配列へのconst参照。O(1)。
// same_component(u,v)/is_ancestor(u,v): 同じ木か/祖先か（自身を含む）。O(1)。
// subtree_range(v,edges=false): 部分木の半開区間。edges=trueは根vを除き子側の頂点で辺を表す。O(1)。
// subtree_size(v): 部分木の頂点数。O(1)。lca(u,v)/distance(u,v): LCA/辺数、異なる木は-1。O(log n)。
// kth_ancestor(v,k): k個上の頂点。k<0/根を越すと-1。jump(u,v,k): u→vのk番目、範囲外/異なる木は-1。O(log n)。
// for_each_path(u,v,fn,edges=false): 通行順にfn(left,right,reversed)を呼ぶ。fnの戻り値は無視。接続ならtrue、異なる木はfalse。
// reversed=trueはright-1からleftへ読む。区間は半開。edges=trueはLCAを除く。O(log n)、ヒープ確保なし。
// path(u,v,edges=false): 同じ順序のInterval{left,right,reversed}配列を返す。異なる木は空。O(log n)時間・領域。
// clear()/swap(other): 空に戻す/O(1)交換。コピーは独立所有、ムーブ元は空。検査はSKIP_RUNTIME_CHECKSで除く。
// reorder(values)/restore(ordered): 長さNのvectorをDFS添字順/元の頂点順へコピー。O(N)時間・領域。
// path_prod(u,v,bit,edges=false): sumを持つBITの和。単位元はT{}、整数は型幅で周回。O(log N)回照会。
// path_prod(u,v,seg,edges=false): ACL形式のSegtreeからop/eを推論した可換積。Segはconst可、Lazyは非const。
// path_prod(u,v,identity,query,op,edges=false): queryはprod/sum、2引数関数なら可換、3引数(l,r,reversed)なら向き対応。
// path_prod(u,v,seg,reverse,edges=false)/汎用版のop直後にreverse指定: 正しい逆順集約を返す非可換積。
// subtree_prod(v,query,edges=false): 部分木のDFS添字昇順の積。区間照会1回。非可換も可。
// path_apply(u,v,range,f,edges=false)/subtree_apply(v,range,f,edges=false): range.apply(l,r,f)で更新。O(log N)/1回。
// prod/applyのrangeは同じDFS添字順で用意する。path_prod/path_applyは同じ木が前提、検査時は別木を例外。

#include <algorithm>
#include <array>
#include <bit>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <memory>
#include <optional>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

#ifndef SIRKIT_UNWEIGHTED_GRAPH_DEFINED
#define SIRKIT_UNWEIGHTED_GRAPH_DEFINED
using Graph = std::vector<std::vector<int>>;
#endif

#ifndef SIRKIT_HLD_QUERY_HELPERS_DEFINED
#define SIRKIT_HLD_QUERY_HELPERS_DEFINED
namespace reinsirk::detail {
template<class Q>
concept HldRangeQuery = requires(Q& q) { q.prod(0, 0); }
    || requires(Q& q) { q.sum(0, 0); }
    || std::is_invocable_v<Q&, int, int, bool> || std::is_invocable_v<Q&, int, int>;
template<class Q>
inline constexpr bool hld_directional_query = !requires(Q& q) { q.prod(0, 0); }
    && !requires(Q& q) { q.sum(0, 0); } && std::is_invocable_v<Q&, int, int, bool>;
template<HldRangeQuery Q>
decltype(auto) hld_read_range(Q& query, int l, int r, bool reversed) {
    if constexpr (requires { query.prod(l, r); }) return query.prod(l, r);
    else if constexpr (requires { query.sum(l, r); }) return query.sum(l, r);
    else if constexpr (hld_directional_query<Q>) return std::invoke(query, l, r, reversed);
    else return std::invoke(query, l, r);
}
template<HldRangeQuery Q>
using HldRangeValue = std::remove_cvref_t<decltype(hld_read_range(std::declval<Q&>(), 0, 0, false))>;
struct HldAddition {
    template<class T> T operator()(T a, T b) const {
#if defined(__SIZEOF_INT128__) && (defined(__GNUC__) || defined(__clang__))
        if constexpr (std::is_same_v<T, __int128> || std::is_same_v<T, unsigned __int128>)
            return static_cast<T>(static_cast<unsigned __int128>(a) + static_cast<unsigned __int128>(b));
        else
#endif
        if constexpr (std::is_integral_v<T> && !std::is_same_v<T, bool>) {
            using U = std::make_unsigned_t<T>;
            return static_cast<T>(static_cast<U>(a) + static_cast<U>(b));
        } else return a + b;
    }
};
}
#endif

#ifndef SIRKIT_HEAVY_LIGHT_VALUES_FORWARD_DEFINED
#define SIRKIT_HEAVY_LIGHT_VALUES_FORWARD_DEFINED
template<class Range, bool Ordered = false> class HeavyLightValues;
#endif

#ifndef SIRKIT_HLD_FENWICK_ACCESS_FORWARD_DEFINED
#define SIRKIT_HLD_FENWICK_ACCESS_FORWARD_DEFINED
namespace reinsirk::detail { template<class Range> struct HldFenwickAccess; }
#endif

#ifndef SIRKIT_HEAVY_LIGHT_DECOMPOSITION_DEFINED
#define SIRKIT_HEAVY_LIGHT_DECOMPOSITION_DEFINED
class HeavyLightDecomposition {
public:
    struct Interval { int left; int right; bool reversed; };
private:
    template<class, bool> friend class HeavyLightValues;
    int root_ = -1;
    std::vector<int> parent_, depth_, component_, roots_, subtree_, heavy_, head_, index_, order_;
#ifndef SKIP_RUNTIME_CHECKS
    void vertex(int v) const {
        if (v < 0 || v >= size()) throw std::out_of_range("HLD: vertex out of range");
    }
#endif
    void prepare(const Graph& graph, int root) {
        if (graph.size() > static_cast<std::size_t>(std::numeric_limits<int>::max()))
            throw std::length_error("HLD: too many vertices");
        const int n = static_cast<int>(graph.size());
#ifndef SKIP_RUNTIME_CHECKS
        if ((n == 0 && root != 0) || (n != 0 && (root < 0 || root >= n)))
            throw std::out_of_range("HLD: root out of range");
#endif
        if (n == 0) return;
        root_ = root;
        parent_.assign(n, -2); depth_.resize(n); component_.resize(n); subtree_.assign(n, 1);
        heavy_.assign(n, -1); head_.resize(n); index_.resize(n); order_.resize(n);
        std::vector<int> stack;
        stack.reserve(n);
        // 部分木集計まではorder_を探索順の保存に使う。
        std::size_t visited_count = 0;
        const auto discover = [&](int start) {
            const int id = static_cast<int>(roots_.size()); roots_.push_back(start);
            parent_[start] = -1; component_[start] = id; stack.push_back(start);
            while (!stack.empty()) {
                const int v = stack.back(); stack.pop_back(); order_[visited_count++] = v;
#ifndef SKIP_RUNTIME_CHECKS
                bool parent_seen = false;
#endif
                for (int u : graph[v]) {
#ifndef SKIP_RUNTIME_CHECKS
                    vertex(u);
#endif
                    if (u == parent_[v]) {
#ifndef SKIP_RUNTIME_CHECKS
                        if (parent_seen) throw std::invalid_argument("HLD: parallel edge");
                        parent_seen = true;
#endif
                        continue;
                    }
#ifndef SKIP_RUNTIME_CHECKS
                    if (parent_[u] != -2) throw std::invalid_argument("HLD: input must be a forest");
#endif
                    parent_[u] = v; depth_[u] = depth_[v] + 1;
                    component_[u] = id; stack.push_back(u);
                }
            }
        };
        discover(root);
        for (int v = 0; v < n; ++v) if (parent_[v] == -2) discover(v);
        for (std::size_t i = visited_count; i != 0;) {
            const int v = order_[--i], parent = parent_[v];
            if (parent != -1) {
                subtree_[parent] += subtree_[v];
                if (heavy_[parent] == -1 || subtree_[v] > subtree_[heavy_[parent]]) heavy_[parent] = v;
            }
        }
        int position = 0;
        for (int start : roots_) {
            stack.push_back(start);
            while (!stack.empty()) {
                const int first = stack.back(); stack.pop_back();
                for (int v = first; v != -1; v = heavy_[v]) {
                    head_[v] = first; index_[v] = position; order_[position++] = v;
                    const int parent = parent_[v], heavy = heavy_[v];
                    for (int u : graph[v]) if (u != parent && u != heavy) stack.push_back(u);
                }
            }
        }
    }
    template<class Identity, class Q, class Op, class Reverse>
    auto path_product_impl(int u, int v, Identity&& identity, Q& query, Op& op, Reverse& reverse, bool edges) const {
        using S = reinsirk::detail::HldRangeValue<Q>;
        S result(std::forward<Identity>(identity));
        constexpr bool directional = reinsirk::detail::hld_directional_query<Q>;
        constexpr bool reverse_value = !std::is_same_v<std::remove_cvref_t<Reverse>, std::identity>;
        static_assert(!directional || !reverse_value, "HLD: choose directional query or reverse, not both");
        const auto consume = [&](int l, int r, bool reversed) {
            S part = reinsirk::detail::hld_read_range(query, l, r, reversed);
            if constexpr (!directional && reverse_value)
                if (reversed) part = std::invoke(reverse, std::move(part));
            result = std::invoke(op, std::move(result), std::move(part));
        };
#if defined(__clang__)
        if constexpr (!directional && !reverse_value) {
            // 可換なら区間の通行順を保存せず、その場で集計できる。
#ifndef SKIP_RUNTIME_CHECKS
            vertex(u); vertex(v);
#endif
            if (roots_.size() != 1 && component_[u] != component_[v]) {
#ifndef SKIP_RUNTIME_CHECKS
                throw std::invalid_argument("HLD: path endpoints are disconnected");
#else
                return result;
#endif
            }
            while (head_[u] != head_[v]) {
                if (index_[u] >= index_[v]) {
                    consume(index_[head_[u]], index_[u] + 1, false); u = parent_[head_[u]];
                } else {
                    consume(index_[head_[v]], index_[v] + 1, false); v = parent_[head_[v]];
                }
            }
            const int left = std::min(index_[u], index_[v]) + static_cast<int>(edges);
            const int right = std::max(index_[u], index_[v]) + 1;
            if (left < right) consume(left, right, false);
            return result;
        }
#endif
        const bool connected = for_each_path(u, v, consume, edges);
#ifndef SKIP_RUNTIME_CHECKS
        if (!connected) throw std::invalid_argument("HLD: path endpoints are disconnected");
#else
        (void)connected;
#endif

        return result;
    }
public:
    template<class Range, bool Ordered = false, class T>
    HeavyLightValues<Range, Ordered> with_values(const std::vector<T>& values) const &;
    template<class Range, bool Ordered = false, class T>
    HeavyLightValues<Range, Ordered> with_values(const std::vector<T>& values) &&;
    HeavyLightDecomposition() = default;
    explicit HeavyLightDecomposition(const Graph& graph, int root = 0) { prepare(graph, root); }
    HeavyLightDecomposition(const HeavyLightDecomposition&) = default;
    HeavyLightDecomposition(HeavyLightDecomposition&& other) noexcept { swap(other); }
    HeavyLightDecomposition& operator=(HeavyLightDecomposition other) noexcept { swap(other); return *this; }
    void swap(HeavyLightDecomposition& other) noexcept {
        std::swap(root_, other.root_); parent_.swap(other.parent_); depth_.swap(other.depth_);
        component_.swap(other.component_); roots_.swap(other.roots_); subtree_.swap(other.subtree_);
        heavy_.swap(other.heavy_); head_.swap(other.head_); index_.swap(other.index_); order_.swap(other.order_);
    }
    void clear() noexcept { HeavyLightDecomposition replacement; swap(replacement); }
    void build(const Graph& graph, int root = 0) { HeavyLightDecomposition replacement(graph, root); swap(replacement); }
    int size() const noexcept { return static_cast<int>(parent_.size()); }
    bool empty() const noexcept { return parent_.empty(); }
    int root() const noexcept { return root_; }
    int component_count() const noexcept { return static_cast<int>(roots_.size()); }
    int parent(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return parent_[v];
    }
    int depth(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return depth_[v];
    }
    int component(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return component_[v];
    }
    int root_of(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return roots_[component_[v]];
    }
    int index(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return index_[v];
    }
    int vertex_at(int i) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(i);
#endif
        return order_[i];
    }
    const std::vector<int>& order() const noexcept { return order_; }
    bool same_component(int u, int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        return component_[u] == component_[v];
    }
    bool is_ancestor(int u, int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        // 部分木区間には他の成分の頂点が入らない。
        return index_[u] <= index_[v] && index_[v] < index_[u] + subtree_[u];
    }
    std::pair<int, int> subtree_range(int v, bool edges = false) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return {index_[v] + static_cast<int>(edges), index_[v] + subtree_[v]};
    }
    int subtree_size(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return subtree_[v];
    }
    int lca(int u, int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        if (component_[u] != component_[v]) return -1;
        while (head_[u] != head_[v]) {
            if (depth_[head_[u]] > depth_[head_[v]]) u = parent_[head_[u]];
            else v = parent_[head_[v]];
        }
        return depth_[u] < depth_[v] ? u : v;
    }
    int distance(int u, int v) const {
        const int w = lca(u, v);
        return w == -1 ? -1 : (depth_[u] - depth_[w]) + (depth_[v] - depth_[w]);
    }
    int kth_ancestor(int v, std::int64_t k) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        if (k < 0 || k > depth_[v]) return -1;
        for (;;) {
            const int within = depth_[v] - depth_[head_[v]];
            if (k <= within) return order_[index_[v] - static_cast<int>(k)];
            k -= static_cast<std::int64_t>(within) + 1; v = parent_[head_[v]];
        }
    }
    int jump(int u, int v, std::int64_t k) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        if ((roots_.size() != 1 && component_[u] != component_[v]) || k < 0) return -1;
        // 同じ重鎖内では添字の差がそのまま経路長になる。
        if (head_[u] == head_[v]) {
            const int delta = index_[v] - index_[u];
            if (k > (delta >= 0 ? delta : -delta)) return -1;
            const int step = static_cast<int>(k);
            return order_[index_[u] + (delta >= 0 ? step : -step)];
        }
        if (k > static_cast<std::int64_t>(depth_[u]) + depth_[v]) return -1;
        // u側の区間内に答えがあれば、その場で返して再走査を省く。
        const int destination = v;
        while (head_[u] != head_[v]) {
            if (index_[u] >= index_[v]) {
                const int within = depth_[u] - depth_[head_[u]];
                if (k <= within) return order_[index_[u] - static_cast<int>(k)];
                k -= static_cast<std::int64_t>(within) + 1;
                u = parent_[head_[u]];
            } else v = parent_[head_[v]];
        }
        if (index_[u] >= index_[v]) {
            const int within = depth_[u] - depth_[v];
            if (k <= within) return order_[index_[u] - static_cast<int>(k)];
            k -= within;
            const int downward = depth_[destination] - depth_[v];
            return k > downward ? -1 : kth_ancestor(destination, downward - k);
        }
        const int within = depth_[v] - depth_[u];
        if (k <= within) return order_[index_[u] + static_cast<int>(k)];
        const int downward = depth_[destination] - depth_[u];
        return k > downward ? -1 : kth_ancestor(destination, downward - k);
    }
    template<class Fn>
    bool for_each_path(int u, int v, Fn&& visit, bool edges = false) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        if (roots_.size() != 1 && component_[u] != component_[v]) return false;
        std::array<Interval, std::numeric_limits<unsigned int>::digits + 1> downward;
        std::size_t count = 0;
        while (head_[u] != head_[v]) {
#if defined(__GNUC__) && !defined(__clang__)
            if (index_[u] >= index_[v]) {
#else
            if (depth_[head_[u]] >= depth_[head_[v]]) {
#endif
                visit(index_[head_[u]], index_[u] + 1, true); u = parent_[head_[u]];
            } else {
                downward[count++] = {index_[head_[v]], index_[v] + 1, false}; v = parent_[head_[v]];
            }
        }
        if (index_[u] >= index_[v]) {
            const int left = index_[v] + static_cast<int>(edges), right = index_[u] + 1;
            if (left < right) visit(left, right, true);
        } else {
            const int left = index_[u] + static_cast<int>(edges), right = index_[v] + 1;
            if (left < right) downward[count++] = {left, right, false};
        }
        while (count != 0) { const auto part = downward[--count]; visit(part.left, part.right, part.reversed); }
        return true;
    }
    std::vector<Interval> path(int u, int v, bool edges = false) const {
        std::vector<Interval> result;
        for_each_path(u, v, [&](int left, int right, bool reverse) { result.push_back({left, right, reverse}); }, edges);
        return result;
    }
    template<class T>
    std::vector<T> reorder(const std::vector<T>& values) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (values.size() != order_.size()) throw std::invalid_argument("HLD: value count mismatch");
#endif
        std::vector<T> result; result.reserve(order_.size());
        for (int v : order_) result.push_back(values[v]);
        return result;
    }
    template<class T>
    std::vector<T> restore(const std::vector<T>& ordered) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (ordered.size() != order_.size()) throw std::invalid_argument("HLD: value count mismatch");
#endif
        std::vector<T> result; result.reserve(order_.size());
        for (int v = 0; v < size(); ++v) result.push_back(ordered[index_[v]]);
        return result;
    }
    template<class Identity, reinsirk::detail::HldRangeQuery Q, class Op, class Reverse>
        requires std::is_invocable_r_v<reinsirk::detail::HldRangeValue<Q>, Op&,
                     reinsirk::detail::HldRangeValue<Q>, reinsirk::detail::HldRangeValue<Q>>
            && std::is_invocable_r_v<reinsirk::detail::HldRangeValue<Q>, Reverse&, reinsirk::detail::HldRangeValue<Q>>
            && std::is_constructible_v<reinsirk::detail::HldRangeValue<Q>, Identity&&>
            && (!reinsirk::detail::hld_directional_query<Q>
                || std::is_same_v<std::remove_cvref_t<Reverse>, std::identity>)
    auto path_prod(int u, int v, Identity&& identity, Q&& query, Op&& op, Reverse&& reverse, bool edges = false) const {
        return path_product_impl(u, v, std::forward<Identity>(identity), query, op, reverse, edges);
    }
    template<class Identity, reinsirk::detail::HldRangeQuery Q, class Op>
        requires std::is_invocable_r_v<reinsirk::detail::HldRangeValue<Q>, Op&,
                     reinsirk::detail::HldRangeValue<Q>, reinsirk::detail::HldRangeValue<Q>>
            && std::is_constructible_v<reinsirk::detail::HldRangeValue<Q>, Identity&&>
    auto path_prod(int u, int v, Identity&& identity, Q&& query, Op&& op, bool edges = false) const {
        std::identity reverse;
        return path_product_impl(u, v, std::forward<Identity>(identity), query, op, reverse, edges);
    }
    template<class Range>
        requires requires(Range& range) { range.sum(0, 0); }
            && (!requires(Range& range) { range.prod(0, 0); })
    auto path_prod(int u, int v, Range& range, bool edges = false) const {
        using S = std::remove_cvref_t<decltype(range.sum(0, 0))>;
        return path_prod(u, v, S{}, range, reinsirk::detail::HldAddition{}, edges);
    }
    template<template<class, auto, auto> class Range, class S, auto Op, auto E>
        requires requires(const Range<S, Op, E>& range) { { range.prod(0, 0) } -> std::same_as<S>; }
    S path_prod(int u, int v, const Range<S, Op, E>& range, bool edges = false) const {
        return path_prod(u, v, std::invoke(E), range, Op, edges);
    }
    template<template<class, auto, auto> class Range, class S, auto Op, auto E, class Reverse>
        requires std::is_invocable_r_v<S, Reverse&, S>
            && requires(const Range<S, Op, E>& range) { { range.prod(0, 0) } -> std::same_as<S>; }
    S path_prod(int u, int v, const Range<S, Op, E>& range, Reverse&& reverse, bool edges = false) const {
        return path_prod(u, v, std::invoke(E), range, Op, std::forward<Reverse>(reverse), edges);
    }
    template<template<class, auto, auto, class, auto, auto, auto> class Range,
             class S, auto Op, auto E, class F, auto Mapping, auto Composition, auto Id>
        requires requires(Range<S, Op, E, F, Mapping, Composition, Id>& range) { { range.prod(0, 0) } -> std::same_as<S>; }
    S path_prod(int u, int v, Range<S, Op, E, F, Mapping, Composition, Id>& range, bool edges = false) const {
        return path_prod(u, v, std::invoke(E), range, Op, edges);
    }
    template<template<class, auto, auto, class, auto, auto, auto> class Range,
             class S, auto Op, auto E, class F, auto Mapping, auto Composition, auto Id, class Reverse>
        requires std::is_invocable_r_v<S, Reverse&, S>
            && requires(Range<S, Op, E, F, Mapping, Composition, Id>& range) { { range.prod(0, 0) } -> std::same_as<S>; }
    S path_prod(int u, int v, Range<S, Op, E, F, Mapping, Composition, Id>& range, Reverse&& reverse, bool edges = false) const {
        return path_prod(u, v, std::invoke(E), range, Op, std::forward<Reverse>(reverse), edges);
    }
    template<reinsirk::detail::HldRangeQuery Q>
    auto subtree_prod(int v, Q&& query, bool edges = false) const {
        const auto [l, r] = subtree_range(v, edges);
        return reinsirk::detail::hld_read_range(query, l, r, false);
    }
    template<class Range, class F>
    void path_apply(int u, int v, Range& range, const F action, bool edges = false) const {
        const bool connected = for_each_path(u, v, [&](int l, int r, bool) { range.apply(l, r, action); }, edges);
#ifndef SKIP_RUNTIME_CHECKS
        if (!connected) throw std::invalid_argument("HLD: path endpoints are disconnected");
#else
        (void)connected;
#endif
    }
    template<class Range, class F>
    void subtree_apply(int v, Range& range, const F action, bool edges = false) const {
        const auto [l, r] = subtree_range(v, edges);
        if (l < r) range.apply(l, r, action);
    }
};
#endif

#ifndef SIRKIT_HLD_OWNED_RANGE_TRAITS_DEFINED
#define SIRKIT_HLD_OWNED_RANGE_TRAITS_DEFINED
namespace reinsirk::detail {
struct HldNoReverseRange {};
template<class Range> struct HldOwnedRangeTraits {
    using Value = HldRangeValue<Range>;
    static Value identity() { return Value{}; }
    static Value combine(Value a, Value b) { return HldAddition{}(std::move(a), std::move(b)); }
};
template<template<class, auto, auto> class Range, class S, auto Op, auto E>
struct HldOwnedRangeTraits<Range<S, Op, E>> {
    using Value = S;
    static S identity() { return std::invoke(E); }
    static S combine(S a, S b) { return std::invoke(Op, std::move(a), std::move(b)); }
};
template<template<class, auto, auto, class, auto, auto, auto> class Range,
         class S, auto Op, auto E, class F, auto Mapping, auto Composition, auto Id>
struct HldOwnedRangeTraits<Range<S, Op, E, F, Mapping, Composition, Id>> {
    using Value = S;
    static S identity() { return std::invoke(E); }
    static S combine(S a, S b) { return std::invoke(Op, std::move(a), std::move(b)); }
};
struct HldDifference {
    template<class T> T operator()(T a, T b) const {
#if defined(__SIZEOF_INT128__) && (defined(__GNUC__) || defined(__clang__))
        if constexpr (std::is_same_v<T, __int128> || std::is_same_v<T, unsigned __int128>)
            return static_cast<T>(static_cast<unsigned __int128>(a) - static_cast<unsigned __int128>(b));
        else
#endif
        if constexpr (std::is_integral_v<T> && !std::is_same_v<T, bool>) {
            using U = std::make_unsigned_t<T>;
            return static_cast<T>(static_cast<U>(a) - static_cast<U>(b));
        } else return a - b;
    }
};
}
#endif

#ifndef SIRKIT_HLD_FENWICK_ACCESS_DEFINED
#define SIRKIT_HLD_FENWICK_ACCESS_DEFINED
namespace reinsirk::detail {
template<class Range>
struct HldFenwickAccess {
    static constexpr bool enabled = [] {
        if constexpr (requires(Range& range) { typename Range::HldFenwickTag; range.sum(0, 0); }) {
            using Value = std::remove_cvref_t<decltype(std::declval<Range&>().sum(0, 0))>;
            return !std::is_floating_point_v<Value> && !std::is_same_v<Value, bool>;
        } else return false;
    }();
    static auto sum_original(Range& range, int l, int r) {
        using Value = decltype(range.sum(l, r));
        return static_cast<Value>(range.prefix_unchecked(static_cast<std::size_t>(r))
                                - range.prefix_unchecked(static_cast<std::size_t>(l)));
    }
    static auto sum_short(Range& range, int l, int r) {
        using Value = decltype(range.sum(l, r));
        if (r - l > 64) return sum_original(range, l, r);
        if (l == r) return Value{};
        auto a = static_cast<unsigned int>(l), b = static_cast<unsigned int>(r);
        const auto shared = b & ~((std::bit_floor(a ^ b) << 1) - 1U);
        typename Range::Storage left{}, right{};
        for (; b != shared; b &= b - 1U) right += range.tree_[b];
        for (; a != shared; a &= a - 1U) left += range.tree_[a];
        return static_cast<Value>(right - left);
    }
};
}
#endif

#ifndef SIRKIT_HEAVY_LIGHT_VALUES_DEFINED
#define SIRKIT_HEAVY_LIGHT_VALUES_DEFINED
template<class Range, bool Ordered>
class HeavyLightValues {
    using Traits = reinsirk::detail::HldOwnedRangeTraits<Range>;
public:
    using value_type = typename Traits::Value;
private:
    static Range make_range(const std::vector<value_type>& values) {
        if constexpr (std::is_constructible_v<Range, const std::vector<value_type>&>) return Range(values);
        else {
            static_assert(std::is_constructible_v<Range, int> && requires(Range& r, value_type x) { r.add(0, x); },
                          "HLD: Range needs a vector constructor or an int constructor and add");
            Range result(static_cast<int>(values.size()));
            for (int i = 0; i < static_cast<int>(values.size()); ++i) result.add(i, values[i]);
            return result;
        }
    }
    struct State {
        HeavyLightDecomposition layout;
        Range range;
        [[no_unique_address]] std::conditional_t<Ordered, std::optional<Range>, reinsirk::detail::HldNoReverseRange> reversed;
        State(HeavyLightDecomposition tree, std::vector<value_type> ordered)
            : layout(std::move(tree)), range(make_range(ordered)) {
            if constexpr (Ordered) { std::reverse(ordered.begin(), ordered.end()); reversed.emplace(make_range(ordered)); }
        }
    };
    std::unique_ptr<State> state_;
    const HeavyLightDecomposition& layout() const noexcept {
        if (state_) return state_->layout;
        static const HeavyLightDecomposition empty;
        return empty;
    }
    Range& range() {
#ifndef SKIP_RUNTIME_CHECKS
        if (!state_) throw std::out_of_range("HLD: empty values");
#endif
        return state_->range;
    }
    static value_type read_point(Range& r, int p) {
        if constexpr (requires { r.get(p); }) return r.get(p);
        else return r.sum(p, p + 1);
    }
    static void set_point(Range& r, int p, const value_type& value) {
        if constexpr (requires { r.set(p, value); }) r.set(p, value);
        else r.add(p, reinsirk::detail::HldDifference{}(value, read_point(r, p)));
    }
public:
    HeavyLightValues() = default;
    HeavyLightValues(const HeavyLightDecomposition& tree, const std::vector<value_type>& values) {
        auto ordered = tree.reorder(values);
        state_ = std::make_unique<State>(tree, std::move(ordered));
    }
    HeavyLightValues(HeavyLightDecomposition&& tree, const std::vector<value_type>& values) {
        auto ordered = tree.reorder(values);
        state_ = std::make_unique<State>(std::move(tree), std::move(ordered));
    }
    HeavyLightValues(const Graph& graph, const std::vector<value_type>& values, int root = 0)
        : HeavyLightValues(HeavyLightDecomposition(graph, root), values) {}
    HeavyLightValues(const HeavyLightValues& other) {
        if (other.state_) state_ = std::make_unique<State>(*other.state_);
    }
    HeavyLightValues(HeavyLightValues&&) noexcept = default;
    HeavyLightValues& operator=(HeavyLightValues other) noexcept { swap(other); return *this; }
    void swap(HeavyLightValues& other) noexcept { state_.swap(other.state_); }
    void clear() noexcept { state_.reset(); }
    void build(const Graph& graph, const std::vector<value_type>& values, int root = 0) {
        HeavyLightValues replacement(graph, values, root); swap(replacement);
    }
    int size() const noexcept { return layout().size(); }
    bool empty() const noexcept { return layout().empty(); }
    int root() const noexcept { return layout().root(); }
    int component_count() const noexcept { return layout().component_count(); }
    int parent(int v) const { return layout().parent(v); }
    int depth(int v) const { return layout().depth(v); }
    int component(int v) const { return layout().component(v); }
    int root_of(int v) const { return layout().root_of(v); }
    int index(int v) const { return layout().index(v); }
    int vertex_at(int p) const { return layout().vertex_at(p); }
    const std::vector<int>& order() const noexcept { return layout().order(); }
    bool same_component(int u, int v) const { return layout().same_component(u, v); }
    bool is_ancestor(int u, int v) const { return layout().is_ancestor(u, v); }
    auto subtree_range(int v, bool edges = false) const { return layout().subtree_range(v, edges); }
    int subtree_size(int v) const { return layout().subtree_size(v); }
    int lca(int u, int v) const { return layout().lca(u, v); }
    int distance(int u, int v) const { return layout().distance(u, v); }
    int kth_ancestor(int v, std::int64_t k) const { return layout().kth_ancestor(v, k); }
    int jump(int u, int v, std::int64_t k) const { return layout().jump(u, v, k); }
    template<class Fn> bool for_each_path(int u, int v, Fn&& fn, bool edges = false) const {
        return layout().for_each_path(u, v, std::forward<Fn>(fn), edges);
    }
    auto path(int u, int v, bool edges = false) const { return layout().path(u, v, edges); }
    template<class T> std::vector<T> reorder(const std::vector<T>& values) const { return layout().reorder(values); }
    template<class T> std::vector<T> restore(const std::vector<T>& values) const { return layout().restore(values); }
    value_type get(int v) requires (requires(Range& r) { r.get(0); } || requires(Range& r) { r.sum(0, 1); }) {
        const int p = layout().index(v); return read_point(range(), p);
    }
    void set(int v, const value_type value)
        requires (requires(Range& r, value_type x) { r.set(0, x); }
               || requires(Range& r, value_type x) { r.add(0, x); x - x; }) {
        const int p = layout().index(v); set_point(range(), p, value);
        if constexpr (Ordered) set_point(*state_->reversed, size() - 1 - p, value);
    }
    void add(int v, const value_type delta) requires requires(Range& r, value_type x) { r.add(0, x); } {
        const int p = layout().index(v); range().add(p, delta);
        if constexpr (Ordered) state_->reversed->add(size() - 1 - p, delta);
    }
    template<class F> void apply(int v, const F action) requires requires(Range& r, const F& f) { r.apply(0, f); } {
        const int p = layout().index(v); range().apply(p, action);
        if constexpr (Ordered) state_->reversed->apply(size() - 1 - p, action);
    }
    value_type path_prod(int u, int v, bool edges = false) {
        auto& forward = range();
        if constexpr (!Ordered) {
            using Access = reinsirk::detail::HldFenwickAccess<Range>;
            if constexpr (Access::enabled) {
                const auto& tree = state_->layout;
                if (tree.size() > 4096) {
#ifndef SKIP_RUNTIME_CHECKS
                    tree.vertex(u); tree.vertex(v);
#endif
                    if (tree.head_[u] == tree.head_[v]) {
                        const int l = std::min(tree.index_[u], tree.index_[v]) + static_cast<int>(edges);
                        const int r = std::max(tree.index_[u], tree.index_[v]) + 1;
                        return l < r ? Access::sum_original(forward, l, r) : value_type{};
                    }
                    return tree.path_prod(u, v, value_type{}, [&](int l, int r) {
                        return Access::sum_short(forward, l, r);
                    }, reinsirk::detail::HldAddition{}, edges);
                }
            }
            return layout().path_prod(u, v, forward, edges);
        }
#if defined(__GNUC__) && !defined(__clang__)
        else if constexpr (std::is_trivially_copyable_v<value_type> && !std::is_floating_point_v<value_type> && sizeof(value_type) <= 32) {
            const auto& tree = state_->layout;
#ifndef SKIP_RUNTIME_CHECKS
            tree.vertex(u); tree.vertex(v);
#endif
            if (tree.roots_.size() != 1 && tree.component_[u] != tree.component_[v]) {
#ifndef SKIP_RUNTIME_CHECKS
                throw std::invalid_argument("HLD: path endpoints are disconnected");
#else
                return Traits::identity();
#endif
            }
            if (tree.head_[u] == tree.head_[v]) {
                const int l = std::min(tree.index_[u], tree.index_[v]) + static_cast<int>(edges);
                const int r = std::max(tree.index_[u], tree.index_[v]) + 1;
                if (l >= r) return Traits::identity();
                return tree.index_[u] >= tree.index_[v]
                    ? reinsirk::detail::hld_read_range(*state_->reversed, tree.size() - r, tree.size() - l, false)
                    : reinsirk::detail::hld_read_range(forward, l, r, false);
            }
            value_type prefix = Traits::identity();
            std::optional<value_type> suffix;
            const auto append_left = [&](int l, int r) {
                auto part = reinsirk::detail::hld_read_range(*state_->reversed, tree.size() - r, tree.size() - l, false);
                prefix = Traits::combine(std::move(prefix), std::move(part));
            };
            const auto prepend_right = [&](int l, int r) {
                auto part = reinsirk::detail::hld_read_range(forward, l, r, false);
                if (suffix) suffix.emplace(Traits::combine(std::move(part), std::move(*suffix)));
                else suffix.emplace(std::move(part));
            };
            while (tree.head_[u] != tree.head_[v]) {
#if defined(__GNUC__) && !defined(__clang__)
                if (tree.index_[u] >= tree.index_[v]) {
#else
                if (tree.depth_[tree.head_[u]] >= tree.depth_[tree.head_[v]]) {
#endif
                    append_left(tree.index_[tree.head_[u]], tree.index_[u] + 1);
                    u = tree.parent_[tree.head_[u]];
                } else {
                    prepend_right(tree.index_[tree.head_[v]], tree.index_[v] + 1);
                    v = tree.parent_[tree.head_[v]];
                }
            }
            const int l = std::min(tree.index_[u], tree.index_[v]) + static_cast<int>(edges);
            const int r = std::max(tree.index_[u], tree.index_[v]) + 1;
            if (l < r) {
                if (tree.index_[u] >= tree.index_[v]) append_left(l, r);
                else prepend_right(l, r);
            }
            return suffix ? Traits::combine(std::move(prefix), std::move(*suffix)) : std::move(prefix);
        }
#endif
        else return layout().path_prod(u, v, Traits::identity(), [&](int l, int r, bool reverse) {
            return reverse ? reinsirk::detail::hld_read_range(*state_->reversed, size() - r, size() - l, false)
                           : reinsirk::detail::hld_read_range(forward, l, r, false);
        }, Traits::combine, edges);
    }
    value_type subtree_prod(int v, bool edges = false) { return layout().subtree_prod(v, range(), edges); }
    template<class F> void path_apply(int u, int v, const F action, bool edges = false)
        requires requires(Range& r, const F& f) { r.apply(0, 0, f); } {
        if constexpr (!Ordered) layout().path_apply(u, v, range(), action, edges);
        else {
            auto& forward = range();
            const bool connected = layout().for_each_path(u, v, [&](int l, int r, bool) {
                forward.apply(l, r, action); state_->reversed->apply(size() - r, size() - l, action);
            }, edges);
#ifndef SKIP_RUNTIME_CHECKS
            if (!connected) throw std::invalid_argument("HLD: path endpoints are disconnected");
#else
            (void)connected;
#endif
        }
    }
    template<class F> void subtree_apply(int v, const F action, bool edges = false)
        requires requires(Range& r, const F& f) { r.apply(0, 0, f); } {
        const auto [l, r] = layout().subtree_range(v, edges);
        if (l < r) { range().apply(l, r, action); if constexpr (Ordered) state_->reversed->apply(size() - r, size() - l, action); }
    }
    std::vector<value_type> values() {
        if (!state_) return {};
        if constexpr (requires(Range& r) { r.values(); }) return layout().restore(range().values());
        else {
            std::vector<value_type> result; result.reserve(size());
            for (int v = 0; v < size(); ++v) result.push_back(get(v));
            return result;
        }
    }
};

template<class Range, bool Ordered, class T>
HeavyLightValues<Range, Ordered> HeavyLightDecomposition::with_values(const std::vector<T>& values) const & {
    return HeavyLightValues<Range, Ordered>(*this, values);
}
template<class Range, bool Ordered, class T>
HeavyLightValues<Range, Ordered> HeavyLightDecomposition::with_values(const std::vector<T>& values) && {
    return HeavyLightValues<Range, Ordered>(std::move(*this), values);
}

#endif

// SPDX-License-Identifier: CC0-1.0
// 参考（データ構造・検証問題）: https://nyaannyaan.github.io/library/data-structure/binary-indexed-tree.hpp
// 参考（公開API）: https://atcoder.github.io/ac-library/production/document_ja/fenwicktree.html
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/fenwick_tree.md
//
// API一覧
// [fenwick_tree<T>]
// fenwick_tree()/fenwick_tree(int n)/fenwick_tree(vector<T>): 空列/n要素の0/列から構築。O(n+1)時間・領域。
// add(int p,T x): 点加算。sum(int l,int r): 半開区間[l,r)の和をT値で返す。O(log(n+1))、空区間はT{}。
// 点添字は0<=p<size()、区間は0<=l<=r<=size()。
// ACL形式の公開APIをグローバルに定義する。bool以外の整数は内部を符号なしにして型幅のmod 2^bitで計算する。
// その他のTはT{}が単位元の可換加法群とし、加減算・コピーをO(1)とする。要素数はintの範囲内。
// size()/empty(): 要素数/空か、O(1)。get(int p)/set(int p,T value): 点取得/代入、O(log(n+1))。
// lower_bound(target)/upper_bound(target): sum(0,i+1)>=target/>targetとなる最小int添字、なければsize()。O(log(n+1))。
// 境界探索は全要素が非負で、途中の和がTに収まり、加算と順序が整合すること。全要素の検査はしない。
// values(): 列を復元して返す。O(n+1)時間・追加O(n)。reset(int n)/reset(): n要素/現在の長さを0にする。O(旧n+n+1)。
// clear()/swap(other): 空にして容量保持/交換。O(旧n+1)/O(1)。コピーは独立、移動元は空として使える。
// 添字・区間は既定で検査しSKIP_RUNTIME_CHECKSで除く。容量・添字のオーバーフロー対策は残す。

#include <algorithm>
#include <bit>
#include <cstddef>
#include <limits>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

#ifndef SIRKIT_HLD_FENWICK_ACCESS_FORWARD_DEFINED
#define SIRKIT_HLD_FENWICK_ACCESS_FORWARD_DEFINED
namespace reinsirk::detail { template<class Range> struct HldFenwickAccess; }
#endif

#ifndef SIRKIT_FENWICK_STORAGE_TYPE_DEFINED
#define SIRKIT_FENWICK_STORAGE_TYPE_DEFINED
namespace reinsirk::detail {
template<class T, bool = std::is_integral_v<T> && !std::is_same_v<T, bool>>
struct FenwickStorage { using type = T; };
template<class T>
struct FenwickStorage<T, true> { using type = std::make_unsigned_t<T>; };
#if defined(__SIZEOF_INT128__)
template<> struct FenwickStorage<__int128> { using type = unsigned __int128; };
template<> struct FenwickStorage<unsigned __int128> { using type = unsigned __int128; };
#endif
}
#endif

#ifndef SIRKIT_FENWICK_TREE_DEFINED
#define SIRKIT_FENWICK_TREE_DEFINED
template<class T>
class fenwick_tree {
    using HldFenwickTag = void;
    template<class> friend struct reinsirk::detail::HldFenwickAccess;
    using Storage = typename reinsirk::detail::FenwickStorage<T>::type;
    std::vector<Storage> tree_;
    static decltype(auto) to_storage(const T& value) {
        if constexpr (std::is_same_v<T, Storage>) return (value);
        else return static_cast<Storage>(value);
    }
    static decltype(auto) from_storage(Storage& value) {
        if constexpr (std::is_same_v<T, Storage>) return (value);
        else return static_cast<T>(value);
    }
    static std::size_t checked_size(int n) {
#ifndef SKIP_RUNTIME_CHECKS
        if (n < 0) throw std::invalid_argument("fenwick_tree: negative size");
#endif
        return static_cast<std::size_t>(n);
    }
    static std::size_t storage_size(std::size_t n) {
        if (n > static_cast<std::size_t>(std::numeric_limits<int>::max())
            || n + 1 > std::vector<Storage>{}.max_size())
            throw std::length_error("fenwick_tree: size");
        return n == 0 ? 0 : n + 1;
    }
    static std::size_t lowbit(std::size_t x) noexcept { return x & (~x + 1); }
    void check_index(int i) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (i < 0 || i >= size()) throw std::out_of_range("fenwick_tree: index");
#else
        (void)i;
#endif
    }
    void check_range(int l, int r) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (l < 0 || l > r || r > size()) throw std::out_of_range("fenwick_tree: range");
#else
        (void)l; (void)r;
#endif
    }
    Storage prefix_unchecked(std::size_t r) const {
        Storage result{};
        for (; r; r -= lowbit(r)) result += tree_[r];
        return result;
    }
    Storage get_unchecked(std::size_t i) const {
        auto node = i + 1;
        Storage result = tree_[node];
        const auto begin = node - lowbit(node);
        for (--node; node > begin; node -= lowbit(node)) result -= tree_[node];
        return result;
    }
    void add_unchecked(std::size_t i, const Storage& delta) {
        const auto n = static_cast<std::size_t>(size());
        for (++i; i <= n;) {
            tree_[i] += delta;
            const auto step = lowbit(i);
            if (step > n - i) break;
            i += step;
        }
    }
public:
    fenwick_tree() = default;
    explicit fenwick_tree(int n) : tree_(storage_size(checked_size(n)), Storage{}) {}
    template<class Values> requires std::is_same_v<Values, std::vector<T>>
    explicit fenwick_tree(const Values& values) : tree_(storage_size(values.size()), Storage{}) {
        const auto n = values.size();
        for (std::size_t i = 1; i <= n; ++i) {
            tree_[i] += to_storage(values[i - 1]);
            const auto step = lowbit(i);
            if (step <= n - i) tree_[i + step] += tree_[i];
        }
    }
    fenwick_tree(const fenwick_tree&) = default;
    fenwick_tree& operator=(const fenwick_tree&) = default;
    fenwick_tree(fenwick_tree&& other) noexcept : tree_(std::move(other.tree_)) { other.tree_.clear(); }
    fenwick_tree& operator=(fenwick_tree&& other) noexcept {
        if (this != &other) { tree_ = std::move(other.tree_); other.tree_.clear(); }
        return *this;
    }
    int size() const noexcept { return tree_.empty() ? 0 : static_cast<int>(tree_.size() - 1); }
    bool empty() const noexcept { return size() == 0; }
    void add(int i, T delta) {
        check_index(i);
        add_unchecked(static_cast<std::size_t>(i), to_storage(delta));
    }
    T get(int i) const { check_index(i); return static_cast<T>(get_unchecked(static_cast<std::size_t>(i))); }
    void set(int i, T value) {
        check_index(i);
        const Storage delta = to_storage(value) - get_unchecked(static_cast<std::size_t>(i));
        add_unchecked(static_cast<std::size_t>(i), delta);
    }
    T sum(int l, int r) {
        check_range(l, r);
        return static_cast<T>(prefix_unchecked(static_cast<std::size_t>(r)) - prefix_unchecked(static_cast<std::size_t>(l)));
    }
    int lower_bound(const T& target) const {
        if (!(T{} < target)) return 0;
        const auto n = static_cast<std::size_t>(size());
        std::size_t index = 0;
        Storage current{};
        for (auto jump = std::bit_floor(n); jump; jump >>= 1) {
            if (jump <= n - index) {
                const auto next = index + jump;
                Storage candidate = current + tree_[next];
                if (from_storage(candidate) < target) { current = std::move(candidate); index = next; }
            }
        }
        return static_cast<int>(index);
    }
    int upper_bound(const T& target) const {
        if (target < T{}) return 0;
        const auto n = static_cast<std::size_t>(size());
        std::size_t index = 0;
        Storage current{};
        for (auto jump = std::bit_floor(n); jump; jump >>= 1) {
            if (jump <= n - index) {
                const auto next = index + jump;
                Storage candidate = current + tree_[next];
                if (!(target < from_storage(candidate))) { current = std::move(candidate); index = next; }
            }
        }
        return static_cast<int>(index);
    }
    std::vector<T> values() const {
        if (tree_.empty()) return {};
        std::vector<T> result(tree_.begin() + 1, tree_.end());
        const auto n = static_cast<std::size_t>(size());
        for (auto i = n; i; --i) {
            const auto step = lowbit(i);
            if (step <= n - i) {
                if constexpr (std::is_same_v<T, Storage>) result[i + step - 1] -= result[i - 1];
                else {
                    const Storage difference = static_cast<Storage>(result[i + step - 1]) - static_cast<Storage>(result[i - 1]);
                    result[i + step - 1] = static_cast<T>(difference);
                }
            }
        }
        return result;
    }
    void reset(int n) {
        std::vector<Storage> replacement(storage_size(checked_size(n)), Storage{});
        tree_.swap(replacement);
    }
    void reset() { std::fill(tree_.begin(), tree_.end(), Storage{}); }
    void clear() noexcept { tree_.clear(); }
    void swap(fenwick_tree& other) noexcept { tree_.swap(other.tree_); }
};
#endif

// SPDX-License-Identifier: CC0-1.0
// 参考（モノイドと区間積）: https://info.atcoder.jp/entry/algorithm_lectures/range_query_monoid_design
// API仕様: https://atcoder.github.io/ac-library/production/document_ja/segtree.html
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/segment_tree.md
//
// API一覧
// [segtree<S, op, e>（ACL形式、グローバルに定義）]
// segtree()/segtree(int n)/segtree(vector<S>): 空列/n個の単位元/列から構築。0<=n<=INT_MAX、O(n+1)時間・領域。
// S op(S,S)は結合的、S e()は左右の単位元。同じ呼び出し形式の関数オブジェクトも可。演算/コピーはO(1)。
// 点添字は0<=p<size()、区間は0<=l<=r<=size()の半開区間。
// set(int p,S x): 点代入、O(log(n+1))。get(int p): 点のS値、O(1)。prod(int l,int r): 左からの区間積、O(log(n+1))。
// all_prod(): 全積のS値、O(1)。空区間・空列の積はe()。積は非可換でもよい。
// max_right<pred>(int l)/min_left<pred>(int r): bool pred(S)を使う境界探索。述語を第2引数に渡す形式も可。戻り値はint、O(log(n+1))。
// 探索はpred(e())==trueで、区間を延ばすと真から偽へ一度だけ変化すること。述語に副作用を持たせない。
// [追加機能]
// size()/empty(): intの要素数/空か、O(1)。transform(int p,f): 点をf(現在値)へ更新、O(log(n+1))。
// values(): 列のコピー、O(n+1)。assign(vector<S>)/reset(int n)/reset(): 列/n個/現在の長さの単位元へ再構築、O(旧n+n+1)。
// clear()/swap(other): 容量を保持して空へ/交換、O(旧n+1)/O(1)。コピーは独立、移動元は空。値の演算等が投げる場合は内容の強い保証なし。

#include <algorithm>
#include <bit>
#include <cstddef>
#include <functional>
#include <limits>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

#ifndef SIRKIT_SEGMENT_TREE_DEFINED
#define SIRKIT_SEGMENT_TREE_DEFINED
template<class S, auto op, auto e>
class segtree {
    static_assert(std::is_invocable_r_v<S, decltype(op), S, S>, "segtree: op(S,S) must return S");
    static_assert(std::is_invocable_r_v<S, decltype(e)>, "segtree: e() must return S");
    S identity_;
    std::size_t n_ = 0, base_ = 1;
    std::vector<S> data_;
    static std::size_t leaf_base(std::size_t n) {
        if (n == 0) return 1;
        const auto limit = std::vector<S>{}.max_size() / 2;
        std::size_t base = 1;
        while (base < n) {
            if (base > limit / 2) throw std::length_error("segtree: size");
            base *= 2;
        }
        if (base > limit) throw std::length_error("segtree: size");
        return base;
    }
    static std::size_t checked_size(int n) {
#ifndef SKIP_RUNTIME_CHECKS
        if (n < 0) throw std::invalid_argument("segtree: negative size");
#endif
        return static_cast<std::size_t>(n);
    }
    static int vector_size(const std::vector<S>& values) {
        if (values.size() > static_cast<std::size_t>(std::numeric_limits<int>::max()))
            throw std::length_error("segtree: int size overflow");
        return static_cast<int>(values.size());
    }
    void check_index(int i) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (i < 0 || static_cast<std::size_t>(i) >= n_) throw std::out_of_range("segtree: index");
#else
        (void)i;
#endif
    }
    void check_range(int l, int r) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (l < 0 || l > r || static_cast<std::size_t>(r) > n_) throw std::out_of_range("segtree: range");
#else
        (void)l; (void)r;
#endif
    }
    static unsigned aligned_node(unsigned value) {
        if (value == 0) std::unreachable();
        return value >> std::countr_zero(value);
    }
    void rebuild() {
        for (auto p = base_; p > 1;) {
            --p;
            data_[p] = std::invoke(op, data_[2 * p], data_[2 * p + 1]);
        }
    }
    void update_carried_ancestors(std::size_t p) {
        if (p <= 1) return;
        S value = std::as_const(data_)[p];
        while (p > 1) {
            const S sibling = std::as_const(data_)[p ^ 1];
            const S left = (p & 1) ? sibling : value;
            const S right = (p & 1) ? value : sibling;
            value = std::invoke(op, left, right);
            p >>= 1;
            data_[p] = std::as_const(value);
        }
    }
    void update_ancestors(std::size_t p) {
        if constexpr (std::is_trivially_copyable_v<S> && std::is_copy_constructible_v<S> &&
                      std::is_copy_assignable_v<S> && sizeof(S) <= 16 &&
                      std::is_invocable_r_v<S, decltype(op), const S&, const S&>) {
#if defined(__clang__)
            if constexpr (sizeof(S) > 8) {
                // 照会を含む呼び出し側のコードが膨らむのを抑える。
                [[clang::noinline]] update_carried_ancestors(p);
                return;
            }
#endif
            update_carried_ancestors(p);
        } else {
            for (p >>= 1; p; p >>= 1) data_[p] = std::invoke(op, data_[2 * p], data_[2 * p + 1]);
        }
    }
public:
    segtree() : segtree(0) {}
    explicit segtree(int n)
        : identity_(std::invoke(e)), n_(checked_size(n)), base_(leaf_base(n_)),
          data_(n_ ? 2 * base_ : 0, identity_) {}
    explicit segtree(const std::vector<S>& values) : segtree(vector_size(values)) {
        if (!n_) return;
        std::copy(values.begin(), values.end(), data_.begin() + base_);
        rebuild();
    }
    segtree(const segtree&) = default;
    segtree& operator=(const segtree& other) {
        if (this != &other) { segtree replacement(other); swap(replacement); }
        return *this;
    }
    segtree(segtree&& other)
        : identity_(other.identity_), n_(other.n_), base_(other.base_), data_(std::move(other.data_)) {
        other.n_ = 0; other.base_ = 1; other.data_.clear();
    }
    segtree& operator=(segtree&& other) {
        if (this != &other) { segtree replacement(std::move(other)); swap(replacement); }
        return *this;
    }
    int size() const noexcept { return static_cast<int>(n_); }
    bool empty() const noexcept { return n_ == 0; }
    S get(int i) const { check_index(i); return data_[base_ + static_cast<std::size_t>(i)]; }
    void set(int i, S value) {
        check_index(i);
        const auto p = base_ + static_cast<std::size_t>(i);
        data_[p] = std::move(value);
        update_ancestors(p);
    }
    template<class F> void transform(int i, F&& f) {
        check_index(i);
        const auto p = base_ + static_cast<std::size_t>(i);
        data_[p] = std::invoke(std::forward<F>(f), std::as_const(data_)[p]);
        update_ancestors(p);
    }
    S prod(int l, int r) const {
        check_range(l, r);
        if (l == r) return identity_;
        // n<=INT_MAXなので葉番号はunsignedに収まり、両端は常に正。
        unsigned first = static_cast<unsigned>(base_) + static_cast<unsigned>(l);
        unsigned last = static_cast<unsigned>(base_) + static_cast<unsigned>(r);
        auto step = first & (~first + 1);
        if (step > last - first) {
            // firstの整列幅より残りが短ければ、右端の下位bitを落としてfirstへ戻れる。
            S result = data_[aligned_node(last) - 1];
            last -= last & (~last + 1);
            while (first < last) {
                result = std::invoke(op, data_[aligned_node(last) - 1], result);
                last -= last & (~last + 1);
            }
            return result;
        }
        // 左から最大の整列ブロックを選ぶ。最初は節点をコピーし、単位元との積を省く。
        S left = data_[aligned_node(first)];
        first += step;
        if (first == last) return left;
        // 短い残区間では分割点の計算を省く。
        if (last - first <= 32) {
            while (first < last && (step = first & (~first + 1)) <= last - first) {
                left = std::invoke(op, left, data_[aligned_node(first)]);
                first += step;
            }
            if (first == last) return left;
            S right = data_[aligned_node(last) - 1];
            last -= last & (~last + 1);
            while (first < last) {
                right = std::invoke(op, data_[aligned_node(last) - 1], right);
                last -= last & (~last + 1);
            }
            return std::invoke(op, left, right);
        }
        // 左走査が止まる整列境界を先に求め、独立な左右の積を交互に進める。
        const unsigned stop = last & (0U - std::bit_floor((first - 1) ^ (last - 1)));
        if (stop == last) {
            while (first < stop) {
                left = std::invoke(op, left, data_[aligned_node(first)]);
                first += first & (~first + 1);
            }
            return left;
        }
        S right = data_[aligned_node(last) - 1];
        last -= last & (~last + 1);
        while (first < stop && last > stop) {
            left = std::invoke(op, left, data_[aligned_node(first)]);
            first += first & (~first + 1);
            right = std::invoke(op, data_[aligned_node(last) - 1], right);
            last -= last & (~last + 1);
        }
        while (first < stop) {
            left = std::invoke(op, left, data_[aligned_node(first)]);
            first += first & (~first + 1);
        }
        while (last > stop) {
            right = std::invoke(op, data_[aligned_node(last) - 1], right);
            last -= last & (~last + 1);
        }
        return std::invoke(op, left, right);
    }
    S all_prod() const { return n_ ? data_[1] : identity_; }
    template<bool (*Pred)(S)> int max_right(int l) const { return max_right(l, Pred); }
    template<class Pred> int max_right(int l, Pred pred) const {
        check_range(l, l);
#ifndef SKIP_RUNTIME_CHECKS
        if (!std::invoke(pred, identity_)) throw std::invalid_argument("segtree: predicate(e())");
#endif
        if (static_cast<std::size_t>(l) == n_) return size();
        S accumulated = identity_;
        auto node = base_ + static_cast<std::size_t>(l);
        while (true) {
            while (!(node & 1)) node >>= 1;
            S candidate = std::invoke(op, accumulated, data_[node]);
            if (!std::invoke(pred, candidate)) {
                while (node < base_) {
                    node *= 2;
                    S next = std::invoke(op, accumulated, data_[node]);
                    if (std::invoke(pred, next)) { accumulated = std::move(next); ++node; }
                }
                return static_cast<int>(std::min(n_, node - base_));
            }
            accumulated = std::move(candidate);
            ++node;
            if ((node & (node - 1)) == 0) return size();
        }
    }
    template<bool (*Pred)(S)> int min_left(int r) const { return min_left(r, Pred); }
    template<class Pred> int min_left(int r, Pred pred) const {
        check_range(r, r);
#ifndef SKIP_RUNTIME_CHECKS
        if (!std::invoke(pred, identity_)) throw std::invalid_argument("segtree: predicate(e())");
#endif
        if (r == 0) return 0;
        S accumulated = identity_;
        auto node = base_ + static_cast<std::size_t>(r);
        while (true) {
            --node;
            while (node > 1 && (node & 1)) node >>= 1;
            S candidate = std::invoke(op, data_[node], accumulated);
            if (!std::invoke(pred, candidate)) {
                while (node < base_) {
                    node = 2 * node + 1;
                    S next = std::invoke(op, data_[node], accumulated);
                    if (std::invoke(pred, next)) { accumulated = std::move(next); --node; }
                }
                return static_cast<int>(node + 1 - base_);
            }
            accumulated = std::move(candidate);
            if ((node & (node - 1)) == 0) return 0;
        }
    }
    std::vector<S> values() const {
        if (!n_) return {};
        return std::vector<S>(data_.begin() + base_, data_.begin() + base_ + n_);
    }
    void assign(const std::vector<S>& values) { segtree replacement(values); swap(replacement); }
    void reset(int n) { segtree replacement(n); swap(replacement); }
    void reset() { std::fill(data_.begin(), data_.end(), identity_); }
    void clear() noexcept { data_.clear(); n_ = 0; base_ = 1; }
    void swap(segtree& other) noexcept(std::is_nothrow_swappable_v<S>) {
        using std::swap;
        swap(identity_, other.identity_);
        swap(n_, other.n_); swap(base_, other.base_); data_.swap(other.data_);
    }
};
#endif

}
// SPDX-License-Identifier: CC0-1.0
// ベンチマーク専用。Verifyのmainや入出力を変更しない。
struct Affine { std::uint32_t a,b; };
constexpr std::uint64_t modulus=998244353;
Affine append_affine(Affine first,Affine second){return {
 static_cast<std::uint32_t>(std::uint64_t(second.a)*first.a%modulus),
 static_cast<std::uint32_t>((std::uint64_t(second.a)*first.b+second.b)%modulus)};}
Affine identity_affine(){return {1,0};}
#if defined(MICRO_COMPOSITE)
using BaseTree=baseline::HeavyLightValues<baseline::segtree<Affine,append_affine,identity_affine>,true>;
using CandidateTree=candidate::HeavyLightValues<candidate::segtree<Affine,append_affine,identity_affine>,true>;
using Value=Affine;
#elif defined(MICRO_POINT)
using BaseTree=baseline::fenwick_tree<std::int64_t>;
using CandidateTree=candidate::fenwick_tree<std::int64_t>;
using Value=std::int64_t;
#else
using BaseTree=baseline::HeavyLightValues<baseline::fenwick_tree<std::int64_t>>;
using CandidateTree=candidate::HeavyLightValues<candidate::fenwick_tree<std::int64_t>>;
using Value=std::int64_t;
#endif
struct Query {int type,u,v;std::int64_t x,y;};
constexpr std::size_t block_size=512;
struct BlockResult {
 std::size_t rep,begin,end,count;
 std::array<int,4> order;
 std::array<std::uint64_t,4> ns;
 std::uint64_t checksum;
};
std::uint64_t cpu_ns(){timespec ts{};if(clock_gettime(CLOCK_THREAD_CPUTIME_ID,&ts)!=0)throw std::runtime_error("clock_gettime failed");return std::uint64_t(ts.tv_sec)*1000000000+ts.tv_nsec;}
std::string quoted_json(std::string_view value){
 std::string result="\"";constexpr char digits[]="0123456789abcdef";
 for(unsigned char c:value){if(c=='"'||c=='\\'){result+='\\';result+=char(c);}else if(c<32){result+="\\u00";result+=digits[c>>4];result+=digits[c&15];}else result+=char(c);}return result+'"';
}
template<class Tree>
#if defined(__GNUC__) && !defined(__clang__)
__attribute__((noinline,noclone))
#elif defined(__clang__)
__attribute__((noinline))
#endif
std::size_t consume(Tree& tree,const std::vector<Query>& queries,std::size_t begin,std::size_t end,std::array<std::uint64_t,block_size>& output){
 std::size_t count=0;
 for(std::size_t i=begin;i<end;++i){const auto& q=queries[i];
#if defined(MICRO_COMPOSITE)
  if(q.type==0)tree.set(q.u,Affine{static_cast<std::uint32_t>(q.x),static_cast<std::uint32_t>(q.y)});
  else{const auto f=tree.path_prod(q.u,q.v);output[count++]=(std::uint64_t(f.a)*static_cast<std::uint64_t>(q.x)+f.b)%modulus;}
#elif defined(MICRO_POINT)
  if(q.type==0)tree.add(q.u,q.x);else output[count++]=static_cast<std::uint64_t>(tree.sum(q.u,q.v));
#else
  if(q.type==0)tree.add(q.u,q.x);else output[count++]=static_cast<std::uint64_t>(tree.path_prod(q.u,q.v));
#endif
 }
 return count;
}
std::uint64_t checksum(const std::array<std::uint64_t,block_size>& result,std::size_t count){std::uint64_t h=1469598103934665603ULL;for(std::size_t i=0;i<count;++i){h^=result[i];h*=1099511628211ULL;}return h^count;}
double median(std::vector<double> values){if(values.empty())return 1;std::sort(values.begin(),values.end());const auto m=values.size()/2;return values.size()%2?values[m]:(values[m-1]+values[m])/2;}
int main(int argc,char** argv){try{
 if(argc<2||argc>3)throw std::invalid_argument("usage: micro INPUT_PATH [REPS]");
 const int reps=argc==3?std::stoi(argv[2]):1;if(reps<1)throw std::invalid_argument("positive REPS required");
 std::ifstream in(argv[1]);if(!in)throw std::runtime_error("cannot open input");
 int n{},q{};in>>n>>q;if(!in||n<0||q<0)throw std::runtime_error("bad header");
 std::vector<Value> values(n);
#if defined(MICRO_COMPOSITE)
 for(auto& v:values)in>>v.a>>v.b;
#else
 for(auto& v:values)in>>v;
#endif
 #if !defined(MICRO_POINT)
 std::vector<std::vector<int>> graph(n);
 for(int i=1;i<n;++i){int u{},v{};in>>u>>v;graph[u].push_back(v);graph[v].push_back(u);}
#endif
 std::vector<Query> queries(q);
 for(auto& x:queries){in>>x.type;if(x.type==0){in>>x.u>>x.x;
#if defined(MICRO_COMPOSITE)
 in>>x.y;
#endif
 }else{in>>x.u>>x.v;
#if defined(MICRO_COMPOSITE)
 in>>x.x;
#endif
 }}if(!in)throw std::runtime_error("truncated input");in.close();
 std::vector<BlockResult> results;results.reserve(std::size_t(reps)*(queries.size()+block_size-1)/block_size);
 std::array<std::uint64_t,4> totals{};std::array<std::uint64_t,4> final_checksums{};std::size_t outputs_checked=0;
 std::mt19937 rng(202611055u);std::vector<double> candidate_ratios,control_ratios,candidate_control_ratios;long double candidate_logs=0,control_logs=0,candidate_control_logs=0;
 for(int rep=0;rep<reps;++rep){
#if defined(MICRO_POINT)
  BaseTree base(values);CandidateTree test(values);BaseTree control(values);CandidateTree test_control(values);
#else
  BaseTree base(graph,values);CandidateTree test(graph,values);BaseTree control(graph,values);CandidateTree test_control(graph,values);
#endif
  for(std::size_t begin=0;begin<queries.size();begin+=block_size){
   const auto end=std::min(begin+block_size,queries.size());BlockResult row{static_cast<std::size_t>(rep),begin,end,0,{0,1,2,3},{},0};std::shuffle(row.order.begin(),row.order.end(),rng);
   std::array<std::array<std::uint64_t,block_size>,4> output{};std::array<std::size_t,4> counts{};
   for(int label:row.order){const auto start=cpu_ns();
    switch(label){case 0:counts[0]=consume(base,queries,begin,end,output[0]);break;case 1:counts[1]=consume(control,queries,begin,end,output[1]);break;case 2:counts[2]=consume(test,queries,begin,end,output[2]);break;default:counts[3]=consume(test_control,queries,begin,end,output[3]);break;}
    row.ns[label]=cpu_ns()-start;totals[label]+=row.ns[label];
   }
   for(int label=1;label<4;++label)if(counts[0]!=counts[label]||!std::equal(output[0].begin(),output[0].begin()+counts[0],output[label].begin()))throw std::runtime_error("base/control/candidate/candidate_control output mismatch atquery "+std::to_string(begin));
   row.count=counts[0];row.checksum=checksum(output[0],counts[0]);outputs_checked+=counts[0];
   for(int label=0;label<4;++label)final_checksums[label]^=checksum(output[label],counts[label])+0x9e3779b97f4a7c15ULL+(final_checksums[label]<<6)+(final_checksums[label]>>2);
   if(row.ns[0]==0||row.ns[1]==0||row.ns[2]==0||row.ns[3]==0)throw std::runtime_error("zero timer duration");
   const double a=double(row.ns[2]+row.ns[3])/(row.ns[0]+row.ns[1]),b=double(row.ns[1])/row.ns[0],c=double(row.ns[3])/row.ns[2];candidate_ratios.push_back(a);control_ratios.push_back(b);candidate_control_ratios.push_back(c);candidate_logs+=std::log(a);control_logs+=std::log(b);candidate_control_logs+=std::log(c);results.push_back(row);
  }
 }
 std::cout<<std::setprecision(12)<<'{';
 bool first_field=true;
 const auto field=[&](std::string_view key,const auto& value){if(!first_field)std::cout<<',';first_field=false;std::cout<<quoted_json(key)<<':'<<value;};
 field("version",3);field("id",quoted_json(micro_id));field("input",quoted_json(argv[1]));field("n",n);field("q",q);field("reps",reps);field("block_size",block_size);field("timer",quoted_json("CLOCK_THREAD_CPUTIME_ID"));field("compiler",quoted_json(__VERSION__));field("candidate_hld_sha256",quoted_json(micro_hld_sha));field("candidate_fenwick_sha256",quoted_json(micro_fw_sha));field("baseline_hld_sha256",quoted_json(micro_base_hld_sha));field("baseline_fenwick_sha256",quoted_json(micro_base_fw_sha));field("all_outputs_equal","true");field("outputs_checked",outputs_checked);field("construction_input_and_output_excluded","true");
 std::cout<<",\"total_cpu_ns\":{\"base\":"<<totals[0]<<",\"control\":"<<totals[1]<<",\"candidate\":"<<totals[2]<<",\"candidate_control\":"<<totals[3]<<'}';
 const auto emit_ratios=[&](const char* key,long double a,long double b,long double c){std::cout<<','<<quoted_json(key)<<":{\"candidate_over_base\":"<<a<<",\"control_over_base\":"<<b<<",\"candidate_control_over_candidate\":"<<c<<'}';};
 emit_ratios("total_ratios",(totals[0]+totals[1])?double(totals[2]+totals[3])/(totals[0]+totals[1]):1,totals[0]?double(totals[1])/totals[0]:1,totals[2]?double(totals[3])/totals[2]:1);
 emit_ratios("paired_median_ratios",median(candidate_ratios),median(control_ratios),median(candidate_control_ratios));
 emit_ratios("paired_geometric_mean_ratios",results.empty()?1:std::exp(candidate_logs/results.size()),results.empty()?1:std::exp(control_logs/results.size()),results.empty()?1:std::exp(candidate_control_logs/results.size()));
 std::cout<<",\"final_checksums\":["<<final_checksums[0]<<','<<final_checksums[1]<<','<<final_checksums[2]<<','<<final_checksums[3]<<']';
 field("scope",quoted_json("preloadedAPIkernel v3; twoinstancespercode; consume noinline/noclone kept; shuffled4labels perblock; queryoutput stores timed; parsing/construction/checksums/JSON excluded; not frozenVerifywholeprocess timings"));
 std::cout<<",\"blocks\":[";
 bool first=true;for(const auto& r:results){if(!first)std::cout<<',';first=false;std::cout<<"{\"rep\":"<<r.rep<<",\"begin\":"<<r.begin<<",\"end\":"<<r.end<<",\"order\":["<<r.order[0]<<','<<r.order[1]<<','<<r.order[2]<<','<<r.order[3]<<"],\"base_ns\":"<<r.ns[0]<<",\"control_ns\":"<<r.ns[1]<<",\"candidate_ns\":"<<r.ns[2]<<",\"candidate_control_ns\":"<<r.ns[3]<<",\"outputs\":"<<r.count<<",\"checksum\":"<<r.checksum<<'}';}
 std::cout<<"]}\n";return 0;
 }catch(const std::exception& e){std::cerr<<"micro error: "<<e.what()<<'\n';return 1;}}
