# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,statistics,sys
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_opt_20261105');load=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
assert len(load(D/'final_tests.json'))==6 and all(x['returncode']==0 and not x['stderr']for x in load(D/'final_tests.json'))
assert len(load(D/'fenwick/final_large_results.json'))==6 and all(x['returncode']==0 and not x['stderr']for x in load(D/'fenwick/final_large_results.json'))
assert load(D/'final_profiles/checkpoint.json')['counts']=={'LOCAL_SAMPLE_PASS':22}
assert len(load(D/'final_output_checks.json'))==112 and all(x['identical']for x in load(D/'final_code_mapping.json'))
selected=[]
for x in load(D/'outline_probe_raw.json'):
 y=dict(x);y.update(compiler='gcc',label='after'if x['label']=='outline'else x['label']);selected.append(y)
for x in load(D/'final_benchmark_raw.json'):
 if (x['compiler'],x['id'])not in [('clang','hld_path_prod'),('gcc','hld_path_composite')]:continue
 y=dict(x);y['label']='after'if x['label']=='owned_access'else x['label'];selected.append(y)
for x in load(D/'composite_recheck_raw.json'):
 y=dict(x);y.update(compiler='gcc',label='after'if x['label']=='owned_access'else x['label']);selected.append(y)
summary=[]
for key in sorted({(x['compiler'],x['id'],x['case'])for x in selected}):
 rr=[x for x in selected if (x['compiler'],x['id'],x['case'])==key];assert len({x['output_sha256']for x in rr})==1
 med={l:statistics.median(x['cpu_ns']for x in rr if x['label']==l)for l in ['base','control','after']};summary.append(dict(compiler=key[0],id=key[1],case=key[2],samples_per_label=sum(x['label']=='base'for x in rr),median_cpu_ns=med,after_ratio=med['after']/med['base'],control_ratio=med['control']/med['base']))
(D/'selected_benchmark_raw.json').write_text(json.dumps(selected)+'\n');(D/'selected_benchmark_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
paths=['Graph/Heavy_Light_Decomposition.cpp','DataStructure/Fenwick_Tree.cpp','Document/heavy_light_decomposition.md','Examples/heavy_light_decomposition_example.cpp','Verify/current/tests/hld_fenwick_path_test.cpp','Verify/current/tests/hld_owned_test.cpp','Verify/current/tests/hld_owned_allocation_test.cpp','Verify/current/drivers/hld_path_prod_main.cpp','Verify/current/drivers/hld_path_composite_main.cpp']
files={p:(R/p).read_bytes()for p in paths}
for p in(D/'before').rglob('*'):
 if p.is_file():files['before/'+str(p.relative_to(D/'before'))]=p.read_bytes()
# 実行ファイル・巨大入力・外部生成器本文を含めず、自己作成の再現コードと測定値を保存。
for p in D.iterdir():
 if p.is_file()and p.suffix in ['.py','.hpp','.json','.log']and not p.name.startswith(('415261','415258')):files['evidence/'+p.name]=p.read_bytes()
for folder in ['fenwick','ordered']:
 for p in(D/folder).iterdir():
  if p.is_file()and p.suffix in ['.py','.cpp','.hpp','.json','.log','.patch']:files['evidence/'+folder+'/'+p.name]=p.read_bytes()
for p in(D/'micro').iterdir():
 if p.is_file()and p.suffix in ['.py','.cpp','.in','.json','.log']:files['evidence/micro/'+p.name]=p.read_bytes()
for p in(D/'micro').glob('calibration_owned_access_v3_*.json'):files['evidence/micro/'+p.name]=p.read_bytes()
for name in ['kernel.cpp.in','build_micro.py','summary_v2.json','summary.json','large_summary.json']:
 for folder in ['version1','version2']:
  p=D/'micro'/folder/name
  if p.is_file():files['evidence/micro/'+folder+'/'+name]=p.read_bytes()
for name in ['fixtures.json','point_fixtures.json','official_sources.json','prepare_fixtures_v2.py','extra_small_heavy.py','reference_small.py','prepare_point_fixtures.py']:
 p=D/'fixtures'/name
 if p.is_file():files['fixtures/'+name]=p.read_bytes()
files['evidence/final_profiles.json']=(D/'final_profiles/checkpoint.json').read_bytes()
for p in(D/'final_profiles/results').glob('*.json'):files['evidence/profiles/'+p.name]=p.read_bytes()
sys.path.insert(0,str(R/'Scripts'));from deterministic_zip import write_archive
z=R/'Audit/data/performance-hld-owned-2026-11-05.zip';write_archive(z,files)
a=dict(date='2026-11-05',scope='HLD所有API再提出ACを確認し、main/共通IO固定でP-Core向け経路和・非可換積を高速化。',online_confirmation='Audit/online-hld-owned-2026-11-05.json',online=dict(hld_path_prod=dict(url='https://judge.yosupo.jp/submission/415261',status='AC',time_ms=326),hld_path_composite=dict(url='https://judge.yosupo.jp/submission/415258',status='AC',time_ms=257),scope='このACは改修前の提出コード。現行版はローカル検証済みで再提出待ち。'),adopted=['自身のFenwickを所有する大規模HLDの経路和で、短区間の共通prefixを相殺する。N>4096で一度だけ選択し、同一重鎖は従来のprefix計算を直接使う。','Fenwickには非公開タグ・friend接続だけを追加し、通常の全メソッド・フィールドはそのまま。HLD生成の区間とサイズ不変条件を利用して境界再検査を省く。','GCCは大規模BIT処理を非公開noinline関数へ分離し、小規模経路の呼出し側が膨らむことを防ぐ。Clangは実測で有効だったinline経路を使用。','GCCのOrdered=trueで32byte以下の自明コピー可能な値（builtinfloat除外）は、前半へ追記・後半へ前置して区間バッファと再走査を除く。同一重鎖は区間結果を直接返す。','文字列など非自明/大きい値、ClangのOrdered、実ACLや旧Fenwickのタグなし型、BITのbuiltinfloat/boolは従来経路へ戻す。公開API・所有権・数学的0判定・容量対策を維持。'],mathematical_proof='Fenwick prefixの親は最下位1bitを消した添字。l,rで最上位の相違bitより上が共通祖先となり、その先の同一prefixは可換加法群の差で相殺できる。長い区間は元計算。非可換積はu側を追記、v側を前置し、最後に前半+後半を結合する。同一重鎖を直接返せるのは単位元則による。入力頂点番号の大小は使わず、内部で生成したDFS添字だけを利用。',ownership_and_safety='vector/make_uniqueを継続。新しいrawnew・解放省略・永続借用・保持状態・CPU専用命令なし。FW/HLD双方の前方宣言と部品ガードで単独貼付/順序/旧版混在を保つ。defaultvertex検査後にprivateheadを参照する。コピー/buildの旧状態保持・move元emptyを維持。',environment=load(D/'environment.json'),measurement=dict(scope='同一の提出mainと共通IOでC++23O2。CPU12(P-Core)固定、各候補を同じ実行パスへコピーし順序を混ぜる。per-process setarch -Rでアドレス配置だけ揃え、globalASLR/周波数/governorを変更しない。CPUtimeはrusage(user+system)、構築・入力・出力・破棄を含む。',per_process_ASLR_disabled=True,selected_runs=len(selected),summary=summary,mapping=load(D/'final_code_mapping.json'),scope_limits='固定commitの公式生成器と独自入力によるローカル比較。現在のオンライン入力そのものやオンライン時間の短縮率とは区別する。compiler/CPU/コード配置差と対照の揺れを含む。'),rejected_and_diagnostics=['共通prefix相殺を通常Fenwick.sum全体へ入れる案は小規模・長区間への費用が増えたため不採用。FW公開メソッドは変更しない。','全コンパイラへの可換直接fold、単なるstate参照変更、optionalprefixで単位元との演算を除く案は別条件の後退があり不採用。Clangの非可換fusionも不採用。','初期process比較は同一binarycontrolにも10〜35%差が出たため採用根拠にしない。microv1は片方のみのinline化、v2は旧code2回/候補1回のtrace-replay頻度差があり定量判断から除外。','microv3は旧/候補各2回の対称比較とnoinlineを用い、変わらないFWで約1%の差まで較正した。最終採用はASLRを揃えた実際の提出main全体の7回比較（追加確認13回）とmachinecode一致による。'],validation=dict(final_asan_ubsan_owned=4,final_asan_ubsan_large_native=4,final_standard_fallback_large=2,allocation_checks=2,owned_results=load(D/'final_tests.json'),large_results=load(D/'fenwick/final_large_results.json'),actual_program_input_checks=112,normal_sample_builds=10,variant_and_example_samples=22,unaffected_code='通常FWのGCC/Clang、旧Jump/外部経路和のGCC/Clang、Clang非可換Verifyの.textは改修前とbyte一致。',source_proofs=load(D/'source_proofs.json')),provenance='既存CC0の自作実装へ、共通prefix相殺・private接続・両端foldを独立に実装。公式generatorの外部本文は/tmpに限り、配布証拠へ含めない。',sources={p:dict(sha256=sha((R/p).read_bytes()),bytes=(R/p).stat().st_size)for p in paths},evidence=dict(path=str(z.relative_to(R)),sha256=sha(z.read_bytes()),entries=len(files)),affected_judgement_records=load(D/'affected_online_ids.json'),required_resubmission=['hld_path_prod','hld_path_composite'])
a['environment']['per_process_ASLR_disabled_for_final_process_comparison']=True
(R/'Audit/performance-hld-owned-2026-11-05.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');print('Final audit complete',len(selected),'verified timed runs,',len(files),'evidence entries')
