# SPDX-License-Identifier: CC0-1.0
"""Global Fenwick.sum用の独立した点加算・半開区間和入力。"""
from pathlib import Path
import random,json,hashlib
D=Path(__file__).resolve().parent;I=D/'point_inputs';I.mkdir(exist_ok=True);rows=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cases=[(32,250000,'random'),(4096,250000,'random'),(500000,500000,'random'),(500000,500000,'short16_64'),(500000,500000,'prefix'),(500000,500000,'update80')]
for k,(n,q,kind)in enumerate(cases):
 seed=202611055+k;rng=random.Random(seed);name=f'custom_point_add_range_sum_{n}_{kind}';p=I/(name+'.in');values=[rng.randrange(1000000001)for _ in range(n)];answers=[]
 with p.open('w')as out:
  out.write(f'{n} {q}\n');out.write(' '.join(map(str,values))+'\n')
  for i in range(q):
   update=(i%5!=4)if kind=='update80'else(i%2==0)
   if update:
    v=rng.randrange(n);x=rng.randrange(1000000001);out.write(f'0 {v} {x}\n')
    if n<=4096:values[v]+=x
   else:
    if kind=='prefix':l=0;r=rng.randrange(n+1)
    elif kind=='short16_64':
     l=rng.randrange(n+1);limit=16 if i%8<4 else 64;r=min(n,l+rng.randrange(limit+1))
    else:l=rng.randrange(n+1);r=rng.randrange(n+1);l,r=min(l,r),max(l,r)
    out.write(f'1 {l} {r}\n')
    if n<=4096:answers.append(str(sum(values[l:r])))
 row=dict(name=name,path=str(p),problem='point_add_range_sum',origin='independent_custom',n=n,q=q,shape=kind,seed=seed,update_fraction=0.8 if kind=='update80'else 0.5,bytes=p.stat().st_size,sha256=sha(p),values='initial/delta0..1e9, totalsfitint64',ranges='halfopen, includingsomeemptyranges')
 if n<=4096:
  expected=p.with_suffix('.out');expected.write_text('\n'.join(answers)+'\n');row.update(expected_path=str(expected),expected_sha256=sha(expected),reference='Independent Python array pointupdates +slice sums')
 rows.append(row);(D/'point_fixtures.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(name,p.stat().st_size,flush=True)
print('DONE',len(rows),flush=True)
