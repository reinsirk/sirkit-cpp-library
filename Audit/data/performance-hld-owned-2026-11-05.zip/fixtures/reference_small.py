# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,collections
D=Path(__file__).resolve().parent;rows=json.loads((D/'fixtures.json').read_text());MOD=998244353;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for row in rows:
 if row['n']>1000 or 'expected_path'in row or row['q']>5000:continue
 it=iter(map(int,Path(row['path']).read_text().split()));n=next(it);q=next(it);kind=row['problem'];v=[next(it)if kind=='vertex_add_path_sum'else(next(it),next(it))for _ in range(n)];g=[[]for _ in range(n)]
 for _ in range(n-1):a=next(it);b=next(it);g[a].append(b);g[b].append(a)
 out=[]
 for _ in range(q):
  t=next(it)
  if t==0:
   a=next(it)
   if kind=='vertex_add_path_sum':v[a]+=next(it)
   else:v[a]=(next(it),next(it))
  else:
   a=next(it);b=next(it);x=None if kind=='vertex_add_path_sum'else next(it);pred=[-1]*n;pred[a]=a;todo=collections.deque([a])
   while todo:
    u=todo.popleft()
    if u==b:break
    for w in g[u]:
     if pred[w]<0:pred[w]=u;todo.append(w)
   route=[]
   while b!=a:route.append(b);b=pred[b]
   route.append(a);route.reverse()
   if kind=='vertex_add_path_sum':out.append(str(sum(v[w]for w in route)))
   else:
    for w in route:aa,bb=v[w];x=(aa*x+bb)%MOD
    out.append(str(x))
 assert next(it,None)is None
 expected=Path(row['path']).with_suffix('.out');expected.write_text('\n'.join(out)+'\n');row.update(expected_path=str(expected),expected_sha256=sha(expected),reference='Independent BFS path extraction followed by elementwise sum/affine application');print(row['name'],'reference outputs',len(out),flush=True)
(D/'fixtures.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
