# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,random,hashlib,collections
D=Path(__file__).resolve().parent;I=D/'inputs';rows=json.loads((D/'fixtures_v2.json').read_text());MOD=998244353;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in [32,4096]:
 for shape in ['chain','random']:
  seed=202611052+n+(shape=='chain');rng=random.Random(seed);parent=[-1]+[v-1 if shape=='chain'else rng.randrange(v)for v in range(1,n)];perm=list(range(n));rng.shuffle(perm);edges=[(perm[v],perm[parent[v]])for v in range(1,n)];rng.shuffle(edges);adj=[[]for _ in range(n)]
  for u,v in edges:adj[u].append(v);adj[v].append(u)
  def path(u,v):
   pred=[-1]*n;pred[u]=u;todo=collections.deque([u])
   while todo:
    x=todo.popleft()
    if x==v:break
    for y in adj[x]:
     if pred[y]<0:pred[y]=x;todo.append(y)
   seq=[]
   while v!=u:seq.append(v);v=pred[v]
   seq.append(u);return seq[::-1]
  q=250000
  for problem in ['vertex_add_path_sum','vertex_set_path_composite']:
   name=f'custom_{problem}_{n}_{shape}_queryheavy';dest=I/f'{name}.in';answers=[]
   value=[rng.randrange(1000000001)if problem=='vertex_add_path_sum'else(rng.randrange(MOD),rng.randrange(MOD))for _ in range(n)]
   with dest.open('w')as out:
    out.write(f'{n} {q}\n')
    if problem=='vertex_add_path_sum':out.write(' '.join(map(str,value))+'\n')
    else:out.writelines(f'{a} {b}\n'for a,b in value)
    out.writelines(f'{u} {v}\n'for u,v in edges)
    for j in range(q):
     if j%2==0:
      v=rng.randrange(n)
      if problem=='vertex_add_path_sum':x=rng.randrange(1000000001);out.write(f'0 {v} {x}\n');value[v]+=x
      else:a=rng.randrange(MOD);b=rng.randrange(MOD);out.write(f'0 {v} {a} {b}\n');value[v]=(a,b)
     else:
      u=rng.randrange(n);v=u if j%8==1 else rng.randrange(n)
      if problem=='vertex_add_path_sum':out.write(f'1 {u} {v}\n')
      else:x=rng.randrange(MOD);out.write(f'1 {u} {v} {x}\n')
      if n==32:
       seq=path(u,v)
       if problem=='vertex_add_path_sum':answers.append(str(sum(value[v]for v in seq)))
       else:
        for v in seq:a,b=value[v];x=(a*x+b)%MOD
        answers.append(str(x))
   row=dict(name=name,path=str(dest),problem=problem,origin='independent_custom',n=n,q=q,bytes=dest.stat().st_size,sha256=sha(dest),shape=shape,seed=seed,labels='arbitrarily permuted',operations='50% updates and50% pathqueries;250k operations isolates smalltree operationcost fromstartup')
   if n==32:
    expected=dest.with_suffix('.out');expected.write_text('\n'.join(answers)+'\n');row.update(expected_path=str(expected),expected_sha256=sha(expected),reference='Independent BFSroute +elementwise sum/affine application')
   rows.append(row);print(name,dest.stat().st_size,flush=True);(D/'fixtures.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
(D/'official_sources.json').write_bytes((D/'official_sources_v2.json').read_bytes())
print('ALL',len(rows),flush=True)
