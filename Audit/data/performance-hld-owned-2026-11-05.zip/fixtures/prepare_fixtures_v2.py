# SPDX-License-Identifier: CC0-1.0
"""HLD比較入力の再現器。外部の公式生成器は /tmp の official/ にのみ保存する。"""
from pathlib import Path
import json,urllib.request,tomllib,subprocess,hashlib,resource,random,concurrent.futures,collections
D=Path(__file__).resolve().parent;REV='73876f1cbcf082d2b22722924b924d3d65a2f00e';BASE=f'https://raw.githubusercontent.com/yosupo06/library-checker-problems/{REV}/';O=D/'official';I=D/'inputs';B=D/'generators';I.mkdir(exist_ok=True);B.mkdir(exist_ok=True)
# 外部生成器だけで使う再帰stack。ライブラリ計測環境は変えない。
resource.setrlimit(resource.RLIMIT_STACK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def fetch(f):
 p=O/f
 if not p.exists():
  p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(urllib.request.urlopen(BASE+f,timeout=45).read())
 return p
problems=['vertex_add_path_sum','vertex_set_path_composite'];source=['LICENSE','common/random.h'];specs={}
for p in problems:
 f=f'tree/{p}/info.toml';specs[p]=tomllib.loads(fetch(f).read_text());source.append(f)
 for t in specs[p]['tests']:
  if t['name'].endswith('.cpp'):source.append(f'tree/{p}/gen/'+t['name'])
  else:
   for k in range(t['number']):source.append(f'tree/{p}/gen/example_{k:02d}.in')
with concurrent.futures.ThreadPoolExecutor(max_workers=8)as pool:list(pool.map(fetch,source))
metadata=dict(repository='https://github.com/yosupo06/library-checker-problems',revision=REV,license='Apache-2.0',usage='外部生成器は入力作成だけに使用。実装への取り込みなし。外部本文は/tmpのみ。',generator_stack_limit='unlimited for generator only',files=[dict(path=f,url=BASE+f,sha256=sha(O/f))for f in source]);(D/'official_sources_v2.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
rows=[];commands=[]
def register(name,path,problem,origin,**extra):
 h=path.open().readline().strip();n,q=map(int,h.split());row=dict(name=name,path=str(path),problem=problem,origin=origin,header=h,n=n,q=q,bytes=path.stat().st_size,sha256=sha(path),**extra);rows.append(row);(D/'fixtures_v2.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(name,h,row['bytes'],flush=True)
for p,spec in specs.items():
 root=O/f'tree/{p}';(root/'params.h').write_text(''.join(f'constexpr int {k} = {v};\n'for k,v in spec['params'].items()))
 for t in spec['tests']:
  if not t['name'].endswith('.cpp'):
   for k in range(t['number']):
    name=f'official_{p}_example_{k}';dest=I/f'{name}.in';dest.write_bytes((root/f'gen/example_{k:02d}.in').read_bytes());register(name,dest,p,'official_example',source=BASE+f'tree/{p}/gen/example_{k:02d}.in')
   continue
  src=root/'gen'/t['name'];exe=B/f'{p}_{src.stem}';cmd=['taskset','-c','2','/usr/bin/g++','-std=c++23','-O2','-I',str(O/'common'),str(src),'-o',str(exe)];subprocess.run(cmd,check=True);commands.append(cmd)
  # 系統ごとにseed0を作り、ランダム最大だけseed1も追加する。
  for seed in ([0,1]if src.stem=='max_random'else[0]):
   name=f'official_{p}_{src.stem}_{seed}';dest=I/f'{name}.in'
   with dest.open('wb')as out:subprocess.run(['taskset','-c','2',str(exe),str(seed)],stdout=out,check=True)
   register(name,dest,p,'official_generator',source=BASE+src.relative_to(O).as_posix(),seed=seed)
(D/'generator_commands_v2.json').write_text(json.dumps(commands,indent=2)+'\n')
MOD=998244353
for n in [32,4096,250000]:
 q=n
 for k,shape in enumerate(['chain','star','balanced','random']):
  seed=20261105+n*11+k;rng=random.Random(seed);parent=[-1]+[v-1 if shape=='chain'else 0 if shape=='star'else(v-1)//2 if shape=='balanced'else rng.randrange(v)for v in range(1,n)];perm=list(range(n));rng.shuffle(perm);edges=[(perm[v],perm[parent[v]])for v in range(1,n)];rng.shuffle(edges);edges=[(v,u)if rng.randrange(2)else(u,v)for u,v in edges]
  adj=[[]for _ in range(n)]if n<=4096 else None
  if adj is not None:
   for u,v in edges:adj[u].append(v);adj[v].append(u)
  def path(u,v):
   before=[-1]*n;todo=collections.deque([u]);before[u]=u
   while todo:
    x=todo.popleft()
    if x==v:break
    for y in adj[x]:
     if before[y]==-1:before[y]=x;todo.append(y)
   result=[]
   while v!=u:result.append(v);v=before[v]
   result.append(u);return result[::-1]
  for problem in problems:
   name=f'custom_{problem}_{n}_{shape}';dest=I/f'{name}.in';outputs=[]
   if problem=='vertex_add_path_sum':values=[rng.randrange(1000000001)for _ in range(n)];original=values[:]
   else:values=[(rng.randrange(MOD),rng.randrange(MOD))for _ in range(n)];original=values[:]
   with dest.open('w')as out:
    out.write(f'{n} {q}\n')
    if problem=='vertex_add_path_sum':out.write(' '.join(map(str,values))+'\n')
    else:out.writelines(f'{a} {b}\n'for a,b in values)
    out.writelines(f'{u} {v}\n'for u,v in edges)
    for j in range(q):
     if j%2==0:
      v=rng.randrange(n)
      if problem=='vertex_add_path_sum':x=rng.randrange(1000000001);out.write(f'0 {v} {x}\n');values[v]+=x
      else:a=rng.randrange(MOD);b=rng.randrange(MOD);out.write(f'0 {v} {a} {b}\n');values[v]=(a,b)
     else:
      u=rng.randrange(n);v=u if j%8==1 else rng.randrange(n)
      if problem=='vertex_add_path_sum':out.write(f'1 {u} {v}\n')
      else:x=rng.randrange(MOD);out.write(f'1 {u} {v} {x}\n')
      if adj is not None:
       route=path(u,v)
       if problem=='vertex_add_path_sum':outputs.append(str(sum(values[v]for v in route)))
       else:
        for v in route:a,b=values[v];x=(a*x+b)%MOD
        outputs.append(str(x))
   extra=dict(seed=seed,shape=shape,labels='arbitrarily permuted',operations='50% point updates; 50% pathqueries including singlevertex')
   if adj is not None:
    expected=dest.with_suffix('.out');expected.write_text('\n'.join(outputs)+'\n');extra.update(expected_path=str(expected),expected_sha256=sha(expected),reference='Independent BFS route followed by elementwise sum/affine evaluation')
   register(name,dest,problem,'independent_custom',**extra)
print('DONE',len(rows),'fixtures',flush=True)
