// SPDX-License-Identifier: CC0-1.0
// Independently written on 2026-11-13; no existing mixer implementation or
// published mixer constants were consulted. Dedicated to the public domain
// under CC0 1.0: https://creativecommons.org/publicdomain/zero/1.0/
// mix(x): uint64_t 全域上の全単射。非暗号的撹拌、O(1)、例外なし。mix(0)=0。
#include <cstdint>

#ifndef SIRKIT_CC0_MIXER_CANDIDATE_DEFINED
#define SIRKIT_CC0_MIXER_CANDIDATE_DEFINED
struct MixerCandidate {
    static constexpr std::uint64_t mix(std::uint64_t x) noexcept {
        x ^= x >> 31;
        x *= UINT64_C(0xacc9cf3297138d5b);
        x ^= x >> 29;
        x *= UINT64_C(0x8da932fd36b1ac97);
        x ^= x >> 32;
        return x;
    }
};
#endif
