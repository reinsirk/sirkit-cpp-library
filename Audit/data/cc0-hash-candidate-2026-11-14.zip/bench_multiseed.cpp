// SPDX-License-Identifier: CC0-1.0
#include "DataStructure/Hash_map.cpp"
#include "DataStructure/Hash_set.cpp"
#include "Internal/Nyaan_hash_map_min.cpp"
#include <chrono>
#include <iostream>
#include <string>
#include <tuple>
#include <vector>
#include <algorithm>
#include <cstdint>
#include <random>
#include <cstdlib>
std::uint64_t task_seed=3721;

volatile std::uint64_t sink = 0;
using Clock = std::chrono::steady_clock;
template<class F> void measure(const char* name, F f) {
    std::vector<double> ms;
    for (int r=0;r<7;++r) {
        auto begin=Clock::now();
        auto total=f();
        auto end=Clock::now();
        sink=total;
        ms.push_back(std::chrono::duration<double,std::milli>(end-begin).count());
    }
    std::sort(ms.begin(),ms.end());
    std::cout << name << ' ' << ms[3] << '\n';
}
template<class Key> void map_case(const char* name, const std::vector<Key>& keys, int repeats) {
    measure(name,[&]{
        std::uint64_t sum=0;
        for(int r=0;r<repeats;++r){
            HashMap<Key,std::uint64_t> map(keys.size(),GenericHash(task_seed));
            for(std::size_t i=0;i<keys.size();++i)map[keys[i]]=i+1;
            for(const auto& key:keys)sum+=map.at(key);
            for(std::size_t i=0;i<keys.size();i+=3)map.erase(keys[i],false);
            for(const auto& key:keys)sum+=map.contains(key);
        }
        return sum;
    });
}
template<class Key> void set_case(const char* name, const std::vector<Key>& keys, int repeats) {
    measure(name,[&]{std::uint64_t sum=0;for(int r=0;r<repeats;++r){
        HashSet<Key> set(keys.size(),GenericHash(task_seed));
        for(const auto& key:keys)set.insert(key);
        for(const auto& key:keys)sum+=set.contains(key);
        for(std::size_t i=0;i<keys.size();i+=3)set.erase(keys[i],false);
        for(const auto& key:keys)sum+=set.contains(key);
    }return sum;});
}
int main(int argc,char** argv){
    if(argc>1)task_seed=std::strtoull(argv[1],nullptr,10);
    std::mt19937_64 rng(19675);
    for(std::size_t n:{64u,65536u}){
        std::vector<std::uint64_t> numbers;
        std::vector<std::tuple<std::uint64_t,std::uint64_t>> pairs;
        std::vector<std::string> strings;
        for(std::size_t i=0;i<n;++i){auto x=rng(); numbers.push_back(x);pairs.emplace_back(x,rng());strings.push_back("string-prefix-"+std::to_string(x));}
        const int repeats=n<100?2000:3;
        const auto size=std::to_string(n);
        map_case(("map_number_"+size).c_str(),numbers,repeats);
        map_case(("map_tuple_"+size).c_str(),pairs,repeats);
        map_case(("map_string_"+size).c_str(),strings,repeats);
        set_case(("set_number_"+size).c_str(),numbers,repeats);
        set_case(("set_tuple_"+size).c_str(),pairs,repeats);
        set_case(("set_string_"+size).c_str(),strings,repeats);
        measure(("internal_number_"+size).c_str(),[&]{std::uint64_t sum=0;for(int r=0;r<repeats;++r){
            reinsirk::detail::InternalHashMap<std::uint64_t,std::uint64_t> table;
            table.reserve(n);for(std::size_t i=0;i<n;++i)table[numbers[i]]=i;
            for(auto key:numbers)sum+=*table.find(key);
        }return sum;});
    }
    measure("construct_seed_1000000",[&]{std::uint64_t sum=0;for(std::uint64_t i=0;i<1000000;++i){GenericHash hash(i);sum+=hash(i);}return sum;});
}
