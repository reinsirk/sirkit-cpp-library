# SPDX-License-Identifier: CC0-1.0
import pathlib,subprocess,json,hashlib,time
root=pathlib.Path('/home/reinsirk/Atcoder_Env'); base=pathlib.Path('/tmp/cc0_hash_validation')
names=['hash_map_test','hash_set_test','internal_hash_reference_test','internal_hash_shared_guard_test','hash_round2_nested_set_test']
results=[]
settings=[('gcc','g++',[]),('clang','clang++',['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]
for slug,compiler,extra in settings:
 for mode,defines in [('checked',[]),('unchecked',['-DSKIP_RUNTIME_CHECKS'])]+([('portable',['-DSIRKIT_DISABLE_SIMD'])] if slug=='gcc' else []):
  for name in names:
   source=root/'Verify/current/tests'/f'{name}.cpp'; binary=base/(name+'_'+slug+'_'+mode)
   cmd=[compiler,*extra,'-std=c++23','-O2',*defines,str(source),'-o',str(binary)]
   begin=time.monotonic(); c=subprocess.run(cmd,text=True,capture_output=True)
   out=subprocess.run([str(binary)],text=True,capture_output=True) if c.returncode==0 else None
   passed=c.returncode==0 and out.returncode==0
   record={'test':name,'compiler':slug,'mode':mode,'command':cmd,'passed':passed,'seconds':time.monotonic()-begin,'compile_stderr':c.stderr,'output':out.stdout if out else '', 'stderr':out.stderr if out else ''}
   results.append(record)
   print(name,slug,mode,'PASS' if passed else 'FAIL',flush=True)
   (base/'tests.json').write_text(json.dumps({'results':results},ensure_ascii=False,indent=2)+'\n')
   if not passed:raise SystemExit(1)
