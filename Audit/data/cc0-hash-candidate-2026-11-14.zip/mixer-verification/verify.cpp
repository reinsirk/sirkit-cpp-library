// SPDX-License-Identifier: CC0-1.0
#include "mixer.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cinttypes>
#include <cstdio>
#include <cstdlib>
#include <random>
#include <string_view>
#include <vector>

using U = std::uint64_t;
constexpr U inverse_odd(U v) {
    U result = 1;
    for (int i = 0; i < 6; ++i) result *= 2 - v * result;
    return result;
}
constexpr U undo_right_xor(U x, int shift) {
    for (int s = shift; s < 64; s *= 2) x ^= x >> s;
    return x;
}
constexpr U inverse(U x) {
    x = undo_right_xor(x, 32);
    x *= inverse_odd(UINT64_C(0x8da932fd36b1ac97));
    x = undo_right_xor(x, 29);
    x *= inverse_odd(UINT64_C(0xacc9cf3297138d5b));
    x = undo_right_xor(x, 31);
    return x;
}
static_assert(MixerCandidate::mix(0) == 0);
static_assert(inverse(MixerCandidate::mix(0)) == 0);
static_assert(inverse(MixerCandidate::mix(UINT64_MAX)) == UINT64_MAX);
static_assert(inverse_odd(UINT64_C(0xacc9cf3297138d5b)) * UINT64_C(0xacc9cf3297138d5b) == 1);
static_assert(inverse_odd(UINT64_C(0x8da932fd36b1ac97)) * UINT64_C(0x8da932fd36b1ac97) == 1);

void require_inverse(U x) {
    if (inverse(MixerCandidate::mix(x)) != x || MixerCandidate::mix(inverse(x)) != x) {
        std::fprintf(stderr, "inverse failed at %016" PRIx64 "\n", x);
        std::abort();
    }
}

template<class Generate>
void balance(std::string_view name, U n, Generate generate) {
    std::array<U,64> counts{};
    for (U i=0; i<n; ++i) {
        U x=generate(i);
        require_inverse(x);
        U y=MixerCandidate::mix(x);
        for (int bit=0; bit<64; ++bit) counts[bit] += (y>>bit)&1;
    }
    auto [lo,hi]=std::minmax_element(counts.begin(),counts.end());
    double max_z=0, sum_z2=0;
    for (auto count:counts) {
        double z=(double(count)-double(n)/2)/std::sqrt(double(n)/4);
        max_z=std::max(max_z,std::abs(z)); sum_z2+=z*z;
    }
    std::printf("balance %-22.*s n=%" PRIu64 " min=%.9f max=%.9f max_abs_z=%.5f rms_z=%.5f\n",
        int(name.size()),name.data(),n,double(*lo)/double(n),double(*hi)/double(n),max_z,std::sqrt(sum_z2/64));
    std::printf("counts");
    for (auto count:counts) std::printf(" %" PRIu64,count);
    std::puts("");
}

template<class Generate>
void avalanche(std::string_view name, U n, Generate generate) {
    std::array<std::array<U,64>,64> counts{};
    U total_weight=0;
    for (U i=0; i<n; ++i) {
        U x=generate(i), y=MixerCandidate::mix(x);
        for (int bit=0;bit<64;++bit) {
            U diff=y ^ MixerCandidate::mix(x ^ (U{1}<<bit));
            total_weight+=std::popcount(diff);
            for(int out=0;out<64;++out) counts[bit][out]+=(diff>>out)&1;
        }
    }
    U minimum=n, maximum=0;
    double max_z=0,sum_z2=0;
    for (auto &row:counts) for (auto count:row) {
        minimum=std::min(minimum,count); maximum=std::max(maximum,count);
        double z=(double(count)-double(n)/2)/std::sqrt(double(n)/4);
        max_z=std::max(max_z,std::abs(z)); sum_z2+=z*z;
    }
    std::printf("avalanche %-20.*s n=%" PRIu64 " min=%.9f max=%.9f max_abs_z=%.5f rms_z=%.5f mean_weight=%.8f\n",
        int(name.size()),name.data(),n,double(minimum)/double(n),double(maximum)/double(n),max_z,std::sqrt(sum_z2/4096),double(total_weight)/double(n*64));
    for (int bit=0;bit<64;++bit) {
        std::printf("sac_row %d",bit);
        for (auto count:counts[bit]) std::printf(" %" PRIu64,count);
        std::puts("");
    }
}

volatile U benchmark_sink=0;
void bench() {
    constexpr U n=U{1}<<24;
    for (int round=0;round<7;++round) {
        U a=1,b=2,c=3,d=4;
        auto start=std::chrono::steady_clock::now();
        for(U i=0;i<n;i+=4) {
            a=MixerCandidate::mix(a); b=MixerCandidate::mix(b);
            c=MixerCandidate::mix(c); d=MixerCandidate::mix(d);
        }
        auto end=std::chrono::steady_clock::now();
        benchmark_sink=a^b^c^d;
        std::printf("bench independent4 round=%d ns_per_mix=%.6f\n",round,std::chrono::duration<double,std::nano>(end-start).count()/n);
        start=std::chrono::steady_clock::now();
        for(U i=0;i<n;++i) a=MixerCandidate::mix(a);
        end=std::chrono::steady_clock::now();
        benchmark_sink=a;
        std::printf("bench dependent1 round=%d ns_per_mix=%.6f\n",round,std::chrono::duration<double,std::nano>(end-start).count()/n);
    }
}
int main(int argc,char**argv) {
    if(argc>1 && std::string_view(argv[1])=="bench") {bench();return 0;}
    constexpr U n=U{1}<<20;
    balance("sequential_zero",n,[](U i){return i;});
    balance("sequential_high",n,[](U i){return UINT64_C(0xd4b821f780000000)+i;});
    balance("sequential_shifted32",n,[](U i){return i<<32;});
    balance("multiples_odd",n,[](U i){return i*UINT64_C(0x17a985e3bdf2064d);});
    std::vector<U> sparse{0};
    for(int a=0;a<64;++a) {
        sparse.push_back(U{1}<<a);
        for(int b=a+1;b<64;++b) {
            sparse.push_back((U{1}<<a)|(U{1}<<b));
            for(int c=b+1;c<64;++c) sparse.push_back((U{1}<<a)|(U{1}<<b)|(U{1}<<c));
        }
    }
    balance("sparse_weight_le3",sparse.size(),[&](U i){return sparse[i];});
    balance("dense_weight_ge61",sparse.size(),[&](U i){return ~sparse[i];});
    std::mt19937_64 generator(UINT64_C(0x6a8c32f910ed45b7));
    std::vector<U> random(n);
    for(auto &x:random) x=generator();
    balance("mt19937_64",n,[&](U i){return random[i];});
    avalanche("sequential_zero",n,[](U i){return i;});
    avalanche("mt19937_64",n,[&](U i){return random[i];});
    avalanche("sparse_weight_le3",sparse.size(),[&](U i){return sparse[i];});
    std::printf("inverse checks passed; mix(0)=%016" PRIx64 "\n",MixerCandidate::mix(0));
}
