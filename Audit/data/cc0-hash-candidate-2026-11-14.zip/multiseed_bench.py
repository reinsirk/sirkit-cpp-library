# SPDX-License-Identifier: CC0-1.0
import pathlib,subprocess,statistics,os,json,sys
base=pathlib.Path('/tmp/cc0_hash_validation');root=pathlib.Path('/home/reinsirk/Atcoder_Env');core=min(os.sched_getaffinity(0))
results={};commands={}
for slug,compiler,extra in [('gcc','g++',[]),('clang','clang++',['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for version in ['old','new']:
  include=base/'old' if version=='old' else root
  cmd=[compiler,*extra,'-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS','-I'+str(include),str(base/'bench_multiseed.cpp'),'-o',str(base/(version+'_multiseed_'+slug))]
  subprocess.run(cmd,check=True);commands[slug+'_'+version]=cmd
if '--compile-only' in sys.argv:raise SystemExit(0)
for compiler in ['gcc','clang']:
 results[compiler]={}
 for seed in [3,17,123,104729]:
  values={'old':{},'new':{}}
  for r in range(2):
   for version in (['old','new'] if r==0 else ['new','old']):
    txt=subprocess.check_output(['taskset','-c',str(core),str(base/(version+'_multiseed_'+compiler)),str(seed)],text=True)
    for line in txt.splitlines():
     name,v=line.split();values[version].setdefault(name,[]).append(float(v))
  result={name:{'old_ms':statistics.median(values['old'][name]),'new_ms':statistics.median(values['new'][name]),'ratio':statistics.median(values['new'][name])/statistics.median(values['old'][name]),'old_samples_ms':values['old'][name],'new_samples_ms':values['new'][name]} for name in values['old']}
  results[compiler][seed]=result
  print(compiler,seed,' '.join(f'{n}:{v["ratio"]:.3f}' for n,v in result.items() if 'tuple' in n or 'string' in n),flush=True)
  (base/'multiseed_bench.json').write_text(json.dumps({'cpu':core,'commands':commands,'results':results},indent=2)+'\n')
