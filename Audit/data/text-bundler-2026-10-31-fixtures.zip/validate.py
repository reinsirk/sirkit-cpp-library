# SPDX-License-Identifier: CC0-1.0
import hashlib,importlib.util,json,os,pathlib,subprocess,sys,time
p=pathlib.Path(__file__).parent;root=pathlib.Path('/home/reinsirk/Atcoder_Env');sys.path.insert(0,str(p/'staged/Scripts'));import bundle_libraries as bundle
os.sched_setaffinity(0,{0})
groups={'math':['Math/NTT.cpp','Math/Formal_Power_Series.cpp','Math/Polynomial.cpp','Math/Convolution.cpp'],'bits':['DataStructure/Dynamic_Bitset.cpp','Math/Binary_Matrix.cpp'],'graph':['Graph/Bellman-Ford.cpp','Graph/Dijkstra.cpp','Graph/Floyd-Warshall.cpp'],'recurrence':['Math/NTT.cpp','Math/Berlekamp_Massey.cpp','Math/Linear_Recurrence.cpp']}
pp=[];sizes=[]
def run(cmd,**kw):
 while(p/'pause').exists():(p/'pause_ack').write_text('idle\n');time.sleep(.25)
 (p/'pause_ack').unlink(missing_ok=True)
 return subprocess.run(cmd,capture_output=True,text=True,timeout=120,**kw)
for profile in bundle.PROFILES:
 for group,libraries in groups.items():
  modules,_,manifest_sha=bundle.load_modules(root,profile,libraries);before,_=bundle.optimize_modules(modules,deduplicate=False);after,report=bundle.optimize_modules(modules);folder=p/'bundles'/profile;folder.mkdir(parents=True,exist_ok=True);(folder/(group+'_before.cpp')).write_bytes(before);(folder/(group+'_after.cpp')).write_bytes(after);sizes.append(dict(profile=profile,group=group,before=len(before),after=len(after),saved=len(before)-len(after),removed=len(report['removals']),conflicting_guards=report['conflicting_guards'],sha256_before=hashlib.sha256(before).hexdigest(),sha256_after=hashlib.sha256(after).hexdigest(),source_hashes=report['libraries']));(p/'sizes.json').write_text(json.dumps(sizes,indent=2)+'\n')
  compilers=['gcc','clang']if profile=='normal'else['gcc'if profile.endswith('gcc')else'clang']
  for compiler in compilers:
   cc=['/usr/bin/g++']if compiler=='gcc'else['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
   for config,flags in [('checked',[]),('skip',['-DSKIP_RUNTIME_CHECKS']),('standard',['-DSIRKIT_DISABLE_SIMD','-DSIRKIT_FORCE_STANDARD_ARITHMETIC'])]:
    cmd=['taskset','-c','0']+cc+['-std=c++23','-E','-P','-x','c++']+flags+['-'];a=run(cmd,input=before.decode());b=run(cmd,input=after.decode());assert a.returncode==b.returncode==0,(profile,group,config,a.stderr,b.stderr);assert a.stdout==b.stdout,(profile,group,config,'preprocessor mismatch');pp.append(dict(profile=profile,group=group,compiler=compiler,config=config,command=cmd,status='PASS',preprocessed_sha256=hashlib.sha256(a.stdout.encode()).hexdigest()));(p/'preprocessor_validation.json').write_text(json.dumps(pp,indent=2)+'\n')
  print(profile,group,len(before),'->',len(after),'remove',len(report['removals']),'PP PASS',flush=True)
