import hashlib,json,os,pathlib,subprocess,time
p=pathlib.Path(__file__).parent
os.sched_setaffinity(0,{0})
rows=json.loads((p/'runtime_validation.json').read_text())
assert len(rows)==34
expected=None
for version in ('before','after'):
    source=(p/'bundles/fast-clang'/f'graph_{version}.cpp').read_bytes()+b'\n#line 1 "bundle_runtime_test.cpp"\n'+(p/'runtime_graph.inc').read_bytes()
    cpp=p/f'runtime_fast-clang_clang_graph_{version}.cpp';cpp.write_bytes(source);exe=cpp.with_suffix('')
    cmd=['taskset','-c','0','/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-std=c++23','-O2','-Wall','-Wextra','-Werror','-Wno-error=misleading-indentation',str(cpp),'-o',str(exe)]
    while(p/'pause').exists():(p/'pause_ack').write_text('idle\n');time.sleep(.25)
    (p/'pause_ack').unlink(missing_ok=True)
    b=subprocess.run(cmd,capture_output=True,text=True,timeout=120);assert b.returncode==0,b.stderr
    r=subprocess.run(['taskset','-c','0',str(exe)],capture_output=True,text=True,timeout=120);assert r.returncode==0,r.stderr
    expected=r.stdout if expected is None else expected;assert expected==r.stdout
    rows.append(dict(profile='fast-clang',compiler='clang',group='graph',version=version,command=cmd,source_sha256=hashlib.sha256(source).hexdigest(),stdout=r.stdout,compiler_stderr=b.stderr,status='PASS',warning_note='Existing before/after Bellman-Ford indentation warning only; original -Werror rejection retained.'))
    (p/'runtime_validation.json').write_text(json.dumps(rows,indent=2)+'\n')
print(len(rows),'runtime conditions PASS')
