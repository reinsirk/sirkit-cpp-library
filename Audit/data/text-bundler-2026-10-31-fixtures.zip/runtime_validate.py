import hashlib,json,os,pathlib,subprocess,time
p=pathlib.Path(__file__).parent;os.sched_setaffinity(0,{0});rows=[]
def run(cmd,**kw):
 while(p/'pause').exists():(p/'pause_ack').write_text('idle\n');time.sleep(.25)
 (p/'pause_ack').unlink(missing_ok=True)
 return subprocess.run(cmd,capture_output=True,text=True,timeout=120,**kw)
for profile in ['normal','gcc','clang','fast-gcc','fast-clang']:
 for group in ['math','bits','graph']:
  for compiler in(['gcc','clang']if profile=='normal'else['gcc'if profile.endswith('gcc')else'clang']):
   cc=['/usr/bin/g++']if compiler=='gcc'else['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
   expected=None
   for version in ['before','after']:
    source=(p/'bundles'/profile/f'{group}_{version}.cpp').read_bytes()+b'\n#line 1 "bundle_runtime_test.cpp"\n'+(p/f'runtime_{group}.inc').read_bytes();cpp=p/f'runtime_{profile}_{compiler}_{group}_{version}.cpp';cpp.write_bytes(source);exe=cpp.with_suffix('');cmd=['taskset','-c','0']+cc+['-std=c++23','-O2','-Wall','-Wextra','-Werror',str(cpp),'-o',str(exe)];b=run(cmd);assert b.returncode==0,b.stderr;r=run(['taskset','-c','0',str(exe)]);assert r.returncode==0,(profile,group,version,r.stderr,r.returncode);expected=r.stdout if expected is None else expected;assert r.stdout==expected;rows.append(dict(profile=profile,compiler=compiler,group=group,version=version,command=cmd,source_sha256=hashlib.sha256(source).hexdigest(),stdout=r.stdout,status='PASS'));(p/'runtime_validation.json').write_text(json.dumps(rows,indent=2)+'\n')
  print(profile,group,'runtime before/after PASS',flush=True)
