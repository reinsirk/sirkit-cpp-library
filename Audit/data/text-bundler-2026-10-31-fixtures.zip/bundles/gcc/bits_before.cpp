// Readable module bundle; component guards and source provenance are retained.
// Library: DataStructure/Dynamic_Bitset.cpp
// SPDX-License-Identifier: CC0-1.0
// 生成版: GCC用。
// 生成元: DataStructure/Dynamic_Bitset.cpp
// 参考: https://nyaannyaan.github.io/library/data-structure/dynamic-bitset.hpp.html
// API選定の参考。配置・所有・可変長操作は独立実装。
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/dynamic_bitset.md
// API一覧
// DynamicBitset(n=0,value=false): n bitを同値で初期化。DynamicBitset(string_view): 高位からの01文字列。
// size()/empty(), words(): bit数/空判定/下位word順のspan<const uint64_t>。末尾の未使用bitは常に0。
// test(pos), operator[](pos) const: bit取得。非const []は代入・bool変換・flip・&=|=^=ができる非所有proxy。
// set()/reset()/flip(): 全bit操作。set(pos,value=true)/reset(pos)/flip(pos): 1 bit操作。全て*thisを返す。
// all()/any()/none(), count(), count(l,r): 全bit判定/1の数/[l,r)の1の数。空のallはtrue。
// intersection_count(other)/intersection_parity(other): ANDの1の数/その偶奇(bool)。&=|=^=と&|^、~、==も使える。==は長さも比較する。
// <<=k / >>=k / <<k / >>k: 固定長の論理shift。空いたbitは0。k>=sizeなら全0。
// shift_or(k): 自身に自身の左shiftをOR。元の各bitを一度だけ参照し、一時bitsetを確保しない。
// find_first()/find_last(), find_next(pos)/find_prev(pos): 1 bit位置。nextはposより後、prevはpos未満。
//   見つからなければsize()。next(pos>=size)もsize、prev(pos>size)は上限をsizeへ丸める。
// resize(n,value=false): 旧bitを保ち新bitを指定値へ。reserve_bits(n): 容量予約。clear(): 0 bitへ。
// to_string(): 高位からの01文字列。copyは独立所有、copy代入/確保失敗時は旧内容を維持。
// move元は空で再利用可。swapはO(1)。word span/proxyはサイズ変更・代入・所有権移動まで使用する。
// 1 bit操作・size/emptyはO(1)。全bit/2項/shift/探索は最悪O(ceil(n/64))、文字列変換はO(n)。
// resize/reserveは再確保時O(ceil(max(旧n,n)/64))、コピーはO(ceil(n/64))。count(l,r)はO((r-l)/64+1)。
// 番号・区間・2項演算の同長・01文字の検査はSKIP_RUNTIME_CHECKSで除外。容量保護と0判定は維持。
// GCC/Clang x86では対応CPUでPOPCNT/AVX2を選択。SIRKIT_DISABLE_SIMDで追加実装・CPU判定を除外。
// count/AND countは4 wordからPOPCNT、64 wordからAVX2。parityは64 wordからAVX2。
// ClangでAVX2を既定対象にしたビルドは、測定で速かった標準ループの自動vector化を使う。

// Library: Math/Binary_Matrix.cpp
// SPDX-License-Identifier: CC0-1.0
// 生成版: GCC用。
// 生成元: Math/Binary_Matrix.cpp
// 参考: https://nyaannyaan.github.io/library/matrix/f2-matrix.hpp
// GF(2)の掃き出し法・機能選定を参考に独立実装。内部bit kernelはDynamicBitsetと同一guardで共有。
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/binary_matrix.md
// API一覧
// BinaryMatrix(rows=0,cols=0): 全0行列。O(rows*ceil(cols/64))時間/領域。GF(2)上の要素0/1を扱う。
// rows()/cols()/empty(): 行数/列数/要素が0個か。row_words(row): 列0を最下位bitとするconst word span。
// test(row,col)/operator()(row,col): bool取得。set(row,col,value=true)/flip(row,col): 要素変更、*thisを返す。
// swap_rows(a,b), xor_rows(target,source,first_col=0): 行交換/first_col以降だけの行XOR。自己XOR可。
// transpose(): 転置。multiply(other)/operator*: 積。operator*=は自己参照可。pow(uint64_t): 正方行列の累乗。
// identity(n): 単位行列。+= / + / ^= / ^は同形行列のGF(2)和。==は形と全要素の一致。
// rank(): 階数。determinant(): 正方行列の行列式bool。0x0の行列式は1。
// inverse(): optional<BinaryMatrix>、非正則ならnullopt。0x0は0x0単位行列を返す。
// solve(span<const uint8_t> rhs): Ax=rhsのoptional<LinearSolution>、不能ならnullopt。rhsは行数個の0/1。
// LinearSolution {particular,kernel,pivot_columns}: particularは列数個のuint8_t特解、
//   kernelは各行が核の基底となる(列数-rank)x列数の行列。任意解は特解と基底行の線形結合。
//   pivot_columnsはRREFのpivot列。0行/0列も可。0行では全変数が自由、0列ではrhsが全0の場合のみ可。
// reset(rows=0,cols=0)/clear(): 再初期化/0x0。copyは独立所有・代入強保証、move元は0x0で再利用可。
// swapはO(1)。set/test/flip/形照会はO(1)、行操作はO(ceil(cols/64))、転置O(rows*cols)。
// AxBの積はO(1+B.rows*B.cols + A.rows*ceil(B.cols/64) + A.rows*B.cols*ceil(A.cols/64))。
// 累乗は行列積O(log(k+1))回。内側0次元でも結果の全0領域は確保する。
// rank/inverseの消去は最悪O(1+rows*cols + rows*min(rows,cols)*ceil(cols/64))時間。元行列を変更しない。
// solveは上記にO(rows+cols+cols*(cols-rank))時間を追加、核は(cols-rank)*ceil(cols/64)語。
// LinearSolutionも独立copy/代入強保証、move元の全フィールドは空。swapはO(1)。
// 確保失敗時は元の内容/viewを維持。viewは成功したreset/clear/代入/所有権移動まで有効。
// 番号・形・rhs長/参照したrhsの0/1検査はSKIP_RUNTIME_CHECKSで除外。容量保護・数学的0判定は維持。
// 0列のsolveは非0のrhsを見つけた時点で終了し、それ以降のrhsは検査しない。
// SIRKIT_DISABLE_SIMDは共有bit kernelの追加CPU判定/専用実装を除く。消去/転置に独自SIMDは使わない。


// Definitions: DataStructure/Dynamic_Bitset.cpp
#line 28 "Variants/GCC/DataStructure/Dynamic_Bitset.cpp"
#include <algorithm>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>
#if (!defined(SIRKIT_DISABLE_SIMD)) && ((defined(__x86_64__)) || (defined(__i386__)))
#include <immintrin.h>
#endif

#ifndef SIRKIT_DYNAMIC_BITSET_WORD_OPERATIONS_DEFINED
#define SIRKIT_DYNAMIC_BITSET_WORD_OPERATIONS_DEFINED
namespace reinsirk::detail {
inline unsigned bitset_word_popcount(std::uint64_t x) noexcept {
    x -= (x >> 1) & UINT64_C(0x5555555555555555);
    x = (x & UINT64_C(0x3333333333333333)) + ((x >> 2) & UINT64_C(0x3333333333333333));
    x = (x + (x >> 4)) & UINT64_C(0x0f0f0f0f0f0f0f0f);
    return static_cast<unsigned>((x * UINT64_C(0x0101010101010101)) >> 56);
}
inline std::size_t bitset_count_words_scalar(const std::uint64_t* words, std::size_t count) noexcept {
    std::size_t result = 0;
    for (std::size_t i = 0; i < count; ++i) result += bitset_word_popcount(words[i]);
    return result;
}
inline std::size_t bitset_intersection_words_scalar(const std::uint64_t* a, const std::uint64_t* b, std::size_t count) noexcept {
    std::size_t result = 0;
    for (std::size_t i = 0; i < count; ++i) result += bitset_word_popcount(a[i] & b[i]);
    return result;
}
inline bool bitset_intersection_parity_words_scalar(const std::uint64_t* a, const std::uint64_t* b, std::size_t count) noexcept {
    std::uint64_t value = 0;
    for (std::size_t i = 0; i < count; ++i) value ^= a[i] & b[i];
    return (bitset_word_popcount(value) & 1) != 0;
}

#if (!defined(SIRKIT_DISABLE_SIMD)) && ((defined(__x86_64__)) || (defined(__i386__)))

__attribute__((target("popcnt"))) inline std::size_t bitset_count_words_popcnt(const std::uint64_t* a,std::size_t n) noexcept {
    std::size_t s0=0,s1=0,s2=0,s3=0,i=0;
    for(;n-i>=4;i+=4){s0+=static_cast<unsigned>(__builtin_popcountll(a[i]));s1+=static_cast<unsigned>(__builtin_popcountll(a[i+1]));s2+=static_cast<unsigned>(__builtin_popcountll(a[i+2]));s3+=static_cast<unsigned>(__builtin_popcountll(a[i+3]));}
    for(;i<n;++i)s0+=static_cast<unsigned>(__builtin_popcountll(a[i]));
    return s0+s1+s2+s3;
}
__attribute__((target("popcnt"))) inline std::size_t bitset_intersection_words_popcnt(const std::uint64_t* a,const std::uint64_t* b,std::size_t n) noexcept {
    std::size_t s0=0,s1=0,s2=0,s3=0,i=0;
    for(;n-i>=4;i+=4){s0+=static_cast<unsigned>(__builtin_popcountll(a[i]&b[i]));s1+=static_cast<unsigned>(__builtin_popcountll(a[i+1]&b[i+1]));s2+=static_cast<unsigned>(__builtin_popcountll(a[i+2]&b[i+2]));s3+=static_cast<unsigned>(__builtin_popcountll(a[i+3]&b[i+3]));}
    for(;i<n;++i)s0+=static_cast<unsigned>(__builtin_popcountll(a[i]&b[i]));
    return s0+s1+s2+s3;
}
__attribute__((target("avx2,popcnt"))) inline std::size_t bitset_count_words_avx2(const std::uint64_t* a,std::size_t n) noexcept {
    const auto table=_mm256_setr_epi8(0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4,0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4);
    const auto mask=_mm256_set1_epi8(15),zero=_mm256_setzero_si256();auto total=zero;std::size_t i=0;
    for(;n-i>=4;i+=4){const auto x=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a+i));const auto lo=_mm256_shuffle_epi8(table,_mm256_and_si256(x,mask));const auto hi=_mm256_shuffle_epi8(table,_mm256_and_si256(_mm256_srli_epi16(x,4),mask));total=_mm256_add_epi64(total,_mm256_sad_epu8(_mm256_add_epi8(lo,hi),zero));}
    alignas(32) std::uint64_t lanes[4];_mm256_store_si256(reinterpret_cast<__m256i*>(lanes),total);auto result=lanes[0]+lanes[1]+lanes[2]+lanes[3];
    for(;i<n;++i)result+=static_cast<unsigned>(__builtin_popcountll(a[i]));
    return static_cast<std::size_t>(result);
}
__attribute__((target("avx2,popcnt"))) inline std::size_t bitset_intersection_words_avx2(const std::uint64_t* a,const std::uint64_t* b,std::size_t n) noexcept {
    const auto table=_mm256_setr_epi8(0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4,0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4);
    const auto mask=_mm256_set1_epi8(15),zero=_mm256_setzero_si256();auto total=zero;std::size_t i=0;
    for(;n-i>=4;i+=4){const auto x=_mm256_and_si256(_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a+i)),_mm256_loadu_si256(reinterpret_cast<const __m256i*>(b+i)));const auto lo=_mm256_shuffle_epi8(table,_mm256_and_si256(x,mask));const auto hi=_mm256_shuffle_epi8(table,_mm256_and_si256(_mm256_srli_epi16(x,4),mask));total=_mm256_add_epi64(total,_mm256_sad_epu8(_mm256_add_epi8(lo,hi),zero));}
    alignas(32) std::uint64_t lanes[4];_mm256_store_si256(reinterpret_cast<__m256i*>(lanes),total);auto result=lanes[0]+lanes[1]+lanes[2]+lanes[3];
    for(;i<n;++i)result+=static_cast<unsigned>(__builtin_popcountll(a[i]&b[i]));
    return static_cast<std::size_t>(result);
}

__attribute__((target("avx2,popcnt"), noinline)) inline std::size_t bitset_parity_words_avx2(const std::uint64_t* a,const std::uint64_t* b,std::size_t n)noexcept {
    auto total=_mm256_setzero_si256();std::size_t i=0;
    for(;n-i>=4;i+=4)total=_mm256_xor_si256(total,_mm256_and_si256(_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a+i)),_mm256_loadu_si256(reinterpret_cast<const __m256i*>(b+i))));
    alignas(32)std::uint64_t lanes[4];_mm256_store_si256(reinterpret_cast<__m256i*>(lanes),total);auto value=lanes[0]^lanes[1]^lanes[2]^lanes[3];
    for(;i<n;++i)value^=a[i]&b[i];
    return static_cast<unsigned>(__builtin_popcountll(value))&1;
}

inline unsigned bitset_cpu_features() noexcept {
    static const unsigned features = (__builtin_cpu_supports("popcnt") ? 1U : 0U) | (__builtin_cpu_supports("avx2") ? 2U : 0U);
    return features;
}
#endif
inline std::size_t bitset_count_words(const std::uint64_t* words, std::size_t count) noexcept {
#if (!defined(SIRKIT_DISABLE_SIMD)) && ((defined(__x86_64__)) || (defined(__i386__)))
    if (count >= 4) {
        const auto features = bitset_cpu_features();
        if (count >= 64 && features == 3) return bitset_count_words_avx2(words, count);
        if (features & 1) return bitset_count_words_popcnt(words, count);
    }
#endif
    return bitset_count_words_scalar(words, count);
}
inline std::size_t bitset_intersection_words(const std::uint64_t* a, const std::uint64_t* b, std::size_t count) noexcept {
#if (!defined(SIRKIT_DISABLE_SIMD)) && ((defined(__x86_64__)) || (defined(__i386__)))
    if (count >= 4) {
        const auto features = bitset_cpu_features();
        if (count >= 64 && features == 3) return bitset_intersection_words_avx2(a, b, count);
        if (features & 1) return bitset_intersection_words_popcnt(a, b, count);
    }
#endif
    return bitset_intersection_words_scalar(a, b, count);
}
inline bool bitset_intersection_parity_words(const std::uint64_t* a, const std::uint64_t* b, std::size_t count) noexcept {
#if (!defined(SIRKIT_DISABLE_SIMD)) && ((defined(__x86_64__)) || (defined(__i386__)))
    if (count >= 64 && bitset_cpu_features() == 3) return bitset_parity_words_avx2(a, b, count) != 0;
#endif
    return bitset_intersection_parity_words_scalar(a, b, count);
}
}
#endif

#ifndef SIRKIT_DYNAMIC_BITSET_DEFINED
#define SIRKIT_DYNAMIC_BITSET_DEFINED
class DynamicBitset {
    std::size_t size_ = 0;
    std::vector<std::uint64_t> words_;
    static constexpr std::uint64_t low_mask(unsigned bits) noexcept {
        return bits == 64 ? ~std::uint64_t{0} : (std::uint64_t{1} << bits) - 1;
    }
    static std::size_t word_count(std::size_t bits) {
        const auto count = bits / 64 + (bits % 64 != 0);
        if (count > std::vector<std::uint64_t>().max_size()) throw std::length_error("DynamicBitset capacity");
        return count;
    }
    void mask_tail() noexcept { if (size_ % 64) words_.back() &= low_mask(static_cast<unsigned>(size_ % 64)); }
    void check_position(std::size_t pos) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (pos >= size_) throw std::out_of_range("DynamicBitset position");
#else
        (void)pos;
#endif
    }
    void check_length(const DynamicBitset& other) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (size_ != other.size_) throw std::invalid_argument("DynamicBitset length mismatch");
#else
        (void)other;
#endif
    }
public:
    class reference {
        std::uint64_t* word_;
        std::uint64_t mask_;
        friend class DynamicBitset;
        reference(std::uint64_t& word, std::uint64_t mask) noexcept : word_(&word), mask_(mask) {}
    public:
        reference(const reference&) noexcept = default;
        operator bool() const noexcept { return (*word_ & mask_) != 0; }
        bool operator~() const noexcept { return !static_cast<bool>(*this); }
        reference& operator=(bool value) noexcept { if (value) *word_ |= mask_; else *word_ &= ~mask_; return *this; }
        reference& operator=(const reference& other) noexcept { return *this = static_cast<bool>(other); }
        reference& flip() noexcept { *word_ ^= mask_; return *this; }
        reference& operator&=(bool value) noexcept { if (!value) *word_ &= ~mask_; return *this; }
        reference& operator|=(bool value) noexcept { if (value) *word_ |= mask_; return *this; }
        reference& operator^=(bool value) noexcept { if (value) *word_ ^= mask_; return *this; }
    };
    explicit DynamicBitset(std::size_t n = 0, bool value = false) : size_(n), words_(word_count(n), value ? ~std::uint64_t{0} : 0) { mask_tail(); }
    explicit DynamicBitset(std::string_view text) : DynamicBitset(text.size()) {
        for (std::size_t i = 0; i < text.size(); ++i) {
            const char c = text[i];
#ifndef SKIP_RUNTIME_CHECKS
            if (c != '0' && c != '1') throw std::invalid_argument("DynamicBitset binary string");
#endif
            if (c == '1') { const auto pos = text.size() - 1 - i; words_[pos / 64] |= std::uint64_t{1} << (pos % 64); }
        }
    }
    DynamicBitset(const DynamicBitset&) = default;
    DynamicBitset& operator=(const DynamicBitset& other) { if (this != &other) { DynamicBitset copy(other); swap(copy); } return *this; }
    DynamicBitset(DynamicBitset&& other) noexcept { swap(other); }
    DynamicBitset& operator=(DynamicBitset&& other) noexcept { if (this != &other) { clear(); swap(other); } return *this; }
    void swap(DynamicBitset& other) noexcept { std::swap(size_, other.size_); words_.swap(other.words_); }
    friend void swap(DynamicBitset& a, DynamicBitset& b) noexcept { a.swap(b); }
    std::size_t size() const noexcept { return size_; }
    bool empty() const noexcept { return size_ == 0; }
    std::span<const std::uint64_t> words() const noexcept { return words_; }
    bool test(std::size_t pos) const { check_position(pos); return ((words_[pos / 64] >> (pos % 64)) & 1) != 0; }
    bool operator[](std::size_t pos) const { return test(pos); }
    reference operator[](std::size_t pos) { check_position(pos); return reference(words_[pos / 64], std::uint64_t{1} << (pos % 64)); }
    DynamicBitset& set() noexcept { std::fill(words_.begin(), words_.end(), ~std::uint64_t{0}); mask_tail(); return *this; }
    DynamicBitset& reset() noexcept { std::fill(words_.begin(), words_.end(), 0); return *this; }
    DynamicBitset& flip() noexcept { for (auto& word : words_) word = ~word; mask_tail(); return *this; }
    DynamicBitset& set(std::size_t pos, bool value = true) { check_position(pos); const auto mask = std::uint64_t{1} << (pos % 64); if (value) words_[pos / 64] |= mask; else words_[pos / 64] &= ~mask; return *this; }
    DynamicBitset& reset(std::size_t pos) { return set(pos, false); }
    DynamicBitset& flip(std::size_t pos) { check_position(pos); words_[pos / 64] ^= std::uint64_t{1} << (pos % 64); return *this; }
    bool any() const noexcept { for (const auto word : words_) if (word) return true; return false; }
    bool none() const noexcept { return !any(); }
    bool all() const noexcept {
        if (words_.empty()) return true;
        for (std::size_t i = 0; i + 1 < words_.size(); ++i) if (words_[i] != ~std::uint64_t{0}) return false;
        return words_.back() == low_mask(static_cast<unsigned>(size_ % 64 == 0 ? 64 : size_ % 64));
    }
    std::size_t count() const noexcept { return reinsirk::detail::bitset_count_words(words_.data(), words_.size()); }
    std::size_t count(std::size_t l, std::size_t r) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (l > r || r > size_) throw std::out_of_range("DynamicBitset range");
#endif
        if (l == r) return 0;
        const auto first = l / 64, last = (r - 1) / 64;
        const auto left = ~std::uint64_t{0} << (l % 64);
        const auto right = low_mask(static_cast<unsigned>(r % 64 == 0 ? 64 : r % 64));
        if (first == last) return reinsirk::detail::bitset_word_popcount(words_[first] & left & right);
        return reinsirk::detail::bitset_word_popcount(words_[first] & left)
            + reinsirk::detail::bitset_count_words(words_.data() + first + 1, last - first - 1)
            + reinsirk::detail::bitset_word_popcount(words_[last] & right);
    }
    std::size_t intersection_count(const DynamicBitset& other) const { check_length(other); return reinsirk::detail::bitset_intersection_words(words_.data(), other.words_.data(), words_.size()); }
    bool intersection_parity(const DynamicBitset& other) const { check_length(other); return reinsirk::detail::bitset_intersection_parity_words(words_.data(), other.words_.data(), words_.size()); }
    DynamicBitset& operator&=(const DynamicBitset& other) { check_length(other); for (std::size_t i = 0; i < words_.size(); ++i) words_[i] &= other.words_[i]; return *this; }
    DynamicBitset& operator|=(const DynamicBitset& other) { check_length(other); for (std::size_t i = 0; i < words_.size(); ++i) words_[i] |= other.words_[i]; return *this; }
    DynamicBitset& operator^=(const DynamicBitset& other) { check_length(other); for (std::size_t i = 0; i < words_.size(); ++i) words_[i] ^= other.words_[i]; return *this; }
    friend DynamicBitset operator&(DynamicBitset a, const DynamicBitset& b) { a &= b; return a; }
    friend DynamicBitset operator|(DynamicBitset a, const DynamicBitset& b) { a |= b; return a; }
    friend DynamicBitset operator^(DynamicBitset a, const DynamicBitset& b) { a ^= b; return a; }
    friend DynamicBitset operator~(DynamicBitset value) { value.flip(); return value; }
    bool operator==(const DynamicBitset& other) const noexcept { return size_ == other.size_ && words_ == other.words_; }
    DynamicBitset& operator<<=(std::size_t shift) noexcept {
        if (shift >= size_) return reset();
        if (!shift) return *this;
        const auto whole = shift / 64; const auto bits = static_cast<unsigned>(shift % 64);
        for (auto i = words_.size(); i != 0;) { --i; std::uint64_t value = 0;
            if (i >= whole) { value = words_[i - whole] << bits; if (bits && i > whole) value |= words_[i - whole - 1] >> (64 - bits); }
            words_[i] = value;
        }
        mask_tail(); return *this;
    }
    DynamicBitset& operator>>=(std::size_t shift) noexcept {
        if (shift >= size_) return reset();
        if (!shift) return *this;
        const auto whole = shift / 64; const auto bits = static_cast<unsigned>(shift % 64);
        for (std::size_t i = 0; i < words_.size(); ++i) { std::uint64_t value = 0; const auto source = i + whole;
            if (source < words_.size()) { value = words_[source] >> bits; if (bits && source + 1 < words_.size()) value |= words_[source + 1] << (64 - bits); }
            words_[i] = value;
        }
        return *this;
    }
    friend DynamicBitset operator<<(DynamicBitset value, std::size_t shift) { value <<= shift; return value; }
    friend DynamicBitset operator>>(DynamicBitset value, std::size_t shift) { value >>= shift; return value; }
    DynamicBitset& shift_or(std::size_t shift) noexcept {
        if (!shift || shift >= size_) return *this;
        const auto whole = shift / 64; const auto bits = static_cast<unsigned>(shift % 64);
        for (auto i = words_.size(); i != whole;) { --i; auto value = words_[i - whole] << bits;
            if (bits && i > whole) value |= words_[i - whole - 1] >> (64 - bits);
            words_[i] |= value;
        }
        mask_tail(); return *this;
    }
    std::size_t find_first() const noexcept {
        for (std::size_t i = 0; i < words_.size(); ++i) if (words_[i]) return i * 64 + static_cast<unsigned>(std::countr_zero(words_[i]));
        return size_;
    }
    std::size_t find_next(std::size_t pos) const noexcept {
        if (pos >= size_ || ++pos == size_) return size_;
        auto i = pos / 64; const auto word = words_[i] & (~std::uint64_t{0} << (pos % 64));
        if (word) return i * 64 + static_cast<unsigned>(std::countr_zero(word));
        while (i < words_.size() - 1) { ++i; if (words_[i]) return i * 64 + static_cast<unsigned>(std::countr_zero(words_[i])); }
        return size_;
    }
    std::size_t find_prev(std::size_t pos) const noexcept {
        pos = std::min(pos, size_); if (!pos) return size_; --pos;
        auto i = pos / 64; const auto word = words_[i] & low_mask(static_cast<unsigned>(pos % 64 + 1));
        if (word) return i * 64 + 63 - static_cast<unsigned>(std::countl_zero(word));
        while (i) { --i; if (words_[i]) return i * 64 + 63 - static_cast<unsigned>(std::countl_zero(words_[i])); }
        return size_;
    }
    std::size_t find_last() const noexcept { return find_prev(size_); }
    void reserve_bits(std::size_t n) { words_.reserve(word_count(n)); }
    void resize(std::size_t n, bool value = false) {
        const auto old = size_; words_.resize(word_count(n), value ? ~std::uint64_t{0} : 0);
        if (n > old && value && old % 64) words_[old / 64] |= ~std::uint64_t{0} << (old % 64);
        size_ = n; mask_tail();
    }
    void clear() noexcept { words_.clear(); size_ = 0; }
    std::string to_string() const {
        std::string result(size_, '0');
        for (std::size_t i = 0; i < size_; ++i) if ((words_[i / 64] >> (i % 64)) & 1) result[size_ - 1 - i] = '1';
        return result;
    }
};
#endif
// Definitions: Math/Binary_Matrix.cpp
#line 32 "Variants/GCC/Math/Binary_Matrix.cpp"
#include <algorithm>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>
#if (!defined(SIRKIT_DISABLE_SIMD)) && ((defined(__x86_64__)) || (defined(__i386__)))
#include <immintrin.h>
#endif

#ifndef SIRKIT_DYNAMIC_BITSET_WORD_OPERATIONS_DEFINED
#define SIRKIT_DYNAMIC_BITSET_WORD_OPERATIONS_DEFINED
namespace reinsirk::detail {
inline unsigned bitset_word_popcount(std::uint64_t x) noexcept {
    x -= (x >> 1) & UINT64_C(0x5555555555555555);
    x = (x & UINT64_C(0x3333333333333333)) + ((x >> 2) & UINT64_C(0x3333333333333333));
    x = (x + (x >> 4)) & UINT64_C(0x0f0f0f0f0f0f0f0f);
    return static_cast<unsigned>((x * UINT64_C(0x0101010101010101)) >> 56);
}
inline std::size_t bitset_count_words_scalar(const std::uint64_t* words, std::size_t count) noexcept {
    std::size_t result = 0;
    for (std::size_t i = 0; i < count; ++i) result += bitset_word_popcount(words[i]);
    return result;
}
inline std::size_t bitset_intersection_words_scalar(const std::uint64_t* a, const std::uint64_t* b, std::size_t count) noexcept {
    std::size_t result = 0;
    for (std::size_t i = 0; i < count; ++i) result += bitset_word_popcount(a[i] & b[i]);
    return result;
}
inline bool bitset_intersection_parity_words_scalar(const std::uint64_t* a, const std::uint64_t* b, std::size_t count) noexcept {
    std::uint64_t value = 0;
    for (std::size_t i = 0; i < count; ++i) value ^= a[i] & b[i];
    return (bitset_word_popcount(value) & 1) != 0;
}

#if (!defined(SIRKIT_DISABLE_SIMD)) && ((defined(__x86_64__)) || (defined(__i386__)))

__attribute__((target("popcnt"))) inline std::size_t bitset_count_words_popcnt(const std::uint64_t* a,std::size_t n) noexcept {
    std::size_t s0=0,s1=0,s2=0,s3=0,i=0;
    for(;n-i>=4;i+=4){s0+=static_cast<unsigned>(__builtin_popcountll(a[i]));s1+=static_cast<unsigned>(__builtin_popcountll(a[i+1]));s2+=static_cast<unsigned>(__builtin_popcountll(a[i+2]));s3+=static_cast<unsigned>(__builtin_popcountll(a[i+3]));}
    for(;i<n;++i)s0+=static_cast<unsigned>(__builtin_popcountll(a[i]));
    return s0+s1+s2+s3;
}
__attribute__((target("popcnt"))) inline std::size_t bitset_intersection_words_popcnt(const std::uint64_t* a,const std::uint64_t* b,std::size_t n) noexcept {
    std::size_t s0=0,s1=0,s2=0,s3=0,i=0;
    for(;n-i>=4;i+=4){s0+=static_cast<unsigned>(__builtin_popcountll(a[i]&b[i]));s1+=static_cast<unsigned>(__builtin_popcountll(a[i+1]&b[i+1]));s2+=static_cast<unsigned>(__builtin_popcountll(a[i+2]&b[i+2]));s3+=static_cast<unsigned>(__builtin_popcountll(a[i+3]&b[i+3]));}
    for(;i<n;++i)s0+=static_cast<unsigned>(__builtin_popcountll(a[i]&b[i]));
    return s0+s1+s2+s3;
}
__attribute__((target("avx2,popcnt"))) inline std::size_t bitset_count_words_avx2(const std::uint64_t* a,std::size_t n) noexcept {
    const auto table=_mm256_setr_epi8(0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4,0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4);
    const auto mask=_mm256_set1_epi8(15),zero=_mm256_setzero_si256();auto total=zero;std::size_t i=0;
    for(;n-i>=4;i+=4){const auto x=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a+i));const auto lo=_mm256_shuffle_epi8(table,_mm256_and_si256(x,mask));const auto hi=_mm256_shuffle_epi8(table,_mm256_and_si256(_mm256_srli_epi16(x,4),mask));total=_mm256_add_epi64(total,_mm256_sad_epu8(_mm256_add_epi8(lo,hi),zero));}
    alignas(32) std::uint64_t lanes[4];_mm256_store_si256(reinterpret_cast<__m256i*>(lanes),total);auto result=lanes[0]+lanes[1]+lanes[2]+lanes[3];
    for(;i<n;++i)result+=static_cast<unsigned>(__builtin_popcountll(a[i]));
    return static_cast<std::size_t>(result);
}
__attribute__((target("avx2,popcnt"))) inline std::size_t bitset_intersection_words_avx2(const std::uint64_t* a,const std::uint64_t* b,std::size_t n) noexcept {
    const auto table=_mm256_setr_epi8(0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4,0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4);
    const auto mask=_mm256_set1_epi8(15),zero=_mm256_setzero_si256();auto total=zero;std::size_t i=0;
    for(;n-i>=4;i+=4){const auto x=_mm256_and_si256(_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a+i)),_mm256_loadu_si256(reinterpret_cast<const __m256i*>(b+i)));const auto lo=_mm256_shuffle_epi8(table,_mm256_and_si256(x,mask));const auto hi=_mm256_shuffle_epi8(table,_mm256_and_si256(_mm256_srli_epi16(x,4),mask));total=_mm256_add_epi64(total,_mm256_sad_epu8(_mm256_add_epi8(lo,hi),zero));}
    alignas(32) std::uint64_t lanes[4];_mm256_store_si256(reinterpret_cast<__m256i*>(lanes),total);auto result=lanes[0]+lanes[1]+lanes[2]+lanes[3];
    for(;i<n;++i)result+=static_cast<unsigned>(__builtin_popcountll(a[i]&b[i]));
    return static_cast<std::size_t>(result);
}

__attribute__((target("avx2,popcnt"), noinline)) inline std::size_t bitset_parity_words_avx2(const std::uint64_t* a,const std::uint64_t* b,std::size_t n)noexcept {
    auto total=_mm256_setzero_si256();std::size_t i=0;
    for(;n-i>=4;i+=4)total=_mm256_xor_si256(total,_mm256_and_si256(_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a+i)),_mm256_loadu_si256(reinterpret_cast<const __m256i*>(b+i))));
    alignas(32)std::uint64_t lanes[4];_mm256_store_si256(reinterpret_cast<__m256i*>(lanes),total);auto value=lanes[0]^lanes[1]^lanes[2]^lanes[3];
    for(;i<n;++i)value^=a[i]&b[i];
    return static_cast<unsigned>(__builtin_popcountll(value))&1;
}

inline unsigned bitset_cpu_features() noexcept {
    static const unsigned features = (__builtin_cpu_supports("popcnt") ? 1U : 0U) | (__builtin_cpu_supports("avx2") ? 2U : 0U);
    return features;
}
#endif
inline std::size_t bitset_count_words(const std::uint64_t* words, std::size_t count) noexcept {
#if (!defined(SIRKIT_DISABLE_SIMD)) && ((defined(__x86_64__)) || (defined(__i386__)))
    if (count >= 4) {
        const auto features = bitset_cpu_features();
        if (count >= 64 && features == 3) return bitset_count_words_avx2(words, count);
        if (features & 1) return bitset_count_words_popcnt(words, count);
    }
#endif
    return bitset_count_words_scalar(words, count);
}
inline std::size_t bitset_intersection_words(const std::uint64_t* a, const std::uint64_t* b, std::size_t count) noexcept {
#if (!defined(SIRKIT_DISABLE_SIMD)) && ((defined(__x86_64__)) || (defined(__i386__)))
    if (count >= 4) {
        const auto features = bitset_cpu_features();
        if (count >= 64 && features == 3) return bitset_intersection_words_avx2(a, b, count);
        if (features & 1) return bitset_intersection_words_popcnt(a, b, count);
    }
#endif
    return bitset_intersection_words_scalar(a, b, count);
}
inline bool bitset_intersection_parity_words(const std::uint64_t* a, const std::uint64_t* b, std::size_t count) noexcept {
#if (!defined(SIRKIT_DISABLE_SIMD)) && ((defined(__x86_64__)) || (defined(__i386__)))
    if (count >= 64 && bitset_cpu_features() == 3) return bitset_parity_words_avx2(a, b, count) != 0;
#endif
    return bitset_intersection_parity_words_scalar(a, b, count);
}
}
#endif

#include <optional>

#ifndef SIRKIT_BINARY_MATRIX_DEFINED
#define SIRKIT_BINARY_MATRIX_DEFINED
class BinaryMatrix {
public:
    struct LinearSolution;
private:
    std::size_t rows_ = 0, cols_ = 0, stride_ = 0;
    std::vector<std::uint64_t> data_;
    static std::size_t stride_for(std::size_t cols) noexcept { return cols / 64 + (cols % 64 != 0); }
    static std::size_t storage_size(std::size_t rows, std::size_t stride) {
        const auto limit = std::vector<std::uint64_t>().max_size();
        if (stride && rows > limit / stride) throw std::length_error("BinaryMatrix capacity");
        return rows * stride;
    }
    void check_row(std::size_t row) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (row >= rows_) throw std::out_of_range("BinaryMatrix row");
#else
        (void)row;
#endif
    }
    void check_position(std::size_t row, std::size_t col) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (row >= rows_ || col >= cols_) throw std::out_of_range("BinaryMatrix position");
#else
        (void)row; (void)col;
#endif
    }
    void check_same_shape(const BinaryMatrix& other) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (rows_ != other.rows_ || cols_ != other.cols_) throw std::invalid_argument("BinaryMatrix shape");
#else
        (void)other;
#endif
    }
    void check_square() const {
#ifndef SKIP_RUNTIME_CHECKS
        if (rows_ != cols_) throw std::invalid_argument("BinaryMatrix square");
#endif
    }
    void xor_suffix(std::size_t target, std::size_t source, std::size_t first_word) noexcept {
        const auto t = target * stride_, s = source * stride_;
        for (std::size_t word = first_word; word < stride_; ++word) data_[t + word] ^= data_[s + word];
    }
    static std::size_t eliminate(BinaryMatrix& work, BinaryMatrix* companion,
                                             std::vector<std::uint8_t>* rhs, bool reduced, std::vector<std::size_t>* pivots = nullptr) {
        if (pivots) pivots->reserve(std::min(work.rows_, work.cols_));
        if (!work.rows_ || !work.cols_) return 0;
        std::size_t rank = 0;
        for (std::size_t col = 0; col < work.cols_ && rank < work.rows_; ++col) {
            const auto word = col / 64, mask = std::uint64_t{1} << (col % 64);
            auto pivot = rank;
            while (pivot < work.rows_ && !(work.data_[pivot * work.stride_ + word] & mask)) ++pivot;
            if (pivot == work.rows_) continue;
            work.swap_rows(rank, pivot);
            if (companion) companion->swap_rows(rank, pivot);
            if (rhs) std::swap((*rhs)[rank], (*rhs)[pivot]);
            const auto first = reduced ? std::size_t{0} : rank + 1;
            for (auto row = first; row < work.rows_; ++row) if (row != rank && (work.data_[row * work.stride_ + word] & mask)) {
                // pivot行のそれ以前の列は0なのでword途中からでも既存pivotを壊さない。
                work.xor_suffix(row, rank, word);
                if (companion) companion->xor_suffix(row, rank, 0);
                if (rhs) (*rhs)[row] ^= (*rhs)[rank];
            }
            if (pivots) pivots->push_back(col);
            ++rank;
        }
        return rank;
    }
public:
    explicit BinaryMatrix(std::size_t rows = 0, std::size_t cols = 0)
        : rows_(rows), cols_(cols), stride_(stride_for(cols)), data_(storage_size(rows, stride_)) {}
    BinaryMatrix(const BinaryMatrix&) = default;
    BinaryMatrix& operator=(const BinaryMatrix& other) { if (this != &other) { BinaryMatrix copy(other); swap(copy); } return *this; }
    BinaryMatrix(BinaryMatrix&& other) noexcept { swap(other); }
    BinaryMatrix& operator=(BinaryMatrix&& other) noexcept { if (this != &other) { clear(); swap(other); } return *this; }
    void swap(BinaryMatrix& other) noexcept { std::swap(rows_, other.rows_); std::swap(cols_, other.cols_); std::swap(stride_, other.stride_); data_.swap(other.data_); }
    friend void swap(BinaryMatrix& a, BinaryMatrix& b) noexcept { a.swap(b); }
    std::size_t rows() const noexcept { return rows_; }
    std::size_t cols() const noexcept { return cols_; }
    bool empty() const noexcept { return !rows_ || !cols_; }
    std::span<const std::uint64_t> row_words(std::size_t row) const {
        check_row(row); if (!stride_) return {};
        return std::span<const std::uint64_t>(data_).subspan(row * stride_, stride_);
    }
    bool test(std::size_t row, std::size_t col) const { check_position(row, col); return ((data_[row * stride_ + col / 64] >> (col % 64)) & 1) != 0; }
    bool operator()(std::size_t row, std::size_t col) const { return test(row, col); }
    BinaryMatrix& set(std::size_t row, std::size_t col, bool value = true) {
        check_position(row, col); auto& word = data_[row * stride_ + col / 64]; const auto mask = std::uint64_t{1} << (col % 64);
        if (value) word |= mask; else word &= ~mask; return *this;
    }
    BinaryMatrix& flip(std::size_t row, std::size_t col) { check_position(row, col); data_[row * stride_ + col / 64] ^= std::uint64_t{1} << (col % 64); return *this; }
    void swap_rows(std::size_t a, std::size_t b) {
        check_row(a); check_row(b); if (a == b) return;
        for (std::size_t word = 0; word < stride_; ++word) std::swap(data_[a * stride_ + word], data_[b * stride_ + word]);
    }
    void xor_rows(std::size_t target, std::size_t source, std::size_t first_col = 0) {
        check_row(target); check_row(source);
#ifndef SKIP_RUNTIME_CHECKS
        if (first_col > cols_) throw std::out_of_range("BinaryMatrix first column");
#endif
        if (first_col == cols_) return;
        const auto first_word = first_col / 64;
        data_[target * stride_ + first_word] ^= data_[source * stride_ + first_word] & (~std::uint64_t{0} << (first_col % 64));
        xor_suffix(target, source, first_word + 1);
    }
    static BinaryMatrix identity(std::size_t n) { BinaryMatrix result(n, n); for (std::size_t i = 0; i < n; ++i) result.data_[i * result.stride_ + i / 64] |= std::uint64_t{1} << (i % 64); return result; }
    BinaryMatrix transpose() const {
        BinaryMatrix result(cols_, rows_); if (empty()) return result;
        for (std::size_t row = 0; row < rows_; ++row) for (std::size_t col = 0; col < cols_; ++col)
            if ((data_[row * stride_ + col / 64] >> (col % 64)) & 1) result.data_[col * result.stride_ + row / 64] |= std::uint64_t{1} << (row % 64);
        return result;
    }
    BinaryMatrix multiply(const BinaryMatrix& other) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (cols_ != other.rows_) throw std::invalid_argument("BinaryMatrix product shape");
#endif
        BinaryMatrix result(rows_, other.cols_); if (!rows_ || !cols_ || !other.cols_) return result;
        const auto transposed = other.transpose();
        for (std::size_t row = 0; row < rows_; ++row) for (std::size_t col = 0; col < other.cols_; ++col)
            if (reinsirk::detail::bitset_intersection_parity_words(data_.data() + row * stride_, transposed.data_.data() + col * transposed.stride_, stride_))
                result.data_[row * result.stride_ + col / 64] |= std::uint64_t{1} << (col % 64);
        return result;
    }
    BinaryMatrix operator*(const BinaryMatrix& other) const { return multiply(other); }
    BinaryMatrix& operator*=(const BinaryMatrix& other) { auto result = multiply(other); swap(result); return *this; }
    BinaryMatrix& operator+=(const BinaryMatrix& other) { check_same_shape(other); for (std::size_t i = 0; i < data_.size(); ++i) data_[i] ^= other.data_[i]; return *this; }
    BinaryMatrix& operator^=(const BinaryMatrix& other) { return *this += other; }
    friend BinaryMatrix operator+(BinaryMatrix a, const BinaryMatrix& b) { a += b; return a; }
    friend BinaryMatrix operator^(BinaryMatrix a, const BinaryMatrix& b) { a ^= b; return a; }
    bool operator==(const BinaryMatrix& other) const noexcept { return rows_ == other.rows_ && cols_ == other.cols_ && data_ == other.data_; }
    BinaryMatrix pow(std::uint64_t exponent) const {
        check_square(); auto result = identity(rows_); if (!exponent || !rows_) return result;
        auto base = *this;
        while (exponent) { if (exponent & 1) result *= base; exponent >>= 1; if (exponent) base *= base; }
        return result;
    }
    std::size_t rank() const { auto work = *this; return eliminate(work, nullptr, nullptr, false); }
    bool determinant() const { check_square(); return rank() == rows_; }
    std::optional<BinaryMatrix> inverse() const {
        check_square(); auto work = *this, result = identity(rows_);
        if (eliminate(work, &result, nullptr, true) != rows_) return std::nullopt;
        return result;
    }
    std::optional<LinearSolution> solve(std::span<const std::uint8_t> rhs) const;
    void reset(std::size_t rows = 0, std::size_t cols = 0) { BinaryMatrix next(rows, cols); swap(next); }
    void clear() noexcept { data_.clear(); rows_ = cols_ = stride_ = 0; }
};

struct BinaryMatrix::LinearSolution {
    std::vector<std::uint8_t> particular;
    BinaryMatrix kernel;
    std::vector<std::size_t> pivot_columns;
    LinearSolution() = default;
    LinearSolution(std::vector<std::uint8_t> value, BinaryMatrix basis, std::vector<std::size_t> pivots)
        : particular(std::move(value)), kernel(std::move(basis)), pivot_columns(std::move(pivots)) {}
    LinearSolution(const LinearSolution&) = default;
    LinearSolution& operator=(const LinearSolution& other) { if (this != &other) { LinearSolution copy(other); swap(copy); } return *this; }
    LinearSolution(LinearSolution&& other) noexcept { swap(other); }
    LinearSolution& operator=(LinearSolution&& other) noexcept {
        if (this != &other) { particular.clear(); kernel.clear(); pivot_columns.clear(); swap(other); } return *this;
    }
    void swap(LinearSolution& other) noexcept { particular.swap(other.particular); kernel.swap(other.kernel); pivot_columns.swap(other.pivot_columns); }
    friend void swap(LinearSolution& a, LinearSolution& b) noexcept { a.swap(b); }
};

inline std::optional<BinaryMatrix::LinearSolution> BinaryMatrix::solve(std::span<const std::uint8_t> rhs) const {
#ifndef SKIP_RUNTIME_CHECKS
    if (rhs.size() != rows_) throw std::invalid_argument("BinaryMatrix rhs length");
#endif
    if (!cols_) {
        for (std::size_t row = 0; row < rows_; ++row) {
#ifndef SKIP_RUNTIME_CHECKS
            if (rhs[row] > 1) throw std::invalid_argument("BinaryMatrix rhs bit");
#endif
            if (rhs[row]) return std::nullopt;
        }
        return LinearSolution{};
    }
    std::vector<std::uint8_t> values(rows_);
    for (std::size_t i = 0; i < rows_; ++i) {
#ifndef SKIP_RUNTIME_CHECKS
        if (rhs[i] > 1) throw std::invalid_argument("BinaryMatrix rhs bit");
#endif
        values[i] = rhs[i];
    }
    auto work = *this; std::vector<std::size_t> pivots; const auto rank = eliminate(work, nullptr, &values, true, &pivots);
    for (auto row = rank; row < rows_; ++row) if (values[row]) return std::nullopt;
    LinearSolution result{std::vector<std::uint8_t>(cols_), BinaryMatrix(cols_ - rank, cols_), std::move(pivots)};
    for (std::size_t row = 0; row < rank; ++row) result.particular[result.pivot_columns[row]] = values[row];
    std::size_t pivot = 0, basis = 0;
    for (std::size_t col = 0; col < cols_; ++col) {
        if (pivot < rank && result.pivot_columns[pivot] == col) { ++pivot; continue; }
        result.kernel.set(basis, col);
        for (std::size_t row = 0; row < rank; ++row) if (work.test(row, col)) result.kernel.set(basis, result.pivot_columns[row]);
        ++basis;
    }
    return result;
}
#endif
