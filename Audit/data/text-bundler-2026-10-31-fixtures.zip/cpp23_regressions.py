# SPDX-License-Identifier: CC0-1.0
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT / 'staged/Scripts'))
import bundle_libraries as bundle

GUARD = '#ifndef SIRKIT_A_DEFINED\n#define SIRKIT_A_DEFINED\nint first;\n{branch}\nint alternate;\n#endif\n'
rows = []
for branch in ('#elifdef ENABLE', '#elifndef DISABLE'):
    source = GUARD.format(branch=branch)
    modules = [dict(library=f'Math/{i}.cpp', source=f'Math/{i}.cpp', data=source.encode()) for i in range(2)]
    before, _ = bundle.optimize_modules(modules, deduplicate=False)
    after, report = bundle.optimize_modules(modules)
    assert not report['removals']
    for compiler in (['/usr/bin/g++'], ['/usr/bin/clang++', '--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']):
        command = ['taskset', '-c', '0'] + compiler + ['-std=c++23', '-DENABLE', '-E', '-P', '-x', 'c++', '-']
        a = subprocess.run(command, input=before, capture_output=True, timeout=30)
        b = subprocess.run(command, input=after, capture_output=True, timeout=30)
        assert a.returncode == b.returncode == 0, (a.stderr, b.stderr)
        assert a.stdout == b.stdout and b'int alternate;' in a.stdout
        rows.append(dict(branch=branch, command=command, status='PASS', before_sha256=bundle.digest(before), after_sha256=bundle.digest(after), preprocessed_sha256=bundle.digest(a.stdout), output=a.stdout.decode()))
(ROOT / 'cpp23_regressions.json').write_text(json.dumps(rows, indent=2) + '\n')
print(len(rows), 'compiler counterexamples PASS')
