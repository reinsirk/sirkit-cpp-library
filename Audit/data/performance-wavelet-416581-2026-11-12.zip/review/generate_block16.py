# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import re,hashlib,json,difflib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_wavelet_416581/review');base=(R/'DataStructure/Wavelet_Matrix.cpp').read_text();expected='cb678711a0a132cd685259a4f00c5a30204156c582b51030f87c5c1b3ae725a2';assert hashlib.sha256(base.encode()).hexdigest()==expected;(D/'base.hpp').write_text(base)
a=base.index('class WaveletRankBits {');b=base.index('\n};\n}\n#endif',a)+len('\n};');part=base[a:b]
old='''    std::vector<std::uint64_t> words_;
    std::vector<std::uint32_t> prefix_;
public:
    explicit WaveletRankBits(std::size_t count) : words_(count / 64 + (count % 64 != 0)) {}
'''
new='''    struct alignas(16) Block {
        std::uint64_t bits = 0;
        std::uint32_t prefix = 0;
        std::uint32_t padding = 0;
    };
    static_assert(sizeof(Block) == 16);
    std::vector<Block> blocks_;
public:
    explicit WaveletRankBits(std::size_t count)
        : blocks_(count / 64 + (count % 64 != 0) + 1) {}
'''
assert part.count(old)==1;part=part.replace(old,new)
part=part.replace('        prefix_.resize(words_.size() + 1);\n','')
part=part.replace('words_.size()','(blocks_.size() - 1)')
part=part.replace('prefix_.back()','blocks_.back().prefix')
part=re.sub(r'\bwords_\[([^\]]+)\]',r'blocks_[\1].bits',part)
part=re.sub(r'\bprefix_\[([^\]]+)\]',r'blocks_[\1].prefix',part)
# Replace the two branches by same-block prefix and bits reads. The extra zero block covers end%64==0 at n.
for popcount in ['std::popcount','wavelet_popcount']:
 old='''        const auto offset = end & 63;
        // endが64の倍数ならwords_[end/64]を読まない。end==nも含む。
        return blocks_[end >> 6].prefix + (offset == 0 ? 0 :
            static_cast<std::size_t>('''+popcount+'''(blocks_[end >> 6].bits & ((std::uint64_t{1} << offset) - 1))));'''
 new='''        const auto offset = end & 63;
        // 最後のゼロblockで、end==nの64境界も同じ式で扱う。
        const auto& block = blocks_[end >> 6];
        return block.prefix + static_cast<std::size_t>('''+popcount+'''(
            block.bits & ((std::uint64_t{1} << offset) - 1)));'''
 assert part.count(old)==1,(popcount,part[-1600:]);part=part.replace(old,new)
assert 'words_'not in part and 'prefix_'not in part
s=base[:a]+part+base[b:];p=D/'block16.hpp';p.write_text(s)
(D/'block16.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='Wavelet_Matrix.cpp',tofile='block16.hpp')))
(D/'block16_metadata.json').write_text(json.dumps(dict(base_sha256=expected,candidate_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),block_bytes=16,old_payload_bytes='12*W+4',new_payload_bytes='16*(W+1)',payload_increase='(4*W+12)/(12*W+4), tends to 33.333%',old_rank_object_bytes_on_x86_64=48,new_rank_object_bytes_on_x86_64=24,public_API_changed=False),indent=2)+'\n');print(hashlib.sha256(p.read_bytes()).hexdigest())
