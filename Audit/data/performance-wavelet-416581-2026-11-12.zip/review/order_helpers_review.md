# rankのガード順と早期終了位置

原本は今回の開始時スナップショット cb678711a0a132cd685259a4f00c5a30204156c582b51030f87c5c1b3ae725a2。正本、main、格納、構築、kth、ほかの公開APIは変更しない。性能の主張は行わず親のP-Core比較に委ねる。

## order_helpers.hpp

既定のcheck_rangeを最初に呼ぶ点を維持し、その後に目的値の上下限判定、空区間判定を別のifとして置く。従来のORで結んだ3条件と同じ条件集合なので、どれかを満たす場合も満たさない場合も戻り値は同じ。orderedは副作用のない符号順変換であり、範囲外valueでも元配列を参照しない。無効区間に目的値の範囲外判定を先行させて検査を迂回することはない。

## span_guard.hpp

空区間を最初に返す。Uの値域を0..M（M=2^digits-1）とし、base<=maximumを使う。code=U(key-base)、span=U(maximum-base)とすると、keyが[base,maximum]に含まれることとcode<=spanは同値。

key>=baseなら差は巡回せず、code<=spanはkey<=maximumに一致する。key<baseならcode=M+1+key-base>=M+1-baseだが、span=maximum-base<=M-baseなので必ずcode>spanになる。base=0、maximum=Mの全幅も正しく扱う。

8/16bitのUでは減算がintへ整数昇格しても差はintの範囲内であり、明示したstatic_cast<U>が規格どおり巡回変換する。32/64bitはunsignedの減算である。符号付きオーバーフローや幅以上のshiftを追加しない。空の既定構築/move元はbase=maximum=0で、空区間の早期returnも同じ。B=0/1、既存のB<=8またはn<=128の経路、StopWhenEmptyの選択は変更しない。

## span_begin.hpp

span_guardに加え、rank_code<true>のleft==right判定を各段の末尾から先頭へ移す。元区間は公開rankの空区間ガードを通過している。非空が続けば同じrankと遷移を行う。途中で空になった場合、元はその段の末尾、新方式は次の段の先頭で0を返すため、追加のrank1アクセスはしない。最後の段で空になった場合はループ終了後のright-leftが0。rank_code<false>ではif constexprで判定自体が消え、従来どおり全段を走査する。

いずれも既定の区間検査とSKIPでの除外、CPUのPOPCNT/AVX2選択、標準経路、所有権と例外保証、全符号範囲、件数/容量上限を維持する。新しい配列走査や状態、動的確保、new式、公開API、入力分布による切替を追加しない。

独立参照テストをGCC/Clang・検査有効/SKIPの4条件ずつで実行する。候補と試験のSHA、コマンド、結果はorder_helpers_validation.jsonへ保存する。コンパイルと試験はCPU8に固定し、性能測定との重複を共通CPU12 lockで防ぐ。性能測定は行わない。
