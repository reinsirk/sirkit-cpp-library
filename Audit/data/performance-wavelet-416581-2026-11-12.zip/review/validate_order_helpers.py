# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import fcntl,subprocess,json,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_wavelet_416581/review');test=R/'Verify/current/tests/wavelet_matrix_reference_test.cpp';rows=[]
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for label in ['order_helpers','span_guard','span_begin']:
  h=D/(label+'.hpp')
  for cc,args in [('gcc',['g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
   for setting in ['checked','skip']:
    exe=D/f'{cc}_{setting}_{label}_ref';cmd=['taskset','-c','8',*args,'-std=c++23','-O2',*(['-DSKIP_RUNTIME_CHECKS']if setting=='skip'else[]),f'-DWAVELET_SOURCE="{h}"',str(test),'-o',str(exe)]
    p=subprocess.run(cmd,capture_output=True,text=True);row=dict(label=label,compiler=cc,setting=setting,command=cmd,header_sha256=hashlib.sha256(h.read_bytes()).hexdigest(),test_sha256=hashlib.sha256(test.read_bytes()).hexdigest(),compile_returncode=p.returncode,compile_stderr=p.stderr);rows.append(row)
    if p.returncode==0:
     p=subprocess.run(['taskset','-c','8',str(exe)],capture_output=True,text=True);row.update(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,passed=p.returncode==0 and not p.stderr and 'checks='in p.stdout)
    else:row['passed']=False
    (D/'order_helpers_validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,cc,setting,row['passed'],row.get('stdout','').strip(),flush=True);assert row['passed'],row
print('12 reference jobs PASS; no more compilation',flush=True)
