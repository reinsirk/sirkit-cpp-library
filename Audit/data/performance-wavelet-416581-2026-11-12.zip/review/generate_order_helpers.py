# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import difflib,hashlib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_wavelet_416581');O=D/'review'
base=(D/'before/DataStructure/Wavelet_Matrix.cpp').read_text();assert hashlib.sha256(base.encode()).hexdigest()=='cb678711a0a132cd685259a4f00c5a30204156c582b51030f87c5c1b3ae725a2'
(O/'base.hpp').write_text(base)
old='''        const U key = ordered(value);
        if (left == right || key < base_ || key > maximum_) return 0;
        const U code = static_cast<U>(key - base_);
'''
assert base.count(old)==1
variants={
'order_helpers':'''        const U key = ordered(value);
        if (key < base_ || key > maximum_) return 0;
        if (left == right) return 0;
        const U code = static_cast<U>(key - base_);
''',
'span_guard':'''        if (left == right) return 0;
        const U code = static_cast<U>(ordered(value) - base_);
        if (code > static_cast<U>(maximum_ - base_)) return 0;
'''}
outputs={k:base.replace(old,v)for k,v in variants.items()}
s=outputs['span_guard'];oldloop='''        for (unsigned depth = 0; depth < bits_; ++depth) {
            const auto a = levels_[depth].rank1(left), b = levels_[depth].rank1(right);
            if ((code >> (bits_ - 1 - depth)) & U{1}) { left = zero_[depth] + a; right = zero_[depth] + b; }
            else { left -= a; right -= b; }
            if constexpr (StopWhenEmpty) { if (left == right) return 0; }
        }
'''
newloop='''        for (unsigned depth = 0; depth < bits_; ++depth) {
            if constexpr (StopWhenEmpty) { if (left == right) return 0; }
            const auto a = levels_[depth].rank1(left), b = levels_[depth].rank1(right);
            if ((code >> (bits_ - 1 - depth)) & U{1}) { left = zero_[depth] + a; right = zero_[depth] + b; }
            else { left -= a; right -= b; }
        }
'''
assert s.count(oldloop)==1;outputs['span_begin']=s.replace(oldloop,newloop)
rows=[]
for label,text in outputs.items():
 p=O/(label+'.hpp');p.write_text(text);(O/(label+'.diff')).write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='base.hpp',tofile=label+'.hpp')))
 rows.append(dict(label=label,base_sha256=hashlib.sha256(base.encode()).hexdigest(),candidate_sha256=hashlib.sha256(text.encode()).hexdigest(),source=str(p),public_API_changed=False,construction_or_storage_changed=False))
(O/'order_helpers_metadata.json').write_text(json.dumps(rows,indent=2)+'\n')
print('3 candidate headers saved')
