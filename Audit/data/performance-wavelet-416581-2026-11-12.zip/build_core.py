# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,json,subprocess,hashlib
D=Path('/tmp/sirkit_wavelet_416581');rows=[]
for label in sys.argv[1:]:
 cmd=['taskset','-c','4','g++','-std=c++23','-O2','-march=native','-DSKIP_RUNTIME_CHECKS',f'-DHEADER="{D}/{label}.hpp"',str(D/'core.cpp'),'-o',str(D/f'gcc_native_skip_{label}_core')];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;rows.append(dict(label=label,command=cmd));print(label,'core build PASS',flush=True)
p=D/'core_builds.json';old=json.loads(p.read_text())if p.exists()else[];p.write_text(json.dumps(old+rows,indent=2)+'\n')
