# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import bench,json,fcntl
D=Path('/tmp/sirkit_wavelet_416581');rows=[]
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for flag in ['native','default','disabled']:
   for label in ['base','final']:
    for f in bench.fixtures:
     r=bench.run_whole(cc,label,f,flag);rows.append(dict(compiler=cc,flag=flag,label=label,fixture=f['id'],output_sha256=r['output_sha256'],passed=True))
   print(cc,flag,'56 fixture outputs PASS',flush=True)
(D/'final_fixture_validation.json').write_text(json.dumps(dict(all_passed=True,count=len(rows),rows=rows),indent=2)+'\n')
