# SPDX-License-Identifier: CC0-1.0
# 実行時に選ばれたfinal.hppだけを検証する。性能測定との重複を共通lockで防ぐ。
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse,datetime,fcntl,hashlib,json,os,re,subprocess,threading
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_wavelet_416581')
COMPILERS={'gcc':(['/usr/bin/g++'],4),'clang':(['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'],6)}
TESTS={'reference':R/'Verify/current/tests/wavelet_matrix_reference_test.cpp','second_reference':R/'Verify/current/tests/wavelet_matrix_second_reference_test.cpp','all_widths':R/'Verify/current/tests/wavelet_matrix_all_widths_test.cpp','allocation':R/'Verify/current/tests/wavelet_matrix_allocation_test.cpp'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def encode(v):return json.dumps(v,ensure_ascii=False,indent=2)+'\n'
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--omit-threshold',action='store_true');args=parser.parse_args()
 # コンパイラと試験の全実行期間をlockする。呼出し元は他の性能測定を停止する必要がない。
 with open('/tmp/sirkit_performance_cpu12.lock','a')as global_lock:
  fcntl.flock(global_lock,fcntl.LOCK_EX)
  header=D/'final.hpp';assert header.is_file(),'採用版を先にfinal.hppへ保存する'
  header_hash=sha(header);text=header.read_text()
  for guard in ['SIRKIT_WAVELET_POPCOUNT_DEFINED','SIRKIT_WAVELET_RANK_BITS_DEFINED','SIRKIT_WAVELET_MATRIX_DEFINED']:assert '#define '+guard in text,guard
  cpu_false=D/'validation_cpu_false.hpp';counts={}
  for feature in ['popcnt','avx2']:
   needle=f'__builtin_cpu_supports("{feature}")';counts[feature]=text.count(needle);assert counts[feature]==1,(feature,counts)
   text=text.replace(needle,'0')
  temporary=cpu_false.with_name(cpu_false.name+'.tmp');temporary.write_text(text);temporary.replace(cpu_false)
  false_hash=sha(cpu_false);jobs=[]
  for cc in COMPILERS:
   for setting in ['checked','skip']:
    for mode in ['default','disabled','cpu_false']:
     for name,source in TESTS.items():jobs.append(dict(compiler=cc,setting=setting,mode=mode,short_test=name,test=source.stem,source=str(source),sanitizer=False))
    for mode in ['default','disabled']:jobs.append(dict(compiler=cc,setting=setting,mode=mode,short_test='reference',test=TESTS['reference'].stem,source=str(TESTS['reference']),sanitizer=True))
  threshold=D/'review/narrow_threshold.cpp'
  if threshold.is_file()and not args.omit_threshold:
   # この試験のnarrow.hppは後からincludeされる。-include final.hppで先に全共通guardを定義する。
   assert '#include "narrow.hpp"'in threshold.read_text()
   for cc in COMPILERS:
    for mode in ['default','disabled']:jobs.append(dict(compiler=cc,setting='checked',mode=mode,short_test='narrow_threshold',test=threshold.stem,source=str(threshold),sanitizer=False,override_note='-include chosen header defines every Wavelet component guard before hardcoded narrow.hpp'))
  out=D/'validation';out.mkdir(exist_ok=True)
  for index,row in enumerate(jobs):
   row.update(index=index,status='pending',source_sha256=sha(Path(row['source'])),test_sha256=sha(Path(row['source'])))
  result=dict(header=str(header),header_sha256=header_hash,forced_cpu_header=str(cpu_false),forced_cpu_header_sha256=false_hash,forced_features=counts,started_at_utc=now(),completed_at_utc=None,total_jobs=len(jobs),passed_jobs=0,completed_jobs=0,all_passed=False,jobs=jobs,scope='48 canonical matrix +8 ASAN/UBSAN reference +optional4 narrow thresholds. Correctness only. No performance run overlaps this entire matrix.',settings=dict(standard='C++23',optimization='-O2',march_native=False,compilers={k:dict(arguments=v[0],cpu=v[1])for k,v in COMPILERS.items()},safety=dict(ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1',leak_scope='host ptrace prevents LeakSanitizer; allocation test has independent live allocation counter assertions')))
  write_lock=threading.Lock();stop=threading.Event()
  def save():
   result['passed_jobs']=sum(x.get('passed',False)for x in jobs);result['completed_jobs']=sum(x['status']in['passed','failed']for x in jobs);result['all_passed']=result['passed_jobs']==len(jobs)
   p=D/'final_validation.json';tmp=p.with_name(p.name+'.tmp');tmp.write_text(encode(result));tmp.replace(p)
  def update(row,**data):
   with write_lock:row.update(**data);save()
  def expected(name,stdout):
   if name in ['reference','second_reference','narrow_threshold']:
    values=re.findall(r'\bchecks=(\d+)',stdout);return bool(values)and all(int(x)>0 for x in values)
   if name=='all_widths':return 'all B=0..64, signed extremes, word/AVX threshold boundaries OK' in stdout
   if name=='allocation':
    delta=re.search(r'wavelet live delta=(-?\d+)',stdout);failures=re.search(r'wavelet allocation failures=(\d+)',stdout)
    return bool(delta and failures)and int(delta.group(1))==0 and int(failures.group(1))>0
   raise AssertionError(name)
  def run_one(row):
   if stop.is_set():return
   cc=row['compiler'];compiler,cpu=COMPILERS[cc];h=cpu_false if row['mode']=='cpu_false'else header;source=Path(row['source']);exe=out/f"{cc}_{row['setting']}_{row['mode']}_{row['short_test']}_{'san'if row['sanitizer']else'plain'}"
   cmd=['taskset','-c',str(cpu),*compiler,'-std=c++23','-O2','-include',str(h),f'-DWAVELET_SOURCE="{h}"']
   if row['setting']=='skip':cmd+=['-DSKIP_RUNTIME_CHECKS']
   if row['mode']=='disabled':cmd+=['-DSIRKIT_DISABLE_SIMD']
   if row['sanitizer']:cmd+=['-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer']
   cmd+=[str(source),'-o',str(exe)];update(row,status='compiling',started_at_utc=now(),command=cmd,header=str(h),header_sha256=sha(h),executable=str(exe))
   try:
    assert sha(header)==header_hash and sha(cpu_false)==false_hash and sha(source)==row['test_sha256'],'frozen input changed'
    compiled=subprocess.run(cmd,capture_output=True,text=True,timeout=240);update(row,compile_returncode=compiled.returncode,compile_stdout=compiled.stdout,compile_stderr=compiled.stderr)
    if compiled.returncode!=0:raise RuntimeError('compiler failed')
    env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=0:halt_on_error=1';env['UBSAN_OPTIONS']='halt_on_error=1';run_cmd=['taskset','-c',str(cpu),str(exe)];update(row,status='running',run_command=run_cmd)
    p=subprocess.run(run_cmd,capture_output=True,text=True,timeout=180,env=env)
    counters={}
    m=re.search(r'\bchecks=(\d+)',p.stdout)
    if m:counters['checks']=int(m.group(1))
    m=re.search(r'wavelet allocation failures=(\d+)',p.stdout)
    if m:counters['failures']=int(m.group(1))
    m=re.search(r'wavelet live delta=(-?\d+)',p.stdout)
    if m:counters['live_delta']=int(m.group(1))
    passed=p.returncode==0 and not p.stderr and expected(row['short_test'],p.stdout)
    assert sha(header)==header_hash and sha(cpu_false)==false_hash and sha(source)==row['test_sha256'],'frozen input changed'
    update(row,status='passed'if passed else'failed',returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,counters=counters,passed=passed,completed_at_utc=now())
    print(row['index'],cc,row['setting'],row['mode'],row['short_test'],'san'if row['sanitizer']else'plain',passed,p.stdout.strip(),flush=True)
    if not passed:stop.set()
   except Exception as error:
    update(row,status='failed',passed=False,error=type(error).__name__+': '+str(error),completed_at_utc=now());stop.set();print(row['index'],cc,'FAILED',str(error),flush=True)
  with write_lock:save()
  def compiler_worker(cc):
   for row in jobs:
    if row['compiler']==cc:run_one(row)
  with ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(compiler_worker,COMPILERS))
  result['completed_at_utc']=now()
  with write_lock:save()
  assert result['all_passed'],f"{result['passed_jobs']}/{result['total_jobs']} jobs passed; see final_validation.json"
  print('Final validation PASS',result['passed_jobs'],'jobs, header',header_hash,flush=True)
if __name__=='__main__':main()
