# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import bench,json,subprocess,random,statistics,fcntl
D=Path('/tmp/sirkit_wavelet_416581');labels=['order_helpers','span_guard','span_begin','block16','kth_shift','kth_cmov','outline_build'];rng=random.Random(416581580);raw=[];summary=[]
main_ids=['range_kth_smallest__official_max_random_00','range_kth_smallest__official_dense_large_a_00','static_range_frequency__official_random_03','static_range_frequency__official_random_05','static_range_frequency__official_small_n_00']
cases=[(0,100000,0,0,3,64,0),(0,65536,0,1,3,64,0),(1,200000,200000,0,1,64,0),(2,500000,500000,0,1,64,0),(2,200000,100000,0,1,64,1),(1,64,4096,1,64,32,0),(2,64,4096,1,64,32,1),(3,65536,16384,1,1,64,0),(5,65536,16384,1,1,64,0)]
def run(cc,label,kind,case):
 if kind=='main':return bench.run_whole(cc,label,case)
 bench.activate(D/f'{cc}_native_skip_{label}_core');p=subprocess.run(['setarch','x86_64','-R','taskset','-c','12',str(D/'active'),*map(str,case)],capture_output=True,text=True,check=True);assert not p.stderr;ns,digest=map(int,p.stdout.split());assert ns>0;return dict(cpu_ns=ns,digest=digest)
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for kind,case in [('main',next(f for f in bench.fixtures if f['id']==id))for id in main_ids]+[('core',list(c))for c in cases]:
   local=[];order=[l for l in labels for _ in range(3)]+['control']*3;rng.shuffle(order)
   for rep,label in enumerate(order):
    v=[run(cc,k,kind,case)for k in ['base',label if label!='control'else'base','base']];key='output_sha256'if kind=='main'else'digest';assert len({x[key]for x in v})==1
    b,t,a=[x['cpu_ns']for x in v];drift=max(b,a)/min(b,a);r=dict(compiler=cc,kind=kind,case=case['id']if kind=='main'else case,label=label,rep=rep,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(r);local.append(r)
   ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in labels+['control']};row=dict(compiler=cc,kind=kind,case=case['id']if kind=='main'else case,ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},valid_counts={l:len(v)for l,v in ratios.items()});summary.append(row);print(row,flush=True);(D/'screen_raw.json').write_text(json.dumps(raw));(D/'screen_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
