// SPDX-License-Identifier: CC0-1.0
#include HEADER
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <random>
#include <vector>
#include <bit>
struct Result {std::int64_t ns;std::uint64_t digest;};
template<class T> Result run(int op,std::size_t n,std::size_t q,int shape,int reps,int query_mode) {
 using U=std::make_unsigned_t<T>;std::mt19937_64 rng(0x5a781169);std::vector<T>values(n);
 for(std::size_t i=0;i<n;++i){
  if(shape==0)values[i]=static_cast<T>(rng()%1000000000);
  else if(shape==1)values[i]=std::bit_cast<T>(static_cast<U>(rng()));
  else if(shape==2)values[i]=static_cast<T>(rng()%2);
  else if(shape==3)values[i]=static_cast<T>(rng()%256);
  else if(shape==4)values[i]=T{7};
  else values[i]=static_cast<T>(i);
 }
 if(query_mode==2)for(auto&v:values)v=std::bit_cast<T>(static_cast<U>(std::bit_cast<U>(v)&~U{1}));
 struct Query{std::size_t l,r,k;T x,y;};std::vector<Query>queries;queries.reserve(q);
 for(std::size_t i=0;i<q;++i){
  std::size_t l=rng()%(n+1),r=rng()%(n+1);if(l>r)std::swap(l,r);
  if(shape==5){l=rng()%n;r=std::min(n,l+1+(rng()%16));}
  if((op==1||op==7)&&l==r){if(r<n)++r;else --l;}
  T x,y;if(shape==0){x=static_cast<T>(rng()%1000000000);y=static_cast<T>(rng()%1000000000);}
  else if(shape==2||shape==3){const auto bound=shape==2?2u:256u;x=static_cast<T>(rng()%bound);y=static_cast<T>(rng()%bound);}
  else{x=std::bit_cast<T>(static_cast<U>(rng()));y=std::bit_cast<T>(static_cast<U>(rng()));}
  if(n&&i%2==0)x=values[rng()%n];if(y<x)std::swap(x,y);
  if(query_mode==1&&n){l=0;r=n;x=values[rng()%n];y=x;}
  if(query_mode==2)x=std::bit_cast<T>(static_cast<U>(std::bit_cast<U>(x)|U{1}));
  if(query_mode==3&&n){l=rng()%n;r=l+1;}
  if(query_mode==4){l=rng()%(n+1);r=l;}
  queries.push_back({l,r,l<r?rng()%(r-l):0,x,y});
 }
 std::uint64_t digest=1469598103934665603ULL;auto add=[&](auto x){digest=(digest^static_cast<std::uint64_t>(x))*1099511628211ULL;};
 if(op==0){std::vector<WaveletMatrix<T>>built;built.reserve(reps);auto start=std::clock();for(int i=0;i<reps;++i)built.emplace_back(values);auto ticks=std::clock()-start;for(const auto&m:built){add(m.size());if(n){add(m.access(0));add(m.access(n/2));add(m.access(n-1));}}return{static_cast<std::int64_t>(ticks)*1000000000/CLOCKS_PER_SEC,digest};}
 WaveletMatrix<T>matrix(values);auto start=std::clock();
 for(int rep=0;rep<reps;++rep)for(const auto&v:queries){
  if(op==1)add(matrix.kth_smallest(v.l,v.r,v.k));
  else if(op==2)add(matrix.rank(v.x,v.l,v.r));
  else if(op==3)add(matrix.count_less(v.l,v.r,v.x));
  else if(op==4)add(matrix.range_freq(v.l,v.r,v.x,v.y));
  else if(op==5)add(matrix.access(v.l<n?v.l:n-1));
  else if(op==6)add(matrix.count_less_equal(v.l,v.r,v.x));
  else if(op==7)add(matrix.kth_largest(v.l,v.r,v.k));
  else if(op==8){auto x=matrix.predecessor(v.l,v.r,v.x);add(x?static_cast<U>(*x):U{0});add(x.has_value());}
  else {auto x=matrix.successor(v.l,v.r,v.x);add(x?static_cast<U>(*x):U{0});add(x.has_value());}
 }
 return{static_cast<std::int64_t>(std::clock()-start)*1000000000/CLOCKS_PER_SEC,digest};
}
int main(int argc,char**argv){if(argc!=8)return 2;int op=std::atoi(argv[1]);auto n=std::strtoull(argv[2],nullptr,10),q=std::strtoull(argv[3],nullptr,10);int shape=std::atoi(argv[4]),reps=std::atoi(argv[5]),width=std::atoi(argv[6]);const int query_mode=std::atoi(argv[7]);if(n==0&&op!=0&&op!=2&&op!=3&&op!=4&&op!=6&&op!=8&&op!=9)return 2;const auto r=width==32?run<std::int32_t>(op,n,q,shape,reps,query_mode):run<std::int64_t>(op,n,q,shape,reps,query_mode);std::printf("%jd %ju\n",static_cast<std::intmax_t>(r.ns),static_cast<std::uintmax_t>(r.digest));}
