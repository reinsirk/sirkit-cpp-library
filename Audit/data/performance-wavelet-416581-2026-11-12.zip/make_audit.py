# SPDX-License-Identifier: CC0-1.0
# 完了済みの最終版の証跡を/tmpへ作る。リポジトリへの公開は呼出し側が行う。
from pathlib import Path
from collections import defaultdict
import difflib, hashlib, json, math, statistics, zipfile

R = Path('/home/reinsirk/Atcoder_Env')
D = Path('/tmp/sirkit_wavelet_416581')
LIBRARY = 'DataStructure/Wavelet_Matrix.cpp'
PERFORMANCE = 'Audit/performance-wavelet-416581-2026-11-12.json'
ONLINE = 'Audit/online-wavelet-416581-2026-11-12.json'
EVIDENCE = 'Audit/data/performance-wavelet-416581-2026-11-12.zip'
PREVIOUS = 'Audit/distribution-manifest-before-wavelet-416581-2026-11-12.json'
JOBS = {'wavelet_kth': (416581, 139), 'wavelet_frequency': (416580, 312)}
OP_NAMES = {0:'build', 1:'kth_smallest', 2:'rank', 3:'count_less', 4:'range_freq',
            5:'access', 6:'count_less_equal', 7:'kth_largest', 8:'predecessor', 9:'successor'}


def load(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def encode(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + '\n'


def qualified(row):
    return (row['valid_counts']['final'] >= 5 and row['valid_counts']['control'] >= 2
            and row['ratios']['final'] is not None and row['ratios']['control'] is not None)


def signature(row):
    return (row['compiler'], row['flag'], row['setting'],
            json.dumps(row['case'], sort_keys=True, separators=(',', ':')))


def compact_stats(rows, fields):
    result = []
    for key in sorted({tuple(row[k] for k in fields) for row in rows}):
        group = [row for row in rows if tuple(row[k] for k in fields) == key]
        valid = [row for row in group if qualified(row)]
        row = dict(zip(fields, key)) | dict(cells=len(group), qualified_cells=len(valid))
        if valid:
            row.update(candidate_ratio=math.exp(statistics.mean(math.log(x['ratios']['final']) for x in valid)),
                       identical_control_ratio=math.exp(statistics.mean(math.log(x['ratios']['control']) for x in valid)),
                       minimum_ratio=min(x['ratios']['final'] for x in valid),
                       maximum_ratio=max(x['ratios']['final'] for x in valid))
        result.append(row)
    return result


def measurements(kind, fixtures):
    jobs = load(D / f'final_{kind}_jobs.json')
    summary = load(D / f'final_{kind}_summary.json')
    raw = load(D / f'final_{kind}_raw.json')
    assert jobs and len(jobs) == len(summary) and raw, (kind, '未完了')
    expected = set()
    for job in jobs:
        copy = dict(job)
        if kind == 'whole': copy['case'] = job['case']['id']
        key = signature(copy)
        assert key not in expected, (kind, '重複job', key)
        expected.add(key)
    assert {signature(x) for x in summary} == expected
    assert len({signature(x) for x in summary}) == len(summary)
    grouped = defaultdict(list)
    for row in raw:
        key = signature(row)
        assert key in expected and row['label'] in {'final', 'control'}
        values = [row[k] for k in ['before', 'target', 'after']]
        times = [x['cpu_ns'] for x in values]
        assert all(t > 0 for t in times)
        drift = max(times[0], times[2]) / min(times[0], times[2])
        assert row['calibration_valid'] == (drift <= 1.10)
        assert math.isclose(row['reference_drift'], drift, rel_tol=1e-12)
        assert math.isclose(row['ratio'], times[1] / statistics.median([times[0], times[2]]), rel_tol=1e-12)
        if kind == 'whole':
            correct = fixtures[row['case']]['expected_output_sha256']
            assert all(x['output_sha256'] == correct for x in values)
        else:
            assert len({x['digest'] for x in values}) == 1
        grouped[key].append(row)
    for row in summary:
        samples = grouped[signature(row)]
        for label in ['final', 'control']:
            ratios = [x['ratio'] for x in samples if x['label'] == label and x['calibration_valid']]
            assert row['valid_counts'][label] == len(ratios)
            assert (row['ratios'][label] is None) == (not ratios)
            if ratios: assert math.isclose(row['ratios'][label], statistics.median(ratios), rel_tol=1e-12)
        assert row['sufficient'] == qualified(row)
    assert {x['compiler'] for x in summary} == {'gcc', 'clang'}
    # 基準未達の条件も削除せず記録する。採用根拠が全て未達なら処理を止める。
    assert all(any(qualified(x) and x['compiler'] == cc for x in summary) for cc in ['gcc', 'clang'])
    return jobs, summary, raw


def validate_matrix(after):
    validation = load(D / 'final_validation.json')
    assert validation['header_sha256'] == after and validation['all_passed']
    assert validation['completed_at_utc'] and validation['passed_jobs'] == validation['completed_jobs'] == validation['total_jobs'] == len(validation['jobs'])
    assert validation['total_jobs'] == 60
    canonical_tests = ['wavelet_matrix_reference_test', 'wavelet_matrix_second_reference_test',
                       'wavelet_matrix_all_widths_test', 'wavelet_matrix_allocation_test']
    expected = {(cc, setting, mode, test) for cc in ['gcc', 'clang']
                for setting in ['checked', 'skip'] for mode in ['default', 'disabled', 'cpu_false']
                for test in canonical_tests}
    actual = {(x['compiler'], x['setting'], x['mode'], x['test']) for x in validation['jobs'] if not x['sanitizer'] and x['test'] in canonical_tests}
    assert actual == expected
    sanitizers = {(x['compiler'], x['setting'], x['mode']) for x in validation['jobs'] if x['sanitizer']}
    assert sanitizers == {(cc, setting, mode) for cc in ['gcc', 'clang'] for setting in ['checked', 'skip'] for mode in ['default', 'disabled']}
    allocation = []
    for row in validation['jobs']:
        assert row['passed'] and row['status'] == 'passed' and row['compile_returncode'] == row['returncode'] == 0 and not row['stderr']
        assert sha(Path(row['source'])) == row['test_sha256']
        if row['test'] == 'wavelet_matrix_allocation_test':
            assert row['counters']['live_delta'] == 0 and row['counters']['failures'] > 0
            allocation.append(row['counters'])
    assert len(allocation) == 12

    return validation

PRIOR_AUDIT = 'Audit/performance-wavelet-416569-2026-11-12.json'
PRIOR_EVIDENCE = 'Audit/data/performance-wavelet-416569-2026-11-12.zip'
FIXTURE_METADATA = {'fixtures.json', 'summary.json', 'source_audit.json', 'commands.json'}
FROZEN_PUBLIC = ['Verify/current/drivers/wavelet_kth_main.cpp',
                 'Verify/current/drivers/wavelet_frequency_main.cpp',
                 'Verify/current/common/fast_io.hpp', 'Document/wavelet_matrix.md',
                 'Examples/wavelet_matrix_example.cpp']


def prior_same_source_validation(after):
    audit = load(R / PRIOR_AUDIT)
    assert audit['library'] == LIBRARY and audit['source_sha256']['after'] == after
    archive = R / PRIOR_EVIDENCE
    assert audit['evidence_archive'] == PRIOR_EVIDENCE
    assert sha(archive) == audit['evidence_archive_sha256']
    with zipfile.ZipFile(archive) as z:
        data = z.read(audit['validation']['details'])
        assert hashlib.sha256(data).hexdigest() == audit['validation']['sha256']
        validation = json.loads(data)
    assert validation['header_sha256'] == after and validation['all_passed']
    assert validation['completed_at_utc'] and validation['total_jobs'] == 60
    assert validation['passed_jobs'] == validation['completed_jobs'] == len(validation['jobs']) == 60
    assert all(row['passed'] and row['status'] == 'passed' for row in validation['jobs'])
    return dict(mode='previous_same_source', prior_audit=PRIOR_AUDIT,
                prior_audit_sha256=sha(R / PRIOR_AUDIT), prior_evidence=PRIOR_EVIDENCE,
                prior_evidence_sha256=sha(archive), details_inside_previous_archive=audit['validation']['details'],
                validation_sha256=hashlib.sha256(data).hexdigest(), source_sha256=after,
                completed_at_utc=validation['completed_at_utc'], jobs=60, all_passed=True,
                scope='同一SHAの本体について以前に実施した60件を引用。今回の再実行や候補版の検証として扱わない。')


def fixture_metadata():
    fixtures_list = load(D / 'fixtures/fixtures.json')
    fixtures = {row['id']: row for row in fixtures_list}
    info = load(D / 'fixtures/summary.json')
    assert len(fixtures_list) == len(fixtures) == info['cases'] == 28
    assert {row['problem'] for row in fixtures_list} == {'range_kth_smallest', 'static_range_frequency'}
    # 今回は旧runの固定入力を再利用する。外部パスの実体へarchive収集で移動しない。
    assert not (D / 'fixtures').is_symlink()
    prior = R / PRIOR_EVIDENCE
    with zipfile.ZipFile(prior) as z:
        for name in FIXTURE_METADATA:
            assert z.read('fixtures/' + name) == (D / 'fixtures' / name).read_bytes(), name
    return fixtures, info, dict(
        cases=len(fixtures), metadata_sha256={name: sha(D / 'fixtures' / name) for name in sorted(FIXTURE_METADATA)},
        reused_from_previous_evidence=PRIOR_EVIDENCE,
        scope='旧runの固定28入力と期待出力SHAのメタデータを再利用。JSON内の旧/tmpパスは実測用参照であり、入力・出力本体・旧ディレクトリを証跡へ再収録しない。')


def exploratory_evidence(fixtures, prefix="screen"):
    summary = load(D / (prefix + '_summary.json'))
    raw = load(D / (prefix + '_raw.json'))
    labels = {row['label'] for row in raw} - {'control'}
    assert labels
    sources = {}
    for label in sorted(labels):
        path = D / (label + '.hpp')
        assert path.is_file() and not path.is_symlink()
        sources[label] = dict(file=path.name, sha256=sha(path))
    for row in raw:
        values = [row[name] for name in ['before', 'target', 'after']]
        times = [item['cpu_ns'] for item in values]
        assert all(value > 0 for value in times)
        drift = max(times[0], times[2]) / min(times[0], times[2])
        assert row['calibration_valid'] == (drift <= 1.10)
        assert math.isclose(row['reference_drift'], drift, rel_tol=1e-12)
        assert math.isclose(row['ratio'], times[1] / statistics.median([times[0], times[2]]), rel_tol=1e-12)
        if row['kind'] == 'main':
            assert all(item['output_sha256'] == fixtures[row['case']]['expected_output_sha256'] for item in values)
        else:
            assert len({item['digest'] for item in values}) == 1
    def key(row):
        return row['compiler'], row['kind'], json.dumps(row['case'], sort_keys=True)
    assert len({key(row) for row in summary}) == len(summary)
    assert {key(row) for row in raw} == {key(row) for row in summary}
    for row in summary:
        samples = [item for item in raw if key(item) == key(row)]
        assert set(row['ratios']) == labels | {'control'}
        for label in labels | {'control'}:
            ratios = [item['ratio'] for item in samples if item['label'] == label and item['calibration_valid']]
            assert row['valid_counts'][label] == len(ratios)
            assert (row['ratios'][label] is None) == (not ratios)
            if ratios:
                assert math.isclose(row['ratios'][label], statistics.median(ratios), rel_tol=1e-12)
    return dict(labels=sources, cells=len(summary), triplets=len(raw),
                summary=prefix + '_summary.json', summary_sha256=sha(D / (prefix + '_summary.json')),
                raw=prefix + '_raw.json', raw_sha256=sha(D / (prefix + '_raw.json')),
                scope='今回Dの探索記録だけを保存。少数反復の候補比較であり、最終採用測定や全候補の完全検証とは区別する。')


def adopted_validation_and_measurements(after, fixtures):
    validation = validate_matrix(after)
    builds = load(D / 'final_builds.json')
    assert builds and all(row['returncode'] == 0 for row in builds)
    for row in builds:
        assert sha(Path(row['executable'])) == row['executable_sha256']
    for identifier in JOBS:
        assert {(cc, flag) for cc in ['gcc', 'clang'] for flag in ['native', 'default', 'disabled']} <= {
            (row['compiler'], row['flag']) for row in builds if row['label'] == 'final' and row['kind'] == identifier}
    whole_jobs, whole, whole_raw = measurements('whole', fixtures)
    core_jobs, core, core_raw = measurements('core', fixtures)
    assert {fixtures[row['case']]['problem'] for row in whole} == {'range_kth_smallest', 'static_range_frequency'}
    assert {row['flag'] for row in whole} == {row['flag'] for row in core} == {'native', 'default', 'disabled'}
    assert {row['setting'] for row in core} == {'checked', 'skip'}
    fixture_validation = load(D / 'final_fixture_validation.json')
    assert fixture_validation['all_passed'] and fixture_validation['count'] == len(fixture_validation['rows']) == 336
    assert {(row['compiler'], row['flag'], row['label'], row['fixture']) for row in fixture_validation['rows']} == {
        (cc, flag, label, case) for cc in ['gcc', 'clang'] for flag in ['native', 'default', 'disabled']
        for label in ['base', 'final'] for case in fixtures}
    for row in fixture_validation['rows']:
        assert row['passed'] and row['output_sha256'] == fixtures[row['fixture']]['expected_output_sha256']
    checkpoint = D / 'profiles/checkpoint.json'
    profile = load(checkpoint)
    assert profile['status'] == 'local_samples_passed_for_snapshot' and profile['completed_at_utc'] and profile['active'] is None
    assert profile['counts'] == {'LOCAL_SAMPLE_PASS': 14}
    for row in whole:
        row['problem'] = fixtures[row['case']]['problem']
    invalid_whole = [row for row in whole if not qualified(row)]
    invalid_core = [row for row in core if not qualified(row)]
    result = dict(mode='fresh_final_candidate', jobs=validation['total_jobs'], all_passed=True,
                  details='final_validation.json', sha256=sha(D / 'final_validation.json'),
                  source_sha256=after, completed_at_utc=validation['completed_at_utc'],
                  matrix='48件のGCC/Clang×checked/SKIP×default/disabled/CPU判定false×4独立試験、8件のASAN+UBSAN、4件の幅縮小境界。',
                  leak_scope='host ptraceのためLeakSanitizerは無効。独立live allocation counterは12条件でdelta=0。',
                  fixture_comparisons=336, fixture_details='final_fixture_validation.json',
                  fixture_sha256=sha(D / 'final_fixture_validation.json'),
                  profiles=dict(jobs=14, file='profiles/checkpoint.json', sha256=sha(checkpoint),
                                run_id=profile['run_id'], scope='派生版8件と使用例6件のローカルサンプル。オンライン判定ではない。'))
    measured = dict(
        whole=dict(cells=len(whole_jobs), qualified_cells=len(whole)-len(invalid_whole), triplets=len(whole_raw),
                   jobs='final_whole_jobs.json', summary='final_whole_summary.json', raw='final_whole_raw.json',
                   statistics=compact_stats(whole, ['compiler', 'flag', 'problem']), insufficient_cells=invalid_whole,
                   time='固定main全体の子user+system CPU時間。共通IO・SKIP設定を固定。'),
        core=dict(cells=len(core_jobs), qualified_cells=len(core)-len(invalid_core), triplets=len(core_raw),
                  jobs='final_core_jobs.json', summary='final_core_summary.json', raw='final_core_raw.json',
                  statistics=compact_stats(core, ['compiler', 'flag', 'setting']), insufficient_cells=invalid_core,
                  operations={str(k): OP_NAMES[k] for k in sorted({int(row['case'][0]) for row in core})},
                  time='std::clock。生成は計測外、演算と結果checksumは内。構築は保持配列を計測外で参照する。'),
        observed_tradeoffs=dict(
            whole_above_three_percent=[row for row in whole if qualified(row) and row['ratios']['final'] > 1.03],
            large_core_above_three_percent=[row for row in core if qualified(row) and row['case'][1] >= 100000 and row['ratios']['final'] > 1.03],
            scope='採用根拠と同じ最終summaryから導出。基準未達セルを一律改善へ数えない。'))
    # 任意の追加検査は存在時だけ参照する。過去runの結果を新候補へ流用しない。
    if (D / 'pedantic_validation.json').exists():
        pedantic = load(D / 'pedantic_validation.json')
        assert len(pedantic) == 2 and all(row['passed'] and row['header_sha256'] == after for row in pedantic)
        result['pedantic_standard'] = dict(jobs=2, all_passed=True, details='pedantic_validation.json')
    if (D / 'simd_instructions.json').exists():
        instructions = load(D / 'simd_instructions.json')
        assert instructions and all(row['header_sha256'] == after for row in instructions)
        result['SIMD_instruction_evidence'] = 'simd_instructions.json'
    return result, measured, validation


def evidence_files():
    import os
    excluded_names = {'audit_draft.json', Path(PERFORMANCE).name, 'distribution_update.log'}
    excluded_parts = {'__pycache__', 'generator_bins', 'inputs', 'outputs', 'sources',
                      'platform_evidence', 'validation', 'output', 'active', 'artifacts',
                      'snapshots', 'third_party', 'third-party', 'external'}
    allowed_suffixes = {'.py', '.hpp', '.cpp', '.json', '.diff', '.md', '.log'}
    for parent, directories, names in os.walk(D, followlinks=False):
        parent = Path(parent)
        directories[:] = [name for name in directories if name not in excluded_parts and not (parent / name).is_symlink()]
        for name in names:
            path = parent / name
            if path.is_symlink() or name in excluded_names or path.suffix not in allowed_suffixes:
                continue
            relative = path.relative_to(D)
            assert path.resolve().is_relative_to(D.resolve()), ('証跡の外部参照を辿らない', path)
            if relative.parts[0] == 'fixtures' and (len(relative.parts) != 2 or name not in FIXTURE_METADATA):
                continue
            if relative.parts[0] == 'profiles' and path.suffix != '.json':
                continue
            # compiler_evidence_*は公式原典の保存。必要な事実はcompiler_context.jsonへ抽出済み。
            if name.startswith('compiler_evidence_'):
                continue
            yield path


def main():
    selection = load(D / 'final_selection.json')
    decision = selection['decision']
    assert isinstance(decision, str)
    if decision.startswith('adopt'):
        adopted = True
    elif decision.startswith(('retain', 'reject', 'keep', 'no_adopt')):
        adopted = False
    else:
        raise ValueError('decisionはadopt/retain/reject/keep/no_adoptで開始する')
    frozen_snapshot = load(D / 'frozen.json')
    assert len(frozen_snapshot['files']) == 15
    for name, expected_hash in frozen_snapshot['files'].items():
        assert sha(D / 'before' / name) == expected_hash, ('開始時snapshotの変更', name)
    before = sha(D / 'before' / LIBRARY)
    after = sha(R / LIBRARY)
    assert before == sha(D / 'base.hpp') == 'cb678711a0a132cd685259a4f00c5a30204156c582b51030f87c5c1b3ae725a2'
    if adopted:
        assert before != after and selection['changes']
        assert sha(D / 'final.hpp') == after == selection['measured_candidate_sha256']
        assert sha(D / (selection['label'] + '.hpp')) == after
    else:
        assert before == after, '維持判断で本体を変更しない'
        if 'measured_candidate_sha256' in selection:
            assert selection['measured_candidate_sha256'] == before, '維持対象は実際の正本を指す'
        if (D / 'final.hpp').exists():
            assert sha(D / 'final.hpp') == before
    for name in FROZEN_PUBLIC:
        assert (R / name).read_bytes() == (D / 'before' / name).read_bytes(), name
    online = {row['id']: row for row in load(D / 'online_records.json')['records']}
    journal = {row['id']: row for row in load(R / 'Verify/current/judgements.json')['entries']}
    for identifier, (submission, milliseconds) in JOBS.items():
        old, current = online[identifier], journal[identifier]
        assert old['url'] == f'https://judge.yosupo.jp/submission/{submission}'
        assert old['status'] == 'AC' and old['time_ms'] == milliseconds and old['source_hashes'] == {LIBRARY: before}
        assert len(old['case_results']) == {'wavelet_kth': 24, 'wavelet_frequency': 11}[identifier]
        assert all(row['status'] == 'AC' for row in old['case_results'])
        assert old['driver_sha256'] == sha(R / f'Verify/current/drivers/{identifier}_main.cpp')
        assert old['io_source_hashes'] == {'Verify/current/common/fast_io.hpp': sha(R / 'Verify/current/common/fast_io.hpp')}
        assert current['url'] == old['url'] and current['time_ms'] == milliseconds and current['status'] == 'AC'
        assert current['source_hashes'] == {LIBRARY: before} and current['current_source_hashes'] == {LIBRARY: after}
        assert current['needs_resubmission'] is adopted and current['matched_current_generation'] is (not adopted)
        actual = R / f'Verify/current/submissions/{identifier}.cpp'
        assert current['current_submission_sha256'] == sha(actual)
        assert actual.read_bytes().startswith(b'#define SKIP_RUNTIME_CHECKS\n') and actual.stat().st_size <= 512 * 1024
        expected = D / (f'final_{identifier}.cpp' if adopted else f'{identifier}_submitted_generation.cpp')
        assert actual.read_bytes() == expected.read_bytes()
    fixtures, fixture_info, provenance = fixture_metadata()
    exploratory = exploratory_evidence(fixtures)
    confirmation = exploratory_evidence(fixtures, 'confirm')
    assert confirmation['cells'] == 12
    assert all(row['sufficient'] for row in load(D/'confirm_summary.json'))
    if adopted:
        validation, measured, matrix = adopted_validation_and_measurements(after, fixtures)
    else:
        validation = prior_same_source_validation(after)
        measured = dict(scope='今回は探索比較だけを実施。新候補の最終採用測定・検証を行ったとは扱わない。')
        matrix = None
    # 引用した外部原典はメタデータのみ。独自試験の現在ソースを証跡へ凍結する。
    for path in (R / 'Verify/current/tests').glob('wavelet_matrix*.cpp'):
        target = D / 'evidence_tests' / path.name
        target.parent.mkdir(exist_ok=True)
        if target.exists():
            assert target.read_bytes() == path.read_bytes()
        else:
            target.write_bytes(path.read_bytes())
    if matrix:
        for row in matrix['jobs']:
            path = Path(row['source'])
            if path.parent != R / 'Verify/current/tests' and path.suffix == '.cpp':
                target = D / 'evidence_tests' / path.name
                if target.exists():
                    assert target.read_bytes() == path.read_bytes()
                else:
                    target.write_bytes(path.read_bytes())
    final_text = (R / LIBRARY).read_text()
    (D / 'final.diff').write_text(''.join(difflib.unified_diff(
        (D / 'before' / LIBRARY).read_text().splitlines(True), final_text.splitlines(True),
        fromfile='before/Wavelet_Matrix.cpp', tofile='selected/Wavelet_Matrix.cpp')))
    online_data = load(D / 'online_records.json')
    audit = dict(
        date='2026-11-12', library=LIBRARY, decision=decision,
        source_sha256=dict(before=before, after=after), selection=selection,
        required_resubmission=[f'Verify/current/submissions/{identifier}.cpp' for identifier in JOBS] if adopted else [],
        online_evidence=ONLINE,
        online_scope='416581のkth AC139ms・416580のfrequency AC312msは提出時の本体/main/共通IOと本文照合済み。' + (
            '新本体は未提出で、このACを現行版へ転記しない。' if adopted else
            '同じ本体を維持するため現在の通常版と本文一致し、再提出不要。') + '派生版へオンラインACを転記しない。',
        public_online_comparison=online_data['public_case_comparison'],
        online_compiler_context=online_data['compiler_context'],
        frozen_public_files={name: sha(R / name) for name in FROZEN_PUBLIC},
        before_snapshot=dict(file='frozen.json', sha256=sha(D / 'frozen.json'), files=frozen_snapshot['files']),
        API_scope='型・公開呼び出し・戻り値・全符号範囲・所有権・例外保証・件数上限を維持。同じmain/共通IOで比較する。',
        proof_files=sorted(str(path.relative_to(D)) for path in (D / 'review').glob('*review.md')),
        source_diff='final.diff', validation=validation,
        measurement=dict(
            cpu='Intel Core i9-14900K CPU12（P-Core、sibling13）。E-Coreは性能評価しない。',
            compilers=dict(GCC='15.2.0', Clang='21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'),
            flags_scope='C++23 -O2。native/default/SIRKIT_DISABLE_SIMDを各rowで区別。引数は各builds JSONに保存。',
            CPU_scope='Library Checker実機の速度比を保証しない。オンライン別提出のケース時間とローカル条件固定比較を区別する。',
            lock='/tmp/sirkit_performance_cpu12.lock', compilation_during_timing=False,
            ASLR='子だけsetarch x86_64 -R、同じactiveパス。',
            protocol='旧版→候補→旧版。候補を両端中央値で割る。両端差10%以内を有効とし、候補時間自体では除外しない。最終比較は候補7組/同一対照3組で開始し、不足時のみ候補15組/対照9組まで補う。採用基準は候補5組/対照2組。探索の少数反復とは区別する。',
            fixtures=provenance, exploratory=exploratory, repeated_rank_confirmation=confirmation, **measured),
        license='既存CC0実装への独自変更。参考ライブラリの実装コードを新規に取り込まない。',
        evidence_archive=EVIDENCE,
        evidence_scope='自身の候補・生成器・独立参照試験・レビュー・今回の測定raw・自分の提出API原本・入力provenanceのみ。外部実装ソース・生成入力/出力・実行体・symlink参照先を除く。')
    if not adopted:
        audit['measurement']['protocol'] = '探索は各候補3組+同一対照3組。rank3候補の追加確認は各9組+対照3組。両端差10%以内だけ有効、候補自身では除外しない。確認は候補5有効組/対照2有効組を最低基準とし、不足時だけ候補18組/対照9組まで補う。12確認セルすべて基準達成。'
        audit['measurement']['repeated_rank_confirmation']['scope'] = '各9組で確認したrank3候補。新しい本体は採用しない。'
        audit['validation']['fresh_candidate_details'] = ['kth_validation.json','outline_validation.json','review/order_helpers_validation.json','review/block16_validation.json']
    for field in ['outcome', 'tradeoff_notes', 'limitations']:
        if field in selection:
            audit[field] = selection[field]
    draft = D / Path(PERFORMANCE).name
    archive = D / Path(EVIDENCE).name
    previous = D / Path(PREVIOUS).name
    previous.write_bytes((D / 'before/Distribution/manifest.json').read_bytes())
    (D / 'audit_draft.json').write_text(encode(audit))
    paths = sorted(evidence_files())
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in paths:
            z.write(path, path.relative_to(D).as_posix())
    audit['evidence_archive_sha256'] = sha(archive)
    draft.write_text(encode(audit))
    print(encode(dict(audit=str(draft), audit_target=PERFORMANCE,
                      evidence=str(archive), evidence_target=EVIDENCE,
                      previous_manifest=str(previous), previous_manifest_target=PREVIOUS,
                      evidence_bytes=archive.stat().st_size, evidence_files=len(paths),
                      repository_written=False)), end='')


if __name__ == '__main__':
    main()
