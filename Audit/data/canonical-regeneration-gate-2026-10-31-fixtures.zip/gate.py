# SPDX-License-Identifier: CC0-1.0
from __future__ import annotations
import hashlib,json,os,pathlib,re,stat,subprocess,sys,time,zipfile
P=pathlib.Path(__file__).parent;ROOT=P/'root';SOURCE=pathlib.Path('/tmp/sirkit_12h_20261031_095733/distribution_release_candidate/sirkit-cpp-library_full.zip')
os.sched_setaffinity(0,{0})
def sha(data):return hashlib.sha256(data).hexdigest()
def load(path):return json.loads((ROOT/path).read_text())
state=dict(scope='Actual generation after deleting reviewed generator-owned outputs from a fresh full release_candidate extraction; no formal/shared changes, no C++ build/performance.',archive=str(SOURCE),archive_sha256=sha(SOURCE.read_bytes()),root=str(ROOT),cpu=0,stages=[])
def save():(P/'checkpoint.json').write_text(json.dumps(state,indent=2)+'\n')
def run(name,script,check=False):
    while(P/'pause').exists():(P/'pause_ack').write_text('idle\n');time.sleep(.25)
    (P/'pause_ack').unlink(missing_ok=True)
    folder=P/'logs';folder.mkdir(exist_ok=True);cmd=[sys.executable,'Scripts/'+script]+(['--check']if check else[])
    env=dict(os.environ,LC_ALL='C',LANG='C',PYTHONDONTWRITEBYTECODE='1')
    for key in('PYTHONPATH','CPATH','CPLUS_INCLUDE_PATH','C_INCLUDE_PATH','OBJC_INCLUDE_PATH','INCLUDE'):env.pop(key,None)
    r=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,text=True,timeout=300)
    (folder/(name+'.stdout')).write_text(r.stdout);(folder/(name+'.stderr')).write_text(r.stderr)
    state['stages'].append(dict(name=name,command=cmd,cwd=str(ROOT),returncode=r.returncode,stdout_sha256=sha(r.stdout.encode()),stderr_sha256=sha(r.stderr.encode())));save()
    assert r.returncode==0,(name,r.stdout,r.stderr)
    print(name,'PASS',flush=True)
if ROOT.exists():raise SystemExit('fresh root must not exist')
ROOT.mkdir()
with zipfile.ZipFile(SOURCE)as z:
    infos=z.infolist();names=[x.filename for x in infos];assert len(names)==len(set(names))and z.testzip()is None
    for x in infos:
        name=x.filename;assert not name.startswith('/')and '\\'not in name and ':'not in name and all(c and c not in('.','..')for c in name.split('/'))and stat.S_IFMT(x.external_attr>>16)!=stat.S_IFLNK
    expected={n:dict(bytes=z.getinfo(n).file_size,sha256=sha(z.read(n)))for n in names}
    z.extractall(ROOT)
    variants=load('Variants/manifest.json')['entries'];profiles=load('Variants/verify_manifest.json')['entries'];normal=load('Verify/current/manifest.json')['entries'];fast=load('Fast/source_manifest.json')
    component_stages=[
      ('generate_geometry.py',['Geometry/geometory.cpp','Geometry/Point.cpp','Geometry/Line_Segment.cpp','Geometry/Polygon.cpp','Geometry/Circle.cpp']),
      ('generate_zeta.py',['Math/Zeta_Mebius.cpp','Math/Zeta/Set_Transform.cpp','Math/Zeta/Bitwise_Convolution.cpp','Math/Zeta/Sieve.cpp','Math/Zeta/Divisor_Multiple_Transform.cpp','Math/Zeta/Gcd_Lcm_Convolution.cpp','Math/Zeta/Sparse_Transform.cpp']),
      ('generate_combination.py',['Math/Combination_Mod.cpp','Math/Combination_AtCoderMod.cpp','Math/Combination/Binomial_Mod.cpp','Math/Combination/ModInt_Binomial.cpp','Math/Combination/Prime_Binomial.cpp']),
      ('generate_formal_power_series.py',['Math/Formal_Power_Series.cpp']),
      ('generate_linear_recurrence.py',['Math/Berlekamp_Massey.cpp','Math/Linear_Recurrence.cpp']),
      ('generate_gaussian_elimination.py',['Math/Gaussian_Elimination.cpp']),
      ('generate_binary_matrix.py',['Math/Binary_Matrix.cpp']),
      ('generate_convolution.py',['Math/Convolution.cpp']),
      ('generate_polynomial.py',['Math/Polynomial.cpp'])]
    stages=component_stages+[
      ('generate_fast_sources.py',[e['path']for e in fast if not e.get('handwritten')]+['Scripts/fast_overrides.json','Fast/source_manifest.json']),
      ('generate_variants.py',[e['path']for e in variants]+['Variants/manifest.json']),
      ('prepare_verify.py',[e['submission']for e in normal]+['Verify/current/manifest.json']),
      ('prepare_variant_verify.py',[e['path']for e in profiles]+['Variants/verify_manifest.json'])]
    assert len(fast)==11 and len([e for e in fast if not e.get('handwritten')])==10
    assert len(variants)==420 and len(profiles)==802 and len(normal)==227
    state['ownership']=[dict(generator=script,outputs=outputs)for script,outputs in stages]
    deleted=[n for _,outputs in stages for n in outputs];assert len(deleted)==len(set(deleted))==1488
    kept_fast=[f'Fast/Source/{e.relative_to(ROOT/"Fast/Source").as_posix()}'for e in sorted((ROOT/'Fast/Source').rglob('*.cpp'))if e.relative_to(ROOT).as_posix()not in deleted]
    assert kept_fast==['Fast/Source/DataStructure/Node.cpp','Fast/Source/Internal/Buffer.cpp','Fast/Source/Internal/Hash_Released_Array.cpp','Fast/Source/Internal/Unreleased_Vector.cpp']
    state['kept_fast_canonical']=kept_fast
    # Submission annotations are canonical metadata inputs, never silently inferred from erased bodies.
    groups={}
    for group in sorted((ROOT/'Verify/current/groups').glob('*.json')):
        for entry in json.loads(group.read_text())['entries']:groups[entry['id']]=entry
    annotations=load('Variants/submission_annotations.json')if(ROOT/'Variants/submission_annotations.json').exists()else{}
    urls=[]
    for entry in normal:
        found=re.findall(r'^// Submission: (https?://\S+)\s*$',(ROOT/entry['submission']).read_text(),re.M)
        canonical=groups[entry['id']].get('submission_urls',[])[-1:]
        assert found==canonical,(entry['id'],'normal annotation must be canonicalized before deletion',found,canonical)
        if found:urls.append(dict(kind='normal',id=entry['id'],urls=found,input='Verify/current/groups'))
    for entry in profiles:
        found=re.findall(r'^// Submission: (https?://\S+)\s*$',(ROOT/entry['path']).read_text(),re.M)
        prefix=('Fast/'if entry['fast']else'Variants/')+entry['compiler']
        canonical=annotations.get(prefix+':'+entry['id'],[])[-1:]
        assert found==canonical,(entry['id'],'profile annotation must be canonicalized',found,canonical)
        if found:urls.append(dict(kind='profile',id=entry['id'],urls=found,input='Variants/submission_annotations.json'))
    state['submission_annotation_inputs']=urls
    state['profile_annotation_file_present']=(ROOT/'Variants/submission_annotations.json').exists()
    state['deleted_outputs']=[dict(path=n,**expected[n])for n in deleted]
    state['preserved_original_inputs']=[dict(path=n,**expected[n])for n in names if n not in deleted]
    state['status']='planned';save()
    for n in deleted:
        assert n in expected and (ROOT/n).is_file();(ROOT/n).unlink()
    assert all(not(ROOT/n).exists()for n in deleted)
    state['status']='all_owned_outputs_absent';save()
    for script,outputs in stages:
        run(script.removesuffix('.py'),script)
        comparisons=[]
        for n in outputs:
            assert(ROOT/n).is_file(),(script,'missing',n)
            actual=(ROOT/n).read_bytes();match=sha(actual)==expected[n]['sha256']and len(actual)==expected[n]['bytes']
            comparisons.append(dict(path=n,bytes=len(actual),sha256=sha(actual),identical=match))
        state['stages'][-1]['outputs']=comparisons;save()
        assert all(x['identical']for x in comparisons),(script,'regeneration difference')
    # Confirm source, driver, groups, judgements and helper inputs stayed byte-identical too.
    all_paths=sorted(x.relative_to(ROOT).as_posix()for x in ROOT.rglob('*')if x.is_file())
    assert all_paths==sorted(names),('unexpected path set',set(all_paths)-set(names),set(names)-set(all_paths))
    state['final_full_tree_comparison']=[]
    for n in names:
        actual=(ROOT/n).read_bytes();assert sha(actual)==expected[n]['sha256']and len(actual)==expected[n]['bytes'],('final tree differs',n)
    state['final_full_tree_comparison']=dict(files=len(names),identical=True,generated_outputs=len(deleted),preserved_inputs=len(names)-len(deleted))
    # Inner package check list also succeeds after actual cold regeneration.
    for script,_ in stages:run(script.removesuffix('.py')+'_check',script,True)
    run('source_api_check','check_source_api_docs.py',True)
state['status']='passed';save();print('all1488 missing outputs regenerated byte-identically; whole tree identical',flush=True)
