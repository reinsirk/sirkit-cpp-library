# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,os,hashlib,re
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_ntt_416560');rows=[]
header=D/'final.hpp';assert header.is_file();text=header.read_text();old='static const bool available=__builtin_cpu_supports("avx2");';assert text.count(old)==1;(D/'cpu_false.hpp').write_text(text.replace(old,'static const bool available=false;'))
for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for setting in ['checked','skip']:
  for mode in ['default','disabled','cpu_false']:
   h=D/'cpu_false.hpp'if mode=='cpu_false'else header
   for test in ['ntt_montgomery_reference_test','formal_power_series_reference_test','string_math_allocation_test']:
    rows.append(dict(compiler=cc,compiler_args=args,setting=setting,mode=mode,test=test,header=str(h),sanitizer=False))
  for mode in ['default','disabled']:
   rows.append(dict(compiler=cc,compiler_args=args,setting=setting,mode=mode,test='ntt_montgomery_reference_test',header=str(header),sanitizer=True))
result=dict(header_sha256=hashlib.sha256(header.read_bytes()).hexdigest(),jobs=rows,all_passed=False,passed_jobs=0,total_jobs=len(rows),note='Correctness only. ASAN detect_leaks=0 forhostptrace; allocation counters separatelyverifylive_delta=0. -include forcescandidate NTT ahead ofembeddedexisting FPS copies. No performance measurement overlaps.')
def save():(D/'final_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
save()
for i,row in enumerate(rows):
 source=R/'Verify/current/tests'/(row['test']+'.cpp');exe=D/f'validation_{i}';h=row['header'];cmd=['taskset','-c','4',*row['compiler_args'],'-std=c++23','-O2','-include',h,f'-DNTT_HEADER="{h}"']
 if row['setting']=='skip':cmd+=['-DSKIP_RUNTIME_CHECKS']
 if row['mode']=='disabled':cmd+=['-DSIRKIT_DISABLE_SIMD']
 if row['sanitizer']:cmd+=['-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer']
 cmd+=[str(source),'-o',str(exe)];row['command']=cmd;row['test_sha256']=hashlib.sha256(source.read_bytes()).hexdigest();p=subprocess.run(cmd,text=True,capture_output=True);row['compile_returncode']=p.returncode;row['compile_stderr']=p.stderr
 if p.returncode==0:
  env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=0:halt_on_error=1';env['UBSAN_OPTIONS']='halt_on_error=1';p=subprocess.run(['taskset','-c','4',str(exe)],capture_output=True,text=True,env=env);row.update(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,counters={k:int(v)for k,v in re.findall(r'\b(checks|failures|live_delta)=(\d+)',p.stdout)});row['passed']=p.returncode==0 and not p.stderr and row['counters'].get('checks',0)>0 and row['counters'].get('live_delta',0)==0
 else:row['passed']=False
 result['passed_jobs']=sum(r.get('passed',False)for r in rows);save();print(i,row['compiler'],row['setting'],row['mode'],row['test'],row['sanitizer'],row['passed'],row.get('stdout','').strip(),flush=True)
 assert row['passed'],row
result['all_passed']=True;save()
