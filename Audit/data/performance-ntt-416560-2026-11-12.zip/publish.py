# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json,subprocess,shutil
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_ntt_416560')
def load(p):return json.loads(p.read_text())
v=load(D/'final_validation.json');assert v['all_passed']and v['passed_jobs']==44;assert v['header_sha256']==hashlib.sha256((D/'final.hpp').read_bytes()).hexdigest()
c=load(D/'text_correspondence.json');assert len(c)==10 and all(x.get('final_matches_measured',x.get('final_matches_baseline'))for x in c)
f=load(D/'focused_summary.json');assert len(f)==44 and all(x['sufficient']for x in f)
for x in f:
 if x['n']>=65536:assert x['ratios']['final']<=1.03,x
for p in ['Verify/current/drivers/ntt_convolution_main.cpp','Verify/current/common/fast_io.hpp','Examples/ntt_example.cpp','Document/ntt.md']:
 assert (R/p).read_bytes()==(D/'before'/p).read_bytes(),p
assert (R/'Math/NTT.cpp').read_bytes()==(D/'base.hpp').read_bytes()
shutil.copyfile(D/'final.hpp',R/'Math/NTT.cpp')
for name in ['generate_formal_power_series','generate_linear_recurrence','generate_convolution','generate_polynomial','generate_variants']:
 subprocess.run(['python3',str(R/'Scripts'/(name+'.py'))],check=True)
subprocess.run(['python3',str(D/'apply_online_metadata.py'),'--apply','--performance-audit','Audit/performance-ntt-416560-2026-11-12.json'],check=True,stdout=(D/'online_apply.log').open('w'))
for name in ['prepare_verify','prepare_variant_verify']:
 subprocess.run(['python3',str(R/'Scripts'/(name+'.py'))],check=True)
for name in ['generate_formal_power_series','generate_linear_recurrence','generate_convolution','generate_polynomial','generate_variants','prepare_verify','prepare_variant_verify','check_source_api_docs']:
 subprocess.run(['python3',str(R/'Scripts'/(name+'.py')),'--check'],check=True)
assert (R/'Verify/current/submissions/ntt_convolution.cpp').read_bytes()==(D/'final_main.cpp').read_bytes()
print('Published and all source generation checks passed')
