# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import bench,json,statistics,fcntl
D=Path('/tmp/sirkit_ntt_416560');labels=['subtract','recursive'];rp=D/'native_raw.json';sp=D/'native_summary.json';raw=json.loads(rp.read_text());rows=json.loads(sp.read_text());(D/'native_initial_raw.json').write_bytes(rp.read_bytes());(D/'native_initial_summary.json').write_bytes(sp.read_bytes())
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for row in rows:
  if row['sufficient']:continue
  f=next(f for f in bench.fixtures if f['name']==row['case']);local=[r for r in raw if r['compiler']==row['compiler']and r['case']==row['case']]
  for attempt in range(3):
   missing=[l for l in labels+['control']if sum(r['label']==l and r['calibration_valid']for r in local)<(2 if l=='control'else 5)]
   if not missing:break
   for label in missing:
    for extra in range(3):
     v=[bench.run_whole(row['compiler']+'_native',l,f)for l in ['base',label if label!='control'else'base','base']];assert len({r['output_sha256']for r in v})==1
     b,t,a=[r['cpu_ns']for r in v];drift=max(b,a)/min(b,a);r=dict(compiler=row['compiler'],case=row['case'],label=label,rep=len(local),repair=True,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(r);local.append(r)
  ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in labels+['control']};row.update(valid_counts={l:len(v)for l,v in ratios.items()},ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},sufficient=all(len(ratios[l])>=5 for l in labels)and len(ratios['control'])>=2,calibration_repaired=True);print(row,flush=True)
 rp.write_text(json.dumps(raw));sp.write_text(json.dumps(rows,indent=2)+'\n')
print('native qualified',sum(r['sufficient']for r in rows),'of',len(rows),flush=True)
