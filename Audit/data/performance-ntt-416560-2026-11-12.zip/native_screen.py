# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import bench,json,random,statistics,fcntl
D=Path('/tmp/sirkit_ntt_416560');rng=random.Random(560);raw=[];rows=[];labels=['subtract','recursive'];names=['official_fft_killer_00','official_fft_killer_01','official_max_random_00','official_random_00','official_small_and_large_00','official_small_and_large_01','custom_33x524288_random']
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for name in names:
   f=next(x for x in bench.fixtures if x['name']==name);local=[];order=[l for l in labels for _ in range(9)]+['control']*3;rng.shuffle(order)
   for rep,l in enumerate(order):
    v=[bench.run_whole(cc+'_native',k,f)for k in ['base',l if l!='control'else'base','base']];assert len({x['output_sha256']for x in v})==1
    b,t,a=[x['cpu_ns']for x in v];drift=max(b,a)/min(b,a);r=dict(compiler=cc,case=name,n=f['n'],m=f['m'],label=l,rep=rep,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(r);local.append(r)
   ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in labels+['control']};r=dict(compiler=cc,case=name,ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},valid_counts={l:len(v)for l,v in ratios.items()},sufficient=all(len(ratios[l])>=5 for l in labels)and len(ratios['control'])>=2);rows.append(r);print(r,flush=True);(D/'native_raw.json').write_text(json.dumps(raw));(D/'native_summary.json').write_text(json.dumps(rows,indent=2)+'\n')
