# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,re,json,collections
D=Path('/tmp/sirkit_ntt_416560');rows=[]
for cc in ['gcc','clang']:
 for label in ['base','subtract','quarter','quarter_subtract']:
  exe=D/f'{cc}_{label}_main';a=subprocess.check_output(['objdump','-d','-C','--no-show-raw-insn',str(exe)],text=True);(D/f'{cc}_{label}.asm').write_text(a)
  cnt=collections.Counter(re.findall(r'^\s*[0-9a-f]+:\s+([a-z0-9]+)',a,re.M));rows.append(dict(compiler=cc,label=label,command=['objdump','-d','-C','--no-show-raw-insn',str(exe)],vector_instruction_counts={k:v for k,v in sorted(cnt.items())if k.startswith('vp')or k.startswith('vmov')},scope='Static disassembly instruction count, not runtime operations or speed claim.'))
(D/'instruction_stats.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:print(r['compiler'],r['label'],{k:r['vector_instruction_counts'].get(k,0)for k in ['vpmuludq','vpaddd','vpsubd','vpblendd','vpminud']})
