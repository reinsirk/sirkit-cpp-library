# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import bench,json,statistics,random,fcntl,subprocess
D=Path('/tmp/sirkit_ntt_416560');rng=random.Random(560560);raw=[];summary=[]
cases=[(6,128,16384),(6,1024,2048),(4,128,8192),(4,1024,2048),(5,1024,2048),(4,65536,16),(6,65536,256),(4,524288,2),(5,524288,2),(0,524288,1),(3,524288,1)]
def run(cc,st,label,op,n,reps):
 bench.activate(D/f'{cc}_{st}_{label}_core');p=subprocess.run(['setarch','x86_64','-R','taskset','-c','12',str(D/'active'),str(op),str(n),str(n),str(reps)],check=True,capture_output=True,text=True);assert not p.stderr
 ns,digest=map(int,p.stdout.split());assert ns>0;return dict(cpu_ns=ns,digest=digest)
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for st in ['checked','skip']:
   for op,n,reps in cases:
    local=[];order=['final']*9+['control']*9;rng.shuffle(order)
    for rep,l in enumerate(order):
     v=[run(cc,st,k,op,n,reps)for k in ['base',l if l!='control'else'base','base']];assert len({x['digest']for x in v})==1
     b,t,a=[x['cpu_ns']for x in v];drift=max(b,a)/min(b,a);r=dict(compiler=cc,setting=st,op=op,n=n,repetitions=reps,label=l,rep=rep,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(r);local.append(r)
    ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in ['final','control']};r=dict(compiler=cc,setting=st,op=op,n=n,repetitions=reps,valid_counts={l:len(v)for l,v in ratios.items()},ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},sufficient=all(len(v)>=5 for v in ratios.values()));summary.append(r);print(r,flush=True);(D/'focused_raw.json').write_text(json.dumps(raw));(D/'focused_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
