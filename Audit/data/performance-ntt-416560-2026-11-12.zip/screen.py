# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import bench,json,random,statistics,fcntl
D=Path('/tmp/sirkit_ntt_416560');rng=random.Random(416560);labels=['quarter','subtract','quarter_subtract'];raw=[];rows=[]
cases=[(0,33,33),(0,1024,1024),(0,65536,65536),(0,524288,524288),(0,33,524288),(0,100,524288),(0,1000,524288),(0,262145,262144),(4,1024,1024),(5,1024,1024),(4,524288,524288),(5,524288,524288),(3,524288,524288)]
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for op,n,m in cases:
   local=[];order=[l for l in labels for _ in range(5)]+['control']*3;rng.shuffle(order)
   for rep,l in enumerate(order):
    v=[bench.run_core(cc,'skip',k,op,n,m)for k in ['base',l if l!='control'else'base','base']];assert len({x['digest']for x in v})==1
    b,t,a=[x['cpu_ns']for x in v];r=dict(compiler=cc,op=op,n=n,m=m,label=l,rep=rep,before=v[0],target=v[1],after=v[2],reference_drift=max(b,a)/min(b,a),ratio=t/statistics.median([b,a]));r['calibration_valid']=r['reference_drift']<=1.10;raw.append(r);local.append(r)
   ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in labels+['control']};r=dict(compiler=cc,op=op,n=n,m=m,ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},valid_counts={l:len(v)for l,v in ratios.items()});rows.append(r);print(r,flush=True);(D/'screen_raw.json').write_text(json.dumps(raw));(D/'screen_summary.json').write_text(json.dumps(rows,indent=2)+'\n')
