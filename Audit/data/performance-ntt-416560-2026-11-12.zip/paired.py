# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,random,statistics,fcntl
import bench
D=Path('/tmp/sirkit_ntt_416560');labels=['recursive'];rng=random.Random(416560)
def main():
 with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  validation=[]
  for cc in ['gcc','clang']:
   for f in bench.fixtures:
    a=bench.run_whole(cc,'base',f)
    for label in labels:
     b=bench.run_whole(cc,label,f);assert a['output_sha256']==b['output_sha256'];validation.append(dict(compiler=cc,case=f['name'],label=label,sha256=b['output_sha256']))
  (D/'whole_output_validation.json').write_text(json.dumps(validation,indent=2)+'\n')
  for mode in ['whole','core']:
   raw=[];summary=[]
   if mode=='whole':
    cases=[dict(compiler=cc,case=f['name'],n=f['n'],m=f['m'])for cc in ['gcc','clang']for f in bench.fixtures if f['ntt_length']>=65536 or max(f['n'],f['m'])>=200000]
   else:
    sizes=[16,128,1024,65536,524288];shapes=[(op,n,n)for op in range(7)for n in sizes]+[(0,33,33),(0,32,524288),(0,33,524288),(0,524288,32),(0,262145,262144),(1,33,33)]
    cases=[dict(compiler=cc,setting=st,op=op,n=n,m=m)for cc in ['gcc','clang']for st in ['checked','skip']for op,n,m in shapes]
   for case in cases:
    if mode=='whole':
     f=next(f for f in bench.fixtures if f['name']==case['case'])
     def run(label):return bench.run_whole(case['compiler'],label,f)
     key='output_sha256'
    else:
     def run(label):return bench.run_core(case['compiler'],case['setting'],label,case['op'],case['n'],case['m'])
     key='digest'
    order=[x for x in labels for _ in range(9)]+['control']*3;rng.shuffle(order);local=[]
    for rep,l in enumerate(order):
     v=[run(label)for label in ['base',l if l!='control'else'base','base']];assert len({r[key]for r in v})==1
     b,t,a=[r['cpu_ns']for r in v];drift=max(b,a)/min(b,a);r=case|dict(label=l,rep=rep,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(r);local.append(r)
    ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in labels+['control']};r=case|dict(valid_counts={l:len(v)for l,v in ratios.items()},ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},sufficient=all(len(ratios[l])>=5 for l in labels)and len(ratios['control'])>=2);summary.append(r);print(mode,r,flush=True);(D/f'paired_{mode}_raw.json').write_text(json.dumps(raw));(D/f'paired_{mode}_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
   print(mode,'completed',len(raw),'triplets',flush=True)
if __name__=='__main__':main()
