# AVX2剰余減算の簡約

前提は0<=a,b<2ModかつMod<2^30。d=a-bをuint32の巡回差とする。

a>=bならd<2Modで、d+2Mod<4Mod<2^32なのでmin(d,d+2Mod)=d。a<bならd=2^32-(b-a)で、d+2Modは巡回して2Mod-(b-a)<2Modとなり、dより小さい。したがってmin(d,d+2Mod)は常に[a-b] modulo2Modの代表値[0,2Mod)となる。従来のmin(a+2Mod-b,a-b)と全bitが一致する。

両実装とも同じuint32 SIMD加減算とunsigned min。中間の巡回はAVX2整数演算の定義内であり、符号付きC++のオーバーフローを導入しない。ModやCPU/コンパイラの適用範囲、検査、所有、動的確保、公開APIは変えない。標準経路の関数は変更しない。

GCCのmain逆アセンブルではAVX2 vpadddの静的個数109→83、Clang83→81。他の関数複製も含む静的個数なので実行回数や速度比には換算せず、同条件の実測を別に保存する。
