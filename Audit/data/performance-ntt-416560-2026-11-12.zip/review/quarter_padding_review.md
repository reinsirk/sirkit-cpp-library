# Quarter-zero first-stage proof

Reviewed source: `quarter_padding.hpp`, generated from canonical NTT SHA256 `d4bdefca3f0c7d3dc4cc1a2e1ddf00afc3ca1944bc5358d87fdbb9f56c2dfd36` by `generate_quarter_padding.py`. No repository files or Verify main changed.

## Preconditions and zero provenance

The existing private `forward_padded(a,input_size)` is called only after convolution records both original vector lengths and extends the vectors with `resize`, or after square value-initializes its full buffer and copies/normalizes the prefix. Supported transform length n has already passed the mandatory capacity/power-of-two checks. The existing SIMD gate still requires Montgomery modulus, AVX2-capable CPU/compiler/architecture, n>=32 and input_size<=n/2.

The new nested branch additionally requires input_size<=n/4. Therefore every a[i] for i in [n/4,n) is an appended/value-initialized zero, regardless of the values in the original prefix. No distribution scan or judge-specific property is assumed. Otherwise the previous half-zero function body is retained verbatim through an if-constexpr false specialization.

## Algebra

Write q=n/4, and r1=roots[2q+j], r2=roots[3q+j], r3=roots[q+j]. The prior half-zero top stage used x0,x1 and had x2=x3=0:

- v2=x0*r1; v3=x1*r2.
- output quarters are x0+x1, (x0-x1)*r3, v2+v3, (v2-v3)*r3.

With the stronger precondition x1=0, these are x0, x0*r3, x0*r1, (x0*r1)*r3. That is exactly the new four stores. The full-vector encoding of x1=0 and its root loads/products are omitted. Existing vector_add/subtract of a valid x and zero return x exactly under the lazy Montgomery representation; multiplication of zero yields zero. Thus first-stage outputs match the existing half-zero stage bit for bit, not only modulo Mod. The separate quarter-root arithmetic added earlier continues unchanged.

The top stage still executes once, then calls `forward_avx2<false,true>` starting at n/4. Existing 16-point and 8-point suffixes handle both log2 parity cases just as before. Actual convolution use has min(n,m)>32 and therefore transform n>=128; the private gate n>=32 also makes q>=8 and q a multiple of8 for hypothetical smallest valid calls.

## Bounds, checks and exceptions

Each SIMD iteration j covers [j,j+8) entirely inside [0,q). All four store ranges fit the four separate quarters and all roots indices are below n. No original coefficient lies outside the first quarter when the new branch is eligible. `vector_check(x0)` therefore checks every original coefficient in the same loop as normal encoding, while omitted coefficients are proven appended zeros. SKIP removes the check via the same preprocessor condition and no check-only state is added. Ineligible half/full inputs retain their previous check coverage. The size/capacity guards remain active even with SKIP.

After checks, x0 is encoded once and every product uses the existing operator whose inputs/output stay in [0,2Mod). Since Mod<2^30 in this path, the prior 64-bit product/reduction bounds and 32-bit add/subtract bounds are unchanged. Standard non-Montgomery moduli, unsupported hardware, disabled SIMD and public transform take their prior paths; public transform never uses trusted padding information.

The buffers are owning vectors, and all writes stay inside the current buffer. No allocation, cache field, raw owning pointer, alias assumption, lifetime change or exception handler is added. Caller originals remain unchanged if convolution copies them; moved ownership follows the existing API. Check failure may leave internal by-value buffers partially transformed, but normal vector destruction still releases them, as before.

Square's output-size relation makes input_size<=n/4 unattainable for its actual NTT branch, so square simply takes the existing half-zero branch with one additional predictable comparison. Performance must still be measured rather than inferred; no speed claim is made here.

## Validation

`validate.py` compiles the existing independent NTT/DFT/naive/ownership tests plus extra closed-form all-(Mod-1) products for 33×257, 255×3073, 33×65536 and both orders. The expected result at index i is the overlap count modulo Mod, independently of NTT. It also places invalid normalized coefficients at the first/middle/last input positions on both sides, covering the new quarter-only checks as well as old half/full paths. Five large-support moduli are tested, including non-Montgomery fallback moduli. GCC/Clang checked/SKIP results and commands are recorded in validation.json. Tests run CPU6; root owns serialized P-Core performance measurements.
