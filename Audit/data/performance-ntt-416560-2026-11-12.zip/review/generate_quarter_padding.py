# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,difflib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_ntt_416560/review')
base=(R/'Math/NTT.cpp').read_text();assert hashlib.sha256(base.encode()).hexdigest()=='d4bdefca3f0c7d3dc4cc1a2e1ddf00afc3ca1944bc5358d87fdbb9f56c2dfd36'
old='''    template<bool Check>
    [[gnu::target("avx2")]]
    void forward_zero_padded_avx2(std::vector<std::uint32_t>& a) const {'''
new=old.replace('template<bool Check>','template<bool Check, bool QuarterOnly = false>')
assert base.count(old)==1;s=base.replace(old,new)
a=s.index('        // 後半はresizeが補ったゼロ。',s.index('    void forward_zero_padded_avx2'));b=s.index('        forward_avx2<false,true>(a);',a)
body=s[a:b]
oldloop='''        for(std::size_t j=0;j<quarter;j+=8) {
            auto x0=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+j));'''
assert body.count(oldloop)==1
opening='''        // QuarterOnlyでは後ろ3/4が追加ゼロ。先頭1/4だけを符号化する。
        if constexpr (QuarterOnly) {
            for(std::size_t j=0;j<quarter;j+=8) {
                auto x0=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+j));
#ifndef SKIP_RUNTIME_CHECKS
                if constexpr(Check)vector_check(x0);
#endif
                x0=vector_multiply(x0,r2);
                const auto first=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data()+2*quarter+j));
                const auto third=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data()+quarter+j));
                const auto v2=vector_multiply(x0,first);
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+j),x0);
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+quarter+j),vector_multiply(x0,third));
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+2*quarter+j),v2);
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+3*quarter+j),vector_multiply(v2,third));
            }
        } else {
'''
s=s[:a]+opening+body+'        }\n'+s[b:]
old='''            forward_zero_padded_avx2<Check>(a);return;'''
new='''            if(input_size<=a.size()/4)forward_zero_padded_avx2<Check,true>(a);
            else forward_zero_padded_avx2<Check>(a);
            return;'''
assert s.count(old)==1;s=s.replace(old,new)
(D/'quarter_padding.hpp').write_text(s)
(D/'quarter_padding.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='Math/NTT.cpp',tofile='quarter_padding.hpp')))
(D/'metadata.json').write_text(json.dumps(dict(base_sha256=hashlib.sha256(base.encode()).hexdigest(),candidate_sha256=hashlib.sha256(s.encode()).hexdigest(),private_change='Known original input length <= n/4 enables first radix4 stage with only x0 nonzero. No input-value scan or new cache/state. Half-zero specialization retains prior body.'),indent=2)+'\n')
