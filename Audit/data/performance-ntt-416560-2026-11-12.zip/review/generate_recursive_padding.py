# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json,difflib
D=Path('/tmp/sirkit_ntt_416560');O=D/'review';base=(D/'subtract.hpp').read_text();s=base
old='void forward_avx2(std::vector<std::uint32_t>& a) const {'
new='void forward_avx2(std::vector<std::uint32_t>& a, [[maybe_unused]] std::size_t remaining_length=0) const {'
assert s.count(old)==1;s=s.replace(old,new)
old='std::size_t length=SkipFirst ? n/4 : n;';assert s.count(old)==1;s=s.replace(old,'std::size_t length=SkipFirst ? remaining_length : n;')
old='forward_avx2<false,true>(a);';assert s.count(old)==1;s=s.replace(old,'forward_avx2<false,true>(a,n/4);')
helper='''    template<bool Check, bool Encode>
    [[gnu::target("avx2")]]
    void forward_zero_quarters_avx2(std::vector<std::uint32_t>& a,
                                    std::size_t length, std::size_t active) const {
        const auto quarter=length/4;
        // 各区間の先頭active要素以外は、以前の段でもゼロのまま。
        for(std::size_t block=0;block<a.size();block+=length)for(std::size_t j=0;j<active;j+=8) {
            auto x0=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+block+j));
            if constexpr(Encode) {
#ifndef SKIP_RUNTIME_CHECKS
                if constexpr(Check)vector_check(x0);
#endif
                x0=vector_multiply(x0,_mm256_set1_epi32(static_cast<int>(r_squared_)));
            }
            const auto first=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data()+2*quarter+j));
            const auto third=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data()+quarter+j));
            const auto v2=vector_multiply(x0,first);
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+block+j),x0);
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+block+quarter+j),vector_multiply(x0,third));
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+block+2*quarter+j),v2);
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+block+3*quarter+j),vector_multiply(v2,third));
        }
    }
'''
old='''    template<bool Check>
    [[gnu::target("avx2")]]
    void backward_avx2''';assert s.count(old)==1;s=s.replace(old,helper+old)
old='''            forward_zero_padded_avx2<Check>(a);return;'''
new='''            if(input_size<=a.size()/4) {
                // 長さは上限検査済み。8要素へ丸めても各区間の1/4以内に収まる。
                const auto active=(input_size+7)&~std::size_t{7};
                auto length=a.size();
                forward_zero_quarters_avx2<Check,true>(a,length,active);
                length/=4;
                while(length>=32 && active<=length/4) {
                    forward_zero_quarters_avx2<false,false>(a,length,active);
                    length/=4;
                }
                forward_avx2<false,true>(a,length);return;
            }
            forward_zero_padded_avx2<Check>(a);return;'''
assert s.count(old)==1;s=s.replace(old,new)
(O/'recursive_padding.hpp').write_text(s)
(O/'recursive_padding.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='subtract.hpp',tofile='recursive_padding.hpp')))
(O/'recursive_padding_metadata.json').write_text(json.dumps(dict(base_sha256=hashlib.sha256(base.encode()).hexdigest(),candidate_sha256=hashlib.sha256(s.encode()).hexdigest(),changes='Only known-zero prefix-support radix4 stages; general continuation takes trusted remaining length. Explicit original halfzero call passes n/4; ordinary transform ignores the extra default0 private parameter.'),indent=2)+'\n')
