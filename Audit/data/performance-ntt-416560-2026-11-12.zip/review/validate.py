# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_ntt_416560/review');rows=[]
original=(R/'Verify/current/tests/ntt_montgomery_reference_test.cpp').read_text()
extra='''template<std::uint32_t Mod,std::uint32_t Root>void quarter_padding_cases(){
 NTT<Mod,Root>engine;
 for(auto [n,m]:{std::pair{33,257},std::pair{255,3073},std::pair{33,65536}}){
  if(std::bit_ceil(static_cast<std::size_t>(n+m-1))>engine.max_length())continue;
  for(bool swapped:{false,true}){
   std::vector<std::uint32_t>a(n,Mod-1),b(m,Mod-1);if(swapped)a.swap(b);
   const auto c=engine.convolution_normalized(a,b);
   for(std::size_t i=0;i<c.size();++i)check(c[i]==std::min({i+1,a.size(),b.size(),c.size()-i})%Mod);
#ifndef SKIP_RUNTIME_CHECKS
   for(bool right:{false,true})for(auto bad:{Mod,UINT32_MAX}){
    auto&target=right?b:a;
    for(auto position:{std::size_t{0},target.size()/2,target.size()-1}){
     target[position]=bad;rejects<std::invalid_argument>([&]{engine.convolution_normalized(a,b);});target[position]=Mod-1;
    }
   }
#endif
  }
 }
}
'''
assert original.count('int main(){')==1
source=original.replace('int main(){',extra+'int main(){quarter_padding_cases<998244353,3>();quarter_padding_cases<167772161,3>();quarter_padding_cases<1053818881,7>();quarter_padding_cases<1224736769,3>();quarter_padding_cases<2013265921,31>();')
p=D/'quarter_padding_reference.cpp';p.write_text(source)
for cc,args in [('gcc',['g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for st in ['checked','skip']:
  exe=D/f'{cc}_{st}_reference';cmd=['taskset','-c','6',*args,'-std=c++23','-O2',*(['-DSKIP_RUNTIME_CHECKS']if st=='skip'else[]),f'-DNTT_HEADER="{D}/quarter_padding.hpp"',str(p),'-o',str(exe)]
  a=subprocess.run(cmd,capture_output=True,text=True);assert a.returncode==0,a.stderr
  run=subprocess.run(['taskset','-c','6',str(exe)],capture_output=True,text=True);r=dict(compiler=cc,setting=st,command=cmd,header_sha256=hashlib.sha256((D/'quarter_padding.hpp').read_bytes()).hexdigest(),source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),returncode=run.returncode,stdout=run.stdout,stderr=run.stderr);rows.append(r);(D/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');assert run.returncode==0 and not run.stderr,r
  print(cc,st,run.stdout.strip(),flush=True)
