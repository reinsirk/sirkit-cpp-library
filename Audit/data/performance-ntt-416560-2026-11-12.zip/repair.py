# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,statistics,fcntl
import bench
D=Path('/tmp/sirkit_ntt_416560');labels=['recursive']
for mode in ['whole','core']:
 rp=D/f'paired_{mode}_raw.json';sp=D/f'paired_{mode}_summary.json';raw=json.loads(rp.read_text());summary=json.loads(sp.read_text());(D/f'paired_{mode}_initial_raw.json').write_bytes(rp.read_bytes());(D/f'paired_{mode}_initial_summary.json').write_bytes(sp.read_bytes())
 with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  for row in summary:
   if row['sufficient']:continue
   fields=['compiler','case','n','m']if mode=='whole'else['compiler','setting','op','n','m']
   def belongs(r):return all(r[k]==row[k]for k in fields)
   if mode=='whole':
    fixture=next(f for f in bench.fixtures if f['name']==row['case'])
    def run(label):return bench.run_whole(row['compiler'],label,fixture)
    key='output_sha256'
   else:
    def run(label):return bench.run_core(row['compiler'],row['setting'],label,row['op'],row['n'],row['m'])
    key='digest'
   local=[r for r in raw if belongs(r)]
   for attempt in range(3):
    missing=[l for l in labels+['control']if sum(r['label']==l and r['calibration_valid']for r in local)<(2 if l=='control'else 5)]
    if not missing:break
    for label in missing:
     for extra in range(3):
      v=[run(l)for l in ['base',label if label!='control'else'base','base']];assert len({r[key]for r in v})==1
      b,t,a=[r['cpu_ns']for r in v];drift=max(b,a)/min(b,a);r={k:row[k]for k in fields};r.update(label=label,rep=len(local),repair=True,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(r);local.append(r)
   ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in labels+['control']};row.update(valid_counts={l:len(v)for l,v in ratios.items()},ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},sufficient=all(len(ratios[l])>=5 for l in labels)and len(ratios['control'])>=2,calibration_repaired=True);print(mode,row,flush=True)
  rp.write_text(json.dumps(raw));sp.write_text(json.dumps(summary,indent=2)+'\n')
 print(mode,'sufficient',sum(r['sufficient']for r in summary),'of',len(summary),flush=True)
