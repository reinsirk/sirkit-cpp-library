# SPDX-License-Identifier: CC0-1.0
# 完了済みの測定・検証から/tmpだけへ証跡を作る。正本への公開は親が行う。
from pathlib import Path
import hashlib,json,math,shutil,statistics,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_ntt_416560');P=Path('/tmp/sirkit_ntt_416532')
LIBRARY='Math/NTT.cpp';PERFORMANCE='Audit/performance-ntt-416560-2026-11-12.json'
ONLINE='Audit/online-ntt-416560-2026-11-12.json';EVIDENCE='Audit/data/performance-ntt-416560-2026-11-12.zip'
PREVIOUS='Audit/distribution-manifest-before-ntt-416560-2026-11-12.json'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def encode(v):return json.dumps(v,ensure_ascii=False,indent=2)+'\n'
def qualified(row,candidate,control_minimum=2):
 return row['valid_counts'].get(candidate,0)>=5 and row['valid_counts'].get('control',0)>=control_minimum and row['ratios'].get(candidate) is not None and row['ratios'].get('control') is not None

def stats(rows,fields,candidate,control_minimum=2):
 out=[]
 for key in sorted({tuple(r[k]for k in fields)for r in rows}):
  group=[r for r in rows if tuple(r[k]for k in fields)==key];valid=[r for r in group if qualified(r,candidate,control_minimum)]
  if valid:out.append(dict(zip(fields,key))|dict(total_cells=len(group),qualified_cells=len(valid),candidate_ratio=math.exp(statistics.mean(math.log(r['ratios'][candidate])for r in valid)),identical_control_ratio=math.exp(statistics.mean(math.log(r['ratios']['control'])for r in valid)),minimum_ratio=min(r['ratios'][candidate]for r in valid),maximum_ratio=max(r['ratios'][candidate]for r in valid)))
 return out

def main():
 selection=load(D/'selection.json');chosen=selection['chosen'];assert chosen in {'subtract','recursive'}
 before=sha(D/'before'/LIBRARY);after=sha(R/LIBRARY);assert before==sha(D/'base.hpp') and before!=after and after==sha(D/'final.hpp')
 frozen=['Verify/current/drivers/ntt_convolution_main.cpp','Verify/current/common/fast_io.hpp','Examples/ntt_example.cpp','Document/ntt.md']
 for p in frozen:assert (R/p).read_bytes()==(D/'before'/p).read_bytes(),p
 assert (R/'Verify/current/submissions/ntt_convolution.cpp').read_bytes()==(D/'final_main.cpp').read_bytes()
 validation=load(D/'final_validation.json');assert validation['header_sha256']==after
 assert validation['all_passed']and validation['passed_jobs']==validation['total_jobs']==len(validation['jobs'])==44
 assert all(x.get('passed')and x['compile_returncode']==x['returncode']==0 and not x['stderr']for x in validation['jobs'])
 tests=['ntt_montgomery_reference_test.cpp','formal_power_series_reference_test.cpp','string_math_allocation_test.cpp'];test_hashes={n:sha(R/'Verify/current/tests'/n)for n in tests}
 for x in validation['jobs']:assert x['test_sha256']==test_hashes[x['test']+'.cpp'],'検査後にテスト変更'
 old_test=sha(D/'reference_test_before.cpp');test_changed=old_test!=test_hashes[tests[0]]
 allocation=[x['counters']for x in validation['jobs']if x['test']=='string_math_allocation_test'];assert len(allocation)==12 and all(x['live_delta']==0 for x in allocation)
 profile=load(D/'profiles/checkpoint.json');assert profile['counts']=={'LOCAL_SAMPLE_PASS':10}and profile['status']=='local_samples_passed_for_snapshot'and profile['completed_at_utc']and profile['active']is None
 bridge=load(D/'text_correspondence.json');assert len(bridge)==10 and all(x.get('final_matches_measured',x.get('final_matches_baseline'))is True for x in bridge)
 assert {(cc,st,k)for cc in ['gcc','clang']for k,ss in [('main',['']),('core',['checked','skip']),('standard_core',['checked','skip'])]for st in ss}=={(x['compiler'],x['setting'],x['kind'])for x in bridge}
 standard=load(D/'standard_builds.json');assert len(standard)==8;lookup={(x['compiler'],x['setting'],x['label']):x for x in standard};standard_matches=[]
 for cc in ['gcc','clang']:
  for st in ['checked','skip']:
   pair=[lookup[cc,st,k]for k in ['base','final']]
   for label,x in zip(['base','final'],pair):assert x['text_sha256']==sha(D/f'{cc}_{st}_standard_{label}_core.text')
   assert pair[0]['text_sha256']==pair[1]['text_sha256'],'標準経路の機械コード差が未評価'
   standard_matches.append(dict(compiler=cc,setting=st,identical=True,text_sha256=pair[0]['text_sha256']))
 whole=load(D/'paired_whole_summary.json');core=load(D/'paired_core_summary.json');focused=load(D/'focused_summary.json');native=load(D/'native_summary.json')
 assert len(whole)==68 and all(qualified(x,chosen)for x in whole)
 assert len(core)==164;insufficient=[x for x in core if not qualified(x,chosen)]
 focus_cases={(6,128),(6,1024),(4,128),(4,1024),(5,1024),(4,65536),(6,65536),(4,524288),(5,524288),(0,524288),(3,524288)}
 assert len(focused)==44 and all(qualified(x,'final',5)and x['sufficient']for x in focused)
 assert {(x['compiler'],x['setting'],x['op'],x['n'])for x in focused}=={(cc,st,op,n)for cc in ['gcc','clang']for st in ['checked','skip']for op,n in focus_cases}
 native_cases={'official_fft_killer_00','official_fft_killer_01','official_max_random_00','official_random_00','official_small_and_large_00','official_small_and_large_01','custom_33x524288_random'}
 assert len(native)==14 and {(x['compiler'],x['case'])for x in native}=={(cc,n)for cc in ['gcc','clang']for n in native_cases}
 assert all({'subtract','recursive','control'}<=set(x['ratios'])and qualified(x,chosen)for x in native)
 fixtures=load(D/'fixtures.json');assert len(fixtures)==73 and(D/'fixtures.json').read_bytes()==(Path('/tmp/sirkit_ntt_416559')/'fixtures.json').read_bytes()
 outputs=load(D/'whole_output_validation.json');assert len(outputs)==146 and {(x['compiler'],x['case'])for x in outputs}=={(cc,f['name'])for cc in ['gcc','clang']for f in fixtures}
 record=next(x for x in load(D/'online_records.json')['records']if x['id']=='ntt_convolution')
 assert record['url']=='https://judge.yosupo.jp/submission/416560'and record['status']=='AC'and record['time_ms']==61 and record['source_hashes']=={LIBRARY:before}
 assert len(record['case_results'])==53 and all(x['status']=='AC'for x in record['case_results'])
 journal=next(x for x in load(R/'Verify/current/judgements.json')['entries']if x['id']=='ntt_convolution')
 assert journal['url']==record['url']and journal['time_ms']==61 and journal['needs_resubmission']and not journal['matched_current_generation']and journal['current_source_hashes']=={LIBRARY:after}
 platform=load(D/'platform_evidence.json');assert platform['published_help']['confirmed_current_html_references_bundle']and platform['published_help']['resource_information']['server']=='c2d-highcpu-8 (GCP)'
 assert '-march=native'in platform['official_compiler']['declared_cpp']['compile']
 proof_files=['subtract_review.md']+(['review/recursive_padding_review.md','review/recursive_padding_metadata.json']if chosen=='recursive'else[])
 for p in proof_files:assert (D/p).is_file()
 dependent=[dict(path=p,before_sha256=sha(D/'before'/p),after_sha256=sha(R/p))for p in ['Math/Formal_Power_Series.cpp','Math/Linear_Recurrence.cpp','Math/Convolution.cpp','Math/Polynomial.cpp']]
 changes=['AVX2剰余減算をmin(a-b,(a-b)+2Mod)へ簡約する。0<=a,b<2Mod・Mod<2^30で、従来のmin(a+2Mod-b,a-b)と全bit一致。uint32の巡回演算とunsigned minだけを使い、C++符号付きオーバーフローを追加しない。']
 if chosen=='recursive':changes+=['元長さから3つの四分領域が追加ゼロと分かるradix4段だけ、8要素へ丸めた有効prefixを処理する。段ごとに同じprefix支持不変条件を保ち、成立しなくなれば通常の段へ継続する。入力係数の値や問題固有分布を調べない。最初の段だけ係数検査と符号化を行い、チェック漏れ・二重符号化を避ける。']
 changes+=['前回の半分ゼロ段・constexpr根・直接逆元・固定オペランド積・blend/4点根の改善、公開API、所有権、容量保護、SKIPの除外、非対応環境の標準経路を維持する。AVX-512実装は追加せず、未対応CPUでの速度や実行成功を主張しない。']
 audit=dict(date='2026-11-12',library=LIBRARY,decision='adopt_'+chosen,selection=selection,required_resubmission=['Verify/current/submissions/ntt_convolution.cpp'],online_evidence=ONLINE,
  online_scope='416560は変更前d4bdef本体で全53ケースAC・61ms。本文/main/共通IOを照合済み。今回採用版は未提出で、このACを現行版や派生版へ転記しない。',source_sha256=dict(before=before,after=after),measured_candidate_sha256=sha(D/(chosen+'.hpp')),
  comment_bridge='最終版と測定候補の既定経路main/coreの.text一致を確認。標準経路も変更前と同一.textであり、同経路の追加高速化とは主張しない。',frozen_main_IO_example={p:sha(R/p)for p in frozen},API_change='公開API・型引数・重要な前提・戻り値・所有権・main/共通IOは不変。Document・使用例は変更しない。',changes=changes,proof_files=proof_files,dependent_generated_sources=dependent,
  candidates=[dict(name=k,sha256=sha(D/(k+'.hpp')),adopted=k==chosen)for k in ['quarter','subtract','quarter_subtract','recursive']if(D/(k+'.hpp')).exists()],
  measurement=dict(topology=load(D/'topology.json'),cpu='i9-14900K CPU12、P-Core、sibling13。E-Core対象外。',compilers=dict(GCC='15.2.0',Clang='21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'),flags=['-std=c++23','-O2'],march_native=False,extra_pragmas=False,compilation_during_timing=False,lock='/tmp/sirkit_performance_cpu12.lock',ASLR='子だけsetarch x86_64 -R、同じactiveパス。',
   protocol='旧版→候補→旧版で候補を両端中央値で割る。旧版両端が10%以内の組だけ有効とし、候補自身の時間では除外しない。基本は候補9組・対照3組、基準は候補5組・同一実行体対照2組。不足種の補充は実際のスクリプト/rawに保存。長時間は候補9組・対照9組で両方5組以上。',
   inputs='固定revision73876f1cbcf082d2b22722924b924d3d65a2f00eの公式53入力と補足20入力、計73件。制約外1048576×1048576も含む。オンライン非公開入力との同一性は主張しない。',fixtures_sha256=sha(D/'fixtures.json'),independent_outputs='38件の独立全出力SHAと全入力の端点・多項式評価0/1/−1。GCC/Clang各73件の変更前後出力SHAを照合。',
   whole_time='固定main/共通IO/SKIP/コンパイラ/入力、子user+system CPU時間。L>=65536またはmax(n,m)>=200000の34入力×2compiler。',whole_rows=len(whole),whole_triplets=len(load(D/'paired_whole_raw.json')),whole_statistics=stats(whole,['compiler'],chosen),official_whole_statistics=stats([x for x in whole if x['case'].startswith('official_')],['compiler'],chosen),
   core_time='std::clock。入力準備は外、API計算・全結果checksum・返却結果破棄は内。coldは毎回NTT作成/解放。prepareは計測外transformで根を観測。基本反復max(1,32768/max(n,m))。',core_operations={0:'normalized cold move',1:'normalized cached move',2:'generic int64 cached',3:'square cached',4:'forward',5:'inverse',6:'prepare cold'},core_rows=len(core),core_triplets=len(load(D/'paired_core_raw.json')),qualified_core_cells=len(core)-len(insufficient),insufficient_core_cells=insufficient,core_statistics=stats(core,['compiler','setting','op'],chosen),large_core_statistics=stats([x for x in core if max(x['n'],x['m'])>=200000],['compiler','setting','op'],chosen),
   focused_long_repetitions=dict(cells=len(focused),triplets=len(load(D/'focused_raw.json')),all_qualified=True,statistics=stats(focused,['compiler','setting','op'],'final',5),rows=focused),
   native_comparison=dict(flags=['-std=c++23','-O2','-march=native'],cpu='同じi9-14900K P-Core。Library Checker公開のMilan実機ではない。',cells=len(native),triplets=len(load(D/'native_raw.json')),selected_qualified=True,all_comparators= ['subtract','recursive'],statistics={k:stats(native,['compiler'],k)for k in ['subtract','recursive']},rows=native),
   standard_path=dict(machine_code=standard_matches,scope='標準経路の変更前後.textは全4条件同一。追加高速化を主張しない。'),comparison_outputs_equal=True,no_claim_every_condition_faster=True,outcome='大規模固定main34入力の幾何平均はGCC約1.6%、Clang約1.2%短縮。公式small_and_large4入力の幾何平均はGCC約5%、Clang約4%短縮。native追加のP-Core比較でも選択候補は概ね同等〜改善し、測定した長時間44条件に3%以上の後退はない。Milan実機の速度比とは主張しない。'),
  platform_evidence='platform_evidence.json',platform_scope='現在配信中の公式help HTMLと参照bundleでC2D/EPYC7B13表記を確認。Google公式ではMilan第3世代、AMD AVX512はGenoa第4世代以降。公開構成からの推定でworker CPUID実測ではない。公式cpp設定は-march=nativeを含み、ローカル基本測定のP-Core/追加marchなしとは区別する。',
  online_maximum_scope='最大は旧53→61msだが、新61msはfft_killer_00に限られ、同規模の他ケースは多くが短縮。一部の短いケースにも孤立遅延がある。この公開結果だけで本体退行や雑音と断定せず、ローカル比較を別に保存する。',
  validation=dict(jobs=44,all_passed=True,tests_sha256=test_hashes,previous_reference_test_sha256=old_test,reference_test_changed=test_changed,reference_scope='既存の独立DFT/直接積・11法・境界・所有権試験に加え、33×257・255×3073・33×65536の両入力順を、(Mod-1)列の積の重なり個数という独立な閉形式で照合。複数段のゼロ省略、8係数丸め、第一/中央/末尾の不正係数を両側で確認。',conditions='GCC/Clang×検査有効/無効×default/SIRKIT_DISABLE_SIMD/CPU判定false。ASAN+UBSANは両compiler・両検査設定・default/SIMD無効。',allocation=allocation,sanitizers='host ptraceのためdetect_leaks=0。別のlive counterで12条件live_delta=0も確認。',machine_code_evidence=bridge,profiles=dict(status=profile['status'],counts=profile['counts'],run_id=profile['run_id']),current_submission_exactly_matches_compiled_final=True,current_submission_bytes=(R/'Verify/current/submissions/ntt_convolution.cpp').stat().st_size),
  license='CC0の独自NTTへの独自実装。外部ライブラリコードは取り込まない。第三者frontend/HTML/TOMLや公式入力生成器本体は証跡へ含めない。',evidence_archive=EVIDENCE,evidence_scope='候補・証明・独立参照試験・測定raw・検証コマンド・公開提出API原本。巨大入力/出力・実行体・外部ソースを除外。プラットフォームはplatform_evidence.jsonの事実/URL/ハッシュだけ保存。')
 for n in tests:
  p=D/'evidence_tests'/n;p.parent.mkdir(exist_ok=True);shutil.copyfile(R/'Verify/current/tests'/n,p)
 meta=D/'fixtures_metadata';meta.mkdir(exist_ok=True)
 for n in ['source_audit.json','commands.json','summary.json']:shutil.copyfile(P/'fixtures'/n,meta/n)
 draft=D/Path(PERFORMANCE).name;evidence=D/Path(EVIDENCE).name;previous=D/Path(PREVIOUS).name
 previous.write_bytes((D/'before/Distribution/manifest.json').read_bytes());(D/'audit_draft.json').write_text(encode(audit));excluded={'audit_draft.json',draft.name,'distribution_update.log'};paths=[]
 for p in D.rglob('*'):
  if not p.is_file()or p.name in excluded or p.suffix not in {'.py','.hpp','.cpp','.json','.diff','.md','.log'}:continue
  rel=p.relative_to(D)
  if rel.parts[0]=='platform_evidence':continue
  if rel.parts[0]=='profiles'and(p.suffix!='.json'or(len(rel.parts)>1 and rel.parts[1]in{'snapshots','artifacts','sources'})):continue
  paths.append(p)
 with zipfile.ZipFile(evidence,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in sorted(paths):z.write(p,p.relative_to(D).as_posix())
 audit['evidence_archive_sha256']=sha(evidence);draft.write_text(encode(audit))
 print(encode(dict(audit=str(draft),audit_target=PERFORMANCE,evidence=str(evidence),evidence_target=EVIDENCE,previous_manifest=str(previous),previous_manifest_target=PREVIOUS,evidence_bytes=evidence.stat().st_size,evidence_files=len(paths),repository_written=False)),end='')
if __name__=='__main__':main()
