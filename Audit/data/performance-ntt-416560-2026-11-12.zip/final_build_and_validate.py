# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib,fcntl
D=Path('/tmp/sirkit_ntt_416560');(D/'selection.json').write_text(json.dumps(dict(chosen='recursive',decision='adopt_avx2_subtraction_and_recursive_known_zero_padding'),indent=2)+'\n');(D/'final.hpp').write_bytes((D/'recursive.hpp').read_bytes())
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 subprocess.run(['python3',str(D/'build.py'),'final'],check=True)
 rows=[];bridge=[]
 def section(p):
  o=Path(str(p)+'.text');subprocess.run(['objcopy','--dump-section','.text='+str(o),str(p)],check=True,capture_output=True);return o.read_bytes()
 for cc,args in [('gcc',['g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for st in ['checked','skip']:
   for label in ['base','final']:
    p=D/f'{cc}_{st}_standard_{label}_core';cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-DSIRKIT_DISABLE_SIMD',*(['-DSKIP_RUNTIME_CHECKS']if st=='skip'else[]),f'-DHEADER="{D}/{label}.hpp"',str(D/'core.cpp'),'-o',str(p)];subprocess.run(cmd,check=True,capture_output=True);rows.append(dict(compiler=cc,setting=st,label=label,command=cmd,text_sha256=hashlib.sha256(section(p)).hexdigest()))
   a=[r for r in rows if r['compiler']==cc and r['setting']==st];assert len({r['text_sha256']for r in a})==1;bridge.append(dict(compiler=cc,setting=st,kind='standard_core',final_matches_baseline=True,text_sha256=a[0]['text_sha256']))
  for kind,settings in [('main',['']),('core',['checked','skip'])]:
   for st in settings:
    a=D/(f'{cc}_final_main'if kind=='main'else f'{cc}_{st}_final_core');b=D/(f'{cc}_recursive_main'if kind=='main'else f'{cc}_{st}_recursive_core');x=section(a);assert x==section(b);bridge.append(dict(compiler=cc,setting=st,kind=kind,final_matches_measured=True,text_sha256=hashlib.sha256(x).hexdigest()))
 (D/'standard_builds.json').write_text(json.dumps(rows,indent=2)+'\n');(D/'text_correspondence.json').write_text(json.dumps(bridge,indent=2)+'\n')
 subprocess.run(['python3',str(D/'validate.py')],check=True,stdout=(D/'validation.log').open('w'))
 print('final44 and machine code bridges PASS',flush=True)
