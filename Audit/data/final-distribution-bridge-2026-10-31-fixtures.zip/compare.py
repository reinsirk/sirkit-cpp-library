# SPDX-License-Identifier: CC0-1.0
import hashlib,json,os,pathlib,stat,zipfile
P=pathlib.Path(__file__).parent;OLD=pathlib.Path('/tmp/sirkit_12h_20261031_095733/distribution_release_candidate');NEW=pathlib.Path('/home/reinsirk/Atcoder_Env/Distribution')
os.sched_setaffinity(0,{0})
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):
    with zipfile.ZipFile(path)as z:
        names=z.namelist();assert len(names)==len(set(names))and z.testzip()is None
        result={}
        for e in z.infolist():
            n=e.filename;assert not n.startswith('/')and '\\'not in n and ':'not in n and all(x and x not in('.','..')for x in n.split('/'))and stat.S_IFMT(e.external_attr>>16)!=stat.S_IFLNK
            data=z.read(n);result[n]=dict(bytes=len(data),sha256=sha(data))
        return result
core=['Variants/manifest.json','Variants/verify_manifest.json','Verify/current/manifest.json']
reports=[]
for path in sorted(NEW.glob('*.zip')):
    original=OLD/path.name;old=read(original);new=read(path)
    added=sorted(new.keys()-old.keys());removed=sorted(old.keys()-new.keys());modified=sorted(n for n in old.keys()&new.keys()if old[n]!=new[n])
    changes=added+removed+modified
    forbidden=[n for n in changes if not(n.startswith('Audit/')or n=='Document/fast_variants.md')]
    assert not forbidden,(path,forbidden)
    # Includes all libraries, all Verify+support, Examples, StandaloneExamples, Scripts,
    # templates, licences and other manifest entries; only Docs/Audit are excluded.
    protected=sorted(n for n in old if not n.startswith(('Audit/','Document/')))
    assert all(n in new and old[n]==new[n]for n in protected)
    category={}
    for label,condition in [('cpp_outside_audit',lambda n:n.endswith('.cpp')and not n.startswith('Audit/')),
      ('standalone_examples',lambda n:n.startswith('StandaloneExamples/')and n.endswith('.cpp')),
      ('examples',lambda n:n.startswith('Examples/')and n.endswith('.cpp')),
      ('tools',lambda n:n.startswith('Scripts/')),
      ('verify_and_support',lambda n:n.startswith('Verify/')or'/Verify/'in n)]:
        names=sorted(n for n in old if condition(n));assert all(n in new and old[n]==new[n]for n in names);category[label]=len(names)
    if path.name.endswith('_full.zip'):
        manifests={n:dict(old=old[n],final=new[n],identical=old[n]==new[n])for n in core}
    else:
        manifests={'Verify/current/manifest.json':dict(old=old['Verify/current/manifest.json'],final=new['Verify/current/manifest.json'],identical=old['Verify/current/manifest.json']==new['Verify/current/manifest.json'])}
    reports.append(dict(name=path.name,original_path=str(original),final_path=str(path),original_zip_sha256=sha(original.read_bytes()),final_zip_sha256=sha(path.read_bytes()),original_bytes=original.stat().st_size,final_bytes=path.stat().st_size,old_entries=old,final_entries=new,diff=dict(added=added,modified=modified,removed=removed),protected_entry_count=len(protected),protected_all_identical=True,categories_identical=category,core_manifests=manifests))
assert len(reports)==5
result=dict(status='passed',scope='Exact final Distribution5ZIP vs frozen release_candidate. Only Audit supplemental evidence/plan/inventory and Document/fast_variants.md differ; every non-Doc/non-Audit entry is identical. Audit supplemental C++/Python files are excluded from library/tool equality categories.',archives=reports)
(P/'entry_comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print('all5ZIP protected payload and core manifest bridges PASS')
for r in reports:print(r['name'],r['final_zip_sha256'],{k:len(v)for k,v in r['diff'].items()})
