# SPDX-License-Identifier: CC0-1.0
from __future__ import annotations
import hashlib,json,os,pathlib,signal,stat,subprocess,sys,time,zipfile,zlib
P=pathlib.Path(__file__).parent
INPUT=pathlib.Path('/tmp/sirkit_12h_20261031_095733/distribution_release_candidate')
EXTRACT=P/'extracted'
REBUILT=P/'rebuilt'
REPORT=P/'checkpoint.json'
os.sched_setaffinity(0,{0})
state=dict(status='starting',python=sys.version,python_executable=sys.executable,zlib=zlib.ZLIB_VERSION,zlib_runtime=zlib.ZLIB_RUNTIME_VERSION,cpu=0,commands=[],archives=[])
def sha(data):return hashlib.sha256(data).hexdigest()
def save():REPORT.write_text(json.dumps(state,indent=2)+'\n')
def pause():
 while(P/'pause').exists():(P/'pause_ack').write_text('no active child\n');time.sleep(.25)
 (P/'pause_ack').unlink(missing_ok=True)
def run(name,command,timeout=600):
 pause();folder=P/'logs';folder.mkdir(exist_ok=True);out=folder/(name+'.stdout');err=folder/(name+'.stderr')
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',LC_ALL='C',LANG='C')
 for key in ('PYTHONPATH','CPATH','CPLUS_INCLUDE_PATH','C_INCLUDE_PATH','OBJC_INCLUDE_PATH','INCLUDE'):env.pop(key,None)
 record=dict(name=name,command=command,cwd=str(EXTRACT),timeout_seconds=timeout,started=time.time(),stdout=str(out),stderr=str(err))
 state['active']=record;save()
 with out.open('wb')as a,err.open('wb')as b:
  child=subprocess.Popen(command,cwd=EXTRACT,stdout=a,stderr=b,env=env,start_new_session=True)
  try:record['returncode']=child.wait(timeout=timeout);record['status']='EXITED'
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait();record.update(returncode=child.returncode,status='TIMEOUT')
 record.update(elapsed=time.time()-record['started'],stdout_sha256=sha(out.read_bytes()),stderr_sha256=sha(err.read_bytes()))
 state['commands'].append(record);state['active']=None;save();print(name,record['status'],record['returncode'],flush=True)
 return record['returncode']==0 and record['status']=='EXITED'

def payloads(path):
 with zipfile.ZipFile(path)as z:
  names=z.namelist();assert len(names)==len(set(names)),('duplicate',path)
  assert z.testzip()is None,('CRC',path)
  rows=[]
  for entry in z.infolist():
   name=entry.filename;parts=pathlib.PurePosixPath(name).parts
   assert name and not name.startswith('/')and '\\'not in name and ':'not in name and all(x not in ('..','.')for x in parts),(path,name)
   assert stat.S_IFMT(entry.external_attr>>16)!=stat.S_IFLNK,('symlink',name)
   rows.append(dict(path=name,size=entry.file_size,sha256=sha(z.read(name))))
  return rows

if EXTRACT.exists():raise SystemExit('refuse to reuse nonempty extraction destination')
EXTRACT.mkdir();REBUILT.mkdir(exist_ok=True)
paths=sorted(INPUT.glob('*.zip'));assert len(paths)==5
for path in paths:
 rows=payloads(path);state['archives'].append(dict(path=str(path),sha256=sha(path.read_bytes()),bytes=path.stat().st_size,entries=rows))
state['status']='extracting';save()
with zipfile.ZipFile(INPUT/'sirkit-cpp-library_full.zip')as archive:archive.extractall(EXTRACT)
# No workspace include/import paths; the extraction owns every invoked script.
state['extracted_scripts']=[dict(path=str(f.relative_to(EXTRACT)),sha256=sha(f.read_bytes()))for f in sorted((EXTRACT/'Scripts').rglob('*'))if f.is_file()]
state['extracted_manifests']=[dict(path=str(f.relative_to(EXTRACT)),sha256=sha(f.read_bytes()))for f in sorted(EXTRACT.rglob('*manifest*.json'))if f.is_file()]
state['status']='testing';save()
checks=[]
checks.append(run('unit_tests',[sys.executable,'-m','unittest','discover','-s','Scripts/tests','-v']))
checks.append(run('check_generated',[sys.executable,'-c',"from pathlib import Path; import sys; sys.path.insert(0,'Scripts'); import package_revised_libraries as p; p.check_generated(Path.cwd())"]))
checks.append(run('package_full',[sys.executable,'Scripts/package_revised_libraries.py',str(REBUILT/'sirkit-cpp-library_full.zip')]))
checks.append(run('package_profiles',[sys.executable,'Scripts/package_compiler_libraries.py',str(REBUILT)]))
state['comparison']=[]
for before in paths:
 after=REBUILT/before.name
 if not after.exists():state['comparison'].append(dict(name=before.name,status='MISSING_REBUILD'));checks.append(False);continue
 a=next(x['entries']for x in state['archives']if x['path']==str(before));b=payloads(after)
 same_payload=a==b
 item=dict(name=before.name,payload_lists_identical=same_payload,original_sha256=sha(before.read_bytes()),rebuilt_sha256=sha(after.read_bytes()),original_bytes=before.stat().st_size,rebuilt_bytes=after.stat().st_size)
 item['byte_identical']=item['original_sha256']==item['rebuilt_sha256']
 if not same_payload:
  da={x['path']:x for x in a};db={x['path']:x for x in b};item['missing']=sorted(da.keys()-db.keys());item['extra']=sorted(db.keys()-da.keys());item['changed']=[x for x in da.keys()&db.keys()if da[x]!=db[x]]
 state['comparison'].append(item);checks.append(same_payload and item['byte_identical'])
state['status']='passed'if all(checks)else'failed';save();print(state['status'],flush=True)
