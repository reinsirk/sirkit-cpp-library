# SPDX-License-Identifier: CC0-1.0
import hashlib,json,os,pathlib,subprocess,zipfile
P=pathlib.Path(__file__).parent
CACHE=pathlib.Path('/tmp/sirkit_12h_20261031_095733/standalone_zip_validation')
REFERENCE=CACHE/'final_delta/snapshot.json'
INPUT=pathlib.Path('/tmp/sirkit_12h_20261031_095733/distribution_release_candidate')
os.sched_setaffinity(0,{0})
def sha(data):return hashlib.sha256(data).hexdigest()
def load(path):return json.loads(path.read_text())
prior=load(REFERENCE)
versions={}
for compiler,command in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 versions[compiler]=subprocess.run(command+['--version'],env=dict(os.environ,LC_ALL='C',LANG='C'),capture_output=True,text=True,check=True).stdout
rows=[]
for edition in ('full','gcc','clang','fast_gcc','fast_clang'):
 # Previous runner labels use underscores, matching current archive slugs.
 relevant=[x for x in prior['plans']if x['edition'].replace('-','_')==edition]
 expected=206 if edition=='full' else 103
 assert len(relevant)==expected,(edition,len(relevant))
 path=INPUT/f'sirkit-cpp-library_{edition}.zip'
 with zipfile.ZipFile(path)as archive:
  names=archive.namelist();assert len([n for n in names if n.startswith('StandaloneExamples/')and n.endswith('.cpp')])==103
  for old in relevant:
   data=archive.read(old['entry']);digest=sha(data);assert digest==old['entry_sha256'],(edition,old['name'],'source changed')
   recipe=old['compile_recipe'];assert recipe['entry_sha256']==digest
   assert recipe['compiler_version']==versions[old['compiler']]
   assert recipe['flags']==['-std=c++23','-O2','-Wall','-Wextra']
   assert recipe['compiler_command']==(['/usr/bin/g++']if old['compiler']=='GCC'else['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])
   compiled_path=CACHE/'compile_cache'/(old['compile_key']+'.json');compiled=load(compiled_path);assert compiled['status']=='PASS'and compiled['recipe']==recipe
   binary=CACHE/'artifacts'/old['compile_key']/'program';assert binary.is_file()and sha(binary.read_bytes())==compiled['binary_sha256']
   run_path=CACHE/'run_cache'/(old['run_key']+'.json');ran=load(run_path);assert ran['status']=='PASS'and ran['recipe']==old['run_recipe']
   assert all(x['matched']and x['returncode']==0 and x['status']=='EXITED'for x in ran['samples'])
   rows.append(dict(edition=edition,compiler=old['compiler'],entry=old['entry'],entry_sha256=digest,compile_key=old['compile_key'],run_key=old['run_key'],compile_recipe=recipe,run_recipe=old['run_recipe'],binary_sha256=compiled['binary_sha256'],compile_result_sha256=sha(compiled_path.read_bytes()),run_result_sha256=sha(run_path.read_bytes()),status='CACHED_IDENTICAL_PASS'))
assert len(rows)==618
report=dict(status='passed',conditions=618,recompiled=0,rerun=0,scope='Archive-entry source bytes, compiler command/version/flags, exact inputs/output/checker recipe and prior passing result artifacts match. Binaries independently SHA checked. This is a versioned normal-output regression bridge, not independent mathematical proof or online AC.',reference_snapshot=str(REFERENCE),reference_snapshot_sha256=sha(REFERENCE.read_bytes()),archives=[dict(path=str(f),sha256=sha(f.read_bytes()))for f in sorted(INPUT.glob('*.zip'))],compiler_versions=versions,rows=rows)
(P/'standalone_bridge.json').write_text(json.dumps(report,indent=2)+'\n')
print('618 exact archive/source/compiler/input/checker/result bridges PASS; 0 recompiles')
