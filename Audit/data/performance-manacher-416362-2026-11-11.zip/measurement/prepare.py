# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
D=Path('/tmp/sirkit_manacher_416362');base=(D/'before/String/Manacher.cpp').read_text();(D/'base.hpp').write_text(base)
start=base.index('    // centerは文字上');finish=base.index('    return result;',start);body=base[start:finish]
def make(name,part): (D/(name+'.hpp')).write_text(base[:start]+part+base[finish:])
u32=body.replace('std::size_t','unsigned int').replace('    for (unsigned int center = 0; center < result.size(); ++center) {','    const auto centers = static_cast<unsigned int>(result.size());\n    for (unsigned int center = 0; center < centers; ++center) {')
make('unsigned_index',u32)
limit=body.replace('        while (l >= 0 && r < n && s[l] == s[r]) { --l; ++r; length += 2; }','''        int remaining = std::min(l + 1, n - r);
        while (remaining > 0 && s[l] == s[r]) { --l; ++r; length += 2; --remaining; }''')
make('limit',limit)
distance=body.replace('while (l >= 0 && r < n && s[l] == s[r]) { --l; ++r; length += 2; }','while (l >= 0 && r < n && s[l] == s[r]) { --l; ++r; }\n        length = r - l - 1;')
make('distance',distance)
end_r=body.replace('const auto end = center + static_cast<std::size_t>(length) - 1;','const auto end = std::size_t{2} * static_cast<std::size_t>(r - 1);')
make('end_r',end_r)
for name,part in [('unsigned_limit',limit),('unsigned_distance',distance),('unsigned_end',end_r)]:
 part=part.replace('std::size_t','unsigned int').replace('unsigned int{2}','static_cast<unsigned int>(2)').replace('    for (unsigned int center = 0; center < result.size(); ++center) {','    const auto centers = static_cast<unsigned int>(result.size());\n    for (unsigned int center = 0; center < centers; ++center) {');make(name,part)
