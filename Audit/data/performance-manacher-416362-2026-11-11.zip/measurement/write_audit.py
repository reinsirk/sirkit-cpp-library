# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_manacher_416362');P=Path('/tmp/sirkit_manacher_416358')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['Verify/current/drivers/manacher_main.cpp','Verify/current/common/fast_io.hpp']:
 assert (R/n).read_bytes()==(D/'before'/n).read_bytes()
old=(D/'before/String/Manacher.cpp').read_text();new=(R/'String/Manacher.cpp').read_text();begin='#ifndef SIRKIT_PALINDROME_RADII_DEFINED';end='#ifndef SIRKIT_PALINDROMIC_LENGTHS_DEFINED';assert old[old.index(begin):old.index(end)]==new[new.index(begin):new.index(end)]
whole=load(D/'final_summary.json');focused=load(D/'focused_summary.json');typed=load(D/'typed_summary.json');fixtures=load(P/'agent_fixtures/fixtures.json');runs=sorted((D/'profiles/runs').glob('*.json'));assert runs and load(runs[-1])['counts']=={'LOCAL_SAMPLE_PASS':10}
labels=['unsigned_index','limit','distance','end_r','unsigned_limit','unsigned_distance','unsigned_end','push','unsigned_push','skip_zero']
audit={
 'date':'2026-11-11','library':'String/Manacher.cpp','decision':'accept_unsigned_center_index_standard_Cpp23','required_resubmission':['Verify/current/submissions/manacher.cpp'],
 'online':{'url':'https://judge.yosupo.jp/submission/416362','status':'AC','time_ms':24,'previous_time_ms':30,'observed_reduction_percent':20,'evidence':'Audit/online-manacher-416362-2026-11-11.json','scope':'変更前の本文と本体/main/共通IOを空白等のみ除いて照合。24msは現行改修のオンライン結果ではない。'},
 'change':['PalindromicLengthsのmiddle/right/centerと鏡像/境界算術を、size_tからintと同幅の符号なしCenterへ変更。測定環境では64bitから32bit。','n<INT_MAXの全域を保ち、コンパイラ別/入力分布別の実装切替は追加しない。','返却要素数はcount+(count-1)、容量はmax_size()/2+max_size()%2で判定し、途中の倍化/加算のwrapを避ける。','前回の中心一体化・中間配列省略・確定値再利用は維持。PalindromeRadiiと全照会API、本体所有権、例外保証、main/IOは維持。'],
 'bounds_proof':['M=INT_MAX、U=UINT_MAX=2M+1、n<=M-1より、返却長2n-1<=U-4、center/right<=2n-2<=U-5。','center+length+1<=2n<=U-3で中間和もCenterに収まる。ループ上限のresult.size()からCenterへのcastも正確。','center<rightならmiddle<=centerかつright<=2middleなので、middle-(center-middle)は非負の処理済み添字。','available=right-center+1はn以内。lのcast前値は0..n-1、rは1..nなのでintへ正確に変換でき、lの-1はcast後に行う。','Centerよりsize_tが狭い場合も、確保済みvectorの添字はそのsize以内なのでsize_tへの変換は正確。','capacity/2+capacity%2はceil(capacity/2)を加算wrapなしで求め、通過したcount>0ではcount+(count-1)<=capacity。','O(n)時間、返却vector O(n)、比較だけが必要な汎用列と同値関係の前提は不変。'],
 'source_hashes':{'before':sha(D/'before/String/Manacher.cpp'),'after':sha(R/'String/Manacher.cpp'),'submission_after':sha(R/'Verify/current/submissions/manacher.cpp'),'main':sha(R/'Verify/current/drivers/manacher_main.cpp'),'IO':sha(R/'Verify/current/common/fast_io.hpp')},
 'fixed_conditions':{'main_unchanged':True,'IO_unchanged':True,'skip_runtime_checks':True,'query_batching_or_problem_specific_dispatch':False,'submission_bytes':(R/'Verify/current/submissions/manacher.cpp').stat().st_size},
 'measurement':{'cpu':'Intel Core i9-14900K、CPU 12/core 6 P-Core、sibling CPU 13、max6GHz','E_Core_measured':False,'compilers':{'gcc':'15.2.0','clang':'21.1.8 (--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15)'},'flags':['-std=c++23','-O2'],'march_native':False,'additional_pragmas':False,'lock':'/tmp/sirkit_performance_cpu12.lock','ASLR':'子プロセスのみsetarch x86_64 -R。システム設定を変更しない。','order':'before/control/candidatesを決定的にシャッフルし、同じactiveパスで実行。controlはbeforeと同じ実行ファイル。','whole_scope':'固定main/IO全体のuser+system時間。after中央値をbefore/control pooled中央値と比較。','baseline':'今回のAC24ms版。初回AC30ms版ではない。','fixtures':len(fixtures),'official_revision':'73876f1cbcf082d2b22722924b924d3d65a2f00e','fixture_note':'前回の公式固定生成器24入力と自作26入力を再利用。制約外1000000を含む。オンライン現行入力の同一性は主張しない。','whole_final_repetitions':9,'whole_final_runs':len(load(D/'final_raw.json')),'focused_repetitions':21,'focused_runs':len(load(D/'focused_raw.json')),'outputs_equal':True,'focused_results':[{**r,'reduction_percent':100*(1-r['ratios']['unsigned_index'])}for r in focused],'final_text_equivalence':load(D/'final_builds.json')},
 'generic_API_measurement':{'operations':{'0':'PalindromicLengths(string)','1':'PalindromicLengths(vector<int64_t>)','2':'PalindromicLengths(vector<bool>)'},'sizes':[32,4096,500000],'shapes':{'0':'all_same','1':'periodic3','2':'binary_random'},'repetitions':7,'runs':len(load(D/'typed_raw.json')),'scope':'入力生成を除き、結果領域確保/計算/破棄を含む反復呼出しのsteady_clock時間。Verify全体の時間とは区別。','checksums_equal':True,'large_results':[r for r in typed if r['n']==500000],'unchanged_public_Radii':'クラス本体/全照会APIは完全同一。前回Auditの単独API機械語一致検証も参照。'},
 'limits':{'GCC':'同値列は重点再測定で約2.7%短縮。大規模ランダムは同等の条件も多く、全条件の改善とは言わない。prefix_then_randomには約1.2%増が残る。','Clang':'重点7条件は約3.9〜6.0%短縮。全50入力の初測定ではprefix_then_randomに約2.7%増があったが、21回の重点再測定では約3.9%減。揺れを含むため一律の保証はしない。','small':'小入力の全体時間は起動時間で増減する。単発最速値で採否を決めない。','online':'24msからの差は未提出のため未確認。特にGCCの改善幅は小さく、オンラインでは差が出ない可能性がある。'},
 'verification':{'final_tests':load(D/'tests.json'),'sanitizers':'GCC/Clang×checked/SKIPの独立参照と長列SA/LCP参照はASan/UBSan。global new失敗注入はサニタイザなし。','independent':'全中心の直接展開、正順+区切り+逆順SA/LCPからの独立半径を参照。各設定130 cases/9234184 checks、別の文字列全探索約597万checks。','types_and_boundaries':'全256バイト/NUL、500000、空列・奇偶境界、int64極値、bool、noncopyable、explicit bool proxy、比較例外、size_t巨大長、size()がintのINT_MAX-1仮想列。','allocation':'各コンパイラ2343 checks / 69 injected failures / live_delta=0。','quick_candidates':load(D/'quick_tests.json'),'profiles':{'run_file':'profiles/runs/'+runs[-1].name,'counts':load(runs[-1])['counts'],'scope':'通常/GCC/Clang/速度優先GCC/速度優先Clangの提出用コードと使用例。'}},
 'candidates':{'count':len(labels),'source_sha256':{name:sha(D/(name+'.hpp'))for name in labels},'rejected':{'limit':'境界比較を残り長へまとめる案。別条件の退行で不採用。','distance/end_r variants':'length更新省略やrからのend再計算、Center化との併用も測定したが、同値列/回文等に退行。','push/unsigned_push':'零初期化を省きreserve+push_backで直接出力。全体の同値列は速いが、汎用APIの大規模二値列でGCC約4〜7%/Clang約5〜6%遅い条件があるため不採用。','skip_zero':'確定値0の書込みを省く追加分岐が別条件を悪化させるため不採用。','SIMD':'今回再測定したという意味ではない。前回のreverse word/AVX2はランダム条件の負荷増で不採用、現行の比較ループは同じなので専用実装を追加していない。'}},
 'documentation':'公開API・利用方法・計算量は不変。型幅の理由を内部コメントで短く記載し、Document/READMEに性能履歴を追加しない。',
 'license':'採用コード/計測補助は独自CC0-1.0。前回固定公式生成器の本文は収録せず、URL/ハッシュ/再生成手順だけ参照。',
 'prior_evidence':'Audit/performance-manacher-416358-2026-11-11.json','evidence_zip':'Audit/data/performance-manacher-416362-2026-11-11.zip'
}
p=R/'Audit/performance-manacher-416362-2026-11-11.json';p.write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n');files=[]
for f in D.iterdir():
 if f.is_file()and f.suffix in ['.json','.py','.hpp','.log']:files.append((f,'measurement/'+f.name))
for n in ['fixtures.json','official_sources.json','official_generation_plan.json','prepare.py']:
 files.append((P/'agent_fixtures'/n,'fixture_dependencies/'+n))
for n in ['typed_benchmark.cpp','quick_test.cpp']:files.append((P/n,'measurement/'+n))
for f in (D/'profiles').rglob('*.json'):files.append((f,'profiles/'+str(f.relative_to(D/'profiles'))))
for n in ['416362.cpp','before/String/Manacher.cpp','before/Verify/current/submissions/manacher.cpp','before/Verify/current/drivers/manacher_main.cpp','before/Verify/current/common/fast_io.hpp']:files.append((D/n,n))
for n in ['String/Manacher.cpp','Verify/current/submissions/manacher.cpp','Verify/current/tests/manacher_independent_test.cpp','Verify/current/tests/string_algorithms_reference_test.cpp','Verify/current/tests/string_math_allocation_test.cpp','Audit/online-manacher-416362-2026-11-11.json','Audit/performance-manacher-416362-2026-11-11.json']:files.append((R/n,'after/'+n))
with zipfile.ZipFile(R/audit['evidence_zip'],'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f,n in sorted(files,key=lambda v:v[1]):z.writestr(zipfile.ZipInfo(n,(2026,11,11,0,0,0)),f.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
print('audit/evidence',len(files),(R/audit['evidence_zip']).stat().st_size)
