#line 1 "Math/a.cpp"
// API prefix \ 
#define FLAG 1
inline int test(){
#ifdef FLAG
return 1;
#else
return 0;
#endif
}


int main(){return test();}
