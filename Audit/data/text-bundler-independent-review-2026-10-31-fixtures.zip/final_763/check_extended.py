from pathlib import Path
import sys,importlib.util,json,subprocess,hashlib
p=Path(__file__).resolve().parent;sys.dont_write_bytecode=True;sys.path.insert(0,str(p));spec=importlib.util.spec_from_file_location('review_bundle',p/'bundle_libraries.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);rows=[]
def obj(text,name):return {'library':'Math/'+name,'source':'Math/'+name,'data':text.encode()}
def execute(cmd):
 r=subprocess.run(cmd,capture_output=True,text=True);return {'command':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
def case(name,modules,main,flags=()):
 bundled,meta=module.optimize_modules(modules);before=''.join('#line 1 '+json.dumps(m['source'])+'\n'+m['data'].decode()+'\n'for m in modules).encode()+main.encode();after=bundled+main.encode();(p/(name+'_before.cpp')).write_bytes(before);(p/(name+'_after.cpp')).write_bytes(after)
 for label,cc,extra in [('GCC','/usr/bin/g++',[]),('Clang','/usr/bin/clang++',['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  outputs=[]
  for kind in ['before','after']:
   source=p/(name+'_'+kind+'.cpp');binary=p/(name+'_'+label+'_'+kind);record=execute(['taskset','-c','8',cc,*extra,'-std=c++23','-O0',*flags,str(source),'-o',str(binary)]);record['run']=execute(['taskset','-c','8',str(binary)])if record['returncode']==0 else None;outputs.append(record)
  row={'name':name,'compiler':label,'prototype_sha256':hashlib.sha256((p/'bundle_libraries.py').read_bytes()).hexdigest(),'removals':meta['removals'],'runs':outputs,'equivalent':outputs[0]['returncode']==outputs[1]['returncode']and bool(outputs[0]['run'])==bool(outputs[1]['run'])and(outputs[0]['run']is None or(outputs[0]['run']['returncode'],outputs[0]['run']['stdout'])==(outputs[1]['run']['returncode'],outputs[1]['run']['stdout']))};rows.append(row);print(name,label,'equivalent',row['equivalent'])
A='#ifndef SIRKIT_A_DEFINED\n#define SIRKIT_A_DEFINED\ninline int a=1;\n#elifdef ENABLE\ninline int b=2;\n#endif\n';case('elifdef',[obj(A,'a.cpp'),obj(A,'b.cpp')],'\nint main(){return a+b==3?0:1;}\n',['-DENABLE'])
A='#ifndef SIRKIT_A_DEFINED\n#define SIRKIT_A_DEFINED\n#define TOKEN 1\n#endif\n';case('space_spliced_undef',[obj(A+'#undef TOKEN\n#un\\ \ndef SIRKIT_A_DEFINED\n','a.cpp'),obj(A,'b.cpp')],'\nint main(){return TOKEN==1?0:1;}\n')
A='// API prefix \\ \n#define FLAG 1\ninline int test(){\n#ifdef FLAG\nreturn 1;\n#else\nreturn 0;\n#endif\n}\n';case('space_spliced_frontmatter',[obj(A,'a.cpp')],'\nint main(){return test();}\n')
A='#ifndef SIRKIT_A_DEFINED\n#define SIRKIT_A_DEFINED\n#define TOKEN 1\n#endif\n'
P=r'''#define CAT(a,b) a##b
#define P(s) CAT(_Pra,gma)(s)
P("push_macro(\"SIRKIT_A_DEFINED\")")
'''
Q=r'''#undef TOKEN
P("pop_macro(\"SIRKIT_A_DEFINED\")")
'''
case('pasted_pragma',[obj(P+A+Q,'a.cpp'),obj(A,'b.cpp')],'\nint main(){return TOKEN==1?0:1;}\n')
case('digraph_pasted_pragma',[obj(P.replace('a##b','a%:%:b')+A+Q,'a.cpp'),obj(A,'b.cpp')],'\nint main(){return TOKEN==1?0:1;}\n')
try:
 selected,_,_=module.load_modules(Path('/home/reinsirk/Atcoder_Env'),'normal',['temp.cpp']);main_selected=bool(selected)
except ValueError as e:main_selected=False;main_message=str(e)
else:main_message='accepted actual manifest temp.cpp containing main'
rows.append({'name':'actual_template_main_selection','accepted':main_selected,'message':main_message});print('template main accepted',main_selected)
(p/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
