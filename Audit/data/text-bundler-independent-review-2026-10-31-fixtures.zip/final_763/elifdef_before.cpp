#line 1 "Math/a.cpp"
#ifndef SIRKIT_A_DEFINED
#define SIRKIT_A_DEFINED
inline int a=1;
#elifdef ENABLE
inline int b=2;
#endif

#line 1 "Math/b.cpp"
#ifndef SIRKIT_A_DEFINED
#define SIRKIT_A_DEFINED
inline int a=1;
#elifdef ENABLE
inline int b=2;
#endif


int main(){return a+b==3?0:1;}
