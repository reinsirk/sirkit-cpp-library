// Readable module bundle; component guards and source provenance are retained.
// Library: Math/a.cpp

// Library: Math/b.cpp


// Definitions: Math/a.cpp
#line 1 "Math/a.cpp"
#define CAT(a,b) a%:%:b
#define P(s) CAT(_Pra,gma)(s)
P("push_macro(\"SIRKIT_A_DEFINED\")")
#ifndef SIRKIT_A_DEFINED
#define SIRKIT_A_DEFINED
#define TOKEN 1
#endif
#undef TOKEN
P("pop_macro(\"SIRKIT_A_DEFINED\")")
// Definitions: Math/b.cpp
#line 1 "Math/b.cpp"
#ifndef SIRKIT_A_DEFINED
#define SIRKIT_A_DEFINED
#define TOKEN 1
#endif

int main(){return TOKEN==1?0:1;}
