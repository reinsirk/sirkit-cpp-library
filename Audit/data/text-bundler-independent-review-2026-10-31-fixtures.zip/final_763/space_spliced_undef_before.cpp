#line 1 "Math/a.cpp"
#ifndef SIRKIT_A_DEFINED
#define SIRKIT_A_DEFINED
#define TOKEN 1
#endif
#undef TOKEN
#un\ 
def SIRKIT_A_DEFINED

#line 1 "Math/b.cpp"
#ifndef SIRKIT_A_DEFINED
#define SIRKIT_A_DEFINED
#define TOKEN 1
#endif


int main(){return TOKEN==1?0:1;}
