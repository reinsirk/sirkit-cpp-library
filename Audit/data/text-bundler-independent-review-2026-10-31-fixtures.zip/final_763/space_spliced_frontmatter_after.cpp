// Readable module bundle; component guards and source provenance are retained.
// Library: Math/a.cpp
// API prefix \ 
#define FLAG 1

// Definitions: Math/a.cpp
#line 3 "Math/a.cpp"
inline int test(){
#ifdef FLAG
return 1;
#else
return 0;
#endif
}

int main(){return test();}
