// Readable module bundle; component guards and source provenance are retained.
// Library: Math/a.cpp
// API prefix \ 

// Definitions: Math/a.cpp
#line 2 "Math/a.cpp"
#define FLAG 1
inline int test(){
#ifdef FLAG
return 1;
#else
return 0;
#endif
}

int main(){return test();}
