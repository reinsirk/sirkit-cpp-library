// Readable module bundle; component guards and source provenance are retained.
// Library: Math/a.cpp

// Library: Math/b.cpp


// Definitions: Math/a.cpp
#line 1 "Math/a.cpp"
#ifndef SIRKIT_A_DEFINED
#define SIRKIT_A_DEFINED
inline int a=1;
#elifdef ENABLE
inline int b=2;
#endif
// Definitions: Math/b.cpp
#line 1 "Math/b.cpp"
// Identical guarded component omitted.
#line 7 "Math/b.cpp"

int main(){return a+b==3?0:1;}
