from pathlib import Path
import json,subprocess,sys,tempfile,hashlib,importlib.util
p=Path(__file__).resolve().parent;target=p/'final_8841';sys.dont_write_bytecode=True;sys.path.insert(0,str(target));import bundle_libraries as b
rows=[]
def run(cmd):
 r=subprocess.run(cmd,capture_output=True,text=True);return {'command':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
A='#ifndef SIRKIT_A_DEFINED\n#define SIRKIT_A_DEFINED\ninline int value=1;\n#endif\n'
with tempfile.TemporaryDirectory(dir=p)as tmp:
 root=Path(tmp);normal=root/'Math/A.cpp';origin=root/'Fast/Source/Math/A.cpp';profile=root/'Fast/GCC/Math/A.cpp'
 for f in [normal,origin,profile]:f.parent.mkdir(parents=True,exist_ok=True);f.write_text(A)
 manifest=root/'Variants/manifest.json';manifest.parent.mkdir();entry={'source':'Math/A.cpp','origin':'Fast/Source/Math/A.cpp','compiler':'GCC','fast':True,'path':'Fast/GCC/Math/A.cpp','source_sha256':b.digest(A.encode()),'sha256':b.digest(A.encode())};manifest.write_text(json.dumps({'entries':[entry]}));base=[sys.executable,str(target/'bundle_libraries.py'),'--root',str(root),'--profile','fast-gcc','--library','Math/A.cpp']
 for flag in ['--output','--report']:
  cmd=base+(['--output',str(origin)]if flag=='--output'else['--output',str(root/'out.cpp'),'--report',str(origin)]);r=run(cmd);assert r['returncode']==1 and origin.read_text()==A;rows.append({'case':'protect_fast_origin_'+flag,'passed':True,'result':r})
 for field,value in [('source','../outside.cpp'),('path','../outside.cpp'),('origin','../outside.cpp'),('path','Fast/Clang/Math/A.cpp')]:
  bad=dict(entry);bad[field]=value;manifest.write_text(json.dumps({'entries':[bad]}));r=run(base+['--output',str(root/'out.cpp')]);assert r['returncode']==1;rows.append({'case':'reject_manifest_'+field+'_'+value,'passed':True,'result':r})
 large='// '+('x'*(b.LIMIT+1))+'\n'+A;normal.write_text(large);manifest.write_text(json.dumps({'entries':[dict(entry,fast=False,path='Variants/GCC/Math/A.cpp',origin='Math/A.cpp',source_sha256=b.digest(large.encode()))]}));output=root/'limit.cpp';output.write_text('sentinel');r=run([sys.executable,str(target/'bundle_libraries.py'),'--root',str(root),'--library','Math/A.cpp','--output',str(output)]);assert r['returncode']==2 and output.read_text()=='sentinel';rows.append({'case':'512KiB_reject_preserves_existing_output','passed':True,'result':r})
for include in ['"a.hpp"','HEADER','<atcoder/modint>','<unknown.hpp>']:
 try:b.optimize_modules([{'library':'Math/A.cpp','source':'Math/A.cpp','data':('#if 0\n#include '+include+'\n#endif\n'+A).encode()}])
 except ValueError:rows.append({'case':'reject_include_'+include,'passed':True})
 else:raise AssertionError(include)
# __FILE__/__LINE__ are compared as executable output under standard #line origins.
first='// SPDX-License-Identifier: CC0-1.0\n// API A\n#include <cstdio>\n#ifndef SIRKIT_LINE_DEFINED\n#define SIRKIT_LINE_DEFINED\ninline const char*fa=__FILE__; inline int la=__LINE__;\n#endif\n'
second='/* LICENSE B */\n// API B\n'+first[first.index('#ifndef'):]+ 'inline const char*fb=__FILE__; inline int lb=__LINE__;\n'
mods=[{'library':'Math/a.cpp','source':'Math/a.cpp','data':first.encode()},{'library':'Math/b.cpp','source':'Math/b.cpp','data':second.encode()}];after,meta=b.optimize_modules(mods);assert len(meta['removals'])==1;assert after.index(b'LICENSE B')<after.index(b'#include');main='\nint main(){std::printf("%s %d %s %d\\n",fa,la,fb,lb);}\n';before=''.join('#line 1 '+json.dumps(m['source'])+'\n'+m['data'].decode()for m in mods)+main
for label,cc,args in [('GCC','/usr/bin/g++',[]),('Clang','/usr/bin/clang++',['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 values=[]
 for name,data in [('before',before.encode()),('after',after+main.encode())]:
  cpp=p/f'line_{label}_{name}.cpp';binary=cpp.with_suffix('');cpp.write_bytes(data);r=run(['taskset','-c','8',cc,*args,'-std=c++23',str(cpp),'-o',str(binary)]);assert r['returncode']==0,r;v=run(['taskset','-c','8',str(binary)]);assert v['returncode']==0;values.append(v['stdout'])
 assert values[0]==values[1];rows.append({'case':'standard_line_file_frontmatter_'+label,'passed':True,'stdout':values[0]})
root=Path('/home/reinsirk/Atcoder_Env');libs=['Math/NTT.cpp','Math/Formal_Power_Series.cpp','Math/Polynomial.cpp','Math/Convolution.cpp']
for profile in ['normal','gcc','clang','fast-gcc','fast-clang']:
 modules,_,_=b.load_modules(root,profile,libs);data,meta=b.optimize_modules(modules);cpp=p/f'no_skip_{profile}.cpp';cpp.write_bytes(data+b'\n#ifdef SKIP_RUNTIME_CHECKS\n#error leaked_skip_macro\n#endif\n');prefix=['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']if'clang'in profile else['/usr/bin/g++'];r=run(['taskset','-c','8',*prefix,'-std=c++23','-E','-P',str(cpp)]);assert r['returncode']==0,r;rows.append({'case':'no_global_SKIP_'+profile,'passed':True,'source_sha256':hashlib.sha256(data).hexdigest(),'preprocessed_sha256':hashlib.sha256(r['stdout'].encode()).hexdigest(),'bytes':len(data),'removed_blocks':len(meta['removals'])})
(p/'final_checks_results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print('final independent checks',len(rows),'PASS')
