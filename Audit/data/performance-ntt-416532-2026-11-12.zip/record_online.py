# SPDX-License-Identifier: CC0-1.0
# 保存済み公開APIと提出時スナップショットを照合する。正本・ネット・コンパイラには触れない。
from pathlib import Path
import datetime
import hashlib
import json

R = Path('/home/reinsirk/Atcoder_Env')
D = Path('/tmp/sirkit_ntt_416532')
AUDIT = 'Audit/online-ntt-416532-2026-11-12.json'
IDENTIFIER = 'ntt_convolution'
LIBRARY = 'Math/NTT.cpp'
SUBMISSION = 416532

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def norm(source):
    return '\n'.join(line.rstrip() for line in source.replace('\r\n', '\n').splitlines()
                     if line.strip() and not line.startswith('// Submission:'))

retrieval_path = D / 'retrieval.json'
retrieval = json.loads(retrieval_path.read_text())
response, saved = D / '416532.json', D / '416532.cpp'
endpoint = 'https://v3.api.judge.yosupo.jp/submissions/416532'
assert retrieval['url'] == endpoint
assert retrieval['response_sha256'] == sha(response)
data = json.loads(response.read_text())
overview = data['overview']
assert overview['id'] == SUBMISSION and overview['problem_name'] == 'convolution_mod'
assert overview['status'] == 'AC'
assert len(data['case_results']) == 53 and all(row['status'] == 'AC' for row in data['case_results'])
assert saved.read_bytes() == data['source'].encode()
snapshot = D / f'before/Verify/current/submissions/{IDENTIFIER}.cpp'
assert norm(data['source']) == norm(snapshot.read_text()), '提出本文とスナップショットが不一致'
driver, io = f'Verify/current/drivers/{IDENTIFIER}_main.cpp', 'Verify/current/common/fast_io.hpp'
checked = datetime.datetime.now(datetime.timezone.utc).isoformat()
record = dict(id=IDENTIFIER, status=overview['status'], url='https://judge.yosupo.jp/submission/416532',
              time_ms=round(overview['time'] * 1000), memory_bytes=overview['memory'], language=overview['lang'],
              submission_time=overview['submission_time'], fetched_at_utc=retrieval['fetched_at_utc'],
              checked_at_utc=checked, case_results=data['case_results'], submission_sha256=sha(snapshot),
              uploaded_source_sha256=sha(saved), source_hashes={LIBRARY: sha(D / 'before' / LIBRARY)},
              driver_sha256=sha(D / 'before' / driver), io_source_hashes={io: sha(D / 'before' / io)},
              io_mode='shared_fast_io', matched_prescreen_snapshot=True,
              source_match='空行・改行・行末空白・Submission注記のみ除いて、提出本文と提出時の本体/main/共通IOが一致。',
              evidence_file=AUDIT)
source = dict(id=IDENTIFIER, endpoint=endpoint, response_file=str(response), response_sha256=sha(response),
              fetched_at_utc=retrieval['fetched_at_utc'], saved_source_file=str(saved), saved_source_sha256=sha(saved),
              submitted_snapshot=str(snapshot), is_latest_at_saved_API_snapshot=overview.get('is_latest'))
output = dict(records=[record], endpoints=[endpoint], checked_at_utc=checked,
              normalization='CRLFをLFにし、空行・行末空白・先頭が // Submission: の注記のみ除く。他のコード/pragmaは除外しない。',
              source_snapshots=[source], retrieval=retrieval, retrieval_file_sha256=sha(retrieval_path),
              scope='416532のAC54msと提出時スナップショットの本文一致を記録。fetched_at_utcはAPI取得時刻、checked_at_utcはローカル照合時刻。現行通常版との一致・再提出要否は生成時の本体で別途判断し、後の改修や派生版へオンラインACを転記しない。')
(D / 'online_records.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ('id', 'status', 'time_ms', 'memory_bytes', 'source_hashes', 'matched_prescreen_snapshot')}, ensure_ascii=False, indent=2))
