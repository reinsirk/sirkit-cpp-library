# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,subprocess,os,random,fcntl,shutil,statistics,hashlib
D=Path('/tmp/sirkit_ntt_416532');fixtures=json.loads((D/'fixtures/fixtures.json').read_text());rng=random.Random(416532);raw=[];summary=[]
def run(cc,label,f):
 shutil.copyfile(D/f'{cc}_{label}_main',D/'active');(D/'active').chmod(0o700)
 with Path(f['path']).open('rb')as fi,(D/'output').open('wb')as fo:
  p=subprocess.Popen(['setarch','x86_64','-R','taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,status,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status);assert p.returncode==0
 blob=(D/'output').read_bytes();digest=hashlib.sha256(blob).hexdigest();expected=f.get('oracle',{}).get('expected_sha256');assert expected is None or expected==digest,(f['name'],label)
 values=list(map(int,blob.split()));assert len(values)==f['output_size']
 # 正解全体のない入力も独立な3点の評価値と端点を照合。
 checks=f['evaluation_checks'];mod=998244353;assert all(0<=v<mod for v in values)
 if values:
  assert values[0]==checks['at_zero'] and values[-1]==checks['last_coefficient']
  assert sum(values)%mod==checks['at_one'];assert (sum(values[::2])-sum(values[1::2]))%mod==checks['at_minus_one']
 return dict(cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),output_sha256=digest)
def main():
 with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  for cc in ['gcc','clang']:
   for f in fixtures:
    order=['prepare_avx2']*9+['control']*3;rng.shuffle(order);local=[]
    for rep,label in enumerate(order):
     v=[run(cc,l,f)for l in ['base',label if label!='control'else'base','base']];assert len({r['output_sha256']for r in v})==1
     b,t,a=[x['cpu_ns']for x in v];drift=max(b,a)/min(b,a);row=dict(compiler=cc,case=f['name'],label=label,rep=rep,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(row);local.append(row)
    ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in ['prepare_avx2','control']};row=dict(compiler=cc,case=f['name'],n=f['n'],m=f['m'],ntt_length=f['ntt_length'],valid_counts={l:len(v)for l,v in ratios.items()},ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},sufficient=len(ratios['prepare_avx2'])>=5 and len(ratios['control'])>=2);summary.append(row);print(row,flush=True);(D/'paired_whole_raw.json').write_text(json.dumps(raw));(D/'paired_whole_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print('Completed',len(raw),'triplets',flush=True)
if __name__=='__main__':main()
