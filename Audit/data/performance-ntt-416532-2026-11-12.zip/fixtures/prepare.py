# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import datetime,hashlib,json,random,shutil,subprocess
D=Path('/tmp/sirkit_ntt_416532/fixtures');S=D/'sources';I=D/'inputs';B=D/'generator_bins';I.mkdir(exist_ok=True);B.mkdir(exist_ok=True);meta=json.loads((D/'source_audit.json').read_text());info=meta['info'];MOD=info['params']['MOD'];MAX=info['params']['N_AND_M_MAX'];rows=[];commands=[]
params=''.join(f'#define {k} {v}LL\n'for k,v in info['params'].items());p=S/'convolution/convolution_mod/params.h';p.write_text(params);meta['generated_params']=dict(path=str(p),sha256=hashlib.sha256(params.encode()).hexdigest(),method='info.toml integer params expanded to LL-suffixed literals, matching Random::uniform calls with 0LL/1ll')
(D/'source_audit.json').write_text(json.dumps(meta,indent=2)+'\n')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def output_hash(values):
 h=hashlib.sha256();chunk=[];count=0
 for v in values:
  chunk.append(str(v));count+=1
  if len(chunk)==16384:
   h.update(((' 'if count>len(chunk)else'')+' '.join(chunk)).encode());chunk=[]
 if chunk:h.update(((' 'if count>len(chunk)else'')+' '.join(chunk)).encode())
 h.update(b'\n');return h.hexdigest()
def register(name,path,origin,gen=None,seed=None,outside=False):
 data=list(map(int,path.read_bytes().split()));n,m=data[:2];assert len(data)==n+m+2,(name,len(data),n,m);a=data[2:n+2];b=data[n+2:];assert n>=1 and m>=1;assert all(0<=x<MOD for x in a+b)
 if not outside:assert n<=MAX and m<=MAX
 ca=a[0]if all(x==a[0]for x in a)else None;cb=b[0]if all(x==b[0]for x in b)else None;oracle=None
 if ca is not None and cb is not None:
  factor=ca*cb%MOD;oracle=dict(method='independent constant-sequence overlap count',expected_sha256=output_hash(min(k+1,n,m,n+m-1-k)*factor%MOD for k in range(n+m-1)))
 elif ca==0 or cb==0:oracle=dict(method='independent zero-factor polynomial',expected_sha256=output_hash(0 for _ in range(n+m-1)))
 elif n*m<=100000:
  c=[0]*(n+m-1)
  for i,x in enumerate(a):
   for j,y in enumerate(b):c[i+j]=(c[i+j]+x*y)%MOD
  oracle=dict(method='independent quadratic convolution',expected_sha256=output_hash(c))
 rows.append(dict(name=name,path=str(path),n=n,m=m,output_size=n+m-1,ntt_length=1<<(n+m-2).bit_length(),bytes=path.stat().st_size,sha256=digest(path),origin=origin,generator=gen,seed=seed,outside_official_constraints=outside,oracle=oracle,evaluation_checks=dict(at_zero=a[0]*b[0]%MOD,last_coefficient=a[-1]*b[-1]%MOD,at_one=sum(a)*sum(b)%MOD,at_minus_one=(sum(a[::2])-sum(a[1::2]))*(sum(b[::2])-sum(b[1::2]))%MOD)))
 print(name,n,m,'oracle'if oracle else'paired/invariants',flush=True)
 (D/'fixtures.json').write_text(json.dumps(rows,indent=2)+'\n')
for test in info['tests']:
 name=test['name']
 if name.endswith('.cpp'):
  source=S/'convolution/convolution_mod/gen'/name;exe=B/source.stem;cmd=['taskset','-c','4','/usr/bin/g++','-std=c++23','-O2','-I'+str(S/'common'),str(source),'-o',str(exe)];subprocess.run(cmd,check=True);commands.append(dict(source=str(source),source_sha256=digest(source),compile_command=cmd))
  for seed in range(test['number']):
   label=f'official_{source.stem}_{seed:02d}';path=I/(label+'.in');cmd=['taskset','-c','4',str(exe),str(seed)]
   with path.open('wb')as out:subprocess.run(cmd,stdout=out,check=True)
   commands.append(dict(input=label,generate_command=cmd));register(label,path,'pinned official generator',name,seed)
 else:
  for seed in range(test['number']):
   filename=name.replace('.in',f'_{seed:02d}.in');path=I/('official_'+filename);shutil.copyfile(S/'convolution/convolution_mod/gen'/filename,path);register('official_'+filename.removesuffix('.in'),path,'pinned official example',filename,seed)
(D/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
rng=random.Random(416532)
def write_custom(n,m,shape,name=None,outside=False):
 if name is None:name=f'custom_{n}x{m}_{shape}'+('_outside'if outside else'')
 def values(k):
  if shape=='ones':return[1]*k
  if shape=='max':return[MOD-1]*k
  if shape=='alternating':return[i%2*(MOD-1)for i in range(k)]
  if shape=='impulse':return[MOD-1]+[0]*(k-1)
  return[rng.randrange(MOD)for _ in range(k)]
 a,b=values(n),values(m);p=I/(name+'.in');p.write_text(f'{n} {m}\n'+' '.join(map(str,a))+'\n'+' '.join(map(str,b))+'\n');register(name,p,'independent deterministic custom; Python random.Random(416532)',outside=outside)
for n,m,shape in [(1,1,'max'),(31,33,'random'),(32,33,'max'),(33,33,'random'),(63,65,'random'),(64,65,'random'),(65,65,'random'),(127,129,'alternating'),(128,129,'random'),(129,129,'random'),(32,MAX,'max'),(MAX,32,'max'),(33,MAX,'random'),(MAX,33,'random'),(262144,262144,'random'),(262145,262144,'random'),(262145,262145,'random'),(MAX-1,1,'impulse')]:write_custom(n,m,shape)
for shape in ['ones','random']:write_custom(1048576,1048576,shape,outside=True)
summary=dict(completed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),revision=meta['revision'],official_rows=sum(x['name'].startswith('official_')for x in rows),custom_rows=sum(x['name'].startswith('custom_')for x in rows),rows=len(rows),byte_unique_inputs=len({x['sha256']for x in rows}),total_input_bytes=sum(x['bytes']for x in rows),independent_output_oracles=sum(x['oracle']is not None for x in rows),manifest_sha256=digest(D/'fixtures.json'),scope='Fixed public generators and independent supplemental data, not a claim of byte identity to live judge inputs. External source bodies stay in temporary sources only; archive metadata/scripts may reference their URL/SHA without redistributing them.')
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2),flush=True)
