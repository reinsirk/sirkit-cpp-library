# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import datetime,hashlib,json,tomllib,urllib.request
D=Path('/tmp/sirkit_ntt_416532/fixtures');S=D/'sources';REV='73876f1cbcf082d2b22722924b924d3d65a2f00e';base=f'https://raw.githubusercontent.com/yosupo06/library-checker-problems/{REV}/';rows=[]
def fetch(relative):
 url=base+relative;blob=urllib.request.urlopen(url,timeout=45).read();p=S/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(blob);rows.append(dict(relative=relative,url=url,path=str(p),bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),fetched_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()));return blob
info=tomllib.loads(fetch('convolution/convolution_mod/info.toml').decode());fetch('common/random.h');fetch('LICENSE')
for t in info['tests']:
 name=t['name']
 if name.endswith('.cpp'):fetch('convolution/convolution_mod/gen/'+name)
 else:
  for seed in range(t['number']):fetch('convolution/convolution_mod/gen/'+name.replace('.in',f'_{seed:02d}.in'))
params=''.join(f'#define {k} {v}\n'for k,v in info['params'].items());p=S/'convolution/convolution_mod/params.h';p.write_text(params)
(D/'source_audit.json').write_text(json.dumps(dict(revision=REV,info=info,downloaded=rows,generated_params=dict(path=str(p),sha256=hashlib.sha256(params.encode()).hexdigest(),method='info.toml params expanded as macro definitions')),indent=2)+'\n');print('Fetched',len(rows),'sources; tests',sum(t['number']for t in info['tests']))
