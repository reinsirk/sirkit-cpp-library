# 根の表のAVX2生成

基準のSHA-256は`5b5c85da53f0108b521b725b5ab014eaf8ee21446729b2e45c30100d796426fa`。
`generate_prepare_avx2.py`は原本ハッシュ、置換箇所の一意性、逆置換を確認する。

## 自然順とSIMDレーン順

元のprepareは段halfで、v[j]=roots_[half/2+j]を使い、r[2j]=v[j]、r[2j+1]=working_multiply(v[j],step)を生成する。段ごとに自然順の根になる。
新しい経路は同じ8個のvと8個の積pを作り、同じ16個を連続格納する。

- unpacklo(v,p)の32bitレーンは`v0,p0,v1,p1,v4,p4,v5,p5`。
- unpackhi(v,p)は`v2,p2,v3,p3,v6,p6,v7,p7`。
- permute2x128(lo,hi,0x20)は下位128bit同士を連結し`v0,p0,v1,p1,v2,p2,v3,p3`。
- 0x31は上位128bit同士で`v4,p4,v5,p5,v6,p6,v7,p7`。

従来の添字half+2jからの16個と完全に同じ順になる。根をbit-reverse順と解釈していない。

## 範囲と初期化

- public prepareの長さ検査・早期return・previousの計算・resize・roots_[1]初期化は変更しない。previousは2または既に保持している2冪長。
- 各段が読むのは[half/2,half)で、既存保持または前段で全て初期化済み。
- j+8<=half/2なので最終読込はhalf-1以内、出力2本は最大2half-1以内。半分の段がlength未満なので2half<=lengthで、resize済みの根の表内。
- 入力と出力の区間は重ならない。8個の入力をまとめて読んでも、別のブロックが未読の根を上書きしない。
- 16個未満の前段、8個未満の端数は元と同じスカラー処理。2冪のhalf>=16ではhalf/2が8の倍数となり、SIMDループは段全体を処理する。
- length=256未満では旧経路のまま。256以上でも初期段は同じスカラー計算から始まり、根が存在しない位置を先読みしない。準備済み表を拡張する場合も同じpreviousから始まる。

## 数値・例外・所有

stepとvalueは元と同じMontgomery形式・2Mod未満。既存vector_multiplyはworking_multiplyと同じ64bit積・q・Mod加算・32bitシフトで、同じレーン値を返す。積と加算の上限もMod<2^30のまま。
新しい条件はmontgomery_とlength>=256、既存use_avx2のCPU判定が全て成立する場合だけ。その他の法・CPU・SIRKIT_DISABLE_SIMDは元の標準経路を使う。新しいISAは追加しない。
確保は元のroots_.resizeだけ。所有、コピー、move、clear_cache、roots_capacity、例外時のvectorの扱いは変更しない。追加の保持配列・状態・new式・入力検査のためだけの走査はない。
段の上限は既存max_length以下、half*2<=lengthなので段長の算術を変更しない。

## 組合せ版

pointwise_square_prepare.hppは、別途静的確認したpointwise_fused_square.hppに同じ根生成変更だけを加えたもの。前段の根の値と順序が一致するため、要素積・逆変換との接続条件を変更しない。
公開API、説明、include、mainは不変。SIMD実行・コンパイル・性能測定は行っていない。速度の採否は親の同条件測定による。
