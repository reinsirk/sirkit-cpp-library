# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,difflib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_ntt_416532/agent');base=(R/'Math/NTT.cpp').read_text();expected='5b5c85da53f0108b521b725b5ab014eaf8ee21446729b2e45c30100d796426fa';assert hashlib.sha256(base.encode()).hexdigest()==expected
old='''        const auto q_even=_mm256_mul_epu32(even,inverse),q_odd=_mm256_mul_epu32(odd,inverse);
        const auto reduced_even=_mm256_srli_epi64(_mm256_add_epi64(even,_mm256_mul_epu32(q_even,mod)),32);
        const auto reduced_odd=_mm256_slli_epi64(_mm256_srli_epi64(_mm256_add_epi64(odd,_mm256_mul_epu32(q_odd,mod)),32),32);'''
new='''        const auto product_low=_mm256_blend_epi32(even,_mm256_slli_epi64(odd,32),0xaa);
        const auto q=_mm256_mullo_epi32(product_low,inverse);
        const auto reduced_even=_mm256_srli_epi64(_mm256_add_epi64(even,_mm256_mul_epu32(q,mod)),32);
        const auto reduced_odd=_mm256_slli_epi64(_mm256_srli_epi64(_mm256_add_epi64(odd,_mm256_mul_epu32(_mm256_srli_epi64(q,32),mod)),32),32);'''
assert base.count(old)==1
candidate=base.replace(old,new);assert candidate.replace(new,old)==base
path=D/'packed_q.hpp';path.write_text(candidate)
(D/'packed_q.hpp.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),candidate.splitlines(True),fromfile='Math/NTT.cpp',tofile='packed_q.hpp')))
(D/'packed_q_metadata.json').write_text(json.dumps(dict(base_sha256=expected,candidate_sha256=hashlib.sha256(candidate.encode()).hexdigest(),modified='vector_multiply only',compiled=False,executed=False),indent=2)+'\n')
