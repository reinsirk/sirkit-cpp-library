# packed_qの静的確認

基準は`Math/NTT.cpp`、SHA-256 `5b5c85da53f0108b521b725b5ab014eaf8ee21446729b2e45c30100d796426fa`。
候補は`vector_multiply`のq計算だけを変更する。生成器は逆置換でも原本との一致を確認する。

- evenの各64bit要素は入力の偶数32bitレーン同士の64bit積、oddは奇数レーン同士の64bit積。従来と同じ。
- oddを各64bit要素内で32bit左にずらし、0xaaのblendで奇数32bitレーンだけ採ると、product_lowの各32bitレーンは対応する入力積の下位32bitになる。
- `mullo_epi32(product_low,inverse)`は各レーンの下位32bitを返す。従来の64bit乗算から次の`mul_epu32`で下位32bitだけを使う経路と、法2^32で同じqとなる。符号付きの積でも下位32bitは同じ。
- qの偶数レーンをそのまま、奇数レーンを64bit右シフトして使う。どちらも元のq_even/q_oddの有効な下位32bitと一致する。
- 64bit積、q*Mod、加算、右シフト、最後の偶奇の合成は従来と同じ。各入力が2Mod未満、Mod<2^30で、64bit加算の上限とMontgomery還元の0..2Modの不変条件を変更しない。
- SIMD乗算命令数は元の6個の`mul_epu32`から4個の`mul_epu32`と1個の`mullo_epi32`となるが、blend・シフトを増やす。P-Coreでの`vpmulld`のコストがあるため速くなるとは断定しない。
- このhelperは既存のAVX2 target、コンパイラ/CPU条件、SIRKIT_DISABLE_SIMDの条件内だけ。新しいISA、CPU判定、状態、確保、チェックの変更はない。公開API、標準経路、ライセンス、文書を変更しない。

コンパイル・実行・性能測定は行っていない。原本は変更していない。
