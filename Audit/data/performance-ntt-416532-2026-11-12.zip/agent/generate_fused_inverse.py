# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import difflib,hashlib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_ntt_416532/agent');base=(R/'Math/NTT.cpp').read_text();expected='5b5c85da53f0108b521b725b5ab014eaf8ee21446729b2e45c30100d796426fa';assert hashlib.sha256(base.encode()).hexdigest()==expected
old_start=base.index('    template<bool Check>\n    [[gnu::target("avx2")]]\n    void backward_avx2(')
end_marker='\n#endif\n\n    template <bool Check>\n    void forward'
old_end=base.index(end_marker,old_start)
old_inverse=base[old_start:old_end]
prefix_start=old_inverse.index('        const auto u4=')
prefix_end=old_inverse.index('        std::size_t completed=8;')
initial=old_inverse[prefix_start:prefix_end]
helper='''
    [[gnu::always_inline,gnu::target("avx2")]]
    static inline void store_inverse_avx2(std::vector<std::uint32_t>& result,
                                          std::size_t position, __m256i value,
                                          __m256i scale, __m256i reverse) noexcept {
        value = vector_reduce(vector_multiply(value, scale));
        if (position == 0) {
            alignas(32) std::uint32_t first[8];
            _mm256_store_si256(reinterpret_cast<__m256i*>(first), value);
            result[0] = first[0];
            for (std::size_t i = 1; i < 8; ++i) result[result.size() - i] = first[i];
        } else {
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(result.data() + result.size() - position - 7),
                               _mm256_permutevar8x32_epi32(value, reverse));
        }
    }
    template<bool Final>
    [[gnu::target("avx2")]]
    void backward_stage_avx2(std::vector<std::uint32_t>& a,
                             std::vector<std::uint32_t>& result, std::size_t length,
                             __m256i scale, __m256i reverse) const {
        const auto n = a.size(), quarter = length / 4;
        for (std::size_t block = 0; block < n; block += length)
            for (std::size_t j = 0; j < quarter; j += 8) {
                const auto x0 = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data() + block + j));
                const auto raw1 = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data() + block + j + quarter));
                const auto x2 = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data() + block + j + 2 * quarter));
                const auto raw3 = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data() + block + j + 3 * quarter));
                const auto first = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data() + quarter + j));
                const auto second = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data() + 2 * quarter + j));
                const auto third = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data() + 3 * quarter + j));
                const auto x1 = vector_multiply(raw1, first), x3 = vector_multiply(raw3, first);
                const auto v0 = vector_add(x0, x1), v1 = vector_subtract(x0, x1);
                const auto v2 = vector_multiply(vector_add(x2, x3), second);
                const auto v3 = vector_multiply(vector_subtract(x2, x3), third);
                const auto y0 = vector_add(v0, v2), y1 = vector_add(v1, v3);
                const auto y2 = vector_subtract(v0, v2), y3 = vector_subtract(v1, v3);
                if constexpr (Final) {
                    store_inverse_avx2(result, block + j, y0, scale, reverse);
                    store_inverse_avx2(result, block + j + quarter, y1, scale, reverse);
                    store_inverse_avx2(result, block + j + 2 * quarter, y2, scale, reverse);
                    store_inverse_avx2(result, block + j + 3 * quarter, y3, scale, reverse);
                } else {
                    _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data() + block + j), y0);
                    _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data() + block + j + quarter), y1);
                    _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data() + block + j + 2 * quarter), y2);
                    _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data() + block + j + 3 * quarter), y3);
                }
            }
    }
    [[gnu::target("avx2")]]
    void finish_convolution_avx2(std::vector<std::uint32_t>& a,
                                 std::vector<std::uint32_t>& result) const {
        const auto n = a.size();
        const auto inverse_n = reinsirk::detail::ntt_power(static_cast<std::uint32_t>(n), Mod - 2, Mod);
        const auto scale = _mm256_set1_epi32(static_cast<int>(inverse_n));
        const auto reverse = _mm256_setr_epi32(7,6,5,4,3,2,1,0);
'''+initial+'''        std::size_t completed = 8;
        for (std::size_t length = 32; length <= n;) {
            if (length == n) backward_stage_avx2<true>(a, result, length, scale, reverse);
            else backward_stage_avx2<false>(a, result, length, scale, reverse);
            completed = length;
            if (length > n / 4) break;
            length *= 4;
        }
        if (completed < n) {
            const auto half = n / 2;
            for (std::size_t j = 0; j < half; j += 8) {
                const auto u = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data() + j));
                const auto raw = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data() + half + j));
                const auto roots = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data() + half + j));
                const auto v = vector_multiply(raw, roots);
                store_inverse_avx2(result, j, vector_add(u, v), scale, reverse);
                store_inverse_avx2(result, half + j, vector_subtract(u, v), scale, reverse);
            }
        }
    }
'''
old_compute='''        if(use_avx2(length))pointwise_avx2(a,b);
        else
#endif
        for (std::size_t i = 0; i < length; ++i) a[i] = working_multiply(a[i], b[i]);'''
new_compute='''        if(use_avx2(length)) {
            pointwise_avx2(a,b); finish_convolution_avx2(a,b);
            b.resize(output); return b;
        }
#endif
        for (std::size_t i = 0; i < length; ++i) a[i] = working_multiply(a[i], b[i]);'''
assert base.count(old_compute)==1
candidate=base[:old_end]+helper+base[old_end:];candidate=candidate.replace(old_compute,new_compute)
assert candidate.replace(helper,'').replace(new_compute,old_compute)==base
assert old_inverse + "\n" in candidate
assert candidate[candidate.index('    template <std::integral T>\n    std::vector<std::uint32_t> square'):]==base[base.index('    template <std::integral T>\n    std::vector<std::uint32_t> square'):]
(D/'fused_inverse.hpp').write_text(candidate)
(D/'fused_inverse.hpp.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),candidate.splitlines(True),fromfile='Math/NTT.cpp',tofile='fused_inverse.hpp')))
(D/'fused_inverse_metadata.json').write_text(json.dumps(dict(base_sha256=expected,candidate_sha256=hashlib.sha256(candidate.encode()).hexdigest(),old_backward_sha256=hashlib.sha256(old_inverse.encode()).hexdigest(),old_backward_unchanged=True,old_backward_with_closing_newline_sha256=hashlib.sha256((old_inverse+'\n').encode()).hexdigest(),new_lines=len(helper.splitlines()),source_bytes=len(candidate.encode()),compiled=False,executed=False),indent=2)+'\n')
