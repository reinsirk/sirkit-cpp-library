# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,difflib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_ntt_416532/agent');base=(R/'Math/NTT.cpp').read_text();expected='5b5c85da53f0108b521b725b5ab014eaf8ee21446729b2e45c30100d796426fa';assert hashlib.sha256(base.encode()).hexdigest()==expected
anchor='''    template<bool Check>
    [[gnu::target("avx2")]]
    static std::vector<std::uint32_t> naive_avx2'''
helper='''    [[gnu::target("avx2")]]
    void prepare_avx2(std::size_t previous, std::size_t length) {
        for (std::size_t half = previous; half < length; half <<= 1) {
            const auto step = encode(reinsirk::detail::ntt_power(Root, static_cast<std::uint32_t>((Mod - 1) / (half * 2)), Mod));
            const auto scale = _mm256_set1_epi32(static_cast<int>(step));
            std::size_t j = 0;
            for (; j + 8 <= half / 2; j += 8) {
                const auto value = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data() + half / 2 + j));
                const auto product = vector_multiply(value, scale);
                const auto low = _mm256_unpacklo_epi32(value, product);
                const auto high = _mm256_unpackhi_epi32(value, product);
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(roots_.data() + half + 2 * j), _mm256_permute2x128_si256(low, high, 0x20));
                _mm256_storeu_si256(reinterpret_cast<__m256i*>(roots_.data() + half + 2 * j + 8), _mm256_permute2x128_si256(low, high, 0x31));
            }
            for (; j < half / 2; ++j) {
                const auto value = roots_[half / 2 + j];
                roots_[half + 2 * j] = value;
                roots_[half + 2 * j + 1] = working_multiply(value, step);
            }
        }
    }
'''
prepare_anchor='''        roots_.resize(length); roots_[1] = encode(1);
        for (std::size_t half = previous; half < length; half <<= 1) {'''
prepare_new='''        roots_.resize(length); roots_[1] = encode(1);
#if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__))
        if constexpr (montgomery_) if (length >= 256 && use_avx2(length)) {
            prepare_avx2(previous, length);
            return;
        }
#endif
        for (std::size_t half = previous; half < length; half <<= 1) {'''
def transform(text):
 assert text.count(anchor)==1 and text.count(prepare_anchor)==1
 result=text.replace(anchor,helper+anchor).replace(prepare_anchor,prepare_new)
 assert result.replace(helper+anchor,anchor).replace(prepare_new,prepare_anchor)==text
 return result
square=(D/'pointwise_fused_square.hpp').read_text();assert hashlib.sha256(square.encode()).hexdigest()=='27eed1285a41e3ae9693140c31baee4defe4d3886b28381a4373cc0fe63b22b5'
rows=[]
for name,body in [('prepare_avx2',transform(base)),('pointwise_square_prepare',transform(square))]:
 (D/(name+'.hpp')).write_text(body)
 (D/(name+'.hpp.diff')).write_text(''.join(difflib.unified_diff(base.splitlines(True),body.splitlines(True),fromfile='Math/NTT.cpp',tofile=name+'.hpp')))
 rows.append(dict(name=name,base_sha256=expected,candidate_sha256=hashlib.sha256(body.encode()).hexdigest(),compiled=False,executed=False))
(D/'prepare_metadata.json').write_text(json.dumps(rows,indent=2)+'\n')
