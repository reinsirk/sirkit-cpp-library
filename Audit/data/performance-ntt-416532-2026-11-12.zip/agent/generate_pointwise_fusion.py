# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import difflib,hashlib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_ntt_416532/agent');base=(R/'Math/NTT.cpp').read_text();expected='5b5c85da53f0108b521b725b5ab014eaf8ee21446729b2e45c30100d796426fa';assert hashlib.sha256(base.encode()).hexdigest()==expected
old_sig='''    template<bool Check>
    [[gnu::target("avx2")]]
    void backward_avx2(std::vector<std::uint32_t>& a) const {'''
new_sig='''    template<bool Check, bool Pointwise = false>
    [[gnu::target("avx2")]]
    void backward_avx2(std::vector<std::uint32_t>& a,
                       const std::vector<std::uint32_t>* other = nullptr) const {'''
assert base.count(old_sig)==1
start=base.index(old_sig);end=base.index('\n#endif\n\n    template <bool Check>\n    void forward',start)
old_part=base[start:end];new_part=old_part.replace(old_sig,new_sig)
old_load='''            auto x=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+block));'''
new_load='''            auto x=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+block));
            if constexpr (Pointwise) {
                const auto y=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(other->data()+block));
                x=vector_multiply(x,y);
            }'''
assert new_part.count(old_load)==1
new_part=new_part.replace(old_load,new_load)
old_compute='''        if(use_avx2(length))pointwise_avx2(a,b);
        else
#endif
        for (std::size_t i = 0; i < length; ++i) a[i] = working_multiply(a[i], b[i]);'''
new_compute='''        if(use_avx2(length)) {
            backward_avx2<false,true>(a,&b); a.resize(output);
            return a;
        }
#endif
        for (std::size_t i = 0; i < length; ++i) a[i] = working_multiply(a[i], b[i]);'''
assert base.count(old_compute)==1
candidate=base[:start]+new_part+base[end:];candidate=candidate.replace(old_compute,new_compute)
assert candidate.replace(new_compute,old_compute).replace(new_part,old_part)==base
old_square='''        if(use_avx2(length))pointwise_avx2(x,x);
        else
#endif
        for (auto& value : x) value = working_multiply(value, value);'''
new_square='''        if(use_avx2(length)) {
            backward_avx2<false,true>(x,&x); x.resize(output);
            return x;
        }
#endif
        for (auto& value : x) value = working_multiply(value, value);'''
assert candidate.count(old_square)==1
square=candidate.replace(old_square,new_square);assert square.replace(new_square,old_square)==candidate
rows=[]
for name,body in [('pointwise_fused',candidate),('pointwise_fused_square',square)]:
 path=D/(name+'.hpp');path.write_text(body)
 (D/(name+'.hpp.diff')).write_text(''.join(difflib.unified_diff(base.splitlines(True),body.splitlines(True),fromfile='Math/NTT.cpp',tofile=name+'.hpp')))
 rows.append(dict(name=name,base_sha256=expected,candidate_sha256=hashlib.sha256(body.encode()).hexdigest(),compiled=False,executed=False))
(D/'pointwise_fusion_metadata.json').write_text(json.dumps(rows,indent=2)+'\n')
