# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import difflib,hashlib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_ntt_416532/agent');base=(R/'Math/NTT.cpp').read_text();expected='5b5c85da53f0108b521b725b5ab014eaf8ee21446729b2e45c30100d796426fa';assert hashlib.sha256(base.encode()).hexdigest()==expected
inverse=(D/'fused_inverse.hpp').read_text();prepare=(D/'prepare_avx2.hpp').read_text()
assert hashlib.sha256(inverse.encode()).hexdigest()=='a22cd7edde0a36ae731b2608cb3a2e66e108375fc1e58d1ce4a666405ef6c776'
assert hashlib.sha256(prepare.encode()).hexdigest()=='0d1a53fc3442736fcb7bad6fc55e3a2ce24e419acf01e5f2d37dd37825af2482'
# 各生成器の変更区間だけを抽出し、原本からの完全な逆置換も別々に検査する。
pa='''    template<bool Check>
    [[gnu::target("avx2")]]
    static std::vector<std::uint32_t> naive_avx2'''
new_start=prepare.index('    [[gnu::target("avx2")]]\n    void prepare_avx2(')
new_end=prepare.index(pa,new_start)
helper=prepare[new_start:new_end]
old_prepare='''        roots_.resize(length); roots_[1] = encode(1);
        for (std::size_t half = previous; half < length; half <<= 1) {'''
new_prepare='''        roots_.resize(length); roots_[1] = encode(1);
#if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__))
        if constexpr (montgomery_) if (length >= 256 && use_avx2(length)) {
            prepare_avx2(previous, length);
            return;
        }
#endif
        for (std::size_t half = previous; half < length; half <<= 1) {'''
assert prepare.replace(helper,'').replace(new_prepare,old_prepare)==base
assert inverse.count(pa)==1 and inverse.count(old_prepare)==1
candidate=inverse.replace(pa,helper+pa).replace(old_prepare,new_prepare)
assert candidate.replace(helper,'').replace(new_prepare,old_prepare)==inverse
inverse_start=inverse.index('\n    [[gnu::always_inline,gnu::target("avx2")]]\n    static inline void store_inverse_avx2(')
inverse_end=inverse.index('\n#endif\n\n    template <bool Check>\n    void forward',inverse_start)
inverse_helper=inverse[inverse_start:inverse_end]
old_compute='''        if(use_avx2(length))pointwise_avx2(a,b);
        else
#endif
        for (std::size_t i = 0; i < length; ++i) a[i] = working_multiply(a[i], b[i]);'''
new_compute='''        if(use_avx2(length)) {
            pointwise_avx2(a,b); finish_convolution_avx2(a,b);
            b.resize(output); return b;
        }
#endif
        for (std::size_t i = 0; i < length; ++i) a[i] = working_multiply(a[i], b[i]);'''
assert inverse.replace(inverse_helper,'').replace(new_compute,old_compute)==base
assert candidate.replace(inverse_helper,'').replace(new_compute,old_compute)==prepare
assert candidate.replace(helper,'').replace(new_prepare,old_prepare).replace(inverse_helper,'').replace(new_compute,old_compute)==base
(D/'fused_inverse_prepare.hpp').write_text(candidate)
(D/'fused_inverse_prepare.hpp.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),candidate.splitlines(True),fromfile='Math/NTT.cpp',tofile='fused_inverse_prepare.hpp')))
(D/'fused_inverse_prepare_metadata.json').write_text(json.dumps(dict(base_sha256=expected,inverse_sha256=hashlib.sha256(inverse.encode()).hexdigest(),prepare_sha256=hashlib.sha256(prepare.encode()).hexdigest(),candidate_sha256=hashlib.sha256(candidate.encode()).hexdigest(),reverse_both_verified=True,reverse_inverse_equals_prepare=True,reverse_prepare_equals_inverse=True,source_bytes=len(candidate.encode()),compiled=False,executed=False),indent=2)+'\n')
