# NTT提出416532の記録用補助

`record_online.py` は保存済み公開API応答・取得時刻・応答SHAを確認し、53ケースすべてAC、54ms、19,869,696Bを記録する。空行・CRLF・行末空白・Submission注記だけを除いて、保存済み提出本文と変更前スナップショットが一致した。他のpragmaやコードは除外しない。

提出時のMath/NTT.cppは`5b5c85da53f0108b521b725b5ab014eaf8ee21446729b2e45c30100d796426fa`。mainと共通IOも別々のSHAで記録する。`online_records.json`はこの提出時の事実に限定し、将来の採用案へACを付け替えない。

`apply_online_metadata.py` は既定dry-run。実際の現行本体から、提出URLを最新1本へそろえて再生成した提出コードのSHAを比べる。変更前本体では一致・再提出不要、pointwise_fused.hppの仮定では不一致・再提出待ちになった。`--library-override` はdry-run専用。正本を書き換えるのは親が本体を決定した後の`--apply`だけである。既存Auditが異なる内容なら上書きを拒否する。

`update_distribution_manifest.py` も既定dry-runで、最終Auditと正本SHA、再提出指定、通常版の判定記録と生成済みmanifest、4派生版の未提出状態、5ZIPの最新検査・SHA・容量・エントリ数を確認してから外側manifestを更新する。採用時は新NTT監査をaccepted_performance_auditへ設定し、維持時は不変の旧manifestのaccepted_performance_auditをそのまま保持する。後者は全体リリースで以前採用した監査への参照であり、NTTの今回の採用を意味しない。

親が事前に保存する旧manifestは`Audit/distribution-manifest-before-ntt-416532-2026-11-12.json`。最終監査は`Audit/performance-ntt-416532-2026-11-12.json`で、`decision`はadopt/retain/reject/keep/no_adoptのいずれかで始まる値、`source_sha256.before/after`、`required_resubmission`を持つ。NTT採用なら再提出対象は`Verify/current/submissions/ntt_convolution.cpp`だけ。

一時ファイルへの生成・record/dry-run・構文確認のみ実行し、正本・コンパイラ・性能測定へは触れていない。実行時点で本体/main/IO/groups/judgements/外側manifestが変更前スナップショットと同一であることも確認した。
