# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,random,statistics,fcntl
import screen
D=Path('/tmp/sirkit_ntt_416532');rng=random.Random(532);raw=[];summary=[]
def run(cc,setting,label,op,n,m):return screen.run(cc,setting,label,op,n,m)
def main():
 with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  cases=[(op,n,n)for op in range(7)for n in [16,1024,65536,524288]]+[(0,33,33),(0,32,524288),(0,33,524288),(0,524288,33),(0,262145,262144),(1,33,33)]
  for cc in ['gcc','clang']:
   for st in ['checked','skip']:
    for op,n,m in cases:
     order=['prepare_avx2']*9+['control']*3;rng.shuffle(order);local=[]
     for rep,label in enumerate(order):
      v=[run(cc,st,l,op,n,m)for l in ['base',label if label!='control'else'base','base']];assert len({x['digest']for x in v})==1
      b,t,a=[x['cpu_ns']for x in v];drift=max(b,a)/min(b,a);row=dict(compiler=cc,setting=st,op=op,n=n,m=m,label=label,rep=rep,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(row);local.append(row)
     ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in ['prepare_avx2','control']};row=dict(compiler=cc,setting=st,op=op,n=n,m=m,valid_counts={l:len(v)for l,v in ratios.items()},ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},sufficient=len(ratios['prepare_avx2'])>=5 and len(ratios['control'])>=2);summary.append(row);print(row,flush=True);(D/'paired_core_raw.json').write_text(json.dumps(raw));(D/'paired_core_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print('Completed',len(raw),'triplets',flush=True)
if __name__=='__main__':main()
