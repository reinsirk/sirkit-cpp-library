# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,statistics,math,zipfile,shutil
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_ntt_416532')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def encode(x):return json.dumps(x,ensure_ascii=False,indent=2)+'\n'
base=sha(D/'base.hpp');after=sha(R/'Math/NTT.cpp');assert after==sha(D/'final.hpp') and base!=after
assert (D/'final.hpp').read_text().replace('                // 偶数べきと奇数べきを交互に並べる。\n','')==(D/'prepare_avx2.hpp').read_text()
validation=load(D/'final_validation.json');assert validation['all_passed'] and validation['passed_jobs']==44
profile=load(D/'profiles/checkpoint.json');assert profile['counts']=={'LOCAL_SAMPLE_PASS':10}
for stem in ['paired_whole','paired_core']:assert all(r['sufficient']for r in load(D/(stem+'_summary.json')))
frozen=['Verify/current/drivers/ntt_convolution_main.cpp','Verify/current/common/fast_io.hpp','Document/ntt.md','Examples/ntt_example.cpp']
for f in frozen:assert (R/f).read_bytes()==(D/'before'/f).read_bytes(),f
assert (R/'Verify/current/submissions/ntt_convolution.cpp').read_bytes()==(D/'final_main.cpp').read_bytes()
old_manifest=R/'Audit/distribution-manifest-before-ntt-416532-2026-11-12.json';old=(D/'before/Distribution/manifest.json').read_bytes()
if old_manifest.exists():assert old_manifest.read_bytes()==old
else:old_manifest.write_bytes(old)
fixtures=load(D/'fixtures/fixtures.json');whole=load(D/'paired_whole_summary.json');core=load(D/'paired_core_summary.json')
def stats(rows,fields):
 out=[]
 for key in sorted({tuple(r[k]for k in fields)for r in rows}):
  a=[r for r in rows if tuple(r[k]for k in fields)==key and r['sufficient']]
  if not a:continue
  out.append(dict(zip(fields,key))|dict(cases=len(a),candidate_ratio=math.exp(statistics.mean(math.log(r['ratios']['prepare_avx2'])for r in a)),identical_control_ratio=math.exp(statistics.mean(math.log(r['ratios']['control'])for r in a)),minimum_candidate_ratio=min(r['ratios']['prepare_avx2']for r in a),maximum_candidate_ratio=max(r['ratios']['prepare_avx2']for r in a)))
 return out
# 証跡には実際に使った独立参照も含める。
for f in ['ntt_reference_test.cpp','ntt_montgomery_reference_test.cpp','formal_power_series_reference_test.cpp','string_math_allocation_test.cpp']:
 p=D/'evidence_tests'/f;p.parent.mkdir(exist_ok=True);shutil.copyfile(R/'Verify/current/tests'/f,p)
j=next(x for x in load(R/'Verify/current/judgements.json')['entries']if x['id']=='ntt_convolution');assert j['status']=='AC'and j['time_ms']==54 and j['needs_resubmission']and not j['matched_current_generation']
dependent=['Math/Formal_Power_Series.cpp','Math/Linear_Recurrence.cpp','Math/Convolution.cpp','Math/Polynomial.cpp']
result=dict(date='2026-11-12',library='Math/NTT.cpp',decision='adopt_AVX2_root_table_generation',required_resubmission=['Verify/current/submissions/ntt_convolution.cpp'],online_evidence='Audit/online-ntt-416532-2026-11-12.json',online_scope='416532は変更前通常版の全53ケースAC・54ms・19,869,696B。提出本文と本体/main/共通IOが一致。今回の根生成SIMD版は未提出であり、そのACを現行版や派生版へ転記しない。',source_sha256=dict(before=base,after=after),measured_candidate_sha256=sha(D/'prepare_avx2.hpp'),comment_bridge='最終版の偶数/奇数べきの説明1行を除くと測定候補へ完全一致。GCC/Clangのmainと検査2設定coreの.textも一致。',frozen_main_IO_document_example={f:sha(R/f)for f in frozen},dependent_generated_sources=[dict(path=f,before_sha256=sha(D/'before'/f),after_sha256=sha(R/f))for f in dependent],
 changes=['既存の根と次の奇数べきの根を8要素ずつMontgomery演算で作り、unpackと128bitレーン交換で自然な順序の16要素として格納する。読み元と書き先は別の根の段で重ならない。','Mod<2^30、長さ256以上、GCC/Clangの対応x86 CPUに限る。既存のAVX2判定を再利用し、SIRKIT_DISABLE_SIMDで追加コードとCPU判定を除外する。','根のstd::vector・確保/初期化・コピー/移動/clear・容量・上限保護・公開API・入力検査を維持。新しい動的確保やnew式は導入しない。','APIは十分揃っているため、この改修では新たな別名や公開操作を追加しない。main/共通IO/使用例/Documentは不変。'],
 rejected_candidates=[dict(name=k,sha256=sha(D/(k+'.hpp')),decision=reason)for k,reason in [('packed_q','乗算内部の命令数削減は10〜22%程度遅くなる代表条件があり不採用。'),('pointwise_fused','要素積と逆変換初段の統合に安定した利益なし。'),('pointwise_fused_square','二乗までの統合でも安定した利益なし。'),('pointwise_square_prepare','根生成単独より複雑で、キャッシュ済み畳み込みに後退する条件がある。'),('fused_inverse','逆変換最終段から別入力領域へ縮小・反転して直接格納する案。公開APIは保つが約90行増に見合う利益なし。'),('fused_inverse_prepare','最終逆変換統合と根生成の組合せも、根生成単独に対する安定した上積みなし。')]],
 measurement=dict(topology=load(D/'topology.json'),cpu='i9-14900KのCPU12、SMT sibling13、sysfs core_id24、最大6GHzのP-Core。E-Coreの性能は考慮しない。',compilers=dict(GCC='15.2.0',Clang='21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'),flags=['-std=c++23','-O2'],march_native=False,extra_pragmas=False,lock='/tmp/sirkit_performance_cpu12.lock',ASLR='子だけsetarch x86_64 -R。毎回同じactiveパスへ実行体を置く。',compilation_during_timing=False,
  paired_protocol='旧版→候補→旧版を1組にして、候補時間を両端の旧版中央値で割る。各条件9組の候補と3組の同一実行体対照を決定的shuffle。両端の旧版が10%以内の組だけ有効（候補の時間では除外しない）。候補5組・対照2組に不足する種だけ最大3回、各3組補充。初期と補充rawを保存。探索screenは実行スクリプトに別の反復数を保持。',
  input_scope='固定リビジョン73876f1cbcf082d2b22722924b924d3d65a2f00eの公開生成器による公式53入力と補足20入力、計73件。オンライン入力との同一性は主張しない。補足には制約外1048576×1048576も含む。',fixture_manifest_sha256=sha(D/'fixtures/fixtures.json'),independent_oracles='38入力は独立な直接積または定数列の重なり数等から作った全出力SHA。ほかも端点と0/1/−1での多項式評価を検査。全73入力をGCC/Clang×前後で一度ずつ照合し、その後の同一出力はSHAで確認。',
  whole_timer='同じVerify main/共通IO/入力/コンパイラ/SKIP設定で子のuser+system CPU時間。L>=65536またはmax(n,m)>=200000の34入力×2コンパイラ。出力の解析・独立評価はタイマの外。',whole_statistics=stats(whole,['compiler']),official_whole_statistics=stats([r for r in whole if r['case'].startswith('official_')],['compiler']),whole_rows=len(whole),whole_triplets=len(load(D/'paired_whole_raw.json')),all_68_whole_cells_sufficient=True,
  core_timer='std::clock()のプロセスCPU時間。入力準備は外、API計算・全結果checksum・返却結果破棄は内。coldだけ毎回NTTを生成・解放、ほかは根を事前準備。prepareだけは根を計測外のtransformで使用して観測可能性を保つ。',core_operations={0:'normalized move cold',1:'normalized move cached',2:'generic int64 cached',3:'square cached',4:'forward transform',5:'inverse transform',6:'prepare cold'},core_settings=['checked','SKIP_RUNTIME_CHECKS'],core_sizes=[16,1024,65536,524288],core_supplement='33境界、32/33×524288、逆順の偏り、2冪を超える出力長。小規模の反復はmax(1,32768/max(n,m))。',large_core_statistics=stats([r for r in core if r['n']==r['m']and r['n']>=200000],['compiler','setting','op']),core_rows=len(core),core_triplets=len(load(D/'paired_core_raw.json')),all_136_core_cells_sufficient=True,
  observed_limitations='主目的の全体短縮はGCC約0.50%、Clang約0.54%に留まる。根生成単独の大規模は約15〜17%、65536要素を含めると約15〜19%短縮。中規模Clang順変換65536は初回+6.4%（同一実行体対照−5.5%）、15組ずつ再確認すると+2.35%（対照−1.06%）。小規模Clang二乗1024は初回+3.8%、再確認+0.82%。これらを一律に非後退とは説明しない。小中規模の小幅な後退を許容するユーザー方針と、大規模根生成の明確な改善に基づいて採用。',targeted_rechecks=load(D/'recheck_summary.json'),
  measurement_corrections=[load(D/'repetition_fix.json'),'初回whole試行はoracleがnullである入力の読取りで停止。optional oracleを正しく扱い、出力の再パースを検査済みSHAごとに一度へ変更して全条件を最初から再実行。初期記録は不採用として保存。'],all_comparison_outputs_equal=True),
 validation=dict(normal_and_standard_cpu_false_and_sanitizer_jobs=44,all_passed=True,compiler_checks='GCC/Clang×検査有効/無効×default/SIMD無効/CPU判定をfalseへ固定した検査用ヘッダー。',reference_tests=['独立DFT・直接積、11法、正負整数極値、bool、空、32/33境界、長さの偏り、正規化違反','大規模の全1畳み込み、順逆往復、キャッシュ成長/コピー/移動/解放','FPSを含む独立参照、同梱NTTとの二重include','確保失敗/例外時解放/入力不変性'],allocation_counters=[r['counters']for r in validation['jobs']if r['test']=='string_math_allocation_test'],sanitizer_scope='NTT独立参照をGCC/Clang×検査2設定×default/SIMD無効でASAN+UBSAN。host ptraceによりdetect_leaks=0、解放は独立確保カウンタのlive_delta=0で確認。',standard_fallback='GCC/Clang×検査2設定のSIRKIT_DISABLE_SIMD core .textが変更前と完全一致。',machine_code_evidence=load(D/'text_correspondence.json'),variant_program_and_examples=dict(status=profile['status'],counts=profile['counts'],run_id=profile['run_id']),generated_API_docs_and_manifests_checked=True,current_submission_bytes=(R/'Verify/current/submissions/ntt_convolution.cpp').stat().st_size,current_submission_exactly_matches_compiled_final=True),
 license='現行CC0の独自NTTに、独自に記述したSIMD根生成だけを追加。外部の公式入力生成器の実装は証跡ZIPやライブラリ本体へ含めない。原典URL/固定SHAのメタデータのみ保持。',evidence_archive='Audit/data/performance-ntt-416532-2026-11-12.zip',evidence_scope='候補、生成器、静的確認、公開API応答、比較raw、検査結果、測定器修正の前後、実行コマンド。巨大入力/出力・実行体・外部生成器本体を除外。')
(D/'audit_draft.json').write_text(encode(result));archive=R/result['evidence_archive'];archive.parent.mkdir(exist_ok=True)
paths=[]
for p in D.rglob('*'):
 if not p.is_file()or p.name=='audit_draft.json'or p.suffix not in {'.py','.hpp','.cpp','.json','.diff','.md','.log'}:continue
 rel=p.relative_to(D)
 if len(rel.parts)>1 and rel.parts[0]=='fixtures'and rel.parts[1]in {'sources','generator_bins','inputs'}:continue
 if rel.parts[0]=='profiles'and p.suffix!='.json':continue
 if rel.parts[0]=='profiles'and len(rel.parts)>1 and rel.parts[1]in {'snapshots','artifacts','sources'}:continue
 paths.append(p)
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(paths):z.write(p,p.relative_to(D).as_posix())
result['evidence_archive_sha256']=sha(archive);(R/'Audit/performance-ntt-416532-2026-11-12.json').write_text(encode(result));print('Audit saved:',archive.stat().st_size,'bytes;',len(paths),'evidencefiles')
