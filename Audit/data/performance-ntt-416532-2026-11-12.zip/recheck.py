# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,fcntl,random,statistics
import screen
D=Path('/tmp/sirkit_ntt_416532');rng=random.Random(5322026);raw=[];summary=[]
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc,setting,op,n in [('clang','skip',4,65536),('clang','checked',3,1024)]:
  order=['prepare_avx2']*15+['control']*15;rng.shuffle(order);local=[]
  for rep,l in enumerate(order):
   v=[screen.run(cc,setting,label,op,n,n)for label in ['base',l if l!='control'else'base','base']];assert len({r['digest']for r in v})==1
   b,t,a=[r['cpu_ns']for r in v];drift=max(b,a)/min(b,a);r=dict(compiler=cc,setting=setting,op=op,n=n,m=n,label=l,rep=rep,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(r);local.append(r)
  ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in ['prepare_avx2','control']};r=dict(compiler=cc,setting=setting,op=op,n=n,valid_counts={l:len(v)for l,v in ratios.items()},ratios={l:statistics.median(v)for l,v in ratios.items()});summary.append(r);print(r,flush=True)
(D/'recheck_raw.json').write_text(json.dumps(raw));(D/'recheck_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
