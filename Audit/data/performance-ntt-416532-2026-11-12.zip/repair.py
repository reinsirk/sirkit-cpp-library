# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,statistics,fcntl
import paired_whole as whole
import paired_core as core
D=Path('/tmp/sirkit_ntt_416532')
for stem,module in [('paired_whole',whole),('paired_core',core)]:
 rp=D/(stem+'_raw.json');sp=D/(stem+'_summary.json');raw=json.loads(rp.read_text());summary=json.loads(sp.read_text());(D/(stem+'_initial_raw.json')).write_bytes(rp.read_bytes());(D/(stem+'_initial_summary.json')).write_bytes(sp.read_bytes())
 with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  for row in summary:
   if row['sufficient']:continue
   fields=['compiler','case']if stem=='paired_whole'else['compiler','setting','op','n','m']
   def belongs(r):return all(r[k]==row[k]for k in fields)
   if stem=='paired_whole':
    f=next(f for f in whole.fixtures if f['name']==row['case'])
    def run(label):return module.run(row['compiler'],label,f)
    key='output_sha256'
   else:
    def run(label):return module.run(row['compiler'],row['setting'],label,row['op'],row['n'],row['m'])
    key='digest'
   local=[r for r in raw if belongs(r)]
   for attempt in range(3):
    missing=[l for l,minimum in [('prepare_avx2',5),('control',2)]if sum(r['label']==l and r['calibration_valid']for r in local)<minimum]
    if not missing:break
    for label in missing:
     for extra in range(3):
      v=[run(l)for l in ['base',label if label!='control'else'base','base']];assert len({r[key]for r in v})==1
      b,t,a=[r['cpu_ns']for r in v];drift=max(b,a)/min(b,a);r={k:row[k]for k in fields};r.update(label=label,rep=len(local),repair=True,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(r);local.append(r)
   ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in ['prepare_avx2','control']};row.update(valid_counts={l:len(v)for l,v in ratios.items()},ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},sufficient=len(ratios['prepare_avx2'])>=5 and len(ratios['control'])>=2,calibration_repaired=True);print(stem,row,flush=True)
  rp.write_text(json.dumps(raw));sp.write_text(json.dumps(summary,indent=2)+'\n')
 print(stem,'sufficient',sum(r['sufficient']for r in summary),'of',len(summary),flush=True)
