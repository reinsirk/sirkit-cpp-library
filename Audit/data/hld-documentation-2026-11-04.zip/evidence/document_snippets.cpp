#include "/home/reinsirk/Atcoder_Env/Graph/Heavy_Light_Decomposition.cpp"
#include "/home/reinsirk/Atcoder_Env/DataStructure/Fenwick_Tree.cpp"
#include "/home/reinsirk/Atcoder_Env/DataStructure/Segment_Tree.cpp"
#include <cassert>
#include <string>
#include <cstdint>
std::string concat(std::string a,const std::string& b){a+=b;return a;}
std::string empty_word(){return {};}
int main(){
Graph tree{{1}, {0,2}, {1}}; // 0―1―2、根は既定で0。
std::vector<std::int64_t> value{10,20,30};
auto hld = HeavyLightDecomposition(tree)
    .with_values<fenwick_tree<std::int64_t>>(value);
hld.add(1, 5);                       // 頂点1を20→25にする。
auto sum = hld.path_prod(0, 2);       // 0→1→2の和、65。
auto subtree = hld.subtree_prod(1);  // 頂点1とその子孫の和、55。
auto x = hld.get(1);                 // 25。value[1]自体は20のまま。

using Words = segtree<std::string, concat, empty_word>;
std::vector<std::string> token{"a","b","c"};
auto words = HeavyLightDecomposition(tree).with_values<Words,true>(token);
auto forward = words.path_prod(0,2); // "abc"。
auto backward = words.path_prod(2,0); // "cba"。

assert(sum==65&&subtree==55&&x==25&&value[1]==20&&forward=="abc"&&backward=="cba");
}
