# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,hashlib,json,re
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_documentation_20261104');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def strip(b):return b'\n'.join(x for x in b.splitlines()if not x.lstrip().startswith(b'//'))
source=R/'Graph/Heavy_Light_Decomposition.cpp';before=D/'before/Graph/Heavy_Light_Decomposition.cpp';assert strip(source.read_bytes())==strip(before.read_bytes())
(D/'implementation_equivalence.json').write_text(json.dumps(dict(before_sha256=sha(before),after_sha256=sha(source),noncomment_sha256=hashlib.sha256(strip(source.read_bytes())).hexdigest(),result='All implementation lines unchanged; only full-line API comments differ'),indent=2)+'\n')
text=(R/'Document/heavy_light_decomposition.md').read_text();blocks=re.findall(r'```cpp\n(.*?)```',text,re.S);assert len(blocks)==2
p=D/'document_snippets.cpp';p.write_text('#include "'+str(source)+'"\n#include "'+str(R/'DataStructure/Fenwick_Tree.cpp')+'"\n#include "'+str(R/'DataStructure/Segment_Tree.cpp')+'"\n#include <cassert>\n#include <string>\n#include <cstdint>\nstd::string concat(std::string a,const std::string& b){a+=b;return a;}\nstd::string empty_word(){return {};}\nint main(){\n'+'\n'.join(blocks)+'\nassert(sum==65&&subtree==55&&x==25&&value[1]==20&&forward=="abc"&&backward=="cba");\n}\n')
rows=[]
for cc,args in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  exe=D/f'doc_{cc}_{int(skip)}';cmd=['taskset','-c','6',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror']+(['-DSKIP_RUNTIME_CHECKS']if skip else[])+[str(p),'-o',str(exe)];c=subprocess.run(cmd,text=True,capture_output=True);assert c.returncode==0,c.stderr;r=subprocess.run(['taskset','-c','6',str(exe)],text=True,capture_output=True);assert r.returncode==0 and not r.stderr,r.stderr;rows.append(dict(compiler=cc,skip_runtime_checks=skip,compile_command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,source_sha256=sha(p),library_sha256=sha(source)));(D/'document_snippets_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,skip,'document snippets PASS',flush=True)
