// SPDX-License-Identifier: CC0-1.0
#ifndef SIRKIT_DISJOINT_TEST_SOURCE
#define SIRKIT_DISJOINT_TEST_SOURCE "/home/reinsirk/Atcoder_Env/DataStructure/Disjoint_Sparse_Table.cpp"
#endif
#include SIRKIT_DISJOINT_TEST_SOURCE
#include <array>
#include <cstdint>
#include <cinttypes>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <functional>
#include <limits>
#include <numeric>
#include <random>
#include <string>
struct Gcd32 { std::uint32_t operator()(std::uint32_t a,std::uint32_t b) const{return std::gcd(a,b);} };
struct First32 { std::uint32_t operator()(std::uint32_t a,std::uint32_t b) const{return a?a:b;} };
struct Minimum { std::int32_t operator()(std::int32_t a,std::int32_t b) const{return a<b?a:b;} };
using Affine=std::array<std::uint64_t,2>;
struct Composition { Affine operator()(const Affine&a,const Affine&b)const {return {a[0]*b[0]%998244353,(a[1]*b[0]+b[1])%998244353};} };
std::uint64_t digest(const Affine&x){return x[0]+x[1];}
template<class T>std::uint64_t digest(T x){return std::uint64_t(x);}
template<class T,class Op>int run(std::size_t n,const std::string&mode,int repeats,const T&identity){
 std::mt19937_64 rng(832010+n);std::vector<T>a(n);
 for(std::size_t i=0;i<n;++i){if constexpr(std::is_same_v<T,Affine>)a[i]=Affine{rng()%1000,rng()%1000};else a[i]=T(rng()%100);}
 std::vector<std::pair<std::size_t,std::size_t>>qs;
 if(mode!="build"&&mode!="copy"&&mode!="values") {qs.reserve(1000000);for(int i=0;i<1000000;++i){auto l=rng()%n,r=l+1+rng()%(n-l);qs.emplace_back(l,r);}}
 std::uint64_t checksum=0;std::int64_t ns=0;
 if(mode=="build") {
  auto start=std::clock();for(int i=0;i<repeats;++i){DisjointSparseTable<T,Op>t(a,identity);checksum+=digest(t.all_prod());}ns=std::int64_t(std::clock()-start)*1000000000/CLOCKS_PER_SEC;
 }else{
  DisjointSparseTable<T,Op>t(a,identity);auto start=std::clock();
  if(mode=="query")for(auto[l,r]:qs)checksum+=digest(t.prod(l,r));
  else if(mode=="get")for(auto[l,r]:qs){(void)r;checksum+=digest(T(t.get(l)));}
  else if(mode=="copy")for(int i=0;i<repeats;++i){auto u=t;checksum+=digest(u.all_prod());}
  else if(mode=="values")for(int i=0;i<repeats;++i){auto b=t.values();checksum+=digest(T(b[n/2]));}
  else if constexpr(std::is_same_v<T,std::int64_t>){
   for(std::size_t i=0;i<100000;++i){const auto[l,r]=qs[i];auto pred=[limit=std::int64_t(rng()%10000)](std::int64_t x){return x<=limit;};checksum+=t.max_right(l,pred);checksum+=t.min_left(r,pred);}
  }
  ns=std::int64_t(std::clock()-start)*1000000000/CLOCKS_PER_SEC;
 }
 std::printf("%" PRIu64 " %" PRId64 "\n",checksum,ns);return 0;
}
int main(int argc,char**argv){if(argc!=5)return 1;auto n=std::strtoull(argv[1],nullptr,10);std::string mode=argv[2],type=argv[4];int reps=std::atoi(argv[3]);if(type=="min")return run<std::int32_t,Minimum>(n,mode,reps,std::numeric_limits<std::int32_t>::max());if(type=="sum32")return run<std::int32_t,std::plus<std::int32_t>>(n,mode,reps,0);if(type=="gcd32")return run<std::uint32_t,Gcd32>(n,mode,reps,0);if(type=="first32")return run<std::uint32_t,First32>(n,mode,reps,0);if(type=="sum")return run<std::int64_t,std::plus<std::int64_t>>(n,mode,reps,0);if(type=="affine")return run<Affine,Composition>(n,mode,reps,Affine{1,0});return run<bool,std::logical_and<bool>>(n,mode,reps,true);}
