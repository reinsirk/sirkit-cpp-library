# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,subprocess,json,statistics,random,shutil,fcntl,os,time,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_disjoint_final_followup_20261103');P=Path('/tmp/sirkit_sparse_speed_20261103');sys.path.insert(0,str(R/'Scripts'));import prepare_verify
s=(D/'before.hpp').read_text().replace('#include <cstddef>','#include <cstddef>\n#include <memory>')
old='''    // 第0行は、原列と半幅1の行を兼ねる。
    std::vector<std::vector<T>> table_;
    std::size_t length_ = 0;
    static constexpr bool fill_identity_rows_ =
        std::is_integral_v<T> && !std::is_same_v<T, bool> && sizeof(T) >= 4;'''
new='''    template<class U> struct DefaultInitAllocator : std::allocator<U> {
        using value_type = U;
        DefaultInitAllocator() = default;
        template<class V> DefaultInitAllocator(const DefaultInitAllocator<V>&) noexcept {}
        template<class V> struct rebind { using other = DefaultInitAllocator<V>; };
        DefaultInitAllocator select_on_container_copy_construction() const noexcept { return {}; }
        template<class V, class... Args> void construct(V* p, Args&&... args) {
            if constexpr (sizeof...(Args) == 0) std::uninitialized_default_construct_n(p, 1);
            else std::construct_at(p, std::forward<Args>(args)...);
        }
        template<class V> bool operator==(const DefaultInitAllocator<V>&) const noexcept { return true; }
    };
    static constexpr bool fill_identity_rows_ =
        std::is_integral_v<T> && !std::is_same_v<T, bool> && sizeof(T) >= 4;
    using Row = std::conditional_t<fill_identity_rows_,
        std::vector<T, DefaultInitAllocator<T>>, std::vector<T>>;
    std::vector<Row> table_;
    std::size_t length_ = 0;'''
assert old in s;s=s.replace(old,new).replace('''        table_.push_back(values);
        if (n <= 2) return;''','''        if constexpr (fill_identity_rows_) table_.emplace_back(values.begin(), values.end());
        else table_.push_back(values);
        if (n <= 2) return;''').replace('if constexpr (fill_identity_rows_) table_.emplace_back(n, identity_);','if constexpr (fill_identity_rows_) table_.emplace_back(n);')
s=s.replace('''    std::vector<T> values() const { return table_.empty() ? std::vector<T>{} : table_.front(); }''','''    std::vector<T> values() const {
        if (table_.empty()) return {};
        if constexpr (fill_identity_rows_) return std::vector<T>(table_.front().begin(), table_.front().end());
        else return table_.front();
    }''')
(D/'allocator.hpp').write_text(s);e=next(e for e in prepare_verify.collect()if e['id']=='disjoint_sparse_table');data,_=prepare_verify.render(e,source_overrides={'DataStructure/Disjoint_Sparse_Table.cpp':s.encode()});(D/'allocator.cpp').write_bytes(data)
comps=[('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]
for cc,args in comps:
 for kind,src,defs in [('main',D/'allocator.cpp',[]),('micro',D/'micro.cpp',['-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_DISJOINT_TEST_SOURCE="{D/"allocator.hpp"}"'])]:
  exe=D/f'alloc_{kind}_{cc}';cmd=['taskset','-c','4',*args,'-std=c++23','-O2',*defs,str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr
print('BUILT',flush=True);raw=[];rng=random.Random(745191)
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for kind in ['main','micro']:
  for cc,_ in comps:
   tasks=['official_max_random_0','official_small_width_query_3','official_small_width_query_4','official_small_values_0','4096_random','500000_build']if kind=='main'else[('min',32,'build',20000),('min',4096,'build',150),('min',500000,'build',3),('sum32',500000,'build',3),('gcd32',500000,'build',3),('min',500000,'query',1),('gcd32',4096,'query',1),('min',500000,'copy',3),('min',500000,'values',50)]
   for case in tasks:
    for rep in range(11):
     labels=['base','control','owned','allocator'];rng.shuffle(labels)
     for label in labels:
      if label=='allocator':exe=D/f'alloc_{kind}_{cc}'
      elif kind=='main':exe=D/f'{cc}_{"base"if label=="control"else label}'
      else:exe=D/f'micro_{cc}_{"base"if label=="control"else label}'
      shutil.copyfile(exe,D/'active_alloc');(D/'active_alloc').chmod(0o700)
      if kind=='main':
       inp=P/((case if case.startswith('official')else'input_'+case)+'.in')
       with inp.open('rb')as fi,(D/'output').open('wb')as fo:
        p=subprocess.Popen(['taskset','-c','12',str(D/'active_alloc')],stdin=fi,stdout=fo);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;ns=round((ru.ru_utime+ru.ru_stime)*1e9)
       check=hashlib.sha256((D/'output').read_bytes()).hexdigest()
      else:
       ty,n,mode,reps=case;p=subprocess.run(['taskset','-c','12',str(D/'active_alloc'),str(n),mode,str(reps),ty],capture_output=True,text=True,check=True);check,ns=map(int,p.stdout.split())
      raw.append(dict(kind=kind,compiler=cc,case=case,rep=rep,label=label,cpu_ns=ns,checksum=check))
    rr=[r for r in raw if r['kind']==kind and r['compiler']==cc and r['case']==case];assert len({r['checksum']for r in rr})==1;m={l:statistics.median(r['cpu_ns']for r in rr if r['label']==l)for l in labels};print(kind,cc,case,{k:round(x/m['base'],4)for k,x in m.items()},flush=True);(D/'allocator_raw.json').write_text(json.dumps(raw))
print('DONE',flush=True)
