# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,subprocess,json,statistics,random,shutil,fcntl,os,time,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_disjoint_final_followup_20261103');P=Path('/tmp/sirkit_sparse_speed_20261103');sys.path.insert(0,str(R/'Scripts'));import prepare_verify
s=(D/'before.hpp').read_text();h=s.replace('#include <cstddef>','#include <cstddef>\n#include <memory>')
h=h.replace('fill_identity_rows_','array_rows_')
old='''    // 第0行は、原列と半幅1の行を兼ねる。
    std::vector<std::vector<T>> table_;
    std::size_t length_ = 0;
    static constexpr bool array_rows_ =
        std::is_integral_v<T> && !std::is_same_v<T, bool> && sizeof(T) >= 4;'''
new='''    static constexpr bool array_rows_ =
        std::is_integral_v<T> && !std::is_same_v<T, bool> && sizeof(T) >= 4;
    using Row = std::conditional_t<array_rows_, std::unique_ptr<T[]>, std::vector<T>>;
    std::vector<Row> table_;
    std::size_t length_ = 0;'''
assert old in h;h=h.replace(old,new)
h=h.replace('''        return op_(table_[k][l], table_[k][last]);''','''        if constexpr (array_rows_) {
            const T* row = table_[k].get();
            return op_(row[l], row[last]);
        } else return op_(table_[k][l], table_[k][last]);''')
h=h.replace('''        table_.push_back(values);
        if (n <= 2) return;''','''        if constexpr (array_rows_) {
            auto original = std::make_unique_for_overwrite<T[]>(n);
            std::copy_n(values.data(), n, original.get());
            table_.push_back(std::move(original));
        } else table_.push_back(values);
        if (n <= 2) return;''')
h=h.replace('if constexpr (array_rows_) table_.emplace_back(n, identity_);','if constexpr (array_rows_) table_.push_back(std::make_unique_for_overwrite<T[]>(n));')
h=h.replace('''    DisjointSparseTable(const DisjointSparseTable&) = default;''','''    DisjointSparseTable(const DisjointSparseTable&) requires (!array_rows_) = default;
    DisjointSparseTable(const DisjointSparseTable& other)
        requires (array_rows_ && std::is_copy_constructible_v<Op>)
        : op_(other.op_), identity_(other.identity_), length_(other.length_) {
        table_.reserve(other.table_.size());
        for (const auto& source : other.table_) {
            auto row = std::make_unique_for_overwrite<T[]>(length_);
            std::copy_n(source.get(), length_, row.get());
            table_.push_back(std::move(row));
        }
    }''')
h=h.replace('''    std::vector<T> values() const { return table_.empty() ? std::vector<T>{} : table_.front(); }''','''    std::vector<T> values() const {
        if (table_.empty()) return {};
        if constexpr (array_rows_) {
            const T* first = table_.front().get();
            return std::vector<T>(first, first + length_);
        } else return table_.front();
    }''')
v={'base':s,'owned':h}
e=next(e for e in prepare_verify.collect()if e['id']=='disjoint_sparse_table');comps=[('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]
for label,src in v.items():
 (D/f'{label}.hpp').write_text(src);data,_=prepare_verify.render(e,source_overrides={'DataStructure/Disjoint_Sparse_Table.cpp':src.encode()});(D/f'{label}.cpp').write_bytes(data)
 for cc,args in comps:
  cmd=['taskset','-c','4',*args,'-std=c++23','-O2',str(D/f'{label}.cpp'),'-o',str(D/f'{cc}_{label}')];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr
print('BUILT',flush=True);raw=[];rng=random.Random(532491)
cases=['official_random_0','official_random_2','official_max_random_0','official_max_random_1','official_small_width_query_0','official_small_width_query_3','official_small_width_query_4','official_small_values_0','32_random','4096_random','500000_build']
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc,_ in comps:
  for case in cases:
   inp=P/((case if case.startswith('official')else'input_'+case)+'.in')
   for rep in range(11):
    labels=['base','control','owned'];rng.shuffle(labels)
    for label in labels:
     shutil.copyfile(D/f'{cc}_{"base"if label=="control"else label}',D/'active');(D/'active').chmod(0o700)
     with inp.open('rb')as fi,(D/'output').open('wb')as fo:
      start=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-start
     raw.append(dict(compiler=cc,case=case,rep=rep,label=label,cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),wall_ns=wall,max_rss_bytes=ru.ru_maxrss*1024,sha256=hashlib.sha256((D/'output').read_bytes()).hexdigest()))
   rr=[r for r in raw if r['compiler']==cc and r['case']==case];assert len({r['sha256']for r in rr})==1;m={l:statistics.median(r['cpu_ns']for r in rr if r['label']==l)for l in labels};print(cc,case,{k:round(x/m['base'],4)for k,x in m.items()},flush=True);(D/'screen_raw.json').write_text(json.dumps(raw))
