# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,statistics,random,shutil,fcntl
D=Path('/tmp/sirkit_disjoint_final_followup_20261103');P=Path('/tmp/sirkit_disjoint_followup_20261103');(D/'micro.cpp').write_bytes((P/'micro.cpp').read_bytes());raw=[];rng=random.Random(582145)
comps=[('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]
for cc,args in comps:
 for label in ['base','owned']:
  cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_DISJOINT_TEST_SOURCE="{D/(label+".hpp")}"',str(D/'micro.cpp'),'-o',str(D/f'micro_{cc}_{label}')];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr
print('BUILT',flush=True)
tasks=[(ty,n,mode,reps)for ty in ['min','sum32','gcd32','first32','sum','affine','bool']for n,reps in [(32,20000),(4096,150),(500000,3)]for mode in ['build','query']]
for ty in ['min','bool']:
 for n in [32,500000]:tasks.append((ty,n,'get',1))
for n in [32,4096,500000]:tasks.append(('sum',n,'boundary',1))
for mode in ['copy','values']:tasks.append(('min',500000,mode,3))
for n in [0,1,2]:tasks.append(('min',n,'build',50000))
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc,_ in comps:
  for ty,n,mode,reps in tasks:
   for rep in range(11):
    labels=['base','control','owned'];rng.shuffle(labels);checks=[]
    for label in labels:
     shutil.copyfile(D/f'micro_{cc}_{"base"if label=="control"else label}',D/'active_micro');(D/'active_micro').chmod(0o700);p=subprocess.run(['taskset','-c','12',str(D/'active_micro'),str(n),mode,str(reps),ty],capture_output=True,text=True,check=True);check,ns=map(int,p.stdout.split());checks.append(check);raw.append(dict(compiler=cc,type=ty,n=n,mode=mode,repeated_operations=reps,rep=rep,label=label,cpu_ns=ns,checksum=check))
    assert len(set(checks))==1
   rr=[r for r in raw if(r['compiler'],r['type'],r['n'],r['mode'])==(cc,ty,n,mode)];m={l:statistics.median(r['cpu_ns']for r in rr if r['label']==l)for l in labels};print(cc,ty,n,mode,{k:round(x/max(m['base'],1),4)for k,x in m.items()},flush=True);(D/'micro_raw.json').write_text(json.dumps(raw))
print('DONE',flush=True)
