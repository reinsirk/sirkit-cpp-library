# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,os,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_disjoint_final_followup_20261103');rows=[]
assert (D/'before.hpp').read_bytes()==(R/'DataStructure/Disjoint_Sparse_Table.cpp').read_bytes()
assert (D/'driver.cpp').read_bytes()==(R/'Verify/current/drivers/disjoint_sparse_table_main.cpp').read_bytes()
assert hashlib.sha256((R/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest()=='291bf8dbc56a1d691f6256fe95b4714183c2cf5d9e55e4bef240e31d1eb178c1'
for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  for test in ['disjoint_sparse_table_owned_rows_test','range_structures_allocation_test']:
   exe=D/f'final_{cc}_{int(skip)}_{test}'
   cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-DSIRKIT_DISABLE_SIMD']
   if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
   if test=='disjoint_sparse_table_owned_rows_test':cmd+=['-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-omit-frame-pointer']
   cmd+=[str(R/f'Verify/current/tests/{test}.cpp'),'-o',str(exe)]
   p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr
   p=subprocess.run(['taskset','-c','4',str(exe)],capture_output=True,text=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'})
   rows.append(dict(compiler=cc,skip_runtime_checks=skip,test=test,command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
   (D/'final_checks.json').write_text(json.dumps(rows,indent=2)+'\n')
   print(cc,skip,test,p.returncode,p.stdout.strip(),flush=True)
   assert p.returncode==0 and not p.stderr,p.stderr
