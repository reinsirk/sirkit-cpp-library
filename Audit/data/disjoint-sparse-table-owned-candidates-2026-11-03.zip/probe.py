# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,os,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_disjoint_final_followup_20261103');rows=[]
for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for label in ['before','owned']:
  for test in ['disjoint_sparse_table_owned_rows_test','disjoint_sparse_table_integer_init_test','disjoint_sparse_table_storage_test','range_structures_allocation_test']:
   src=R/f'Verify/current/tests/{test}.cpp';exe=D/f'probe_{cc}_{label}_{test}';cmd=['taskset','-c','4',*args,'-std=c++23','-O2',f'-DSIRKIT_DISJOINT_TEST_SOURCE="{D/(label+".hpp")}"']
   if test!='range_structures_allocation_test':cmd+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
   if test=='disjoint_sparse_table_owned_rows_test':cmd+=['-Wall','-Wextra','-Werror']
   cmd +=[str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,(cmd,p.stderr)
   p=subprocess.run(['taskset','-c','4',str(exe)],capture_output=True,text=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'});rows.append(dict(compiler=cc,label=label,test=test,command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));print(cc,label,test,p.returncode,p.stdout.strip(),flush=True);(D/'probe.json').write_text(json.dumps(rows,indent=2)+'\n');assert p.returncode==0 and not p.stderr,p.stderr
