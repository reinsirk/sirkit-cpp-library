# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,random,re
D=Path('/tmp/sirkit_disjoint_final_followup_20261103');s=(D/'micro.cpp').read_text();old='DisjointSparseTable<T,Op>t(a,identity);auto start=std::clock();';new='DisjointSparseTable<T,Op>t(a,identity);if(mode=="query"){std::puts("READY");std::fflush(stdout);std::getchar();}auto start=std::clock();';assert old in s;s=s.replace(old,new);(D/'hold.cpp').write_text(s)
for label in ['base','owned','allocator']:
 cmd=['taskset','-c','4','/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_DISJOINT_TEST_SOURCE="{D/(label+".hpp")}"',str(D/'hold.cpp'),'-o',str(D/('hold_'+label))];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr
rows=[];rng=random.Random(61215)
for rep in range(7):
 labels=['base','owned','allocator'];rng.shuffle(labels)
 for label in labels:
  p=subprocess.Popen(['taskset','-c','12',str(D/('hold_'+label)),'500000','query','1','min'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);assert p.stdout.readline().strip()=='READY';stats=Path(f'/proc/{p.pid}/smaps_rollup').read_text();selected={k:int(v)for k,v in re.findall(r'^(Rss|Anonymous|AnonHugePages|Private_Dirty):\s+(\d+) kB',stats,re.M)};out,err=p.communicate('\n');assert p.returncode==0 and not err;check,ns=map(int,out.split());rows.append(dict(rep=rep,label=label,stats_kib=selected,query_cpu_ns=ns,checksum=check));print(rep,label,selected,ns,flush=True)
(D/'page_probe.json').write_text(json.dumps(rows,indent=2)+'\n')
