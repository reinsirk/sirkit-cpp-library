# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,datetime,zipfile,statistics,collections
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_disjoint_final_followup_20261103')
checks=json.loads((D/'final_checks.json').read_text());assert len(checks)==8 and all(x['returncode']==0 and not x['stderr'] for x in checks)
assert (D/'before.hpp').read_bytes()==(R/'DataStructure/Disjoint_Sparse_Table.cpp').read_bytes()
assert (D/'driver.cpp').read_bytes()==(R/'Verify/current/drivers/disjoint_sparse_table_main.cpp').read_bytes()
name='disjoint-sparse-table-owned-candidates-2026-11-03'
files=['before.hpp','owned.hpp','allocator.hpp','driver.cpp','micro.cpp','hold.cpp','screen.py','screen.log','screen_raw.json','micro_bench.py','micro_bench.log','micro_raw.json','allocator_bench.py','allocator_bench.log','allocator_raw.json','probe.py','probe.log','probe.json','msan.json','page_probe.py','page_probe.log','page_probe.json','final_checks.py','final_checks.log','final_checks.json','generation.log','save_audit.py']
archive=R/f'Audit/data/{name}.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(D/f,f)
 for f in ['disjoint_sparse_table_owned_rows_test','disjoint_sparse_table_integer_init_test','disjoint_sparse_table_storage_test','range_structures_allocation_test']:z.write(R/f'Verify/current/tests/{f}.cpp',f'tests/{f}.cpp')
 z.write(R/'Verify/current/common/fast_io.hpp','fast_io.hpp')
 z.write('/tmp/sirkit_sparse_speed_20261103/official_metadata.json','official_fixture_metadata.json')
raw=json.loads((D/'allocator_raw.json').read_text());summaries=[];groups=collections.defaultdict(lambda:collections.defaultdict(list))
for x in raw:
 key=(x['kind'],x['compiler'],json.dumps(x.get('case')),x.get('type'),x.get('n'),x.get('mode'),x.get('repeated_operations'))
 groups[key][x['label']].append(x['cpu_ns'])
for k,v in groups.items():
 med={label:statistics.median(ns) for label,ns in v.items()};summaries.append(dict(kind=k[0],compiler=k[1],case=k[2],type=k[3],n=k[4],mode=k[5],repeated_operations=k[6],median_cpu_ns=med,ratio_to_base={a:b/med['base'] for a,b in med.items()}))
audit={
 'date':'2026-11-03','decision':'追加の本体変更なし。先行初期化を除く所有配列版・vector独自allocator版は不採用。',
 'online_confirmation':'Audit/online-disjoint-sparse-table-414945-2026-11-03.json',
 'online_result':{'submission':414945,'status':'AC','time_ms':85,'previous_ms':79,'needs_resubmission':False,'scope':'今回の実験前と本体が同じ。派生版へオンラインACは転記しない。'},
 'preserved':{'source_sha256':hashlib.sha256((D/'before.hpp').read_bytes()).hexdigest(),'driver_sha256':hashlib.sha256((D/'driver.cpp').read_bytes()).hexdigest(),'io_sha256':hashlib.sha256((R/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest(),'public_api_unchanged':True},
 'environment':{'cpu':'Intel Core i9-14900K P-Core CPU12（補足CPU14）','gcc':'15.2.0','clang':'21','flags':['-std=c++23','-O2','SKIP_RUNTIME_CHECKS'],'march_native':False,'performance_governor_changed':False,'notes':'周波数固定なし。同一バイナリのcontrolにも変動があり、細かな差は改善と断定しない。main/共通IOは固定。測定順を入れ替えて11回反復。'},
 'candidates':[
 {'name':'owned','storage':'4byte以上の整数行をmake_unique_for_overwrite配列で所有し、各セルへ値を設定してから使う。その他の型は従来のvector。深いコピーとconst参照・非copyable Opの型特性を維持。','decision':'構築が短縮する条件がある一方、照会と提出全体の退行があり不採用。'},
 {'name':'allocator','storage':'整数行はvectorを維持し、独自allocatorのdefault insertionで先行初期化を省く。各セルはfoldで必ず設定。','decision':'構築短縮があっても照会・提出全体での安定した改善がなく不採用。正式な検証済み実装とは扱わない。'}],
 'measurement':{'owned_screen_rows':726,'owned_micro_rows':3564,'four_way_rows':len(raw),'output_agreement':'測定プログラムの出力またはchecksumを照合。','four_way_medians':summaries,'interpretation':'GCCのN=500000 min構築で最終比較の所有配列0.937倍、allocator0.922倍。照会では両案とも約1.5倍になる測定があり、controlの揺らぎも踏まえて改善を採用できない。small_valuesを含む同一mainでも退行が残る。','page_diagnostic':'全21実行でAnonHugePages=0。巨大ページが原因とする仮説は裏付けられない。原因を断定しない。'},
 'correctness':{'current_source_added_tests':checks,'prototype_probe':'所有配列版と現行版をGCC/Clangで境界・型・コピー・例外テスト。16実行PASS。所有配列版の整数初期化5192100件はMemorySanitizerもPASS。','prototype_probe_file':'probe.json（evidence ZIP内）','ownership':'現行版の例外注入テストは各実行6470 checks / 3761 failures / live_delta=0。','leak_sanitizer':'ASanのdetect_leaks=0。所有権と部分構築の解放はallocation testのliveカウンタで補足。','allocator_scope':'allocator案は性能用プログラムの出力照合まで。型・例外・sanitizerの正式検証は未実施のまま不採用。'},
 'evidence':{'path':archive.relative_to(R).as_posix(),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'scope':'自作の比較コード・試作・現行スナップショット・ログ・fixtureメタデータ。公式generatorソース、実行バイナリ、大きい入力は含めない。'},
 'synchronization':'通常版・派生版の提出注記は最新URLのみ。使用例・本体に変更なし。生成照合と配布ZIP検証は別記録。'
}
(R/f'Audit/performance-{name}.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print('Saved',archive,len(raw),'measurements; unchanged source')
