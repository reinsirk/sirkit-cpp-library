// SPDX-License-Identifier: CC0-1.0
#include "Verify/current/common/fast_io.hpp"
#include <string>
int main() {
    std::string s; verify_in >> s;
    const auto z = ZAlgorithm(s);
    for (std::size_t i = 0; i < z.size(); ++i) verify_out << (i ? " " : "") << z[i];
    verify_out << '\n';
}
