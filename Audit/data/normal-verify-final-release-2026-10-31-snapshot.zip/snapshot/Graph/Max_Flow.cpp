// SPDX-License-Identifier: CC0-1.0
// 参考（最大流の理論）: https://atcoder.github.io/ac-library/production/document_ja/maxflow.html
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/max_flow.md
//
// API一覧
// MaxFlow<Capacity=std::int64_t>(n=0): n頂点。Capacityはbool以外の整数型。O(n)時間・領域。
// add_edge(u,v,capacity): 非負容量の有向辺を追加し、size_tの辺番号を返す。自己辺・多重辺可。償却O(1)。
// reserve_edges(m): 元辺の位置表をm辺分確保。size()/edge_count(): 頂点数/元辺数。O(1)。
// flow(s,t,limit=max): limit以下の追加最大流を返し残余グラフを更新。s==tまたはlimit==0は0。
// 反復Dinic法。O(n^2 m)時間、追加O(n)領域。残余を再利用でき、総流量が型上限を越す場合は分割して呼ぶ。
// min_cut(s): 現在の残余辺でsから到達可能な頂点のbool配列。O(n+m)時間・O(n)領域。
// get_edge(id): Edge{from,to,capacity,flow}のコピー。edges(): 元辺順の一覧コピー。O(1)/O(m)。
// change_edge(id,capacity,flow): 指定辺を0<=flow<=capacityへ変更。O(1)。流量保存は利用側の責任。
// 継続flowは同じ始点・終点か、利用側が流量保存を保証した残余グラフに対して行う。
// reset(n=0)/swap(other): 空のn頂点へ戻す/O(1)交換。コピーは残余を独立所有、ムーブ元は空。
// 端点・負容量等の入力検査はSKIP_RUNTIME_CHECKSで除く。内部添字と容量差の安全な計算は維持。

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

#ifndef SIRKIT_MAX_FLOW_DEFINED
#define SIRKIT_MAX_FLOW_DEFINED

template<class Capacity = std::int64_t>
class MaxFlow {
    static_assert(std::is_integral_v<Capacity> && !std::is_same_v<Capacity, bool>, "capacity must be a non-bool integer");
public:
    struct Edge { int from; int to; Capacity capacity; Capacity flow; };
private:
    struct Arc { int to; int reverse; Capacity residual; };
    struct Frame { int vertex; Capacity limit; Capacity sent; };
    std::vector<std::vector<Arc>> graph_;
    std::vector<std::pair<int, int>> positions_;
    std::vector<int> level_, next_, queue_;
    std::vector<Frame> frames_;
    static std::size_t checked_size(int n) {
        if (n < 0) throw std::length_error("MaxFlow: negative vertex count");
        return static_cast<std::size_t>(n);
    }
#ifndef SKIP_RUNTIME_CHECKS
    void vertex(int v) const {
        if (v < 0 || v >= size()) throw std::out_of_range("MaxFlow: vertex out of range");
    }
    void edge_id(std::size_t id) const {
        if (id >= positions_.size()) throw std::out_of_range("MaxFlow: edge out of range");
    }
    static void nonnegative(Capacity value) {
        if constexpr (std::is_signed_v<Capacity>) if (value < 0) throw std::invalid_argument("MaxFlow: negative capacity");
    }
#endif
    bool levels(int source, int sink) {
        std::fill(level_.begin(), level_.end(), -1);
        int front = 0, end = 0; queue_[end++] = source; level_[source] = 0;
        while (front != end) {
            const int v = queue_[front++];
            for (const auto& edge : graph_[v]) if (edge.residual != 0 && level_[edge.to] == -1) {
                level_[edge.to] = level_[v] + 1; queue_[end++] = edge.to;
            }
        }
        return level_[sink] != -1;
    }
    Capacity blocking_flow(int source, int sink, Capacity limit) {
        frames_.clear(); frames_.push_back({source, limit, 0});
        while (!frames_.empty()) {
            auto& frame = frames_.back(); const int v = frame.vertex;
            if (v != sink && frame.sent != frame.limit) {
                auto& cursor = next_[v];
                while (cursor != static_cast<int>(graph_[v].size())) {
                    const auto& edge = graph_[v][cursor];
                    if (edge.residual != 0 && level_[edge.to] == level_[v] + 1) break;
                    ++cursor;
                }
                if (cursor != static_cast<int>(graph_[v].size())) {
                    const auto& edge = graph_[v][cursor];
                    frames_.push_back({edge.to, std::min(static_cast<Capacity>(frame.limit - frame.sent), edge.residual), 0});
                    continue;
                }
                level_[v] = -1;
            }
            const Capacity sent = v == sink ? frame.limit : frame.sent;
            frames_.pop_back();
            if (frames_.empty()) return sent;
            auto& parent = frames_.back(); auto& edge = graph_[parent.vertex][next_[parent.vertex]];
            edge.residual -= sent; graph_[edge.to][edge.reverse].residual += sent;
            parent.sent += sent;
            if (edge.residual == 0 || level_[edge.to] == -1) ++next_[parent.vertex];
        }
        return 0;
    }
public:
    explicit MaxFlow(int n = 0) : graph_(checked_size(n)), level_(graph_.size()), next_(graph_.size()), queue_(graph_.size()) {}
    MaxFlow(const MaxFlow&) = default;
    MaxFlow(MaxFlow&& other) noexcept { swap(other); }
    MaxFlow& operator=(MaxFlow other) noexcept { swap(other); return *this; }
    void swap(MaxFlow& other) noexcept {
        graph_.swap(other.graph_); positions_.swap(other.positions_); level_.swap(other.level_);
        next_.swap(other.next_); queue_.swap(other.queue_); frames_.swap(other.frames_);
    }
    void reset(int n = 0) { MaxFlow replacement(n); swap(replacement); }
    int size() const noexcept { return static_cast<int>(graph_.size()); }
    std::size_t edge_count() const noexcept { return positions_.size(); }
    void reserve_edges(std::size_t count) { positions_.reserve(count); }
    std::size_t add_edge(int from, int to, Capacity capacity) {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(from); vertex(to); nonnegative(capacity);
#endif
        constexpr auto maximum = static_cast<std::size_t>(std::numeric_limits<int>::max());
        if (graph_[from].size() >= maximum || graph_[to].size() >= maximum ||
            (from == to && graph_[from].size() >= maximum - 1)) throw std::length_error("MaxFlow: too many incident edges");
        const int forward = static_cast<int>(graph_[from].size());
        const int backward = static_cast<int>(graph_[to].size()) + static_cast<int>(from == to);
        graph_[from].push_back({to, backward, capacity});
        try { graph_[to].push_back({from, forward, 0}); }
        catch (...) { graph_[from].pop_back(); throw; }
        try { positions_.emplace_back(from, forward); }
        catch (...) { graph_[to].pop_back(); graph_[from].pop_back(); throw; }
        return positions_.size() - 1;
    }
    Edge get_edge(std::size_t id) const {
#ifndef SKIP_RUNTIME_CHECKS
        edge_id(id);
#endif
        const auto [from, position] = positions_[id]; const auto& edge = graph_[from][position];
        const Capacity sent = graph_[edge.to][edge.reverse].residual;
        return {from, edge.to, static_cast<Capacity>(edge.residual + sent), sent};
    }
    std::vector<Edge> edges() const {
        std::vector<Edge> result; result.reserve(positions_.size());
        for (std::size_t id = 0; id < positions_.size(); ++id) result.push_back(get_edge(id));
        return result;
    }
    void change_edge(std::size_t id, Capacity capacity, Capacity sent) {
#ifndef SKIP_RUNTIME_CHECKS
        edge_id(id); nonnegative(capacity); nonnegative(sent);
        if (sent > capacity) throw std::invalid_argument("MaxFlow: flow exceeds capacity");
#endif
        const auto [from, position] = positions_[id]; auto& edge = graph_[from][position];
        edge.residual = capacity - sent; graph_[edge.to][edge.reverse].residual = sent;
    }
    Capacity flow(int source, int sink, Capacity limit = std::numeric_limits<Capacity>::max()) {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(source); vertex(sink); nonnegative(limit);
#endif
        if (source == sink || limit == 0) return 0;
        frames_.reserve(graph_.size());
        Capacity result = 0;
        while (result != limit && levels(source, sink)) {
            std::fill(next_.begin(), next_.end(), 0);
            result += blocking_flow(source, sink, limit - result);
        }
        return result;
    }
    std::vector<bool> min_cut(int source) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(source);
#endif
        std::vector<bool> reachable(graph_.size()); std::vector<int> queue;
        queue.reserve(graph_.size()); queue.push_back(source); reachable[source] = true;
        for (std::size_t front = 0; front < queue.size(); ++front) {
            const int v = queue[front];
            for (const auto& edge : graph_[v]) if (edge.residual != 0 && !reachable[edge.to]) {
                reachable[edge.to] = true; queue.push_back(edge.to);
            }
        }
        return reachable;
    }
};
#endif
