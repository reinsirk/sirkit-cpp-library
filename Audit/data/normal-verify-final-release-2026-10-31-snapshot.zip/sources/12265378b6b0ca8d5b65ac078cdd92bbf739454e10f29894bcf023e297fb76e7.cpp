#define SKIP_RUNTIME_CHECKS
// Verify: https://judge.yosupo.jp/problem/two_sat

// Library: Graph/Two_SAT.cpp
// SPDX-License-Identifier: CC0-1.0
// 参考（2-SATの問題分類）: https://nyaannyaan.github.io/library/math/two-sat.hpp
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/two_sat.md
//
// API一覧
// TwoSAT(n=0): n個のbool変数。変数番号[0,n)。O(1)準備。n<=INT_MAX/2。
// add_clause(i,a,j,b): (x_i==a)または(x_j==b)という節を追加。償却O(1)。解を無効化する。
// imply(i,a,j,b): (x_i==a)なら(x_j==b)。force(i,a): x_i==aを強制。償却O(1)。
// add_xor(i,j,different=true): 2変数の値が異なる/等しいという制約。償却O(1)。
// reserve_clauses(m): m節分の領域を確保。size()/clause_count(): 変数数/内部2リテラル節数。O(1)。
// solve(): 充足可能ならtrue。反復SCCでO(n+m)時間・追加領域。追加後は再実行する。
// answer(): 最後のsolve成功時の0/1 byte配列へのconst参照。value(i): そのbool値。O(1)。
// reset(n=0): 制約を捨てn変数へ。swap(other): O(1)。コピーは独立所有、ムーブ元は空の未解決状態。
// 入力検査はSKIP_RUNTIME_CHECKSで除く。answer/valueは最後のsolveがtrueであることが前提。

#include <algorithm>
#include <cstddef>
#include <limits>
#include <stdexcept>
#include <utility>
#include <vector>

#ifndef SIRKIT_SCC_DETAIL_DEFINED
#define SIRKIT_SCC_DETAIL_DEFINED
namespace reinsirk::detail {
inline std::pair<int, std::vector<int>> directed_component_ids(
        int n, const std::vector<std::pair<int, int>>& edges) {
    std::vector<std::size_t> begin(static_cast<std::size_t>(n) + 1);
    for (auto [u, v] : edges) { (void)v; ++begin[static_cast<std::size_t>(u) + 1]; }
    for (int v = 0; v < n; ++v) begin[v + 1] += begin[v];
    std::vector<std::size_t> next(begin.begin(), begin.end() - 1);
    std::vector<int> destination(edges.size());
    for (auto [u, v] : edges) destination[next[u]++] = v;
    std::copy_n(begin.begin(), n, next.begin());
    std::vector<int> entered(n, -1), low(n), ids(n), dfs, pending;
    std::vector<unsigned char> active(n);
    dfs.reserve(n); pending.reserve(n);
    int clock = 0, count = 0;
    for (int root = 0; root < n; ++root) {
        if (entered[root] != -1) continue;
        entered[root] = low[root] = clock++;
        active[root] = 1; dfs.push_back(root); pending.push_back(root);
        while (!dfs.empty()) {
            const int v = dfs.back();
            if (next[v] != begin[v + 1]) {
                const int u = destination[next[v]++];
                if (entered[u] == -1) {
                    entered[u] = low[u] = clock++;
                    active[u] = 1; dfs.push_back(u); pending.push_back(u);
                } else if (active[u]) low[v] = std::min(low[v], entered[u]);
                continue;
            }
            dfs.pop_back();
            if (low[v] == entered[v]) {
                for (;;) {
                    const int u = pending.back(); pending.pop_back();
                    active[u] = 0; ids[u] = count;
                    if (u == v) break;
                }
                ++count;
            }
            if (!dfs.empty()) {
                const int parent = dfs.back();
                low[parent] = std::min(low[parent], low[v]);
            }
        }
    }
    for (auto& id : ids) id = count - 1 - id;
    return {count, std::move(ids)};
}
}
#endif

#ifndef SIRKIT_TWO_SAT_DEFINED
#define SIRKIT_TWO_SAT_DEFINED
class TwoSAT {
    int n_ = 0;
    std::vector<std::pair<int, int>> implications_;
    std::vector<unsigned char> answer_;
#ifndef SKIP_RUNTIME_CHECKS
    bool solved_ = false, satisfiable_ = false;
    void variable(int i) const {
        if (i < 0 || i >= n_) throw std::out_of_range("TwoSAT: variable out of range");
    }
    void require_answer() const {
        if (!solved_ || !satisfiable_) throw std::logic_error("TwoSAT: no current satisfying assignment");
    }
#endif
    void room(std::size_t extra) {
        const auto maximum = implications_.max_size(), current = implications_.size();
        if (extra > maximum - current) throw std::length_error("TwoSAT: too many clauses");
        if (implications_.capacity() - current >= extra) return;
        const auto capacity = implications_.capacity();
        const auto grown = capacity <= maximum / 2 ? capacity * 2 : maximum;
        implications_.reserve(std::max(current + extra, std::max(std::min(std::size_t{4}, maximum), grown)));
    }
    void invalidate() noexcept {
#ifndef SKIP_RUNTIME_CHECKS
        solved_ = satisfiable_ = false;
#endif
    }
public:
    explicit TwoSAT(int n = 0) : n_(n) {
        if (n < 0 || n > std::numeric_limits<int>::max() / 2) throw std::length_error("TwoSAT: invalid variable count");
    }
    TwoSAT(const TwoSAT&) = default;
    TwoSAT(TwoSAT&& other) noexcept { swap(other); }
    TwoSAT& operator=(TwoSAT other) noexcept { swap(other); return *this; }
    void swap(TwoSAT& other) noexcept {
        std::swap(n_, other.n_); implications_.swap(other.implications_); answer_.swap(other.answer_);
#ifndef SKIP_RUNTIME_CHECKS
        std::swap(solved_, other.solved_); std::swap(satisfiable_, other.satisfiable_);
#endif
    }
    void reset(int n = 0) { TwoSAT replacement(n); swap(replacement); }
    int size() const noexcept { return n_; }
    std::size_t clause_count() const noexcept { return implications_.size() / 2; }
    void reserve_clauses(std::size_t count) {
        if (count > implications_.max_size() / 2) throw std::length_error("TwoSAT: too many clauses");
        implications_.reserve(count * 2);
    }
    void add_clause(int i, bool a, int j, bool b) {
#ifndef SKIP_RUNTIME_CHECKS
        variable(i); variable(j);
#endif
        room(2);
        implications_.emplace_back(2 * i + !a, 2 * j + b);
        implications_.emplace_back(2 * j + !b, 2 * i + a);
        invalidate();
    }
    void imply(int i, bool a, int j, bool b) { add_clause(i, !a, j, b); }
    void force(int i, bool a) { add_clause(i, a, i, a); }
    void add_xor(int i, int j, bool different = true) {
#ifndef SKIP_RUNTIME_CHECKS
        variable(i); variable(j);
#endif
        room(4);
        add_clause(i, true, j, different);
        add_clause(i, false, j, !different);
    }
    bool solve() {
        const auto components = reinsirk::detail::directed_component_ids(2 * n_, implications_);
        const auto& ids = components.second;
        for (int i = 0; i < n_; ++i) if (ids[2 * i] == ids[2 * i + 1]) {
            answer_.clear();
#ifndef SKIP_RUNTIME_CHECKS
            solved_ = true; satisfiable_ = false;
#endif
            return false;
        }
        std::vector<unsigned char> result(n_);
        for (int i = 0; i < n_; ++i) result[i] = ids[2 * i] < ids[2 * i + 1];
        answer_.swap(result);
#ifndef SKIP_RUNTIME_CHECKS
        solved_ = satisfiable_ = true;
#endif
        return true;
    }
    const std::vector<unsigned char>& answer() const {
#ifndef SKIP_RUNTIME_CHECKS
        require_answer();
#endif
        return answer_;
    }
    bool value(int i) const {
#ifndef SKIP_RUNTIME_CHECKS
        require_answer(); variable(i);
#endif
        return answer_[i] != 0;
    }
};
#endif


// SPDX-License-Identifier: CC0-1.0
// Verify I/O: Verify/current/common/fast_io.hpp
// SPDX-License-Identifier: CC0-1.0
#include <algorithm>
#include <array>
#include <charconv>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <vector>

#ifndef SIRKIT_VERIFY_FAST_IO_DEFINED
#define SIRKIT_VERIFY_FAST_IO_DEFINED

// VerifyInput(file=stdin): 非所有のFILEから読む。別の入力方式と混用しない。
// >> 整数: 64bit以下の十進整数を読む。検査省略時は値域内の正しい入力を前提とする。
// >> char/string: 空白を飛ばし、1文字／空白までの文字列を読む。
// >> 浮動小数点: 十進文字列を変換する。通常のCロケールで使う。
// bool / !: 直前までの読み取りが成功しているか／失敗したかを返す。
class VerifyInput {
    static constexpr std::size_t buffer_size = 1 << 17;
    std::FILE* file_;
    std::array<unsigned char, buffer_size> buffer_;
    std::size_t position_ = 0, size_ = 0;
    bool good_ = true;

    int peek() {
        if (position_ == size_) {
            size_ = std::fread(buffer_.data(), 1, buffer_.size(), file_);
            position_ = 0;
            if (size_ == 0) return EOF;
        }
        return buffer_[position_];
    }

    int skip_space() {
        int c;
        while ((c = peek()) != EOF && c <= ' ') ++position_;
        if (c == EOF) good_ = false;
        return c;
    }

public:
    explicit VerifyInput(std::FILE* file = stdin) : file_(file) {}
    VerifyInput(const VerifyInput&) = delete;
    VerifyInput& operator=(const VerifyInput&) = delete;

    explicit operator bool() const noexcept { return good_; }
    bool operator!() const noexcept { return !good_; }

    template<class T>
        requires (std::is_integral_v<T> && sizeof(T) <= sizeof(std::uint64_t)
                  && !std::is_same_v<T, char>)
    VerifyInput& operator>>(T& result) {
        if (!good_) return *this;
        int c = skip_space();
        if (c == EOF) return *this;
        bool negative = false;
        if (c == '-' || c == '+') {
            negative = c == '-';
            ++position_;
            c = peek();
        }
        if (c == EOF) {
            good_ = false;
            return *this;
        }
#ifndef SKIP_RUNTIME_CHECKS
        if (c < '0' || c > '9') {
            good_ = false;
            return *this;
        }
        // 先頭の0を除けば、20桁以下の末尾直前の値はuint64_tに収まる。
        while (c == '0') {
            ++position_;
            c = peek();
        }
        std::uint64_t previous = 0;
        unsigned last_digit = 0;
        std::size_t digits = 0;
#endif
        std::uint64_t value = 0;
        while (c >= '0' && c <= '9') {
#ifndef SKIP_RUNTIME_CHECKS
            previous = value;
            last_digit = static_cast<unsigned>(c - '0');
            if (digits <= 20) ++digits;
#endif
            value = value * 10 + static_cast<unsigned>(c - '0');
            ++position_;
            c = peek();
        }
#ifndef SKIP_RUNTIME_CHECKS
        constexpr auto maximum = std::numeric_limits<std::uint64_t>::max();
        if ((c != EOF && c > ' ') || digits > 20
            || (digits == 20 && (previous > maximum / 10
                || (previous == maximum / 10 && last_digit > maximum % 10)))) {
            good_ = false;
            return *this;
        }
        std::uint64_t limit = static_cast<std::uint64_t>(std::numeric_limits<T>::max());
        if constexpr (std::is_signed_v<T>) limit += negative;
        else if (negative && value != 0) good_ = false;
        if (value > limit) good_ = false;
        if (!good_) return *this;
#endif
        if constexpr (std::is_signed_v<T>) {
            constexpr std::uint64_t minimum_magnitude =
                static_cast<std::uint64_t>(std::numeric_limits<T>::max()) + 1;
            // -(最小値)は評価せず、絶対値が最大値+1のときだけ最小値を使う。
            result = negative
                ? (value == minimum_magnitude ? std::numeric_limits<T>::min()
                                  : static_cast<T>(-static_cast<T>(value)))
                : static_cast<T>(value);
        } else result = static_cast<T>(value);
        return *this;
    }

    VerifyInput& operator>>(char& result) {
        if (!good_) return *this;
        const int c = skip_space();
        if (c != EOF) {
            result = static_cast<char>(c);
            ++position_;
        }
        return *this;
    }

    VerifyInput& operator>>(std::string& result) {
        if (!good_) return *this;
        int c = skip_space();
        if (c == EOF) return *this;
        result.clear();
        do {
            result.push_back(static_cast<char>(c));
            ++position_;
            c = peek();
        } while (c != EOF && c > ' ');
        return *this;
    }

    template<class T> requires std::is_floating_point_v<T>
    VerifyInput& operator>>(T& result) {
        std::string token;
        *this >> token;
        if (!good_) return *this;
#ifndef SKIP_RUNTIME_CHECKS
        char* end = nullptr;
        const long double value = std::strtold(token.c_str(), &end);
        if (end != token.c_str() + token.size()) good_ = false;
        else result = static_cast<T>(value);
#else
        result = static_cast<T>(std::strtold(token.c_str(), nullptr));
#endif
        return *this;
    }
};

// VerifyOutput(file=stdout): 非所有のFILEへ書く。破棄時にflushし、FILEは閉じない。
// << 整数/char/文字列/浮動小数点: 値を出力する。整数は64bit以下に対応する。
// fixed(digits): 浮動小数点を小数点以下digits桁で出力する（digits>=0）。
// flush(): バッファの内容をFILEへ渡す。bool / !で書き込み失敗を確認できる。
class VerifyOutput {
    static constexpr std::size_t buffer_size = 1 << 17;
    std::FILE* file_;
    std::array<char, buffer_size> buffer_;
    std::size_t size_ = 0;
    int precision_ = 6;
    bool fixed_ = false, good_ = true;

    void write(std::string_view text) {
        while (!text.empty() && good_) {
            if (size_ == buffer_.size()) flush();
            const auto count = std::min(text.size(), buffer_.size() - size_);
            std::memcpy(buffer_.data() + size_, text.data(), count);
            size_ += count;
            text.remove_prefix(count);
        }
    }

public:
    explicit VerifyOutput(std::FILE* file = stdout) : file_(file) {}
    VerifyOutput(const VerifyOutput&) = delete;
    VerifyOutput& operator=(const VerifyOutput&) = delete;
    ~VerifyOutput() { flush(); }

    explicit operator bool() const noexcept { return good_; }
    bool operator!() const noexcept { return !good_; }

    VerifyOutput& fixed(int digits) {
        if (digits < 0) throw std::invalid_argument("negative output precision");
        fixed_ = true;
        precision_ = digits;
        return *this;
    }

    void flush() noexcept {
        std::size_t written = 0;
        while (written < size_ && good_) {
            const auto count = std::fwrite(buffer_.data() + written, 1, size_ - written, file_);
            if (count == 0) good_ = false;
            written += count;
        }
        size_ = 0;
    }

    template<class T>
        requires (std::is_integral_v<T> && sizeof(T) <= sizeof(std::uint64_t)
                  && !std::is_same_v<T, char>)
    VerifyOutput& operator<<(T value) {
        if constexpr (std::is_same_v<T, bool>) return *this << static_cast<char>('0' + value);
        else {
            char digits[std::numeric_limits<std::uint64_t>::digits10 + 3];
            const auto end = std::to_chars(digits, digits + sizeof(digits), value).ptr;
            write(std::string_view(digits, static_cast<std::size_t>(end - digits)));
            return *this;
        }
    }

    VerifyOutput& operator<<(char value) {
        if (size_ == buffer_.size()) flush();
        if (good_) buffer_[size_++] = value;
        return *this;
    }

    VerifyOutput& operator<<(std::string_view value) { write(value); return *this; }
    VerifyOutput& operator<<(const std::string& value) { write(value); return *this; }
    VerifyOutput& operator<<(const char* value) { write(value); return *this; }

    template<class T> requires std::is_floating_point_v<T>
    VerifyOutput& operator<<(T value) {
        char local[128];
        const char* format = fixed_ ? "%.*Lf" : "%.*Lg";
        const int count = std::snprintf(local, sizeof(local), format, precision_,
                                        static_cast<long double>(value));
        if (count < 0) good_ = false;
        else if (static_cast<std::size_t>(count) < sizeof(local))
            write(std::string_view(local, static_cast<std::size_t>(count)));
        else {
            std::vector<char> text(static_cast<std::size_t>(count) + 1);
            std::snprintf(text.data(), text.size(), format, precision_, static_cast<long double>(value));
            write(std::string_view(text.data(), static_cast<std::size_t>(count)));
        }
        return *this;
    }
};

inline VerifyInput verify_in;
inline VerifyOutput verify_out;
#endif

#include <string>
int main(){
 std::string prefix,format;int n{},m{};verify_in>>prefix>>format>>n>>m;TwoSAT constraints(n);
 for(int i=0;i<m;++i){int a{},b{},zero{};verify_in>>a>>b>>zero;constraints.add_clause((a>0?a:-a)-1,a>0,(b>0?b:-b)-1,b>0);}
 if(!constraints.solve()){verify_out<<"s UNSATISFIABLE\n";return 0;}
 verify_out<<"s SATISFIABLE\nv";for(int i=0;i<n;++i)verify_out<<' '<<(constraints.value(i)?i+1:-i-1);verify_out<<" 0\n";
}
