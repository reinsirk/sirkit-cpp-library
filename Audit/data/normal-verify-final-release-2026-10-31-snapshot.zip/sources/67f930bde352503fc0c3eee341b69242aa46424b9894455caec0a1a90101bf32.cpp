// Verify: https://judge.yosupo.jp/problem/vertex_add_path_sum

// Library: Graph/Heavy_Light_Decomposition.cpp
// SPDX-License-Identifier: CC0-1.0
// 参考（重軽分解の理論）: https://info.atcoder.jp/entry/algorithm_lectures/heavy_light_decomposition
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/heavy_light_decomposition.md
//
// API一覧
// HeavyLightDecomposition(g,root=0)/build(g,root=0): 無向森を反復DFSで分解。O(n+m)時間・領域。
// 頂点番号[0,n)。隣接リストの対称性は前提。rootの木から、残りは最小未訪問頂点から構築する。
// 失敗時は元を保持。空のgにはroot=0。閉路・自己辺・多重辺は検査有効時に例外。
// size()/empty()/root()/component_count(): 頂点数/空か/指定根（空なら-1）/木の数。O(1)。
// parent(v)/depth(v)/component(v)/root_of(v): 親（根は-1）/深さ/木の番号/木の根。O(1)。
// index(v)/vertex_at(i)/order(): heavy優先DFS添字/対応頂点/順序配列へのconst参照。O(1)。
// same_component(u,v)/is_ancestor(u,v): 同じ木か/祖先か（自身を含む）。O(1)。
// subtree_range(v,edges=false): 部分木の半開区間。edges=trueは根vを除き子側の頂点で辺を表す。O(1)。
// subtree_size(v): 部分木の頂点数。O(1)。lca(u,v)/distance(u,v): LCA/辺数、異なる木は-1。O(log n)。
// kth_ancestor(v,k): k個上の頂点。k<0/根を越すと-1。jump(u,v,k): u→vのk番目、範囲外/異なる木は-1。O(log n)。
// for_each_path(u,v,fn,edges=false): 通行順にfn(left,right,reversed)を呼ぶ。接続ならtrue、異なる木はfalse。
// reversed=trueはright-1からleftへ読む。区間は半開。edges=trueはLCAを除く。O(log n)、ヒープ確保なし。
// path(u,v,edges=false): 同じ順序のInterval{left,right,reversed}配列を返す。異なる木は空。O(log n)時間・領域。
// clear()/swap(other): 空に戻す/O(1)交換。コピーは独立所有、ムーブ元は空。検査はSKIP_RUNTIME_CHECKSで除く。

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <utility>
#include <vector>

#ifndef SIRKIT_UNWEIGHTED_GRAPH_DEFINED
#define SIRKIT_UNWEIGHTED_GRAPH_DEFINED
using Graph = std::vector<std::vector<int>>;
#endif

#ifndef SIRKIT_HEAVY_LIGHT_DECOMPOSITION_DEFINED
#define SIRKIT_HEAVY_LIGHT_DECOMPOSITION_DEFINED
class HeavyLightDecomposition {
public:
    struct Interval { int left; int right; bool reversed; };
private:
    int root_ = -1;
    std::vector<int> parent_, depth_, component_, roots_, subtree_, heavy_, head_, index_, order_;
#ifndef SKIP_RUNTIME_CHECKS
    void vertex(int v) const {
        if (v < 0 || v >= size()) throw std::out_of_range("HLD: vertex out of range");
    }
#endif
    void prepare(const Graph& graph, int root) {
        if (graph.size() > static_cast<std::size_t>(std::numeric_limits<int>::max()))
            throw std::length_error("HLD: too many vertices");
        const int n = static_cast<int>(graph.size());
#ifndef SKIP_RUNTIME_CHECKS
        if ((n == 0 && root != 0) || (n != 0 && (root < 0 || root >= n)))
            throw std::out_of_range("HLD: root out of range");
#endif
        if (n == 0) return;
        root_ = root;
        parent_.assign(n, -2); depth_.resize(n); component_.resize(n); subtree_.assign(n, 1);
        heavy_.assign(n, -1); head_.resize(n); index_.resize(n); order_.resize(n);
        std::vector<int> visited, stack;
        visited.reserve(n); stack.reserve(n);
        const auto discover = [&](int start) {
            const int id = static_cast<int>(roots_.size()); roots_.push_back(start);
            parent_[start] = -1; component_[start] = id; stack.push_back(start);
            while (!stack.empty()) {
                const int v = stack.back(); stack.pop_back(); visited.push_back(v);
#ifndef SKIP_RUNTIME_CHECKS
                bool parent_seen = false;
#endif
                for (int u : graph[v]) {
#ifndef SKIP_RUNTIME_CHECKS
                    vertex(u);
#endif
                    if (u == parent_[v]) {
#ifndef SKIP_RUNTIME_CHECKS
                        if (parent_seen) throw std::invalid_argument("HLD: parallel edge");
                        parent_seen = true;
#endif
                        continue;
                    }
#ifndef SKIP_RUNTIME_CHECKS
                    if (parent_[u] != -2) throw std::invalid_argument("HLD: input must be a forest");
#endif
                    parent_[u] = v; depth_[u] = depth_[v] + 1;
                    component_[u] = id; stack.push_back(u);
                }
            }
        };
        discover(root);
        for (int v = 0; v < n; ++v) if (parent_[v] == -2) discover(v);
        for (std::size_t i = visited.size(); i != 0;) {
            const int v = visited[--i], parent = parent_[v];
            if (parent != -1) {
                subtree_[parent] += subtree_[v];
                if (heavy_[parent] == -1 || subtree_[v] > subtree_[heavy_[parent]]) heavy_[parent] = v;
            }
        }
        int position = 0;
        for (int start : roots_) {
            stack.push_back(start);
            while (!stack.empty()) {
                const int first = stack.back(); stack.pop_back();
                for (int v = first; v != -1; v = heavy_[v]) {
                    head_[v] = first; index_[v] = position; order_[position++] = v;
                    for (int u : graph[v]) if (parent_[u] == v && u != heavy_[v]) stack.push_back(u);
                }
            }
        }
    }
public:
    HeavyLightDecomposition() = default;
    explicit HeavyLightDecomposition(const Graph& graph, int root = 0) { prepare(graph, root); }
    HeavyLightDecomposition(const HeavyLightDecomposition&) = default;
    HeavyLightDecomposition(HeavyLightDecomposition&& other) noexcept { swap(other); }
    HeavyLightDecomposition& operator=(HeavyLightDecomposition other) noexcept { swap(other); return *this; }
    void swap(HeavyLightDecomposition& other) noexcept {
        std::swap(root_, other.root_); parent_.swap(other.parent_); depth_.swap(other.depth_);
        component_.swap(other.component_); roots_.swap(other.roots_); subtree_.swap(other.subtree_);
        heavy_.swap(other.heavy_); head_.swap(other.head_); index_.swap(other.index_); order_.swap(other.order_);
    }
    void clear() noexcept { HeavyLightDecomposition replacement; swap(replacement); }
    void build(const Graph& graph, int root = 0) { HeavyLightDecomposition replacement(graph, root); swap(replacement); }
    int size() const noexcept { return static_cast<int>(parent_.size()); }
    bool empty() const noexcept { return parent_.empty(); }
    int root() const noexcept { return root_; }
    int component_count() const noexcept { return static_cast<int>(roots_.size()); }
    int parent(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return parent_[v];
    }
    int depth(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return depth_[v];
    }
    int component(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return component_[v];
    }
    int root_of(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return roots_[component_[v]];
    }
    int index(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return index_[v];
    }
    int vertex_at(int i) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(i);
#endif
        return order_[i];
    }
    const std::vector<int>& order() const noexcept { return order_; }
    bool same_component(int u, int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        return component_[u] == component_[v];
    }
    bool is_ancestor(int u, int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        return component_[u] == component_[v] && index_[u] <= index_[v] && index_[v] < index_[u] + subtree_[u];
    }
    std::pair<int, int> subtree_range(int v, bool edges = false) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return {index_[v] + static_cast<int>(edges), index_[v] + subtree_[v]};
    }
    int subtree_size(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        return subtree_[v];
    }
    int lca(int u, int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        if (component_[u] != component_[v]) return -1;
        while (head_[u] != head_[v]) {
            if (depth_[head_[u]] > depth_[head_[v]]) u = parent_[head_[u]];
            else v = parent_[head_[v]];
        }
        return depth_[u] < depth_[v] ? u : v;
    }
    int distance(int u, int v) const {
        const int w = lca(u, v);
        return w == -1 ? -1 : (depth_[u] - depth_[w]) + (depth_[v] - depth_[w]);
    }
    int kth_ancestor(int v, std::int64_t k) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(v);
#endif
        if (k < 0 || k > depth_[v]) return -1;
        for (;;) {
            const int within = depth_[v] - depth_[head_[v]];
            if (k <= within) return order_[index_[v] - static_cast<int>(k)];
            k -= static_cast<std::int64_t>(within) + 1; v = parent_[head_[v]];
        }
    }
    int jump(int u, int v, std::int64_t k) const {
        const int w = lca(u, v);
        if (w == -1 || k < 0) return -1;
        const int upward = depth_[u] - depth_[w], downward = depth_[v] - depth_[w];
        if (k > static_cast<std::int64_t>(upward) + downward) return -1;
        return k <= upward ? kth_ancestor(u, k) : kth_ancestor(v, upward + downward - k);
    }
    template<class Fn>
    bool for_each_path(int u, int v, Fn&& visit, bool edges = false) const {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        if (component_[u] != component_[v]) return false;
        std::array<Interval, std::numeric_limits<unsigned int>::digits + 1> downward;
        std::size_t count = 0;
        while (head_[u] != head_[v]) {
            if (depth_[head_[u]] >= depth_[head_[v]]) {
                visit(index_[head_[u]], index_[u] + 1, true); u = parent_[head_[u]];
            } else {
                downward[count++] = {index_[head_[v]], index_[v] + 1, false}; v = parent_[head_[v]];
            }
        }
        if (depth_[u] >= depth_[v]) {
            const int left = index_[v] + static_cast<int>(edges), right = index_[u] + 1;
            if (left < right) visit(left, right, true);
        } else {
            const int left = index_[u] + static_cast<int>(edges), right = index_[v] + 1;
            if (left < right) downward[count++] = {left, right, false};
        }
        while (count != 0) { const auto part = downward[--count]; visit(part.left, part.right, part.reversed); }
        return true;
    }
    std::vector<Interval> path(int u, int v, bool edges = false) const {
        std::vector<Interval> result;
        for_each_path(u, v, [&](int left, int right, bool reverse) { result.push_back({left, right, reverse}); }, edges);
        return result;
    }
};
#endif


// Library: DataStructure/Fenwick_Tree.cpp
// SPDX-License-Identifier: CC0-1.0
// 参考（データ構造・検証問題）: https://nyaannyaan.github.io/library/data-structure/binary-indexed-tree.hpp
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/fenwick_tree.md
//
// API一覧
// [FenwickTree<T>]
// FenwickTree(n=0)/FenwickTree(vector<T>): 0初期化/列から構築。O(n+1)時間・領域。T{}が加法単位元の可換群を使う。
// size()/empty(): 要素数/空か。O(1)。添字は0始まり、区間は半開。加減算がTに収まり、演算/コピーをO(1)とする。
// add(i,delta)/set(i,value): 1点に加算/代入。get(i): 1点の値。O(log(n+1))。
// prefix_sum(r)/sum(l,r)/all_sum(): [0,r)/[l,r)/全区間の和。O(log(n+1))、空区間はT{}。
// lower_bound(target)/upper_bound(target): prefix_sum(i+1)>=target/>targetとなる最小i、なければn。O(log(n+1))。
// 境界探索は全要素が非負で、加算と順序が整合すること。検査のために全要素を走査しない。
// values(): 列を復元して返す。O(n+1)時間・追加O(n)。reset(n)/reset(): n要素/現在の要素数を0にする。O(旧n+n+1)。
// clear()/swap(other): 空にして容量保持/交換。O(旧n+1)/O(1)。コピーは独立、移動元は空として使える。

#include <algorithm>
#include <bit>
#include <cstddef>
#include <limits>
#include <stdexcept>
#include <utility>
#include <vector>

#ifndef SIRKIT_FENWICK_TREE_DEFINED
#define SIRKIT_FENWICK_TREE_DEFINED
template<class T>
class FenwickTree {
    std::vector<T> tree_;
    static std::size_t storage_size(std::size_t n) {
        if (n == std::numeric_limits<std::size_t>::max() || n + 1 > std::vector<T>{}.max_size())
            throw std::length_error("FenwickTree: size");
        return n == 0 ? 0 : n + 1;
    }
    static std::size_t lowbit(std::size_t x) noexcept { return x & (~x + 1); }
    void check_index(std::size_t i) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (i >= size()) throw std::out_of_range("FenwickTree: index");
#else
        (void)i;
#endif
    }
    void check_range(std::size_t l, std::size_t r) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (l > r || r > size()) throw std::out_of_range("FenwickTree: range");
#else
        (void)l; (void)r;
#endif
    }
    T prefix_unchecked(std::size_t r) const {
        T result{};
        for (; r; r -= lowbit(r)) result += tree_[r];
        return result;
    }
public:
    FenwickTree() = default;
    explicit FenwickTree(std::size_t n) : tree_(storage_size(n), T{}) {}
    explicit FenwickTree(const std::vector<T>& values) : tree_(storage_size(values.size()), T{}) {
        const auto n = values.size();
        for (std::size_t i = 1; i <= n; ++i) {
            tree_[i] += values[i - 1];
            const auto step = lowbit(i);
            if (step <= n - i) tree_[i + step] += tree_[i];
        }
    }
    FenwickTree(const FenwickTree&) = default;
    FenwickTree& operator=(const FenwickTree&) = default;
    FenwickTree(FenwickTree&& other) noexcept : tree_(std::move(other.tree_)) { other.tree_.clear(); }
    FenwickTree& operator=(FenwickTree&& other) noexcept {
        if (this != &other) { tree_ = std::move(other.tree_); other.tree_.clear(); }
        return *this;
    }
    std::size_t size() const noexcept { return tree_.empty() ? 0 : tree_.size() - 1; }
    bool empty() const noexcept { return size() == 0; }
    void add(std::size_t i, const T& delta) {
        check_index(i);
        const auto n = size();
        for (++i; i <= n;) {
            tree_[i] += delta;
            const auto step = lowbit(i);
            if (step > n - i) break;
            i += step;
        }
    }
    T get(std::size_t i) const {
        check_index(i);
        auto node = i + 1;
        T result = tree_[node];
        const auto begin = node - lowbit(node);
        for (--node; node > begin; node -= lowbit(node)) result -= tree_[node];
        return result;
    }
    void set(std::size_t i, const T& value) { add(i, value - get(i)); }
    T prefix_sum(std::size_t r) const { check_range(0, r); return prefix_unchecked(r); }
    T sum(std::size_t l, std::size_t r) const {
        check_range(l, r);
        return prefix_unchecked(r) - prefix_unchecked(l);
    }
    T all_sum() const { return prefix_unchecked(size()); }
    std::size_t lower_bound(const T& target) const {
        if (!(T{} < target)) return 0;
        const auto n = size();
        std::size_t index = 0;
        T current{};
        for (auto jump = std::bit_floor(n); jump; jump >>= 1) {
            if (jump <= n - index) {
                const auto next = index + jump;
                T candidate = current + tree_[next];
                if (candidate < target) { current = std::move(candidate); index = next; }
            }
        }
        return index;
    }
    std::size_t upper_bound(const T& target) const {
        if (target < T{}) return 0;
        const auto n = size();
        std::size_t index = 0;
        T current{};
        for (auto jump = std::bit_floor(n); jump; jump >>= 1) {
            if (jump <= n - index) {
                const auto next = index + jump;
                T candidate = current + tree_[next];
                if (!(target < candidate)) { current = std::move(candidate); index = next; }
            }
        }
        return index;
    }
    std::vector<T> values() const {
        if (tree_.empty()) return {};
        std::vector<T> result(tree_.begin() + 1, tree_.end());
        const auto n = size();
        for (auto i = n; i; --i) {
            const auto step = lowbit(i);
            if (step <= n - i) result[i + step - 1] -= result[i - 1];
        }
        return result;
    }
    void reset(std::size_t n) {
        std::vector<T> replacement(storage_size(n), T{});
        tree_.swap(replacement);
    }
    void reset() { std::fill(tree_.begin(), tree_.end(), T{}); }
    void clear() noexcept { tree_.clear(); }
    void swap(FenwickTree& other) noexcept { tree_.swap(other.tree_); }
};
#endif


// SPDX-License-Identifier: CC0-1.0
// Verify I/O: Verify/current/common/fast_io.hpp
// SPDX-License-Identifier: CC0-1.0
#include <algorithm>
#include <array>
#include <charconv>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <vector>

#ifndef SIRKIT_VERIFY_FAST_IO_DEFINED
#define SIRKIT_VERIFY_FAST_IO_DEFINED

// VerifyInput(file=stdin): 非所有のFILEから読む。別の入力方式と混用しない。
// >> 整数: 64bit以下の十進整数を読む。検査省略時は値域内の正しい入力を前提とする。
// >> char/string: 空白を飛ばし、1文字／空白までの文字列を読む。
// >> 浮動小数点: 十進文字列を変換する。通常のCロケールで使う。
// bool / !: 直前までの読み取りが成功しているか／失敗したかを返す。
class VerifyInput {
    static constexpr std::size_t buffer_size = 1 << 17;
    std::FILE* file_;
    std::array<unsigned char, buffer_size> buffer_;
    std::size_t position_ = 0, size_ = 0;
    bool good_ = true;

    int peek() {
        if (position_ == size_) {
            size_ = std::fread(buffer_.data(), 1, buffer_.size(), file_);
            position_ = 0;
            if (size_ == 0) return EOF;
        }
        return buffer_[position_];
    }

    int skip_space() {
        int c;
        while ((c = peek()) != EOF && c <= ' ') ++position_;
        if (c == EOF) good_ = false;
        return c;
    }

public:
    explicit VerifyInput(std::FILE* file = stdin) : file_(file) {}
    VerifyInput(const VerifyInput&) = delete;
    VerifyInput& operator=(const VerifyInput&) = delete;

    explicit operator bool() const noexcept { return good_; }
    bool operator!() const noexcept { return !good_; }

    template<class T>
        requires (std::is_integral_v<T> && sizeof(T) <= sizeof(std::uint64_t)
                  && !std::is_same_v<T, char>)
    VerifyInput& operator>>(T& result) {
        if (!good_) return *this;
        int c = skip_space();
        if (c == EOF) return *this;
        bool negative = false;
        if (c == '-' || c == '+') {
            negative = c == '-';
            ++position_;
            c = peek();
        }
        if (c == EOF) {
            good_ = false;
            return *this;
        }
#ifndef SKIP_RUNTIME_CHECKS
        if (c < '0' || c > '9') {
            good_ = false;
            return *this;
        }
        // 先頭の0を除けば、20桁以下の末尾直前の値はuint64_tに収まる。
        while (c == '0') {
            ++position_;
            c = peek();
        }
        std::uint64_t previous = 0;
        unsigned last_digit = 0;
        std::size_t digits = 0;
#endif
        std::uint64_t value = 0;
        while (c >= '0' && c <= '9') {
#ifndef SKIP_RUNTIME_CHECKS
            previous = value;
            last_digit = static_cast<unsigned>(c - '0');
            if (digits <= 20) ++digits;
#endif
            value = value * 10 + static_cast<unsigned>(c - '0');
            ++position_;
            c = peek();
        }
#ifndef SKIP_RUNTIME_CHECKS
        constexpr auto maximum = std::numeric_limits<std::uint64_t>::max();
        if ((c != EOF && c > ' ') || digits > 20
            || (digits == 20 && (previous > maximum / 10
                || (previous == maximum / 10 && last_digit > maximum % 10)))) {
            good_ = false;
            return *this;
        }
        std::uint64_t limit = static_cast<std::uint64_t>(std::numeric_limits<T>::max());
        if constexpr (std::is_signed_v<T>) limit += negative;
        else if (negative && value != 0) good_ = false;
        if (value > limit) good_ = false;
        if (!good_) return *this;
#endif
        if constexpr (std::is_signed_v<T>) {
            constexpr std::uint64_t minimum_magnitude =
                static_cast<std::uint64_t>(std::numeric_limits<T>::max()) + 1;
            // -(最小値)は評価せず、絶対値が最大値+1のときだけ最小値を使う。
            result = negative
                ? (value == minimum_magnitude ? std::numeric_limits<T>::min()
                                  : static_cast<T>(-static_cast<T>(value)))
                : static_cast<T>(value);
        } else result = static_cast<T>(value);
        return *this;
    }

    VerifyInput& operator>>(char& result) {
        if (!good_) return *this;
        const int c = skip_space();
        if (c != EOF) {
            result = static_cast<char>(c);
            ++position_;
        }
        return *this;
    }

    VerifyInput& operator>>(std::string& result) {
        if (!good_) return *this;
        int c = skip_space();
        if (c == EOF) return *this;
        result.clear();
        do {
            result.push_back(static_cast<char>(c));
            ++position_;
            c = peek();
        } while (c != EOF && c > ' ');
        return *this;
    }

    template<class T> requires std::is_floating_point_v<T>
    VerifyInput& operator>>(T& result) {
        std::string token;
        *this >> token;
        if (!good_) return *this;
#ifndef SKIP_RUNTIME_CHECKS
        char* end = nullptr;
        const long double value = std::strtold(token.c_str(), &end);
        if (end != token.c_str() + token.size()) good_ = false;
        else result = static_cast<T>(value);
#else
        result = static_cast<T>(std::strtold(token.c_str(), nullptr));
#endif
        return *this;
    }
};

// VerifyOutput(file=stdout): 非所有のFILEへ書く。破棄時にflushし、FILEは閉じない。
// << 整数/char/文字列/浮動小数点: 値を出力する。整数は64bit以下に対応する。
// fixed(digits): 浮動小数点を小数点以下digits桁で出力する（digits>=0）。
// flush(): バッファの内容をFILEへ渡す。bool / !で書き込み失敗を確認できる。
class VerifyOutput {
    static constexpr std::size_t buffer_size = 1 << 17;
    std::FILE* file_;
    std::array<char, buffer_size> buffer_;
    std::size_t size_ = 0;
    int precision_ = 6;
    bool fixed_ = false, good_ = true;

    void write(std::string_view text) {
        while (!text.empty() && good_) {
            if (size_ == buffer_.size()) flush();
            const auto count = std::min(text.size(), buffer_.size() - size_);
            std::memcpy(buffer_.data() + size_, text.data(), count);
            size_ += count;
            text.remove_prefix(count);
        }
    }

public:
    explicit VerifyOutput(std::FILE* file = stdout) : file_(file) {}
    VerifyOutput(const VerifyOutput&) = delete;
    VerifyOutput& operator=(const VerifyOutput&) = delete;
    ~VerifyOutput() { flush(); }

    explicit operator bool() const noexcept { return good_; }
    bool operator!() const noexcept { return !good_; }

    VerifyOutput& fixed(int digits) {
        if (digits < 0) throw std::invalid_argument("negative output precision");
        fixed_ = true;
        precision_ = digits;
        return *this;
    }

    void flush() noexcept {
        std::size_t written = 0;
        while (written < size_ && good_) {
            const auto count = std::fwrite(buffer_.data() + written, 1, size_ - written, file_);
            if (count == 0) good_ = false;
            written += count;
        }
        size_ = 0;
    }

    template<class T>
        requires (std::is_integral_v<T> && sizeof(T) <= sizeof(std::uint64_t)
                  && !std::is_same_v<T, char>)
    VerifyOutput& operator<<(T value) {
        if constexpr (std::is_same_v<T, bool>) return *this << static_cast<char>('0' + value);
        else {
            char digits[std::numeric_limits<std::uint64_t>::digits10 + 3];
            const auto end = std::to_chars(digits, digits + sizeof(digits), value).ptr;
            write(std::string_view(digits, static_cast<std::size_t>(end - digits)));
            return *this;
        }
    }

    VerifyOutput& operator<<(char value) {
        if (size_ == buffer_.size()) flush();
        if (good_) buffer_[size_++] = value;
        return *this;
    }

    VerifyOutput& operator<<(std::string_view value) { write(value); return *this; }
    VerifyOutput& operator<<(const std::string& value) { write(value); return *this; }
    VerifyOutput& operator<<(const char* value) { write(value); return *this; }

    template<class T> requires std::is_floating_point_v<T>
    VerifyOutput& operator<<(T value) {
        char local[128];
        const char* format = fixed_ ? "%.*Lf" : "%.*Lg";
        const int count = std::snprintf(local, sizeof(local), format, precision_,
                                        static_cast<long double>(value));
        if (count < 0) good_ = false;
        else if (static_cast<std::size_t>(count) < sizeof(local))
            write(std::string_view(local, static_cast<std::size_t>(count)));
        else {
            std::vector<char> text(static_cast<std::size_t>(count) + 1);
            std::snprintf(text.data(), text.size(), format, precision_, static_cast<long double>(value));
            write(std::string_view(text.data(), static_cast<std::size_t>(count)));
        }
        return *this;
    }
};

inline VerifyInput verify_in;
inline VerifyOutput verify_out;
#endif

#include <cstdint>
#include <vector>
int main(){
 int n{},q{};verify_in>>n>>q;std::vector<std::int64_t> values(n);for(auto& value:values)verify_in>>value;Graph graph(n);
 for(int i=1;i<n;++i){int u{},v{};verify_in>>u>>v;graph[u].push_back(v);graph[v].push_back(u);}
 HeavyLightDecomposition hld(graph);std::vector<std::int64_t> ordered(n);for(int v=0;v<n;++v)ordered[hld.index(v)]=values[v];FenwickTree<std::int64_t> sums(ordered);
 while(q--){int type{};verify_in>>type;if(type==0){int v{};std::int64_t delta{};verify_in>>v>>delta;sums.add(hld.index(v),delta);}else{int u{},v{};verify_in>>u>>v;std::int64_t answer=0;hld.for_each_path(u,v,[&](int l,int r,bool){answer+=sums.sum(l,r);});verify_out<<answer<<'\n';}}
}
