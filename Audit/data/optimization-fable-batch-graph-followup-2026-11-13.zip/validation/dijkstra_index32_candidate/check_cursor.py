from pathlib import Path
import random,json
rng=random.Random(0xBE61A32);checks=0
# Exhaustive total size for 8-bit analogue; all actual scatter increments, not wrapped models.
for total in range(256):
 for rows in (1,2,3,7,31):
  degrees=[0]*rows
  for i in range(total):degrees[rng.randrange(rows)]+=1
  prefix=[0]
  for d in degrees:prefix.append((prefix[-1]+d)&255)
  assert prefix[-1]==total
  cursor=prefix[:-1].copy();seen=[]
  remaining=degrees.copy();owners=[u for u,d in enumerate(degrees)for _ in range(d)];rng.shuffle(owners)
  for u in owners:
   at=cursor[u];assert at<prefix[u+1]<=total
   seen.append(at);cursor[u]=(cursor[u]+1)&255;remaining[u]-=1
   assert cursor[u]==prefix[u]+degrees[u]-remaining[u];checks+=1
  assert sorted(seen)==list(range(total)) and cursor==prefix[1:]
# 32-bit terminal cursors/prefixes use Python exact integers as independent oracle.
limit=(1<<32)-1
for total in (limit-1,limit):
 for rows in (1,2,3,17):
  cuts=sorted([0,total]+[rng.randrange(total+1)for _ in range(rows-1)])
  prefix=0
  for start,end in zip(cuts,cuts[1:]):
   degree=end-start;prefix=(prefix+degree)&limit;assert prefix==end
   # No need to allocate 2^32 arcs: check first/last representable cursor transitions of each row.
   for consumed in {0,max(0,degree-2),max(0,degree-1)}:
    if consumed==degree:continue
    cursor=start+consumed;assert cursor<end<=total
    next_cursor=(cursor+1)&limit
    assert next_cursor==start+consumed+1 and next_cursor<=end;checks+=1
  assert prefix==total
result={'passed':True,'checks':checks,'exhaustive_8bit_totals':256,'tested_32bit_totals':[limit-1,limit],'actual_max_edge_array_allocated':False,'size_t_fallback':'Forced branch only; see forced_size_t source and test_results.json'}
Path(__file__).with_name('cursor_results.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
