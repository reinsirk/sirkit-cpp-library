from pathlib import Path
import json,subprocess,hashlib,re
w=Path(__file__).resolve().parent
install=Path(subprocess.check_output(['/usr/bin/g++','-print-libgcc-file-name'],text=True).strip()).parent
records=[]
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir='+str(install)])]:
 allsections={}
 for label in ['baseline','candidate']:
  obj=w/label/(cc+'.o');command=['taskset','-c','12',*compiler,'-std=c++23','-O2','-ffunction-sections','-c',str(w/label/'submission.cpp'),'-o',str(obj)]
  result=subprocess.run(command,capture_output=True,text=True);assert result.returncode==0,result.stderr
  headers=subprocess.check_output(['objdump','-h',str(obj)],text=True)
  sections={}
  for line in headers.splitlines():
   row=line.split()
   if len(row)>2 and row[0].isdigit() and row[1].startswith('.text.') and any(name in row[1] for name in ['DijkstraRadixRun','DijkstraRadixFinish','DijkstraBigImpl','DijkstraInitialChain','DijkstraLarge','DijkstraImpl']):
    sections[row[1]]=row[2]
  allsections[label]={}
  for idx,section in enumerate(sorted(sections)):
   dump=w/label/(cc+f'.engine_{idx}.bin')
   subprocess.run(['objcopy','--dump-section',section+'='+str(dump),str(obj)],check=True,capture_output=True)
   allsections[label][section]={'sha256':hashlib.sha256(dump.read_bytes()).hexdigest(),'bytes':dump.stat().st_size}
  (w/label/(cc+'.sections.json')).write_text(json.dumps(allsections[label],indent=2)+'\n')
 matching=set(allsections['baseline'])==set(allsections['candidate'])
 differences=[name for name in allsections['baseline'] if allsections['baseline'][name]!=allsections['candidate'].get(name)]
 row={'compiler':cc,'analysis_flags':'Actual generated flags + CLI O2, adding only -ffunction-sections for section extraction (not timing).','engine_sections':len(allsections['baseline']),'section_names_match':matching,'section_contents_byte_identical':matching and not differences,'different_sections':differences}
 records.append(row);print(cc,row,flush=True)
(w/'engine_results.json').write_text(json.dumps(records,indent=2)+'\n')
