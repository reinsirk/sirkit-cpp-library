# CSR beginのuint32_t境界

候補は構築用のローカルbeginだけをIndex化する。arcs_ / rows_ / engine / API / 検査と検査順は同じ。

m <= UINT32_MAXなら、各次数は[0,m]。次数累積後のbegin[v]は、出発点がv未満の辺数なので[0,m]。前方の非負和は常に総和m以下で、uint32_t加算は溢れない。型の整数昇格が起きる環境でも、uint32_t最大値を表せる加算型かuint32_t自身で計算される。

散布中、頂点uのcursorはstart[u]+その頂点で散布済みの辺数。残り辺を1本処理するときはcursor < end[u] <= mで、実際に参照する添字は最大m-1。後置++後の最大値はmでありm+1ではない。m=UINT32_MAXでも、最後の有効添字UINT32_MAX-1からUINT32_MAXになるだけなので溢れない。begin[n]は全辺数の番兵で、入力端点u<nにより散布時に増分しない。空の行はcursor=endだが、その行からの入力辺がないので増分しない。

n<0とarcs_/rows_のmax_size検査は従来どおり構築器の冒頭で実施する。beginのn+1はsize_tへ変換後に加算し、rows_の容量制約（各行span）によりこの加算の溢れも起きない。begin自身のvector容量検査は従来と同様vectorが行う。uint32_t Indexのベクトル容量上限は64bit size_t版より小さくならない。32bit環境ではuint32_tとsize_tの幅が同じで、既存arcs_容量制約が先に効く。

m > UINT32_MAXではsize_tへフォールバックし、従来と同じbegin演算を使う。実測環境は64bitで、UINT32_MAX本の実辺入力は約64GiBのtuple列だけでも必要になるため生成しない。境界は上の証明と独立cursorモデルで検証し、size_t実装経路はテスト専用に分岐だけを強制したソースで既存独立照合・故障注入を実行する。巨大入力を実行確認済みとは扱わない。
