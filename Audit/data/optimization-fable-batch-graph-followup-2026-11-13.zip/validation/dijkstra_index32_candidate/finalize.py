from pathlib import Path
import json,hashlib,statistics
w=Path(__file__).resolve().parent
provenance=json.loads((w/'provenance.json').read_text());tests=json.loads((w/'test_results.json').read_text());engine=json.loads((w/'engine_results.json').read_text())
rounds=[json.loads((w/name).read_text()) for name in ['benchmark_results.json','benchmark_round2_results.json']]
rows=[]
for cc in ('gcc','clang'):
 for case in ('official_line','random_reachable','dag','dense','star'):
  r=[next(r for r in run['results'] if r['kind']=='timing' and r['compiler']==cc and r['case']==case) for run in rounds]
  rows.append({'compiler':cc,'case':case,'ratios':[x['candidate_ratio'] for x in r],'baseline_ms':[x['median_ns']['baseline']/1e6 for x in r],'candidate_ms':[x['median_ns']['candidate']/1e6 for x in r],'candidate_pair_wins':[x['candidate_pair_wins'] for x in r],'measured_pairs_per_round':7,'output_identical_in_both_rounds':all(x['output_byte_identical'] for x in r)})
report={
 'decision':'reject','adopted':False,'repository_source_modified':False,'fable_invoked':False,
 'reason':'構築用beginの領域半減とDAG/starの小改善はあるが、最大の公式lineではGCCの改善が再現せず、Clangのline/randomは2回とも中央値が約1〜2%遅い。全体時間の安定利益を示せないため採用しない。',
 'cpu':12,'compilers':rounds[0]['compilers'],'flags':rounds[0]['flags'],
 'scope':'同じ現行main・共通I/O・GCC O3 pragma/CLI O2・SKIP_RUNTIME_CHECKSを固定し、構築器内beginのIndexだけを変更。arcs_/rows_/engine/public APIは同一。',
 'source':provenance,
 'tests':{'all_passed':all(r['passed'] for r in tests),'configurations':len(tests),'description':'候補および分岐だけをsize_tへ強制したテスト専用版。各GCC15.2/Clang21×checked/skipで171グラフのBellman-Ford/heap・全距離・経路・旧API・入力不変・境界/例外検査と、確保失敗注入を実行。','allocation_failures_before_success':{r['label']+'/'+r['compiler']+'/'+r['mode']:r['stdout'].strip() for r in tests if r['kind']=='allocation'},'results':str(w/'test_results.json')},
 'boundary':{'proof':str(w/'boundary.md'),'model_results':json.loads((w/'cursor_results.json').read_text()),'real_UINT32_MAX_edge_input_run':False,'inclusive_limit_is_safe':'各prefix <= m。散布前cursor < row_end <= m、後置++後は最大m。m=UINT32_MAXでもm+1にはならない。番兵begin[n]は増分しない。'},
 'engine_machine_code':engine,
 'measurement_summary':rows,
 'uncertainty':'公式lineの絶対時間はround間で大きく変動。2warm+7交互を開始順逆転で2回行い、他入力も保持した。都合のよい初回GCC line値だけを採用根拠にしない。',
 'reproduction_files':{name:str(w/name)for name in ('prepare.py','candidate.patch','test.py','benchmark.py','benchmark_round2.py','check_engine.py','check_cursor.py')},
 'baseline_body_still_current':provenance['baseline_body_sha256']==hashlib.sha256(Path('/home/reinsirk/Atcoder_Env/Graph/Dijkstra.cpp').read_bytes()).hexdigest(),
 'progress_files_edited':False,
}
(w/'final_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
lines=['# Dijkstra begin32候補：不採用','','構築用beginだけをuint32_t/size_tに切り替えた。m<=UINT32_MAXを含む境界は安全だが、全体時間の安定利益を確認できなかった。repo変更なし。','', '| compiler | input | round1比 | round2比 |','| --- | --- | ---: | ---: |']
for r in rows:lines.append(f"| {r['compiler']} | {r['case']} | {r['ratios'][0]:.4f} | {r['ratios'][1]:.4f} |")
lines+=['','比は候補/現行、CPU12、CLI O2と現行生成GCC O3 pragma、同じmain/共通I/O。各roundは2warm+7交互、round2は開始順を反転。出力は全件bytes一致。','', '候補とsize_t強制経路はそれぞれGCC15.2/Clang21×checked/skipで独立Bellman/heapと故障注入がPASS（計16構成）。live_delta=0。機械語はGCC14節・Clang10節のengine関数sectionが一致（分析時のみ-ffunction-sections追加）。','', 'UINT32_MAX本の巨大配列は生成していない。boundary.mdの数学的証明、0..255を全走査する8bit縮小モデルとUINT32_MAX-1/MAXの端部cursorモデルで境界を補足。','', '公式lineの絶対時間がround間で変動し、GCC初回の改善は再現しなかった。Clang line/randomは中央値が両roundで悪化した。beginの理論使用量は64bit環境で8(N+1)→4(N+1) bytesだが、RSS改善を実測したとは扱わない。','']
(w/'summary.md').write_text('\n'.join(lines))
print(json.dumps({'decision':report['decision'],'tests_passed':report['tests']['all_passed'],'configurations':len(tests),'baseline_body_still_current':report['baseline_body_still_current'],'report':str(w/'final_report.json')},indent=2))
