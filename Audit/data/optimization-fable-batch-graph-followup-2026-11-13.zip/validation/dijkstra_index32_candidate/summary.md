# Dijkstra begin32候補：不採用

構築用beginだけをuint32_t/size_tに切り替えた。m<=UINT32_MAXを含む境界は安全だが、全体時間の安定利益を確認できなかった。repo変更なし。

| compiler | input | round1比 | round2比 |
| --- | --- | ---: | ---: |
| gcc | official_line | 0.9612 | 1.0130 |
| gcc | random_reachable | 0.9836 | 1.0117 |
| gcc | dag | 0.9746 | 0.9714 |
| gcc | dense | 0.9994 | 0.9730 |
| gcc | star | 0.9475 | 0.9816 |
| clang | official_line | 1.0217 | 1.0181 |
| clang | random_reachable | 1.0130 | 1.0198 |
| clang | dag | 0.9686 | 0.9863 |
| clang | dense | 1.0001 | 1.0038 |
| clang | star | 0.9801 | 0.9715 |

比は候補/現行、CPU12、CLI O2と現行生成GCC O3 pragma、同じmain/共通I/O。各roundは2warm+7交互、round2は開始順を反転。出力は全件bytes一致。

候補とsize_t強制経路はそれぞれGCC15.2/Clang21×checked/skipで独立Bellman/heapと故障注入がPASS（計16構成）。live_delta=0。機械語はGCC14節・Clang10節のengine関数sectionが一致（分析時のみ-ffunction-sections追加）。

UINT32_MAX本の巨大配列は生成していない。boundary.mdの数学的証明、0..255を全走査する8bit縮小モデルとUINT32_MAX-1/MAXの端部cursorモデルで境界を補足。

公式lineの絶対時間がround間で変動し、GCC初回の改善は再現しなかった。Clang line/randomは中央値が両roundで悪化した。beginの理論使用量は64bit環境で8(N+1)→4(N+1) bytesだが、RSS改善を実測したとは扱わない。
