from pathlib import Path
import subprocess,hashlib,json,time
w=Path(__file__).resolve().parent
install=Path(subprocess.check_output(['/usr/bin/g++','-print-libgcc-file-name'],text=True).strip()).parent
records=[]
for label in ['candidate','forced_size_t']:
 for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir='+str(install)])]:
  for mode,flags in [('checked',[]),('skip',['-DSKIP_RUNTIME_CHECKS'])]:
   for kind in ['reference','allocation']:
    src=w/label/'tests'/f'{kind}.cpp';exe=w/label/'tests'/f'{cc}-{mode}-{kind}'
    cmd=['taskset','-c','12',*compiler,'-std=c++23','-O2','-Wall','-Wextra',*flags,str(src),'-o',str(exe)]
    started=time.perf_counter();build=subprocess.run(cmd,capture_output=True,text=True);assert build.returncode==0,build.stderr
    result=subprocess.run(['taskset','-c','12',str(exe)],capture_output=True,text=True,timeout=30)
    row={'label':label,'compiler':cc,'mode':mode,'kind':kind,'command':cmd,'elapsed_seconds':time.perf_counter()-started,'stdout':result.stdout,'stderr':result.stderr,'compile_diagnostics':build.stderr,'passed':result.returncode==0}
    records.append(row);(w/'test_results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label,cc,mode,kind,result.stdout.strip(),flush=True);assert result.returncode==0,result.stderr
