from pathlib import Path
import subprocess,hashlib,json,time,statistics,shutil
w=Path(__file__).resolve().parent;p=w.parent/'other_lc'
install=Path(subprocess.check_output(['/usr/bin/g++','-print-libgcc-file-name'],text=True).strip()).parent
cases=[('official_line',p/'official_generator/line_00.in'),('random_reachable',p/'dijkstra/random_reachable.in'),('dag',p/'dijkstra/dag.in'),('dense',p/'dijkstra_flags/dense.in'),('star',p/'dijkstra/star.in')]
records=[];meta={'cpu':12,'flags':'CLI C++23 O2; identical actual generated GCC pragma, SKIP_RUNTIME_CHECKS, main and shared fast I/O retained. 2 warm + 7 strict alternating measured pairs per input/compiler. Same executable pathname for each variant.','compilers':{},'results':records}
def save():(w/'benchmark_results.json').write_text(json.dumps(meta,indent=2)+'\n')
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir='+str(install)])]:
 meta['compilers'][cc]=subprocess.check_output([compiler[0],'--version'],text=True).splitlines()[0]
 bins={}
 for label in ['baseline','candidate']:
  src=w/label/'submission.cpp';exe=w/label/cc;cmd=['taskset','-c','12',*compiler,'-std=c++23','-O2',str(src),'-o',str(exe)]
  result=subprocess.run(cmd,capture_output=True,text=True);assert result.returncode==0,result.stderr;bins[label]=exe
  records.append({'kind':'build','compiler':cc,'label':label,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'passed':True,'diagnostics':result.stderr});save()
 for case,inp in cases:
  outputs={}
  for label,exe in bins.items():
   with inp.open('rb') as fi:result=subprocess.run(['taskset','-c','12',str(exe)],stdin=fi,capture_output=True)
   assert result.returncode==0,result.stderr;outputs[label]=result.stdout
  assert outputs['candidate']==outputs['baseline'],(cc,case,'output mismatch')
  raw={label:[] for label in bins}
  for rep in range(9):
   order=['baseline','candidate'] if rep%2==0 else ['candidate','baseline']
   for label in order:
    active=w/'active';shutil.copyfile(bins[label],active);active.chmod(0o755)
    with inp.open('rb') as fi,open('/dev/null','wb') as fo:
     start=time.perf_counter_ns();result=subprocess.run(['taskset','-c','12',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
    assert result.returncode==0,result.stderr
    if rep>=2:raw[label].append(elapsed)
  med={k:statistics.median(v) for k,v in raw.items()}
  row={'kind':'timing','compiler':cc,'case':case,'input':str(inp),'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'shape':inp.open().readline().strip(),'output_byte_identical':True,'output_sha256':hashlib.sha256(outputs['baseline']).hexdigest(),'raw_ns':raw,'median_ns':med,'candidate_ratio':med['candidate']/med['baseline'],'paired_median_ratio':statistics.median(b/a for a,b in zip(raw['baseline'],raw['candidate'])),'candidate_pair_wins':sum(b<a for a,b in zip(raw['baseline'],raw['candidate']))}
  records.append(row);save();print(cc,case,{k:round(v/1e6,3) for k,v in med.items()},'ratio',round(row['candidate_ratio'],4),'wins',row['candidate_pair_wins'],flush=True)
