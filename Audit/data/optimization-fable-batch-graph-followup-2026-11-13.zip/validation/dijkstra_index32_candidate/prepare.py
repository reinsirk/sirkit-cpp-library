from pathlib import Path
import hashlib,json,sys,difflib
root=Path('/home/reinsirk/Atcoder_Env');w=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'Scripts'));import prepare_verify as pv
baseline=(root/'Graph/Dijkstra.cpp').read_text()
start=baseline.index('public:\n    DijkstraCsrGraph(');end=baseline.index('    DijkstraCsrGraph(const DijkstraCsrGraph&)',start)
old=baseline[start:end]
head,body=old.split('        std::vector<std::size_t> begin',1)
checks=head[head.index('        if(n<0)'):]
new='''    template<class Index>
    void build(int n, std::span<const std::tuple<int,int,std::int64_t>> input) {
        std::vector<Index> begin'''+body+'''public:
    DijkstraCsrGraph(int n, std::span<const std::tuple<int,int,std::int64_t>> input) {
'''+checks+'''        if (input.size() <= std::numeric_limits<std::uint32_t>::max())
            build<std::uint32_t>(n, input);
        else
            build<std::size_t>(n, input);
    }
'''
candidate=baseline[:start]+new+baseline[end:]
forced=candidate.replace('input.size() <= std::numeric_limits<std::uint32_t>::max()', 'false /* test-only forced size_t fallback */')
for label,body in [('baseline',baseline),('candidate',candidate),('forced_size_t',forced)]:
 p=w/label/'Graph/Dijkstra.cpp';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(body)
assert baseline[end:]==candidate[candidate.index('    DijkstraCsrGraph(const DijkstraCsrGraph&)'):]
(w/'candidate.patch').write_text(''.join(difflib.unified_diff(baseline.splitlines(True),candidate.splitlines(True),fromfile='baseline/Graph/Dijkstra.cpp',tofile='candidate/Graph/Dijkstra.cpp')))
entry=next(e for e in pv.collect() if e['id']=='dijkstra')
for label in ['baseline','candidate']:
 body=(w/label/'Graph/Dijkstra.cpp').read_bytes();source,_=pv.render(entry,source_overrides={'Graph/Dijkstra.cpp':body})
 (w/label/'submission.cpp').write_bytes(source)
repo_test=(root/'Verify/current/tests/dijkstra_bulk_test.cpp').read_text()
fault=(w.parent/'other_lc/dijkstra_bulk_candidate/tests/allocation.cpp').read_text()
for label in ['baseline','candidate','forced_size_t']:
 tests=w/label/'tests';tests.mkdir(exist_ok=True)
 (tests/'reference.cpp').write_text(repo_test.replace('#include SIRKIT_DIJKSTRA_TEST_SOURCE','#include "../Graph/Dijkstra.cpp"'))
 (tests/'allocation.cpp').write_text(fault)
record={'candidate_body_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'baseline_body_sha256':hashlib.sha256(baseline.encode()).hexdigest(),'body_outside_constructor_byte_identical':True,'driver_sha256':hashlib.sha256((root/entry['driver']).read_bytes()).hexdigest(),'common_io_sha256':hashlib.sha256((root/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest(),'entry':entry,'source_sha256':{k:hashlib.sha256((w/k/'submission.cpp').read_bytes()).hexdigest() for k in ['baseline','candidate']}}
(w/'provenance.json').write_text(json.dumps(record,indent=2)+'\n')
