// SPDX-License-Identifier: CC0-1.0
#ifndef SIRKIT_SCC_TEST_SOURCE
#define SIRKIT_SCC_TEST_SOURCE "../../../Graph/SCC.cpp"
#endif
#include SIRKIT_SCC_TEST_SOURCE
#include <algorithm>
#include <cinttypes>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <random>
#include <utility>
#include <vector>

namespace {
using Edges = std::vector<std::pair<int, int>>;
using Result = std::pair<int, std::vector<int>>;
std::uint64_t checks = 0, graphs = 0;
void check(bool ok) { ++checks; if (!ok) std::abort(); }

// low-linkを使わない2回のDFSによる独立参照。
Result reference(int n, const Edges& edges) {
    Graph forward(n), reverse(n);
    for (auto [u, v] : edges) { forward[u].push_back(v); reverse[v].push_back(u); }
    std::vector<unsigned char> seen(n);
    std::vector<int> finish;
    std::vector<std::pair<int, std::size_t>> frames;
    for (int root = 0; root < n; ++root) {
        if (seen[root]) continue;
        seen[root] = 1;
        frames.emplace_back(root, 0);
        while (!frames.empty()) {
            auto& [v, next] = frames.back();
            if (next == forward[v].size()) {
                finish.push_back(v); frames.pop_back();
            } else {
                const int u = forward[v][next++];
                if (!seen[u]) { seen[u] = 1; frames.emplace_back(u, 0); }
            }
        }
    }
    std::vector<int> ids(n, -1), pending;
    int count = 0;
    for (auto it = finish.rbegin(); it != finish.rend(); ++it) {
        if (ids[*it] != -1) continue;
        ids[*it] = count; pending.push_back(*it);
        while (!pending.empty()) {
            const int v = pending.back(); pending.pop_back();
            for (int u : reverse[v]) if (ids[u] == -1) {
                ids[u] = count; pending.push_back(u);
            }
        }
        ++count;
    }
    return {count, std::move(ids)};
}

Result verify(int n, const Edges& edges) {
    const auto narrow = reinsirk::detail::directed_component_ids_index<std::uint32_t>(n, edges);
    const auto wide = reinsirk::detail::directed_component_ids_index<std::size_t>(n, edges);
    const auto selected = reinsirk::detail::directed_component_ids(n, edges);
    check(narrow == wide);
    check(narrow == selected);
    check(narrow.second.size() == static_cast<std::size_t>(n));
    const auto expected = reference(n, edges);
    check(narrow.first == expected.first);
    std::vector<int> expected_to_actual(expected.first, -1), actual_to_expected(expected.first, -1);
    for (int v = 0; v < n; ++v) {
        const int id = narrow.second[v], ref = expected.second[v];
        check(0 <= id && id < narrow.first);
        if (expected_to_actual[ref] == -1) expected_to_actual[ref] = id;
        if (actual_to_expected[id] == -1) actual_to_expected[id] = ref;
        check(expected_to_actual[ref] == id && actual_to_expected[id] == ref);
    }
    for (auto [u, v] : edges)
        check(narrow.second[u] == narrow.second[v] || narrow.second[u] < narrow.second[v]);
    if (n <= 12) {
        auto reach = std::vector(n, std::vector<bool>(n));
        for (int v = 0; v < n; ++v) reach[v][v] = true;
        for (auto [u, v] : edges) reach[u][v] = true;
        for (int k = 0; k < n; ++k)
            for (int u = 0; u < n; ++u)
                for (int v = 0; v < n; ++v)
                    reach[u][v] = reach[u][v] || (reach[u][k] && reach[k][v]);
        for (int u = 0; u < n; ++u)
            for (int v = 0; v < n; ++v)
                check((narrow.second[u] == narrow.second[v]) == (reach[u][v] && reach[v][u]));
    }
    ++graphs;
    return narrow;
}
}

static_assert(~0 == -1);
static_assert(~(std::numeric_limits<int>::max()-1) == -std::numeric_limits<int>::max());
static_assert(-std::numeric_limits<int>::max() > std::numeric_limits<int>::min());
int main() {
    for (int n : {1, 2, 3, 100000}) {
        for (int shape = 0; shape < 4; ++shape) {
            Edges edges; edges.reserve(n);
            for (int v = 0; v < n; ++v) {
                const int to = shape == 0 ? v :
                    shape == 1 ? (v ^ 1) < n ? (v ^ 1) : v :
                    shape == 2 ? v == n-1 ? v : v+1 :
                    v == n-1 ? n/2 : v+1;
                edges.emplace_back(v,to);
            }
            verify(n, edges);
        }
    }
    std::printf("SCC explicit functional shapes graphs=%" PRIu64 " checks=%" PRIu64 "\n", graphs, checks);
}
