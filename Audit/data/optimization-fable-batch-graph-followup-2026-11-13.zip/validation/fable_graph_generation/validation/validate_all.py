from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/fable_graph_generation/validation');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');report={'format':1,'status':'running','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'targets':['lca','scc'],'root_sources_before':{p:sha(R/p)for p in ['Graph/LCA.cpp','Graph/SCC.cpp','Verify/current/drivers/lca_main.cpp','Verify/current/drivers/scc_main.cpp','Verify/current/common/fast_io.hpp']},'runs':[],'repo_generated':False,'fable_called':False,'dijkstra_retested':False,'large_independent_fixtures_repeated':False}
def save():(W/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
save()
for ident in ['lca','scc']:
 script=W/ident/'validate.py';log=W/ident/'runner.log'
 with log.open('w')as file:
  process=subprocess.Popen([sys.executable,str(script)],cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  for line in process.stdout:file.write(line);file.flush();print(ident+': '+line,end='',flush=True)
  code=process.wait()
 assert code==0,(ident,code,str(log));child=json.loads((W/ident/'results.json').read_text());assert child['status']=='passed';report['runs'].append({'id':ident,'report':str(W/ident/'results.json'),'status':child['status'],'build_configurations':child['total_build_configurations'],'sample_executions':child['total_sample_executions'],'root_sources_unchanged':child['root_sources_unchanged']});save()
 if ident=='scc':subprocess.run([sys.executable,str(W/'scc/freeze_normal.py')],cwd=R,env=env,check=True)
 else:
  entries={e['id']:e for e in json.loads((R/'Verify/current/manifest.json').read_text())['entries']};rows=[r for run in child['normal']for r in json.loads(Path(run['result']).read_text())['results']];child['frozen_normal_sources']=[]
  for name in ['lca','lca_local']:
   for skip in [False,True]:
    data,_=pv.render(entries[name],skip_runtime_checks=skip);digest=hashlib.sha256(data).hexdigest();assert {r['tested_source_sha256']for r in rows if r['id']==name and r['skip_runtime_checks']==skip}=={digest};p=W/ident/'sources'/(name+('_skip'if skip else'_checked')+'.cpp');p.write_bytes(data);child['frozen_normal_sources'].append({'id':name,'skip_runtime_checks':skip,'source':str(p),'sha256':digest})
  child['tool_hashes']={p:sha(R/p)for p in ['Scripts/prepare_verify.py','Scripts/ci_verify.py','Scripts/prepare_variant_verify.py']};(W/ident/'results.json').write_text(json.dumps(child,ensure_ascii=False,indent=2)+'\n')
report['root_sources_after']={p:sha(R/p)for p in report['root_sources_before']};assert report['root_sources_after']==report['root_sources_before'];report['total_build_configurations']=sum(r['build_configurations']for r in report['runs']);report['total_sample_executions']=sum(r['sample_executions']for r in report['runs']);assert report['total_build_configurations']==56 and report['total_sample_executions']==56;report['primary_lca_scc_configurations']=40;report['local_supplement_configurations']=16;report['local_notes']='lca_local exists; no SCC local manifest entry exists, so the existing SCC-only ACL API fixture is used as an equivalent (n<=28), 8 configurations each.';report['status']='passed';report['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print('FINAL PASS 40 primary +16 local configurations, 56 total sample executions',flush=True)
