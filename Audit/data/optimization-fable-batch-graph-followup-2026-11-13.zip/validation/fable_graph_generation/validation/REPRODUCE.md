# Fable Graph候補採用後の限定検証

対象はLCA offsets-only（e7f26…）とSCC fused（357d6…）。
Dijkstraおよび大規模独立fixtureは再実行しない。repo・ZIP・オンライン記録は変更しない。

LCA/SCCはそれぞれ通常8構成、Variants8構成、Fast4構成、計40構成。
通常/VariantsはGCC15.2・Clang21のchecked/skip×通常/標準fallback。
Fastは生成時に本体検査が除去済みなので、各compilerのskip×通常/標準fallbackのみ。
追加でlca_local 8構成と、SCC local相当8構成を確認し、計56構成とする。

p.collect()にSCC local entryは存在しないため、前回と同様に既存SCC-only ACL API fixtureを使う。
このfixtureはn≤28で、到達可能性参照、API型、scc/build/ids、辺追加後の再構築、返却値の独立性、コピー/ムーブを照合する。
TwoSATと30万頂点のfixtureは対象外。

通常版はci_verifyの明示IDで検証。rootが同期済みなのでpackage同期確認だけを省き、prepare(check=True)は残す。
派生はprofile manifestの対象IDだけを取り出し、skip生成全文のbyte一致を確認して凍結。
checkedは同じprofile body/driverから再renderする。sampleは現在のmatcherで照合する。

- `results.json`: 2件の統合結果、総数、開始/終了、body/driver/IOの前後SHA。
- `lca/results.json` / `scc/results.json`: compiler、各compile/run command、source SHA、diagnostics、sample結果。
- 各 `raw/`: ci結果と派生/localの診断・stdout。
- 各 `sources/`: 実際に検証したnormal/checked/skip/profile全文。
- 各 `runner.log`: 元の検証ログ。

再現:
`PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/fable_graph_generation/validation/validate_all.py`

CPU10に固定して順次実行する。結果はローカル照合であり、オンラインACを意味しない。
