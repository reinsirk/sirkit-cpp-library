from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/fable_graph_generation/validation/scc');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
os.sched_setaffinity(0,{10});sha=lambda d:hashlib.sha256(d).hexdigest();env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');report={'format':1,'id':'scc','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','repo_generated':False,'online_status':'not_evaluated','cpu':10,'normal':[],'profiles':[],'notes':['Normal uses ci_verify --id scc --skip-sync; root already completed generation sync. prepare(check=True) remains enabled in ci_verify.','Variants checked sources are rendered from the same frozen profile body and driver with SKIP_RUNTIME_CHECKS disabled. Fast body checks were removed by generation: only valid-input skip contract tested.','Profile compile/sample implementation follows existing profile_flags_validation/validate.py; extends checked/fallback modes, freezes selected scc sources only.']}
for n in ['sources','bin','raw']:(W/n).mkdir(exist_ok=True)
compilers={'GCC':['/usr/bin/g++'],'Clang':['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']};report['compilers']={k:subprocess.check_output([v[0],'--version'],text=True).splitlines()[0]for k,v in compilers.items()};assert '15.2.0' in report['compilers']['GCC'];assert '21.' in report['compilers']['Clang']
watched=['Verify/current/manifest.json','Variants/verify_manifest.json','Graph/SCC.cpp','Verify/current/drivers/scc_main.cpp','Verify/current/common/fast_io.hpp','Verify/current/submissions/scc.cpp'];report['root_hashes_before']={p:sha((R/p).read_bytes())for p in watched}
def save():(W/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
save()
for name,command in compilers.items():
 for fallback in [False,True]:
  output=W/'raw'/f'normal_{name}_{fallback}.json';cmd=[sys.executable,str(R/'Scripts/ci_verify.py'),'--id','scc','--skip-sync','--compiler',command[0],'--results',str(output)]
  if fallback:cmd+=['--fallback']
  t=time.monotonic();p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=600);row={'compiler':name,'fallback':fallback,'command':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.monotonic()-t,'result':str(output),'passed':p.returncode==0};report['normal'].append(row);save();print('normal',name,'fallback',fallback,'PASS'if row['passed']else'FAIL',p.stdout.strip(),flush=True)
  assert row['passed'],p.stderr
entries={e['id']:e for e in pv.collect()};entry=entries['scc'];profiles=[x for x in json.loads((R/'Variants/verify_manifest.json').read_text())['entries']if x['id']=='scc'];assert len(profiles)==4
report['profile_snapshot']=profiles
for item in profiles:
 profile=('Fast/'if item['fast']else'Variants/')+item['compiler'];libraries={k:(R/v).read_bytes()for k,v in item['source_paths'].items()};driver=(R/item['driver']).read_text();root=(R/item['path']).read_bytes();assert sha(root)==item['sha256'];report['root_hashes_before'][item['path']]=sha(root)
 for skip in ([True]if item['fast']else[False,True]):
  source,_=pv.render({**entry,'submission_urls':item.get('submission_urls',[])},source_overrides=libraries,driver_override=driver,skip_runtime_checks=skip)
  lines=source.decode().splitlines(keepends=True);lines.insert(1 if lines[0].startswith('#define SKIP_RUNTIME_CHECKS')else 0,'// Profile: '+profile+'; online judgement is recorded separately.\n');source=''.join(lines).encode()
  if skip:assert source==root,(profile,'render mismatch')
  else:assert not source.startswith(b'#define SKIP_RUNTIME_CHECKS')
  for fallback in [False,True]:
   label=profile.replace('/','_')+('_skip'if skip else'_checked')+('_fallback'if fallback else'_default');src=W/'sources'/(label+'.cpp');src.write_bytes(source);exe=W/'bin'/label;cmd=[*compilers[item['compiler']],'-std=c++23','-O2','-Wall','-Wextra']
   if fallback:cmd+=['-U__SIZEOF_INT128__','-DSIRKIT_FORCE_STANDARD_ARITHMETIC','-DSIRKIT_LINE_CONTAINER_FORCE_PORTABLE','-DSIRKIT_DISABLE_SIMD']
   cmd += [str(src),'-o',str(exe)];t=time.monotonic();p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=180);row={'profile':profile,'compiler':item['compiler'],'skip_runtime_checks':skip,'fast_unchecked_contract':item['fast'],'standard_fallback':fallback,'source':str(src),'source_sha256':sha(source),'generated_source_sha256':item['sha256'],'command':cmd,'compile_returncode':p.returncode,'compile_stdout':p.stdout,'compile_stderr':p.stderr,'compile_seconds':time.monotonic()-t,'samples':[]}
   if p.returncode==0:
    for i,sample in enumerate(entry['samples']):
     p=subprocess.run([str(exe)],input=sample['input'],text=True,capture_output=True,timeout=60,env=env);passed=p.returncode==0 and pv.matches(entry,sample,p.stdout);row['samples'].append({'index':i,'input':sample['input'],'expected':sample['output'],'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'sample_checker':entry.get('sample_checker','tokens'),'passed':passed})
   row['passed']=row['compile_returncode']==0 and len(row['samples'])==len(entry['samples']) and all(s['passed']for s in row['samples']);(W/'raw'/(label+'.json')).write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n');report['profiles'].append(row);save();print(label,'PASS'if row['passed']else'FAIL',flush=True);assert row['passed'],row

report['local_equivalent']=[]
report['local_id_lookup']='p.collect() contains only scc for Graph/SCC.cpp; no local SCC entry exists. Existing SCC-only ACL API fixture is used as the local equivalent.'
local_source=(R/'Verify/current/tests/scc_acl_api_test.cpp').read_text()
local_source=local_source.replace('#define SIRKIT_SCC_TEST_SOURCE "../../../Graph/SCC.cpp"','#define SIRKIT_SCC_TEST_SOURCE "scc_library.cpp"')
local_path=W/'sources'/'scc_acl_api_local.cpp';local_path.write_text(local_source)
library_path=W/'sources'/'scc_library.cpp';library_path.write_bytes((R/'Graph/SCC.cpp').read_bytes())
expected_stdout=None
for name,prefix in compilers.items():
 for skip in [False,True]:
  for fallback in [False,True]:
   label=f'local_{name}_{skip}_{fallback}';exe=W/'bin'/label;cmd=[*prefix,'-std=c++23','-O2','-Wall','-Wextra']
   if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
   if fallback:cmd+=['-U__SIZEOF_INT128__','-DSIRKIT_FORCE_STANDARD_ARITHMETIC','-DSIRKIT_LINE_CONTAINER_FORCE_PORTABLE','-DSIRKIT_DISABLE_SIMD']
   cmd += [str(local_path),'-o',str(exe)];t=time.monotonic();p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=180);row={'id':'scc_acl_api_local_equivalent','compiler':name,'skip_runtime_checks':skip,'standard_fallback':fallback,'fixture':'Verify/current/tests/scc_acl_api_test.cpp','source_path':str(local_path),'fixture_sha256':sha(local_source.encode()),'library_path':str(library_path),'library_sha256':sha(library_path.read_bytes()),'command':cmd,'compile_returncode':p.returncode,'diagnostics':p.stderr,'compile_seconds':time.monotonic()-t,'samples':[]}
   if p.returncode==0:
    t=time.monotonic();p=subprocess.run([str(exe)],capture_output=True,text=True,timeout=60,env=env);expected_stdout=p.stdout if expected_stdout is None else expected_stdout;passed=p.returncode==0 and p.stdout==expected_stdout and p.stdout.startswith('SCC ACL API checks=');row['samples']=[{'passed':passed,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.monotonic()-t,'checker':'fixture-independent-reachability-checks-and-identical-check-count'}]
   row['passed']=row['compile_returncode']==0 and bool(row['samples'])and all(x['passed']for x in row['samples']);report['local_equivalent'].append(row);(W/'raw'/(label+'.json')).write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n');save();print(label,'PASS'if row['passed']else'FAIL',row['samples'][0]['stdout'].strip()if row['samples']else row['diagnostics'][:200],flush=True);assert row['passed'],row

report['root_hashes_after']={p:sha((R/p).read_bytes())for p in report['root_hashes_before']};report['root_sources_unchanged']=report['root_hashes_before']==report['root_hashes_after'];assert report['root_sources_unchanged'];report['status']='passed';report['normal_build_configurations']=sum(len(json.loads(Path(r['result']).read_text())['results'])for r in report['normal']);report['profile_build_configurations']=len(report['profiles']);report['local_equivalent_build_configurations']=len(report['local_equivalent']);report['total_build_configurations']=report['normal_build_configurations']+report['profile_build_configurations']+report['local_equivalent_build_configurations'];report['total_sample_executions']=sum(len(c['samples'])for r in report['normal']for c in json.loads(Path(r['result']).read_text())['results'])+sum(len(r['samples'])for r in report['profiles'])+sum(len(r['samples'])for r in report['local_equivalent']);report['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print('FINAL PASS',report['total_build_configurations'],'build configurations',report['total_sample_executions'],'samples',flush=True)
