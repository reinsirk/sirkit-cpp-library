# LCA offsets-only CSR検討

結論: 採用推奨。rootがdiff確認・採用・同期・再Verifyを行う。この作業ではrepo/Fableを操作していない。

候補は `candidate_library.cpp`、差分は `library.diff`、統合結果は `review.json`。
現repoのspan行CSRをbaselineへ凍結し、LcaCsrGraphの内部だけを変更した。
public API、ヘルパー外の本体bytes、main、共通I/O、現在O3設定は同一。

## 変更と安全性

- rows_のvector<span<const int>>を削除し、begin_のvector<size_t>(N+2)で行を表す。
- 次数をbegin_[u+2]へ数え、prefix後のbegin_[u+1]をscatter cursorにする。
- 各cursorはその頂点の次数だけ進むため、散布後に行vは[begin_[v],begin_[v+1])になる。
- N=0はbegin_が2要素、arcsは最低1要素で所有し、size()==0。空のspanにも安全なpointerを使う。
- N+2、2M、pointer差分の上限を確保・倍増前に検査。負nは常にlength_error。
- checkedは全端点をindex計算前に検査し、既存の根・閉路・多重辺検査と例外種別を保持。
- 所有はunique_ptr/vector、非所有のspan行は内部の一時参照のみ。コピー/共有契約は不変。

## 検証

`test_results.json`: GCC15.2/Clang21 checked/skip/標準fallback等20構成、367,292,224項目PASS。
旧Graph APIと辺列APIの全照会、森、任意根、小森全列挙、30万頂点3形状、深い分岐66ケースを含む。

`extra_results.json`: 直接CSR/全API/例外型対照4構成、確保失敗4構成、Clang ASan+UBSan2構成がPASS。
直接対照は行の内容・順序まで現行CSRと一致を確認し、old Graph APIとの全API snapshotも比較した。
不正根/端点/自己辺/多重辺/閉路の例外型と、失敗後の元・コピーの保持を照合。
確保失敗点は各44→40、live allocation差0。浅い森・深い鎖のconstructor/buildを注入した。

## 同条件の全体測定

CPU10、C++23 -O2 -Wall -Wextra、現在のGCC O3 pragmaを維持。Clangはpragmaを無視。
同じ入力・main・I/Oで2 warmup+9回ずつ順序を交互にした。
公式4入力は入力/出力SHAが公式hashと一致。starの全出力は独立モデル、smallも独立期待値と一致した。

|入力|GCC 候補/現行|Clang 候補/現行|
|---|---:|---:|
|max_random_01|.824|.927|
|max_line_00|.965|.911|
|binary_00|.877|.936|
|almost_line_01|.941|.911|
|path N=Q=500000|.943|.919|
|star N=Q=500000|.908|.930|

全ての大入力で改善し、peak RSSは約3.8MiB減った。
前処理中の16N byteの行spanが約8N byteのoffsetへ替わる。旧版の一時offsetは既に解放済みなので、
実際のpeak差は約8N byteであり、16N byteとはしない。
smallのGCC+6µs/Clang-10µsは起動時間内の差で、速度改善とは主張しない。
全体時間の測定であり、照会単体や構築単体の時間短縮は切り出していない。

## 原データと再現

`sources.json`にbody/main/IO/全文SHA、`results.json`に全測定値・出力SHA・RSS、`rss/`に個別RSSを保存。
公式inputは前回の凍結ファイル、starの入力/独立期待値はinputs/へ保存した。全path/hashはJSONに記録。

```sh
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/lca_offsets_candidate/test.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/lca_offsets_candidate/test_extra.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/lca_offsets_candidate/benchmark.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/lca_offsets_candidate/finalize.py
```

CPU10で他の計時と同時実行しない。初回rawを残す場合は再実行前にresultsを別名へ保存する。
prepare.pyは現repoをbaselineとして作り直すため、親の採用後には実行せず凍結済みsourceを使う。
