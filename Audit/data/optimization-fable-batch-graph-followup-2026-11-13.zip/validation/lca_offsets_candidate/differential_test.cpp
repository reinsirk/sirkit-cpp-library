#define LCA BaselineLCA
#define LcaCsrGraph BaselineCsrGraph
#include "baseline_library.cpp"
#undef LCA
#undef LcaCsrGraph
#undef SIRKIT_LCA_DEFINED
#undef SIRKIT_LCA_CSR_GRAPH_DEFINED
#define LCA OffsetLCA
#define LcaCsrGraph OffsetCsrGraph
#include "candidate_library.cpp"
#undef LCA
#undef LcaCsrGraph
#include <cstdio>
#include <cstdlib>
#include <numeric>
#include <random>
#include <type_traits>
using Edges=std::vector<std::pair<int,int>>;
using Graph=std::vector<std::vector<int>>;
std::uint64_t checks=0;
void check(bool ok){++checks;if(!ok)std::abort();}
enum class Result{ok,length,range,invalid,other};
template<class F>Result classification(F f){try{f();return Result::ok;}catch(const std::length_error&){return Result::length;}catch(const std::out_of_range&){return Result::range;}catch(const std::invalid_argument&){return Result::invalid;}catch(...){return Result::other;}}
template<class Tree>std::vector<int> snapshot(const Tree&t){std::vector<int> out{static_cast<int>(t.size()),t.root(),static_cast<int>(t.component_count())};for(int v=0;v<static_cast<int>(t.size());++v){out.insert(out.end(),{t.parent(v),t.depth_of(v),t.component_of(v),t.root_of(v),t.order_index(v),t.subtree_size(v)});auto[a,b]=t.subtree_range(v);out.insert(out.end(),{a,b});for(int u=0;u<static_cast<int>(t.size());++u){out.insert(out.end(),{t.get(u,v),t.get_distance(u,v),static_cast<int>(t.is_ancestor(u,v)),t.kth_on_path(u,v,0),t.kth_on_path(u,v,UINT64_MAX)});for(int r=0;r<static_cast<int>(t.size());++r)out.push_back(t.get(u,v,r));}for(std::uint64_t k=0;k<=t.size()+1;++k)out.push_back(t.kth_ancestor(v,k));}return out;}
void bad_case(int n,const Edges&e,int root,Result expected){
 check(classification([&]{BaselineLCA t(n,e,root);})==expected);check(classification([&]{OffsetLCA t(n,e,root);})==expected);
 Graph g{{1},{0}};BaselineLCA a(g);OffsetLCA b(g);auto copy_a=a;auto copy_b=b;const auto before=snapshot(a);check(before==snapshot(b));
 check(classification([&]{a.build(n,e,root);})==expected);check(classification([&]{b.build(n,e,root);})==expected);check(snapshot(a)==before);check(snapshot(b)==before);check(snapshot(copy_a)==before);check(snapshot(copy_b)==before);
}
int main(){std::mt19937_64 random(1197721);
 for(int n=0;n<=100;++n)for(int trial=0;trial<16;++trial){Edges edges;Graph expected(n);if(n)for(int k=0;k<trial*n;++k){int u=random()%n,v=random()%n;edges.emplace_back(u,v);expected[u].push_back(v);expected[v].push_back(u);}reinsirk::detail::BaselineCsrGraph a(n,edges);reinsirk::detail::OffsetCsrGraph b(n,edges);check(a.size()==static_cast<std::size_t>(n)&&b.size()==a.size());for(int v=0;v<n;++v){check(std::vector<int>(a[v].begin(),a[v].end())==expected[v]);check(std::vector<int>(b[v].begin(),b[v].end())==expected[v]);}}
 for(int trial=0;trial<160;++trial){const int n=trial%37;Graph graph(n);Edges edges;for(int v=1;v<n;++v)if(random()%4){int u=random()%v;edges.emplace_back(u,v);}std::shuffle(edges.begin(),edges.end(),random);for(auto&[u,v]:edges){if(random()%2)std::swap(u,v);graph[u].push_back(v);graph[v].push_back(u);}int root=n?random()%n:0;BaselineLCA a(n,edges,root);OffsetLCA b(n,edges,root);BaselineLCA old(graph,root);check(snapshot(a)==snapshot(b));check(snapshot(a)==snapshot(old));auto a_copy=a;auto b_copy=b;a.clear();b.clear();check(a.empty()&&b.empty());check(snapshot(a_copy)==snapshot(b_copy));a.build(n,edges,root);b.build(n,edges,root);check(snapshot(a)==snapshot(b));}
 bad_case(-1,{},0,Result::length);
#ifndef SKIP_RUNTIME_CHECKS
 bad_case(0,{},1,Result::range);bad_case(2,{{0,1}},-1,Result::range);bad_case(2,{{0,1}},2,Result::range);bad_case(2,{{-1,0}},0,Result::range);bad_case(2,{{0,2}},0,Result::range);bad_case(0,{{0,0}},0,Result::range);bad_case(5,{{0,1},{4,99}},0,Result::range);
 bad_case(2,{{0,0}},0,Result::invalid);bad_case(2,{{0,1},{0,1}},0,Result::invalid);bad_case(2,{{0,1},{1,0}},0,Result::invalid);bad_case(3,{{0,1},{1,2},{2,0}},0,Result::invalid);
#endif
 std::printf("PASS %llu direct CSR/order/full API/exception checks\n",static_cast<unsigned long long>(checks));}
