from pathlib import Path
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/lca_offsets_candidate');s=(R/'Verify/current/tests/lca_allocation_test.cpp').read_text().replace('#define SIRKIT_LCA_SOURCE "../../../Graph/LCA.cpp"','#define SIRKIT_LCA_SOURCE "candidate_library.cpp"');s=s[:s.index('static void constructor_failures')]+'''
static std::vector<std::pair<int,int>> edge_list(const Graph& g) {
 std::vector<std::pair<int,int>> out;for(int v=0;v<static_cast<int>(g.size());++v)for(int u:g[v])if(v<u)out.emplace_back(v,u);return out;
}
int main() {
 const auto initial=live_allocations;
 {
  const auto small=make_graph(9,false);const LCA original(small,3);const auto previous=snapshot(original);LCA shared_copy(original);
  for(int shape=0;shape<2;++shape) {
   Graph g=make_graph(73,true);int root=41;
   if(shape) {g=Graph(300);for(int v=1;v<300;++v){g[v-1].push_back(v);g[v].push_back(v-1);}root=0;}
   const auto edges=edge_list(g);const int n=static_cast<int>(g.size());const LCA reference(n,edges,root);const auto expected=snapshot(reference);
   bool success=false;
   for(std::ptrdiff_t point=0;point<128;++point) {
    const auto before=live_allocations;bool caught=false;
    try {failure_countdown=point;LCA t(n,edges,root);failure_countdown=-1;require(snapshot(t)==expected);success=true;}
    catch(const std::bad_alloc&){failure_countdown=-1;caught=true;++failures;}
    require(live_allocations==before);if(!caught)break;
   }
   require(success);success=false;
   for(std::ptrdiff_t point=0;point<128;++point) {
    const auto outside=live_allocations;bool caught=false;
    {
     LCA target(original);const auto before=live_allocations;
     try {failure_countdown=point;target.build(n,edges,root);failure_countdown=-1;require(snapshot(target)==expected);success=true;}
     catch(const std::bad_alloc&){failure_countdown=-1;caught=true;++failures;require(snapshot(target)==previous);require(live_allocations==before);}
     require(snapshot(original)==previous);require(snapshot(shared_copy)==previous);
    }
    require(live_allocations==outside);if(!caught)break;
   }
   require(success);
  }
 }
 require(live_allocations==initial);
 std::printf("{\\"status\\":\\"PASS\\",\\"checks\\":%zu,\\"allocation_failure_points\\":%zu,\\"live_delta\\":%zu}\\n",checks,failures,live_allocations-initial);
}
''';(W/'csr_allocation_test.cpp').write_text(s)
