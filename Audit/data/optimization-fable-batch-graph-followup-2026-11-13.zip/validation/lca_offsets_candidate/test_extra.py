from pathlib import Path
import json,os,subprocess,sys
W=Path('/tmp/sirkit_fastest_review_20261113/lca_offsets_candidate');os.sched_setaffinity(0,{10});subprocess.run([sys.executable,str(W/'prepare_allocation_test.py')],check=True);(W/'extra_bin').mkdir(exist_ok=True);rows=[]
for test in ['differential_test','csr_allocation_test']:
 for label,prefix in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for skip in [False,True]:
   exe=W/'extra_bin'/f'{test}_{label}_{skip}';cmd=[*prefix,'-std=c++23','-O2','-Wall','-Wextra']
   if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
   cmd += [str(W/(test+'.cpp')),'-o',str(exe)];built=subprocess.run(cmd,capture_output=True,text=True,timeout=180);assert built.returncode==0,built.stderr;r=subprocess.run([str(exe)],capture_output=True,text=True,timeout=120);row={'test':test,'compiler':label,'skip':skip,'command':cmd,'diagnostics':built.stderr,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr};rows.append(row);(W/'extra_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(test,label,skip,r.returncode,r.stdout.strip(),flush=True);assert r.returncode==0,r.stderr
for skip in [False,True]:
 exe=W/'extra_bin'/f'differential_asan_{skip}';cmd=['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-std=c++23','-O1','-fsanitize=address,undefined','-fno-omit-frame-pointer']
 if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
 cmd += [str(W/'differential_test.cpp'),'-o',str(exe)];built=subprocess.run(cmd,capture_output=True,text=True,timeout=180);assert built.returncode==0,built.stderr;r=subprocess.run([str(exe)],capture_output=True,text=True,timeout=120,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0'));row={'test':'differential_sanitized','compiler':'Clang','skip':skip,'command':cmd,'diagnostics':built.stderr,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr};rows.append(row);(W/'extra_results.json').write_text(json.dumps(rows,indent=2)+'\n');print('sanitizers',skip,r.returncode,r.stdout.strip(),flush=True);assert r.returncode==0,r.stderr
