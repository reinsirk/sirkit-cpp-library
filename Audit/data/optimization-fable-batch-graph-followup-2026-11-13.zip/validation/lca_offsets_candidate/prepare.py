from pathlib import Path
import difflib,hashlib,json,sys
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/lca_offsets_candidate');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
source=(R/'Graph/LCA.cpp').read_text();(W/'baseline_library.cpp').write_text(source)
a=source.index('class LcaCsrGraph {');b=source.index('\n};',a)+len('\n};');old=source[a:b]
new='''class LcaCsrGraph {
    std::unique_ptr<int[]> arcs_;
    std::vector<std::size_t> begin_;
public:
    LcaCsrGraph(int n, std::span<const std::pair<int,int>> edges) {
        if (n < 0) throw std::length_error("LCA: negative vertex count");
        const auto count = static_cast<std::size_t>(n);
        if (begin_.max_size() < 2 || count > begin_.max_size() - 2
            || edges.size() > static_cast<std::size_t>(std::numeric_limits<std::ptrdiff_t>::max()) / (2 * sizeof(int)))
            throw std::length_error("LCA: CSR capacity exceeded");
        // 散布cursorを1要素ずらし、散布後の値をそのまま行のoffsetへ使う。
        begin_.assign(count + 2, 0);
        for (const auto& [u,v] : edges) {
#ifndef SKIP_RUNTIME_CHECKS
            if (static_cast<unsigned>(u) >= static_cast<unsigned>(n)
                || static_cast<unsigned>(v) >= static_cast<unsigned>(n))
                throw std::out_of_range("LCA: endpoint out of range");
#endif
            ++begin_[static_cast<std::size_t>(u) + 2];
            ++begin_[static_cast<std::size_t>(v) + 2];
        }
        for (std::size_t i = 2; i <= count + 1; ++i) begin_[i] += begin_[i-1];
        arcs_ = std::make_unique_for_overwrite<int[]>(std::max(std::size_t{1}, 2 * edges.size()));
        for (const auto& [u,v] : edges) {
            arcs_[begin_[static_cast<std::size_t>(u) + 1]++] = v;
            arcs_[begin_[static_cast<std::size_t>(v) + 1]++] = u;
        }
    }
    LcaCsrGraph(const LcaCsrGraph&) = delete;
    LcaCsrGraph& operator=(const LcaCsrGraph&) = delete;
    std::size_t size() const noexcept { return begin_.size() - 2; }
    std::span<const int> operator[](int v) const noexcept {
        const auto index = static_cast<std::size_t>(v);
        return {arcs_.get() + begin_[index], begin_[index+1] - begin_[index]};
    }
};'''
source=source[:a]+new+source[b:];(W/'candidate_library.cpp').write_text(source);(W/'library.diff').write_text(''.join(difflib.unified_diff((W/'baseline_library.cpp').read_text().splitlines(True),source.splitlines(True),fromfile='Graph/LCA.cpp baseline',tofile='offset candidate')))
main=(R/'Verify/current/drivers/lca_main.cpp').read_text();(W/'main.cpp').write_text(main);entry=next(e for e in pv.collect()if e['id']=='lca');meta={'entry':entry,'body_sha256':{},'driver_sha256':hashlib.sha256(main.encode()).hexdigest(),'io_sha256':hashlib.sha256((R/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest(),'programs':{}}
for name in ['baseline','candidate']:
 data=(W/(name+'_library.cpp')).read_bytes();meta['body_sha256'][name]=hashlib.sha256(data).hexdigest();program,_=pv.render(entry,source_overrides={'Graph/LCA.cpp':data},driver_override=main,skip_runtime_checks=True);p=W/(name+'_program.cpp');p.write_bytes(program);meta['programs'][name]={'path':str(p),'sha256':hashlib.sha256(program).hexdigest()}
(W/'sources.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');print('prepared',W)
