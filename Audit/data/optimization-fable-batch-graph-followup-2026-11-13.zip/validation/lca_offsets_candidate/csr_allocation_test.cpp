// SPDX-License-Identifier: CC0-1.0
#ifndef SIRKIT_LCA_REQUIRE_EXTRA
#define SIRKIT_LCA_REQUIRE_EXTRA
#endif
#ifndef SIRKIT_LCA_SOURCE
#define SIRKIT_LCA_SOURCE "candidate_library.cpp"
#endif
#include SIRKIT_LCA_SOURCE
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <new>
#include <type_traits>
#include <utility>
#include <vector>

static std::ptrdiff_t failure_countdown = -1;
static std::size_t live_allocations = 0, checks = 0, failures = 0;
[[gnu::noinline]] void* operator new(std::size_t n) {
    if (failure_countdown == 0) throw std::bad_alloc();
    if (failure_countdown > 0) --failure_countdown;
    if (void* p = std::malloc(n ? n : 1)) { ++live_allocations; return p; }
    throw std::bad_alloc();
}
[[gnu::noinline]] void* operator new[](std::size_t n) { return ::operator new(n); }
[[gnu::noinline]] static void free_block(void* p) noexcept { if (p) --live_allocations; std::free(p); }
void operator delete(void* p) noexcept { free_block(p); }
void operator delete[](void* p) noexcept { free_block(p); }
void operator delete(void* p, std::size_t) noexcept { free_block(p); }
void operator delete[](void* p, std::size_t) noexcept { free_block(p); }
static void require(bool ok) { ++checks; if (!ok) std::abort(); }
using Graph = std::vector<std::vector<int>>;
static Graph make_graph(int n, bool forest) {
    Graph g(n); for(int v=1;v<n;++v) if(!forest || v%7) {int p=(v-1)/2;g[v].push_back(p);g[p].push_back(v);}return g;
}
template<class Tree> static void append_extra(std::vector<int>& out,const Tree& tree,int v) {
    if constexpr(requires { tree.subtree_size(v);tree.subtree_range(v);tree.order_index(v); }) {
        out.push_back(tree.subtree_size(v));out.push_back(tree.order_index(v));
        const auto [first,last]=tree.subtree_range(v);out.push_back(first);out.push_back(last);
    }
}
static std::vector<int> snapshot(const LCA& tree) {
    std::vector<int> result{static_cast<int>(tree.size()),tree.root(),static_cast<int>(tree.component_count())};
    for (int v=0;v<static_cast<int>(tree.size());++v) {
        result.push_back(tree.parent(v));result.push_back(tree.depth_of(v));result.push_back(tree.root_of(v));result.push_back(tree.component_of(v));
        result.push_back(tree.kth_ancestor(v,UINT64_MAX));append_extra(result,tree,v);
        for(int u=0;u<static_cast<int>(tree.size());++u) {result.push_back(tree.get(v,u));result.push_back(tree.get_distance(v,u));result.push_back(tree.is_ancestor(v,u));result.push_back(tree.kth_on_path(v,u,1));}
    }
    return result;
}

static std::vector<std::pair<int,int>> edge_list(const Graph& g) {
 std::vector<std::pair<int,int>> out;for(int v=0;v<static_cast<int>(g.size());++v)for(int u:g[v])if(v<u)out.emplace_back(v,u);return out;
}
int main() {
 const auto initial=live_allocations;
 {
  const auto small=make_graph(9,false);const LCA original(small,3);const auto previous=snapshot(original);LCA shared_copy(original);
  for(int shape=0;shape<2;++shape) {
   Graph g=make_graph(73,true);int root=41;
   if(shape) {g=Graph(300);for(int v=1;v<300;++v){g[v-1].push_back(v);g[v].push_back(v-1);}root=0;}
   const auto edges=edge_list(g);const int n=static_cast<int>(g.size());const LCA reference(n,edges,root);const auto expected=snapshot(reference);
   bool success=false;
   for(std::ptrdiff_t point=0;point<128;++point) {
    const auto before=live_allocations;bool caught=false;
    try {failure_countdown=point;LCA t(n,edges,root);failure_countdown=-1;require(snapshot(t)==expected);success=true;}
    catch(const std::bad_alloc&){failure_countdown=-1;caught=true;++failures;}
    require(live_allocations==before);if(!caught)break;
   }
   require(success);success=false;
   for(std::ptrdiff_t point=0;point<128;++point) {
    const auto outside=live_allocations;bool caught=false;
    {
     LCA target(original);const auto before=live_allocations;
     try {failure_countdown=point;target.build(n,edges,root);failure_countdown=-1;require(snapshot(target)==expected);success=true;}
     catch(const std::bad_alloc&){failure_countdown=-1;caught=true;++failures;require(snapshot(target)==previous);require(live_allocations==before);}
     require(snapshot(original)==previous);require(snapshot(shared_copy)==previous);
    }
    require(live_allocations==outside);if(!caught)break;
   }
   require(success);
  }
 }
 require(live_allocations==initial);
 std::printf("{\"status\":\"PASS\",\"checks\":%zu,\"allocation_failure_points\":%zu,\"live_delta\":%zu}\n",checks,failures,live_allocations-initial);
}
