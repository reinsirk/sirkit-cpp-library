from pathlib import Path
import hashlib,json,os,random,statistics,subprocess,time
P=Path('/tmp/sirkit_fastest_review_20261113');W=P/'lca_offsets_candidate';os.sched_setaffinity(0,{10});sha=lambda b:hashlib.sha256(b).hexdigest()
for d in ['inputs','bin','rss']:(W/d).mkdir(exist_ok=True)
old=json.loads((P/'lca_csr_candidate/clean_ref/results.json').read_text());cases=[r['input']for r in old['results']if r['compiler']=='GCC'and r['input']['official']]
for shape in ['small','line']:
 path=P/'lca_hld/inputs'/f'lca_{shape}.in';cases.append({'path':str(path),'case':'small'if shape=='small'else'path','official':False,'small':shape=='small','input_sha256':sha(path.read_bytes())})
p=W/'inputs/star.in';expected=W/'inputs/star.expected'
if not p.exists():
 rng=random.Random(691273);n=500000;q=500000
 with p.open('w')as f,expected.open('w')as out:
  f.write(f'{n} {q}\n');f.write(' '.join(['0']*(n-1))+'\n')
  for step in range(q):
   u=rng.randrange(n);v=u if step%4==0 else rng.randrange(n);f.write(f'{u} {v}\n');out.write(str(u if u==v else 0)+'\n')
cases.append({'path':str(p),'case':'star','official':False,'independent_expected':str(expected),'input_sha256':sha(p.read_bytes())})
meta=json.loads((W/'sources.json').read_text());flags=['-std=c++23','-O2','-Wall','-Wextra'];report={'format':1,'status':'running','cpu':10,'flags':flags,'source_metadata':meta,'notes':['Current actual lca per-entry GCC O3 pragma preserved; Clang ignores it. Body CSR helper only differs; main, I/O, public APIs, query algorithm and flags unchanged.','2 warmup +9 measured interleaved reverse order. RSS from separate /usr/bin/time run includes full preprocessing allocations.','Offsets storage during preprocessing replaces 16N-byte span rows with ~8N-byte offsets; old transient offsets were freed before preprocessing. Expected peak reduction is about 8N bytes, not 16N.'],'results':[]};report['compilers']={k:subprocess.check_output([v,'--version'],text=True).splitlines()[0]for k,v in [('GCC','/usr/bin/g++'),('Clang','/usr/bin/clang++')]};assert '15.2.0'in report['compilers']['GCC']and '21.'in report['compilers']['Clang']
for label,prefix in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 builds={};binaries={}
 for name,info in meta['programs'].items():
  src=Path(info['path']);assert sha(src.read_bytes())==info['sha256'];exe=W/'bin'/f'{label}_{name}';cmd=[*prefix,*flags,str(src),'-o',str(exe)];r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);assert r.returncode==0,r.stderr;binaries[name]=exe;builds[name]={'command':cmd,'source_sha256':info['sha256'],'binary_sha256':sha(exe.read_bytes()),'diagnostics':r.stderr}
 for info in cases:
  path=Path(info['path']);assert sha(path.read_bytes())==info['input_sha256'];outputs={};reference=None
  for name,exe in binaries.items():
   with path.open('rb')as f:r=subprocess.run([str(exe)],stdin=f,capture_output=True,check=True,timeout=90)
   if reference is None:reference=r.stdout
   assert r.stdout==reference,(label,name,path,'outputs differ');outputs[name]=sha(r.stdout)
   if info['official']:assert outputs[name]==info['official_output_sha256'],(name,path,'official output differs')
   if info.get('small'):assert r.stdout.split()==path.with_suffix('.expected').read_bytes().split()
   if info.get('independent_expected'):assert r.stdout==Path(info['independent_expected']).read_bytes()
  samples={name:[]for name in binaries}
  for iteration in range(11):
   for name in (['baseline','candidate']if iteration%2==0 else['candidate','baseline']):
    with path.open('rb')as f:
     begin=time.perf_counter_ns();subprocess.run([str(binaries[name])],stdin=f,stdout=subprocess.DEVNULL,check=True);ms=(time.perf_counter_ns()-begin)/1e6
    if iteration>=2:samples[name].append(ms)
  median={n:statistics.median(v)for n,v in samples.items()};rss={}
  for name,exe in binaries.items():
   raw=W/'rss'/f'{label}_{path.stem}_{name}.txt'
   with path.open('rb')as f:subprocess.run(['/usr/bin/time','-f','%M','-o',str(raw),str(exe)],stdin=f,stdout=subprocess.DEVNULL,check=True,timeout=90)
   rss[name]=int(raw.read_text())
  pair=[c/b for c,b in zip(samples['candidate'],samples['baseline'])];row={'compiler':label,'builds':builds,'input':info,'case':info.get('case',path.stem),'all_outputs_equal':True,'output_sha256':outputs,'samples_ms':samples,'median_ms':median,'candidate_over_baseline':median['candidate']/median['baseline'],'paired_median_ratio':statistics.median(pair),'candidate_wins_out_of_9':sum(v<1 for v in pair),'peak_rss_kib':rss,'rss_saved_kib':rss['baseline']-rss['candidate'],'warmup':2,'measured':9};report['results'].append(row);(W/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(label,row['case'],round(row['candidate_over_baseline'],3),median,'rss',rss,'wins',row['candidate_wins_out_of_9'],flush=True)
report['status']='passed';(W/'results.json').write_text(json.dumps(report,indent=2)+'\n');print('FINAL PASS',len(report['results']),'compiler/input cases',flush=True)
