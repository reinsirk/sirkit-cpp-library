from pathlib import Path
import hashlib,json,os,subprocess
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/lca_offsets_candidate');os.sched_setaffinity(0,{10});rows=[]
original=(R/'Verify/current/tests/lca_reference_test.cpp').read_text();old='#define SIRKIT_LCA_SOURCE "../../../Graph/LCA.cpp"';assert old in original;original=original.replace(old,'#define SIRKIT_LCA_SOURCE "candidate_library.cpp"');(W/'old_api_reference_test.cpp').write_text(original)
helper='''
static std::vector<std::pair<int,int>> edge_list(const Graph& g) {
 std::vector<std::pair<int,int>> result;
 for(int v=0;v<static_cast<int>(g.size());++v)for(int u:g[v])if(v<u)result.emplace_back(v,u);
 return result;
}
'''
new=original.replace('using Graph = std::vector<std::vector<int>>;','using Graph = std::vector<std::vector<int>>;'+helper).replace('LCA t(g,root);','LCA t(static_cast<int>(g.size()),edge_list(g),root);').replace('LCA t(g);','LCA t(static_cast<int>(g.size()),edge_list(g));').replace('t.build(g,root);','t.build(static_cast<int>(g.size()),edge_list(g),root);').replace('t.build(Graph{});','t.build(0,std::span<const std::pair<int,int>>{});')
extra='''
static void csr_invalid() {
 const std::vector<std::pair<int,int>> good{{0,1}};
 LCA t(2,good); LCA copied(t);
 throws<std::length_error>([&]{t.build(-1,{});});require(t.size()==2&&t.get(0,1)==0);
#ifndef SKIP_RUNTIME_CHECKS
 throws<std::out_of_range>([&]{LCA z(0,{},1);});
 throws<std::out_of_range>([&]{LCA z(2,good,-1);});
 throws<std::out_of_range>([&]{LCA z(2,good,2);});
 for(const auto& bad:std::vector<std::vector<std::pair<int,int>>>{{{-1,0}},{{0,2}},{{0,0}},{{0,1},{1,0}}}) {
  bool caught=false;try{t.build(2,bad);}catch(const std::out_of_range&){caught=true;}catch(const std::invalid_argument&){caught=true;}
  require(caught);require(t.size()==2&&t.get(0,1)==0);require(copied.size()==2&&copied.get(0,1)==0);
 }
 const std::vector<std::pair<int,int>> cyclic{{0,1},{1,2},{2,0}};
 throws<std::invalid_argument>([&]{t.build(3,cyclic);});require(t.size()==2&&t.get(0,1)==0);
 const std::vector<std::pair<int,int>> unseen_bad{{0,1},{4,99}};
 throws<std::out_of_range>([&]{t.build(5,unseen_bad);});require(t.size()==2&&t.get(0,1)==0);
#endif
 LCA e(0,{});require(e.empty());e.build(1,{});require(e.parent(0)==-1);e.build(0,{});require(e.empty());
 LCA brace_empty({},0);require(brace_empty.empty());
}
'''
pos=new.index('int main() {');new=new[:pos]+extra+new[pos:];new=new.replace('    invalid_inputs(); deep_shapes();','    invalid_inputs(); csr_invalid(); deep_shapes();');(W/'csr_reference_test.cpp').write_text(new)
# Existing deep RMQ/ancestor threshold fixture, routed through the new constructor.
s=(R/'Verify/current/tests/lca_deep_branch_test.cpp').read_text().replace(old,'#define SIRKIT_LCA_SOURCE "candidate_library.cpp"');needle='using Graph=std::vector<std::vector<int>>;';assert needle in s;s=s.replace(needle,needle+helper).replace('LCA t(g,root);','LCA t(static_cast<int>(g.size()),edge_list(g),root);').replace('t.build(g,root);','t.build(static_cast<int>(g.size()),edge_list(g),root);');(W/'csr_deep_branch_test.cpp').write_text(s)
(W/'test_bin').mkdir(exist_ok=True)
for test in ['old_api_reference_test','csr_reference_test','csr_deep_branch_test']:
 for label,compiler in [('GCC','/usr/bin/g++'),('Clang','/usr/bin/clang++')]:
  for skip in [False,True]:
   fallbacks=[False,True]if test!='csr_deep_branch_test'else[False]
   for fallback in fallbacks:
    exe=W/'test_bin'/f'{test}_{label}_{skip}_{fallback}';cmd=[compiler,'-std=c++23','-O2','-Wall','-Wextra']
    if label=='Clang':cmd+=['--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
    if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
    if fallback:cmd+=['-U__SIZEOF_INT128__','-DSIRKIT_FORCE_STANDARD_ARITHMETIC','-DSIRKIT_DISABLE_SIMD']
    cmd += [str(W/(test+'.cpp')),'-o',str(exe)];r=subprocess.run(cmd,capture_output=True,text=True,timeout=120);row={'test':test,'compiler':label,'skip':skip,'fallback':fallback,'command':cmd,'compile_returncode':r.returncode,'diagnostics':r.stderr}
    if r.returncode==0:
     r=subprocess.run([str(exe)],capture_output=True,text=True,timeout=180);row.update(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
    row['passed']=row['compile_returncode']==0 and row.get('returncode')==0;rows.append(row);(W/'test_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(test,label,skip,fallback,'PASS'if row['passed']else'FAIL',row.get('stdout','').strip(),flush=True);assert row['passed'],row
