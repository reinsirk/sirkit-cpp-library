// SPDX-License-Identifier: CC0-1.0
#include MANACHER_HEADER
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <random>
#include <string>
#include <string_view>
#include <vector>
int main(int argc,char** argv){
 if(argc!=4)return 1;const int op=std::atoi(argv[1]),n=std::atoi(argv[2]),shape=std::atoi(argv[3]);
 std::string s(n,'a');std::vector<std::int64_t>a(n);std::vector<bool>bits(n);std::mt19937_64 rng(416358);
 for(int i=0;i<n;++i){const int value=shape==0?0:shape==1?i%3:static_cast<int>(rng()%2);s[i]=static_cast<char>('a'+value);a[i]=value;bits[i]=value!=0;}
 const int reps=std::max(2,2000000/std::max(1,n));std::uint64_t checksum=0;PalindromeRadii p(s);
 const auto begin=std::chrono::steady_clock::now();
 for(int r=0;r<reps;++r){
  if(op==4){const PalindromeRadii next(s);checksum+=next.odd.size()+next.odd.back()+next.even[n/2];}
  else {p.assign(s);checksum+=p.odd.size()+p.odd.back()+p.even[n/2];}
 }
 const auto elapsed=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-begin).count();std::printf("%jd %ju\n",static_cast<std::intmax_t>(elapsed),static_cast<std::uintmax_t>(checksum));
}
