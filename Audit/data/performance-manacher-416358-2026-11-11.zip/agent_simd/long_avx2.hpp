// SPDX-License-Identifier: CC0-1.0
// 参考（回文半径の出力形式とVerify先。実装は独自構成）:
// https://judge.yosupo.jp/problem/enumerate_palindromes
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/manacher.md
//
// API一覧
// PalindromeRadii(s)/assign(s): 列の奇数/偶数長回文の半径をO(n)時間・領域で構築。
// odd[i]: 中心iの奇数回文の半径（中心を含む）。even[i]: i-1とiの間の偶数回文の半分の長さ。
// size()/empty(): 元の列長/空かを返す。is_palindrome(l,r): 半開区間[l,r)をO(1)で判定、空区間はtrue。
// longest(): 最長回文の半開区間を返す。同長なら最小の左端、空なら{0,0}。O(n)。
// count(): 非空の連続回文区間の総数をuint64_tで返す。O(n)。
// PalindromicLengths(s): 文字上/文字間の2n-1中心の最長回文長を順に返す。空なら{}、O(n)。
// size()/添字アクセス/==が使える列が前提。各比較O(1)、列長はINT_MAX未満。元の列は保持しない。
// 検査省略時もis_palindromeの添字は0<=l<=r<=size()が必要。公開半径配列は変更しないこと。

#include <algorithm>
#include <bit>
#include <climits>
#include <cstring>
#include <string>
#include <type_traits>

#include <cstddef>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <utility>
#include <vector>
#if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__)) && CHAR_BIT == 8
#include <immintrin.h>
#endif

#ifndef SIRKIT_PALINDROME_RADII_DEFINED
#define SIRKIT_PALINDROME_RADII_DEFINED
class PalindromeRadii {
public:
    std::vector<int> odd, even;
    PalindromeRadii() = default;
    template <class Sequence>
    explicit PalindromeRadii(const Sequence& s) { assign(s); }

    template <class Sequence>
    void assign(const Sequence& s) {
        if (s.size() >= static_cast<std::size_t>(std::numeric_limits<int>::max()))
            throw std::length_error("PalindromeRadii: sequence too long");
        const int n = static_cast<int>(s.size());
        std::vector<int> next_odd(s.size()), next_even(s.size());
        int left = 0, right = -1;
        for (int i = 0; i < n; ++i) {
            int radius = i <= right ? std::min(right - i + 1, next_odd[left + (right - i)]) : 1;
            while (radius <= i && radius < n - i && s[i - radius] == s[i + radius]) ++radius;
            next_odd[i] = radius;
            if (i + radius - 1 > right) { left = i - radius + 1; right = i + radius - 1; }
        }
        left = 0; right = -1;
        for (int i = 0; i < n; ++i) {
            int radius = i <= right ? std::min(right - i + 1, next_even[left + (right - i) + 1]) : 0;
            while (radius < i && radius < n - i && s[i - radius - 1] == s[i + radius]) ++radius;
            next_even[i] = radius;
            if (i + radius - 1 > right) { left = i - radius; right = i + radius - 1; }
        }
        odd.swap(next_odd); even.swap(next_even);
    }

    [[nodiscard]] int size() const noexcept { return static_cast<int>(odd.size()); }
    [[nodiscard]] bool empty() const noexcept { return odd.empty(); }
    [[nodiscard]] bool is_palindrome(int l, int r) const {
#ifndef SKIP_RUNTIME_CHECKS
        if (l < 0 || l > r || r > size()) throw std::out_of_range("PalindromeRadii: range");
#endif
        const int length = r - l;
        if (length == 0) return true;
        const int center = l + length / 2;
        return length & 1 ? odd[center] >= length / 2 + 1 : even[center] >= length / 2;
    }
    [[nodiscard]] std::pair<int, int> longest() const noexcept {
        std::pair<int, int> best{0, 0};
        const auto consider = [&](int l, int r) {
            if (r - l > best.second - best.first ||
                (r - l == best.second - best.first && l < best.first)) best = {l, r};
        };
        for (int i = 0; i < size(); ++i) {
            consider(i - odd[i] + 1, i + odd[i]);
            consider(i - even[i], i + even[i]);
        }
        return best;
    }
    [[nodiscard]] std::uint64_t count() const noexcept {
        std::uint64_t result = 0;
        for (int radius : odd) result += static_cast<std::uint64_t>(radius);
        for (int radius : even) result += static_cast<std::uint64_t>(radius);
        return result;
    }
};
#endif

#ifndef SIRKIT_PALINDROME_EXTEND_WORD_DEFINED
#define SIRKIT_PALINDROME_EXTEND_WORD_DEFINED
namespace reinsirk::detail {
// lから左、rから右へ進む一致数。呼出し時は-1<=l<n、0<=r<=n。
inline int extend_palindrome_word(const char* data, int l, int r, int n) {
    const int limit = std::min(l + 1, n - r);
    int matched = 0;
#if defined(UINT64_MAX) && CHAR_BIT == 8
    if constexpr (std::endian::native == std::endian::little || std::endian::native == std::endian::big) {
        while (limit - matched >= 8) {
            std::uint64_t left, right;
            std::memcpy(&left, data + l - matched - 7, sizeof(left));
            std::memcpy(&right, data + r + matched, sizeof(right));
            const auto difference = std::byteswap(left) ^ right;
            if (difference != 0) {
                if constexpr (std::endian::native == std::endian::little)
                    return matched + static_cast<int>(std::countr_zero(difference) / 8);
                else return matched + static_cast<int>(std::countl_zero(difference) / 8);
            }
            matched += 8;
        }
    }
#endif
    while (matched < limit && data[l - matched] == data[r + matched]) ++matched;
    return matched;
}
}
#endif

#ifndef SIRKIT_PALINDROME_EXTEND_AVX2_DEFINED
#define SIRKIT_PALINDROME_EXTEND_AVX2_DEFINED
#if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__)) && CHAR_BIT == 8
namespace reinsirk::detail {
__attribute__((target("avx2")))
inline int extend_palindrome_avx2(const char* data, int l, int r, int n) {
    const int limit = std::min(l + 1, n - r);
    int matched = 0;
    const auto reverse_lane = _mm256_setr_epi8(
        15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0,
        15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0);
    while (limit - matched >= 32) {
        __m256i left, right;
        std::memcpy(&left, data + l - matched - 31, sizeof(left));
        std::memcpy(&right, data + r + matched, sizeof(right));
        left = _mm256_shuffle_epi8(left, reverse_lane);
        left = _mm256_permute2x128_si256(left, left, 1);
        const auto mask = static_cast<std::uint32_t>(_mm256_movemask_epi8(_mm256_cmpeq_epi8(left, right)));
        if (mask != UINT32_MAX)
            return matched + static_cast<int>(std::countr_zero(static_cast<std::uint32_t>(~mask)));
        matched += 32;
    }
    return matched + extend_palindrome_word(data, l - matched, r + matched, n);
}
inline bool palindrome_avx2_available() {
    static const bool available = __builtin_cpu_supports("avx2");
    return available;
}
}
#endif
#endif

#ifndef SIRKIT_PALINDROMIC_LENGTHS_DEFINED
#define SIRKIT_PALINDROMIC_LENGTHS_DEFINED
template <class Sequence>
std::vector<int> PalindromicLengths(const Sequence& s) {
    if (s.size() >= static_cast<std::size_t>(std::numeric_limits<int>::max()))
        throw std::length_error("PalindromicLengths: sequence too long");
    const int n = static_cast<int>(s.size());
    if (n == 0) return {};
    std::vector<int> result(std::size_t{2} * static_cast<std::size_t>(n) - 1);
    std::size_t middle = 0, right = 0;
    for (std::size_t center = 0; center < result.size(); ++center) {
        int length = (center & 1) == 0 ? 1 : 0;
        if (center < right) {
            const int available = static_cast<int>(right - center + 1);
            const int reflected = result[middle - (center - middle)];
            if (reflected < available) { result[center] = reflected; continue; }
            length = available;
        }
        int l = static_cast<int>((center + 1 - static_cast<std::size_t>(length)) / 2) - 1;
        int r = static_cast<int>((center + static_cast<std::size_t>(length) + 1) / 2);
        if constexpr (std::is_same_v<Sequence, std::string>) {
            const int limit = std::min(l + 1, n - r);
            const int short_limit = std::min(16, limit);
            int matched = 0;
            // 短い一致では通常比較だけ。16組一致してからブロック比較へ進む。
            while (matched < short_limit && s[l - matched] == s[r + matched]) ++matched;
            if (matched == short_limit && matched < limit) {
                #if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__)) && CHAR_BIT == 8
                if (limit - matched >= 64 && reinsirk::detail::palindrome_avx2_available())
                    matched += reinsirk::detail::extend_palindrome_avx2(s.data(), l - matched, r + matched, n);
                else
#endif
                    matched += reinsirk::detail::extend_palindrome_word(s.data(), l - matched, r + matched, n);
            }
            l -= matched; r += matched; length += matched * 2;
        } else {
        while (l >= 0 && r < n && s[l] == s[r]) { --l; ++r; length += 2; }
        }
        result[center] = length;
        const auto end = center + static_cast<std::size_t>(length) - 1;
        if (end > right) { middle = center; right = end; }
    }
    return result;
}
#endif
