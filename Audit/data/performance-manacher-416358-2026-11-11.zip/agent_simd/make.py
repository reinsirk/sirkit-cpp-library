# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
D=Path('/tmp/sirkit_manacher_416358/agent_simd')
base=Path('/tmp/sirkit_manacher_416358/center_skip.hpp').read_text()
includes='''#include <bit>
#include <climits>
#include <cstring>
#include <string>
#include <type_traits>
'''
word='''#ifndef SIRKIT_PALINDROME_EXTEND_WORD_DEFINED
#define SIRKIT_PALINDROME_EXTEND_WORD_DEFINED
namespace reinsirk::detail {
// lから左、rから右へ進む一致数。呼出し時は-1<=l<n、0<=r<=n。
inline int extend_palindrome_word(const char* data, int l, int r, int n) {
    const int limit = std::min(l + 1, n - r);
    int matched = 0;
#if defined(UINT64_MAX) && CHAR_BIT == 8
    if constexpr (std::endian::native == std::endian::little || std::endian::native == std::endian::big) {
        while (limit - matched >= 8) {
            std::uint64_t left, right;
            std::memcpy(&left, data + l - matched - 7, sizeof(left));
            std::memcpy(&right, data + r + matched, sizeof(right));
            const auto difference = std::byteswap(left) ^ right;
            if (difference != 0) {
                if constexpr (std::endian::native == std::endian::little)
                    return matched + static_cast<int>(std::countr_zero(difference) / 8);
                else return matched + static_cast<int>(std::countl_zero(difference) / 8);
            }
            matched += 8;
        }
    }
#endif
    while (matched < limit && data[l - matched] == data[r + matched]) ++matched;
    return matched;
}
}
#endif

'''
condition='!defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__)) && CHAR_BIT == 8'
avx='''#ifndef SIRKIT_PALINDROME_EXTEND_AVX2_DEFINED
#define SIRKIT_PALINDROME_EXTEND_AVX2_DEFINED
#if '''+condition+'''
namespace reinsirk::detail {
__attribute__((target("avx2")))
inline int extend_palindrome_avx2(const char* data, int l, int r, int n) {
    const int limit = std::min(l + 1, n - r);
    int matched = 0;
    const auto reverse_lane = _mm256_setr_epi8(
        15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0,
        15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0);
    while (limit - matched >= 32) {
        __m256i left, right;
        std::memcpy(&left, data + l - matched - 31, sizeof(left));
        std::memcpy(&right, data + r + matched, sizeof(right));
        left = _mm256_shuffle_epi8(left, reverse_lane);
        left = _mm256_permute2x128_si256(left, left, 1);
        const auto mask = static_cast<std::uint32_t>(_mm256_movemask_epi8(_mm256_cmpeq_epi8(left, right)));
        if (mask != UINT32_MAX)
            return matched + static_cast<int>(std::countr_zero(static_cast<std::uint32_t>(~mask)));
        matched += 32;
    }
    return matched + extend_palindrome_word(data, l - matched, r + matched, n);
}
inline bool palindrome_avx2_available() {
    static const bool available = __builtin_cpu_supports("avx2");
    return available;
}
}
#endif
#endif

'''
needle='        while (l >= 0 && r < n && s[l] == s[r]) { --l; ++r; length += 2; }'
assert base.count(needle)==1
for mode in ['word','avx2']:
    helper=word+(avx if mode=='avx2' else '')
    call='matched += reinsirk::detail::extend_palindrome_word(s.data(), l - matched, r + matched, n);'
    if mode=='avx2':
        call='''#if '''+condition+'''
                if (limit - matched >= 64 && reinsirk::detail::palindrome_avx2_available())
                    matched += reinsirk::detail::extend_palindrome_avx2(s.data(), l - matched, r + matched, n);
                else
#endif
                    matched += reinsirk::detail::extend_palindrome_word(s.data(), l - matched, r + matched, n);'''
    body='''        if constexpr (std::is_same_v<Sequence, std::string>) {
            const int limit = std::min(l + 1, n - r);
            const int short_limit = std::min(16, limit);
            int matched = 0;
            // 短い一致では通常比較だけ。16組一致してからブロック比較へ進む。
            while (matched < short_limit && s[l - matched] == s[r + matched]) ++matched;
            if (matched == short_limit && matched < limit) {
                '''+call+'''
            }
            l -= matched; r += matched; length += matched * 2;
        } else {
'''+needle+'''
        }'''
    text=base.replace('#include <algorithm>','#include <algorithm>\n'+includes)
    if mode=='avx2':text=text.replace('#include <vector>','#include <vector>\n#if '+condition+'\n#include <immintrin.h>\n#endif')
    text=text.replace('#ifndef SIRKIT_PALINDROMIC_LENGTHS_DEFINED',helper+'#ifndef SIRKIT_PALINDROMIC_LENGTHS_DEFINED').replace(needle,body)
    (D/('long_'+mode+'.hpp')).write_text(text)
print('2 candidate headers written; no compilation or measurement')
