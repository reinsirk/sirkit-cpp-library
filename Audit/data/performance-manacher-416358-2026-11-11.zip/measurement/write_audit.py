# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_manacher_416358')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
whole=load(D/'final_summary.json');typed=load(D/'typed_summary.json');fixtures=load(D/'agent_fixtures/fixtures.json');fm={r['name']:r for r in fixtures}
for name in ['Verify/current/drivers/manacher_main.cpp','Verify/current/common/fast_io.hpp']:
 assert (R/name).read_bytes()==(D/'before'/name).read_bytes()
old=(D/'before/String/Manacher.cpp').read_text();new=(R/'String/Manacher.cpp').read_text();begin='#ifndef SIRKIT_PALINDROME_RADII_DEFINED';end='#ifndef SIRKIT_PALINDROMIC_LENGTHS_DEFINED';assert old[old.index(begin):old.index(end)]==new[new.index(begin):new.index(end)]
profiles=sorted((D/'profiles/runs').glob('*.json'));assert profiles;profile=load(profiles[-1]);assert profile['counts']=={'LOCAL_SAMPLE_PASS':10}
finaltests=[r for r in load(D/'tests.json')if r['test']!='string_math_allocation_test']+load(D/'allocation_tests.json')
key=['official_max_random_00','official_max_random_01','official_all_same_00','custom_500000_binary','custom_500000_alternating','custom_500000_long_palindrome']
audit={
 'date':'2026-11-11','library':'String/Manacher.cpp','decision':'accept_standard_Cpp23_center_skip','required_resubmission':['Verify/current/submissions/manacher.cpp'],
 'online':{'url':'https://judge.yosupo.jp/submission/416358','status':'AC','time_ms':30,'memory_bytes':12206080,'evidence':'Audit/online-manacher-416358-2026-11-11.json','scope':'変更前の提出本文を取得し本体/main/共通IOを空白等のみ除いて照合。現在の高速化版のオンライン結果ではない。'},
 'changes':['PalindromicLengthsは2n-1個の文字上/文字間の中心を一体化して出力vectorへ直接保存する。','奇数/偶数の中間半径vectorと出力への詰替えを省く。非空入力で確保回数は3回から1回、保持int数は約4nから2nへ。','既知回文内で反射した長さが右端に届かなければ、不一致まで確定しているので再比較しない。','返却要素数はsize_tで計算し、max_sizeによる倍化前の容量上限を常に確認する。','PalindromeRadiiと各照会/assignの実装・API・強い例外保証は維持。main/共通IOは無変更。'],
 'correctness_invariants':['centerは元の文字上と文字間を0..2n-2で交互に番号付けする。長さは元の列の要素数で保存し、偶数centerは奇数長、奇数centerは偶数長。','既知回文のmiddle=L+R、right=2R、length=R-L+1。center<rightなら反射先middle-(center-middle)は非負かつ処理済み。','available=right-center+1は当該中心と同じ長さparity。reflected<availableなら不一致まで箱内で確定しコピーだけでよい。','次に比較する位置はl=(center+1-length)/2-1、r=(center+length+1)/2。l>=-1、r<=nで、比較はl>=0かつr<nの時だけ。','n<INT_MAXかつ返却vectorの容量検査により倍化中心、length+=2、center+length+1、end計算の範囲を保つ。','比較成功は右端を進め、失敗は中心ごと定数回なのでO(n)。==は一貫した同値関係、入力は保持/変更しない。'],
 'source_hashes':{'before':sha(D/'before/String/Manacher.cpp'),'after':sha(R/'String/Manacher.cpp'),'submitted_after':sha(R/'Verify/current/submissions/manacher.cpp'),'main':sha(R/'Verify/current/drivers/manacher_main.cpp'),'IO':sha(R/'Verify/current/common/fast_io.hpp')},
 'fixed_conditions':{'main_unchanged':True,'IO_unchanged':True,'skip_runtime_checks':True,'extra_optimization_pragmas':False,'query_batching_or_problem_specific_dispatch':False,'submitted_bytes':(R/'Verify/current/submissions/manacher.cpp').stat().st_size,'max_submission_bytes':512*1024},
 'measurement':{'cpu':'Intel Core i9-14900K、CPU 12/core 6 P-Core、sibling CPU 13、max 6GHz','E_Core_considered':False,'compilers':{'gcc':'/usr/bin/g++ 15.2.0','clang':'/usr/bin/clang++ 21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'},'flags':['-std=c++23','-O2'],'march_native':False,'affinity':'taskset -c 12','lock':'/tmp/sirkit_performance_cpu12.lock','ASLR':'各試験子プロセスのみsetarch x86_64 -R、システム設定変更なし。','order':'before/control/candidateを決定的にシャッフルし同じactiveパスで実行。controlはbeforeと同じ実行ファイル。','whole_verify':'固定main/IOの入力から出力/破棄までのuser+system時間。候補中央値とbefore/control pooled中央値を比較。','repetitions':9,'fixtures':len(fixtures),'final_runs':len(load(D/'final_raw.json')),'outputs_identical':True,'official_revision':'73876f1cbcf082d2b22722924b924d3d65a2f00e','fixture_scope':'公式固定生成器24入力と自作26入力。自作は小入力/500000/制約外1000000を含む。オンライン現行ケースのバイト列一致は主張しない。','selected_results':[{**r,'reduction_percent':100*(1-r['ratios']['center_skip'])}for r in whole if r['case']in key],'large_worst_ratios':{cc:max(r['ratios']['center_skip']for r in whole if r['compiler']==cc and fm[r['case']]['n']>=200000)for cc in ['gcc','clang']},'small_input_caveat':'小入力全体時間は起動時間の影響で増減する。全条件の非退行を保証する主張はしない。','compiled_final_equivalence':load(D/'final_builds.json')},
 'generic_API_measurement':{'operations':{'0':'PalindromicLengths(string)','1':'PalindromicLengths(vector<int64_t>)','2':'PalindromicLengths(vector<bool>)','3':'PalindromicLengths(string_view)','4':'PalindromeRadii construction','5':'PalindromeRadii assign'},'sizes':[32,4096,500000],'shapes':{'0':'all_same','1':'periodic3','2':'binary_random'},'repetitions':7,'runs':len(load(D/'typed_raw.json')),'scope':'入力生成を除き、結果領域の確保/構築/破棄を含む反復呼出しのsteady_clock時間。Verify全体と区別。','output_checksums_identical':True,'large_wrapper_ratios':{cc:[r for r in typed if r['compiler']==cc and r['n']==500000 and r['operation']<4]for cc in ['gcc','clang']},'unchanged_public_radii':'実装本文は完全同一。APIを単独にした両コンパイラの.textもbefore/after一致。','isolated_code_proof':load(D/'isolated_radii.json'),'mixed_binary_caveat':'全APIを混ぜたベンチではClangのbinaryで構築+6.1%・assign+5.2%の差がある。一方API単独の機械語は一致し、変更対象は返却長配列の経路のみ。混在プログラムではインライン化/配置の影響があり、すべての呼出し方で同じ速度とは主張しない。'},
 'memory':{'live_result_and_auxiliary_ints':'変更前は奇数n+偶数n+出力2n-1、変更後は出力2n-1のみ。','measured_peak':load(D/'memory.json'),'method':'/usr/bin/timeが小さい親からexecすることで、Python親のfork時RSSの床を避けた別計測。','warning':'final_raw.jsonのru_maxrssはPython親のfork前RSS約40MBの床を含むため、今回のメモリ比較には使わない。'},
 'verification':{'final_tests':finaltests,'allocation_snapshot_note':'tests.json内の確保試験2件は境界追加前。allocation_tests.jsonの2件を最終結果とする。','sanitizers':'GCC/Clang×checked/SKIPの独立文字列参照とSA/LCP長列参照はASan/UBSan。global newで失敗注入する確保試験はサニタイザなし。','independent_oracle':'正順+一意区切り+逆順のSA/LCPと区間最小値から全中心をO(n log n)で求める。短列は全中心の直接展開で独立照合。','large_reference':'各設定130 cases/9234184 checks。500000の同値/交互/全256バイト回文/内部変更、499999、整数極値・bool・noncopyable・explicit-bool proxy・例外・巨大長。','allocation_result':'各コンパイラ2343 checks / 69 injected failures / live_delta=0。size()がintを返すINT_MAX-1の仮想列も確保失敗まで要素アクセスせず扱う。','quick_naive_candidates':load(D/'quick_tests.json'),'profiles':{'run_file':'profiles/runs/'+profiles[-1].name,'counts':profile['counts'],'scope':'通常/GCC/Clang/速度優先GCC/速度優先Clangの提出用コードと使用例。'}},
 'rejected_candidates':[{'names':['indexed','direct_two','direct_center','two_skip','radii_skip','center_halves'],'reason':'配列生成だけの変更、奇偶別直接出力、既知値省略なし、half位置の32bit計算等を比較。center_skipを大規模全体性能と簡潔さで選択。PalindromeRadiiのskip変更はランダム条件に後退があり採用しない。'},{'names':['long_word','long_avx2'],'reason':'長い一致だけ逆方向の8byte/32byte比較へ進む案も試したが、標準center_skipよりランダム列で遅い。SIMD/CPU判定/専用includeは現行本体に導入しない。'}],
 'documentation':'APIと使い方は維持。比較が同値関係である前提だけ明記し、性能履歴はDocument/READMEに追加しない。',
 'license':'採用コード/独立テスト/測定補助は独自CC0-1.0。公式外部生成器(Apache-2.0)の本文はライブラリ/証跡ZIPへ収録せず、固定URL/ハッシュ/再生成計画だけ保存。',
 'evidence_zip':'Audit/data/performance-manacher-416358-2026-11-11.zip'
}
p=R/'Audit/performance-manacher-416358-2026-11-11.json';p.write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n');files=[]
for f in D.iterdir():
 if f.is_file() and f.suffix in ['.json','.py','.hpp','.log']:files.append((f,'measurement/'+f.name))
for folder in ['agent_fixtures','agent_simd','agent_tests']:
 for f in (D/folder).iterdir():
  if f.is_file()and f.suffix in ['.json','.py','.hpp','.cpp']:files.append((f,folder+'/'+f.name))
for f in (D/'profiles').rglob('*.json'):files.append((f,'profiles/'+str(f.relative_to(D/'profiles'))))
for name in ['416358.cpp','quick_test.cpp','typed_benchmark.cpp','isolated_radii.cpp','before/String/Manacher.cpp','before/Verify/current/submissions/manacher.cpp','before/Verify/current/drivers/manacher_main.cpp','before/Verify/current/common/fast_io.hpp']:
 files.append((D/name,name))
for name in ['String/Manacher.cpp','Document/manacher.md','Verify/current/submissions/manacher.cpp','Verify/current/drivers/manacher_main.cpp','Verify/current/tests/manacher_independent_test.cpp','Verify/current/tests/string_algorithms_reference_test.cpp','Verify/current/tests/string_math_allocation_test.cpp','Audit/online-manacher-416358-2026-11-11.json','Audit/performance-manacher-416358-2026-11-11.json']:
 files.append((R/name,'after/'+name))
with zipfile.ZipFile(R/audit['evidence_zip'],'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f,name in sorted(files,key=lambda v:v[1]):z.writestr(zipfile.ZipInfo(name,(2026,11,11,0,0,0)),f.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
print('audit evidence',len(files),(R/audit['evidence_zip']).stat().st_size,'bytes')
