# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,shutil
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_manacher_416358');a=json.loads((D/'416358.json').read_text());(D/'416358.cpp').write_text(a['source'])
def norm(s):return '\n'.join(x.rstrip() for x in s.replace('\r\n','\n').splitlines() if x.strip() and not x.startswith('// Submission:'))
assert norm(a['source'])==norm((R/'Verify/current/submissions/manacher.cpp').read_text())
for n in ['String/Manacher.cpp','Verify/current/submissions/manacher.cpp','Verify/current/drivers/manacher_main.cpp','Verify/current/common/fast_io.hpp','Verify/current/groups/expansion_20261031.json','Verify/current/judgements.json','Distribution/manifest.json']:
 p=D/'before'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,p)
base=(R/'String/Manacher.cpp').read_text();(D/'base.hpp').write_text(base)
pos=base.index('    const PalindromeRadii radii(s);');end=base.index('\n}\n#endif',pos)
check='''    if (s.size() >= static_cast<std::size_t>(std::numeric_limits<int>::max()))
        throw std::length_error("PalindromicLengths: sequence too long");
    const int n = static_cast<int>(s.size());
    if (n == 0) return {};
    std::vector<int> result(s.size() * 2 - 1);
'''
two=check+'''    int left = 0, right = -1;
    for (int i = 0; i < n; ++i) {
        int radius = i <= right ? std::min(right - i + 1,
            (result[std::size_t{2} * (left + (right - i))] + 1) / 2) : 1;
        while (radius <= i && radius < n - i && s[i - radius] == s[i + radius]) ++radius;
        result[std::size_t{2} * i] = radius * 2 - 1;
        if (i + radius - 1 > right) { left = i - radius + 1; right = i + radius - 1; }
    }
    left = 0; right = -1;
    for (int i = 1; i < n; ++i) {
        int radius = i <= right ? std::min(right - i + 1,
            result[std::size_t{2} * (left + (right - i) + 1) - 1] / 2) : 0;
        while (radius < i && radius < n - i && s[i - radius - 1] == s[i + radius]) ++radius;
        result[std::size_t{2} * i - 1] = radius * 2;
        if (i + radius - 1 > right) { left = i - radius; right = i + radius - 1; }
    }
    return result;'''
one=check+'''    std::size_t middle = 0, right = 0;
    for (std::size_t center = 0; center < result.size(); ++center) {
        int length = (center & 1) == 0 ? 1 : 0;
        if (center < right)
            length = std::min(result[middle - (center - middle)], static_cast<int>(right - center + 1));
        int l = static_cast<int>((center - static_cast<std::size_t>(length) + 1) / 2) - 1;
        int r = static_cast<int>((center + static_cast<std::size_t>(length) + 1) / 2);
        while (l >= 0 && r < n && s[l] == s[r]) { --l; ++r; length += 2; }
        result[center] = length;
        const auto end = center + static_cast<std::size_t>(length) - 1;
        if (end > right) { middle = center; right = end; }
    }
    return result;'''
(D/'direct_two.hpp').write_text(base[:pos]+two+base[end:]);(D/'direct_center.hpp').write_text(base[:pos]+one+base[end:])
# Separate return allocation costs from the Manacher redesign.
indexed=base.replace('    std::vector<int> result;\n    result.reserve(s.size() * 2 - 1);','    std::vector<int> result(s.size() * 2 - 1);').replace('        result.push_back(radii.odd[i] * 2 - 1);','        result[std::size_t{2} * i] = radii.odd[i] * 2 - 1;').replace('        if (i + 1 < radii.size()) result.push_back(radii.even[i + 1] * 2);','        if (i + 1 < radii.size()) result[std::size_t{2} * i + 1] = radii.even[i + 1] * 2;')
(D/'indexed.hpp').write_text(indexed)
