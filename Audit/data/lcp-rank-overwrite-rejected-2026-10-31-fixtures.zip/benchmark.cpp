#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include HEADER
std::uint64_t hash(const std::vector<int>& a){std::uint64_t h=1469598103934665603ULL;for(int x:a)h=(h^static_cast<std::uint32_t>(x))*1099511628211ULL;return h;}
[[gnu::noinline]] std::vector<int> calculate(const std::string&s,const std::vector<int>&sa){return LCPArray(s,sa);}
int main(int argc,char**argv){if(argc!=3)return 1;std::ifstream in(argv[1],std::ios::binary);std::uint64_t n=0,want=0;in.read(reinterpret_cast<char*>(&n),8);std::string s(static_cast<std::size_t>(n),' ');std::vector<int> sa(static_cast<std::size_t>(n));in.read(s.data(),static_cast<std::streamsize>(n));in.read(reinterpret_cast<char*>(sa.data()),static_cast<std::streamsize>(n*sizeof(int)));in.read(reinterpret_cast<char*>(&want),8);if(!in)return 2;auto test=calculate(s,sa);if(hash(test)!=want)return 3;for(int i=0;i<3;++i)test=calculate(s,sa);int loops=std::stoi(argv[2]);std::uint64_t checksum=0;const auto begin=std::chrono::steady_clock::now();for(int i=0;i<loops;++i){asm volatile("" ::: "memory");auto result=calculate(s,sa);checksum+=static_cast<std::uint64_t>(result[static_cast<std::size_t>(i)%result.size()]);}const auto end=std::chrono::steady_clock::now();auto ns=std::chrono::duration_cast<std::chrono::nanoseconds>(end-begin).count();std::cout<<ns<<' '<<loops<<' '<<checksum<<' '<<want<<'\n';}
