# LCP rank初期化省略候補（未採用）の再現資料

正式ソースは変更していません。候補は `candidate.hpp`、比較元は `baseline.hpp` です。`verify_*.cpp` は同じ既存main・高速入出力を含みます。

入力データと実行バイナリはZIPへ重複収録していません。入力は固定seedの `fixture.cpp` で再生でき、全 `.bin/.in/.out` のSHAは `run_manifest.json` にあります。`.bin` は今回のx86-64環境（int32・little endian）の測定用形式です。

```sh
mkdir -p inputs
taskset -c 0 /usr/bin/g++ -std=c++23 -O2 -DSKIP_RUNTIME_CHECKS fixture.cpp -o fixture
taskset -c 0 ./fixture inputs
taskset -c 0 python3 build.py
```

`build.py` はGCC15.2・Clang21.1.8の実行ファイルを作り、独立参照・例外・所有の16条件を確認します。ASAN/UBSANは `detect_leaks=0`、確保数の復元は別に確認します。

速度測定は、他のビルド・検査を止め、CPU12が専有できる時間に限って実行します。`measure.py` は固定入力を使い、同じbaselineバイナリの別呼び出しをcontrolとして含めます。

```sh
taskset -c 12 python3 measure.py
```

`raw.json` に1440条件、`summary.json` に5反復の中央値があります。LCP単体は内部の経過時間を使います。実mainは入力ファイルのopen・プロセス起動・I/Oを含む外部経過時間です。同一バイナリにも二峰性があり、大きく見える比率をそのまま改善とは扱いません。今回は大規模・実mainの改善が一貫せず、空列の確保も増えるため未採用です。
