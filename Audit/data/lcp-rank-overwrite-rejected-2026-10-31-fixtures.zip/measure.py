# SPDX-License-Identifier: CC0-1.0
import hashlib,json,os,pathlib,random,subprocess,time
p=pathlib.Path(__file__).parent;os.sched_setaffinity(0,{12});rows=[]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
manifest=dict(cpu=12,source_files={f.name:sha(f)for f in sorted(p.glob('*'))if f.is_file()and f.suffix in('.cpp','.hpp','.py')},builds_sha256=sha(p/'builds.json'),inputs={f.name:sha(f)for f in sorted((p/'inputs').glob('*'))},compilers={cc:subprocess.run([cc,'--version'],capture_output=True,text=True,check=True).stdout for cc in('/usr/bin/g++','/usr/bin/clang++')},method='Exclusive CPU12. Immutable pre-generated input, no compilation/correctness/background aggregation during raw; kernel memory-clobber before call, no source store; warmup3. Control is a separately scheduled invocation of the identical baseline binary. Driver is exact existing main+fastIO; wall time includes startup and I/O equally.')
(p/'run_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
configs=['gcc_default','gcc_native','clang_default','clang_native'];cases=[(n,k)for n in(16,1024,100000,1000000)for k in range(3)]
rng=random.Random(20261101)
for repeat in range(5):
 jobs=[(kind,config,n,k)for kind in('kernel','verify')for config in configs for n,k in cases];rng.shuffle(jobs)
 for kind,config,n,k in jobs:
  labels=['baseline','control','candidate'];rng.shuffle(labels)
  checksum=None
  for label in labels:
   variant='baseline'if label=='control'else label
   exe=p/(('benchmark_'if kind=='kernel'else'verify_')+config+'_'+variant)
   command=[str(exe)];expected=(p/'inputs'/f'{n}_{k}.out').read_bytes()
   if kind=='kernel':command += [str(p/'inputs'/f'{n}_{k}.bin'),str({16:200000,1024:10000,100000:100,1000000:6}[n])]
   begin=time.perf_counter_ns()
   with (p/'inputs'/f'{n}_{k}.in').open('rb')as input_file:
    r=subprocess.run(command,stdin=input_file if kind=='verify'else subprocess.DEVNULL,capture_output=True,timeout=20)
   elapsed=time.perf_counter_ns()-begin
   assert r.returncode==0,(command,r.returncode,r.stderr)
   item=dict(repeat=repeat,kind=kind,config=config,n=n,distribution=('random','uniform','periodic')[k],label=label,command=command,binary_sha256=sha(exe),elapsed_wall_ns=elapsed,stdout=r.stdout.decode(),stderr=r.stderr.decode())
   if kind=='kernel':
    ns,loops,got,want=map(int,r.stdout.split());item.update(kernel_elapsed_ns=ns,loops=loops,ns_per_call=ns/loops,checksum=got,reference_lcp_hash=want)
    if checksum is None:checksum=(got,want)
    assert checksum==(got,want)
   else:assert r.stdout==expected,(kind,config,n,k,label,r.stdout,expected)
   rows.append(item)
 (p/'raw.json').write_text(json.dumps(rows,indent=2)+'\n');print('repeat',repeat,'rows',len(rows),flush=True)
(p/'raw.json').write_text(json.dumps(rows,indent=2)+'\n');print('RAW COMPLETE',len(rows),flush=True)
