from pathlib import Path
import hashlib,json
p=Path(__file__).parent;root=Path('/home/reinsirk/Atcoder_Env');base=(root/'String/Suffix_Array.cpp').read_text();old='    std::vector<int> rank(s.size());';assert base.count(old)==1
candidate=base.replace('#include <limits>','#include <limits>\n#include <memory>').replace(old,'    auto rank = std::make_unique_for_overwrite<int[]>(s.size());')
(p/'baseline.hpp').write_text(base);(p/'candidate.hpp').write_text(candidate)
submission=(root/'Verify/current/submissions/suffix_array_substrings.cpp').read_text();assert submission.count(base)==1
(p/'verify_baseline.cpp').write_text(submission);(p/'verify_candidate.cpp').write_text(submission.replace(base,candidate))
manifest=dict(baseline_sha256=hashlib.sha256(base.encode()).hexdigest(),candidate_sha256=hashlib.sha256(candidate.encode()).hexdigest(),submission_sha256=hashlib.sha256(submission.encode()).hexdigest(),driver_sha256=hashlib.sha256((root/'Verify/current/drivers/suffix_array_substrings_main.cpp').read_bytes()).hexdigest(),io_sha256=hashlib.sha256((root/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest())
(p/'source_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
