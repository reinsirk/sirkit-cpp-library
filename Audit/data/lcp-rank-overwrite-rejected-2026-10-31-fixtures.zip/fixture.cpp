#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <numeric>
#include <random>
#include <string>
#include <vector>
#include "baseline.hpp"
std::uint64_t hash(const std::vector<int>& a){std::uint64_t h=1469598103934665603ULL;for(int x:a)h=(h^static_cast<std::uint32_t>(x))*1099511628211ULL;return h;}
int main(int argc,char**argv){if(argc!=2)return 1;std::mt19937_64 rng(123456789);for(std::size_t n:{16,1024,100000,1000000})for(int kind=0;kind<3;++kind){std::string s(n,'a');for(std::size_t i=0;i<n;++i)if(kind==0)s[i]=static_cast<char>('a'+rng()%26);else if(kind==2)s[i]=static_cast<char>('a'+i%7);auto sa=SuffixArray(s);std::vector<int> want(n-1);for(std::size_t k=0;k+1<n;++k){int i=sa[k],j=sa[k+1],length=0;if(kind==1||(kind==2&&i%7==j%7))length=static_cast<int>(n)-std::max(i,j);else while(i+length<static_cast<int>(n)&&j+length<static_cast<int>(n)&&s[i+length]==s[j+length])++length;want[k]=length;}if(LCPArray(s,sa)!=want)return 2;const auto prefix=std::string(argv[1])+"/"+std::to_string(n)+"_"+std::to_string(kind);std::ofstream out(prefix+".bin",std::ios::binary);auto m=static_cast<std::uint64_t>(n),h=hash(want);out.write(reinterpret_cast<const char*>(&m),8);out.write(s.data(),static_cast<std::streamsize>(n));out.write(reinterpret_cast<const char*>(sa.data()),static_cast<std::streamsize>(n*sizeof(int)));out.write(reinterpret_cast<const char*>(&h),8);std::ofstream text(prefix+".in");text<<s<<'\n';std::uint64_t answer=n*(n+1)/2;for(int x:want)answer-=static_cast<unsigned int>(x);std::ofstream expected(prefix+".out");expected<<answer<<'\n';std::cout<<n<<' '<<kind<<' '<<h<<' '<<answer<<'\n';}}
