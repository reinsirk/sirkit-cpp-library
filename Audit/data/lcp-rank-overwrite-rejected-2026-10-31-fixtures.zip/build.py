import hashlib,json,os,pathlib,subprocess,time
p=pathlib.Path(__file__).parent;os.sched_setaffinity(0,{0});rows=[]
for compiler,cc in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for native in (False,True):
  flags=['-std=c++23','-O2']+(['-march=native']if native else[])
  for variant in ('baseline','candidate'):
   name=compiler+('_native'if native else'_default')+'_'+variant
   for kind in ('benchmark','verify'):
    output=p/(kind+'_'+name);source=p/('benchmark.cpp'if kind=='benchmark'else'verify_'+variant+'.cpp');cmd=cc+flags+(['-DSKIP_RUNTIME_CHECKS','-DHEADER="'+variant+'.hpp"']if kind=='benchmark'else[])+[str(source),'-o',str(output)]
    b=subprocess.run(cmd,capture_output=True,text=True,timeout=120);assert b.returncode==0,b.stderr;rows.append(dict(kind=kind,name=name,command=cmd,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(output.read_bytes()).hexdigest()))
 for variant in ('baseline','candidate'):
  for skip in (False,True):
   name=compiler+'_'+variant+('_skip'if skip else'_checked');output=p/('test_'+name);cmd=cc+['-std=c++23','-O2','-DHEADER="'+variant+'.hpp"']+(['-DSKIP_RUNTIME_CHECKS']if skip else[])+[str(p/'correctness.cpp'),'-o',str(output)];b=subprocess.run(cmd,capture_output=True,text=True,timeout=120);assert b.returncode==0,b.stderr;r=subprocess.run([str(output)],capture_output=True,text=True,timeout=60);assert r.returncode==0,(name,r.stdout,r.stderr,r.returncode);rows.append(dict(kind='correctness',name=name,command=cmd,stdout=r.stdout,status='PASS'))
  for skip in (False,True):
   name=compiler+'_'+variant+('_skip'if skip else'_checked')+'_asan';output=p/('test_'+name);cmd=cc+['-std=c++23','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-DHEADER="'+variant+'.hpp"']+(['-DSKIP_RUNTIME_CHECKS']if skip else[])+[str(p/'correctness.cpp'),'-o',str(output)];b=subprocess.run(cmd,capture_output=True,text=True,timeout=120);assert b.returncode==0,b.stderr;r=subprocess.run([str(output)],capture_output=True,text=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0'),timeout=60);assert r.returncode==0,(name,r.stdout,r.stderr,r.returncode);rows.append(dict(kind='correctness',name=name,command=cmd,stdout=r.stdout,status='PASS'))
 (p/'builds.json').write_text(json.dumps(rows,indent=2)+'\n')
print(len(rows),'build/validation rows PASS',flush=True)
