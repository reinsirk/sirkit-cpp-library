#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <new>
#include <numeric>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
#include HEADER
static std::int64_t live=0;static int fail_after=-1;static std::uint64_t allocations=0;
void* operator new(std::size_t n){if(fail_after==0)throw std::bad_alloc();if(fail_after>0)--fail_after;void*p=std::malloc(n?n:1);if(!p)throw std::bad_alloc();++live;++allocations;return p;}
void operator delete(void*p)noexcept{if(p){--live;std::free(p);}}
void operator delete(void*p,std::size_t)noexcept{::operator delete(p);}
void*operator new[](std::size_t n){return ::operator new(n);}
void operator delete[](void*p)noexcept{::operator delete(p);}
void operator delete[](void*p,std::size_t)noexcept{::operator delete(p);}
template<class S>bool verify(const S&s){std::vector<int>sa(s.size());std::iota(sa.begin(),sa.end(),0);std::sort(sa.begin(),sa.end(),[&](int a,int b){return std::lexicographical_compare(s.begin()+a,s.end(),s.begin()+b,s.end());});auto got=LCPArray(s,sa);std::vector<int>want(s.size()?s.size()-1:0);for(std::size_t i=0;i+1<sa.size();++i){int a=sa[i],b=sa[i+1],k=0;while(a+k<static_cast<int>(s.size())&&b+k<static_cast<int>(s.size())&&s[a+k]==s[b+k])++k;want[i]=k;}return got==want;}
struct ThrowSequence{const std::string&s;mutable int budget;std::size_t size()const{return s.size();}char operator[](int i)const{if(--budget==0)throw 17;return s[static_cast<std::size_t>(i)];}};
int main(){std::mt19937_64 random(1234);std::uint64_t checks=0;for(int trial=0;trial<6000;++trial){std::size_t n=random()%128;std::string s(n,'a');std::vector<int>v(n);for(std::size_t i=0;i<n;++i){s[i]=static_cast<char>(random()%256);v[i]=static_cast<int>(random()%17)-8;}if(!verify(s)||!verify(v))return 1;checks+=2;}
for(int n:{0,1,2,63,64,65,127}){if(!verify(std::string(static_cast<std::size_t>(n),'x')))return 2;++checks;}
std::string s="abracadabraabracadabra";auto sa=SuffixArray(s);const auto expected=LCPArray(s,sa);auto copy=expected;if(!copy.empty()){copy[0]^=1;if(copy==expected)return 3;}auto moved=std::move(copy);(void)moved;
const auto before_live=live;int failures=0;for(int point=0;point<8;++point){fail_after=point;try{auto result=LCPArray(s,sa);if(result!=expected)return 4;}catch(const std::bad_alloc&){++failures;}fail_after=-1;if(live!=before_live||s!="abracadabraabracadabra"||sa!=SuffixArray(s))return 5;}
try{auto unused=LCPArray(ThrowSequence{s,1},sa);(void)unused;return 6;}catch(int value){if(value!=17)return 7;}if(live!=before_live)return 8;
#ifndef SKIP_RUNTIME_CHECKS
for(auto bad:std::vector<std::vector<int>>{{0},{0,0},{0,2},{-1,1}}){bool rejected=false;try{auto result=LCPArray(std::string("ab"),bad);(void)result;}catch(const std::exception&){rejected=true;}if(!rejected)return 9;}
#endif
std::vector<int>empty;auto prior=allocations;{auto out=LCPArray(std::string{},empty);if(!out.empty())return 10;}auto zero_allocations=allocations-prior;
std::cout<<"PASS checks="<<checks<<" allocation_failures="<<failures<<" live_restored=1 empty_allocations="<<zero_allocations<<'\n';}
