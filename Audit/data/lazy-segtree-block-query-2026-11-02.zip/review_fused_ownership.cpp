// SPDX-License-Identifier: CC0-1.0
#include SOURCE
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <memory>
#include <random>
constexpr std::uint64_t mod=1000000007;
int live=0;
struct Rule { std::uint64_t a,b;Rule(std::uint64_t x,std::uint64_t y):a(x),b(y){++live;}~Rule(){--live;} };
struct Tag { std::shared_ptr<const Rule> rule;Tag()=delete;Tag(std::uint64_t a,std::uint64_t b):rule(std::make_shared<const Rule>(a,b)){} };
std::uint64_t op(const std::uint64_t&a,const std::uint64_t&b){return (a+b)%mod;}
std::uint64_t e(){return 0;}
Tag compose(const Tag&newer,const Tag&older){return Tag(newer.rule->a*older.rule->a%mod,(newer.rule->a*older.rule->b+newer.rule->b)%mod);}
Tag id(){return Tag(1,0);}
std::uint64_t mapping(const Tag&f,const std::uint64_t&v,std::size_t width){if(!width||(width&(width-1)))std::abort();return (f.rule->a*v+f.rule->b*width)%mod;}
int main(){
 std::mt19937 rng(14137);unsigned checks=0;
 for(int n:{1,2,3,7,8,9,31,32,33,65}){
  std::vector<std::uint64_t> ref(n);for(int i=0;i<n;++i)ref[i]=i+1;
  lazy_segtree<std::uint64_t,op,e,Tag,mapping,compose,id> t(ref);
  for(int step=0;step<60;++step){
   int l=rng()%n,r=l+1+rng()%(n-l);std::uint64_t a=rng()%5,b=rng()%11;
   t.apply(l,r,Tag(a,b));for(int i=l;i<r;++i)ref[i]=(a*ref[i]+b)%mod;
   for(int rep=0;rep<20;++rep){int x=rng()%(n+1),y=rng()%(n+1);if(x>y)std::swap(x,y);std::uint64_t want=0;for(int i=x;i<y;++i)want=(want+ref[i])%mod;if(t.prod(x,y)!=want)std::abort();++checks;}
   if(t.values()!=ref)std::abort();++checks;
   auto copy=t;const auto total=copy.all_prod();t.apply(0,n,Tag(2,3));for(auto&v:ref)v=(2*v+3)%mod;if(copy.all_prod()!=total)std::abort();++checks;
  }
 }
 if(live!=0)std::abort();
 std::printf("PASS owning nondefault F, noncommutative composition, physical-width mapping, copies: %u checks\n",checks);
}
