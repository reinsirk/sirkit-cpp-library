// SPDX-License-Identifier: CC0-1.0
#include SOURCE
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <type_traits>
struct S {
 std::int64_t sum;
 S()=delete;
 explicit S(std::int64_t x):sum(x){}
 S(const S&)=default;
 S(S&&)=delete;
 S&operator=(const S&)=default;
 S&operator=(S&&)=default;
};
static_assert(std::is_copy_constructible_v<S>);
static_assert(!std::is_move_constructible_v<S>);
S op(const S&a,const S&b){return S(a.sum+b.sum);}
S e(){return S(0);}
S mapping(const int&f,const S&v,std::size_t length){return S(v.sum+f*static_cast<std::int64_t>(length));}
int compose(const int&f,const int&g){return f+g;}
int id(){return 0;}
int main(){
 for(int n:{0,1,2,3,7,8,9,31,32,33,65}){
  lazy_segtree<S,op,e,int,mapping,compose,id> tree(n);
  std::vector<std::int64_t> values(n);
  for(int step=0;step<40;++step){
   if(n){int l=(step*11)%n,r=l+1+(step*7)%(n-l);tree.apply(l,r,step%5);for(int i=l;i<r;++i)values[i]+=step%5;tree.set(step%n,S(step));values[step%n]=step;}
   for(int l=0;l<=n;++l)for(int r=l;r<=n;++r){std::int64_t want=0;for(int i=l;i<r;++i)want+=values[i];if(tree.prod(l,r).sum!=want)std::abort();}
  }
 }
 std::puts("PASS copy-only S: range mapping/set/all query intervals");
}
