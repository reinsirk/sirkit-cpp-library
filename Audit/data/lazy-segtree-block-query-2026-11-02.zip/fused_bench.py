from pathlib import Path
import sys,subprocess,json,random,statistics,shutil,os,time,hashlib
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_lazy_speed_20261102');s=(D/'before.hpp').read_text();g=(D/'review_query_guarded.hpp').read_text();a=s.index('    void act(');b=s.index('    void push_path(',a)
fused='''    void map_value(std::size_t p, const F& f, std::size_t length) {
        if constexpr (std::is_invocable_r_v<S, decltype(mapping), const F&, const S&>)
            data_[p] = std::invoke(mapping, f, data_[p]);
        else data_[p] = std::invoke(mapping, f, data_[p], length);
    }
    void store_update(std::size_t p, const F& f) {
        if (pending_[p]) lazy_[p] = std::invoke(composition, f, lazy_[p]);
        else { lazy_[p] = f; pending_[p] = 1; }
    }
    void act(std::size_t p, const F& f, std::size_t length) {
        map_value(p, f, length);
        if (p < base_) store_update(p, f);
    }
    void push(std::size_t p, std::size_t length) {
        if (!pending_[p]) return;
        const auto child = 2 * p;
        const F& f = lazy_[p];
        map_value(child, f, length / 2);
        map_value(child + 1, f, length / 2);
        if (child < base_) {
            store_update(child, f);
            store_update(child + 1, f);
        }
        pending_[p] = 0;
    }
'''
variants={'old':s,'guarded_greedy':g,'fused':s[:a]+fused+s[b:]};ga=g.index('    void act(');gb=g.index('    void push_path(',ga);variants['fused_greedy']=g[:ga]+fused+g[gb:]
e=next(e for e in prepare_verify.collect() if e['id']=='lazy_segment_tree')
for label,source in variants.items():
 (D/f'{label}.hpp').write_text(source);data,_=prepare_verify.render(e,source_overrides={'DataStructure/Lazy_Segment_Tree.cpp':source.encode()});src=D/f'{label}.cpp';src.write_bytes(data)
 for cc,cmd0 in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:subprocess.run(['taskset','-c','2',*cmd0,'-std=c++23','-O2',str(src),'-o',str(D/f'{cc}_{label}')],check=True)
cases=[]
for family in ['random','max_random']:
 for seed in range(3):cases.append({'name':f'official_{family}_{seed}','path':str(D/f'official_{family}_{seed}.in')})
for n in [32,4096,500000]:
 for mode in ['mixed','query','update','short']:cases.append({'name':f'{n}_{mode}','path':str(D/f'input_{n}_{mode}.in')})
print('BUILT',flush=True);rs=[];rng=random.Random(785213)
for cc in ['gcc','clang']:
 for c in cases:
  for rep in range(7):
   labels=list(variants)+['control'];rng.shuffle(labels);checks=[]
   for label in labels:
    shutil.copyfile(D/f'{cc}_{"old" if label=="control" else label}',D/'active3');(D/'active3').chmod(0o700)
    with open(c['path'],'rb') as inp,open(D/'output','wb') as out:
     t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active3')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-t
    ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rs.append({'compiler':cc,'case':c['name'],'rep':rep,'label':label,'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
   assert len(set(checks))==1
  ms={l:statistics.median(x['cpu_ns'] for x in rs if x['compiler']==cc and x['case']==c['name'] and x['label']==l) for l in labels};print(cc,c['name'],{l:round(v/ms['old'],3) for l,v in ms.items()},flush=True);(D/'fused_raw.json').write_text(json.dumps(rs))
