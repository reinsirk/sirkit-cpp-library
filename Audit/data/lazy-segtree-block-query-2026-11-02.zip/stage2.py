from pathlib import Path
import sys,subprocess,json,random,statistics,shutil,os,time,hashlib
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_lazy_speed_20261102');s=(D/'before.hpp').read_text();g=(D/'greedy.hpp').read_text();pair=(D/'paired.hpp').read_text();qa=s.index('    S prod(');qb=s.index('    S all_prod()',qa);ga=g.index('    S prod(');gb=g.index('    S all_prod()',ga);pg=pair.replace(s[qa:qb],g[ga:gb]);variants={'old':s,'greedy':g,'paired_greedy':pg}
pa=s.index('    void push_boundary(');pb=s.index('    void pull_path(',pa);oldpush=s[pa:pb];pairpush=pair[pa:pair.index('    void pull_path(',pa)] if pair[pa:].startswith('    void push_boundary(') else pair[pair.index('    void push_boundary('):pair.index('    void pull_path(')]
aa=s.index('        for (std::size_t level = 1; level <= height_; ++level) {',s.index('    void apply(int l, int r'));ab=s.index('\n    }',aa);oldpull=s[aa:ab];pp=pair.index('        const unsigned a = std::countr_zero(begin)',pair.index('    void apply(int l, int r'));pq=pair.index('\n    }',pp);pairpull=pair[pp:pq]
body=oldpush[oldpush.index('{')+1:oldpush.rfind('}')]
for limit in [32,64]:
 newpush=pairpush[:pairpush.index('{')+1]+f'\n        if (r - l > {limit}) {{'+body+'            return;\n        }\n'+pairpush[pairpush.index('{')+1:]
 newpull=f'        if (end - begin > {limit}) {{\n'+oldpull+'\n            return;\n        }\n'+pairpull
 variants[f'adaptive{limit}']=pg.replace(pairpush,newpush).replace(pairpull,newpull)
e=next(e for e in prepare_verify.collect() if e['id']=='lazy_segment_tree')
for label,source in variants.items():
 (D/f'{label}.hpp').write_text(source);data,_=prepare_verify.render(e,source_overrides={'DataStructure/Lazy_Segment_Tree.cpp':source.encode()});src=D/f'{label}.cpp';src.write_bytes(data)
 for cc,cmd0 in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:subprocess.run(['taskset','-c','2',*cmd0,'-std=c++23','-O2',str(src),'-o',str(D/f'{cc}_{label}')],check=True)
G=D/'official_generator';(D/'params.h').write_text('#define N_AND_Q_MAX 500000\n#define MOD 998244353\n');cases=[]
for family,src in [('random','random.cpp'),('max_random','max_random.cpp')]:
 exe=G/('generator_'+family);subprocess.run(['taskset','-c','2','/usr/bin/g++','-std=c++23','-O2','-I',str(G),str(G/src),'-o',str(exe)],check=True)
 for seed in range(3):
  p=D/f'official_{family}_{seed}.in'
  with p.open('wb') as f:subprocess.run([str(exe),str(seed)],stdout=f,check=True)
  cases.append({'name':p.stem,'path':str(p)})
for n in [32,4096,500000]:
 for mode in ['mixed','query','update','short']:cases.append({'name':f'{n}_{mode}','path':str(D/f'input_{n}_{mode}.in')})
meta=json.loads((D/'official_metadata.json').read_text());meta['inputs']=[{'name':Path(c['path']).name,'sha256':hashlib.sha256(Path(c['path']).read_bytes()).hexdigest(),'header':Path(c['path']).open().readline().strip()} for c in cases if c['name'].startswith('official')];(D/'official_metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
print('BUILT AND INPUTS READY',flush=True);rs=[];rng=random.Random(19358)
for cc in ['gcc','clang']:
 for c in cases:
  for rep in range(7):
   labels=list(variants)+['control'];rng.shuffle(labels);checks=[]
   for label in labels:
    shutil.copyfile(D/f'{cc}_{"old" if label=="control" else label}',D/'active2');(D/'active2').chmod(0o700)
    with open(c['path'],'rb') as inp,open(D/'output','wb') as out:
     t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active2')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-t
    ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rs.append({'compiler':cc,'case':c['name'],'rep':rep,'label':label,'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
   assert len(set(checks))==1
  ms={l:statistics.median(x['cpu_ns'] for x in rs if x['compiler']==cc and x['case']==c['name'] and x['label']==l) for l in labels};print(cc,c['name'],{l:round(v/ms['old'],3) for l,v in ms.items()},flush=True);(D/'stage2_raw.json').write_text(json.dumps(rs))
