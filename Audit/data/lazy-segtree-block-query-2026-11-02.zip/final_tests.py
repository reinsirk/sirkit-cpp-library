from pathlib import Path
import subprocess,json,os,hashlib
D=Path('/tmp/sirkit_lazy_speed_20261102');R=Path.cwd();rs=[]
for cc,cmd0 in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  for name in ['lazy_segment_tree_reference_test','lazy_segment_tree_query_types_test','acl_range_api_test','acl_range_reference_test','range_structures_allocation_test']:
   src=R/'Verify/current/tests'/(name+'.cpp');exe=D/f'{cc}_{name}_{skip}';cmd=['taskset','-c','4',*cmd0,'-std=c++23','-O2','-I',str(R/'Verify/current/vendor')]
   if name!='range_structures_allocation_test':cmd+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
   if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
   cmd+=[str(src),'-o',str(exe)];subprocess.run(cmd,check=True,capture_output=True);p=subprocess.run(['taskset','-c','4',str(exe)],env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0'),capture_output=True,text=True);rs.append({'compiler':cc,'skip':skip,'test':name,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'command':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr});(D/'final_tests.json').write_text(json.dumps(rs,ensure_ascii=False,indent=2)+'\n');print(cc,skip,name,p.returncode,p.stdout.strip(),flush=True);assert p.returncode==0
