// SPDX-License-Identifier: CC0-1.0
#include SOURCE
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <random>
#include <string>
struct Word {
 std::string text;
 Word()=delete;
 explicit Word(std::string s):text(std::move(s)){}
};
Word cat(const Word&a,const Word&b){return Word(a.text+b.text);}
Word empty(){return Word("");}
Word shift(const int&f,const Word&s){auto result=s.text;for(char&c:result)c=static_cast<char>('a'+(c-'a'+f)%26);return Word(std::move(result));}
int comp(const int&f,const int&g){return (f+g)%26;}
int id(){return 0;}
bool yes(){return true;}
bool no(){return false;}
bool bmap(const bool&f,const bool&x){return f||x;}
bool bcomp(const bool&f,const bool&g){return f||g;}
int main(){
 std::mt19937 rng(13147);unsigned checks=0;
 for(int n:{1,2,3,7,8,9,16,17,33,65}){
  std::vector<Word> initial(n,Word("a"));std::vector<std::string> ref(n,"a");
  lazy_segtree<Word,cat,empty,int,shift,comp,id> t(initial);
  std::vector<bool> bits(n,false);lazy_segtree<bool,std::logical_and<bool>{},yes,bool,bmap,bcomp,no> b(bits);
  for(int step=0;step<25;++step){
   int l=rng()%n,r=l+1+rng()%(n-l),f=rng()%26;t.apply(l,r,f);b.apply(l,r,true);
   for(int i=l;i<r;++i){for(char&c:ref[i])c=static_cast<char>('a'+(c-'a'+f)%26);bits[i]=true;}
   const int p=rng()%n;ref[p]=std::string(1+rng()%3,static_cast<char>('a'+rng()%26));t.set(p,Word(ref[p]));bits[p]=false;b.set(p,false);
   for(int x=0;x<=n;++x)for(int y=x;y<=n;++y){std::string want;bool wb=true;for(int i=x;i<y;++i){want+=ref[i];wb=wb&&bits[i];}if(t.prod(x,y).text!=want||b.prod(x,y)!=wb)std::abort();++checks;}
  }
 }
 std::printf("PASS nondefault owning noncommutative S and vector<bool>: %u interval checks\n",checks);
}
