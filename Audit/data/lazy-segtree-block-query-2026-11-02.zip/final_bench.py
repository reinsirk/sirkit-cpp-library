from pathlib import Path
import sys,subprocess,json,random,statistics,shutil,os,time,hashlib
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_lazy_speed_20261102');s=(D/'before.hpp').read_text();g=(D/'review_query_guarded.hpp').read_text();fg=(D/'fused_greedy.hpp').read_text();node='''    static std::size_t aligned_node(std::size_t value) {
        if (value == 0) std::unreachable();
        return value >> std::countr_zero(value);
    }
'''
nz=g.replace('    void pull(std::size_t p)',node+'    void pull(std::size_t p)').replace('begin >> std::countr_zero(begin)','aligned_node(begin)').replace('(end >> std::countr_zero(end))','aligned_node(end)')
attr='''#if defined(__GNUC__) || defined(__clang__)
    [[gnu::noinline]]
#endif
    S prod('''
variants={'old':s,'guarded':g,'nonzero':nz,'outlined':nz.replace('    S prod(',attr),'fused_outlined':fg.replace('    S prod(',attr)}
e=next(e for e in prepare_verify.collect() if e['id']=='lazy_segment_tree')
for label,source in variants.items():
 (D/f'final_{label}.hpp').write_text(source);data,_=prepare_verify.render(e,source_overrides={'DataStructure/Lazy_Segment_Tree.cpp':source.encode()});src=D/f'final_{label}.cpp';src.write_bytes(data)
 for cc,cmd0 in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:subprocess.run(['taskset','-c','2',*cmd0,'-std=c++23','-O2',str(src),'-o',str(D/f'final_{cc}_{label}')],check=True)
cases=[]
for family in ['random','max_random']:
 for seed in range(3):cases.append({'name':f'official_{family}_{seed}','path':str(D/f'official_{family}_{seed}.in')})
for n in [32,4096,500000]:
 for mode in ['mixed','query','update','short']:cases.append({'name':f'{n}_{mode}','path':str(D/f'input_{n}_{mode}.in')})
print('BUILT',flush=True);rs=[];rng=random.Random(581093)
for cc in ['gcc','clang']:
 for c in cases:
  for rep in range(9):
   labels=list(variants)+['control'];rng.shuffle(labels);checks=[]
   for label in labels:
    shutil.copyfile(D/f'final_{cc}_{"old" if label=="control" else label}',D/'active_final');(D/'active_final').chmod(0o700)
    with open(c['path'],'rb') as inp,open(D/'output','wb') as out:
     t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active_final')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-t
    ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rs.append({'compiler':cc,'case':c['name'],'rep':rep,'label':label,'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
   assert len(set(checks))==1
  ms={l:statistics.median(x['cpu_ns'] for x in rs if x['compiler']==cc and x['case']==c['name'] and x['label']==l) for l in labels};print(cc,c['name'],{l:round(v/ms['old'],3) for l,v in ms.items()},flush=True);(D/'final_raw.json').write_text(json.dumps(rs))
