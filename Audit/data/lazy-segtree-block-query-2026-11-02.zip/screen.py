from pathlib import Path
import sys,subprocess,json,random,statistics,shutil,os,time,hashlib
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_lazy_speed_20261102');s=(D/'before.hpp').read_text();pa=s.index('    void push_boundary(');pb=s.index('    void pull_path(',pa);aa=s.index('        for (std::size_t level = 1; level <= height_; ++level) {',s.index('    void apply(int l, int r'));ab=s.index('\n    }',aa);oldpull=s[aa:ab]
push_split='''    void push_boundary(std::size_t l, std::size_t r) {
        const unsigned a = std::countr_zero(l), b = std::countr_zero(r);
        const unsigned fork = std::bit_width(l ^ (r - 1));
        const unsigned shared = std::max(fork, std::min(a, b) + 1);
        for (unsigned level = static_cast<unsigned>(height_); level >= shared; --level)
            push(l >> level, std::size_t{1} << level);
        for (unsigned level = fork; level > a + 1;) { --level; push(l >> level, std::size_t{1} << level); }
        for (unsigned level = fork; level > b + 1;) { --level; push((r - 1) >> level, std::size_t{1} << level); }
    }
'''
pull_split='''        const unsigned a = std::countr_zero(begin), b = std::countr_zero(end);
        const unsigned fork = std::bit_width(begin ^ (end - 1));
        for (unsigned level = a + 1; level < fork; ++level) pull(begin >> level);
        for (unsigned level = b + 1; level < fork; ++level) pull((end - 1) >> level);
        for (unsigned level = std::max(fork, std::min(a, b) + 1); level <= height_; ++level)
            pull(begin >> level);'''
push_pair='''    void push_boundary(std::size_t l, std::size_t r) {
        const unsigned a = std::countr_zero(l), b = std::countr_zero(r);
        const unsigned fork = std::bit_width(l ^ (r - 1));
        const unsigned low = std::min(a, b);
        for (unsigned level = static_cast<unsigned>(height_); level >= std::max(fork, low + 1); --level)
            push(l >> level, std::size_t{1} << level);
        for (unsigned level = fork; level > low + 1;) {
            --level;
            if (level > a) push(l >> level, std::size_t{1} << level);
            if (level > b) push((r - 1) >> level, std::size_t{1} << level);
        }
    }
'''
pull_pair='''        const unsigned a = std::countr_zero(begin), b = std::countr_zero(end);
        const unsigned fork = std::bit_width(begin ^ (end - 1));
        const unsigned low = std::min(a, b);
        for (unsigned level = low + 1; level < fork; ++level) {
            if (level > a) pull(begin >> level);
            if (level > b) pull((end - 1) >> level);
        }
        for (unsigned level = std::max(fork, low + 1); level <= height_; ++level) pull(begin >> level);'''
bit=lambda x:x.replace('#include <algorithm>','#include <algorithm>\n#include <bit>')
variants={'old':s,'split':bit(s.replace(s[pa:pb],push_split).replace(oldpull,pull_split)),'paired':bit(s.replace(s[pa:pb],push_pair).replace(oldpull,pull_pair)),'push_split':bit(s.replace(s[pa:pb],push_split)),'pull_split':bit(s.replace(oldpull,pull_split))}
q=s.replace('if (r & (length - 1)) push((r - 1) >> level, length);','if ((r & (length - 1)) && (!(l & (length - 1)) || (l >> level) != ((r - 1) >> level))) push((r - 1) >> level, length);').replace('if (end & (span - 1)) pull((end - 1) >> level);','if ((end & (span - 1)) && (!(begin & (span - 1)) || (begin >> level) != ((end - 1) >> level))) pull((end - 1) >> level);');variants['dedup']=q
oldquery='''        S left = value_identity_, right = value_identity_;
        for (; begin < end; begin >>= 1, end >>= 1) {
            if (begin & 1) left = std::invoke(op, left, data_[begin++]);
            if (end & 1) right = std::invoke(op, data_[--end], right);
        }
        return std::invoke(op, left, right);'''
query='''        auto step = begin & (~begin + 1);
        if (step > end - begin) {
            S result = data_[(end >> std::countr_zero(end)) - 1];
            end -= end & (~end + 1);
            while (begin < end) {
                result = std::invoke(op, data_[(end >> std::countr_zero(end)) - 1], result);
                end -= end & (~end + 1);
            }
            return result;
        }
        S left = data_[begin >> std::countr_zero(begin)];
        begin += step;
        while (begin < end && (step = begin & (~begin + 1)) <= end - begin) {
            left = std::invoke(op, left, data_[begin >> std::countr_zero(begin)]);
            begin += step;
        }
        if (begin == end) return left;
        S right = data_[(end >> std::countr_zero(end)) - 1];
        end -= end & (~end + 1);
        while (begin < end) {
            right = std::invoke(op, data_[(end >> std::countr_zero(end)) - 1], right);
            end -= end & (~end + 1);
        }
        return std::invoke(op, left, right);'''
variants['greedy']=bit(s.replace(oldquery,query));variants['split_greedy']=variants['split'].replace(oldquery,query)
e=next(e for e in prepare_verify.collect() if e['id']=='lazy_segment_tree')
for label,source in variants.items():
 (D/f'{label}.hpp').write_text(source);data,_=prepare_verify.render(e,source_overrides={'DataStructure/Lazy_Segment_Tree.cpp':source.encode()});src=D/f'{label}.cpp';src.write_bytes(data);subprocess.run(['taskset','-c','2','/usr/bin/g++','-std=c++23','-O2',str(src),'-o',str(D/label)],check=True)
print('BUILT',flush=True);cases=[];mod=998244353
for n,q in [(32,200000),(4096,300000),(500000,500000)]:
 for mode in ['mixed','query','update','short']:
  p=D/f'input_{n}_{mode}.in';rng=random.Random(88412+n)
  with p.open('w') as f:
   f.write(f'{n} {q}\n');f.write(' '.join(str(rng.randrange(mod)) for _ in range(n))+'\n')
   for i in range(q):
    if mode=='short':l=rng.randrange(n);r=min(n,l+rng.randrange(1,17))
    else:l=rng.randrange(n);r=rng.randrange(l+1,n+1)
    update=mode=='update' or (mode in ['mixed','short'] and rng.randrange(2)==0)
    if update:f.write(f'0 {l} {r} {rng.randrange(1,mod)} {rng.randrange(mod)}\n')
    else:f.write(f'1 {l} {r}\n')
  cases.append({'n':n,'q':q,'mode':mode,'path':str(p)})
print('INPUTS BUILT',flush=True);rs=[];rng=random.Random(558922)
for c in cases:
 for rep in range(5):
  labels=list(variants)+['control'];rng.shuffle(labels);checks=[]
  for label in labels:
   shutil.copyfile(D/('old' if label=='control' else label),D/'active');(D/'active').chmod(0o700)
   with open(c['path'],'rb') as inp,open(D/'output','wb') as out:
    t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-t
   ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rs.append({'n':c['n'],'q':c['q'],'mode':c['mode'],'rep':rep,'label':label,'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
  assert len(set(checks))==1,(c,checks)
 ms={l:statistics.median(x['cpu_ns'] for x in rs if x['n']==c['n'] and x['mode']==c['mode'] and x['label']==l) for l in labels};print(c['n'],c['mode'],{l:round(v/ms['old'],3) for l,v in ms.items()},flush=True);(D/'screen_raw.json').write_text(json.dumps(rs))
