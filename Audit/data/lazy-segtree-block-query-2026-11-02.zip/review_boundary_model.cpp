// SPDX-License-Identifier: CC0-1.0
#include <algorithm>
#include <bit>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <random>
#include <vector>
using U=std::uint64_t;
struct Step { U p,width; bool operator==(const Step&)const=default; };
std::uint64_t cases=0,checks=0;
void check(bool ok){++checks;if(!ok)std::abort();}
void validate(U base,U L,U R){
 const int height=std::countr_zero(base),a=std::countr_zero(L),b=std::countr_zero(R);
 const int k=std::bit_width(L^(R-1));
 std::vector<Step> old,push,pull;
 for(int level=height;level>=1;--level){U width=U{1}<<level;if(L&(width-1))old.push_back({L>>level,width});if(R&(width-1))old.push_back({(R-1)>>level,width});}
 const int common=std::max(k,std::min(a,b)+1),separate=std::min(height,k-1);
 for(int level=height;level>=common;--level)push.push_back({L>>level,U{1}<<level});
 for(int level=separate;level>a;--level)push.push_back({L>>level,U{1}<<level});
 for(int level=separate;level>b;--level)push.push_back({(R-1)>>level,U{1}<<level});
 for(int level=a+1;level<=separate;++level)pull.push_back({L>>level,U{1}<<level});
 for(int level=b+1;level<=separate;++level)pull.push_back({(R-1)>>level,U{1}<<level});
 for(int level=common;level<=height;++level)pull.push_back({L>>level,U{1}<<level});
 auto less=[](const Step&x,const Step&y){return x.p<y.p;};
 std::sort(old.begin(),old.end(),less);old.erase(std::unique(old.begin(),old.end()),old.end());
 for(auto*sequence:{&push,&pull}){
  auto sorted=*sequence;std::sort(sorted.begin(),sorted.end(),less);check(sorted==old);
  for(const auto&s:*sequence){check(s.p>0&&s.p<base);const int depth=std::bit_width(s.p)-1;check(s.width==(U{1}<<(height-depth)));}
  // 親子が両方含まれる場合、pushは親を先に、pullは子を先に扱う。
  for(std::size_t i=0;i<sequence->size();++i)for(std::size_t j=i+1;j<sequence->size();++j){
   auto x=(*sequence)[i].p,y=(*sequence)[j].p;int dx=std::bit_width(x),dy=std::bit_width(y);
   if(sequence==&push&&dx>dy)check((x>>(dx-dy))!=y);
   if(sequence==&pull&&dx<dy)check((y>>(dy-dx))!=x);
  }
 }
 ++cases;
}
int main(){
 // すべての(l,r)は、任意の非二分冪n>=rのケースも含む。
 for(U base=1;base<=1024;base*=2)for(U l=0;l<base;++l)for(U r=l+1;r<=base;++r)validate(base,base+l,base+r);
 std::mt19937_64 rng(0x8910031);
 for(int height=1;height<=31;++height){
  U base=U{1}<<height,n=std::min(base,(U{1}<<31)-1);
  for(U l:{U{0},U{1},n/2,n-1})for(U r:{l+1,n})if(l<r&&r<=n)validate(base,base+l,base+r);
  for(int bit=0;bit<=height;++bit){U p=U{1}<<bit;for(U l:{p? p-1:0,p,std::min(n-1,p+1)})if(l<n){validate(base,base+l,base+l+1);validate(base,base+l,base+n);}}
  for(int rep=0;rep<10000;++rep){U l=rng()%n,r=l+1+rng()%(n-l);validate(base,base+l,base+r);}
 }
 std::printf("PASS boundary partition: %llu cases, %llu checks\n",static_cast<unsigned long long>(cases),static_cast<unsigned long long>(checks));
}
