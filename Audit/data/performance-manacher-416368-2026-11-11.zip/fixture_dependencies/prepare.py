# SPDX-License-Identifier: CC0-1.0
# 自作の入力作成/公式再生成計画。外部生成器はtempのみへ取得し、配布物へ含めない。
from pathlib import Path
import argparse, hashlib, json, posixpath, random, re, tomllib, urllib.request
D=Path('/tmp/sirkit_manacher_416358/agent_fixtures')
REV='73876f1cbcf082d2b22722924b924d3d65a2f00e'
BASE=f'https://raw.githubusercontent.com/yosupo06/library-checker-problems/{REV}/'
ROOT='string/enumerate_palindromes'
def sha(data):return hashlib.sha256(data).hexdigest()
def dump(name,value):(D/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def fetch():
    official=D/'official';official.mkdir(exist_ok=True)
    queue=['LICENSE',ROOT+'/info.toml'];seen=set();records=[]
    info=tomllib.loads((D/'info.toml').read_text())
    for test in info['tests']:
        name=test['name']
        if name.endswith('.cpp'):queue.append(ROOT+'/gen/'+name)
        else:queue += [ROOT+'/gen/'+name[:-3]+f'_{i:02d}.in' for i in range(test['number'])]
    while queue:
        path=queue.pop(0)
        if path in seen:continue
        seen.add(path);url=BASE+path;p=official/path;p.parent.mkdir(parents=True,exist_ok=True)
        if p.exists():data=p.read_bytes()
        else:data=urllib.request.urlopen(url,timeout=30).read();p.write_bytes(data)
        records.append(dict(path=path,url=url,sha256=sha(data)))
        for name in re.findall(r'^\s*#\s*include\s*"([^"]+)"',data.decode(errors='replace'),re.M):
            choices=[posixpath.normpath(posixpath.join(posixpath.dirname(path),name)),'common/'+name]
            # problem params.h is generated below; random.h is supplied through -Icommon.
            if posixpath.basename(name)=='params.h':continue
            target=choices[0] if name.startswith('.') else 'common/'+name
            queue.append(target)
    params=''.join(f'constexpr auto {k} = {v};\n' for k,v in info['params'].items())
    (official/ROOT/'params.h').write_text(params)
    dump('official_sources.json',dict(repository='https://github.com/yosupo06/library-checker-problems',revision=REV,license='Apache-2.0',usage='外部コードはtempのみ。配布ライブラリ/証跡ZIPへ本文を含めない。',constraints=info['params'],files=records,generated_params=params))
    build=D/'official_build';build.mkdir(exist_ok=True);inputs=D/'fixtures/inputs';inputs.mkdir(parents=True,exist_ok=True)
    plan=dict(revision=REV,compile=[],runs=[],examples=[])
    for test in info['tests']:
        name=test['name'];stem=name.rsplit('.',1)[0]
        if name.endswith('.cpp'):
            exe=build/stem
            plan['compile'].append(['/usr/bin/g++','-std=c++23','-O2','-I'+str(official/'common'),'-I'+str(official/ROOT),str(official/ROOT/'gen'/name),'-o',str(exe)])
            for seed in range(test['number']):plan['runs'].append(dict(name=f'official_{stem}_{seed:02d}',command=[str(exe),str(seed)],output=str(inputs/f'official_{stem}_{seed:02d}.in'),generator=ROOT+'/gen/'+name,seed=seed))
        else:
            for seed in range(test['number']):plan['examples'].append(dict(name=f'official_{stem}_{seed:02d}',path=str(official/ROOT/'gen'/f'{stem}_{seed:02d}.in')))
    dump('official_generation_plan.json',plan)
def naive(s):
    out=[];n=len(s)
    for c in range(2*n-1):
        l=c//2;r=(c+1)//2;count=0
        while l>=0 and r<n and s[l]==s[r]:count=r-l+1;l-=1;r+=1
        out.append(count)
    return out

def formula(n,shape):
    if shape=='all_same':return [min(c+1,2*n-1-c) for c in range(2*n-1)]
    if shape=='periodic3':return [1 if c%2==0 else 0 for c in range(2*n-1)]
    if shape=='alternating':return [2*min(c//2+1,n-c//2)-1 if c%2==0 else 0 for c in range(2*n-1)]
    return None

def make(n,shape,seed):
    rng=random.Random(seed)
    if shape=='all_same':return b'a'*n
    if shape=='alternating':return (b'ab'*(n//2+1))[:n]
    if shape=='periodic3':return (b'abc'*(n//3+1))[:n]
    if shape=='random26':return bytes(97+rng.randrange(26) for _ in range(n))
    if shape=='binary':return bytes(97+rng.randrange(2) for _ in range(n))
    if shape in ['last_different','middle_different','first_different']:
        s=bytearray(b'a'*n);s[{'last_different':n-1,'middle_different':n//2,'first_different':0}[shape]]=98;return bytes(s)
    if shape=='long_palindrome':
        a=make((n+1)//2,'random26',seed);return a+a[:n//2][::-1]
    if shape=='fibonacci':
        a,b=b'a',b'ab'
        while len(b)<n:a,b=b,b+a
        return b[:n]
    if shape=='binary_carry':return bytes(97+(i.bit_count()&1) for i in range(n))
    if shape=='prefix_then_random':return b'a'*(n//2)+make(n-n//2,'random26',seed)
    raise ValueError(shape)

def row(name,path,data,source,seed=None,shape=None):
    s=data.rstrip(b'\r\n');assert s and all(97<=c<=122 for c in s)
    p=D/'fixtures/expected'/f'{name}.out';p.parent.mkdir(parents=True,exist_ok=True)
    expected=naive(s) if len(s)<=256 else formula(len(s),shape)
    method='independent_naive' if len(s)<=256 else 'independent_formula' if expected is not None else 'before_after_output_comparison_only'
    result=dict(name=name,path=str(path),n=len(s),bytes=len(data),sha256=sha(data),seed=seed,source=source,shape=shape,within_problem_limit=len(s)<=500000,oracle=method)
    if expected is not None:
        output=(' '.join(map(str,expected))+'\n').encode();p.write_bytes(output);result.update(expected_path=str(p),expected_sha256=sha(output))
    return result

def custom():
    inputs=D/'fixtures/inputs';inputs.mkdir(parents=True,exist_ok=True);rows=[]
    cases=[]
    for n in [1,32,4096]:
        for shape in ['all_same','binary','periodic3']:cases.append((n,shape))
    for shape in ['all_same','random26','binary','periodic3','alternating','last_different','middle_different','first_different','prefix_then_random','long_palindrome','fibonacci','binary_carry']:cases.append((500000,shape))
    for shape in ['all_same','random26','binary','alternating','long_palindrome']:cases.append((1000000,shape))
    for i,(n,shape) in enumerate(cases):
        name=f'custom_{n}_{shape}';data=make(n,shape,416358+i)+b'\n';p=inputs/f'{name}.in';p.write_bytes(data);rows.append(row(name,p,data,'self-generated',416358+i,shape))
    dump('custom_fixtures.json',rows)
    # Formula is checked against brute force independently, including both input parities.
    checks=0
    for n in range(1,129):
        for shape in ['all_same','alternating','periodic3']:
            assert naive(make(n,shape,0))==formula(n,shape);checks+=1
    dump('formula_validation.json',dict(cases=checks,status='PASS',comparison='独立中心全比較とall_same/alternating/periodic3の式を照合'))
    return rows

def register():
    rows=load_json('custom_fixtures.json');plan=load_json('official_generation_plan.json')
    for e in plan['examples']:
        p=Path(e['path']);rows.append(row(e['name'],p,p.read_bytes(),'official-fixed-example'))
    for e in plan['runs']:
        p=Path(e['output'])
        if not p.exists():continue
        shape='all_same' if e['name'].startswith('official_all_same_') else None
        rows.append(row(e['name'],p,p.read_bytes(),'official-fixed-generator',e['seed'],shape))
    dump('fixtures.json',rows);print('fixtures',len(rows),'official generated',sum(r['source']=='official-fixed-generator' for r in rows))
def load_json(name):return json.loads((D/name).read_text())
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--fetch',action='store_true');parser.add_argument('--register-official',action='store_true');args=parser.parse_args();D.mkdir(parents=True,exist_ok=True)
    if args.fetch:fetch()
    if args.register_official:register()
    else:custom();register() if (D/'official_generation_plan.json').exists() else None
