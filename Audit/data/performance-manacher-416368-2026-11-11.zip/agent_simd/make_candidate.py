# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
D=Path('/tmp/sirkit_manacher_416368');source=(D/'leading.hpp').read_text()
condition='!defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__i386__) || defined(__x86_64__)) && CHAR_BIT == 8 && INT_MAX == 2147483647 && defined(__SIZEOF_INT__) && __SIZEOF_INT__ == 4'
headers='#include <climits>\n#if '+condition+'\n#include <immintrin.h>\n#endif\n'
source=source.replace('#include <algorithm>','#include <algorithm>\n'+headers)
helper='''#ifndef SIRKIT_PALINDROMIC_PREFIX_FILL_DEFINED
#define SIRKIT_PALINDROMIC_PREFIX_FILL_DEFINED
namespace reinsirk::detail {
#if SIMD_CONDITION
[[gnu::target("avx2")]] inline void fill_palindromic_prefix_avx2(int* output, int run) noexcept {
    const auto lanes = _mm256_setr_epi32(1,2,3,4,5,6,7,8);
    const auto step = _mm256_set1_epi32(8);
    auto values = lanes;
    int i = 0;
    for (; run - i >= 8; i += 8) {
        _mm256_storeu_si256(reinterpret_cast<__m256i*>(output + i), values);
        values = _mm256_add_epi32(values, step);
    }
    for (; i < run; ++i) output[i] = i + 1;
    int* descending = output + run;
    const int remaining = run - 1;
    values = _mm256_sub_epi32(_mm256_set1_epi32(run), lanes);
    i = 0;
    for (; remaining - i >= 8; i += 8) {
        _mm256_storeu_si256(reinterpret_cast<__m256i*>(descending + i), values);
        values = _mm256_sub_epi32(values, step);
    }
    for (; i < remaining; ++i) descending[i] = remaining - i;
}
#endif
// run>=2で、outputは少なくとも2*run-1個の確保済みintを指す。
inline void fill_palindromic_prefix(int* output, int run) noexcept {
#if SIMD_CONDITION
    if (run >= 4096 && __builtin_cpu_supports("avx2")) {
        fill_palindromic_prefix_avx2(output, run);
        return;
    }
#endif
    using Center = unsigned int;
    const auto end = Center{2} * static_cast<Center>(run) - 1;
    for (Center c = 0; c < static_cast<Center>(run); ++c) output[c] = static_cast<int>(c + 1);
    for (Center c = static_cast<Center>(run); c < end; ++c) output[c] = static_cast<int>(end - c);
}
}
#endif

'''.replace('SIMD_CONDITION',condition)
source=source.replace('#ifndef SIRKIT_PALINDROME_RADII_DEFINED',helper+'#ifndef SIRKIT_PALINDROME_RADII_DEFINED',1)
old='''        for (Center c = 0; c < static_cast<Center>(run); ++c) result[c] = static_cast<int>(c + 1);
        for (Center c = static_cast<Center>(run); c < prefix_centers; ++c) result[c] = static_cast<int>(prefix_centers - c);'''
assert source.count(old)==1
source=source.replace(old,'        reinsirk::detail::fill_palindromic_prefix(result.data(), run);')
(D/'agent_simd/leading_fill_avx2.hpp').write_text(source)
