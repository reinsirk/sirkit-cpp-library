# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,fcntl,random,statistics,shutil
D=Path('/tmp/sirkit_manacher_416368');raw=[];summary=[];rng=random.Random(416042)
with open('/tmp/sirkit_performance_cpu12.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for op in range(3):
   for n in [32,4096,500000]:
    for shape in range(3):
     values=[]
     for rep in range(7):
      labels=['base','control','leading','leading_scan'];rng.shuffle(labels)
      for label in labels:
       shutil.copyfile(D/f'{cc}_typed_{"base"if label=="control"else label}',D/'active');(D/'active').chmod(0o700)
       result=subprocess.run(['setarch','x86_64','-R','taskset','-c','12',str(D/'active'),str(op),str(n),str(shape)],capture_output=True,text=True,check=True)
       ns,checksum=map(int,result.stdout.split());row=dict(compiler=cc,operation=op,n=n,shape=shape,rep=rep,label=label,ns=ns,checksum=checksum);raw.append(row);values.append(row)
     assert len({r['checksum']for r in values})==1
     m={label:statistics.median(r['ns']for r in values if r['label']==label)for label in ['base','control','leading','leading_scan']};base=statistics.median(r['ns']for r in values if r['label']in ['base','control']);row=dict(compiler=cc,operation=op,n=n,shape=shape,median_ns=m,pooled_base_ns=base,ratio={l:m[l]/base for l in ['leading','leading_scan']},control_ratio=m['control']/base);summary.append(row);print(cc,op,n,shape,{l:round(v,4)for l,v in row['ratio'].items()},flush=True)
     (D/'typed_raw.json').write_text(json.dumps(raw));(D/'typed_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Complete',len(raw),flush=True)
