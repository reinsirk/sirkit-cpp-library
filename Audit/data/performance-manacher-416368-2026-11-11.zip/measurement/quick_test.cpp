// SPDX-License-Identifier: CC0-1.0
#include MANACHER_HEADER
#include <cstdlib>
#include <cstdio>
#include <string>
#include <vector>
std::size_t cases=0;
void test(const std::string& s) {
 const int n=static_cast<int>(s.size());std::vector<int> odd(n),even(n),expected(n?2*n-1:0);
 for(int i=0;i<n;++i){int k=1;while(k<=i&&k<n-i&&s[i-k]==s[i+k])++k;odd[i]=k;expected[2*i]=2*k-1;k=0;while(k<i&&k<n-i&&s[i-k-1]==s[i+k])++k;even[i]=k;if(i)expected[2*i-1]=2*k;}
 const PalindromeRadii p(s);if(p.odd!=odd||p.even!=even||PalindromicLengths(s)!=expected)std::abort();++cases;
}
int main(){for(int n=0;n<=11;++n)for(unsigned x=0;x<(1U<<n);++x){std::string s(n,'a');for(int i=0;i<n;++i)s[i]=static_cast<char>('a'+(x>>i&1));test(s);}for(int n=0;n<=7;++n){unsigned count=1;for(int i=0;i<n;++i)count*=3;for(unsigned x=0;x<count;++x){auto k=x;std::string s(n,'a');for(auto& c:s){c=static_cast<char>('a'+k%3);k/=3;}test(s);}}std::printf("quick naive cases=%zu\n",cases);}
