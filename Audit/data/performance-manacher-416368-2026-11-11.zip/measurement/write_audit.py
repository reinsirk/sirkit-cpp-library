# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_manacher_416368');P=Path('/tmp/sirkit_manacher_416358')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['Verify/current/drivers/manacher_main.cpp','Verify/current/common/fast_io.hpp']:assert (R/n).read_bytes()==(D/'before'/n).read_bytes()
old=(D/'before/String/Manacher.cpp').read_text();new=(R/'String/Manacher.cpp').read_text();a='#ifndef SIRKIT_PALINDROME_RADII_DEFINED';b='#ifndef SIRKIT_PALINDROMIC_LENGTHS_DEFINED';assert old[old.index(a):old.index(b)]==new[new.index(a):new.index(b)]
whole=load(D/'final_summary.json');typed=load(D/'typed_summary.json');fixtures=load(P/'agent_fixtures/fixtures.json');fm={r['name']:r for r in fixtures};runs=sorted((D/'profiles/runs').glob('*.json'));assert runs and load(runs[-1])['counts']=={'LOCAL_SAMPLE_PASS':10}
labels=['leading','leading_scan','leading_min','leading_blocked','leading_scan_blocked','leading_avx2','leading_scan_avx2']
key=['official_all_same_00','official_all_same_01','official_all_same_02','official_all_same_03','official_all_same_04','official_max_random_00','official_max_random_01','official_max_random_02','custom_500000_binary','custom_500000_last_different','custom_500000_prefix_then_random']
audit={
 'date':'2026-11-11','library':'String/Manacher.cpp','decision':'accept_leading_equal_run_standard_Cpp23','required_resubmission':['Verify/current/submissions/manacher.cpp'],
 'online':{'url':'https://judge.yosupo.jp/submission/416368','status':'AC','time_ms':28,'previous_url':'https://judge.yosupo.jp/submission/416362','previous_time_ms':24,'evidence':'Audit/online-manacher-416368-2026-11-11.json','scope':'max_random_02が19→28ms、他の大規模は概ね同等。オンライン結果だけで揺れ/入力依存を断定しない。提出本文は本体/main/共通IOと空白等のみ除いて一致。このACは追加の先頭run改修を含まない。'},
 'change':['先頭2要素が同値なら、先頭の最大同値run長rをアルゴリズムの一部として求める。検査専用の走査ではない。','run内2r-1中心の回文長を、増加列1..rと減少列r-1..1で一括生成する。','r==nなら返却値が完成する。r<nなら次の文字間中心は不一致で0確定、初期化済みのまま飛ばして通常のManacherを中心2rから続ける。','main/共通IO/PalindromeRadii/全照会API/容量guard/所有権は維持。追加の公開APIや入力分布に応じたmainの切替はない。'],
 'correctness':['先頭同値run長rでは、中心c<rは左端0まで一致し長さc+1。r<=c<2r-1はs[r]との不一致または列末尾で止まり長さ2r-1-c。','r<nの中心2r-1はs[r-1]!=s[r]で0。次中心2rからの鏡像参照は、既に正しいrun/gapの値だけを読む。','初期window middle=r-1,right=2r-2は先頭run全体の回文L=0,R=r-1を表す。','M=INT_MAX、U=UINT_MAX=2M+1、r<=n<=M-1より、2U*r<=U-3、prefix_centers<=U-4、right<=U-5。乗算はCenterへ変換してから行う。','r<nならstart=2r<=centers-1で配列内。出力はr以下なのでint castは正確。run++はrun<nのときだけで最大n。','等値比較は一貫した同値関係。要素コピー等の追加要件なし。O(r)の走査/一括生成と残りの線形走査で全体O(n)、追加領域なし。'],
 'source_hashes':{'before':sha(D/'before/String/Manacher.cpp'),'after':sha(R/'String/Manacher.cpp'),'submission_after':sha(R/'Verify/current/submissions/manacher.cpp'),'main':sha(R/'Verify/current/drivers/manacher_main.cpp'),'IO':sha(R/'Verify/current/common/fast_io.hpp')},
 'fixed_conditions':{'main_unchanged':True,'IO_unchanged':True,'skip_runtime_checks':True,'query_batching_or_problem_specific_dispatch':False,'submission_bytes':(R/'Verify/current/submissions/manacher.cpp').stat().st_size},
 'measurement':{'CPU':'Intel Core i9-14900K、CPU12/core6 P-Core、sibling13、max6GHz','E_Core_considered':False,'compilers':{'GCC':'15.2.0','Clang':'21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'},'flags':['-std=c++23','-O2'],'march_native':False,'added_optimize_pragmas':False,'affinity':'taskset -c12','ASLR':'子プロセスのみsetarch x86_64 -R。システム設定変更なし。','lock':'/tmp/sirkit_performance_cpu12.lock','order':'before/control/candidatesを決定的にshuffleし同じactiveパスで実行。controlはbeforeと同じ実行ファイル。','whole_scope':'固定main/IO全体のuser+system時間。after中央値/before-control pooled中央値。','fixtures':len(fixtures),'official_revision':'73876f1cbcf082d2b22722924b924d3d65a2f00e','fixture_scope':'公式固定生成器24入力と自作26入力(制約外1000000を含む)を再利用。オンライン現行入力の同一性は主張しない。','repetitions':9,'final_runs':len(load(D/'final_raw.json')),'all_outputs_identical':True,'selected_results':[{**r,'reduction_percent':100*(1-r['ratios']['leading'])}for r in whole if r['case'] in key],'large_worst_ratios':{cc:max(r['ratios']['leading']for r in whole if r['compiler']==cc and fm[r['case']]['n']>=200000)for cc in ['gcc','clang']},'compiled_final_equivalence':load(D/'final_builds.json')},
 'generic_API_measurement':{'operations':{'0':'PalindromicLengths(string)','1':'PalindromicLengths(vector<int64_t>)','2':'PalindromicLengths(vector<bool>)'},'sizes':[32,4096,500000],'shapes':{'0':'all_same','1':'periodic3','2':'binary_random'},'repetitions':7,'runs':len(load(D/'typed_raw.json')),'scope':'入力生成を除き、返却領域の確保/計算/破棄を含む反復呼出しのsteady_clock時間。Verify全体と区別。','all_checksums_identical':True,'large_results':[r for r in typed if r['n']==500000],'public_Radii':'クラス本体/照会APIは完全同一。前回の独立単体機械語一致証拠も参照。'},
 'limits':{'large':'公式同値列はGCC約8.2〜10.7%、Clang約11.5〜15.0%短縮。末尾違いはGCC約9.2%、Clang約16.8%。ランダム列は同等の条件も多い。','regressions':'全50入力の大規模最大ratioはGCC約1.012、Clang約1.011。一律の非退行を主張せず、小幅増も記録する。','small':'全体時間には起動時間が含まれ、小入力の比率は特に揺れる。','online':'28msからの変化は未提出のため未確認。'},
 'candidates':{'source_sha256':{l:sha(D/(l+'.hpp'))for l in labels},'rejected':{'leading_scan':'走査を無条件にする案も全50入力で測定。採用版と近いがGCCの重点条件/汎用操作と単純さでleadingを選択。','leading_min':'minで一括fillする単一ループは他条件の後退があり不採用。','blocked/AVX2_fill':'8要素の標準手動展開/AVX2 fillは安定した上積みがなく不採用。自動vectorize診断も保存。','AVX2_scan':'prefix走査だけの32byte scanも別途比較。GCCで安定した上積みがなく、Clangのrandom/長い回文に後退があり不採用。追加ISA/CPU判定/専用includeは現行に導入しない。'}},
 'verification':{'final_tests':load(D/'tests.json'),'quick_candidates':load(D/'quick_tests.json'),'sanitizers':'GCC/Clang×checked/SKIPの独立参照とSA/LCP長列参照はASan/UBSan。global newで確保失敗を注入する試験はサニタイザなし。','independent':'全中心直接展開と、正順+区切り+逆順SA/LCPの別方式から全半径を照合。','large_reference':'各設定131 cases / 9234220 checks。50万要素、NUL/全256バイト、奇偶境界、整数極値/bool、先頭runを持つnoncopyable+explicit-bool proxy、比較例外/巨大長。','allocation':'各コンパイラ2343 checks / 69 injected failures / live_delta=0。','profiles':{'run_file':'profiles/runs/'+runs[-1].name,'counts':load(runs[-1])['counts'],'scope':'通常/GCC/Clang/速度優先GCC/速度優先Clangの提出コードと使用例。'}},
 'documentation':'公開API/使い方/計算量は不変。runの三角列と零初期化の利用だけソースに短く注記。Document/READMEに性能履歴を追加しない。',
 'license':'採用コード/独立試験/測定補助は独自CC0-1.0。公式外部生成器の本文は収録せず、前回の固定URL/ハッシュ/再生成計画だけ参照。',
 'prior_evidence':['Audit/performance-manacher-416358-2026-11-11.json','Audit/performance-manacher-416362-2026-11-11.json'],'evidence_zip':'Audit/data/performance-manacher-416368-2026-11-11.zip'
}
p=R/'Audit/performance-manacher-416368-2026-11-11.json';p.write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n');files=[]
for f in D.iterdir():
 if f.is_file()and f.suffix in ['.json','.py','.hpp','.log','.txt']:files.append((f,'measurement/'+f.name))
for folder in ['agent_simd','agent_scan']:
 for f in (D/folder).iterdir():
  if f.is_file()and f.suffix in ['.json','.py','.hpp']:files.append((f,folder+'/'+f.name))
for n in ['fixtures.json','official_sources.json','official_generation_plan.json','prepare.py']:files.append((P/'agent_fixtures'/n,'fixture_dependencies/'+n))
for n in ['typed_benchmark.cpp','quick_test.cpp']:files.append((P/n,'measurement/'+n))
for f in (D/'profiles').rglob('*.json'):files.append((f,'profiles/'+str(f.relative_to(D/'profiles'))))
for n in ['416368.cpp','before/String/Manacher.cpp','before/Verify/current/submissions/manacher.cpp','before/Verify/current/drivers/manacher_main.cpp','before/Verify/current/common/fast_io.hpp']:files.append((D/n,n))
for n in ['String/Manacher.cpp','Verify/current/submissions/manacher.cpp','Verify/current/tests/manacher_independent_test.cpp','Verify/current/tests/string_algorithms_reference_test.cpp','Verify/current/tests/string_math_allocation_test.cpp','Audit/online-manacher-416368-2026-11-11.json','Audit/performance-manacher-416368-2026-11-11.json']:files.append((R/n,'after/'+n))
with zipfile.ZipFile(R/audit['evidence_zip'],'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f,n in sorted(files,key=lambda v:v[1]):z.writestr(zipfile.ZipInfo(n,(2026,11,11,0,0,0)),f.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
print('audit/evidence',len(files),(R/audit['evidence_zip']).stat().st_size)
