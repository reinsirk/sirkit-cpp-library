# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
D=Path('/tmp/sirkit_manacher_416368');base=(D/'before/String/Manacher.cpp').read_text();(D/'base.hpp').write_text(base)
old='''    Center middle = 0, right = 0;
    const auto centers = static_cast<Center>(result.size());
    for (Center center = 0; center < centers; ++center) {'''
new='''    Center middle = 0, right = 0, start = 0;
    const auto centers = static_cast<Center>(result.size());
    if (n > 1 && s[0] == s[1]) {
        int run = 2;
        while (run < n && s[0] == s[run]) ++run;
        const auto prefix_centers = Center{2} * static_cast<Center>(run) - 1;
        for (Center c = 0; c < static_cast<Center>(run); ++c) result[c] = static_cast<int>(c + 1);
        for (Center c = static_cast<Center>(run); c < prefix_centers; ++c) result[c] = static_cast<int>(prefix_centers - c);
        if (run == n) return result;
        middle = static_cast<Center>(run - 1);
        right = prefix_centers - 1;
        start = prefix_centers + 1;
    }
    for (Center center = start; center < centers; ++center) {'''
assert old in base;s=base.replace(old,new);(D/'leading.hpp').write_text(s)
# Keep the leading scan unconditional but avoid work for a single-element run.
new2=new.replace('''    if (n > 1 && s[0] == s[1]) {
        int run = 2;
        while (run < n && s[0] == s[run]) ++run;''','''    int run = 1;
    while (run < n && s[0] == s[run]) ++run;
    if (run > 1) {''');(D/'leading_scan.hpp').write_text(base.replace(old,new2))
# A single min loop instead of the two fill loops, for compiler comparison.
s=s.replace('''        for (Center c = 0; c < static_cast<Center>(run); ++c) result[c] = static_cast<int>(c + 1);
        for (Center c = static_cast<Center>(run); c < prefix_centers; ++c) result[c] = static_cast<int>(prefix_centers - c);''','''        for (Center c = 0; c < prefix_centers; ++c)
            result[c] = static_cast<int>(std::min(c + 1, prefix_centers - c));''');(D/'leading_min.hpp').write_text(s)
