# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
D=Path('/tmp/sirkit_manacher_416368');source=(D/'leading.hpp').read_text()
condition='!defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__i386__) || defined(__x86_64__)) && CHAR_BIT == 8 && INT_MAX == 2147483647 && defined(__SIZEOF_INT__) && __SIZEOF_INT__ == 4'
headers='#include <climits>\n#if '+condition+'\n#include <bit>\n#include <immintrin.h>\n#include <string>\n#include <type_traits>\n#endif\n'
source=source.replace('#include <algorithm>','#include <algorithm>\n'+headers)
helper='''#if SIMD_CONDITION
#ifndef SIRKIT_PALINDROMIC_PREFIX_SCAN_DEFINED
#define SIRKIT_PALINDROMIC_PREFIX_SCAN_DEFINED
namespace reinsirk::detail {
// n>=2かつtext[0]==text[1]。読み込む各32byteは必ず[0,n)内。
[[gnu::target("avx2")]] inline int scan_equal_prefix_avx2(const char* text, int n) noexcept {
    const auto first = _mm256_set1_epi8(text[0]);
    int run = 2;
    for (; n - run >= 32; run += 32) {
        const auto bytes = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(text + run));
        const auto equal = _mm256_cmpeq_epi8(first, bytes);
        const auto different = ~static_cast<unsigned int>(_mm256_movemask_epi8(equal));
        if (different != 0) return run + std::countr_zero(different);
    }
    while (run < n && text[0] == text[run]) ++run;
    return run;
}
}
#endif
#endif

'''.replace('SIMD_CONDITION',condition)
source=source.replace('#ifndef SIRKIT_PALINDROME_RADII_DEFINED',helper+'#ifndef SIRKIT_PALINDROME_RADII_DEFINED',1)
old='''        int run = 2;
        while (run < n && s[0] == s[run]) ++run;'''
new='''        int run = 2;
#if SIMD_CONDITION
        if constexpr (std::is_same_v<Sequence, std::string>) {
            if (n >= 4096 && __builtin_cpu_supports("avx2"))
                run = reinsirk::detail::scan_equal_prefix_avx2(s.data(), n);
        }
#endif
        while (run < n && s[0] == s[run]) ++run;'''.replace('SIMD_CONDITION',condition)
assert source.count(old)==1
source=source.replace(old,new)
(D/'agent_scan/leading_scan_avx2.hpp').write_text(source)
