// SPDX-License-Identifier: CC0-1.0
#include "narrow.hpp"
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <limits>
#include <random>
#include <vector>
namespace {
std::uint64_t checks=0;
void check(bool value){++checks;assert(value);}
template<class T>void trial(T origin,std::uint64_t span,std::mt19937_64& random){
 for(std::size_t n:{2,63,64,65,127,128,129,1024}){
  std::vector<T>values(n);
  for(auto&v:values)v=static_cast<T>(origin+static_cast<T>(random()%(span+1)));
  values[0]=origin;values[1]=static_cast<T>(origin+static_cast<T>(span));
  WaveletMatrix<T>matrix(values);
  for(std::size_t i=0;i<n;++i)check(matrix.access(i)==values[i]);
  for(int query=0;query<200;++query){
   auto l=static_cast<std::size_t>(random()%(n+1)),r=static_cast<std::size_t>(random()%(n+1));if(l>r)std::swap(l,r);
   std::vector<T>part(values.begin()+l,values.begin()+r);std::sort(part.begin(),part.end());
   const T x=values[random()%n];
   check(matrix.rank(x,l,r)==static_cast<std::size_t>(std::count(part.begin(),part.end(),x)));
   check(matrix.count_less(l,r,x)==static_cast<std::size_t>(std::lower_bound(part.begin(),part.end(),x)-part.begin()));
   if(l!=r){const auto k=static_cast<std::size_t>(random()%(r-l));check(matrix.kth_smallest(l,r,k)==part[k]);check(matrix.kth_largest(l,r,k)==part[part.size()-1-k]);}
  }
 }
}
}
int main(){
 std::mt19937_64 random(416569);
 for(auto span:{UINT64_C(0x7fffffff),UINT64_C(0xffffffff),UINT64_C(0x100000000)}){
  trial<std::int64_t>(std::numeric_limits<std::int64_t>::min(),span,random);
  trial<std::int64_t>(std::numeric_limits<std::int64_t>::max()-static_cast<std::int64_t>(span),span,random);
  trial<std::int64_t>(-(INT64_C(1)<<40),span,random);
  trial<std::uint64_t>(0,span,random);
  trial<std::uint64_t>(std::numeric_limits<std::uint64_t>::max()-span,span,random);
 }
 std::cout<<"narrow threshold checks="<<checks<<'\n';
}
