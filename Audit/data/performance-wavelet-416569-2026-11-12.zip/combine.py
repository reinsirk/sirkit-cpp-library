# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
D=Path('/tmp/sirkit_wavelet_416569');base=(D/'base.hpp').read_text();narrow=(D/'narrow.hpp').read_text();a=base.index('    void initialize(');b=base.index('    std::size_t count_less_unchecked(',a);na=narrow.index('    template<class Work>');nb=narrow.index('    std::size_t count_less_unchecked(',na)
for label,parent in [('early_narrow','early'),('early_single_narrow','single'),('early_single_sentinel_narrow','early_single_sentinel')]:
 s=(D/(parent+'.hpp')).read_text();assert s.count(base[a:b])==1;s=s.replace(base[a:b],narrow[na:nb])
 if parent=='single':
  x=base.index('    std::size_t rank(T value,');y=base.index('    std::size_t count(',x);early=(D/'early.hpp').read_text();ex=early.index('    std::size_t rank(T value,');ey=early.index('    std::size_t count(',ex);assert s.count(base[x:y])==1;s=s.replace(base[x:y],early[ex:ey])
 (D/(label+'.hpp')).write_text(s)
# Reuse independent partition kernel in combined sentinel/narrow implementation.
s=(D/'early_single_sentinel_narrow.hpp').read_text();p=(D/'partition.hpp').read_text();start=p.index('#if !defined(SIRKIT_DISABLE_SIMD)',p.index('    template<class U> std::size_t build_bits'));end=p.index('    bool at(',start)
# Select only additional methods, following existing build_bits's return.
start=p.index('#if !defined(SIRKIT_DISABLE_SIMD) && !defined(SIRKIT_WAVELET_FORCE_SOFTWARE)',p.index('        return values.size() - prefix_.back();',p.index('    template<class U> std::size_t build_bits')))
methods=p[start:end];pos=s.index('    bool at(');s=s[:pos]+methods+s[pos:];s=s.replace('#include <algorithm>','#include <algorithm>\n#include <array>',1)
old='''            std::size_t low = 0, high = zeros;
            for (Work value : current) {
                const auto bit = static_cast<std::size_t>((value >> shift) & Work{1});
                next[bit != 0 ? high : low] = value;
                low += bit ^ std::size_t{1}; high += bit;
            }
''';new='''            bits.partition(std::span<const Work>(current), shift, zeros, std::span<Work>(next));
''';assert s.count(old)==1;s=s.replace(old,new);(D/'combined_simd.hpp').write_text(s)
