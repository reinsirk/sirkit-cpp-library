# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,subprocess,shutil,os
D=Path('/tmp/sirkit_wavelet_416569');fixtures=json.loads((D/'fixtures/fixtures.json').read_text())
def activate(p):shutil.copyfile(p,D/'active');(D/'active').chmod(0o700)
def run_whole(cc,label,f,flag='native'):
 id='wavelet_kth'if f['problem']=='range_kth_smallest'else'wavelet_frequency';activate(D/f'{cc}_{flag}_{label}_{id}')
 with Path(f['path']).open('rb')as fi,(D/'output').open('wb')as fo:
  p=subprocess.Popen(['setarch','x86_64','-R','taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,status,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status);assert p.returncode==0
 digest=hashlib.sha256((D/'output').read_bytes()).hexdigest();assert digest==f['expected_output_sha256'],(cc,label,f['id'],digest)
 return dict(cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),output_sha256=digest)
