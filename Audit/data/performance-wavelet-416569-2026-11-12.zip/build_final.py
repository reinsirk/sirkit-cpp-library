# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import sys,subprocess,json,hashlib,fcntl
D=Path('/tmp/sirkit_wavelet_416569');R=Path('/home/reinsirk/Atcoder_Env')
sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
entries={e['id']:e for e in pv.collect()};jobs=[]
for l in ['base','final']:
 for cc,cmd,cpu in [('gcc',['g++'],4),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'],6)]:
  for flag,extra in [('native',['-march=native']),('default',[]),('disabled',['-DSIRKIT_DISABLE_SIMD'])]:
   for setting in ['checked','skip']:
    exe=D/f'{cc}_{flag}_{setting}_{l}_core'
    jobs.append(dict(compiler=cc,flag=flag,setting=setting,label=l,kind='core',command=['taskset','-c',str(cpu),*cmd,'-std=c++23','-O2',*extra,*(['-DSKIP_RUNTIME_CHECKS']if setting=='skip'else[]),f'-DHEADER="{D}/{l}.hpp"',str(D/'core.cpp'),'-o',str(exe)],executable=str(exe)))
   for identifier in ['wavelet_kth','wavelet_frequency']:
    src=D/f'{l}_{identifier}.cpp'
    entry=entries[identifier].copy();entry['submission_urls']=['https://judge.yosupo.jp/submission/'+('416569'if identifier=='wavelet_kth'else'416570')];data,_=pv.render(entry,source_overrides={'DataStructure/Wavelet_Matrix.cpp':(D/f'{l}.hpp').read_bytes()});src.write_bytes(data)
    exe=D/f'{cc}_{flag}_{l}_{identifier}'
    jobs.append(dict(compiler=cc,flag=flag,setting='skip',label=l,kind=identifier,command=['taskset','-c',str(cpu),*cmd,'-std=c++23','-O2',*extra,str(src),'-o',str(exe)],executable=str(exe)))
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 def worker(cc):
  for row in jobs:
   if row['compiler']!=cc:continue
   p=subprocess.run(row['command'],capture_output=True,text=True);row.update(returncode=p.returncode,stderr=p.stderr);assert p.returncode==0,p.stderr;row['executable_sha256']=hashlib.sha256(Path(row['executable']).read_bytes()).hexdigest()
  print(cc,'final build complete',flush=True)
 with ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(worker,['gcc','clang']))
(D/'final_builds.json').write_text(json.dumps(jobs,indent=2)+'\n')
