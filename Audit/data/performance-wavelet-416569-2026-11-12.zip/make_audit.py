# SPDX-License-Identifier: CC0-1.0
# 完了済みの最終版の証跡を/tmpへ作る。リポジトリへの公開は呼出し側が行う。
from pathlib import Path
from collections import defaultdict
import difflib, hashlib, json, math, statistics, zipfile

R = Path('/home/reinsirk/Atcoder_Env')
D = Path('/tmp/sirkit_wavelet_416569')
LIBRARY = 'DataStructure/Wavelet_Matrix.cpp'
PERFORMANCE = 'Audit/performance-wavelet-416569-2026-11-12.json'
ONLINE = 'Audit/online-wavelet-416569-2026-11-12.json'
EVIDENCE = 'Audit/data/performance-wavelet-416569-2026-11-12.zip'
PREVIOUS = 'Audit/distribution-manifest-before-wavelet-416569-2026-11-12.json'
JOBS = {'wavelet_kth': (416569, 137), 'wavelet_frequency': (416570, 307)}
OP_NAMES = {0:'build', 1:'kth_smallest', 2:'rank', 3:'count_less', 4:'range_freq',
            5:'access', 6:'count_less_equal', 7:'kth_largest', 8:'predecessor', 9:'successor'}


def load(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def encode(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + '\n'


def qualified(row):
    return (row['valid_counts']['final'] >= 5 and row['valid_counts']['control'] >= 2
            and row['ratios']['final'] is not None and row['ratios']['control'] is not None)


def signature(row):
    return (row['compiler'], row['flag'], row['setting'],
            json.dumps(row['case'], sort_keys=True, separators=(',', ':')))


def compact_stats(rows, fields):
    result = []
    for key in sorted({tuple(row[k] for k in fields) for row in rows}):
        group = [row for row in rows if tuple(row[k] for k in fields) == key]
        valid = [row for row in group if qualified(row)]
        row = dict(zip(fields, key)) | dict(cells=len(group), qualified_cells=len(valid))
        if valid:
            row.update(candidate_ratio=math.exp(statistics.mean(math.log(x['ratios']['final']) for x in valid)),
                       identical_control_ratio=math.exp(statistics.mean(math.log(x['ratios']['control']) for x in valid)),
                       minimum_ratio=min(x['ratios']['final'] for x in valid),
                       maximum_ratio=max(x['ratios']['final'] for x in valid))
        result.append(row)
    return result


def measurements(kind, fixtures):
    jobs = load(D / f'final_{kind}_jobs.json')
    summary = load(D / f'final_{kind}_summary.json')
    raw = load(D / f'final_{kind}_raw.json')
    assert jobs and len(jobs) == len(summary) and raw, (kind, '未完了')
    expected = set()
    for job in jobs:
        copy = dict(job)
        if kind == 'whole': copy['case'] = job['case']['id']
        key = signature(copy)
        assert key not in expected, (kind, '重複job', key)
        expected.add(key)
    assert {signature(x) for x in summary} == expected
    assert len({signature(x) for x in summary}) == len(summary)
    grouped = defaultdict(list)
    for row in raw:
        key = signature(row)
        assert key in expected and row['label'] in {'final', 'control'}
        values = [row[k] for k in ['before', 'target', 'after']]
        times = [x['cpu_ns'] for x in values]
        assert all(t > 0 for t in times)
        drift = max(times[0], times[2]) / min(times[0], times[2])
        assert row['calibration_valid'] == (drift <= 1.10)
        assert math.isclose(row['reference_drift'], drift, rel_tol=1e-12)
        assert math.isclose(row['ratio'], times[1] / statistics.median([times[0], times[2]]), rel_tol=1e-12)
        if kind == 'whole':
            correct = fixtures[row['case']]['expected_output_sha256']
            assert all(x['output_sha256'] == correct for x in values)
        else:
            assert len({x['digest'] for x in values}) == 1
        grouped[key].append(row)
    for row in summary:
        samples = grouped[signature(row)]
        for label in ['final', 'control']:
            ratios = [x['ratio'] for x in samples if x['label'] == label and x['calibration_valid']]
            assert row['valid_counts'][label] == len(ratios)
            assert (row['ratios'][label] is None) == (not ratios)
            if ratios: assert math.isclose(row['ratios'][label], statistics.median(ratios), rel_tol=1e-12)
        assert row['sufficient'] == qualified(row)
    assert {x['compiler'] for x in summary} == {'gcc', 'clang'}
    # 基準未達の条件も削除せず記録する。採用根拠が全て未達なら処理を止める。
    assert all(any(qualified(x) and x['compiler'] == cc for x in summary) for cc in ['gcc', 'clang'])
    return jobs, summary, raw


def main():
    selection = load(D / 'final_selection.json')
    assert selection['decision'].startswith('adopt') and selection['changes']
    before = sha(D / 'before' / LIBRARY)
    after = sha(R / LIBRARY)
    assert before == sha(D / 'base.hpp') and before != after
    assert after == sha(D / 'final.hpp') == selection['measured_candidate_sha256']
    assert sha(D / (selection['label'] + '.hpp')) == after
    frozen = ['Verify/current/drivers/wavelet_kth_main.cpp',
              'Verify/current/drivers/wavelet_frequency_main.cpp',
              'Verify/current/common/fast_io.hpp', 'Document/wavelet_matrix.md',
              'Examples/wavelet_matrix_example.cpp']
    for name in frozen:
        assert (R / name).read_bytes() == (D / 'before' / name).read_bytes(), name
    if (D / 'frozen_public_files.json').exists():
        for row in load(D / 'frozen_public_files.json'):
            assert row['unchanged'] and sha(R / row['path']) == row['sha256']
    for identifier in JOBS:
        actual = R / f'Verify/current/submissions/{identifier}.cpp'
        assert actual.read_bytes() == (D / f'final_{identifier}.cpp').read_bytes()
        assert actual.read_bytes().startswith(b'#define SKIP_RUNTIME_CHECKS\n')
        assert actual.stat().st_size <= 512 * 1024

    online = {x['id']: x for x in load(D / 'online_records.json')['records']}
    journal = {x['id']: x for x in load(R / 'Verify/current/judgements.json')['entries']}
    for identifier, (submission, time_ms) in JOBS.items():
        old, current = online[identifier], journal[identifier]
        assert old['url'] == f'https://judge.yosupo.jp/submission/{submission}'
        assert old['status'] == 'AC' and old['time_ms'] == time_ms
        assert old['source_hashes'] == {LIBRARY: before}
        assert old['case_results'] and all(x['status'] == 'AC' for x in old['case_results'])
        assert old['driver_sha256'] == sha(R / f'Verify/current/drivers/{identifier}_main.cpp')
        assert old['io_source_hashes'] == {'Verify/current/common/fast_io.hpp': sha(R / 'Verify/current/common/fast_io.hpp')}
        assert current['url'] == old['url'] and current['time_ms'] == time_ms and current['status'] == 'AC'
        assert current['source_hashes'] == {LIBRARY: before} and current['current_source_hashes'] == {LIBRARY: after}
        assert current['needs_resubmission'] and not current['matched_current_generation']
        assert current['current_submission_sha256'] == sha(R / f'Verify/current/submissions/{identifier}.cpp')

    validation = load(D / 'final_validation.json')
    assert validation['header_sha256'] == after and validation['all_passed']
    assert validation['completed_at_utc'] and validation['passed_jobs'] == validation['completed_jobs'] == validation['total_jobs'] == len(validation['jobs'])
    assert validation['total_jobs'] >= 56
    canonical_tests = ['wavelet_matrix_reference_test', 'wavelet_matrix_second_reference_test',
                       'wavelet_matrix_all_widths_test', 'wavelet_matrix_allocation_test']
    expected = {(cc, setting, mode, test) for cc in ['gcc', 'clang']
                for setting in ['checked', 'skip'] for mode in ['default', 'disabled', 'cpu_false']
                for test in canonical_tests}
    actual = {(x['compiler'], x['setting'], x['mode'], x['test']) for x in validation['jobs'] if not x['sanitizer'] and x['test'] in canonical_tests}
    assert actual == expected
    sanitizers = {(x['compiler'], x['setting'], x['mode']) for x in validation['jobs'] if x['sanitizer']}
    assert sanitizers == {(cc, setting, mode) for cc in ['gcc', 'clang'] for setting in ['checked', 'skip'] for mode in ['default', 'disabled']}
    allocation = []
    for row in validation['jobs']:
        assert row['passed'] and row['status'] == 'passed' and row['compile_returncode'] == row['returncode'] == 0 and not row['stderr']
        assert sha(Path(row['source'])) == row['test_sha256']
        if row['test'] == 'wavelet_matrix_allocation_test':
            assert row['counters']['live_delta'] == 0 and row['counters']['failures'] > 0
            allocation.append(row['counters'])
    assert len(allocation) == 12

    builds = load(D / 'final_builds.json')
    assert builds and all(row['returncode'] == 0 for row in builds)
    for row in builds:
        assert sha(Path(row['executable'])) == row['executable_sha256']
    # ビルド・計測で使った最終提出ソースと公開する提出ソースは上でbyte照合する。
    for identifier in JOBS:
        assert {(cc, flag) for cc in ['gcc', 'clang'] for flag in ['native', 'default', 'disabled']} <= {
            (x['compiler'], x['flag']) for x in builds if x['label'] == 'final' and x['kind'] == identifier}

    fixtures_list = load(D / 'fixtures/fixtures.json')
    fixtures = {x['id']: x for x in fixtures_list}
    fixture_info = load(D / 'fixtures/summary.json')
    assert len(fixtures_list) == len(fixtures) == fixture_info['cases'] == 28
    assert set(x['problem'] for x in fixtures_list) == {'range_kth_smallest', 'static_range_frequency'}
    whole_jobs, whole, whole_raw = measurements('whole', fixtures)
    core_jobs, core, core_raw = measurements('core', fixtures)
    for row in whole: row['problem'] = fixtures[row['case']]['problem']
    core_ops = sorted({int(x['case'][0]) for x in core})
    fixture_validation = load(D / 'final_fixture_validation.json')
    assert fixture_validation['all_passed'] and fixture_validation['count'] == len(fixture_validation['rows']) == 336
    assert {(x['compiler'], x['flag'], x['label'], x['fixture']) for x in fixture_validation['rows']} == {
        (cc, flag, label, case) for cc in ['gcc', 'clang'] for flag in ['native', 'default', 'disabled']
        for label in ['base', 'final'] for case in fixtures}
    for row in fixture_validation['rows']:
        assert row['passed'] and row['output_sha256'] == fixtures[row['fixture']]['expected_output_sha256']

    profile = None
    checkpoint = D / 'profiles/checkpoint.json'
    if checkpoint.exists():
        p = load(checkpoint)
        assert p['status'] == 'local_samples_passed_for_snapshot' and p['completed_at_utc'] and p['active'] is None
        assert set(p['counts']) == {'LOCAL_SAMPLE_PASS'} and p['counts']['LOCAL_SAMPLE_PASS'] > 0
        profile = dict(file='profiles/checkpoint.json', sha256=sha(checkpoint),
                       counts=p['counts'], run_id=p['run_id'], scope='派生版と使用例のローカルサンプル。オンライン判定ではない。')

    before_text = (D / 'before' / LIBRARY).read_text()
    final_text = (D / 'final.hpp').read_text()
    (D / 'final.diff').write_text(''.join(difflib.unified_diff(before_text.splitlines(True), final_text.splitlines(True), fromfile='before/Wavelet_Matrix.cpp', tofile='final.hpp')))
    proofs = sorted(str(p.relative_to(D)) for p in (D / 'review').glob('*review.md'))
    for p in (R / 'Verify/current/tests').glob('wavelet_matrix*.cpp'):
        target = D / 'evidence_tests' / p.name
        target.parent.mkdir(exist_ok=True)
        if target.exists(): assert target.read_bytes() == p.read_bytes()
        else: target.write_bytes(p.read_bytes())
    for row in validation['jobs']:
        p = Path(row['source'])
        if p.parent != R / 'Verify/current/tests' and p.suffix == '.cpp':
            target = D / 'evidence_tests' / p.name
            if target.exists(): assert target.read_bytes() == p.read_bytes()
            else: target.write_bytes(p.read_bytes())

    invalid_whole = [x for x in whole if not qualified(x)]
    invalid_core = [x for x in core if not qualified(x)]
    worst = sorted([x for x in core if qualified(x)], key=lambda x:x['ratios']['final'], reverse=True)[:5]
    audit = dict(
        date='2026-11-12', library=LIBRARY, decision=selection['decision'],
        source_sha256=dict(before=before, after=after), selection=selection,
        required_resubmission=[f'Verify/current/submissions/{x}.cpp' for x in JOBS],
        online_evidence=ONLINE,
        online_scope='416569のkth AC137ms・416570のfrequency AC307msは改修前の提出本文/main/共通IOと照合済み。今回の改修版は未提出であり、そのACを現行版や派生版へ転記しない。',
        frozen_public_files={p:sha(R / p) for p in frozen},
        API_scope='型引数・公開の呼び出し形式と戻り値・全符号範囲・所有権・例外保証・件数上限を維持。公開APIを重複追加せず、本体と同じmain/共通IOで比較する。',
        proof_files=proofs, source_diff='final.diff',
        measurement=dict(
            cpu='Intel Core i9-14900K CPU12（P-Core、sibling13）。E-Coreは性能評価しない。',
            compilers=dict(GCC='15.2.0', Clang='21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'),
            flags_scope='C++23 -O2を共通に、各rowのflagで-march=native有無とSIRKIT_DISABLE_SIMDを区別する。正確な引数はfinal_builds.jsonに保存。',
            flags_measured=sorted({x['flag'] for x in whole + core}),
            settings_measured=sorted({x['setting'] for x in core}),
            CPU_scope='Library CheckerのAMD Milan実機の速度比ではない。CPU/コンパイラ/検査/入力/main/IOをそろえたローカル比較。',
            lock='/tmp/sirkit_performance_cpu12.lock', compilation_during_timing=False,
            ASLR='子だけsetarch x86_64 -R、同じactiveパス。',
            protocol='旧版→候補→旧版の組。候補を両端中央値で割る。旧版両端の差が10%以内の組のみ有効とし、候補自身の時間では除外しない。最終比較は候補7組・同一実行体対照3組から開始。不足時だけ候補最大15組・対照最大9組まで補い、候補5組/対照2組を基準とする。rawと各jobを証跡へ保存。',
            fixtures=dict(cases=28, input_bytes_by_problem=fixture_info['input_bytes_by_problem'],
                          source_audit='fixtures/source_audit.json', commands='fixtures/commands.json',
                          exact_oracle='kthは独自の永続セグ木、frequencyは(value,index)ソートと2回のlower_bound。全クエリの出力SHAを持ち、小規模9入力は素朴なsort/countとも照合。',
                          scope='固定版の公式生成入力と補足の符号付き64bit/境界/構築偏重/照会偏重。オンライン非公開入力との同一性は主張しない。'),
            whole=dict(cells=len(whole), qualified_cells=len(whole)-len(invalid_whole), triplets=len(whole_raw),
                       statistics=compact_stats(whole,['compiler','flag','problem']),
                       insufficient_cells=invalid_whole,
                       raw='final_whole_raw.json', summary='final_whole_summary.json', jobs='final_whole_jobs.json',
                       time='固定main全体の子user+system CPU時間。共通高速IOとSKIP設定を維持。'),
            core=dict(cells=len(core), qualified_cells=len(core)-len(invalid_core), triplets=len(core_raw),
                      statistics=compact_stats(core,['compiler','flag','setting']),
                      operations={str(k):OP_NAMES[k] for k in core_ops},
                      widths=sorted({x['case'][5] for x in core}),
                      insufficient_cells=invalid_core, largest_observed_ratios=worst,
                      raw='final_core_raw.json', summary='final_core_summary.json', jobs='final_core_jobs.json',
                      time='std::clock。入力・照会の生成は外、演算と結果checksumは内。構築は保持配列を計測外で参照して最適化消去を防ぎ、n/q/形/反復/型幅/照会モードを固定。'),
            scope='基準未達セルは除外せず件数と条件を明記する。統計は基準達成セルだけの幾何平均。全条件・全CPUで一律高速とは主張しない。'),
        validation=dict(jobs=validation['total_jobs'], all_passed=True,
                        matrix='48件のGCC/Clang×checked/SKIP×default/disabled/CPU判定false×独立参照/第二参照/全幅/確保失敗。加えて8件のASAN+UBSANと、存在すれば4件の幅縮小しきい値検査。',
                        details='final_validation.json', sha256=sha(D/'final_validation.json'),
                        leak_scope='host ptraceのためLeakSanitizerは無効。独立live allocation counterは12条件でdelta=0。',
                        fixture_comparisons=336, fixture_details='final_fixture_validation.json',
                        fixture_sha256=sha(D/'final_fixture_validation.json'), profiles=profile),
        license='既存CC0実装への独自変更。参考ライブラリの実装コードは新規に取り込まない。公式生成器/第三者ソース、入力/出力本体、実行体は今回の証跡へ含めない。',
        evidence_archive=EVIDENCE,
        evidence_scope='自身の候補・生成スクリプト・代数レビュー・独立参照試験・測定raw・公開提出API原本・入力provenanceを保存。第三者生成器はURL/固定版/SHA等のメタデータのみ。')

    pedantic = load(D / 'pedantic_validation.json')
    assert len(pedantic) == 2 and all(x['passed'] and x['header_sha256'] == after for x in pedantic)
    audit['validation']['pedantic_standard'] = dict(jobs=2, all_passed=True, details='pedantic_validation.json')
    instructions = load(D / 'simd_instructions.json')
    assert all(x['header_sha256'] == after and x['instructions']['vpermd'] > 0 for x in instructions)
    audit['validation']['SIMD_instruction_evidence'] = 'simd_instructions.json'
    audit['measurement']['observed_tradeoffs'] = dict(
        whole_above_three_percent=[x for x in whole if qualified(x) and x['ratios']['final'] > 1.03],
        large_core_above_three_percent=[x for x in core if qualified(x) and x['case'][1] >= 100000 and x['ratios']['final'] > 1.03],
        scope='空列への50万照会はnativeでGCC約0.2ms、Clang約1.3ms増。Clang nativeの存在値のみの頻度照会は約3.6%（約0.5ms）増。性能が一律改善したとは扱わず、他の大規模条件の短縮とのトレードオフとして採用。')
    audit['measurement']['outcome'] = 'P-Coreの-march=native、固定mainの代表最大ケースで、GCCはkth約4.1%・frequency約25.6%、Clangは約3.7%・約25.6%短縮。32bit差分の構築単体は約44〜45%短縮。オンライン実機の比率とは主張しない。'
    audit['superseded_scope'] = 'superseded_wide/は採用前候補8175のfinalという名前の記録をそのまま保存したもの。小さい列の存在値頻度照会の35%増を検出したため、N<=128は従来ループへ戻し、cb6787の採用版ですべての最終検証・測定を取り直した。'

    draft = D / Path(PERFORMANCE).name
    archive = D / Path(EVIDENCE).name
    previous = D / Path(PREVIOUS).name
    previous.write_bytes((D / 'before/Distribution/manifest.json').read_bytes())
    (D / 'audit_draft.json').write_text(encode(audit))
    excluded = {'audit_draft.json', draft.name, 'distribution_update.log'}
    fixture_metadata = {'fixtures.json','summary.json','source_audit.json','commands.json'}
    paths = []
    for p in D.rglob('*'):
        if not p.is_file() or p.name in excluded or p.suffix not in {'.py','.hpp','.cpp','.json','.diff','.md','.log'}: continue
        rel = p.relative_to(D)
        if any(part in {'__pycache__','generator_bins','inputs','outputs','sources','platform_evidence','validation'} for part in rel.parts): continue
        if rel.parts[0] == 'fixtures' and (len(rel.parts) != 2 or p.name not in fixture_metadata): continue
        if rel.parts[0] == 'profiles' and (p.suffix != '.json' or (len(rel.parts)>1 and rel.parts[1] in {'snapshots','artifacts','sources'})): continue
        paths.append(p)
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(paths): z.write(p,p.relative_to(D).as_posix())
    audit['evidence_archive_sha256'] = sha(archive)
    draft.write_text(encode(audit))
    print(encode(dict(audit=str(draft),audit_target=PERFORMANCE,evidence=str(archive),evidence_target=EVIDENCE,
                      previous_manifest=str(previous),previous_manifest_target=PREVIOUS,
                      evidence_bytes=archive.stat().st_size,evidence_files=len(paths),repository_written=False)),end='')

if __name__ == '__main__': main()
