# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,hashlib,json
D=Path('/tmp/sirkit_wavelet_416569');rows=[]
for cc in ['gcc','clang']:
 path=D/f'{cc}_native_final_wavelet_kth';cmd=['objdump','-d',str(path)];p=subprocess.run(cmd,capture_output=True,text=True,check=True)
 rows.append(dict(compiler=cc,executable=path.name,executable_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),command=cmd,header_sha256=hashlib.sha256((D/'final.hpp').read_bytes()).hexdigest(),instructions={t:p.stdout.count(t)for t in ['vpermd','vpmaskmovd','vpmaskmovq','popcnt']},scope='instruction presence only; runtime path separately tested'))
(D/'simd_instructions.json').write_text(json.dumps(rows,indent=2)+'\n')
