# 最終の単純な候補 safe_rank / safe_width の確認

元のrank格納とkthの通常ループを維持し、rankの空区間での終了・作業配列の幅縮小・AVX2安定分割を組み合わせる。safe_rankはrankだけにB<=1の式を追加する。safe_widthはさらに、B<=8では空区間での途中終了を省く元のrankループ、B>8では途中終了付きのrankループをprivate helperで選ぶ。kthのB1専用式やsingleton suffixはこの2候補に含めない。

以前のsafe/safe_b1の検査はsafe_validation.jsonに保存してあるが、その結果を新候補の結果として扱わない。新しい2候補の結果はsafe_final_validation.jsonへ保存する。正本や公開API/main/共有I/Oは変更しない。

## B0

B=bit_width(maximum-base)=0なら全値のordered符号がbaseと同じである。rankは最初に区間検査、空区間、global key範囲を確認する。非空で範囲内のkeyはbaseだけなので、その出現回数はright-left。空列/空区間は先頭で0となり、存在しないlevel[0]を参照しない。欠けたkeyは範囲判定で0になる。

## B1

B=1ならmaximum-base=1で、取り得るoffsetは0か1だけ。level[0]の1はoffset1を表す。ones=rank1(right)-rank1(left)がoffset1の個数、zeros=(right-left)-onesがoffset0の個数なので、code==0ならzeros、code==1ならonesを返せる。先頭の範囲判定により、この式へ来るcodeは必ず0か1である。

Tが符号付きでもorderedの順序符号に対する議論なので同じ。最低値と最低値+1、最高値-1と最高値、-1と0を含む。特に-1から0をまたぐ場合も、ordered符号は隣接し、差は1である。最大unsigned値だけのB0も加算をせず正しく扱う。新しい足し算のオーバーフローやシフト幅は追加しない。

以前比較したsafe_b1のkth式も、k<zerosならoffset0、それ以外ならoffset1という数学的には正しい式だった。ただし最終2候補では性能上の理由でその式を削除し、kthは元の実装のままにしている。

## rank_codeの途中終了の有無

各段の区間はqueryの処理済みprefixと一致する要素だけを含む。途中でleft==rightになれば一致要素がないので即0にできる。途中終了を省略しても、rank1(left)==rank1(right)であるため、その後の遷移で常にleft==rightを保ち、最後は0を返す。

空区間の端点も0..nに収まる。元のrank1はend==nが語境界なら追加wordを参照せずprefixだけを返し、非境界なら最後の実データ語の有効prefixを数える。このため、途中終了を省く場合も範囲外に進まない。ここではatを使うsingleton式を導入しないので、空を1個と誤認する処理もない。

B8という閾値は結果に影響せず、同じ計算の途中終了の費用を変えるだけである。B0/B1はその前に閉形式で処理し、B2..8/B9以上はいずれも元のrankと同じ個数を返す。判定はライブラリの値域幅だけに基づき、提出問題や頂点番号などの固有性を使わない。

## 構築と所有

幅縮小・LUT安定分割の証明はcombined_review.mdとconstruction_review.mdを参照。offset<=maximum-base、B<=32ならWork32が正確で、その他は元の幅を使う。AVX2の4/8係数分割はbit列と安定順を保存する。元のrank格納を維持し、番兵語やpair格納は追加しない。公開のコピー/移動/build/clear/swap、確保失敗時の保証、SKIPの範囲検査除去と容量保護は変えない。

## 検査

新2候補×GCC/Clang×検査有効/SKIPの8ビルドで、既存の独立参照とB0/B1専用試験を同じtranslation unitで実行する。既存参照の本体はmainを名前変更し明示的return0を加える以外は変更せず、原本SHAとwrapper SHAを記録する。

専用試験は8整数型、空・同値・2値、語境界前後、区間の全組、出現回数とkth/min/maxを独立な個数式で照合する。符号端点・-1/0・最大unsignedを含み、検査有効では空へのkth、不正rank範囲、不正順位を確認する。性能測定は行わない。

## safe_smallのn<=128による選択（新ソースの検証は未実施）

safe_small.hppのSHA256は `cb678711a0a132cd685259a4f00c5a30204156c582b51030f87c5c1b3ae725a2`。B0/B1の式はその前に維持し、それ以外のrankでB<=8またはn<=128ならrank_code<false>、その他ならrank_code<true>を使う。

nは構築時から保持する元の要素数であり、判定のために入力を走査したり、新しい状態・確保・検査を追加しない。小さいNでも大きいBでも、falseのループは元と同じ両端rank遷移を全段実行する。途中で空になった区間は以後も空のままで、最終結果は0。trueの途中終了と数学的な結果は等しい。従ってこの追加条件は既存の正しい2つの計算手順の選択を変えるだけであり、結果・有効範囲・所有権・例外保証・公開API・O(B)時間/O(1)領域を変えない。

n=128も含む境界、小さいNの全符号幅、空列は同じ議論で扱える。rankの先頭の区間検査・空判定・global key範囲判定を維持し、SKIPでもn判定と数学的な0判定は残る。kthや構築処理はこの条件では変更しない。問題名・入力の並べ替え・照会バッチ・値の出現分布に依存する選択ではない。

この追記は意味上の互換性の検討だけであり、ビルド・実行・性能測定を行っていない。safe_rank/safe_widthに対する以前のsafe_final_validation.jsonの結果を、新しいsafe_smallの検証結果として転記しない。採用時は親が選定した最終ソースに対して独立参照・境界・標準経路を含む最終matrixを実施する。
