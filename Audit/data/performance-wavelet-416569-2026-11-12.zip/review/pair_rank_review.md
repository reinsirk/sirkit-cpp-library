# 2語ブロックへrank情報をまとめる候補

元は開始時の `DataStructure/Wavelet_Matrix.cpp`。本体・main・公開API・共有I/Oは変更していない。候補の生成器は原本の各置換箇所の個数を検査し、差分とSHAを保存する。

## 格納とrank

Blockは64bit語2個、そのブロックの直前までの1の個数（uint32）、第1語の1の個数（uint8）を持つ。GCC/Clangの通常のx86 ABIではBlockは24Bで、元の2語と2個のuint32の合計24Bと同じ。これは規格上すべてのABIのsizeofを固定する主張ではなく、候補にもsizeof制約を追加しない。内部オブジェクトはword_countと1個のvectorを保持する。

endに対して block=end/128、word=(end/64)%2、offset=end%64。直前ブロックまでの個数に、word==1なら第1語の個数、選択語の下位offset個のpopcountを足す。wordは0/1なので第1語の個数はuint8をsize_tへ広げてwordを掛ければ分岐しない。第1語のpopcountは0..64だからuint8へ正確に格納できる。

offsetは0..63のため1ULL<<offsetは常に定義内。offset=0ではmask=0となりpopcountは0。余分なゼロBlockを末尾へ一つ用意するため、end==nかつnが128の倍数でも、そのゼロBlockを安全に参照できる。nが64の奇数倍なら、最後のBlockの第2語（初期値0）と第1語の個数によって全個数を返す。nが64の倍数でない場合は最後の実データ語とmaskを用いる。n=0ではゼロBlock1個を確保し、build/finishでそのprefix=0を設定する。

## 構築と再構築

word_countはceil(n/64)。buildのパック処理、AVX2のload・shift・movemask、scalar残余は元と同じであり、書き先だけBlockの対応する語へ変更する。logical wordだけを走査し、even wordの前にblock.prefix、even wordを数えた後にsecond_prefixを記録し、合計を累積する。末尾のゼロBlockには合計を置く。返却するゼロの個数は従来と同じn-total。

同じcountへbuildを繰り返す場合、各logical wordは新しくゼロからpackされて上書きされ、even-wordごとのprefixとsecond_prefixも更新する。未使用の最後の語とゼロBlockはlogical writeの対象にならず、構築時のゼロを維持する。finishはset後の全logical wordから同じ情報を再計算し、繰り返しても結果が変わらない。公開のWaveletMatrixはcountをUINT32_MAX以下に制限するので、どの累積prefixもその範囲に収まる。

## 所有と互換性

std::vectorによる所有を維持し、new式、参照寿命、非所有ポインタ、公開型や関数を追加しない。内部クラスのdefault copyはvectorを独立所有する。WaveletMatrixのmove/再build/clear/swapの公開保証は変えない。prefixのための個別確保は不要になり、finishは新規確保しないが、公開buildの一時オブジェクトによる例外保証は維持する。

標準popcount、CPU判定とPOPCNT、SIMD無効化、AVX2の切替条件を変えない。rank1の呼び出し方、set/finish/at/build_bits/build_avx2の引数・戻り値も同じ。各語のpopcountとパックbitは従来と同じ数学値なので、rankを利用するすべての公開操作の結果を維持する。新たなキャッシュ局所性と追加の添字算術には速度上の兼ね合いがあるため、性能の採否は親のP-Core実測へ委ねる。

独立参照4条件と内部component4条件（GCC/Clang・検査有効/SKIP）の実施結果、コマンド、テストと候補のSHAはpair_validation.jsonへ保存する。componentはn=0、64/128前後・奇数語末尾、全幅のbit、同countの全0再build、set後のfinish再実行、copyの独立性を直接確認する。性能測定はしない。
