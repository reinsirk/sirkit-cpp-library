# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib
D=Path('/tmp/sirkit_wavelet_416569');R=Path('/home/reinsirk/Atcoder_Env');header=D/'review/pair_rank.hpp';rows=[]
for cc,args in [('gcc',['g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for st in ['checked','skip']:
  for name,source in [('reference',R/'Verify/current/tests/wavelet_matrix_reference_test.cpp'),('component',D/'review/pair_component.cpp')]:
   exe=D/f'review/{cc}_{st}_pair_{name}';cmd=['taskset','-c','8',*args,'-std=c++23','-O2',*(['-DSKIP_RUNTIME_CHECKS']if st=='skip'else[]),f'-DWAVELET_SOURCE="{header}"',str(source),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);row=dict(compiler=cc,setting=st,test=name,header_sha256=hashlib.sha256(header.read_bytes()).hexdigest(),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),command=cmd,compile_returncode=p.returncode,compile_stderr=p.stderr)
   if p.returncode==0:
    p=subprocess.run(['taskset','-c','8',str(exe)],capture_output=True,text=True);row.update(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,passed=p.returncode==0 and not p.stderr)
   else:row['passed']=False
   rows.append(row);(D/'review/pair_validation.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(cc,st,name,row['passed'],row.get('stdout','').strip(),flush=True);assert row['passed'],row
