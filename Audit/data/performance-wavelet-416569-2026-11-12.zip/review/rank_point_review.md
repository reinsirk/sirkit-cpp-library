# rankの残り候補が0/1要素になった場合の確認

対象は空区間guardのあるrank_point_simd.hppだけ。以前のdraft_missing_empty.hppは対象外であり、試験にも使わない。validate_rank_point.pyは候補内の「right-left<=1」の直後に「left==rightなら0」を確認してからビルドする。

## 不変条件と結果

各通常段の区間は、元の照会区間にあり、既に処理したquery codeのprefixを持つ要素だけを表す。安定分割とrankによる遷移がその不変条件を保つ。

候補が0要素なら完全に一致する要素もないため0。候補が1要素なら、その唯一の要素とqueryの残りのbitを直接比較できる。残りのどれかが異なる時点で完全一致は存在せず0。すべて一致した場合は唯一の候補がqueryそのものであり1。

現在の唯一の位置をi、bitをb、rank1(i)をaとする。rank1(i+1)=a+bなので、元の両端rankを取る遷移は、bitがqueryと一致する場合、b=0ならi-a、b=1ならzero+aへ移る。これは新しい片端rankだけの遷移と同じである。過去のprefixは既に一致しているため、残りを全部比較すればよい。

重複する値が照会区間に複数あれば、それらは同じprefixを通るため、候補数が1になるまでは元と同じ両端の遷移を続ける。最後まで複数残れば従来どおりright-leftを返す。照会区間に含まれる重複が1個だけなら1を返すのが正しい。

## 空区間guardが必要な理由

通常の遷移の後で、範囲内にqueryの次のprefixがなくなることがある。次の段ではright-left=0となるため、<=1の中で必ず先に0を返す必要がある。空なのにat(left)を読むとleft==nで範囲外になる場合や、別の値のsuffixを読み間違って1を返す場合がある。現在の候補はこのguardを持つ。例えば{0,1,6,7}に対する欠けた値2..5と、その全ての部分区間を専用試験で確認する。

## 安全性と境界

非空singletonでは0<=left<right<=nだからat(left)とrank1(left)は有効。次の位置も、選んだ側の存在する唯一の要素の位置へ移るのでn未満である。suffix中のrightは更新しないが、その後はrightを参照せず一致/不一致でreturnする。シフトはdepth<bitsの間だけで、幅は0..digits-1。

先頭のrange検査とglobal key範囲の判定を維持する。空列/空区間は0。同値だけの非空列（bits=0）は従来どおり区間長を返す。符号端点や全64bitのkeyも元のordered/base差の符号のまま扱う。SKIP時も有効な入力の前提と数学的な0判定は維持する。

追加の走査、確保、共有状態、所有権の変更や公開APIはない。時間O(B)、追加領域O(1)を保つ。構築のnarrow/sentinel/LUTやkth singletonは別操作の既存候補であり、この変更はそのbit列の数学的意味だけを利用する。

独立参照4条件（GCC/Clang・検査有効/SKIP）と専用component2条件（両compiler・検査有効）をrank_point_validation.jsonへ保存する。componentは8整数型の全符号幅、空/全区間、missing key、重複、129要素の語境界、invalid rangeをstd::countで照合する。性能測定はしない。
