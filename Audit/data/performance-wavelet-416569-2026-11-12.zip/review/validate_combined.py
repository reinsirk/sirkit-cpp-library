# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib
D=Path('/tmp/sirkit_wavelet_416569');R=Path('/home/reinsirk/Atcoder_Env');rows=[]
for label in ['early_narrow','early_single_narrow','early_single_sentinel_narrow','combined_simd']:
 h=D/(label+'.hpp')
 for cc,args in [('gcc',['g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for st in ['checked','skip']:
   source=R/'Verify/current/tests/wavelet_matrix_reference_test.cpp';exe=D/f'review/{cc}_{st}_{label}_reference';cmd=['taskset','-c','8',*args,'-std=c++23','-O2',*(['-DSKIP_RUNTIME_CHECKS']if st=='skip'else[]),f'-DWAVELET_SOURCE="{h}"',str(source),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);row=dict(candidate=label,compiler=cc,setting=st,command=cmd,header_sha256=hashlib.sha256(h.read_bytes()).hexdigest(),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),compile_returncode=p.returncode,compile_stderr=p.stderr)
   if p.returncode==0:
    p=subprocess.run(['taskset','-c','8',str(exe)],capture_output=True,text=True);row.update(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,passed=p.returncode==0 and not p.stderr)
   else:row['passed']=False
   rows.append(row);(D/'review/combined_validation.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(label,cc,st,row['passed'],row.get('stdout','').strip(),flush=True);assert row['passed'],row
