# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json,difflib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_wavelet_416569/review');base=(R/'DataStructure/Wavelet_Matrix.cpp').read_text();(D/'base.hpp').write_text(base)
old='''            const auto zeros = bits.build_bits(std::span<const U>(current), shift);
            zero_.push_back(zeros);
            std::size_t low = 0, high = zeros;
            for (U value : current) {
                const auto bit = static_cast<std::size_t>((value >> shift) & U{1});
                next[bit != 0 ? high : low] = value;
                low += bit ^ std::size_t{1}; high += bit;
            }
'''
assert base.count(old)==1
# Fused scalar classification and bit packing, reversing the collected ones.
method='''    template<class U> std::size_t build_partition(std::span<const U> values, unsigned shift,
                                                 std::span<U> output) {
        prefix_.resize(words_.size() + 1);
        std::size_t low = 0, high = values.size();
        for (std::size_t word = 0; word < words_.size(); ++word) {
            const auto start = word * 64;
            const auto count = std::min(std::size_t{64}, values.size() - start);
            std::uint64_t packed = 0;
            for (std::size_t i = 0; i < count; ++i) {
                const auto value = values[start + i];
                const auto bit = static_cast<unsigned>((value >> shift) & U{1});
                packed |= std::uint64_t{bit} << i;
                if (bit) output[--high] = value;
                else output[low++] = value;
            }
            words_[word] = packed;
            prefix_[word + 1] = prefix_[word] + wavelet_popcount(packed);
        }
        std::reverse(output.begin() + low, output.end());
        return low;
    }
'''
s=base.replace('    bool at(std::size_t index) const noexcept {',method+'    bool at(std::size_t index) const noexcept {',1)
s=s.replace(old,'''            const auto zeros = bits.build_partition(std::span<const U>(current), shift, std::span<U>(next));
            zero_.push_back(zeros);
''')
(D/'fused_scalar.hpp').write_text(s)
# Table-based stable SIMD partition; reuse existing bit mask rather than retest vector values.
method='''#if !defined(SIRKIT_DISABLE_SIMD) && !defined(SIRKIT_WAVELET_FORCE_SOFTWARE) && (defined(__GNUC__) || defined(__clang__)) && defined(__x86_64__)
    template<class U> __attribute__((target("avx2")))
    void partition_avx2(std::span<const U> values, std::size_t zeros, std::span<U> output) const {
        constexpr unsigned lanes = 32 / sizeof(U);
        static constexpr auto permutation = [] {
            std::array<std::array<std::array<std::int32_t, 8>, 2>, 1u << lanes> table{};
            for (unsigned mask = 0; mask < (1u << lanes); ++mask) {
                for (unsigned group = 0; group < 2; ++group) {
                    unsigned position = 0;
                    for (unsigned i = 0; i < lanes; ++i) if (((mask >> i) & 1u) == group) {
                        for (unsigned part = 0; part < sizeof(U) / 4; ++part)
                            table[mask][group][position++] = static_cast<std::int32_t>(i * (sizeof(U) / 4) + part);
                    }
                }
            }
            return table;
        }();
        static constexpr auto masks = [] {
            std::array<std::array<std::int32_t, 8>, lanes + 1> table{};
            for (unsigned count = 0; count <= lanes; ++count)
                for (unsigned i = 0; i < count * (sizeof(U) / 4); ++i) table[count][i] = -1;
            return table;
        }();
        static constexpr auto counts = [] {
            std::array<unsigned char, 1u << lanes> table{};
            for (unsigned mask = 0; mask < (1u << lanes); ++mask) {
                unsigned count = 0;
                for (unsigned i = 0; i < lanes; ++i) count += (mask >> i) & 1u;
                table[mask] = static_cast<unsigned char>(count);
            }
            return table;
        }();
        std::size_t low = 0, high = zeros, i = 0;
        for (; i + lanes <= values.size(); i += lanes) {
            const auto packed = static_cast<unsigned>((words_[i >> 6] >> (i & 63)) & ((1u << lanes) - 1));
            const auto ones = static_cast<unsigned>(counts[packed]), zero_count = lanes - ones;
            const auto value = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(values.data() + i));
            const auto zero_order = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(permutation[packed][0].data()));
            const auto one_order = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(permutation[packed][1].data()));
            const auto zero_mask = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(masks[zero_count].data()));
            const auto one_mask = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(masks[ones].data()));
            if constexpr (sizeof(U) == 4) {
                _mm256_maskstore_epi32(reinterpret_cast<std::int32_t*>(output.data() + low), zero_mask,
                                      _mm256_permutevar8x32_epi32(value, zero_order));
                _mm256_maskstore_epi32(reinterpret_cast<std::int32_t*>(output.data() + high), one_mask,
                                      _mm256_permutevar8x32_epi32(value, one_order));
            } else {
                // 組込関数が要求する64bitのABI型を使う。
                using StoreWord = decltype(_mm256_extract_epi64(__m256i{}, 0));
                _mm256_maskstore_epi64(reinterpret_cast<StoreWord*>(output.data() + low), zero_mask,
                                      _mm256_permutevar8x32_epi32(value, zero_order));
                _mm256_maskstore_epi64(reinterpret_cast<StoreWord*>(output.data() + high), one_mask,
                                      _mm256_permutevar8x32_epi32(value, one_order));
            }
            low += zero_count; high += ones;
        }
        for (; i < values.size(); ++i) {
            const auto bit = static_cast<std::size_t>((words_[i >> 6] >> (i & 63)) & 1);
            output[bit ? high++ : low++] = values[i];
        }
    }
#endif
    template<class U> void partition(std::span<const U> values, unsigned shift,
                                     std::size_t zeros, std::span<U> output) const {
#if !defined(SIRKIT_DISABLE_SIMD) && !defined(SIRKIT_WAVELET_FORCE_SOFTWARE) && (defined(__GNUC__) || defined(__clang__)) && defined(__x86_64__)
        if constexpr (sizeof(U) == 4 || sizeof(U) == 8) {
#if defined(__AVX2__)
            if (values.size() >= 128) { partition_avx2(values, zeros, output); return; }
#else
            if (values.size() >= 128 && wavelet_has_avx2) { partition_avx2(values, zeros, output); return; }
#endif
        }
#endif
        std::size_t low = 0, high = zeros;
        for (U value : values) {
            const auto bit = static_cast<std::size_t>((value >> shift) & U{1});
            output[bit ? high : low] = value;
            low += bit ^ std::size_t{1}; high += bit;
        }
    }
'''
s=base.replace('#include <algorithm>','#include <algorithm>\n#include <array>',1)
s=s.replace('    bool at(std::size_t index) const noexcept {',method+'    bool at(std::size_t index) const noexcept {',1)
s=s.replace(old,'''            const auto zeros = bits.build_bits(std::span<const U>(current), shift);
            zero_.push_back(zeros);
            bits.partition(std::span<const U>(current), shift, zeros, std::span<U>(next));
''')
(D/'partition_avx2.hpp').write_text(s)
rows=[]
for label in ['fused_scalar','partition_avx2']:
 p=D/(label+'.hpp');s=p.read_text();rows.append(dict(label=label,base_sha256=hashlib.sha256(base.encode()).hexdigest(),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 (D/(label+'.diff')).write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='Wavelet_Matrix.cpp',tofile=label+'.hpp')))
(D/'construction_metadata.json').write_text(json.dumps(rows,indent=2)+'\n')
print(rows)
