# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib,fcntl
D=Path('/tmp/sirkit_wavelet_416569');R=Path('/home/reinsirk/Atcoder_Env');rows=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save():
 p=D/'review/safe_validation.json';t=p.with_name(p.name+'.tmp');t.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');t.replace(p)
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 canonical=R/'Verify/current/tests/wavelet_matrix_reference_test.cpp';original=canonical.read_text();assert original.count('int main() {')==1
 ref=original.replace('int main() {','int run_canonical_reference() {',1);pos=ref.rfind('\n}');assert not ref[pos+2:].strip();ref=ref[:pos]+'\n    return 0;'+ref[pos:]
 assert ref.replace('int run_canonical_reference() {','int main() {',1).replace('\n    return 0;\n}', '\n}',1)==original
 source=D/'review/safe_reference.cpp';source.write_text(ref+'\n'+(D/'review/safe_b1_extra.inc').read_text())
 for label in ['safe','safe_b1']:
  h=D/(label+'.hpp')
  for cc,args in [('gcc',['g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
   for st in ['checked','skip']:
    exe=D/f'review/{cc}_{st}_{label}_reference';cmd=['taskset','-c','8',*args,'-std=c++23','-O2',*(['-DSKIP_RUNTIME_CHECKS']if st=='skip'else[]),f'-DWAVELET_SOURCE="{h}"',str(source),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);row=dict(candidate=label,compiler=cc,setting=st,command=cmd,header_sha256=sha(h),source_sha256=sha(source),canonical_reference_sha256=sha(canonical),extra_source_sha256=sha(D/'review/safe_b1_extra.inc'),scope='Canonical reference text unchanged except rename main+explicit return0; appended B0/B1 independent closed-form cases.',compile_returncode=p.returncode,compile_stderr=p.stderr)
    if p.returncode==0:
     p=subprocess.run(['taskset','-c','8',str(exe)],capture_output=True,text=True);row.update(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,passed=p.returncode==0 and not p.stderr and 'wavelet matrix checks='in p.stdout and 'safe B1 checks='in p.stdout)
    else:row['passed']=False
    rows.append(row);save();print(label,cc,st,row['passed'],row.get('stdout','').strip(),flush=True);assert row['passed'],row
 print('Safe validation all8 compiler runs PASS',flush=True)
