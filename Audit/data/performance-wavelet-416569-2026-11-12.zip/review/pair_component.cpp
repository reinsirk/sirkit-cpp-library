// SPDX-License-Identifier: CC0-1.0
#include WAVELET_SOURCE
#include <cstdio>
#include <cstdlib>
#include <random>
std::uint64_t checks=0;
void check(bool x){++checks;if(!x)std::abort();}
template<class U>void test(std::mt19937_64& rng){
 for(std::size_t n:{0,1,2,31,32,33,63,64,65,127,128,129,191,192,193,255,256,257,1024}){
  reinsirk::detail::WaveletRankBits bits(n);std::vector<U> values(n);
  for(auto&v:values)v=static_cast<U>(rng());
  for(unsigned shift=0;shift<std::numeric_limits<U>::digits;++shift){
   const auto zeros=bits.build_bits(std::span<const U>(values),shift);std::size_t ones=0;
   check(bits.rank1(0)==0);
   for(std::size_t i=0;i<n;++i){const bool expected=((values[i]>>shift)&1)!=0;ones+=expected;check(bits.at(i)==expected);check(bits.rank1(i+1)==ones);}
   check(zeros==n-ones);bits.finish();check(bits.rank1(n)==ones);bits.finish();check(bits.rank1(n)==ones);
   // 同じcountへ全0で再構築し、以前のword/prefixが残らないことを確認する。
   std::vector<U>zero(n);check(bits.build_bits(std::span<const U>(zero),shift)==n);
   for(std::size_t i=0;i<=n;++i)check(bits.rank1(i)==0);
  }
  // set/finishとコピーの独立性も別に確認する。
  for(std::size_t i=0;i<n;i+=3)bits.set(i);bits.finish();auto copy=bits;std::size_t ones=0;
  for(std::size_t i=0;i<n;++i){ones+=i%3==0;check(bits.rank1(i+1)==ones);check(copy.rank1(i+1)==ones);}
  if(n>1){bits.set(1);bits.finish();check(bits.rank1(n)==copy.rank1(n)+1);}
 }
}
int main(){std::mt19937_64 rng(0x41656927);test<std::uint8_t>(rng);test<std::uint16_t>(rng);test<std::uint32_t>(rng);test<std::uint64_t>(rng);std::printf("pair component checks=%ju\n",static_cast<std::uintmax_t>(checks));}
