// SPDX-License-Identifier: CC0-1.0
#include WAVELET_SOURCE
#include <cstdio>
#include <cstdlib>
#include <limits>
std::uint64_t checks=0;void check(bool x){++checks;if(!x)std::abort();}
template<class F>void rejects(F f){bool caught=false;try{f();}catch(const std::out_of_range&){caught=true;}check(caught);}
template<class T>void test(){
 WaveletMatrix<T> empty;
 check(empty.empty());check(empty.predecessor(0,0,T{})==std::nullopt);check(empty.successor(0,0,T{})==std::nullopt);
#ifndef SKIP_RUNTIME_CHECKS
 rejects([&]{empty.kth_smallest(0,0,0);});rejects([&]{empty.kth_largest(0,0,0);});rejects([&]{empty.range_min(0,0);});rejects([&]{empty.range_max(0,0);});
#endif
 for(auto values:{std::vector<T>{T{}},std::vector<T>{std::numeric_limits<T>::lowest()},std::vector<T>{std::numeric_limits<T>::max()},std::vector<T>{std::numeric_limits<T>::max(),T{},std::numeric_limits<T>::lowest(),T{1},std::numeric_limits<T>::max(),T{1},T{}}}){
  WaveletMatrix<T> m(values);
  for(std::size_t l=0;l<values.size();++l){
   check(m.kth_smallest(l,l+1,0)==values[l]);check(m.kth_largest(l,l+1,0)==values[l]);check(m.range_min(l,l+1)==values[l]);check(m.range_max(l,l+1)==values[l]);
#ifndef SKIP_RUNTIME_CHECKS
   rejects([&]{m.kth_smallest(l,l+1,1);});rejects([&]{m.kth_largest(l,l+1,1);});rejects([&]{m.kth_smallest(l,l,0);});rejects([&]{m.kth_largest(l,l,0);});rejects([&]{m.range_min(l,l);});rejects([&]{m.range_max(l,l);});
#endif
   for(std::size_t r=l+1;r<=values.size();++r){std::vector<T>a(values.begin()+l,values.begin()+r);std::sort(a.begin(),a.end());for(std::size_t k=0;k<a.size();++k){check(m.kth_smallest(l,r,k)==a[k]);check(m.kth_largest(l,r,k)==a[a.size()-1-k]);}}
  }
#ifndef SKIP_RUNTIME_CHECKS
  rejects([&]{m.kth_smallest(0,values.size()+1,0);});rejects([&]{m.kth_smallest(values.size(),0,0);});
#endif
 }
}
int main(){test<std::int8_t>();test<std::uint8_t>();test<std::int16_t>();test<std::uint16_t>();test<std::int32_t>();test<std::uint32_t>();test<std::int64_t>();test<std::uint64_t>();std::printf("single component checks=%ju\n",static_cast<std::uintmax_t>(checks));}
