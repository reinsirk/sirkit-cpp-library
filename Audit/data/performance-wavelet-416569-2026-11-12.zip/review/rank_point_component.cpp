// SPDX-License-Identifier: CC0-1.0
#include WAVELET_SOURCE
#include <cstdio>
#include <cstdlib>
#include <random>
std::uint64_t checks=0;void check(bool x){++checks;if(!x)std::abort();}
template<class F>void rejects(F f){bool caught=false;try{f();}catch(const std::out_of_range&){caught=true;}check(caught);}
template<class T>void test(std::mt19937_64& rng){
 const T lo=std::numeric_limits<T>::lowest(),hi=std::numeric_limits<T>::max();
 std::vector<std::vector<T>>datasets{{},{T{}},{lo},{hi},{T{0},T{1},T{6},T{7}},{T{0},T{1},T{0},T{6},T{7},T{6},T{7}},{lo,static_cast<T>(lo+1),T{},T{1},static_cast<T>(hi-1),hi,lo,hi}};
 std::vector<T>duplicates(129);for(std::size_t i=0;i<duplicates.size();++i)duplicates[i]=static_cast<T>(i%7);datasets.push_back(duplicates);
 for(const auto&values:datasets){
  const WaveletMatrix<T>matrix(values);std::vector<T>probes{lo,hi,T{0},T{1},T{2},T{3},T{4},T{5},T{6},T{7}};
  for(int i=0;i<12;++i){using U=std::make_unsigned_t<T>;probes.push_back(std::bit_cast<T>(static_cast<U>(rng())));}
  for(std::size_t l=0;l<=values.size();++l)for(std::size_t r=l;r<=values.size();++r)for(T x:probes){const auto expected=static_cast<std::size_t>(std::count(values.begin()+l,values.begin()+r,x));check(matrix.rank(x,l,r)==expected);check(matrix.count(l,r,x)==expected);}
#ifndef SKIP_RUNTIME_CHECKS
  rejects([&]{matrix.rank(T{},0,values.size()+1);});rejects([&]{matrix.rank(T{},1,0);});
#endif
 }
}
int main(){std::mt19937_64 rng(0x41656997);test<std::int8_t>(rng);test<std::uint8_t>(rng);test<std::int16_t>(rng);test<std::uint16_t>(rng);test<std::int32_t>(rng);test<std::uint32_t>(rng);test<std::int64_t>(rng);test<std::uint64_t>(rng);std::printf("rank point component checks=%ju\n",static_cast<std::uintmax_t>(checks));}
