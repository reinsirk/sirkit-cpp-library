# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,difflib,hashlib
D=Path('/tmp/sirkit_wavelet_416569');R=D/'review';R.mkdir(exist_ok=True);base=(D/'before/DataStructure/Wavelet_Matrix.cpp').read_text();s=base
old='''    std::vector<std::uint64_t> words_;
    std::vector<std::uint32_t> prefix_;
public:
    explicit WaveletRankBits(std::size_t count) : words_(count / 64 + (count % 64 != 0)) {}
    void set(std::size_t index) noexcept { words_[index >> 6] |= std::uint64_t{1} << (index & 63); }
'''
new='''    struct Block {
        std::uint64_t words[2]{};
        std::uint32_t prefix{};
        std::uint8_t second_prefix{};
    };
    std::size_t word_count_;
    std::vector<Block> blocks_;
    std::uint32_t record_word(std::size_t word, std::uint64_t packed,
                              std::uint32_t total) noexcept {
        auto& block = blocks_[word >> 1];
        if ((word & 1) == 0) block.prefix = total;
        block.words[word & 1] = packed;
        const auto ones = wavelet_popcount(packed);
        if ((word & 1) == 0) block.second_prefix = static_cast<std::uint8_t>(ones);
        return total + static_cast<std::uint32_t>(ones);
    }
public:
    explicit WaveletRankBits(std::size_t count)
        : word_count_(count / 64 + (count % 64 != 0)),
          blocks_(word_count_ / 2 + (word_count_ % 2 != 0) + 1) {}
    void set(std::size_t index) noexcept { blocks_[index >> 7].words[(index >> 6) & 1] |= std::uint64_t{1} << (index & 63); }
'''
assert s.count(old)==1;s=s.replace(old,new)
a=s.index('#if defined(__POPCNT__)\n    void finish()');b=s.index('#if !defined(SIRKIT_DISABLE_SIMD)',a)
s=s[:a]+'''    void finish() {
        std::uint32_t total = 0;
        for (std::size_t word = 0; word < word_count_; ++word)
            total = record_word(word, blocks_[word >> 1].words[word & 1], total);
        blocks_.back().prefix = total;
    }
'''+s[b:]
assert s.count('prefix_.resize(words_.size() + 1);')==2
s=s.replace('prefix_.resize(words_.size() + 1);','std::uint32_t total = 0;')
s=s.replace('word < words_.size();','word < word_count_;')
old='''            words_[word] = packed;
            prefix_[word + 1] = prefix_[word] + wavelet_popcount(packed);
        }
        return values.size() - prefix_.back();'''
new='''            total = record_word(word, packed, total);
        }
        blocks_.back().prefix = total;
        return values.size() - total;'''
assert s.count(old)==2;s=s.replace(old,new)
a=s.index('    bool at(std::size_t index) const noexcept');b=s.index('\n};\n}\n#endif',a)
s=s[:a]+'''    bool at(std::size_t index) const noexcept { return (blocks_[index >> 7].words[(index >> 6) & 1] >> (index & 63)) & 1; }
    std::size_t rank1(std::size_t end) const noexcept {
        const auto& block = blocks_[end >> 7];
        const auto word = (end >> 6) & 1;
        const auto offset = end & 63;
        const auto masked = block.words[word] & ((std::uint64_t{1} << offset) - 1);
        return block.prefix + static_cast<std::size_t>(block.second_prefix) * word +
               static_cast<std::size_t>(wavelet_popcount(masked));
    }'''+s[b:]
assert 'words_'not in s and 'prefix_'not in s
(R/'pair_rank.hpp').write_text(s);(R/'pair_rank.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='base.hpp',tofile='pair_rank.hpp')))
(R/'pair_rank_metadata.json').write_text(json.dumps(dict(base_sha256=hashlib.sha256(base.encode()).hexdigest(),candidate_sha256=hashlib.sha256(s.encode()).hexdigest(),scope='rank co-located 2-word blocks, no source/main/API changes applied'),indent=2)+'\n')
print(hashlib.sha256(s.encode()).hexdigest())
