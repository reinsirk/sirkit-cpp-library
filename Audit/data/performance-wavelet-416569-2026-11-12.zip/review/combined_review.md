# 幅縮小と照会・構築候補の組合せの確認

対象はearly_narrow / early_single_narrow / early_single_sentinel_narrow / combined_simd。正本・main・共有I/Oは変更しない。16条件の独立参照（4候補×GCC/Clang×検査有効/SKIP）をcombined_validation.jsonへ保存する。性能測定はしない。

## Work幅の選択

orderedはTの順序を保つUの符号で、base<=ordered(value)<=maximumが全入力に成立する。offset=ordered(value)-baseは非負でmaximum-base以下。bits=bit_width(maximum-base)が32以下ならoffset<=UINT32_MAXなので、Tが64bitでもWork=uint32への変換は情報を失わない。各段のshiftは0..bits-1だから32bit Workでも常に有効であり、元の64bit表現と同じbit列を取り出す。bits>32ではUの幅を維持する。

min/max走査は圧縮範囲を求める通常の計算であり、検査のための走査ではない。各段のrank bit列と安定分割順は元と同じなので、残したbase/max/bitsと照会操作は元の結果を返す。返却時base+codeは元の値のordered符号に一致する。値がすべて同じ場合はbits=0で、構築用配列を確保せず従来と同じ結果を返す。n=0も既存の早期returnのまま。

current/nextは新しいオブジェクトが独立に所有するvectorであり、inputはconstのまま。確保失敗時の公開build/copy代入は従来の一時オブジェクトとswapによる保証を保つ。UINT32_MAXの件数上限と容量保護は残る。幅縮小は検査省略時も数学的に必要な選択として実行する。

## sentinelの範囲

論理語数w=ceil(n/64)に対しwordsの領域はw+1で、最後はゼロ語。prefixの領域もw+1で、build/finishはword+1<words.sizeのw語だけを走査する。これにより、最後の余分な語を入力側の64要素と誤認しない。

end<=nならend/64<=wであり、prefixとwordの両方を常に安全に読める。offset=end%64が0ならmask=0、popcount=0。end==nが64の倍数でもw番のゼロ語で安全となる。その他の端点は実データ語の下位offset bitだけを数える。シフト幅は0..63。sentinelはset/buildの論理書き込み範囲外なので、再構築でもゼロを維持する。n=0ではw=0で語1個・prefix1個になるが、公開の空列にはそもそもlevelを作らない。

## AVX2分割と幅縮小の組合せ

Work32は8要素、Work64は4要素ずつ処理する。どちらの幅も64を割り切り、iはその幅の倍数なので分類bitは必ず1つの論理word内に収まる。i+lanes<=nの完全な入力ブロックだけをloadし、端数は従来のscalar処理に戻す。i<nなのでsentinelを入力分類として参照しない。

constexprの表は、bit0/bit1それぞれの入力添字を昇順へ並べる。Work64では隣接する32bit2レーンを必ず同じ64bit値として移動する。0/1の全体の領域は[0,zeros)/[zeros,n)で分離し、処理済み件数に応じて各領域の未使用位置へ格納する。maskはそのブロックで実際に書く件数だけを有効にするので、maskoffの格納先を有効領域と数えない。空側のポインタがoutput.endでも、maskstoreの無効レーンはメモリを参照しないという専用命令の意味を使う。通常C++の範囲外アクセスや任意の整数ポインタによる通常のdereferenceを追加しない。

64bit用storeのポインタ型は組込関数が要求するABI型をdecltypeで取得する。これはGCC/Clang x86-64専用のintrinsic経路であり、標準C++の型の別名規則を新たに一般化する主張ではない。標準経路は通常のWork代入のままである。

表はreadonlyで動的確保を増やさない。32/64bit Work、128要素以上、対応するコンパイラ/CPUを満たす場合だけ専用経路へ進み、8/16bit・小さい入力・未対応CPU・SIRKIT_DISABLE_SIMD等はscalar経路へ戻る。32bitへの幅縮小により8要素版を選ぶ場合も、上記のoffsetが正確であるため分類と安定順を保つ。

## 照会側の組合せ

空になったrank区間には目的値がないので0を返せる。kthのsingleton suffixは、rank1(right)=rank1(left)+at(left)とk=0の不変条件から元の残りの遷移と一致する（single_review.md参照）。これらは格納した各段のbit列と安定順だけに依存し、構築のWorkの物理幅には依存しない。公開APIと既定の区間/順位検査はそのまま残る。
