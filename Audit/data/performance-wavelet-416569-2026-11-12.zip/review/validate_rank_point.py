# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib
D=Path('/tmp/sirkit_wavelet_416569');R=Path('/home/reinsirk/Atcoder_Env');header=D/'rank_point_simd.hpp';rows=[]
text=header.read_text();assert 'if (right - left <= 1) {\n                if (left == right) return 0;'in text,'missing empty guard'
for cc,args in [('gcc',['g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for st,name,source in [('checked','reference',R/'Verify/current/tests/wavelet_matrix_reference_test.cpp'),('skip','reference',R/'Verify/current/tests/wavelet_matrix_reference_test.cpp'),('checked','component',D/'review/rank_point_component.cpp')]:
  exe=D/f'review/{cc}_{st}_rank_point_{name}';cmd=['taskset','-c','8',*args,'-std=c++23','-O2',*(['-DSKIP_RUNTIME_CHECKS']if st=='skip'else[]),f'-DWAVELET_SOURCE="{header}"',str(source),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);row=dict(candidate='rank_point_simd',compiler=cc,setting=st,test=name,command=cmd,header_sha256=hashlib.sha256(header.read_bytes()).hexdigest(),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),compile_returncode=p.returncode,compile_stderr=p.stderr)
  if p.returncode==0:
   p=subprocess.run(['taskset','-c','8',str(exe)],capture_output=True,text=True);row.update(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,passed=p.returncode==0 and not p.stderr)
  else:row['passed']=False
  rows.append(row);(D/'review/rank_point_validation.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(cc,st,name,row['passed'],row.get('stdout','').strip(),flush=True);assert row['passed'],row
