# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,hashlib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_wavelet_416569/review');rows=json.loads((D/'construction_validation.json').read_text())
for label in ['partition_avx2']:
 for cc,args in [('gcc',['g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for st,flags in [('checked',[]),('skip',['-DSKIP_RUNTIME_CHECKS']),('standard',['-DSIRKIT_DISABLE_SIMD'])]:
   h=D/(label+'.hpp');src=R/'Verify/current/tests/wavelet_matrix_reference_test.cpp';exe=D/f'{cc}_{st}_{label}_reference';cmd=['taskset','-c','6',*args,'-std=c++23','-O2',*flags,f'-DWAVELET_SOURCE="{h}"',str(src),'-o',str(exe)]
   p=subprocess.run(cmd,text=True,capture_output=True);r=dict(label=label,compiler=cc,setting=st,header_sha256=hashlib.sha256(h.read_bytes()).hexdigest(),test_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),command=cmd,compile_returncode=p.returncode,compile_stderr=p.stderr);assert p.returncode==0,r
   p=subprocess.run(['taskset','-c','6',str(exe)],text=True,capture_output=True);r.update(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,passed=p.returncode==0 and not p.stderr);rows.append(r);(D/'construction_validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,cc,st,p.stdout.strip(),flush=True);assert r['passed'],r
