# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json,difflib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_wavelet_416569/review');base=(D/'base.hpp').read_text()
a=base.index('    void initialize(std::span<const T> values) {');b=base.index('    std::size_t count_less_unchecked(',a)
old=base[a:b]
new='''    template<class Work>
    void build_levels(std::span<const T> values) {
        std::vector<Work> current(n_), next(n_);
        for (std::size_t i = 0; i < n_; ++i)
            current[i] = static_cast<Work>(ordered(values[i]) - base_);
        levels_.reserve(bits_); zero_.reserve(bits_);
        for (unsigned depth = 0; depth < bits_; ++depth) {
            const unsigned shift = bits_ - 1 - depth;
            levels_.emplace_back(n_);
            auto& bits = levels_.back();
            const auto zeros = bits.build_bits(std::span<const Work>(current), shift);
            zero_.push_back(zeros);
            std::size_t low = 0, high = zeros;
            for (Work value : current) {
                const auto bit = static_cast<std::size_t>((value >> shift) & Work{1});
                next[bit != 0 ? high : low] = value;
                low += bit ^ std::size_t{1}; high += bit;
            }
            current.swap(next);
        }
    }
    void initialize(std::span<const T> values) {
        if (values.size() > std::numeric_limits<std::uint32_t>::max())
            throw std::length_error("WaveletMatrix count limit");
        n_ = values.size();
        if (n_ == 0) return;
        base_ = maximum_ = ordered(values[0]);
        for (T value : values) {
            const auto key = ordered(value);
            base_ = std::min(base_, key); maximum_ = std::max(maximum_, key);
        }
        bits_ = static_cast<unsigned>(std::bit_width(static_cast<U>(maximum_ - base_)));
        if (bits_ == 0) return;
        if constexpr (sizeof(U) > sizeof(std::uint32_t)) {
            if (bits_ <= 32) { build_levels<std::uint32_t>(values); return; }
        }
        build_levels<U>(values);
    }
'''
s=base[:a]+new+base[b:];p=D/'narrow.hpp';p.write_text(s)
(D/'narrow.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='Wavelet_Matrix.cpp',tofile='narrow.hpp')))
(D/'narrow_metadata.json').write_text(json.dumps(dict(base_sha256=hashlib.sha256(base.encode()).hexdigest(),candidate_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),public_API_changed=False,construction_only=True),indent=2)+'\n');print('narrow SHA',hashlib.sha256(p.read_bytes()).hexdigest())
