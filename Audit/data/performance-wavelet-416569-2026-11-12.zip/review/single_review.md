# kthの候補区間が1要素になった場合の残りの復元

対象は `single.hpp` と `early_single_pair.hpp`。公開API/main/共通I/Oや正本は変更せず、候補を検査する。後者のpair格納の証明はpair_rank_review.mdを参照する。

## 正当性

初期の有効入力は0<=k<right-leftであり、区間は配列内の半開区間である。各通常段はゼロ側の個数zを求め、k<zならゼロ側へ進み、その他はone側へ進んでkをzだけ減らす。従って、各段の開始時にも0<=k<right-leftを保つ。

right-left==1なら必ずk=0である。left位置のbitをb、rank1(left)をaとすると、rank1(right)=a+bであり、ゼロ側の個数は1-b。

- b=0なら、元のkth手順はゼロ側を選び、新しいleft=left-aとなる。codeへはこの段のbitを追加しない。
- b=1なら、ゼロ側個数は0で、one側を選び、新しいleft=zero_[depth]+aとなる。codeのこの段のbitを1にする。

これは追加したaccess形式のsuffixと一致する。新しい候補区間も長さ1なので、以後の各段でも同じ議論が成立する。既に処理したcodeの上位bitは保存し、各残りbitだけを元と同じ位置へORする。したがって最終のbase+code、符号を戻した返却値も元と一致する。

## 境界と安全性

有効な1要素区間のleft<nであり、at(left)とrank1(left)の添字は常に有効。bit=0の遷移先もzero側の範囲、bit=1の遷移先もone側の範囲に入る。depth<bits_のときだけbits_-1-depthを使い、シフト幅は0..digits-1。全符号範囲を含むTでも元と同じUによるbit演算である。

同値だけの非空列ではbits_=0になり、有効なkに対して従来どおりループを実行せずbaseを返す。空列・空区間や不正kは既定の先頭検査で例外となり、追加ループへ到達しない。SKIP時は元と同じ有効入力の前提である。kth_largest/min/max/predecessor/successorも、有効なkth呼び出しへ変換される限り同じ結果を返す。公開のrange検査とrank検査はそのまま残す。

追加の所有領域・確保・共有状態・入力の走査はない。計算量O(B)、追加領域O(1)を維持する。singleton時だけ後続段の2本目のrankを省き、代わりに1個のbitを読む。通常段ではsingleton判定が追加されるため、性能の採否は親の実測へ委ねる。

後者のearly-rankは、区間が空になった時点で完全なキーを持つ候補がないため0を返せる。singleton復元はkthだけに適用され、rankの早期終了とは相互依存しない。pair格納のrank1は元の数学的なprefix個数と一致するため、この証明をそのまま利用できる。

## 検査

single_validation.jsonへGCC/Clang、検査有効/SKIP、両候補の独立参照・全幅検査・singleton専用検査を保存する。専用検査では空への不正k/区間、1要素へのk=1、全ての整数幅の符号端点・重複を含む全区間全k、kth_largest/min/maxを照合する。性能測定は行わない。
