# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import bench,json,random,statistics,subprocess,fcntl,sys
D=Path('/tmp/sirkit_wavelet_416569');rng=random.Random(56957057);raw=[];summary=[]
kind=sys.argv[1]

def core(cc,label,case,flag,setting):
 bench.activate(D/f'{cc}_{flag}_{setting}_{label}_core')
 p=subprocess.run(['setarch','x86_64','-R','taskset','-c','12',str(D/'active'),*map(str,case)],capture_output=True,text=True,check=True)
 assert not p.stderr;ns,digest=map(int,p.stdout.split());assert ns>0
 return dict(cpu_ns=ns,digest=digest)

def measure(cc,flag,setting,case):
 if kind=='whole':return lambda label:bench.run_whole(cc,label,case,flag)
 return lambda label:core(cc,label,case,flag,setting)

with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 jobs=json.loads((D/('final_'+kind+'_jobs.json')).read_text())
 for job in jobs:
  cc,flag,setting,case=job['compiler'],job['flag'],job['setting'],job['case'];run=measure(cc,flag,setting,case);local=[];attempts={'final':0,'control':0}
  order=['final']*7+['control']*3;rng.shuffle(order)
  while order:
   label=order.pop();attempts[label]+=1
   v=[run(k)for k in ['base',label if label!='control'else'base','base']]
   key='output_sha256'if kind=='whole'else'digest';assert len({r[key]for r in v})==1,(job,label,v)
   b,t,a=[r['cpu_ns']for r in v];drift=max(b,a)/min(b,a)
   r=dict(compiler=cc,flag=flag,setting=setting,case=case['id']if kind=='whole'else case,label=label,rep=attempts[label],before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(r);local.append(r)
   if not order:
    for k,minimum,cap in [('final',5,15),('control',2,9)]:
     count=sum(r['calibration_valid']and r['label']==k for r in local)
     if count<minimum and attempts[k]<cap:order+=[k]*(min(minimum-count,cap-attempts[k]))
  ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in ['final','control']}
  row={k:job[k]for k in ['compiler','flag','setting']};row.update(case=case['id']if kind=='whole'else case,ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},valid_counts={l:len(v)for l,v in ratios.items()},sufficient=len(ratios['final'])>=5 and len(ratios['control'])>=2);summary.append(row)
  print(row,flush=True);(D/('final_'+kind+'_raw.json')).write_text(json.dumps(raw));(D/('final_'+kind+'_summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
