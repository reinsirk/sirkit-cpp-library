# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import difflib
D=Path('/tmp/sirkit_wavelet_416569');base=(D/'base.hpp').read_text();p=(D/'partition.hpp').read_text();n=(D/'early_narrow.hpp').read_text();a=base.index('    void initialize(');b=base.index('    std::size_t count_less_unchecked(',a);na=n.index('    template<class Work>');nb=n.index('    std::size_t count_less_unchecked(',na)
s=base[:a]+n[na:nb]+base[b:]
x=base.index('    std::size_t rank(T value,');y=base.index('    std::size_t count(',x);e=(D/'early.hpp').read_text();ex=e.index('    std::size_t rank(T value,');ey=e.index('    std::size_t count(',ex);assert s.count(base[x:y])==1;s=s.replace(base[x:y],e[ex:ey])
start=p.index('#if !defined(SIRKIT_DISABLE_SIMD) && !defined(SIRKIT_WAVELET_FORCE_SOFTWARE)',p.index('        return values.size() - prefix_.back();',p.index('    template<class U> std::size_t build_bits')));end=p.index('    bool at(',start);methods=p[start:end];pos=s.index('    bool at(');s=s[:pos]+methods+s[pos:];s=s.replace('#include <algorithm>','#include <algorithm>\n#include <array>',1)
old='''            std::size_t low = 0, high = zeros;
            for (Work value : current) {
                const auto bit = static_cast<std::size_t>((value >> shift) & Work{1});
                next[bit != 0 ? high : low] = value;
                low += bit ^ std::size_t{1}; high += bit;
            }
''';assert s.count(old)==1;s=s.replace(old,'            bits.partition(std::span<const Work>(current), shift, zeros, std::span<Work>(next));\n');(D/'safe.hpp').write_text(s)
# At B=1 the value is one of two consecutive ordered codes; no final routing needed.
a=s.index('    std::size_t rank(T value,');b=s.index('    std::size_t count(',a);part=s[a:b];old='''        const U code = static_cast<U>(key - base_);
''';new=old+'''        if (bits_ <= 1) {
            if (bits_ == 0) return right - left;
            const auto ones = levels_[0].rank1(right) - levels_[0].rank1(left);
            return code == 0 ? (right - left) - ones : ones;
        }
''';assert part.count(old)==1;s=s[:a]+part.replace(old,new)+s[b:]
a=s.index('    T kth_smallest(');b=s.index('    T kth_largest(',a);part=s[a:b];old='''        U code = 0;
''';new='''        if (bits_ <= 1) {
            if (bits_ == 0) return restore(base_);
            const auto ones = levels_[0].rank1(right) - levels_[0].rank1(left);
            const auto zeros = (right - left) - ones;
            return restore(static_cast<U>(base_ + static_cast<U>(k >= zeros)));
        }
'''+old;assert part.count(old)==1;s=s[:a]+part.replace(old,new)+s[b:];(D/'safe_b1.hpp').write_text(s)
for label in ['safe','safe_b1']:
 t=(D/(label+'.hpp')).read_text();(D/(label+'.diff')).write_text(''.join(difflib.unified_diff(base.splitlines(True),t.splitlines(True),fromfile='base.hpp',tofile=label+'.hpp')))
