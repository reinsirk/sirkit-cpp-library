# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import bench,random,json,statistics,fcntl
D=Path('/tmp/sirkit_wavelet_416569');rng=random.Random(416569);labels=['early','sentinel','early_sentinel','pair','early_pair','single','early_single_sentinel','early_single_pair','partition','fused','narrow'];raw=[];summary=[]
ids=['range_kth_smallest__official_max_random_00','range_kth_smallest__custom_signed64','static_range_frequency__official_random_05','static_range_frequency__custom_alphabet256','range_kth_smallest__custom_build_dominant']
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for id in ids:
   f=next(x for x in bench.fixtures if x['id']==id);local=[];order=[l for l in labels for _ in range(3)]+['control']*3;rng.shuffle(order)
   for rep,l in enumerate(order):
    v=[bench.run_whole(cc,k,f)for k in ['base',l if l!='control'else'base','base']];assert len({x['output_sha256']for x in v})==1
    b,t,a=[x['cpu_ns']for x in v];drift=max(b,a)/min(b,a);r=dict(compiler=cc,case=id,label=l,rep=rep,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(r);local.append(r)
   ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in labels+['control']};row=dict(compiler=cc,case=id,ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},valid_counts={l:len(v)for l,v in ratios.items()});summary.append(row);print(row,flush=True);(D/'screen_raw.json').write_text(json.dumps(raw));(D/'screen_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
