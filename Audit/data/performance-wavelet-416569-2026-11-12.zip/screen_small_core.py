# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import bench,json,random,statistics,subprocess,fcntl
D=Path('/tmp/sirkit_wavelet_416569');rng=random.Random(5690570);raw=[];summary=[];labels=['safe_small']
cases=[(0,100000,0,0,1,64,0),(0,65536,0,1,1,64,0),(1,200000,200000,0,1,64,0),(2,500000,500000,0,1,64,0),(2,65536,65536,2,2,64,1),(2,65536,65536,3,1,64,1),(2,200000,100000,0,1,64,1),(2,200000,100000,0,1,64,2),(1,65536,65536,1,1,64,3)]+[(op,65536,16384,1,1,64,0)for op in range(3,10)]+[(0,64,0,0,32,32,0),(1,64,4096,1,64,32,0),(2,64,4096,1,64,32,1)]
cases=[cases[i]for i in [2,3,4,5,6,7,17,18]]
def run(cc,label,case):
 bench.activate(D/f'{cc}_native_skip_{label}_core');p=subprocess.run(['setarch','x86_64','-R','taskset','-c','12',str(D/'active'),*map(str,case)],capture_output=True,text=True,check=True);assert not p.stderr;ns,digest=map(int,p.stdout.split());assert ns>0;return dict(cpu_ns=ns,digest=digest)
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for case in cases:
   local=[];order=[l for l in labels for _ in range(5)]+['control']*3;rng.shuffle(order)
   for rep,l in enumerate(order):
    v=[run(cc,k,case)for k in ['base',l if l!='control'else'base','base']];assert len({r['digest']for r in v})==1,(cc,case,l,v)
    b,t,a=[x['cpu_ns']for x in v];drift=max(b,a)/min(b,a);r=dict(compiler=cc,case=list(case),label=l,rep=rep,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(r);local.append(r)
   ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in labels+['control']};row=dict(compiler=cc,case=list(case),ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},valid_counts={l:len(v)for l,v in ratios.items()});summary.append(row);print(row,flush=True);(D/'small_core_screen_raw.json').write_text(json.dumps(raw));(D/'small_core_screen_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
