# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import fcntl,subprocess,json,hashlib,sys
D=Path('/tmp/sirkit_wavelet_416569');R=Path('/home/reinsirk/Atcoder_Env');rows=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for kind in ['whole','core']:
  jobs=json.loads((D/f'final_{kind}_jobs.json').read_text());summary=json.loads((D/f'final_{kind}_summary.json').read_text());assert len(jobs)==len(summary)
 assert json.loads((D/'final_validation.json').read_text())['all_passed']
 assert json.loads((D/'final_fixture_validation.json').read_text())['all_passed']
 assert sha(D/'final.hpp')==json.loads((D/'final_selection.json').read_text())['measured_candidate_sha256']
 assert (R/'DataStructure/Wavelet_Matrix.cpp').read_bytes()==(D/'base.hpp').read_bytes()
 for row in json.loads((D/'frozen_public_files.json').read_text()):assert sha(R/row['path'])==row['sha256']
 target=R/'DataStructure/Wavelet_Matrix.cpp';tmp=target.with_suffix('.cpp.tmp');tmp.write_bytes((D/'final.hpp').read_bytes());tmp.replace(target)
 commands=[['python3',str(D/'apply_online_metadata.py'),'--apply','--performance-audit','Audit/performance-wavelet-416569-2026-11-12.json'],['python3','Scripts/prepare_verify.py','--id','wavelet_kth','--id','wavelet_frequency'],['python3','Scripts/generate_fast_sources.py'],['python3','Scripts/generate_variants.py'],['python3','Scripts/prepare_variant_verify.py'],['python3','Scripts/check_source_api_docs.py','--check']]
 for cmd in commands:
  p=subprocess.run(cmd,cwd=R,capture_output=True,text=True);rows.append(dict(command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));assert p.returncode==0,p.stderr;print(cmd[1], 'PASS',flush=True)
 for identifier in ['wavelet_kth','wavelet_frequency']:assert (R/f'Verify/current/submissions/{identifier}.cpp').read_bytes()==(D/f'final_{identifier}.cpp').read_bytes()
 (D/'publication.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
