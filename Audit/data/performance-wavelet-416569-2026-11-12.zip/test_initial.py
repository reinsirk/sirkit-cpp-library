# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_wavelet_416569');rows=[]
for label in ['early','sentinel','early_sentinel']:
 for cc,args in [('gcc',['g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for st in ['checked','skip']:
   h=D/(label+'.hpp');exe=D/f'{cc}_{st}_{label}_ref';cmd=['taskset','-c','4',*args,'-std=c++23','-O2',*(['-DSKIP_RUNTIME_CHECKS']if st=='skip'else[]),f'-DWAVELET_SOURCE="{h}"',str(R/'Verify/current/tests/wavelet_matrix_reference_test.cpp'),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','4',str(exe)],capture_output=True,text=True);r=dict(label=label,compiler=cc,setting=st,command=cmd,sha256=hashlib.sha256(h.read_bytes()).hexdigest(),returncode=p.returncode,stdout=p.stdout,stderr=p.stderr);rows.append(r);assert p.returncode==0 and not p.stderr,r
 print(label,'reference4 PASS',flush=True)
(D/'initial_validation.json').write_text(json.dumps(rows,indent=2)+'\n')
