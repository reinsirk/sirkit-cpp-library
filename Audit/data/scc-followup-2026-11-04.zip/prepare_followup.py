# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_scc_followup_20261104');s=(D/'before.hpp').read_text()
# 前回と同じ公式/独自入力を生成する部分だけを再利用。
p=(D/'prepare.py').read_text();p=p[:p.index('mark=src.replace')].replace('/tmp/sirkit_scc_speed_20261103','/tmp/sirkit_scc_followup_20261104');(D/'fixtures_prepare.py').write_text(p)
fn='''    for (int root = 0; root < n; ++root) {
        if (entered[root] != -1) continue;
        int v = root;
        int low = entered[v] = clock++;
        Index cursor = next[v], end = begin[v + 1];
        pending.push_back(v);
        for (;;) {
            if (cursor != end) {
                const int u = destination[cursor++];
                if (entered[u] == -1) {
                    next[v] = cursor;
                    ids[v] = low;
                    dfs.push_back(v);
                    v = u;
                    low = entered[v] = clock++;
                    cursor = next[v]; end = begin[v + 1];
                    pending.push_back(v);
                } else low = std::min(low, entered[u]);
                continue;
            }
            const int child_low = low;
            if (child_low == entered[v]) {
                for (;;) {
                    const int u = pending.back(); pending.pop_back();
                    entered[u] = n; ids[u] = count;
                    if (u == v) break;
                }
                ++count;
            }
            if (dfs.empty()) break;
            v = dfs.back(); dfs.pop_back();
            low = std::min(ids[v], child_low);
            cursor = next[v]; end = begin[v + 1];
        }
    }
'''
a=s.index('    for (int root = 0; root < n; ++root) {');b=s.index('    for (auto& id : ids)',a)
local=s[:a]+fn+s[b:];(D/'local.hpp').write_text(local)
# cursorだけローカル化し、low-linkは従来どおりidsに保持する案。
cursor=local.replace('int low = entered[v] = clock++;','entered[v] = ids[v] = clock++;').replace('                    ids[v] = low;\n','').replace('low = entered[v] = clock++;','entered[v] = ids[v] = clock++;').replace('} else low = std::min(low, entered[u]);','} else ids[v] = std::min(ids[v], entered[u]);').replace('const int child_low = low;','const int child_low = ids[v];').replace('low = std::min(ids[v], child_low);','ids[v] = std::min(ids[v], child_low);');(D/'cursor.hpp').write_text(cursor)
# 書き込み前の初期化を省く所有配列は独立の比較候補。
dest=local.replace('#include <limits>','#include <limits>\n#include <memory>').replace('std::vector<int> destination(edges.size());','auto destination = std::make_unique_for_overwrite<int[]>(edges.size());');(D/'dest.hpp').write_text(dest)
for label,src in [('base',s),('cursor',cursor),('local',local),('dest',dest)]:
 driver=(D/'driver.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"',(D/'io.hpp').read_text());(D/f'{label}.cpp').write_text('#define SKIP_RUNTIME_CHECKS\n'+src+'\n'+driver)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:subprocess.run(['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(D/f'{label}.cpp'),'-o',str(D/f'{cc}_{label}')],check=True)
print('Prepared base/cursor/local/dest')
