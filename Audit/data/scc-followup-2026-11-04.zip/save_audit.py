# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,statistics,collections,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_scc_followup_20261104');A=R/'Audit'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def summarize(file,keys):
 rows=json.loads((D/file).read_text());g=collections.defaultdict(lambda:collections.defaultdict(list))
 for r in rows:g[tuple(r[k]for k in keys)][r['label']].append(r['cpu_ns'])
 result=[]
 for k,values in g.items():
  med={a:statistics.median(b)for a,b in values.items()};result.append(dict(**dict(zip(keys,k)),median_cpu_ns=med,ratio_to_before={a:b/med['base']for a,b in med.items()}))
 return result
checks=json.loads((D/'checks.json').read_text());msan=json.loads((D/'msan.json').read_text());assert len(checks)==20 and all(x['returncode']==0 and not x['stderr']for x in checks);assert msan['returncode']==0 and not msan['stderr'];micro=json.loads((D/'micro_raw.json').read_text());assert len(micro)==2380 and {x['label']for x in micro}=={'base','control','local','leaf','leafdest'}
profile=json.loads(sorted((D/'profiles/runs').glob('*.json'))[-1].read_text());assert profile['counts']=={'LOCAL_SAMPLE_PASS':14};normal=json.loads((D/'normal_samples.json').read_text());assert len(normal)==4
files=['before.hpp','two_sat_before.hpp','driver.cpp','io.hpp','cursor.hpp','local.hpp','dest.hpp','stack.hpp','leaf.hpp','leafdest.hpp','adopted.hpp','prepare_followup.py','prepare.log','fixtures_prepare.py','fixtures.json','official_metadata.json','leaf_prepare.py','leaf_prepare.log','screen.py','screen.log','screen_raw.json','leaf_bench.py','leaf_bench.log','leaf_raw.json','leaf_probe.json','micro.cpp','micro_bench.py','micro_bench.log','micro_raw.json','checks.py','checks.log','checks.json','msan.json','generation.log','profiles.log','normal_samples.json','save_audit.py']
archive=A/'data/scc-followup-2026-11-04.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for f in files:z.write(D/f,f)
 for f in ['Graph/SCC.cpp','Graph/Two_SAT.cpp','Verify/current/tests/scc_acl_api_test.cpp','Verify/current/tests/new_scc_two_sat_reference_test.cpp','Verify/current/tests/scc_index_paths_test.cpp','Verify/current/tests/scc_condensation_test.cpp','Verify/current/tests/new_graph_allocation_test.cpp']:z.write(R/f,'final/'+f)
 for p in (D/'profiles').rglob('*.json'):
  if 'attempts'not in p.parts:z.write(p,'profiles/'+p.relative_to(D/'profiles').as_posix())
audit={
 'date':'2026-11-04','decision':'ローカルcursor/low保持、出次数0の即時確定、CSR宛先配列の先行初期化省略を採用。API/main/共通I/O/成分順・非再帰・所有権を維持。',
 'online_confirmation':'Audit/online-scc-415132-2026-11-04.json',
 'online_status':{'before_submission':415132,'before_status':'AC','before_ms':82,'previous_ms':93,'current_status':'未提出','needs_resubmission':['Verify/current/submissions/scc.cpp'],'scope':'TwoSATの共有内部関数も同期。TwoSATの初回オンラインVerifyは今後。既存のオンラインACを新しい本体・派生版へ転記しない。'},
 'changes':['現在頂点のCSR走査位置とlow-linkをローカル保持し、親を中断する直前だけnext/idsへ退避。戻るときは退避lowと子のlowを合成。','出次数0の未訪問頂点はその場で単独成分にする。親lowへの伝播は値を変えないため省き、DFS番号を出辺のある頂点間で順序を保って圧縮。成分確定順は維持。','CSRの宛先はmake_unique_for_overwrite<int[]>で所有。全スロットへ書いてから参照し、先行ゼロ初期化を省略。クラスのコピー/ムーブと返り値の型は変更なし。','手動添字のスタック配列案はGCCの改善が弱いため不採用。入力検査と内部容量保護・uint32/size_t経路は維持。'],
 'correctness_reasoning':['葉の判定はentered[u]==-1の後だけ行う。訪問済み頂点はCSR走査終了によりcursor==endとなるため、未訪問判定を省けない。自己辺は出次数0ではなく通常経路。','親low<=親のDFS番号<未訪問の子のDFS番号。出辺0の子は即座に自身をrootとして確定し、親lowは不変。時計圧縮はlowの大小関係とroot判定を保つ。','子へ降りる直前に親lowを保存するため、復帰先のidsは必ず未確定の退避low。子SCCをpopしても親はそのSCCへ含まれない。','CSRの各頂点の[start,end)は互いに重ならず、degree回の後方書込みで各セルを一度ずつ設定。uint32のm==UINT32_MAXもcursorはm以下、アクセスはm未満。超過時size_tへ切り替える。巨大辺数を実確保した検証とは扱わない。'],
 'environment':{'cpu':'Intel Core i9-14900K P-Core CPU12（core6、sibling13）','compiler_versions':profile['compiler_versions'],'flags':['-std=c++23','-O2','SKIP_RUNTIME_CHECKS'],'march_native':False,'custom_optimization_pragmas':False,'explicit_SIMD_added':False,'governor':'powersave、設定変更・周波数固定なし','measurement':'同一main/共通I/O/コンパイラ/検査設定。mainはwait4 user+system、API単体はstd::clock。順序を乱数化し同じ実行名へ切替、beforeと同じcontrolも計測。flockで自分の性能測定・コンパイル・検証を直列化。E-Coreは対象外。'},
 'measurements':{'screen':summarize('screen_raw.json',['compiler','case']),'final_main':summarize('leaf_raw.json',['compiler','case']),'API':summarize('micro_raw.json',['compiler','n','kind','mode']),'scope':'公式generator取得版の固定seed入力11本と独自19本（32/4096/500000頂点、密グラフ250000頂点2000000辺）。公式/独自の前回29入力SHAは全て一致。稼働中ジャッジのgenerator commit/隠し入力と同一とは断定しない。','observed':'前回82ms版を基準に、main全体の公式相当11入力はGCC約0.2〜2.1%、Clang約2.9〜10.2%短縮。GCCの小さい差はcontrol変動と区別が難しく、同じ割合のオンライン短縮は保証しない。','limitations':['Clang4096頂点の無辺mainは約16%増（controlは約2%減）。小規模の増加は許容する既存方針で採用。大規模の無辺は約0.2%増でcontrolと同程度。','API単体の大きなcontrol変動がある結果は最適化効果と断定しない。例: Clang500000 paired condensationのcontrolは約0.915倍。','全main出力SHA、API checksumを照合。main全体を読む型やI/Oは変更していない。']},
 'validation':{'preliminary_probes':json.loads((D/'leaf_probe.json').read_text()),'final_checks':checks,'memory_sanitizer':msan,'profile_samples':profile['counts'],'normal_samples':normal,'coverage':'69,680グラフ・18,600,039 checksの両Index/独立Kosaraju/到達可能性、全n<=4グラフ、30万鎖/閉路、自己辺/多重辺、コピー/ムーブ/再分解、ACL API型、TwoSAT全探索、縮約Graph、確保失敗を検証。','settings':'GCC/Clang×検査有無。ASan+UBSan、SIRKIT_DISABLE_SIMD。allocation testは各設定109 failures/1091 successes/live_delta=0。MemorySanitizerも同じ18,600,039 checksを通過。','leak_scope':'ASAN_OPTIONS=detect_leaks=0。解放はallocation testのliveカウンタで補足。'},
 'hashes':{'before_scc':sha(D/'before.hpp'),'current_scc':sha(R/'Graph/SCC.cpp'),'before_two_sat':sha(D/'two_sat_before.hpp'),'current_two_sat':sha(R/'Graph/Two_SAT.cpp'),'driver_before_and_after':sha(D/'driver.cpp'),'io_before_and_after':sha(D/'io.hpp')},
 'evidence':{'path':archive.relative_to(R).as_posix(),'sha256':sha(archive),'scope':'自作候補・生データ・ログ・入力SHA/出典・テスト・最終ソース。公式generator原本、実行バイナリ、大きい入力は含めない。'},
 'synchronization':'本体、GCC/Clang、速度優先、提出コードを生成照合。Documentと使用例のAPI/前提/呼出は変更なし。配布ZIP検証はDistribution/validation.json。'
}
(A/'performance-scc-followup-2026-11-04.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n');print('Evidence/audit saved; 20 final checks + MSan, 14 profile samples + 4 normal samples PASS')
