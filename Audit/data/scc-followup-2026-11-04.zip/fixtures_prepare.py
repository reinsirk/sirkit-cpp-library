# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,hashlib,json,random
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_scc_followup_20261104');src=(D/'before.hpp').read_text();meta=[]
for name in ['random','max_random','large_cycle']:
 p=D/'official_generator'/f'{name}.cpp';exe=p.with_suffix('');subprocess.run(['/usr/bin/g++','-std=c++23','-O2',str(p),'-o',str(exe)],check=True)
 for seed in range(1 if name=='large_cycle' else 5):
  f=D/f'official_{name}_{seed}.in'
  with f.open('wb') as out:subprocess.run([str(exe),str(seed)],stdout=out,check=True)
  meta.append(dict(name=f.stem,path=str(f),header=f.read_text().splitlines()[0],sha256=hashlib.sha256(f.read_bytes()).hexdigest(),source=f'https://raw.githubusercontent.com/yosupo06/library-checker-problems/master/graph/scc/gen/{name}.cpp',seed=seed))
for n in [32,4096,500000]:
 for kind in ['empty','line','cycle','star','dag','paired']:
  if kind=='empty':edges=[]
  elif kind in ['line','cycle']:edges=[(i-1,i) for i in range(1,n)]+([(n-1,0)] if kind=='cycle' else [])
  elif kind=='star':edges=[(0,i)for i in range(1,n)]
  elif kind=='dag':
   r=random.Random(9296+n);edges=[]
   for i in range(2*n):
    u,v=r.randrange(n),r.randrange(n)
    if u>v:u,v=v,u
    edges.append((u,v))
  else:edges=[(i,i^1)for i in range(n)]
  f=D/f'custom_{n}_{kind}.in'
  with f.open('w') as out:
   out.write(f'{n} {len(edges)}\n');out.writelines(f'{u} {v}\n'for u,v in edges)
  meta.append(dict(name=f.stem,path=str(f),header=f'{n} {len(edges)}',sha256=hashlib.sha256(f.read_bytes()).hexdigest(),source='own fixture generator'))
(D/'fixtures.json').write_text(json.dumps(meta,indent=2)+'\n')
