# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,random,hashlib,json
D=Path('/tmp/sirkit_scc_followup_20261104');s=(D/'local.hpp').read_text()
old='''        int v = root;
        int low = entered[v] = clock++;
        Index cursor = next[v], end = begin[v + 1];'''
new='''        int v = root;
        Index cursor = next[v], end = begin[v + 1];
        if (cursor == end) {
            entered[v] = n; ids[v] = count++;
            continue;
        }
        int low = entered[v] = clock++;'''
assert old in s;s=s.replace(old,new)
needle='''                if (entered[u] == -1) {
                    next[v] = cursor;'''
new='''                if (entered[u] == -1) {
                    const Index child_cursor = next[u], child_end = begin[u + 1];
                    if (child_cursor == child_end) {
                        entered[u] = n; ids[u] = count++;
                        continue;
                    }
                    next[v] = cursor;'''
assert needle in s;s=s.replace(needle,new).replace('                    cursor = next[v]; end = begin[v + 1];','                    cursor = child_cursor; end = child_end;');(D/'leaf.hpp').write_text(s)
leafdest=s.replace('#include <limits>','#include <limits>\n#include <memory>').replace('std::vector<int> destination(edges.size());','auto destination = std::make_unique_for_overwrite<int[]>(edges.size());');(D/'leafdest.hpp').write_text(leafdest)
for label,src in [('leaf',s),('leafdest',leafdest)]:
 driver=(D/'driver.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"',(D/'io.hpp').read_text());(D/f'{label}.cpp').write_text('#define SKIP_RUNTIME_CHECKS\n'+src+'\n'+driver)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:subprocess.run(['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(D/f'{label}.cpp'),'-o',str(D/f'{cc}_{label}')],check=True)
r=random.Random(73013);f=D/'custom_250000_dense.in'
with f.open('w')as out:
 out.write('250000 2000000\n')
 for i in range(2000000):out.write(f'{r.randrange(250000)} {r.randrange(250000)}\n')
meta=json.loads((D/'fixtures.json').read_text());meta.append(dict(name=f.stem,path=str(f),header='250000 2000000',sha256=hashlib.sha256(f.read_bytes()).hexdigest(),source='own generator, random seed 73013'));(D/'fixtures.json').write_text(json.dumps(meta,indent=2)+'\n')
