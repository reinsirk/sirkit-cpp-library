# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,datetime,sys
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_opt_20261105');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();norm=lambda t:'\n'.join(l.rstrip()for l in t.replace('\r\n','\n').splitlines()if l.strip()and not l.startswith('// Submission:'))
sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv;pv.preserve_submission_annotations()
group=R/'Verify/current/groups/expansion_20261031.json';g=json.loads(group.read_text());p=R/'Verify/current/judgements.json';j=json.loads(p.read_text());records=[]
for sid,vid in [(415261,'hld_path_prod'),(415258,'hld_path_composite')]:
 api=json.loads((D/f'{sid}.json').read_text());o=api['overview'];e=next(e for e in g['entries']if e['id']==vid);source=D/'before/Verify/current/submissions'/f'{vid}.cpp';assert norm(api['source'])==norm(source.read_text());assert o['status']=='AC'
 record=dict(id=vid,status='AC',url=f'https://judge.yosupo.jp/submission/{sid}',time_ms=round(o['time']*1000),memory_bytes=o['memory'],language=o['lang'],submission_time=o['submission_time'],checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),case_results=api['case_results'],submission_sha256=sha(source),uploaded_source_sha256=sha(D/f'{sid}.cpp'),source_hashes={f:sha(D/'before'/f)for f in e['libraries']},driver_sha256=sha(D/'before'/e['driver']),io_source_hashes={'Verify/current/common/fast_io.hpp':sha(D/'before/Verify/current/common/fast_io.hpp')},io_mode='shared_fast_io',matched_current_generation=True,needs_resubmission=False,source_match='改行・空行・行末空白・Submission注記を除き提出時の本体・main・共通IOと一致。',evidence_file='Audit/online-hld-owned-2026-11-05.json');records.append(record);e['submission_urls']=[record['url']];e['limitations']='オンラインでは所有するBITの加算・経路和、またはOrdered Segtreeの代入・非可換経路積を検証。森林・任意根・辺モード・Lazy・コピー/例外・標準代替経路は独立ローカル検証で補足。';j['entries']=[x for x in j['entries']if x['id']!=vid]+[record]
group.write_text(json.dumps(g,ensure_ascii=False,indent=2)+'\n');p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
a=dict(endpoints=[f'https://v3.api.judge.yosupo.jp/submissions/{i}'for i in [415261,415258]],scope='通常版HLDの所有API初回AC326ms/257msを提出コードと照合。以降の高速化を現行ACと扱わない。',records=records)
(R/'Audit/online-hld-owned-2026-11-05.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
from deterministic_zip import write_archive
write_archive(R/'Audit/data/online-hld-owned-2026-11-05.zip',{f:(D/f).read_bytes()for f in ['415261.json','415258.json','415261.cpp','415258.cpp','confirm.py']});print('Both AC/source/main/IO matches recorded')
