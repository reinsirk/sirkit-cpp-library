# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json,subprocess,shutil,os
D=Path('/tmp/sirkit_ntt_416541');fixtures=json.loads((D/'fixtures.json').read_text());verified=set()
def activate(exe):shutil.copyfile(exe,D/'active');(D/'active').chmod(0o700)
def run_core(cc,setting,label,op,n,m):
 activate(D/f'{cc}_{setting}_{label}_core');p=subprocess.run(['setarch','x86_64','-R','taskset','-c','12',str(D/'active'),str(op),str(n),str(m),str(max(1,32768//max(n,m)))],text=True,capture_output=True,check=True);assert not p.stderr
 ns,digest=map(int,p.stdout.split());assert ns>0;return dict(cpu_ns=ns,digest=digest)
def run_whole(cc,label,f):
 activate(D/f'{cc}_{label}_main')
 with Path(f['path']).open('rb')as fi,(D/'output').open('wb')as fo:
  p=subprocess.Popen(['setarch','x86_64','-R','taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,status,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status);assert p.returncode==0
 blob=(D/'output').read_bytes();digest=hashlib.sha256(blob).hexdigest();expected=(f.get('oracle')or{}).get('expected_sha256');assert expected is None or digest==expected,(cc,label,f['name'])
 if (f['sha256'],digest)not in verified:
  a=list(map(int,blob.split()));assert len(a)==f['output_size']and all(0<=v<998244353 for v in a);e=f['evaluation_checks']
  if a:assert a[0]==e['at_zero']and a[-1]==e['last_coefficient']and sum(a)%998244353==e['at_one']and (sum(a[::2])-sum(a[1::2]))%998244353==e['at_minus_one']
  verified.add((f['sha256'],digest))
 return dict(cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),output_sha256=digest)
