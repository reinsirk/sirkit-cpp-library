# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,random,shutil,statistics,fcntl,json
D=Path('/tmp/sirkit_ntt_416541');raw=[];summary=[];rng=random.Random(416532)
labels=['stage_roots','inverse_length','stage_inverse']
def run(cc,setting,label,op,n,m):
 shutil.copyfile(D/f'{cc}_{setting}_{label}_core',D/'active');(D/'active').chmod(0o700)
 p=subprocess.run(['setarch','x86_64','-R','taskset','-c','12',str(D/'active'),str(op),str(n),str(m),str(max(1,32768//max(n,m)))],check=True,text=True,capture_output=True);assert not p.stderr
 ns,digest=map(int,p.stdout.split());assert ns>0;return dict(cpu_ns=ns,digest=digest)
def main():
 with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  for cc in ['gcc','clang']:
   for setting in ['skip','checked']:
    for n in [16,128,1024,65536,524288]:
     for op in [0,1,3,4,5,6]:
      order=[x for x in labels for _ in range(5)]+['control']*3;rng.shuffle(order);local=[]
      for rep,label in enumerate(order):
       values=[run(cc,setting,l,op,n,n)for l in ['base',label if label!='control'else'base','base']];assert len({v['digest']for v in values})==1
       b,t,a=[v['cpu_ns']for v in values];drift=max(b,a)/min(b,a);row=dict(compiler=cc,setting=setting,n=n,m=n,op=op,label=label,rep=rep,before=values[0],target=values[1],after=values[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(row);local.append(row)
      ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in labels+['control']};row=dict(compiler=cc,setting=setting,n=n,m=n,op=op,valid_counts={l:len(v)for l,v in ratios.items()},ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},sufficient=all(len(ratios[l])>=3 for l in labels)and len(ratios['control'])>=2);summary.append(row);print(row,flush=True)
      (D/'math_screen_raw.json').write_text(json.dumps(raw));(D/'math_screen_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print('Completed',len(raw),'triplets',flush=True)

if __name__=='__main__':main()
