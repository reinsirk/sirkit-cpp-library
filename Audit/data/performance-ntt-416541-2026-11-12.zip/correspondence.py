# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib
D=Path('/tmp/sirkit_ntt_416541');rows=[]
def section(exe):
 out=D/(exe.name+'.text');subprocess.run(['objcopy','--dump-section','.text='+str(out),str(exe)],check=True);return out.read_bytes()
for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for kind,settings in [('main',['']),('core',['checked','skip'])]:
  for st in settings:
   a=D/(f'{cc}_final_main'if kind=='main'else f'{cc}_{st}_final_core');b=D/(f'{cc}_stage_inverse_naive_main'if kind=='main'else f'{cc}_{st}_stage_inverse_naive_core');x=section(a);assert x==section(b);rows.append(dict(compiler=cc,setting=st,kind=kind,final_matches_measured=True,text_sha256=hashlib.sha256(x).hexdigest()))
 for st in ['checked','skip']:
  exe=D/f'{cc}_{st}_standard_final_core';cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-DSIRKIT_DISABLE_SIMD',*(['-DSKIP_RUNTIME_CHECKS']if st=='skip'else[]),f'-DHEADER="{D}/final.hpp"',str(D/'core.cpp'),'-o',str(exe)];subprocess.run(cmd,check=True,capture_output=True);old=D/f'{cc}_{st}_standard_stage_inverse_naive_core';x=section(exe);assert x==section(old);rows.append(dict(compiler=cc,setting=st,kind='standard_core',final_matches_measured=True,text_sha256=hashlib.sha256(x).hexdigest()))
(D/'text_correspondence.json').write_text(json.dumps(rows,indent=2)+'\n');print('Final standard/SIMD machine code matches measured candidate.',flush=True)
