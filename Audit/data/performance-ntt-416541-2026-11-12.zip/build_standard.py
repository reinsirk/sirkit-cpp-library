# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json
D=Path('/tmp/sirkit_ntt_416541');rows=[]
for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for setting in ['checked','skip']:
  for label in ['base','stage_inverse_naive']:
   exe=D/f'{cc}_{setting}_standard_{label}_core';cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-DSIRKIT_DISABLE_SIMD',*(['-DSKIP_RUNTIME_CHECKS']if setting=='skip'else[]),f'-DHEADER="{D}/{label}.hpp"',str(D/'core.cpp'),'-o',str(exe)];subprocess.run(cmd,check=True,capture_output=True);rows.append(dict(compiler=cc,setting=setting,label=label,command=cmd));print(cc,setting,label,flush=True)
(D/'standard_builds.json').write_text(json.dumps(rows,indent=2)+'\n')
