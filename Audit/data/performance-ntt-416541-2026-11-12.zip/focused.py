# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,subprocess,statistics,fcntl,random
import bench
D=Path('/tmp/sirkit_ntt_416541');rng=random.Random(541641);raw=[];summary=[]
def run(cc,setting,label,op,n,m,reps):
 bench.activate(D/f'{cc}_{setting}_{label}_core');p=subprocess.run(['setarch','x86_64','-R','taskset','-c','12',str(D/'active'),str(op),str(n),str(m),str(reps)],check=True,capture_output=True,text=True);assert not p.stderr
 ns,digest=map(int,p.stdout.split());return dict(cpu_ns=ns,digest=digest)
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for mode in ['alignment','standard']:
  labels=['stage_inverse_naive','aligned_forward']if mode=='alignment'else['stage_inverse_naive']
  cases=[(4,65536,1),(4,65536,8),(4,524288,1),(0,524288,1),(5,16,2048)]if mode=='alignment'else[(op,n,max(1,32768//n))for op in [0,5,6]for n in [16,1024,524288]]
  for cc in ['gcc','clang']:
   for st in ['checked','skip']:
    for op,n,reps in cases:
     setting=st if mode=='alignment'else st+'_standard';order=[l for l in labels for _ in range(9)]+['control']*9;rng.shuffle(order);local=[]
     for rep,l in enumerate(order):
      v=[run(cc,setting,label,op,n,n,reps)for label in ['base',l if l!='control'else'base','base']];assert len({r['digest']for r in v})==1
      b,t,a=[r['cpu_ns']for r in v];drift=max(b,a)/min(b,a);r=dict(mode=mode,compiler=cc,setting=setting,op=op,n=n,m=n,repetitions=reps,label=l,rep=rep,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(r);local.append(r)
     ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in labels+['control']};r=dict(mode=mode,compiler=cc,setting=setting,op=op,n=n,repetitions=reps,valid_counts={l:len(v)for l,v in ratios.items()},ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},sufficient=all(len(ratios[l])>=5 for l in labels)and len(ratios['control'])>=5);summary.append(r);print(r,flush=True);(D/'focused_raw.json').write_text(json.dumps(raw));(D/'focused_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
