# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,math,statistics,zipfile,shutil
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_ntt_416541');P=Path('/tmp/sirkit_ntt_416532');chosen='stage_inverse_naive'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def encode(a):return json.dumps(a,ensure_ascii=False,indent=2)+'\n'
base=sha(D/'base.hpp');after=sha(R/'Math/NTT.cpp');assert after==sha(D/'final.hpp') and base!=after
validation=load(D/'final_validation.json');assert validation['all_passed']and validation['passed_jobs']==44
profile=load(D/'profiles/checkpoint.json');assert profile['counts']=={'LOCAL_SAMPLE_PASS':10}
whole=load(D/'paired_whole_summary.json');core=load(D/'paired_core_summary.json')
def qualified(row):return row['valid_counts'][chosen]>=5 and row['valid_counts']['control']>=2
assert all(qualified(r)for r in whole+core)
frozen=['Verify/current/drivers/ntt_convolution_main.cpp','Verify/current/common/fast_io.hpp','Examples/ntt_example.cpp']
for f in frozen:assert (R/f).read_bytes()==(D/'before'/f).read_bytes(),f
assert (R/'Verify/current/submissions/ntt_convolution.cpp').read_bytes()==(D/'final_main.cpp').read_bytes()
previous=R/'Audit/distribution-manifest-before-ntt-416541-2026-11-12.json';old=(D/'before/Distribution/manifest.json').read_bytes()
if previous.exists():assert previous.read_bytes()==old
else:previous.write_bytes(old)
def stats(rows,fields):
 result=[]
 for key in sorted({tuple(r[k]for k in fields)for r in rows}):
  a=[r for r in rows if tuple(r[k]for k in fields)==key and qualified(r)]
  if a:result.append(dict(zip(fields,key))|dict(cases=len(a),candidate_ratio=math.exp(statistics.mean(math.log(r['ratios'][chosen])for r in a)),identical_control_ratio=math.exp(statistics.mean(math.log(r['ratios']['control'])for r in a)),minimum_ratio=min(r['ratios'][chosen]for r in a),maximum_ratio=max(r['ratios'][chosen]for r in a)))
 return result
for f in ['ntt_montgomery_reference_test.cpp','formal_power_series_reference_test.cpp','string_math_allocation_test.cpp']:
 p=D/'evidence_tests'/f;p.parent.mkdir(exist_ok=True);shutil.copyfile(R/'Verify/current/tests'/f,p)
metadata=D/'fixtures_metadata';metadata.mkdir(exist_ok=True)
for f in ['source_audit.json','commands.json','summary.json']:
 p=P/'fixtures'/f
 if p.exists():shutil.copyfile(p,metadata/f)
j=next(r for r in load(R/'Verify/current/judgements.json')['entries']if r['id']=='ntt_convolution');assert j['url'].endswith('/416541')and j['time_ms']==53 and j['needs_resubmission']and not j['matched_current_generation']
audit=dict(date='2026-11-12',library='Math/NTT.cpp',decision='adopt_constexpr_stage_roots_direct_length_inverse_and_naive_constant_operand',required_resubmission=['Verify/current/submissions/ntt_convolution.cpp'],online_evidence='Audit/online-ntt-416541-2026-11-12.json',online_scope='416541は変更前の根生成SIMD版で全53ケースAC・53ms。実アップロード本文と変更前スナップショットの本体/main/IOを照合した。注記だけ416532から416541へ直した再生成SHAも別途保存。今回の数式最適化版は未提出であり、そのACを現行版や派生版へ転記しない。',source_sha256=dict(before=base,after=after),measured_candidate_sha256=sha(D/(chosen+'.hpp')),comment_bridge='最終ヘッダーは動的キャッシュの説明2行だけを測定候補から変更。GCC/Clangのmain、検査2設定core、標準経路coreの.textが測定済み候補と一致。',frozen_main_IO_example={f:sha(R/f)for f in frozen},document_change='Document/ntt.mdはroots_capacity/clear_cacheが動的キャッシュを対象とすることだけ明確化。変更履歴・測定記録は追加しない。',document_hashes=dict(before=sha(D/'before/Document/ntt.md'),after=sha(R/'Document/ntt.md')),
 changes=['段ごとの根をconstexprの配列にする。highest_rootを繰り返し二乗して各段の通常表現を作り、従来と同じMontgomery符号化をconstexprで計算する。根の値は従来のruntime pow/encodeとlazy表現まで一致する。','halfは正の2冪で、参照添字countr_zero(half)+1は2..rank。rank=1のループは空。動的キャッシュのstd::vector、サイズ上限、コピー/移動/clear、オブジェクトの大きさは変えない。静的readonly表はO(rank)で動的確保なし。','変換長nはMod−1の正の約数なので、その逆元をMod−(Mod−1)/nで計算する。n*(Mod−(Mod−1)/n)=(n−1)Mod+1。public入口の空/1要素処理と常時有効の長さ検査により、private backwardへは正の対応長だけが入る。','AVX2の直接畳み込みでは固定オペランドbに対するb*Nprime mod2^32を外側で準備し、qをa*(b*Nprime) mod2^32として計算する。通常積とqを並行に計算し、以降の還元は同じ。qの下位32bit、64bit加算範囲、結果のlazy表現を維持。','公開API・main・共通IO・所有権・係数検査・SKIP時の除外・容量保護を維持。新規の別名/公開操作やnew式は追加しない。'],
 dependent_generated_sources=[dict(path=f,before_sha256=sha(D/'before'/f),after_sha256=sha(R/f))for f in ['Math/Formal_Power_Series.cpp','Math/Linear_Recurrence.cpp','Math/Convolution.cpp','Math/Polynomial.cpp']],
 candidates=[dict(name=k,sha256=sha(D/(k+'.hpp')),adopted=k==chosen,reason=reason)for k,reason in [('constant_prepare','根生成の固定積だけでは安定した利益なし。'),('constant_scale','逆変換の固定積だけでは安定した利益なし。'),('constant_naive','GCCの偏った長さで約2〜3%改善、Clangはほぼ同等。組合せへ採用。'),('constant_all','prepare/scaleまで含める追加部分に安定した利益なし。'),('stage_roots','小さいprepareで大幅改善、組合せへ採用。'),('inverse_length','小さいinverseで大幅改善、組合せへ採用。'),('stage_inverse','上記数学2変更の比較用。'),('stage_inverse_naive','数学2変更と直接畳み込み固定積のみ採用。'),('aligned_forward','64B関数配置指定に一貫した効果はなく不採用。')]],
 measurement=dict(topology=load(D/'topology.json'),cpu='i9-14900K CPU12、SMT sibling13、sysfs core_id24、最大6GHzのP-Core。E-Coreは性能評価しない。',compilers=dict(GCC='15.2.0',Clang='21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'),flags=['-std=c++23','-O2'],march_native=False,extra_pragmas=False,compilation_during_timing=False,lock='/tmp/sirkit_performance_cpu12.lock',ASLR='子だけsetarch x86_64 -R、同じactiveパス。',
 protocol='旧版→候補→旧版で1組。候補を両端の旧版中央値で割る。各条件は各候補9組と同一実行体対照3組を決定的shuffle。両端の旧版が10%以内の組のみ有効とし、候補自身の時間では除外しない。各候補5組・対照2組に不足する種だけ最大3回、各3組補充。探索screen/配置比較/標準経路の反復は各スクリプトに別途保持。',
 inputs='前回と同じ固定revision73876f1cbcf082d2b22722924b924d3d65a2f00eの公式53入力と補足20入力。計73件。オンラインとの同一性は主張しない。制約外1048576×1048576を含む。',fixtures_sha256=sha(D/'fixtures.json'),input_provenance='同梱fixtures_metadataとAudit/data/performance-ntt-416532-2026-11-12.zip。巨大入力・外部生成器本体は今回のZIPへ含めない。',independent_outputs='38件の独立な全出力SHA、全入力の端点と多項式評価0/1/−1、前後出力SHA一致。全73入力をGCC/Clang×2候補で一度ずつ照合し、その後は同じ検査済みSHAの全値再パースを省く。',
 whole_time='固定main/共通IO/SKIP/コンパイラ/入力で子のuser+system CPU時間。L>=65536またはmax(n,m)>=200000の34入力×2compiler。',whole_statistics=stats(whole,['compiler']),official_whole_statistics=stats([r for r in whole if r['case'].startswith('official_')],['compiler']),whole_rows=len(whole),whole_triplets=len(load(D/'paired_whole_raw.json')),whole_comparisons_sufficient=True,
 core_time='std::clockのプロセスCPU時間。入力準備は外、API計算・全結果checksum・返却結果破棄は内。coldだけ毎回NTTを作成/解放、ほかは根を準備。prepareは計測外transformで根を観測し、消去最適化を避ける。反復max(1,32768/max(n,m))。',core_operations={0:'normalized cold move',1:'normalized cached move',2:'generic int64 cached',3:'square cached',4:'forward',5:'inverse',6:'prepare cold'},core_sizes=[16,128,1024,65536,524288],core_supplement='33境界、32/33×524288と逆順の偏り、2冪を超える出力長。',core_rows=len(core),core_triplets=len(load(D/'paired_core_raw.json')),selected_candidate_sufficient_cells=sum(qualified(r)for r in core),unused_candidate_limit='比較用stage_inverseのClang checked prepare1024だけ有効3組に留まる。この未採用候補の条件を採否の5組基準達成とは扱わない。採用候補と対照は全164条件で基準を満たす。',
 small_inverse_and_prepare=stats([r for r in core if r['op']in[5,6]and r['n']==r['m']==16],['compiler','setting','op']),large_core_statistics=stats([r for r in core if max(r['n'],r['m'])>=200000],['compiler','setting','op']),
 outcome='大規模main全体はGCC/Clangともほぼ同等（約0.2%程度の差は対照と併せて評価し、高速化成果と強く主張しない）。16要素のprepareは約82〜85%、inverseは約52〜56%短縮。GCCの16/32×524288の直接積は約2〜3%短縮、Clangは概ね同等。新しい公開機能より既存の小さい演算の固定費削減を優先した。',
 focused_standard_and_alignment=load(D/'focused_summary.json'),medium_variation='初回Clang skip cached forward65536は候補+11.5%、同一実行体対照−8.7%。focused再確認では元の配置で約−1.2%（対照−8.2%）、8回連続では約+0.55%（対照+0.18%）。大きな初回差は安定再現せず、配置64B指定も一貫した利益なし。初回rawを消さず保存し、全条件無後退とは断定しない。',all_comparison_outputs_equal=True),
 validation=dict(jobs=44,all_passed=True,conditions='GCC/Clang×検査有効/無効×default/SIRKIT_DISABLE_SIMD/CPU判定falseの検査用ヘッダー。',independent_tests=['独立DFT/直接積、11法、正負整数極値、bool、空、32/33境界、偏り、正規化違反','大規模全1畳み込み・順逆往復・キャッシュ成長/コピー/移動/解放','FPS独立参照、同梱NTTとの二重include','確保失敗・入力不変性・例外解放'],allocation=[r['counters']for r in validation['jobs']if r['test']=='string_math_allocation_test'],sanitizers='NTT独立参照を両compiler・両検査設定・default/SIMD無効でASAN+UBSAN。host ptraceでdetect_leaks=0、解放は独立live counterで確認。',standard_path='静的根と直接逆元の変更は標準経路にも適用。固定オペランドSIMDはSIRKIT_DISABLE_SIMDで除去。標準経路もP-Coreで36条件を比較し、小さい演算の改善と大規模のほぼ同等を確認。',machine_code_evidence=load(D/'text_correspondence.json'),profiles=dict(status=profile['status'],counts=profile['counts'],run_id=profile['run_id']),current_submission_exactly_matches_compiled_final=True,current_submission_bytes=(R/'Verify/current/submissions/ntt_convolution.cpp').stat().st_size,generated_API_docs_and_manifests_checked=True),
 license='CC0の独自NTTに数学式と独自実装を追加。外部実装のコードを取り込まない。公式生成器はURL/固定SHAのメタデータのみ保存し、本体は証跡・配布へ含めない。',evidence_archive='Audit/data/performance-ntt-416541-2026-11-12.zip',evidence_scope='候補/生成器/静的レビュー、公開API応答と注記更新の対応、raw計測/検査/コマンド。巨大入力/出力、実行体、外部生成器本体を除外。')
for f in ['ntt_montgomery_reference_test.cpp','formal_power_series_reference_test.cpp','string_math_allocation_test.cpp']:
 t=D/'evidence_tests'/f;t.parent.mkdir(exist_ok=True);shutil.copyfile(R/'Verify/current/tests'/f,t)
meta=D/'fixtures_metadata';meta.mkdir(exist_ok=True)
for f in ['source_audit.json','commands.json','summary.json']:
 p=P/'fixtures'/f
 if p.exists():shutil.copyfile(p,meta/f)
(D/'audit_draft.json').write_text(encode(audit));archive=R/audit['evidence_archive'];archive.parent.mkdir(exist_ok=True)
paths=[]
for p in D.rglob('*'):
 if not p.is_file()or p.name=='audit_draft.json'or p.suffix not in {'.py','.hpp','.cpp','.json','.diff','.md','.log'}:continue
 rel=p.relative_to(D)
 if rel.parts[0]=='profiles'and (p.suffix!='.json'or (len(rel.parts)>1 and rel.parts[1]in{'snapshots','artifacts','sources'})):continue
 paths.append(p)
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(paths):z.write(p,p.relative_to(D).as_posix())
audit['evidence_archive_sha256']=sha(archive);(R/'Audit/performance-ntt-416541-2026-11-12.json').write_text(encode(audit));print('Audit saved',archive.stat().st_size,'bytes;',len(paths),'files')
