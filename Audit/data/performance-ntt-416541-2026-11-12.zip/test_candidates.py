# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,sys,json,os
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_ntt_416541');rows=[]
for label in sys.argv[1:]:
 exe=D/f'test_{label}';cmd=['taskset','-c','4','/usr/bin/g++','-std=c++23','-O2',f'-DNTT_HEADER="{D}/{label}.hpp"',str(R/'Verify/current/tests/ntt_reference_test.cpp'),'-o',str(exe)];subprocess.run(cmd,check=True,capture_output=True);p=subprocess.run(['taskset','-c','4',str(exe)],check=True,capture_output=True,text=True);assert not p.stderr;rows.append(dict(label=label,command=cmd,stdout=p.stdout,returncode=p.returncode));(D/'candidate_tests.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,p.stdout.strip(),flush=True)
