# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import ast,difflib,hashlib,json
D=Path('/tmp/sirkit_ntt_416541/agent');base=Path('/tmp/sirkit_ntt_416541/base.hpp').read_text();expected='e463880ff12a76cc6ce6998ca7568411892661b71efd24956c6b10b2eba1b662';assert hashlib.sha256(base.encode()).hexdigest()==expected
stage=(D/'stage_inverse.hpp').read_text();naive=(D/'constant_naive.hpp').read_text()
assert hashlib.sha256(stage.encode()).hexdigest()=='6c16ad2d46f8bed5178a3cd261da866ee52f99fa95ae6e90707b94e1f8a25257'
assert hashlib.sha256(naive.encode()).hexdigest()=='d8a5d5ba01e7530d37ac16792d271a8e3be9a8f06d9d183f3e5f4dbd2cde69de'
# 生成器を実行せず、定数の文字列定義だけを読む。
def string_definitions(filename):
 result={}
 def value(node):
  if isinstance(node,ast.Constant)and isinstance(node.value,str):return node.value
  if isinstance(node,ast.Name):return result[node.id]
  if isinstance(node,ast.BinOp)and isinstance(node.op,ast.Add):return value(node.left)+value(node.right)
  raise ValueError('non-string expression')
 for node in ast.parse((D/filename).read_text()).body:
  if isinstance(node,ast.Assign)and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
   try:result[node.targets[0].id]=value(node.value)
   except(KeyError,ValueError):pass
 return result
const=string_definitions('generate_constants.py');roots=string_definitions('generate_stage_roots.py');inverse=string_definitions('generate_inverse_length.py')
anchor=const['anchor'];helper=const['helper']
def add_naive(text):
 assert text.count(anchor)==1
 result=text.replace(anchor,helper+anchor)
 for old,new in [(const['naive_old'],const['naive_new']),(const['naive_product_old'],const['naive_product_new'])]:
  assert result.count(old)==1;result=result.replace(old,new)
 return result
def undo_naive(text):
 assert text.count(helper+anchor)==1
 result=text.replace(helper+anchor,anchor)
 for old,new in [(const['naive_old'],const['naive_new']),(const['naive_product_old'],const['naive_product_new'])]:
  assert result.count(new)==1;result=result.replace(new,old)
 return result
def undo_stage_inverse(text):
 result=text
 for new,old,count in [(roots['include_new'],roots['include_old'],1),(roots['field_anchor']+roots['field'],roots['field_anchor'],1),(roots['step_new'],roots['step_old'],2),(inverse['new_avx'],inverse['old_avx'],1),(inverse['new_scalar'],inverse['old_scalar'],1)]:
  assert result.count(new)==count,(new,result.count(new));result=result.replace(new,old)
 return result
assert add_naive(base)==naive
candidate=add_naive(stage)
assert undo_naive(candidate)==stage
assert undo_stage_inverse(candidate)==naive
assert undo_stage_inverse(undo_naive(candidate))==base
assert undo_naive(undo_stage_inverse(candidate))==base
assert candidate.count('vector_multiply_prepared(')==2
assert 'step_times_inverse' not in candidate and 'inverse_times_negative_inverse' not in candidate
assert 'finish_convolution_avx2' not in candidate and 'bool Pointwise' not in candidate
(D/'stage_inverse_naive.hpp').write_text(candidate)
(D/'stage_inverse_naive.hpp.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),candidate.splitlines(True),fromfile='base.hpp',tofile='stage_inverse_naive.hpp')))
(D/'stage_inverse_naive_metadata.json').write_text(json.dumps(dict(base_sha256=expected,stage_inverse_sha256=hashlib.sha256(stage.encode()).hexdigest(),constant_naive_sha256=hashlib.sha256(naive.encode()).hexdigest(),candidate_sha256=hashlib.sha256(candidate.encode()).hexdigest(),undo_naive_equals_stage_inverse=True,undo_stage_inverse_equals_constant_naive=True,undo_both_equals_base=True,source_bytes=len(candidate.encode()),compiled=False,executed=False),indent=2)+'\n')
