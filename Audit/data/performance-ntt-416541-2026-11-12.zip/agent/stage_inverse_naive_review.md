# 段根・逆元・naive固定積の組合せ

基準は`base.hpp`、SHA-256 `e463880ff12a76cc6ce6998ca7568411892661b71efd24956c6b10b2eba1b662`。
stage_inverse（6c16ad...）へ、constant_naive（d8a5d5...）のprivate helperとnaiveループの変更だけを加える。
生成器は両候補のハッシュを確認し、以下を全て検査する。

- naive変更を戻すとstage_inverseへ完全一致する。
- 段根と逆元の変更を戻すとconstant_naiveへ完全一致する。
- 両方をどちらの順で戻しても基準へ完全一致する。
- vector_multiply_preparedの出現は定義とnaiveの呼出しの2箇所だけ。根生成と逆変換の固定積を変更していない。
- pointwiseと逆変換の統合、bへの最終出力、値の幅の変更は含まない。

## 結果の一致

段根のconstexpr表は、元のpowと同じ正規化された根を同じlazy Montgomery値へ変換する。
変換長の直接逆元は、対応する2冪nがMod-1の約数であることから、元のpowと同じ通常表現の逆元を返す。
これらはprepareおよびNTT逆変換の経路だけに影響し、naiveの短い積はその経路へ入らない。
naiveの固定積ではbq=(b*N') mod 2^32を一度計算し、q=(a*bq) mod 2^32とする。これは元のq=((a*b)*N') mod 2^32と一致する。以降のt+q*Modとシフトは同じなので、数値表現まで同一である。
従来のcoefficientとinputの順を交換するが、各レーンの符号なし64bit積は交換則で同じ。入力の検査とスカラーの端数は元どおり。

## 保持する性質

公開API、インクルードガードと設定マクロ、CPU判定、所有権、入力の不変性、確保・例外、常時有効の長さ・容量保護は変えない。
新helperは既存AVX2の条件内にあり、naiveのSIMD経路からだけ呼ぶ。標準経路や非Montgomery法ではnaiveの固定積変更を実行しない。段根と逆元は標準経路にも同値な計算として適用される。
privateな不変の段根表以外に保持状態はない。静的表は動的な確保やオブジェクトのコピーを増やさず、追加の所有バッファや直接new式を導入しない。
スカラーのbq準備もu64の積からu32へ写す。AVX2で扱うa,b<2ModかつMod<2^30という既存の64bit範囲を維持する。

各変更の数式・境界・全呼出し経路の詳細はstage_roots_review.md、inverse_length_review.md、constant_review.mdに記録している。
本組合せも静的確認だけで、コンパイル・実行・性能測定は行っていない。原本・他の候補・mainは変更していない。
