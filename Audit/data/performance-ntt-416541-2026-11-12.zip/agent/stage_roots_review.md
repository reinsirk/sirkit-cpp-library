# 段ごとの根のconstexpr表

基準SHA-256: `e463880ff12a76cc6ce6998ca7568411892661b71efd24956c6b10b2eba1b662`。
生成器は基準とconstant_allのハッシュ、変更箇所の一意性、逆置換時の元の候補との完全一致を確認する。
公開APIは追加・変更せず、std::arrayのincludeとprivateなstatic constexpr表を加え、スカラーprepareとprepare_avx2のstep計算だけを置き換える。

## 根の一致

Mod-1=d*2^r（dは奇数、r=rank_）とする。
既存highest_root_はRoot^d mod Modの正規化された値である。
新しいtable[r]にこれを置き、table[k-1]=table[k]^2 mod Modとすると、帰納的にtable[k]=Root^(d*2^(r-k)) mod Mod。
半段長half=2^(k-1)の従来stepの指数は(Mod-1)/(2half)=d*2^(r-k)なので、正規化された根の値が完全に一致する。
Rootが乗法群全体の生成元である必要はなく、既存の最大2冪位数を満たすRootについて同じ式が成り立つ。

Montgomery対象では、表の各値に既存encodeと同じ演算を手書きで適用する。
t=value*r_squared_、q=(uint32_t(t)*negative_inverse_) mod 2^32、結果=(t+q*Mod)>>32である。
qの法2^32を明示するためu64の積をu32へ変換するが、元のencodeと同じ下位32bitとなる。結果も正規化し直さず、元のlazy値そのものを保持する。
従来のruntime powが返す値も新表の平方剰余も0..Mod-1の一意な剰余なので、encodeへの入力も同じ。非Montgomery法では表を正規化された値のまま残し、従来のencodeの恒等変換と一致する。
クラス完了前にconstexprメンバー関数を呼ぶ形を避け、ラムダ内は既に定義済みの整数定数と明示演算だけで初期化する。

## 添字と範囲

rank_は既存の奇素数条件により1以上。表はrank_+1個で、最高段から1段までを初期化する。添字0の未使用値は0。
prepareは有効な2冪長だけを受け付け、半段長halfは2からlength/2までの正の2冪。よってk=countr_zero(half)+1は2..rank_で表の範囲内。
rank_=1の場合は最大長2でhalf=2のループへ入らないため、存在しない添字2へアクセスしない。
prepare_avx2も同じhalfの範囲であり、既存表の拡張なら有効なpreviousから始める条件を変更しない。
平方の入力はMod未満でMod<2^31、平方は2^62未満。Montgomery変換の64bit積・q*Mod・加算も既存と同じ上限内。

## 所有・コンパイル条件

表はテンプレートごとの定数領域で、O(rank_)要素。動的確保や実行時の初期化、オブジェクトごとの状態・コピーは増えない。NTTオブジェクトのroots_の確保・所有・コピー・move・clear_cache・roots_capacityは同じ。
同じ表を標準経路も使うため、SIRKIT_DISABLE_SIMD、非AVX2 CPU、Mod>=2^30でも意図的にruntime powを省く。SIMDの条件やCPU判定は変更しない。
std::array、countr_zero、constexprループは標準C++23までで利用できる。128bit拡張や新ISAを使わない。
空・長さ1・不正な長さ・上限超過の早期処理、SKIP_RUNTIME_CHECKS時も維持する長さ・容量保護は変更しない。
constant_allとの組合せは、その候補が使うstepを同一の値で置き換えるだけであり、事前計算するbqも同じになる。

コンパイル・実行・性能測定は行っていない。原本・他の候補・mainは変更していない。
