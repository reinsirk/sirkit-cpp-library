# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import difflib,hashlib,json
D=Path('/tmp/sirkit_ntt_416541/agent');source=Path('/tmp/sirkit_ntt_416541/final.hpp');base=source.read_text();expected='83d672e6e2d74f121ed579755d3e2ba6fa0b6d880a795bafc8c17b07369ff94a';assert hashlib.sha256(base.encode()).hexdigest()==expected
old='''    template<bool Check>
    [[gnu::target("avx2")]]
    void forward_avx2(std::vector<std::uint32_t>& a) const {'''
new='''    template<bool Check>
    [[gnu::target("avx2"),gnu::aligned(64)]]
    void forward_avx2(std::vector<std::uint32_t>& a) const {'''
assert base.count(old)==1 and 'gnu::aligned(64)' not in base
candidate=base.replace(old,new)
assert candidate.replace(new,old)==base
assert candidate.count('gnu::aligned(64)')==1
assert source.read_text()==base
(D/'aligned_forward.hpp').write_text(candidate)
(D/'aligned_forward.hpp.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),candidate.splitlines(True),fromfile='final.hpp',tofile='aligned_forward.hpp')))
(D/'aligned_forward_metadata.json').write_text(json.dumps(dict(baseline_source=str(source),baseline_sha256=expected,candidate_sha256=hashlib.sha256(candidate.encode()).hexdigest(),reverse_verified=True,change='forward_avx2 function alignment only',source_bytes=len(candidate.encode()),compiled=False,executed=False),indent=2)+'\n')
