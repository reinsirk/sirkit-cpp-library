# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import difflib,hashlib,json
D=Path('/tmp/sirkit_ntt_416541/agent');base=Path('/tmp/sirkit_ntt_416541/base.hpp').read_text();expected='e463880ff12a76cc6ce6998ca7568411892661b71efd24956c6b10b2eba1b662';assert hashlib.sha256(base.encode()).hexdigest()==expected
old_avx='''        const auto inverse_n=reinsirk::detail::ntt_power(static_cast<std::uint32_t>(n),Mod-2,Mod);'''
old_scalar='''        const auto inverse_n = reinsirk::detail::ntt_power(static_cast<std::uint32_t>(n), Mod - 2, Mod);'''
comment='''        // nはMod-1の約数（変換長は対応する2冪）。
        // d=(Mod-1)/nなら、n*(Mod-d)=(n-1)*Mod+1。
        // よってMod-dがnの逆元になる。
'''
new_avx=comment+'''        const auto inverse_n=static_cast<std::uint32_t>(Mod - (Mod - 1) / static_cast<std::uint32_t>(n));'''
new_scalar=comment+'''        const auto inverse_n = static_cast<std::uint32_t>(Mod - (Mod - 1) / static_cast<std::uint32_t>(n));'''
def apply(text):
 assert text.count(old_avx)==1 and text.count(old_scalar)==1
 result=text.replace(old_avx,new_avx).replace(old_scalar,new_scalar)
 assert result.replace(new_avx,old_avx).replace(new_scalar,old_scalar)==text
 return result
stage=(D/'stage_roots.hpp').read_text();assert hashlib.sha256(stage.encode()).hexdigest()=='fe6bc7bc2f6b7f671f61390c492a34644d3fc32c98c44cfd7a8f2e06ec7928ad'
rows=[]
for name,text in [('inverse_length',apply(base)),('stage_inverse',apply(stage))]:
 (D/(name+'.hpp')).write_text(text)
 (D/(name+'.hpp.diff')).write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='base.hpp',tofile=name+'.hpp')))
 rows.append(dict(name=name,base_sha256=expected,candidate_sha256=hashlib.sha256(text.encode()).hexdigest(),stage_roots_included=name=='stage_inverse',reverse_verified=True,source_bytes=len(text.encode()),compiled=False,executed=False))
(D/'inverse_length_metadata.json').write_text(json.dumps(rows,indent=2)+'\n')
