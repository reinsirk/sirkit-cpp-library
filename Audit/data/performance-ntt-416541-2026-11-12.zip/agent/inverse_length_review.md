# 変換長の逆元の直接計算

基準SHA-256: `e463880ff12a76cc6ce6998ca7568411892661b71efd24956c6b10b2eba1b662`。
スカラーbackwardとbackward_avx2のinverse_nの累乗だけを直接除算へ置き換え、両箇所に3行の数学的説明を置く。生成器は両方の元の式が1箇所ずつあることと、逆置換時の完全一致を確認する。
stage_inverseはstage_rootsだけと組み合わせ、固定オペランドMontgomery積の変更を含まない。

## 数式と数値範囲

nはMod-1を割り切る正の2冪で、d=(Mod-1)/nは正の整数。
n*(Mod-d)=n*Mod-(Mod-1)=(n-1)*Mod+1なので、Mod-dはnの法Modでの逆元である。
1<=d<=Mod-1だから、返すMod-dは1..Mod-1。従来のFermat法が返す一意な正の逆元と完全に同じ数値となる。
この恒等式の積は証明上の整数演算であり、実装はMod-1、u32除算、Modからの減算だけを行う。
Modは2^31未満、n<=2^rank_<=Mod-1<=2^31-2なので、u32への変換は正確。除数は0でなく、減算のアンダーフローや加算・乗算のオーバーフローを導入しない。
Rootが全乗法群の生成元かどうかは、この逆元の式には関係しない。

## 全ての呼出し経路

- public transform: 空なら直ちにreturn。非空はprepare(a.size())で2冪・上限を検証し、長さ1も個別処理してreturn。inverse指定でbackwardへ入る場合は正の2冪n<=max_lengthが保たれる。
- compute: 空を含む入力と短い方32以下のnaive経路はbackwardへ入らない。NTT経路はresult_sizeの常時上限保護とtransform_sizeの上限保護を通り、bit_ceilした正の2冪をprepareする。短い方>32なので実際のnは128以上。
- square: 長さ32以下は上記のconvolutionへ任せる。大きい場合もresult_size/transform_size/prepareを通るので同じ条件となる。
- backwardのAVX2呼出し: 上記の条件に加え、montgomery_とuse_avx2(n)のCPU対応・n>=16を満たす場合だけ。標準経路に戻る場合もnの条件は同じ。

max_lengthは既存の2^v2(Mod-1)なので、その上限以下の2冪nはMod-1の約数になる。
SKIP_RUNTIME_CHECKSでも内部の長さ・容量保護とpublic prepareの長さ検査は維持されており、この前提を省いていない。
仮にn=1なら式自体も1を返すが、現在の公開経路では長さ1は前段で終了する。

## 保持する性質

逆元の値だけを同値な計算へ置き換え、バタフライ・根・縮小の順序・結果の反転・検査・所有権・例外処理を変更しない。通常表現のinverse_nを返すので、既存Montgomeryの縮小にも同じ値を渡す。
標準経路も意図的に高速化し、SIMD条件・CPU判定・SIRKIT_DISABLE_SIMDは変更しない。追加の配列、確保、動的状態、ISA、公開APIはない。
段の根の表との組合せは別々の同値計算であり、互いの条件や結果を変更しない。

コンパイル・実行・性能測定は行っていない。原本・他の候補・mainは変更していない。
