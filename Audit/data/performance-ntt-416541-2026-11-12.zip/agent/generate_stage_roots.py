# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import difflib,hashlib,json
D=Path('/tmp/sirkit_ntt_416541/agent');B=Path('/tmp/sirkit_ntt_416541/base.hpp');base=B.read_text();expected='e463880ff12a76cc6ce6998ca7568411892661b71efd24956c6b10b2eba1b662';assert hashlib.sha256(base.encode()).hexdigest()==expected
include_old='#include <algorithm>\n#include <bit>'
include_new='#include <algorithm>\n#include <array>\n#include <bit>'
field_anchor='''    static constexpr std::uint32_t r_squared_ = static_cast<std::uint32_t>(std::uint64_t{montgomery_one_}*montgomery_one_%Mod);
'''
field='''    static constexpr std::array<std::uint32_t, rank_ + 1> stage_roots_ = [] {
        std::array<std::uint32_t, rank_ + 1> table{};
        table[rank_] = highest_root_;
        for (int k = rank_; k >= 2; --k)
            table[k - 1] = static_cast<std::uint32_t>(std::uint64_t{table[k]} * table[k] % Mod);
        if constexpr (montgomery_) {
            for (auto& value : table) {
                const auto product = std::uint64_t{value} * r_squared_;
                const auto q = static_cast<std::uint32_t>(std::uint64_t{static_cast<std::uint32_t>(product)} * negative_inverse_);
                value = static_cast<std::uint32_t>((product + std::uint64_t{q} * Mod) >> 32);
            }
        }
        return table;
    }();
'''
step_old='const auto step = encode(reinsirk::detail::ntt_power(Root, static_cast<std::uint32_t>((Mod - 1) / (half * 2)), Mod));'
step_new='const auto step = stage_roots_[std::countr_zero(half) + 1];'
def apply(text):
 assert text.count(include_old)==1 and text.count(field_anchor)==1 and text.count(step_old)==2
 result=text.replace(include_old,include_new).replace(field_anchor,field_anchor+field).replace(step_old,step_new)
 assert result.replace(include_new,include_old).replace(field_anchor+field,field_anchor).replace(step_new,step_old)==text
 return result
constant=(D/'constant_all.hpp').read_text();assert hashlib.sha256(constant.encode()).hexdigest()=='7cfb703e05b5582a6bd32cb37f8393692cab643a35cda584e51206d4cec9c6f4'
rows=[]
for name,text in [('stage_roots',apply(base)),('stage_roots_constant_all',apply(constant))]:
 (D/(name+'.hpp')).write_text(text)
 (D/(name+'.hpp.diff')).write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='base.hpp',tofile=name+'.hpp')))
 rows.append(dict(name=name,base_sha256=expected,candidate_sha256=hashlib.sha256(text.encode()).hexdigest(),reverse_verified=True,constant_all_included=name.endswith('constant_all'),source_bytes=len(text.encode()),compiled=False,executed=False))
(D/'stage_roots_metadata.json').write_text(json.dumps(rows,indent=2)+'\n')
