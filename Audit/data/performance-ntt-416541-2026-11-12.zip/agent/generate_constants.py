# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import difflib,hashlib,json
D=Path('/tmp/sirkit_ntt_416541/agent');B=Path('/tmp/sirkit_ntt_416541/base.hpp');base=B.read_text();expected='e463880ff12a76cc6ce6998ca7568411892661b71efd24956c6b10b2eba1b662';assert hashlib.sha256(base.encode()).hexdigest()==expected
anchor='''#ifndef SKIP_RUNTIME_CHECKS
    [[gnu::always_inline,gnu::target("avx2")]]
    static inline void vector_check'''
helper='''    [[gnu::always_inline,gnu::target("avx2")]]
    static inline __m256i vector_multiply_prepared(__m256i a, __m256i b,
                                                  __m256i b_times_negative_inverse) noexcept {
        const auto mod = _mm256_set1_epi32(static_cast<int>(Mod));
        const auto even = _mm256_mul_epu32(a, b);
        const auto odd = _mm256_mul_epu32(_mm256_srli_epi64(a, 32), _mm256_srli_epi64(b, 32));
        const auto q_even = _mm256_mul_epu32(a, b_times_negative_inverse);
        const auto q_odd = _mm256_mul_epu32(_mm256_srli_epi64(a, 32), _mm256_srli_epi64(b_times_negative_inverse, 32));
        const auto reduced_even = _mm256_srli_epi64(_mm256_add_epi64(even, _mm256_mul_epu32(q_even, mod)), 32);
        const auto reduced_odd = _mm256_slli_epi64(_mm256_srli_epi64(_mm256_add_epi64(odd, _mm256_mul_epu32(q_odd, mod)), 32), 32);
        return _mm256_or_si256(reduced_even, reduced_odd);
    }
'''
assert base.count(anchor)==1
prep_old='''            const auto scale = _mm256_set1_epi32(static_cast<int>(step));
            std::size_t j = 0;'''
prep_new='''            const auto scale = _mm256_set1_epi32(static_cast<int>(step));
            const auto step_times_inverse = static_cast<std::uint32_t>(std::uint64_t{step} * negative_inverse_);
            const auto qscale = _mm256_set1_epi32(static_cast<int>(step_times_inverse));
            std::size_t j = 0;'''
prep_product_old='''                const auto product = vector_multiply(value, scale);'''
prep_product_new='''                const auto product = vector_multiply_prepared(value, scale, qscale);'''
scale_old='''        const auto scale=_mm256_set1_epi32(static_cast<int>(inverse_n));
        const auto reverse=_mm256_setr_epi32(7,6,5,4,3,2,1,0);'''
scale_new='''        const auto scale=_mm256_set1_epi32(static_cast<int>(inverse_n));
        const auto inverse_times_negative_inverse = static_cast<std::uint32_t>(std::uint64_t{inverse_n} * negative_inverse_);
        const auto qscale = _mm256_set1_epi32(static_cast<int>(inverse_times_negative_inverse));
        const auto reverse=_mm256_setr_epi32(7,6,5,4,3,2,1,0);'''
naive_old='''            const auto coefficient=_mm256_set1_epi32(static_cast<int>(encode(a[i])));
            std::size_t j=0;'''
naive_new='''            const auto encoded_coefficient = encode(a[i]);
            const auto coefficient=_mm256_set1_epi32(static_cast<int>(encoded_coefficient));
            const auto coefficient_times_inverse = static_cast<std::uint32_t>(std::uint64_t{encoded_coefficient} * negative_inverse_);
            const auto qcoefficient = _mm256_set1_epi32(static_cast<int>(coefficient_times_inverse));
            std::size_t j=0;'''
naive_product_old='''                const auto product=vector_reduce(vector_multiply(coefficient,input));'''
naive_product_new='''                const auto product=vector_reduce(vector_multiply_prepared(input,coefficient,qcoefficient));'''
changes={
 'prepare':[(prep_old,prep_new),(prep_product_old,prep_product_new)],
 'scale':[(scale_old,scale_new),('vector_multiply(hi,scale)','vector_multiply_prepared(hi,scale,qscale)'),('vector_multiply(lo,scale)','vector_multiply_prepared(lo,scale,qscale)')],
 'naive':[(naive_old,naive_new),(naive_product_old,naive_product_new)],
}
rows=[]
for name,groups in [('constant_prepare',['prepare']),('constant_scale',['scale']),('constant_naive',['naive']),('constant_all',['prepare','scale','naive'])]:
 text=base.replace(anchor,helper+anchor);applied=[]
 for group in groups:
  for old,new in changes[group]:
   assert text.count(old)==1,(name,group,old,text.count(old));text=text.replace(old,new);applied.append((old,new))
 reverted=text
 for old,new in reversed(applied):
  assert reverted.count(new)==1,(name,new);reverted=reverted.replace(new,old)
 assert reverted.replace(helper+anchor,anchor)==base
 (D/(name+'.hpp')).write_text(text)
 (D/(name+'.hpp.diff')).write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='base.hpp',tofile=name+'.hpp')))
 rows.append(dict(name=name,base_sha256=expected,candidate_sha256=hashlib.sha256(text.encode()).hexdigest(),changes=groups,reverse_verified=True,source_bytes=len(text.encode()),compiled=False,executed=False))
(D/'constant_metadata.json').write_text(json.dumps(rows,indent=2)+'\n')
