# 固定オペランドのMontgomery積

基準は`/tmp/sirkit_ntt_416541/base.hpp`、SHA-256 `e463880ff12a76cc6ce6998ca7568411892661b71efd24956c6b10b2eba1b662`。
`generate_constants.py`は基準ハッシュ、置換箇所の一意性、全変更を逆に置換した際の基準完全一致を確認する。元のvector_multiplyと変数同士の乗算経路は変更しない。

## 数式

R=2^32、N'=−Mod^(-1) mod R、t=a*bとする。
元の実装が使うqはq0=(t*N') mod R。
新しい実装は固定値bについてbq=(b*N') mod Rを準備し、q1=(a*bq) mod Rを使う。
法Rの環の結合則により、q0≡(a*b)*N'≡a*(b*N')≡q1 (mod R)。どちらも0..R-1の値なのでq0=q1。

SIMDのq_even/q_oddは64bitの積を保持するが、その次のmul_epu32(q,mod)が使うのは各64bit内の下位32bitだけである。新しいqの上位32bitが元と異なっても結果に影響しない。
通常の積tは元と同じa*bを計算し、以降のt+q*Mod、32bit右シフト、偶奇の合成も同じなので、結果は剰余として同じだけでなく、lazyな数値表現まで一致する。

## レーンと算術範囲

- evenは元と同じ偶数32bitレーン同士の64bit積、oddは両入力の64bit右シフト後の積。
- q_evenはaの偶数レーンとbqの偶数レーンを掛け、q_oddはそれぞれの奇数レーンを掛ける。現在はbqをbroadcastするが、helperは各レーンごとに対応するbqを使う実装である。
- bqのスカラー準備は`static_cast<uint32_t>(uint64_t{b} * negative_inverse_)`。符号なし64bitの積を下位32bitへ写すので、意図した法Rの演算になる。bqの最上位ビットが立つ場合も、set1_epi32で複製したビットをmul_epu32が符号なし32bitとして読む。
- 対応するAVX2経路ではMod<2^30、a,b<2Mod。t<4Mod^2<2^62、q*Mod<2^32*Mod<2^62、和は2^63未満であり、従来の64bit加算の保護を維持する。
- 新しいa*bqの64bit積もa<2^31、bq<2^32なので2^63未満。通常のu32*u32のintrinsic積自体も常にu64に収まる。
- 結果は元と同じ2Mod未満。vector_reduceや後続のworking_add/subtractの前提を変更しない。

## 各候補

| 候補 | 固定値と準備位置 | 変更箇所 |
| --- | --- | --- |
| constant_prepare | encodeしたstep。根の各段のjループの前にbqを1回計算 | prepare_avx2の8要素の積だけ |
| constant_scale | 通常表現のinverse_n。全バタフライ後、反転・縮小ループの前にbqを1回計算 | backward_avx2末尾のlo/hiのSIMD積だけ |
| constant_naive | encodeしたa[i]。外側のiごと、jループの前にbqを1回計算 | naive_avx2の8要素の積だけ |
| constant_all | 上記3個 | 3変更の組合せ |

prepareのstepはMontgomery表現、inverse_nは通常表現だが、helperは同じ生の整数同士のMontgomery積を置き換えるだけなので、表現の違いを変換してはいけない。現候補では元の値をそのまま準備する。
naiveでは固定オペランドを第2引数にするため、元のmultiply(coefficient,input)をmultiply_prepared(input,coefficient,qcoefficient)とする。64bit積の交換則と同じqにより、これも数値表現まで一致する。
スカラーの端数、0/中央の逆変換係数、入力検査の位置と回数、根の表の順序は変えない。

## 保持する性質と測定上の注意

公開API、include、標準C++経路、SIMD無効マクロ、CPU判定、根の確保・コピー・move・clear_cache、所有権、例外、長さ・容量上限の検査は変更しない。新しい状態・配列・直接new式・ISA・入力走査は追加しない。
helperは既存AVX2のコンパイラ・CPU用条件内で、既存のAVX2メソッドからだけ呼ぶ。SIRKIT_DISABLE_SIMD時と非Montgomery法の標準経路では新しい処理を実行しない。
元はt→q→q*Modという依存列だったが、新しいqは準備済みbqから計算でき、t=a*bと並行して開始できる。SIMD乗算命令数は6個のまま。定数の準備やレジスタ配置の費用もあるため、P-Coreで速くなるとは静的確認だけでは断定しない。
コンパイル・実行・性能測定は行っていない。正本・他の候補は変更していない。
