// SPDX-License-Identifier: CC0-1.0
#include "Verify/current/common/fast_io.hpp"
int main(){
 int n{},m{};verify_in>>n>>m;scc_graph graph(n);
 for(int i=0;i<m;++i){int u{},v{};verify_in>>u>>v;graph.add_edge(u,v);}
 const auto groups=graph.scc();verify_out<<groups.size()<<'\n';
 for(const auto& group:groups){verify_out<<group.size();for(int v:group)verify_out<<' '<<v;verify_out<<'\n';}
}
