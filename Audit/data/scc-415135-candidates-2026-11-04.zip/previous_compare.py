# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib,random,statistics,shutil,fcntl,os
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_scc_refine_20261104');P=Path('/tmp/sirkit_scc_followup_20261104');old=(P/'before.hpp').read_bytes();rec=json.loads((R/'Audit/online-scc-415132-2026-11-04.json').read_text())['record'];assert hashlib.sha256(old).hexdigest()==rec['source_hashes']['Graph/SCC.cpp'];(D/'previous.hpp').write_bytes(old)
driver=(D/'driver.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"',(D/'io.hpp').read_text());(D/'previous.cpp').write_text('#define SKIP_RUNTIME_CHECKS\n'+old.decode()+'\n'+driver)
raw=[];rng=random.Random(415135);inputs={x['name']:Path(x['path'])for x in json.loads((D/'fixtures.json').read_text())}
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:subprocess.run(['taskset','-c','4',*args,'-std=c++23','-O2',str(D/'previous.cpp'),'-o',str(D/f'{cc}_previous')],check=True)
 for cc in ['gcc','clang']:
  for case in ['official_random_0','official_random_1','official_max_random_0','official_large_cycle_0','custom_500000_cycle','custom_250000_dense']:
   for rep in range(11):
    labels=['base','control','previous'];rng.shuffle(labels)
    for label in labels:
     shutil.copyfile(D/f'{cc}_{"base"if label=="control"else label}',D/'active');(D/'active').chmod(0o700)
     with inputs[case].open('rb')as fi,(D/'output').open('wb')as fo:
      p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0
     raw.append(dict(compiler=cc,case=case,rep=rep,label=label,cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),sha256=hashlib.sha256((D/'output').read_bytes()).hexdigest()))
   rr=[x for x in raw if x['compiler']==cc and x['case']==case];assert len({x['sha256']for x in rr})==1;m={l:statistics.median(x['cpu_ns']for x in rr if x['label']==l)for l in labels};print(cc,case,'current/82ms',round(m['base']/m['previous'],4),'control/current',round(m['control']/m['base'],4),flush=True);(D/'previous_raw.json').write_text(json.dumps(raw))
