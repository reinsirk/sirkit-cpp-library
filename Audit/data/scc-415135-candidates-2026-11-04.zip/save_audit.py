# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,zipfile,statistics,collections
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_scc_refine_20261104');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (R/'Graph/SCC.cpp').read_bytes()==(D/'before.hpp').read_bytes();assert (R/'Graph/Two_SAT.cpp').read_bytes()==(D/'two_sat_before.hpp').read_bytes();assert (R/'Verify/current/drivers/scc_main.cpp').read_bytes()==(D/'driver.cpp').read_bytes();assert (R/'Verify/current/common/fast_io.hpp').read_bytes()==(D/'io.hpp').read_bytes()
def summary(file,labels):
 raw=json.loads((D/file).read_text());g=collections.defaultdict(lambda:collections.defaultdict(list))
 for x in raw:g[(x['compiler'],x['case'])][x['label']].append(x['cpu_ns'])
 rows=[]
 for(cc,case),v in g.items():
  med={a:statistics.median(b)for a,b in v.items()};rows.append(dict(compiler=cc,case=case,median_cpu_ns=med,ratio_to_current={a:b/med['base']for a,b in med.items()}))
 return rows
probes=json.loads((D/'probes.json').read_text());assert len(probes)==2 and all(x['returncode']==0 and not x['stderr']for x in probes)
archive=R/'Audit/data/scc-415135-candidates-2026-11-04.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for f in ['before.hpp','two_sat_before.hpp','driver.cpp','io.hpp','base.hpp','pointers.hpp','parents.hpp','gabow.hpp','previous.hpp','prepare.py','prepare.log','fixtures.json','screen.py','screen.log','screen_raw.json','previous_compare.py','previous_compare.log','previous_raw.json','probes.json','generation.log','save_audit.py']:z.write(D/f,f)
 z.write(R/'Verify/current/tests/scc_index_paths_test.cpp','scc_index_paths_test.cpp')
 # 生成器原本や大きい入力は含めず、前回の入力生成と出典/SHAへ辿れるようにする。
 z.write('/tmp/sirkit_scc_followup_20261104/official_metadata.json','official_metadata.json')
report={
 'date':'2026-11-04','decision':'追加の本体変更なし。80msの415135版を維持。配列ポインタ保持・Tarjan親リンク・Gabow親リンクの3案は安定した改善がなく不採用。',
 'online_confirmation':'Audit/online-scc-415135-2026-11-04.json',
 'online':{'submission':415135,'status':'AC','time_ms':80,'previous_ms':82,'improvement_percent':(1-80/82)*100,'needs_resubmission':False,'scope':'現行本体は提出されたものと一致。通常版ACを派生版や試作へ転記しない。'},
 'proposals':[
 {'name':'pointers','method':'再確保しないentered/ids/begin/next/destinationの非所有dataポインタを保持。','decision':'main全体の公式相当11入力の幾何平均比はGCC1.0005/Clang0.9993。controlの変動内で明確な上積みなし。'},
 {'name':'parents','method':'DFS親をids[child]に保持し、一時saved_low配列へ親lowを退避してdfsスタックを除去。','decision':'大きい公式相当閉路でGCC約15.7%/Clang約17.4%増。現在の高速化を維持できず不採用。'},
 {'name':'gabow','method':'反復Gabowのpending/candidate-rootスタックとidsのDFS親リンクを比較。','decision':'大きい公式相当閉路でGCC約9.7%/Clang約10.6%増。今回の条件では採用しない。別方式全体の限界とは断定しない。'}],
 'correctness_probes':{'results':probes,'scope':'親リンク2案はGCC C++23-O2、ASan/UBSan、検査有効で各69,680グラフ/18,600,039 checksを独立Kosaraju・到達可能性と照合。uint32/size_t両経路・自己辺/多重辺・30万鎖/閉路を含む。正式採用向けの全コンパイラ/例外/未初期化の検証まで進めず、不採用。','leak_sanitizer':'ASAN_OPTIONS=detect_leaks=0。今回本体変更なしのため、現行版の前回の所有権・MemorySanitizer結果は性能followup Auditに保持。'},
 'environment':{'cpu':'Intel Core i9-14900K P-Core CPU12（core6、sibling13）','compilers':'GCC15.2.0/Clang21.1.8','flags':['-std=c++23','-O2','SKIP_RUNTIME_CHECKS'],'march_native':False,'new_pragmas':False,'frequency':'powersave、変更・固定なし','scope':'自分のコンパイル・測定を直列化し、各ラベルの実行順を乱数化。同じ実行名へ差し替え、controlは現行と同一バイナリ。mainはwait4 user+system CPU時間。'},
 'measurement':{'candidates':summary('screen_raw.json',None),'previous_82ms_vs_current_80ms':summary('previous_raw.json',None),'scope':'前回と同じ公式相当11入力+独自19入力の同一main/共通I/O/コンパイラ/検査設定。公式相当は公開generatorの固定seedから生成した取得版で、稼働中ジャッジの入力と同一だとは断定しない。全出力SHAを現行と照合。','random_00':'オンラインは64→70ms。ローカル同条件11回再比較ではGCC現行/82ms版=0.9868、同一バイナリcontrol/現行=0.9872で、約9%の退行は再現せず。両環境が異なるためオンライン差の原因は断定しない。','statistics':'公式相当の幾何平均比（現行=1）: pointers GCC1.0005/Clang0.9993、parents GCC1.0240/Clang1.0274、gabow GCC1.0131/Clang1.0160。control平均GCC0.9992/Clang0.9990。微小差を速度向上と断定しない。'},
 'source_hashes':{'Graph/SCC.cpp':sha(R/'Graph/SCC.cpp'),'Graph/Two_SAT.cpp':sha(R/'Graph/Two_SAT.cpp'),'driver_before_and_after':sha(D/'driver.cpp'),'io_before_and_after':sha(D/'io.hpp')},
 'evidence':{'path':archive.relative_to(R).as_posix(),'sha256':sha(archive),'scope':'自作候補・スナップショット・比較スクリプト・入力SHA/出典・測定生データ・検証結果。公式generator原本、実行バイナリ、大きい入力は含めない。'},
 'synchronization':'本文・使用例・Documentは変更なし。最新Submission注記、判定記録、通常/派生Verify、配布ZIPを同期。ZIPのCRC/manifest/相対リンク検査はDistribution/validation.json。'
}
(R/'Audit/performance-scc-415135-2026-11-04.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('Rejected three candidates; current source unchanged; evidence saved')
