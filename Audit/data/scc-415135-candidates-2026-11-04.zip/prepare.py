# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_scc_refine_20261104');s=(D/'before.hpp').read_text();variants={'base':s}
a=s.index('    for (int root = 0; root < n; ++root) {');b=s.index('    for (auto& id : ids)',a);loop=s[a:b]
ptr='''    int* const order = entered.data();
    int* const component = ids.data();
    Index* const positions = next.data();
    const Index* const offsets = begin.data();
    const int* const arcs = destination.get();
'''
for old,new in [('entered[','order['),('ids[','component['),('next[','positions['),('begin[','offsets['),('destination[','arcs[')]:loop=loop.replace(old,new)
variants['pointers']=s[:a]+ptr+loop+s[b:]
p=s.replace('    std::vector<int> entered(n, -1), ids(n), dfs, pending;\n    dfs.reserve(n); pending.reserve(n);','    std::vector<int> entered(n, -1), ids(n), pending;\n    auto saved_low = std::make_unique_for_overwrite<int[]>(n);\n    pending.reserve(n);').replace('        int low = entered[v] = clock++;','        ids[v] = -1;\n        int low = entered[v] = clock++;').replace('                    ids[v] = low;\n                    dfs.push_back(v);','                    saved_low[v] = low;\n                    ids[u] = v;').replace('            const int child_low = low;','            const int child_low = low;\n            const int parent = ids[v];').replace('            if (dfs.empty()) break;\n            v = dfs.back(); dfs.pop_back();\n            low = std::min(ids[v], child_low);','            if (parent < 0) break;\n            v = parent;\n            low = std::min(saved_low[v], child_low);');variants['parents']=p
# Gabow: candidate rootsとpending、親リンクはidsへ退避する。
g=s.replace('    std::vector<int> entered(n, -1), ids(n), dfs, pending;\n    dfs.reserve(n); pending.reserve(n);','    std::vector<int> entered(n, -1), ids(n), roots, pending;\n    roots.reserve(n); pending.reserve(n);')
a=g.index('    for (int root = 0; root < n; ++root) {');b=g.index('    for (auto& id : ids)',a)
body='''    for (int root = 0; root < n; ++root) {
        if (entered[root] != -1) continue;
        int v = root;
        Index cursor = next[v], end = begin[v + 1];
        if (cursor == end) {
            entered[v] = n; ids[v] = count++;
            continue;
        }
        entered[v] = clock++; ids[v] = -1;
        pending.push_back(v); roots.push_back(v);
        for (;;) {
            if (cursor != end) {
                const int u = destination[cursor++];
                if (entered[u] == -1) {
                    const Index child_cursor = next[u], child_end = begin[u + 1];
                    if (child_cursor == child_end) {
                        entered[u] = n; ids[u] = count++;
                        continue;
                    }
                    next[v] = cursor; ids[u] = v;
                    v = u; entered[v] = clock++;
                    cursor = child_cursor; end = child_end;
                    pending.push_back(v); roots.push_back(v);
                } else {
                    while (entered[roots.back()] > entered[u]) roots.pop_back();
                }
                continue;
            }
            const int parent = ids[v];
            if (roots.back() == v) {
                roots.pop_back();
                for (;;) {
                    const int u = pending.back(); pending.pop_back();
                    entered[u] = n; ids[u] = count;
                    if (u == v) break;
                }
                ++count;
            }
            if (parent < 0) break;
            v = parent; cursor = next[v]; end = begin[v + 1];
        }
    }
'''
variants['gabow']=g[:a]+body+g[b:]
for label,text in variants.items():
 if label in ['parents','gabow']:
  text=text.replace('// idsは中断中のlow-linkの退避先を兼ね、確定時に成分番号を書く。','// idsは未確定時のDFS親、確定後の成分番号として使う。')
 (D/f'{label}.hpp').write_text(text);driver=(D/'driver.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"',(D/'io.hpp').read_text());(D/f'{label}.cpp').write_text('#define SKIP_RUNTIME_CHECKS\n'+text+'\n'+driver)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:subprocess.run(['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(D/f'{label}.cpp'),'-o',str(D/f'{cc}_{label}')],check=True)
print('base/pointers/parents/gabow compiled')
