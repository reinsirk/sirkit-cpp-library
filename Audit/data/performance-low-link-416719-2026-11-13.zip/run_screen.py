# SPDX-License-Identifier: CC0-1.0
import subprocess,sys
from pathlib import Path
p=Path('/tmp/sirkit_lowlink_416719')
for args in [['validate_candidates.py'],['build.py','base','pending_narrow','root_cut','pending_root_cut'],['screen.py']]:
 with(p/(args[0]+'.log')).open('w')as out:subprocess.run([sys.executable,str(p/args[0]),*args[1:]],stdout=out,stderr=subprocess.STDOUT,check=True)
