# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,sys
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_lowlink_416719')
for args in [['Scripts/prepare_verify.py','--id','low_link_two_edge','--id','low_link_biconnected'],['Scripts/generate_fast_sources.py'],['Scripts/generate_variants.py'],['Scripts/prepare_variant_verify.py'],['Scripts/source_api_docs.py','--check']]:subprocess.run([sys.executable,*args],cwd=R,check=True)
for f in ['Graph/Low_Link.cpp','Verify/current/drivers/low_link_two_edge_main.cpp','Verify/current/drivers/low_link_biconnected_main.cpp','Verify/current/common/fast_io.hpp','Examples/low_link_example.cpp','Document/low_link.md','Verify/current/submissions/low_link_two_edge.cpp','Verify/current/submissions/low_link_biconnected.cpp']:
 assert (R/f).read_bytes()==(D/'before'/f).read_bytes(),f
print('canonical, main, IO, example, Document, normal submissions unchanged; latest metadata synchronized')
