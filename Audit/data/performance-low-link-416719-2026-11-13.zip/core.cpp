// SPDX-License-Identifier: CC0-1.0
#include HEADER
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <vector>
#include <algorithm>
static void add(std::uint64_t&h,std::uint64_t x){h=(h^x)*UINT64_C(1099511628211);}
static void groups_hash(std::uint64_t&h,std::vector<std::vector<int>>&g){for(auto&r:g)std::sort(r.begin(),r.end());std::sort(g.begin(),g.end());add(h,g.size());for(const auto&r:g){add(h,r.size());for(int v:r)add(h,v);}}
static void graph_hash(std::uint64_t&h,const UndirectedLowLink&g,bool blocks){add(h,g.component_count());for(auto e:g.bridges())add(h,e);for(int v:g.articulation_points())add(h,v);auto groups=g.two_edge_components();groups_hash(h,groups);if(blocks){auto b=g.biconnected_vertex_components();groups_hash(h,b);}}
int main(int argc,char**argv){
 if(argc!=4)return 2;const int op=std::atoi(argv[1]),reps=std::atoi(argv[3]);if(reps<=0)return 2;std::ifstream in(argv[2]);int n;std::size_t m;if(!(in>>n>>m))return 2;UndirectedLowLink prepared(n);prepared.reserve_edges(m);for(std::size_t i=0;i<m;++i){int u,v;in>>u>>v;prepared.add_edge(u,v);}
 std::uint64_t h=UINT64_C(1469598103934665603);std::clock_t ticks=0;
 if(op<=3){const bool blocks=(op&1)!=0;if(op>=2)prepared.build(blocks);std::vector<UndirectedLowLink>g(reps,prepared);auto start=std::clock();for(auto&v:g)v.build(blocks);ticks=std::clock()-start;for(const auto&v:g)graph_hash(h,v,blocks);}
 else{prepared.build(op!=4&&op!=7);std::vector<std::vector<std::vector<int>>>results(reps);auto start=std::clock();for(auto&r:results){if(op==4)r=prepared.two_edge_components();else if(op==5)r=prepared.biconnected_vertex_components();else if(op==6)r=prepared.biconnected_vertex_components(false);else r=prepared.bridge_forest();}ticks=std::clock()-start;
  if(op!=7){for(auto&r:results)groups_hash(h,r);}else{auto groups=prepared.two_edge_components();std::vector<int>label;for(const auto&g:groups){assert(!g.empty());label.push_back(*std::min_element(g.begin(),g.end()));}for(const auto&r:results){assert(r.size()==label.size());std::vector<std::pair<int,int>>edges;for(std::size_t a=0;a<r.size();++a)for(int b:r[a])if(a<static_cast<std::size_t>(b)){auto[u,v]=std::minmax(label[a],label[b]);edges.emplace_back(u,v);}std::sort(edges.begin(),edges.end());add(h,edges.size());for(auto[u,v]:edges){add(h,u);add(h,v);}}}
 }
 const auto ns=static_cast<std::int64_t>(ticks)*1000000000/CLOCKS_PER_SEC;std::printf("%jd %ju\n",static_cast<std::intmax_t>(ns),static_cast<std::uintmax_t>(h));
}
