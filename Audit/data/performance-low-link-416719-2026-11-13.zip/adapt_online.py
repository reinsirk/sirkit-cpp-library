# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,zipfile,tomllib,datetime
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_lowlink_416719')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,x):(D/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
old=(D/'prior_frozen.json');f=json.loads((D/'frozen.json').read_text());f['created_utc']=f['frozen_at_utc'];write('frozen.json',f)
for name in ['record_online.py','apply_online_metadata.py','update_distribution_manifest.py','make_audit.py']:
 p=D/name;s=p.read_text().replace('/tmp/sirkit_lowlink_416612',str(D)).replace('416612','416719').replace('416613','416718').replace('2026-11-12','2026-11-13').replace('6e24f831bd5ccec97efbe97de9ebd4b58ddbe942a7a55446975094f7ea018569','b6136a009ad424b9e15f1d7efd59987be2f8d3f95de9adb51fdb7a137221ed3f').replace('6e24f8','b6136a')
 s=s.replace("('low_link_two_edge', 416719, 42)","('low_link_two_edge', 416719, 40)").replace("('low_link_biconnected', 416718, 208)","('low_link_biconnected', 416718, 211)").replace("(416719, 42)","(416719, 40)").replace("(416718, 208)","(416718, 211)")
 s=s.replace('416719のAC42ms','416719のAC40ms').replace('416718のAC208ms','416718のAC211ms').replace('416719のtwo_edge AC42ms・416718のbiconnected AC208ms','416719のtwo_edge AC40ms・416718のbiconnected AC211ms')
 if name=='record_online.py':s=s.replace("'low_link_two_edge':416596,'low_link_biconnected':416595","'low_link_two_edge':416612,'low_link_biconnected':416613")
 if name=='make_audit.py':
  s=s.replace("PRIOR_AUDIT = 'Audit/performance-low-link-416596-2026-11-13.json'","PRIOR_AUDIT = 'Audit/performance-low-link-416612-2026-11-12.json'")
  s=s.replace("PRIOR_EVIDENCE = 'Audit/data/performance-low-link-416596-2026-11-13.zip'","PRIOR_EVIDENCE = 'Audit/data/performance-low-link-416612-2026-11-12.zip'")
 p.write_text(s)
context=json.loads((D/'prior_compiler_context.json').read_text());context['live_api']=next(x for x in json.loads((D/'compiler_live_langs.json').read_text())['langs']if x['id']=='cpp');context['official_repository_current_lang_definition']=next(x for x in tomllib.loads((D/'compiler_official_langs.toml').read_text())['langs']if x['id']=='cpp');context['observed_flags_include_march_native']='-march=native'in context['official_repository_current_lang_definition']['compile'];write('compiler_context.json',context)
checks=[];comparison=[];times=[]
with zipfile.ZipFile(R/'Audit/data/performance-low-link-416612-2026-11-12.zip')as z:
 for identifier,num,prev in [('low_link_two_edge',416719,416612),('low_link_biconnected',416718,416613)]:
  source=(D/f'{num}.cpp').read_text().replace('\r\n','\n');prior=z.read(f'{prev}.cpp').decode().replace('\r\n','\n');driver=(D/'before/Verify/current/drivers'/f'{identifier}_main.cpp').read_text();main=driver[driver.index('int main'):].replace('\r\n','\n');library=(D/'before/Graph/Low_Link.cpp').read_text();io=(D/'before/Verify/current/common/fast_io.hpp').read_text()
  assert library in source and source.endswith(main)and prior.endswith(main)and io in source and io in prior
  checks.append(dict(id=identifier,library_exact_lf_substring=True,library_sha256=sha(D/'before/Graph/Low_Link.cpp'),main_exact_lf_driver_suffix=True,main_unchanged_from_prior_submission=True,io_exact_lf_substring=True,io_unchanged_from_prior_submission=True,main_normalized_sha256=hashlib.sha256(main.encode()).hexdigest(),driver_sha256=sha(D/'before/Verify/current/drivers'/f'{identifier}_main.cpp'),io_sha256=sha(D/'before/Verify/current/common/fast_io.hpp'),has_count_cache_api='two_edge_component_count()'in library,has_typed_adjacency='template<class Id> struct Adjacent'in library))
  current=json.loads((D/f'{num}.json').read_text());old=json.loads(z.read(f'{prev}.json'));byname={x['case']:x for x in old['case_results']};assert set(byname)=={x['case']for x in current['case_results']}
  rows=[]
  for x in current['case_results']:
   b=byname[x['case']];r=dict(case=x['case'],previous_ms=round(b['time']*1000),current_ms=round(x['time']*1000),delta_ms=round((x['time']-b['time'])*1000),previous_memory_bytes=b['memory'],current_memory_bytes=x['memory'],status=x['status']);r['ratio']=x['time']/b['time']if b['time']else None;rows.append(r)
  times.append(dict(id=identifier,submission=num,cases=current['case_results']));comparison.append(dict(id=identifier,previous_submission=prev,current_submission=num,previous_max_ms=round(old['overview']['time']*1000),current_max_ms=round(current['overview']['time']*1000),rows=rows,scope='公式APIの個別提出時間。P-Coreの固定条件比較や同一server負荷を保証しない。小規模を含め全ケースを保持し、遅い試行をノイズと断定しない。'))
write('source_match_details.json',checks);write('public_case_times.json',times);write('public_case_comparison.json',comparison)
print('online context/source/case comparison adapted')
