# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,fcntl,hashlib,json
D=Path('/tmp/sirkit_lowlink_416719');R=Path('/home/reinsirk/Atcoder_Env');labels=['pending_narrow','root_cut','pending_root_cut'];rows=[]
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 def worker(cc):
  out=[]
  for label in labels:
   header=D/(label+'.hpp');exe=D/(cc+'_'+label+'_ref');cmd=['taskset','-c','4'if cc=='gcc'else'6',*(['g++']if cc=='gcc'else['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']),'-std=c++23','-O2','-pedantic-errors','-DLOW_LINK_SOURCE="'+str(header)+'"',str(R/'Verify/current/tests/new_low_link_reference_test.cpp'),'-o',str(exe)]
   p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr
   q=subprocess.run(['taskset','-c','4'if cc=='gcc'else'6',str(exe)],capture_output=True,text=True);assert q.returncode==0 and 'LowLink checks=178177'in q.stdout and not q.stderr,q
   out.append(dict(label=label,compiler=cc,setting='checked',header_sha256=hashlib.sha256(header.read_bytes()).hexdigest(),command=cmd,passed=True,stdout=q.stdout));print(label,cc,'178177checks PASS',flush=True)
  return out
 with ThreadPoolExecutor(max_workers=2)as pool:
  for out in pool.map(worker,['gcc','clang']):rows+=out
(D/'candidate_validation.json').write_text(json.dumps(dict(all_passed=True,count=len(rows),rows=rows),indent=2)+'\n')
