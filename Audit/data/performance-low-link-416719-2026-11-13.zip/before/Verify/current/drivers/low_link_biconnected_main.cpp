// SPDX-License-Identifier: CC0-1.0
#include "Verify/current/common/fast_io.hpp"
int main(){
 int n{},m{};verify_in>>n>>m;UndirectedLowLink graph(n);
 for(int i=0;i<m;++i){int u{},v{};verify_in>>u>>v;graph.add_edge(u,v);}graph.build(true);
 const auto blocks=graph.biconnected_vertex_components();verify_out<<blocks.size()<<'\n';for(const auto&block:blocks){verify_out<<block.size();for(int v:block)verify_out<<' '<<v;verify_out<<'\n';}
}
