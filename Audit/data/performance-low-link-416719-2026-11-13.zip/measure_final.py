# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import bench,json,random,statistics,subprocess,fcntl,sys
D=Path('/tmp/sirkit_lowlink_416719');rng=random.Random(58358299);kind=sys.argv[1];raw=[];summary=[]
def core(cc,label,case,flag,setting):
 bench.activate(D/f'{cc}_{flag}_{setting}_{label}_core');p=subprocess.run(['setarch','x86_64','-R','taskset','-c','12',str(D/'active'),str(case['operation']),case['path'],str(case['repetitions'])],capture_output=True,text=True,check=True);assert not p.stderr;ns,digest=map(int,p.stdout.split());assert ns>0;return dict(cpu_ns=ns,digest=digest)
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for job in json.loads((D/f'final_{kind}_jobs.json').read_text()):
  cc,flag,setting,case=(job[k]for k in ['compiler','flag','setting','case']);local=[];attempts={'final':0,'control':0};order=['final']*7+['control']*3;rng.shuffle(order)
  def run(label):return bench.run_whole(cc,label,case,flag)if kind=='whole'else core(cc,label,case,flag,setting)
  while order:
   label=order.pop();attempts[label]+=1;v=[run(k)for k in ['base',label if label!='control'else'base','base']];key='canonical_sha256'if kind=='whole'else'digest';assert len({x[key]for x in v})==1,(job,label,v)
   b,t,a=[x['cpu_ns']for x in v];drift=max(b,a)/min(b,a);r={k:job[k]for k in ['compiler','flag','setting']};r.update(case=case['id']if kind=='whole'else case,label=label,rep=attempts[label],before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(r);local.append(r)
   if not order:
    for k,minimum,cap in [('final',5,15),('control',2,9)]:
     count=sum(r['calibration_valid']and r['label']==k for r in local)
     if count<minimum and attempts[k]<cap:order += [k]*min(minimum-count,cap-attempts[k])
  ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in ['final','control']};row={k:job[k]for k in ['compiler','flag','setting']};row.update(case=case['id']if kind=='whole'else case,ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},valid_counts={l:len(v)for l,v in ratios.items()},sufficient=len(ratios['final'])>=5 and len(ratios['control'])>=2);summary.append(row);print(row,flush=True);(D/f'final_{kind}_raw.json').write_text(json.dumps(raw));(D/f'final_{kind}_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
