# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import sys,subprocess,json,hashlib,fcntl
D=Path('/tmp/sirkit_lowlink_416719');R=Path('/home/reinsirk/Atcoder_Env');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
entries={e['id']:e for e in pv.collect()};jobs=[];urls={'low_link_two_edge':'https://judge.yosupo.jp/submission/416719','low_link_biconnected':'https://judge.yosupo.jp/submission/416718'}
for label in ['base','final']:
 for identifier,url in urls.items():
  entry=entries[identifier].copy();entry['submission_urls']=[url];data,_=pv.render(entry,source_overrides={'Graph/Low_Link.cpp':(D/f'{label}.hpp').read_bytes()});(D/f'{label}_{identifier}.cpp').write_bytes(data)
 for cc,c,cpu in [('gcc',['g++'],4),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'],6)]:
  for flag,extra in [('native',['-march=native']),('default',[])]:
   for skip in ['checked','skip']:
    exe=D/f'{cc}_{flag}_{skip}_{label}_core';cmd=['taskset','-c',str(cpu),*c,'-std=c++23','-O2',*extra,*(['-DSKIP_RUNTIME_CHECKS']if skip=='skip'else[]),f'-DHEADER="{D}/{label}.hpp"',str(D/'core.cpp'),'-o',str(exe)];jobs.append(dict(compiler=cc,flag=flag,setting=skip,label=label,kind='core',command=cmd,executable=str(exe)))
   for identifier in urls:
    exe=D/f'{cc}_{flag}_{label}_{identifier}';cmd=['taskset','-c',str(cpu),*c,'-std=c++23','-O2',*extra,str(D/f'{label}_{identifier}.cpp'),'-o',str(exe)];jobs.append(dict(compiler=cc,flag=flag,setting='skip',label=label,kind=identifier,command=cmd,executable=str(exe)))
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 def worker(cc):
  for row in jobs:
   if row['compiler']!=cc:continue
   p=subprocess.run(row['command'],capture_output=True,text=True);row.update(returncode=p.returncode,stderr=p.stderr);assert p.returncode==0,p.stderr;row['executable_sha256']=hashlib.sha256(Path(row['executable']).read_bytes()).hexdigest();row['header_sha256']=hashlib.sha256((D/(row['label']+'.hpp')).read_bytes()).hexdigest()
  print(cc,'final main/core buildsPASS',flush=True)
 with ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(worker,['gcc','clang']))
(D/'final_builds.json').write_text(json.dumps(jobs,indent=2)+'\n')
