// SPDX-License-Identifier: CC0-1.0
#include <algorithm>
#include <bit>
#include <cassert>
#include <cstddef>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <string>
#include <utility>
#include <vector>
using Groups=std::vector<std::vector<int>>;
struct DSU{std::vector<int>p;explicit DSU(int n):p(n,-1){}int find(int x){while(p[x]>=0){if(p[p[x]]>=0)p[x]=p[p[x]];x=p[x];}return x;}void unite(int a,int b){a=find(a);b=find(b);if(a==b)return;if(p[a]>p[b])std::swap(a,b);p[a]+=p[b];p[b]=a;}};
Groups two_edge(int n,const std::vector<std::pair<int,int>>&edges,const std::vector<std::vector<std::pair<int,int>>>&adj){
 const int m=static_cast<int>(edges.size());std::vector<int>parent(n,-1),depth(n),order,child(m,-1);std::vector<unsigned char>tree(m);order.reserve(n);
 for(int root=0;root<n;++root)if(parent[root]<0){parent[root]=root;const auto begin=order.size();order.push_back(root);for(std::size_t i=begin;i<order.size();++i){int v=order[i];for(auto[u,e]:adj[v])if(parent[u]<0){parent[u]=v;depth[u]=depth[v]+1;tree[e]=1;child[e]=u;order.push_back(u);}}}
 const auto levels=std::max(1,std::bit_width(static_cast<unsigned>(std::max(1,n))));std::vector<std::vector<int>>up(levels,std::vector<int>(n));if(n)up[0]=parent;for(unsigned k=1;k<levels;++k)for(int v=0;v<n;++v)up[k][v]=up[k-1][up[k-1][v]];
 auto lca=[&](int a,int b){if(depth[a]<depth[b])std::swap(a,b);int delta=depth[a]-depth[b];for(unsigned k=0;k<levels;++k)if((delta>>k)&1)a=up[k][a];if(a==b)return a;for(unsigned k=levels;k-->0;)if(up[k][a]!=up[k][b]){a=up[k][a];b=up[k][b];}return parent[a];};
 std::vector<std::int64_t>cover(n);for(int e=0;e<m;++e)if(!tree[e]){const auto[a,b]=edges[e];const int c=lca(a,b);++cover[a];++cover[b];cover[c]-=2;}
 for(auto i=order.rbegin();i!=order.rend();++i){const int v=*i;if(parent[v]!=v){assert(cover[v]>=0);cover[parent[v]]+=cover[v];}}
 DSU dsu(n);for(int e=0;e<m;++e)if(!tree[e]||cover[child[e]]>0)dsu.unite(edges[e].first,edges[e].second);
 Groups temp(n),out;for(int v=0;v<n;++v)temp[dsu.find(v)].push_back(v);for(auto&g:temp)if(!g.empty())out.push_back(std::move(g));return out;
}
struct Bicon{
 const std::vector<std::pair<int,int>>&edges;const std::vector<std::vector<std::pair<int,int>>>&adj;std::vector<int>tin,low,pending;std::vector<unsigned char>incident;Groups groups;int clock=0;
 Bicon(int n,const std::vector<std::pair<int,int>>&e,const std::vector<std::vector<std::pair<int,int>>>&a):edges(e),adj(a),tin(n,-1),low(n),incident(n){}
 void emit(int stop){std::vector<int>v;for(;;){int e=pending.back();pending.pop_back();v.push_back(edges[e].first);v.push_back(edges[e].second);if(e==stop)break;}std::sort(v.begin(),v.end());v.erase(std::unique(v.begin(),v.end()),v.end());for(int x:v)incident[x]=1;groups.push_back(std::move(v));}
 void dfs(int v,int parent_edge){tin[v]=low[v]=clock++;for(auto[u,e]:adj[v]){if(u==v||e==parent_edge)continue;if(tin[u]<0){pending.push_back(e);dfs(u,e);low[v]=std::min(low[v],low[u]);if(low[u]>=tin[v])emit(e);}else if(tin[u]<tin[v]){pending.push_back(e);low[v]=std::min(low[v],tin[u]);}}}
 Groups run(){for(const auto[u,v]:edges)if(u==v){groups.push_back({u});incident[u]=1;}for(int v=0;v<static_cast<int>(tin.size());++v)if(tin[v]<0){dfs(v,-1);assert(pending.empty());}for(int v=0;v<static_cast<int>(tin.size());++v)if(!incident[v])groups.push_back({v});return std::move(groups);}
};
int main(int argc,char**argv){if(argc!=2)return 2;std::ios::sync_with_stdio(false);std::cin.tie(nullptr);int n,m;if(!(std::cin>>n>>m))return 2;std::vector<std::pair<int,int>>edges(m);std::vector<std::vector<std::pair<int,int>>>adj(n);for(int i=0;i<m;++i){auto&[u,v]=edges[i];std::cin>>u>>v;assert(0<=u&&u<n&&0<=v&&v<n);adj[u].emplace_back(v,i);adj[v].emplace_back(u,i);}Groups g=std::string(argv[1])=="two_edge_connected_components"?two_edge(n,edges,adj):Bicon(n,edges,adj).run();for(auto&v:g){std::sort(v.begin(),v.end());v.erase(std::unique(v.begin(),v.end()),v.end());}std::sort(g.begin(),g.end());std::cout<<g.size()<<'\n';for(auto&v:g){std::cout<<v.size();for(int x:v)std::cout<<' '<<x;std::cout<<'\n';}}
