# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,zipfile,hashlib,sys,datetime
D=Path('/tmp/sirkit_lowlink_416719/fixtures');R=Path('/home/reinsirk/Atcoder_Env');sys.path.insert(0,str(D));from canonical import canonical_sha256
prior_archive=R/'Audit/data/performance-low-link-416612-2026-11-12.zip'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def encode(x):return json.dumps(x,ensure_ascii=False,indent=2)+'\n'
with zipfile.ZipFile(prior_archive)as z:previous={x['id']:x for x in json.loads(z.read('fixtures/fixtures.json'))}
rows=json.loads((D/'fixtures.json').read_text());assert len(rows)==len(previous)==26
reports=[]
for row in rows:
 old=previous[row['id']];inp=Path(row['path']);out=Path(row['expected_output_path']);assert inp.is_file()and out.is_file();assert sha(inp)==row['sha256']==old['sha256'];assert sha(out)==row['expected_canonical_sha256']==old['expected_canonical_sha256'];assert canonical_sha256(out.read_bytes(),row['n'],row['problem'])==row['expected_canonical_sha256'];assert all(row[k]==old[k]for k in ['n','m','bytes','component_count','problem','name'])
 reports.append(dict(id=row['id'],input_sha256=sha(inp),canonical_output_sha256=sha(out),input_matches_prior=True,output_matches_prior=True,passed=True))
summary=json.loads((D/'summary.json').read_text());summary['regenerated_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();summary['regeneration']=dict(prior_archive=str(prior_archive.relative_to(R)),prior_archive_sha256=sha(prior_archive),input_hash_matches=26,output_hash_matches=26,scope='All 13 input files and 26 independent canonical outputs were regenerated in this turn and match prior immutable hashes exactly. Metadata paths, commands and timestamps are new, not byte-identical reused JSON.');(D/'summary.json').write_text(encode(summary))
sources=json.loads((D/'source_audit.json').read_text());sources['generated_params']=[dict(relative=str(p.relative_to(D/'sources')),sha256=sha(p),bytes=p.stat().st_size,definition_source='pinned prior info params')for p in sorted((D/'sources/graph').glob('*/params.h'))];sources['owned_oracle']=dict(file='oracle.cpp',sha256=sha(D/'oracle.cpp'),restored_from='Audit/data/performance-low-link-416583-2026-11-12.zip',same_source=True);sources['prepare_script_sha256']=sha(D/'prepare.py');sources['regeneration_validation']=dict(file='validation.json',all_input_and_output_hashes_match_prior=True);(D/'source_audit.json').write_text(encode(sources))
validation=dict(all_passed=True,fixture_rows=len(rows),unique_inputs=len({r['path']for r in rows}),canonical_outputs=len(reports),checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),input_bytes_unique=summary['input_bytes_unique'],prior_archive=summary['regeneration']['prior_archive'],prior_archive_sha256=sha(prior_archive),matched_prior_inputs=26,matched_prior_outputs=26,closed_form_cross_checks=len(summary['closed_form_cross_checks']),brute_force_cross_checks=len(summary['brute_force_cross_checks']),oracle_source_sha256=sha(D/'oracle.cpp'),canonical_source_sha256=sha(D/'canonical.py'),rows=reports,no_candidate_used_as_reference=True,no_performance_measurement=True)
(D/'validation.json').write_text(encode(validation));print(encode({k:v for k,v in validation.items()if k!='rows'}),end='')
