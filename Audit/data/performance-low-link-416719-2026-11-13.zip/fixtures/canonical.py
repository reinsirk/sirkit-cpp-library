# SPDX-License-Identifier: CC0-1.0
import hashlib

def canonicalize(data, n=None, problem=None):
    tokens=list(map(int,data.split()));assert tokens
    count=tokens[0];assert count>=0;groups=[];pos=1
    for _ in range(count):
        assert pos<len(tokens);size=tokens[pos];pos+=1;assert size>0 and pos+size<=len(tokens)
        group=sorted(tokens[pos:pos+size]);pos+=size
        assert len(set(group))==size
        if n is not None:assert all(0<=v<n for v in group)
        groups.append(tuple(group))
    assert pos==len(tokens)
    if problem=='two_edge_connected_components':
        vertices=[v for g in groups for v in g]
        assert len(vertices)==n and sorted(vertices)==list(range(n))
    groups.sort()
    result=(str(len(groups))+'\n'+''.join(str(len(g))+' '+ ' '.join(map(str,g))+'\n'for g in groups)).encode()
    return result

def canonical_sha256(data,n=None,problem=None):
    return hashlib.sha256(canonicalize(data,n,problem)).hexdigest()
