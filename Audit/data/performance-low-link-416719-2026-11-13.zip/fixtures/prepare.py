# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib,random,resource,fcntl,sys
D=Path('/tmp/sirkit_lowlink_416719/fixtures');S=D/'sources';sys.path.insert(0,str(D));from canonical import canonicalize,canonical_sha256
for name in ['inputs','outputs','generator_bins']:(D/name).mkdir(exist_ok=True)
rows=[];graphs=[];commands=[];rng=random.Random(416583)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(cmd,**kw):commands.append(dict(command=cmd));return subprocess.run(cmd,check=True,**kw)
def stack_limit():
 soft,hard=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(256*1024*1024 if hard==resource.RLIM_INFINITY else min(hard,256*1024*1024),hard))
selected=[('two_edge_connected_components','max_random',0),('biconnected_components','max_random',0),('biconnected_components','max_tree',0)]
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for problem,name,seed in selected:
  source=S/'graph'/problem/'gen'/(name+'.cpp');exe=D/'generator_bins'/(problem+'__'+name);run(['taskset','-c','4','g++','-std=c++23','-O2','-I'+str(S/'common'),str(source),'-o',str(exe)])
 run(['taskset','-c','4','g++','-std=c++23','-O2',str(D/'oracle.cpp'),'-o',str(D/'oracle')])
(D/'compile_complete.json').write_text(json.dumps(dict(commands=commands),indent=2)+'\n');print('COMPILES_DONE',flush=True)
def register(name,p,origin,kind,**extra):
 with p.open()as f:n,m=map(int,f.readline().split())
 graphs.append(dict(name=name,path=str(p),n=n,m=m,bytes=p.stat().st_size,sha256=sha(p),origin=origin,kind=kind,**extra));print('GRAPH',name,n,m,flush=True)
for problem,name,seed in selected:
 p=D/'inputs'/f'official_{problem}_{name}_{seed:02d}.in'
 with p.open('wb')as f:run(['taskset','-c','4',str(D/'generator_bins'/(problem+'__'+name)),str(seed)],stdout=f)
 register(p.stem,p,'Official Library Checker generator at pinned revision','tree'if name=='max_tree'else'random',generator_problem=problem,generator=name,seed=seed)
def make(name,n,m,edges,kind):
 p=D/'inputs'/(name+'.in')
 with p.open('w')as f:
  f.write(f'{n} {m}\n');count=0
  for u,v in edges:f.write(f'{u} {v}\n');count+=1
  assert count==m,(name,count,m)
 register(name,p,'Independently constructed deterministic graph',kind)
make('custom_empty',0,0,[],'empty')
make('custom_singleton',1,0,[],'single')
make('custom_path300k',300000,299999,((i,i+1)for i in range(299999)),'path')
make('custom_star100k',100000,99999,((0,i)for i in range(1,100000)),'star')
make('custom_cycle100k',100000,100000,((i,(i+1)%100000)for i in range(100000)),'cycle')
make('custom_disjoint_cliques100k',100000,450000,((base+i,base+j)for base in range(0,100000,10)for i in range(10)for j in range(i+1,10)),'cliques10')
make('custom_parallel100k',100000,150000,((i,i+1)for i in range(0,100000,2)for _ in range(3)),'parallel_pairs3')
small_self=[(0,0),(0,0),(0,1),(0,1),(1,2),(2,0),(2,3),(3,3),(3,4),(4,5),(5,3),(6,6)]
make('custom_selfloops8',8,len(small_self),small_self,'selfloops')
def rand_edges(n,m):
 for _ in range(m):
  u=rng.randrange(n);v=rng.randrange(n-1)
  if v>=u:v+=1
  yield u,v
make('custom_random64',64,200,rand_edges(64,200),'random')
make('custom_random100k_500k',100000,500000,rand_edges(100000,500000),'random')
assert len(graphs)==13
# Independent recursive oracle gets a bounded 256MiB child stack; ordinary submitted code is unchanged.
for graph in graphs:
 for problem in ['two_edge_connected_components','biconnected_components']:
  out=D/'outputs'/(graph['name']+'__'+problem+'.out')
  with Path(graph['path']).open('rb')as f,out.open('wb')as o:run(['taskset','-c','4',str(D/'oracle'),problem],stdin=f,stdout=o,preexec_fn=stack_limit)
  data=out.read_bytes();assert canonicalize(data,graph['n'],problem)==data
  row={**graph,'id':problem+'__'+graph['name'],'problem':problem,'expected_canonical_sha256':sha(out),'expected_output_path':str(out),'oracle':'Spanning forest + binary-lifting LCA + fundamental-cycle edge cover + DSU'if problem=='two_edge_connected_components'else'Own recursive Tarjan edge-stack implementation; distinct implementation, same low-link mathematics','component_count':int(data.split(maxsplit=1)[0])}
  limits=(200000,200000)if problem=='two_edge_connected_components'else(500000,500000)
  row['outside_size_constraints']=graph['n']<1 or graph['n']>limits[0]or graph['m']>limits[1]or(problem=='two_edge_connected_components'and graph['m']<1)
  row['local_selfloop_semantics']=graph['kind']=='selfloops'or graph.get('generator_problem')=='two_edge_connected_components'
  rows.append(row);print('ORACLE',row['id'],row['component_count'],flush=True)
# Closed-form checks are additional algorithm-independent witnesses.
structural=[]
for row in rows:
 kind=row['kind'];n=row['n'];problem=row['problem'];expected=None
 if kind=='empty':expected=[]
 elif kind=='single':expected=[(0,)]
 elif kind in ['path','star','tree']:
  if problem=='two_edge_connected_components':expected=[(i,)for i in range(n)]
  else:
   tokens=list(map(int,Path(row['path']).read_text().split()));expected=[tuple(sorted(tokens[i:i+2]))for i in range(2,len(tokens),2)]
 elif kind=='cycle':expected=[tuple(range(n))]
 elif kind=='cliques10':expected=[tuple(range(i,i+10))for i in range(0,n,10)]
 elif kind=='parallel_pairs3':expected=[(i,i+1)for i in range(0,n,2)]
 if expected is not None:
  expected.sort();blob=(str(len(expected))+'\n'+''.join(str(len(g))+' '+' '.join(map(str,g))+'\n'for g in expected)).encode();assert hashlib.sha256(blob).hexdigest()==row['expected_canonical_sha256'],row['id'];structural.append(row['id'])
# Brute force for tiny graph: bridges by edge deletion; blocks by maximal connected vertex subsets without cut vertices.
brute=[]
for graph in graphs:
 if graph['n']>8:continue
 tokens=list(map(int,Path(graph['path']).read_text().split()));n,m=tokens[:2];edges=list(zip(tokens[2::2],tokens[3::2]));assert len(edges)==m
 def comps(skip=-1):
  adj=[[]for _ in range(n)]
  for i,(u,v)in enumerate(edges):
   if i!=skip:adj[u].append(v);adj[v].append(u)
  seen=set();groups=[]
  for s in range(n):
   if s in seen:continue
   seen.add(s);q=[s]
   for v in q:
    for u in adj[v]:
     if u not in seen:seen.add(u);q.append(u)
   groups.append(tuple(sorted(q)))
  return groups
 c0=len(comps());bridges={i for i in range(m)if len(comps(i))>c0};adj=[[]for _ in range(n)]
 for i,(u,v)in enumerate(edges):
  if i not in bridges:adj[u].append(v);adj[v].append(u)
 seen=set();groups=[]
 for s in range(n):
  if s in seen:continue
  seen.add(s);q=[s]
  for v in q:
   for u in adj[v]:
    if u not in seen:seen.add(u);q.append(u)
  groups.append(tuple(sorted(q)))
 groups.sort();payload=(str(len(groups))+'\n'+''.join(str(len(g))+' '+' '.join(map(str,g))+'\n'for g in groups)).encode();row=next(r for r in rows if r['name']==graph['name']and r['problem']=='two_edge_connected_components');assert hashlib.sha256(payload).hexdigest()==row['expected_canonical_sha256'];brute.append(row['id'])
 bits=[0]*n;loops=[]
 for u,v in edges:
  if u==v:loops.append((u,))
  else:bits[u]|=1<<v;bits[v]|=1<<u
 def connected(mask):
  if mask==0:return True
  seen=mask&-mask;old=0
  while old!=seen:
   old=seen
   for v in range(n):
    if(seen>>v)&1:seen|=bits[v]&mask
  return seen==mask
 valid=[]
 for mask in range(1,1<<n):
  if connected(mask)and all(connected(mask&~(1<<v))for v in range(n)if(mask>>v)&1):valid.append(mask)
 maximal=[s for s in valid if not any(s!=t and(s&t)==s for t in valid)];groups=[tuple(v for v in range(n)if(s>>v)&1)for s in maximal];loop_vertices={x[0]for x in loops};groups=[g for g in groups if len(g)>1 or g[0]not in loop_vertices]+loops;groups.sort();payload=(str(len(groups))+'\n'+''.join(str(len(g))+' '+' '.join(map(str,g))+'\n'for g in groups)).encode();row=next(r for r in rows if r['name']==graph['name']and r['problem']=='biconnected_components');assert hashlib.sha256(payload).hexdigest()==row['expected_canonical_sha256'];brute.append(row['id'])
unique_bytes=sum(g['bytes']for g in graphs);row_bytes=sum(r['bytes']for r in rows);assert row_bytes<100_000_000,(unique_bytes,row_bytes)
summary=dict(physical_graphs=len(graphs),cases=len(rows),input_bytes_unique=unique_bytes,input_bytes_with_reused_rows=row_bytes,closed_form_cross_checks=structural,brute_force_cross_checks=brute,oracle_source_sha256=sha(D/'oracle.cpp'),canonical_source_sha256=sha(D/'canonical.py'),oracle_stack_bytes=256*1024*1024,scope='Every full canonical output comes from an original reference implementation. Two-edge reference uses cycle-cover/LCA, not low-link. Bicon reference is separately written recursive Tarjan with same mathematical low-link criterion; structural and tiny brute-force checks provide additional independent algorithms. No baseline implementation is treated as truth.',external_source_scope='sources/ contains third-party official generators; exclude it, inputs/, outputs/, generator_bins/ and oracle binary from Audit ZIP.',no_performance_measurement=True)
(D/'fixtures.json').write_text(json.dumps(rows,indent=2)+'\n');(D/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
