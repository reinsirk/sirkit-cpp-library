# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,subprocess,random,fcntl,shutil,statistics
D=Path('/tmp/sirkit_suffix_416522');raw=[];summary=[];rng=random.Random(510509)
def run(cc,setting,label,kind,n,shape):
    shutil.copyfile(D/f'generic_{cc}_{setting}_{label}',D/'active');(D/'active').chmod(0o700)
    cmd=['setarch','x86_64','-R','taskset','-c','12',str(D/'active'),str(kind),str(n),str(shape),str(max(1,32768//n))]
    p=subprocess.run(cmd,check=True,capture_output=True,text=True);assert not p.stderr
    ns,digest=map(int,p.stdout.split());assert ns>0
    return dict(cpu_ns=ns,digest=digest)
def main():
    with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        for cc in ['gcc','clang']:
            for setting in ['checked','skip']:
                for kind in [1,3]:
                    for n in [500000]:
                        for shape in range(3):
                            order=['narrow_direct']*9+['control']*3;rng.shuffle(order);local=[]
                            for rep,target in enumerate(order):
                                values=[run(cc,setting,label,kind,n,shape)for label in ['base','narrow_direct'if target=='narrow_direct'else'base','base']]
                                assert len({r['digest']for r in values})==1
                                b0,t,b1=[r['cpu_ns']for r in values];drift=max(b0,b1)/min(b0,b1)
                                row=dict(compiler=cc,setting=setting,kind=kind,n=n,shape=shape,rep=rep,target_kind=target,before=values[0],target=values[1],after=values[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b0,b1]))
                                raw.append(row);local.append(row)
                            ratios={k:[r['ratio']for r in local if r['target_kind']==k and r['calibration_valid']]for k in ['narrow_direct','control']}
                            row=dict(compiler=cc,setting=setting,kind=kind,n=n,shape=shape,valid_counts={k:len(v)for k,v in ratios.items()},ratios={k:statistics.median(v)if v else None for k,v in ratios.items()},sufficient=len(ratios['narrow_direct'])>=5 and len(ratios['control'])>=2)
                            summary.append(row);print(row,flush=True)
                            (D/'direct_prepared_raw.json').write_text(json.dumps(raw));(D/'direct_prepared_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print('Completed',len(raw),'triplets',len(raw)*3,'executions',flush=True)

if __name__ == '__main__':
    main()
