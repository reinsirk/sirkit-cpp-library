# SPDX-License-Identifier: CC0-1.0
# 保存済み公開API応答と提出時スナップショットを照合する。ネット・コンパイル・本体編集なし。
from pathlib import Path
import datetime
import hashlib
import json

R = Path('/home/reinsirk/Atcoder_Env')
D = Path('/tmp/sirkit_suffix_416522')
AUDIT = 'Audit/online-suffix-array-416522-416523-2026-11-12.json'
PREVIOUS = 'Audit/online-suffix-array-416510-416509-2026-11-12.json'
JOBS = [('suffix_array', 416522, 'suffixarray'),
        ('suffix_array_substrings', 416523, 'number_of_substrings')]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def norm(source):
    return '\n'.join(line.rstrip() for line in source.replace('\r\n', '\n').splitlines()
                     if line.strip() and not line.startswith('// Submission:'))

checked = datetime.datetime.now(datetime.timezone.utc).isoformat()
retrieval = json.loads((D / 'retrieval.json').read_text())
fetched = {r['id']: r for r in retrieval}
previous_path = R / PREVIOUS
previous_bytes = previous_path.read_bytes()
previous = {r['id']: r for r in json.loads(previous_bytes)['records']}
records, sources, comparisons = [], [], []
for identifier, submission, problem in JOBS:
    response, saved = D / f'{submission}.json', D / f'{submission}.cpp'
    endpoint = f'https://v3.api.judge.yosupo.jp/submissions/{submission}'
    fetched_record = fetched[identifier]
    assert fetched_record['url'] == endpoint
    assert fetched_record['json_sha256'] == sha(response), (identifier, 'retrieved response SHA mismatch')
    data = json.loads(response.read_text())
    overview = data['overview']
    assert overview['id'] == submission and overview['problem_name'] == problem
    assert overview['status'] == 'AC' and all(c['status'] == 'AC' for c in data['case_results'])
    assert saved.read_bytes() == data['source'].encode(), (identifier, 'API source and saved cpp differ')
    snapshot = D / f'before/Verify/current/submissions/{identifier}.cpp'
    assert norm(data['source']) == norm(snapshot.read_text()), (identifier, 'normalized source mismatch')
    driver = f'Verify/current/drivers/{identifier}_main.cpp'
    io, library = 'Verify/current/common/fast_io.hpp', 'String/Suffix_Array.cpp'
    record = dict(
        id=identifier, status=overview['status'], url=f'https://judge.yosupo.jp/submission/{submission}',
        time_ms=round(overview['time'] * 1000), memory_bytes=overview['memory'], language=overview['lang'],
        submission_time=overview['submission_time'], fetched_at_utc=fetched_record['fetched_at_utc'],
        checked_at_utc=checked, case_results=data['case_results'], submission_sha256=sha(snapshot),
        uploaded_source_sha256=sha(saved), source_hashes={library: sha(D / 'before' / library)},
        driver_sha256=sha(D / 'before' / driver), io_source_hashes={io: sha(D / 'before' / io)},
        io_mode='shared_fast_io', matched_prescreen_snapshot=True,
        source_match='空行・改行・行末空白・Submission注記のみ除いて、保存済み提出本文と提出時の本体/main/共通IOが一致。',
        evidence_file=AUDIT)
    records.append(record)
    sources.append(dict(
        id=identifier, endpoint=endpoint, response_file=str(response), response_sha256=sha(response),
        fetched_at_utc=fetched_record['fetched_at_utc'], saved_source_file=str(saved),
        saved_source_sha256=sha(saved), submitted_snapshot=str(snapshot),
        is_latest_at_saved_API_snapshot=overview.get('is_latest')))
    old = previous[identifier]
    assert old['status'] == 'AC'
    comparisons.append(dict(
        id=identifier, previous_url=old['url'], current_url=record['url'],
        previous_evidence_file=PREVIOUS, previous_evidence_sha256=sha(previous_path),
        previous_time_ms=old['time_ms'], current_time_ms=record['time_ms'],
        time_delta_ms=record['time_ms'] - old['time_ms'],
        time_change_percent=(record['time_ms'] / old['time_ms'] - 1) * 100,
        previous_memory_bytes=old['memory_bytes'], current_memory_bytes=record['memory_bytes'],
        memory_delta_bytes=record['memory_bytes'] - old['memory_bytes'],
        memory_change_percent=(record['memory_bytes'] / old['memory_bytes'] - 1) * 100,
        same_driver=old['driver_sha256'] == record['driver_sha256'],
        same_shared_io=old['io_source_hashes'] == record['io_source_hashes'],
        previous_source_hashes=old['source_hashes'], submitted_source_hashes=record['source_hashes']))

output = dict(
    records=records, endpoints=[s['endpoint'] for s in sources], checked_at_utc=checked,
    normalization='CRLFをLFにし、空行・行末空白・先頭が // Submission: の注記のみ除く。他のコード/pragmaは除外しない。',
    source_snapshots=sources, retrieval=retrieval, retrieval_file_sha256=sha(D / 'retrieval.json'),
    comparisons=comparisons,
    comparison_scope='同一問題の保存済みオンライン判定の時間・メモリ比較。main/共通IOの同一性をハッシュで確認するが、サーバー負荷やコンパイラ設定は統制できず、本体だけの厳密な速度比較ではない。',
    scope='416522/416523のACと提出時スナップショットの本文一致を記録。fetched_at_utcは保存済みAPIの取得時刻、checked_at_utcは今回のローカル照合時刻。現行通常版との一致・再提出要否は生成時のソースで別途判断し、後の本体改修や派生版のオンラインACへ転記しない。')
assert previous_path.read_bytes() == previous_bytes
(D / 'online_records.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(records=[{k: r[k] for k in ('id', 'status', 'time_ms', 'memory_bytes', 'matched_prescreen_snapshot')} for r in records], comparisons=comparisons), ensure_ascii=False, indent=2))
