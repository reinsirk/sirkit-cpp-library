# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json
D=Path('/tmp/sirkit_suffix_416522');rows=[]
for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for setting in ['checked','skip']:
  for label in ['narrow_reserved']:
   cmd=['taskset','-c','4',*args,'-std=c++23','-O2',f'-DHEADER="{D}/{label}.hpp"',*(['-DSKIP_RUNTIME_CHECKS']if setting=='skip'else[]),str(D/'generic.cpp'),'-o',str(D/f'generic_{cc}_{setting}_{label}')];subprocess.run(cmd,check=True);rows.append(dict(compiler=cc,setting=setting,label=label,command=cmd));print(cc,setting,label,flush=True)
(D/'reserved_prepared_builds.json').write_text(json.dumps(rows,indent=2)+'\n')
