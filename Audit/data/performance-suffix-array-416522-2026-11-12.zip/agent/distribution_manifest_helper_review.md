# 配布manifest更新補助

`/tmp/sirkit_suffix_416522/update_distribution_manifest.py` を準備した。現段階では構文の解析だけを行い、補助の本体は実行していない。ZIP読込・SHA測定・配布生成・正本書込みは行っていない。

親が最終判断を記録し、オンラインメタデータ・生成物・5ZIPを同期してverify_distributionを通した後で使う。既定はdry-runで、完成予定のmanifestをstdoutの `manifest` に示す。`--apply` を明示した場合だけ `Distribution/manifest.json` を一時ファイルから置き換える。

前提:

- 新しいperformance Auditに `library`、文字列の `decision`、`source_sha256.before/after`、`required_resubmission` がある。decisionはadoptで始まれば採用、retain/reject/keep/no_adoptで始まれば維持と解釈する。
- source_sha256.afterは正本本体と一致する。採用ではbeforeと異なり再提出2件、維持ではbeforeと同じで再提出0件とする。
- 416522 AC48msと416523 AC44msが正本judgementsと通常版manifestに載り、match/resubmitフラグが上記判断と一致する。通常版生成cppのSHAと現在の本体SHAも検査する。
- 新しいオンラインAuditは提出時通常版のACを記録する。対象8派生版Verifyはオンライン未提出、submission_urlsは空を維持する。
- 親が旧outer manifestを `Audit/distribution-manifest-before-suffix-array-416522-2026-11-12.json` に保存してある。
- Distribution/validation.jsonは5件すべて成功し、各reportの現行manifest群SHA・検査スクリプトSHA・ZIP SHAが現在ファイルと一致する。ZIPの実際の要素数とCRC検査済み件数も一致する。

更新する内容:

- scopeとonline_scopeを新しい判断・通常版最新ACの範囲に直す。採用本体や派生版のオンラインACとは書かない。
- 実際の5ZIPのSHA・サイズ・要素数と検査結果、現在のmanifest群のSHA・件数を記録する。
- performance_auditとonline_confirmation_auditを今回の記録へ向け、previous_release_manifestを親が保存した旧manifestへ向ける。
- accepted_performance_auditは採用なら今回へ進め、維持なら旧manifestの値を保持する。
- required_resubmission_for_performanceとnext_normal_verifyは、pendingなら対象2提出cppだけ、維持なら空配列にする。

それ以外の既存フィールドは保持する。新旧Auditと旧manifestには書き込まない。最終のZIP確認まで終わる前に実行すると前提検査で止まる想定であり、まだ本体評価中の現状に合わせて正本値を推測して補完しない。
