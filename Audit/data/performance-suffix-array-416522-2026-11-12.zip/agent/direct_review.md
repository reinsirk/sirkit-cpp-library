# 単一テンプレート版の静的確認

`narrow_direct.hpp` は原本ddabecから直接生成した。表の未初期化確保やラッパー版の変更を引き継がない。内部のsuffix_inducedだけを同名の `template<std::integral Symbol>` にし、実装本体は1か所のまま。前方宣言・非テンプレートラッパー・別名の実装はない。

## 呼び出しの全件確認

| 呼び出し位置 | 明示するspan | 誘導処理の符号型 |
| --- | --- | --- |
| 誘導処理内のreduced再帰 | span<const int>(reduced) | int |
| suffix_string | span<const uint_least16_t>(encoded.get(), m+1) | uint_least16_t |
| 上限指定vector<int>入口 | span<const int>(encoded) | int |
| 汎用vectorの整数分岐 | span<const int>(encoded) | int |
| 汎用vectorの非整数分岐 | span<const int>(encoded) | int |

定義1か所と呼び出し5か所を生成器で数え、spanを付け忘れたvector引数の呼び出しがないことも検査した。vectorからの変換はテンプレート引数推論に使われないため、元は暗黙変換だった4か所（再帰を含む）を明示変換した。

関数テンプレート自身の名前は本体の再帰呼び出しから見える。reducedを明示int spanにするため、根のSymbolがuint_least16_tでも再帰先はint。再帰先のreducedも同じintなので、その後もintのまま。65535を超える名前を狭い符号型へ変換する箇所はない。

## 同一性・初期化・所有権

- 生成器は全置換を逆適用して原本とのバイト一致を検査する。誘導処理本体についても、再帰引数の明示spanを戻した後の文字列一致を別に確認する。small、selected、starts/ends、suffixes/cursor、命名、誘導、分岐は変更していない。
- 文字列の符号は従来と同じ0..256で、uint_least16_tがすべて正確に保持する。byte255は256、埋込みNULは1、終端だけ0。全m+1要素を設定した後でspanを渡す。空文字列は終端1要素でn==1の経路を通る。
- spanは同じ所有配列/vectorを呼び出しの間だけ借用する。明示spanは確保・複製・型変換を追加しない。呼び出し完了までencoded/reducedの所有者は生存し、結果へ参照を残さない。
- unique_ptr/vectorによる所有と例外時の解放を維持する。直接new、CPU拡張、設定分岐は追加していない。根の符号配列の要素型だけが変わる。
- 長さ・upperの常時検査、その他の既定入力検査、SKIP_RUNTIME_CHECKS、内部添字と容量計算は同じ。0..256によるバケット添字の範囲も同じ。

公開APIの宣言・戻り値・テンプレート条件は変わらない。公開vector入口の本体には上述のspan明示変換だけが加わる。公開説明・include群・ガード・全マクロは変わらず、既存のconcepts/cstdint/memory/spanで標準C++23として表せる。stdintのleast型は少なくとも16ビットだが実際のsizeofは環境依存。LCP・検索の実装は一切変更していない。

原本は未変更。コンパイル・実行・性能測定は行っていない。ラッパーを除いたことによる性能変化や事前実行後の確保状態の影響は、親の同条件測定で判断する。
