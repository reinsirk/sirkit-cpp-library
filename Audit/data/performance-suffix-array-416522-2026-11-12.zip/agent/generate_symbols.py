from pathlib import Path
import difflib
import hashlib
import json

SOURCE = Path('/home/reinsirk/Atcoder_Env/String/Suffix_Array.cpp')
OUT = Path('/tmp/sirkit_suffix_416522/agent')
EXPECTED_SHA = 'ddabec6d617bfa97a0bd94c0ac79ecc3f4d829ce78add2a52e9af1bc713b45bf'
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED_SHA
base = raw.decode()
old_header = 'inline std::vector<int> suffix_induced(std::span<const int> symbols, int alphabet) {'
new_header = '''inline std::vector<int> suffix_induced(std::span<const int> symbols, int alphabet);

template <std::integral Symbol>
inline std::vector<int> suffix_induced_symbols(std::span<const Symbol> symbols, int alphabet) {'''
old_boundary = '''    return suffixes;
}

inline std::vector<int> suffix_string(std::string_view s) {'''
new_boundary = '''    return suffixes;
}

inline std::vector<int> suffix_induced(std::span<const int> symbols, int alphabet) {
    return suffix_induced_symbols(symbols, alphabet);
}

inline std::vector<int> suffix_string(std::string_view s) {'''
old_encoder = '''    auto encoded = std::make_unique_for_overwrite<int[]>(s.size() + 1);
    encoded[s.size()] = 0;
    for (std::size_t i = 0; i < s.size(); ++i) encoded[i] = static_cast<unsigned char>(s[i]) + 1;
    auto result = reinsirk::detail::suffix_induced(std::span<const int>(encoded.get(), s.size() + 1), 256);'''
new_encoder = '''    auto encoded = std::make_unique_for_overwrite<std::uint_least16_t[]>(s.size() + 1);
    encoded[s.size()] = 0;
    for (std::size_t i = 0; i < s.size(); ++i)
        encoded[i] = static_cast<std::uint_least16_t>(static_cast<unsigned char>(s[i]) + 1);
    auto result = reinsirk::detail::suffix_induced_symbols(
        std::span<const std::uint_least16_t>(encoded.get(), s.size() + 1), 256);'''

def replace_exact(text, old, new, count=1):
    assert text.count(old) == count, (old, text.count(old), count)
    return text.replace(old, new)

body_start = base.index(old_header) + len(old_header)
body_end = base.index('\n}\n\ninline std::vector<int> suffix_string', body_start)
base_body = base[body_start:body_end]
metadata = {'source': str(SOURCE), 'source_sha256': EXPECTED_SHA, 'candidates': []}
for name, narrow in [('templated_int.hpp', False), ('narrow_root.hpp', True)]:
    result = base
    replacements = [(old_header, new_header), (old_boundary, new_boundary)]
    if narrow:
        replacements.append((old_encoder, new_encoder))
    for old, new in replacements:
        result = replace_exact(result, old, new)
    reconstructed = result
    for old, new in reversed(replacements):
        reconstructed = replace_exact(reconstructed, new, old)
    assert reconstructed == base
    changed_body_start = result.index(new_header) + len(new_header)
    assert result[changed_body_start:changed_body_start + len(base_body)] == base_body
    assert result[result.index('template <class Sequence, class Pattern, class Convert>'):] == base[base.index('template <class Sequence, class Pattern, class Convert>'):]
    assert result.count('suffix_induced(reduced, name)') == 1
    assert result.count('inline std::vector<int> suffix_induced(std::span<const int> symbols, int alphabet) {') == 1
    assert result.count('std::vector<std::uint8_t> small(n);') == 1
    output = OUT / name
    output.write_text(result)
    (OUT / (name + '.diff')).write_text(''.join(difflib.unified_diff(
        base.splitlines(True), result.splitlines(True), fromfile='String/Suffix_Array.cpp', tofile=name)))
    metadata['candidates'].append({
        'path': str(output), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
        'narrow_string_root': narrow,
        'exact_replacements': [{'old': old, 'new': new, 'count': 1} for old, new in replacements],
        'reverse_reconstruction_identical': True,
        'induced_body_identical': True,
        'public_api_and_other_helpers_identical': True,
        'int_recursion_retained': True,
    })
assert SOURCE.read_bytes() == raw
(OUT / 'symbols_metadata.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({c['path']: c['sha256'] for c in metadata['candidates']}, indent=2))
