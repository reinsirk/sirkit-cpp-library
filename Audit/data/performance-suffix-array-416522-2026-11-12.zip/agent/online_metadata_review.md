# オンライン記録の準備結果

`record_online.py` と `apply_online_metadata.py` は今回の416522/416523用に準備し、保存済み応答だけで照合した。API再取得・提出・コンパイル・性能測定・正本メタデータの書換えは行っていない。

## 本文対応と取得時刻

- API応答のSHAは既存 `retrieval.json` と一致する。416522は `2026-11-11T23:50:23.174905+00:00`、416523は `2026-11-11T23:50:23.336129+00:00` に取得された応答である。今回のローカル照合時刻とは分けて記録した。
- 保存cppとAPI sourceはバイト単位で一致する。空行・CRLF・行末空白・Submission注記だけを除いた本文は提出時snapshotと一致する。pragmaや実装コードは除外しない。
- 416522は50ケースすべてAC、48ms・12,324,864B。416523は24ケースすべてAC、44ms・9,953,280B。
- 直前の416510は48ms・14,159,872Bで、今回の差は0ms・-1,835,008B。416509は46ms・11,292,672Bで、今回の差は-2ms・-1,339,392B。main/共通IOのハッシュはそれぞれ一致するが、オンライン実行環境を統制した本体単独の比較ではない。
- 旧AuditのSHAは `9e6033a1f0ea57dbd104385bc42eb5e3b6b1c6c700489d28280ba068fb80700e`。旧記録はそのまま保持する。

## 条件付きの反映

- 正本がddabecのままなら、最新URLを付けて再生成した提出cppは提出時snapshotと完全一致する。通常版は `matched_current_generation=true`、`needs_resubmission=false` となる。
- narrow_rootを仮定したdry-runでは両件とも `matched_current_generation=false`、`needs_resubmission=true` となる。AC48/44msは提出時版の記録として残し、変更後本体のACとは記さない。
- 両分岐とも派生版のオンラインACへ転記しない旨をgroup limitationsへ書き、通常版2件のgroupとjudgementsを更新できる状態にした。派生版の記録や判定はこの補助では変更しない。
- 書込みは親が最終判断後に `--apply` を指定した場合だけ行う。`--library-override` はdry-run専用。既存Auditに違う内容を上書きしようとすると停止する。
- 監査記録を正本へ保存した後にrecord_onlineを再実行すると照合時刻が変わるため、同じAuditを再利用する場合は確定したonline_records.jsonを保持する。

実行結果は `record_online_dryrun.json`、`apply_online_metadata_dryrun.json`、`apply_online_metadata_changed_dryrun.json`。正本ライブラリ・group・judgements・既存オンラインAudit群の実行前後ハッシュが同一であることを検査し、`online_protected_hashes.json` に保存した。

## 追加の静的確認とコメント案

narrow_rootの公開API全定義（suffix_arrayの全オーバーロード、lcp_arrayの全オーバーロード、SuffixArrayEqualRange）とsuffix_search/lcp補助は原本と完全一致する。先頭API説明・include・全マクロと検査分岐も変更なし。追加テンプレートには既存concepts、狭い符号には既存cstdint、所有配列には既存memory、spanには既存spanで足りる。コンパイラ固有の構文やCPU拡張を加えず標準C++23で表せる。

uint_least16_tを使う理由は終端0とバイト+1の最大256を表現でき、正確に16ビットの整数型が存在しない環境にも型があるため。標準上はsizeofが2とは限らないので、根の作業領域が半分という主張は対象環境の型幅を前提とする。再帰で名前数が65535を超えてもreducedと元のint用ラッパーを通るため切り捨てない。根のspanだけをテンプレートへ直接渡す。

測定後に採用する場合の内部コメント案（候補の測定対象バイト列には追記していない）:

```cpp
// 文字列の符号は終端0とバイト+1の0..256。再帰の名前はintを保つ。
```

置き場所はsuffix_string内のencoded確保直前を想定する。API説明の重複やDocumentへの内部最適化の追加は不要。
