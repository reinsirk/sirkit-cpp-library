from pathlib import Path
import difflib
import hashlib
import json

SOURCE = Path('/tmp/sirkit_suffix_416522/agent/narrow_direct.hpp')
OUT = SOURCE.parent
EXPECTED_SHA = 'c9c38cf1c1233a0bf6f81ab375cc1ca283d83c696eaf1fec9406fe939f1c60b6'
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED_SHA
base = raw.decode()
old = '    auto encoded = std::make_unique_for_overwrite<std::uint_least16_t[]>(s.size() + 1);'
new = '''    // 対象環境では旧int配列と確保量を揃える。配置の一致は保証しない。
    constexpr std::size_t reserve_factor =
        std::max(std::size_t{1}, sizeof(int) / sizeof(std::uint_least16_t));
    const std::size_t count = s.size() + 1;
    if (count > std::numeric_limits<std::size_t>::max() / reserve_factor)
        throw std::length_error("suffix_array: symbol buffer too large");
    auto encoded = std::make_unique_for_overwrite<std::uint_least16_t[]>(count * reserve_factor);'''
assert base.count(old) == 1
result = base.replace(old, new)
assert result.count(new) == 1 and result.replace(new, old) == base
assert result[result.index('    encoded[s.size()] = 0;'):] == base[base.index('    encoded[s.size()] = 0;'):]
assert result[:result.index('inline std::vector<int> suffix_string')] == base[:base.index('inline std::vector<int> suffix_string')]
output = OUT / 'narrow_reserved.hpp'
output.write_text(result)
(OUT / 'narrow_reserved.hpp.diff').write_text(''.join(difflib.unified_diff(
    base.splitlines(True), result.splitlines(True), fromfile='narrow_direct.hpp', tofile=output.name)))
metadata = dict(source=str(SOURCE), source_sha256=EXPECTED_SHA, path=str(output),
                sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
                exact_replacement=dict(old=old, new=new, count=1), reverse_reconstruction_identical=True,
                sentinel_loop_span_and_all_other_code_identical=True,
                added_capacity_guard_unconditional=True)
(OUT / 'reserved_metadata.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
assert SOURCE.read_bytes() == raw
print(json.dumps(dict(path=str(output), sha256=metadata['sha256']), indent=2))
