from pathlib import Path
import difflib
import hashlib
import json

SOURCE = Path('/home/reinsirk/Atcoder_Env/String/Suffix_Array.cpp')
OUT = Path('/tmp/sirkit_suffix_416522/agent')
EXPECTED_SHA = 'ddabec6d617bfa97a0bd94c0ac79ecc3f4d829ce78add2a52e9af1bc713b45bf'
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED_SHA
base = raw.decode()

starts_old = '    std::vector<int> starts(static_cast<std::size_t>(alphabet) + 1), ends(starts.size());'
starts_new = '''    const std::size_t bucket_count = static_cast<std::size_t>(alphabet) + 1;
    auto starts = std::make_unique_for_overwrite<int[]>(bucket_count);
    std::vector<int> ends(bucket_count);'''
cursor_old = '    std::vector<int> suffixes(n, -1), cursor(ends.size());'
cursor_new = '''    std::vector<int> suffixes(n, -1);
    auto cursor = std::make_unique_for_overwrite<int[]>(ends.size());'''

def replace_exact(text, old, new, count):
    assert text.count(old) == count, (old, text.count(old), count)
    return text.replace(old, new)

metadata = {'source': str(SOURCE), 'source_sha256': EXPECTED_SHA, 'candidates': []}
for name, starts_uninit, cursor_uninit in [
    ('cursor_uninit.hpp', False, True),
    ('starts_uninit.hpp', True, False),
    ('combined_tables.hpp', True, True),
]:
    result = base
    replacements = []
    def change(old, new, count):
        global result
        result = replace_exact(result, old, new, count)
        replacements.append({'old': old, 'new': new, 'count': count})
    if starts_uninit:
        change(starts_old, starts_new, 1)
    if cursor_uninit:
        change(cursor_old, cursor_new, 1)
        change('        cursor = ends;',
               '        std::copy(ends.begin(), ends.end(), cursor.get());', 2)
    if starts_uninit:
        dest = 'cursor.get()' if cursor_uninit else 'cursor.begin()'
        change('        cursor = starts;',
               f'        std::copy_n(starts.get(), ends.size(), {dest});', 1)
    elif cursor_uninit:
        change('        cursor = starts;',
               '        std::copy(starts.begin(), starts.end(), cursor.get());', 1)

    # Reverse every replacement and require byte-for-byte reconstruction.
    reconstructed = result
    for item in reversed(replacements):
        reconstructed = replace_exact(reconstructed, item['new'], item['old'], item['count'])
    assert reconstructed == base
    # No accidental changes to entry points, checks, or the small-state array.
    assert result[result.index('inline std::vector<int> suffix_string'): ] == base[base.index('inline std::vector<int> suffix_string'): ]
    assert result[:result.index('    const int n =')] == base[:base.index('    const int n =')]
    assert result.count('std::vector<std::uint8_t> small(n);') == 1
    output = OUT / name
    output.write_text(result)
    diff = ''.join(difflib.unified_diff(base.splitlines(True), result.splitlines(True),
                                    fromfile='String/Suffix_Array.cpp', tofile=name))
    (OUT / (name + '.diff')).write_text(diff)
    metadata['candidates'].append({
        'path': str(output), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
        'starts_uninitialized': starts_uninit, 'cursor_uninitialized': cursor_uninit,
        'exact_replacements': replacements, 'reverse_reconstruction_identical': True,
        'public_and_other_helpers_identical': True,
    })
assert SOURCE.read_bytes() == raw
(OUT / 'metadata.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({c['path']: c['sha256'] for c in metadata['candidates']}, indent=2))
