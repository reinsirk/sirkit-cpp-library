# バケット表の未初期化確保候補の静的確認

原本: `/home/reinsirk/Atcoder_Env/String/Suffix_Array.cpp`

原本SHA-256: `ddabec6d617bfa97a0bd94c0ac79ecc3f4d829ce78add2a52e9af1bc713b45bf`

`generate.py` はこのハッシュを要求し、指定した置換以外を行わない。各置換の逆適用で原本をバイト単位で復元し、公開APIと他の補助関数の一致も検査した。各差分を目視でも確認した。原本は変更していない。

## 候補と変更範囲

| 候補 | starts | cursor | 変更内容 |
| --- | --- | --- | --- |
| `cursor_uninit.hpp` | vectorのまま | unique_ptr配列 | cursorの不要なゼロ初期化を省き、代入3か所を全要素copyへ変更 |
| `starts_uninit.hpp` | unique_ptr配列 | vectorのまま | startsの不要なゼロ初期化を省き、startsからの代入を全要素copy_nへ変更 |
| `combined_tables.hpp` | unique_ptr配列 | unique_ptr配列 | 上記2件を組み合わせる |

startsの確保はendsより前、suffixesの確保はcursorより前という順序を維持。small・suffixes・endsの初期化方法、誘導ラムダの引数、span、再帰、分類・命名・誘導の手順は変更していない。公開API、include、コメント、検査分岐、所有権の公開方法も変更していない。既存の `<memory>` と `<algorithm>` で宣言が足りる。

## 初期化の証明

- endsはvectorの値初期化を維持する。`++ends[...]` と累積和での読み出しは従来どおり初期化済み。
- startsの最初の使用は累積和の代入。`symbol=0..alphabet` の全要素へ1回ずつ代入し、そのループ内でstartsの既存値を読まない。最初のinduce呼び出しはループ完了後であり、startsを読み出すのは全要素copyだけ。
- cursorの最初の使用はinduce内でのends全要素copy。その後、LMS配置前はends、L型誘導前はstarts、S型誘導前はendsから全要素を上書きする。各読書きの前に対象範囲すべてが初期化され、前段のcursor値には依存しない。2回目のinduceも同じ順序。
- 変更した表の要素数はすべて `static_cast<std::size_t>(alphabet)+1`。copyの要素数はendsのサイズで一致し、コピー元と先は別の生存中の確保領域で重ならない。
- n==1は表を確保する前にreturnする。未初期化表を残したまま別経路から読み出す分岐はない。

## 境界と整数範囲

- 公開入口の長さ検査はSKIP_RUNTIME_CHECKSにかかわらず残り、元の列長mは `m < INT_MAX-1`。終端追加後の内部nは `1 <= n <= INT_MAX-1` で、intへの変換は従来どおり安全。
- 整数列入口のupper検査も常時残る。`0 <= upper <= INT_MAX-2` なので内部alphabet=upper+1は最大INT_MAX-1。文字列入口はalphabet=256、圧縮入口は高々元の列長、再帰先はname<count<=n/2。
- bucket_countはint加算ではなくsize_tへの変換後に1を加える。従来のstarts要素数と同じ式であり、intのalphabet+1オーバーフローを導入していない。配列確保サイズの可否は標準ライブラリの確保処理が扱う。
- prefixループはalphabetがINT_MAX-1でも最後の増分がINT_MAXで止まり、それ以上増分しない。totalは出現数の累積で最大n。いずれもintの範囲内。
- 妥当な入力ではsymbolsの値が0..alphabetに収まり、表の添字範囲は同じ。SKIP_RUNTIME_CHECKSを定義した場合の入力前提は変わらず、今回の変更による検査削除はない。

## 所有権・例外・寿命

- 全領域をvectorまたはunique_ptr配列が所有する。直接のnew式や非所有ポインタの保存は追加していない。get()は即時のcopy呼び出しだけに渡す。
- 後続確保や再帰で例外が起きても構築済みの所有オブジェクトが自動解放される。未初期化int配列の破棄は要素を読み出さない。
- induceは局所表を参照捕捉し、関数終了前にだけ実行する。再帰中も親フレームの所有オブジェクトは生存し、コピー先は再確保されない。
- 表要素数に異常に大きな値を与えた際の確保失敗は引き続き例外となる。vectorと配列確保では実装上の最大サイズ判定や例外の種類が一致するとは限らないが、公開APIは確保失敗の具体的例外型を約束していない。既存の明示的length_error・入力例外は変更していない。
- メモリ要素数と漸近計算量は同じ。性能は未測定であり高速化の採否はこの静的確認では判断しない。

候補のコンパイル、実行、ベンチマークは担当範囲外として行っていない。親エージェント側で正しさ・構成別ビルド・P-Core測定を行うための候補である。
