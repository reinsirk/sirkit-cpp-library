from pathlib import Path
import difflib
import hashlib
import json

SOURCE = Path('/home/reinsirk/Atcoder_Env/String/Suffix_Array.cpp')
OUT = Path('/tmp/sirkit_suffix_416522/agent')
EXPECTED_SHA = 'ddabec6d617bfa97a0bd94c0ac79ecc3f4d829ce78add2a52e9af1bc713b45bf'
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED_SHA
base = raw.decode()
old_header = 'inline std::vector<int> suffix_induced(std::span<const int> symbols, int alphabet) {'
new_header = '''template <std::integral Symbol>
inline std::vector<int> suffix_induced(std::span<const Symbol> symbols, int alphabet) {'''
old_encoder = '''    auto encoded = std::make_unique_for_overwrite<int[]>(s.size() + 1);
    encoded[s.size()] = 0;
    for (std::size_t i = 0; i < s.size(); ++i) encoded[i] = static_cast<unsigned char>(s[i]) + 1;
    auto result = reinsirk::detail::suffix_induced(std::span<const int>(encoded.get(), s.size() + 1), 256);'''
new_encoder = '''    auto encoded = std::make_unique_for_overwrite<std::uint_least16_t[]>(s.size() + 1);
    encoded[s.size()] = 0;
    for (std::size_t i = 0; i < s.size(); ++i)
        encoded[i] = static_cast<std::uint_least16_t>(static_cast<unsigned char>(s[i]) + 1);
    auto result = reinsirk::detail::suffix_induced(
        std::span<const std::uint_least16_t>(encoded.get(), s.size() + 1), 256);'''
replacements = [
    (old_header, new_header, 1),
    ('suffix_induced(reduced, name)', 'suffix_induced(std::span<const int>(reduced), name)', 1),
    ('suffix_induced(encoded,', 'suffix_induced(std::span<const int>(encoded),', 3),
    (old_encoder, new_encoder, 1),
]

def replace_exact(text, old, new, count):
    assert text.count(old) == count, (old, text.count(old), count)
    return text.replace(old, new)

result = base
for old, new, count in replacements:
    result = replace_exact(result, old, new, count)
reconstructed = result
for old, new, count in reversed(replacements):
    reconstructed = replace_exact(reconstructed, new, old, count)
assert reconstructed == base
body_start = base.index(old_header) + len(old_header)
body_end = base.index('\n}\n\ninline std::vector<int> suffix_string', body_start)
base_body = base[body_start:body_end]
new_body_start = result.index(new_header) + len(new_header)
new_body = result[new_body_start:result.index('\n}\n\ninline std::vector<int> suffix_string', new_body_start)]
assert new_body.replace('suffix_induced(std::span<const int>(reduced), name)', 'suffix_induced(reduced, name)') == base_body
assert result.count('inline std::vector<int> suffix_induced(') == 1
assert result.count('suffix_induced(') == 6  # 1定義、再帰、文字列、整数列3入口。
assert result.count('suffix_induced(std::span<const int>(encoded),') == 3
assert 'suffix_induced_symbols' not in result
assert 'suffix_induced(reduced,' not in result and 'suffix_induced(encoded,' not in result
output = OUT / 'narrow_direct.hpp'
output.write_text(result)
(OUT / 'narrow_direct.hpp.diff').write_text(''.join(difflib.unified_diff(
    base.splitlines(True), result.splitlines(True), fromfile='String/Suffix_Array.cpp', tofile=output.name)))
metadata = dict(source=str(SOURCE), source_sha256=EXPECTED_SHA, path=str(output),
                sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
                exact_replacements=[dict(old=old, new=new, count=count) for old, new, count in replacements],
                reverse_reconstruction_identical=True, single_implementation_no_wrapper=True,
                induced_body_identical_except_explicit_int_recursive_span=True,
                explicit_int_span_for_all_three_integer_entry_calls=True)
(OUT / 'direct_metadata.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
assert SOURCE.read_bytes() == raw
print(json.dumps(dict(path=str(output), sha256=metadata['sha256']), indent=2))
