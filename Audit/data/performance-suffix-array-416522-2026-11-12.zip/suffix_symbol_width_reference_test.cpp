// SPDX-License-Identifier: CC0-1.0
// 符号256・65535前後の長さ・多数の再帰名を独立の倍増法と照合する。
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <initializer_list>
#include <iostream>
#include <numeric>
#include <random>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#ifndef SUFFIX_HEADER
#define SUFFIX_HEADER "../../../String/Suffix_Array.cpp"
#endif
#include SUFFIX_HEADER

namespace reinsirk::detail {
std::size_t symbol_width_checks = 0;

// 2^k文字の順位対をstd::sortする倍増法。検査用のO(n log^2 n)。
std::vector<int> symbol_width_reference_sa(std::vector<int> rank) {
    const int n = static_cast<int>(rank.size());
    std::vector<int> order(rank.size()), next(rank.size());
    std::iota(order.begin(), order.end(), 0);
    if (n < 2) return order;
    for (std::size_t width = 1; width < rank.size(); width *= 2) {
        const auto key = [&](int position) {
            const std::size_t second = static_cast<std::size_t>(position) + width;
            return std::pair(rank[position], second < rank.size() ? rank[second] : -1);
        };
        std::sort(order.begin(), order.end(), [&](int a, int b) { return key(a) < key(b); });
        next[order[0]] = 0;
        for (int i = 1; i < n; ++i)
            next[order[i]] = next[order[i - 1]] + (key(order[i - 1]) != key(order[i]));
        rank.swap(next);
        if (rank[order.back()] == n - 1) break;
    }
    return order;
}

void symbol_width_equal(const std::vector<int>& actual, const std::vector<int>& expected,
                        const std::string& label) {
    if (actual != expected) throw std::runtime_error(label);
    ++symbol_width_checks;
}

void symbol_width_check_string(const std::string& text, const std::string& label) {
    std::vector<int> bytes(text.size());
    for (std::size_t i = 0; i < text.size(); ++i)
        bytes[i] = static_cast<unsigned char>(text[i]);
    const auto expected = symbol_width_reference_sa(bytes);
    const auto actual = suffix_array(text);
    symbol_width_equal(actual, expected, label + ": string");
    symbol_width_equal(suffix_array(std::string_view(text)), expected, label + ": string_view");
    symbol_width_equal(suffix_array(bytes, 255), expected, label + ": bounded int");

    // 無作為なバイト列では隣接LCPが短く、各組を直接比較できる。
    std::vector<int> lcp(text.empty() ? 0 : text.size() - 1);
    for (std::size_t i = 0; i < lcp.size(); ++i) {
        const std::size_t a = static_cast<std::size_t>(expected[i]);
        const std::size_t b = static_cast<std::size_t>(expected[i + 1]);
        std::size_t common = 0;
        while (a + common < text.size() && b + common < text.size() &&
               text[a + common] == text[b + common]) ++common;
        lcp[i] = static_cast<int>(common);
    }
    symbol_width_equal(lcp_array(text, actual), lcp, label + ": lcp");
}

void symbol_width_check_recursive_names() {
    constexpr int names = 65538;
    constexpr int peak = names + 1;
    std::vector<int> symbols;
    symbols.reserve(static_cast<std::size_t>(2 * (names + 3)));
    // 谷がLMSとなる。65538種の谷に、同じLMS部分列0,peak,1を重ねる。
    // 名前は65535を超え、重複名があるためintでの再帰も必要になる。
    for (int value = 0; value < names; ++value) {
        symbols.push_back(peak);
        symbols.push_back(value);
    }
    for (int value : {0, 1, 0}) {
        symbols.push_back(peak);
        symbols.push_back(value);
    }
    const auto expected = symbol_width_reference_sa(symbols);
    symbol_width_equal(suffix_array(symbols, peak), expected, "recursive names: bounded int");
    symbol_width_equal(suffix_array(symbols), expected, "recursive names: compressed int");
}
}

int main() {
    try {
        using reinsirk::detail::symbol_width_check_string;
        symbol_width_check_string("", "empty");
        symbol_width_check_string(std::string("\0", 1), "zero");
        symbol_width_check_string(std::string("\xff", 1), "255");
        symbol_width_check_string(std::string("\0\xff\0\xff", 4), "zero and 255");
        symbol_width_check_string(std::string("\xff\0\xff\0\x7f\x80", 6), "signed byte boundary");
        std::string every_byte;
        for (int value = 0; value < 256; ++value)
            every_byte.push_back(static_cast<char>(static_cast<unsigned char>(value)));
        symbol_width_check_string(every_byte, "all 256 bytes");
        std::reverse(every_byte.begin(), every_byte.end());
        symbol_width_check_string(every_byte, "all 256 bytes reversed");

        std::mt19937_64 random(std::uint64_t{0x89f124a6bc039d57});
        for (const std::size_t length : {std::size_t{65535}, std::size_t{65536},
                                         std::size_t{65537}, std::size_t{600000}}) {
            std::string text(length, '\0');
            for (char& byte : text)
                byte = static_cast<char>(static_cast<unsigned char>(random() & 255));
            symbol_width_check_string(text, "random " + std::to_string(length));
        }
        reinsirk::detail::symbol_width_check_recursive_names();
        std::cout << "suffix symbol width: checks=" << reinsirk::detail::symbol_width_checks
                  << " symbol_bytes=" << sizeof(std::uint_least16_t)
                  << " int_bytes=" << sizeof(int) << '\n';
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
