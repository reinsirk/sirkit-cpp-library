// SPDX-License-Identifier: CC0-1.0
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <numeric>
#include <random>
#include <string>
#include <utility>
#include <vector>
std::vector<int> reference_sa(const std::string& s) {
 const int n=static_cast<int>(s.size()); std::vector<int> sa(n),rank(n),next(n);std::iota(sa.begin(),sa.end(),0);
 for(int i=0;i<n;++i)rank[i]=static_cast<unsigned char>(s[i]);
 for(int step=1;step<n;step*=2){auto key=[&](int i){return std::pair{rank[i],step<n-i?rank[i+step]:-1};};
  std::sort(sa.begin(),sa.end(),[&](int a,int b){return key(a)<key(b);});next[sa[0]]=0;
  for(int i=1;i<n;++i)next[sa[i]]=next[sa[i-1]]+(key(sa[i-1])!=key(sa[i]));rank.swap(next);
  if(rank[sa.back()]==n-1 || step>n/2)break;
 }return sa;
}
int main(){
 std::mt19937_64 rng(416380);std::string s(500000,'a');for(char& c:s)c=static_cast<char>(rng()%256);
 auto sa=reference_sa(s);FILE* f=std::fopen("/tmp/sirkit_suffix_416522/independent_random_sa.bin","wb");if(!f)return 1;
 const auto written=std::fwrite(sa.data(),sizeof(int),sa.size(),f);return std::fclose(f)==0 && written==sa.size()?0:1;
}
