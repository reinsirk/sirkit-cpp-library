# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import datetime,hashlib,json,math,statistics,shutil,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_suffix_416522')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def encode(a):return json.dumps(a,ensure_ascii=False,indent=2)+'\n'
def stats(stem,label,fields,large=True):
    a=load(D/(stem+'_summary.json'));out=[]
    for key in sorted({tuple(r[k]for k in fields)for r in a}):
        rows=[r for r in a if tuple(r[k]for k in fields)==key and r['sufficient'] and (not large or r['n']>=200000)]
        if not rows:continue
        out.append(dict(zip(fields,key))|dict(cases=len(rows),candidate_ratio=math.exp(statistics.mean(math.log(r['ratios'][label])for r in rows)),identical_control_ratio=math.exp(statistics.mean(math.log(r['ratios']['control'])for r in rows)),minimum_ratio=min(r['ratios'][label]for r in rows),maximum_ratio=max(r['ratios'][label]for r in rows)))
    return out
canonical=R/'String/Suffix_Array.cpp';base=sha(D/'base.hpp');assert sha(canonical)==base==sha(D/'before/String/Suffix_Array.cpp')
frozen=['Verify/current/drivers/suffix_array_main.cpp','Verify/current/drivers/suffix_array_substrings_main.cpp','Verify/current/common/fast_io.hpp','Document/suffix_array.md','Examples/suffix_array_example.cpp']
for f in frozen:assert sha(R/f)==sha(D/'before'/f),f
prior=R/'Audit/distribution-manifest-before-suffix-array-416522-2026-11-12.json';old=(D/'before/Distribution/manifest.json').read_bytes()
if prior.exists():assert prior.read_bytes()==old
else:prior.write_bytes(old)
validation=load(D/'final_validation.json');assert validation['all_passed'] and validation['passed_jobs']==40
for stem in ['direct_full','fixed','direct_prepared']:assert all(r['sufficient']for r in load(D/(stem+'_summary.json'))),stem
journals={r['id']:r for r in load(R/'Verify/current/judgements.json')['entries']}
def norm(s):return '\n'.join(line.rstrip()for line in s.replace('\r\n','\n').splitlines()if line.strip()and not line.startswith('// Submission:'))
correspondence=[]
for identifier in ['suffix_array','suffix_array_substrings']:
    source=R/f'Verify/current/submissions/{identifier}.cpp';assert norm(source.read_text())==norm((D/f'base_{identifier}.cpp').read_text())
    j=journals[identifier];assert j['matched_current_generation'] and not j['needs_resubmission'] and j['current_source_hashes']['String/Suffix_Array.cpp']==base
    correspondence.append(dict(id=identifier,current_sha256=sha(source),online_url=j['url'],normalized_current_matches_measured_base=True,main_and_IO_unchanged=True,source_bytes=source.stat().st_size,under_512_KiB=source.stat().st_size<=512*1024))
(D/'current_correspondence.json').write_text(encode(correspondence))
(D/'fixed_input_metadata.json').write_text(encode(dict(path=str(D/'independent_random_sa.bin'),sha256=sha(D/'independent_random_sa.bin'),bytes=(D/'independent_random_sa.bin').stat().st_size,n=500000,seed=416380,method='prepare_fixed_sa.cppの独立倍増法を一度だけ実行。全候補で同じ正解SAを読み込み、準備は計測外。単一文字・周期3は数式でSAを作る。',compile_command=['taskset','-c','4','/usr/bin/g++','-std=c++23','-O2',str(D/'prepare_fixed_sa.cpp'),'-o',str(D/'prepare_fixed_sa')],timed_core_repetitions='LCP/検索は8回、それ以外は1回。計算・checksum・返却配列の破棄を計測。')))
# 現行は本体を変えない。新しい幅テストは不採用候補の検証証跡だけに収める。
for filename in ['suffix_array_acl_api_test.cpp','string_algorithms_reference_test.cpp','suffix_ntt_large_reference_test.cpp','string_math_allocation_test.cpp','suffix_histogram_reference_test.cpp']:
    target=D/'evidence_current_tests'/filename;target.parent.mkdir(exist_ok=True);shutil.copyfile(R/'Verify/current/tests'/filename,target)
comparison=load(D/'online_records.json')['comparisons']
result=dict(date='2026-11-12',library='String/Suffix_Array.cpp',decision='retain_current_after_narrow_symbol_regressions',required_resubmission=[],online_evidence='Audit/online-suffix-array-416522-416523-2026-11-12.json',online_scope='現行通常版は416522 AC48ms、416523 AC44ms。提出本文と本体/main/共通IOを照合済み。候補は採用せず、再提出不要。派生版のオンラインACとは扱わない。',source_sha256=dict(before=base,after=base),frozen_main_IO_document_examples={f:sha(R/f)for f in frozen},online_comparison=comparison,
    conclusion='16bitの文字列用符号列はSA/SA+LCPの固定Verify全体を約3%短縮した。一方、構築後のLCP単独計測ではGCC・検査有効時に約5〜11%の遅れが再現した。確保量を旧版に合わせた候補でも約3〜11%の遅れが残り、他操作の速度維持を満たさないため全候補を不採用とする。原因は特定していない。',
    candidates=[dict(name=k,sha256=sha(D/(k+'.hpp')),adopted=False)for k in ['cursor_uninit','starts_uninit','combined_tables','templated_int','narrow_root','narrow_direct','narrow_reserved']],
    candidate_scope=['バケット表のゼロ初期化省略3案は、同一実行ファイル対照を超える安定した効果なし。','int版をテンプレート化しただけの対照、文字列根のみuint_least16_tとする版、内部中継を省く版を比較。再帰名・添字・整数列はintのまま。','最後に符号配列の確保容量だけを調整。実際のint=4B・符号=2B環境で旧版と同じ確保バイト数とするが、アロケータの配置は保証しない。常時有効の容量上限検査・RAII・未参照領域を維持。','メモリ状態を分けるため独立SA準備のAPI単独比較も実施。単独の固定準備では概ね同等だが、構築に続ける操作の退行を解消できていない。'],
    measurement=dict(topology=load(D/'topology.json'),cpu_selection='CPU12、SMT sibling13、sysfs core_id24、最大6GHzのi9-14900K P-Core。E-Coreは性能評価に使わない。',compilers=dict(GCC='15.2.0',Clang='21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'),flags=['-std=c++23','-O2'],march_native=False,extra_pragmas=False,new_ISA_or_CPU_dispatch=False,standard_CXX23=True,lock='/tmp/sirkit_performance_cpu12.lock',ASLR='setarch x86_64 -R for child only',compilation_during_timing=False,
        protocol='旧版→候補→旧版を1組とし、候補時間を両端の旧版中央値で割る。各条件9組の候補と3組の同一base対照を決定的shuffle。直前直後の旧版が10%以内の組だけ有効とし、候補自身の時間では除外しない。候補5組・対照2組に不足する種だけ最大3回・各3組補充。初回/raw/補充を保存。初期screenの反復数は各実行スクリプトに保存。',
        whole_scope='同じmain・共通高速IO・入力・コンパイラ・SKIP設定の子プロセスuser+system CPU時間。75行・73個のbyte重複なし入力。20万以上の48ケースを各平均に使う。公開固定生成器と独立補助入力でありオンライン入力の同一性は主張しない。100万文字の制約外補足も含む。',official_generator_revision='73876f1cbcf082d2b22722924b924d3d65a2f00e',fixtures_sha256=sha(D/'fixtures.json'),whole_direct=stats('direct_full','narrow_direct',['compiler','id']),
        fixed_API_scope='同じ独立SAを事前に用意し、SA構築による直前の確保状態を混ぜない。bounded SA/int64/bool/LCP/検索/大alphabet SA、長さ50万・3形状、検査有効/無効。std::clockのプロセスCPU時間。正解入力生成は計測外。',fixed_API=stats('fixed','narrow_direct',['compiler','setting','kind']),
        construction_then_API_scope='各プロセスでまず各候補のsuffix_array(string)を計測外に実行し、その後のint64 SAまたはLCPを計測。構築後の配置・キャッシュ等も含む実用上の補足。原因をアロケータだけとは断定しない。',construction_then_API=stats('direct_prepared','narrow_direct',['compiler','setting','kind']),reserved_construction_then_API=stats('reserved_prepared','narrow_reserved',['compiler','setting','kind']),reserved_screen_scope='追加案の探索的screenであり、採否はそれ以前に完了したreserved_preparedの退行で判断。同期生成処理がscreen終盤と重なった可能性があるため、このscreenの改善率を採用根拠に使わない。',
        partial_independent_preparation=load(D/'isolated_interruption.json'),all_completed_comparisons_output_equal=True),
    validation=dict(current='現行本体は不変であり、前回Audit/performance-suffix-array-416510-2026-11-12.jsonのGCC/Clang・検査有効/無効32通りの検証に対応する同一SHA。今回2本のオンライン全74ケースACと本文一致を確認。',rejected_direct_candidate=dict(header_sha256=validation['header_sha256'],passed_jobs=validation['passed_jobs'],total_jobs=validation['total_jobs'],all_passed=validation['all_passed'],scope='不採用のnarrow_direct候補の40通り。これを現行本体を再検証した記録とは扱わない。新しい幅テストも正本へ追加せず証跡に保存。',tests=['ACL API/独立短列SA/LCP/検索','20万文字独立倍増法と整数・周期・大alphabet境界','NUL/255/全256文字種、長さ65535/65536/65537/600000、多数の再帰名を独立倍増法と照合','確保失敗と例外時解放'],allocation=[r['counters']for r in validation['jobs']if r['test']=='string_math_allocation_test'],sanitizers='ASAN+UBSANを両コンパイラ・両検査設定で実行。host ptrace制約でdetect_leaks=0、確保カウンタのlive_delta=0で解放を独立検査。'),current_correspondence=correspondence),
    generated_API_docs_and_manifests_checked=True,source_public_API_main_IO_document_examples_changed=False,license='CC0の現行本体を維持。候補・検査・補助スクリプトも今回の独自記述。外部の公式生成器本体は証跡ZIPへ含めない。',evidence_archive='Audit/data/performance-suffix-array-416522-2026-11-12.zip',evidence_scope='一時候補・生成器・静的レビュー・取得済み公開API応答・比較raw・JSON・正しさの記録。実行ファイル、巨大な入力/出力、外部生成器本体は含めない。入力の生成元は同梱fixture metadataと先行416380証跡へ対応。')
(D/'audit_draft.json').write_text(encode(result))
archive=R/result['evidence_archive'];archive.parent.mkdir(exist_ok=True)
paths=[p for p in D.rglob('*')if p.is_file()and p.suffix in {'.py','.hpp','.cpp','.json','.diff','.md','.log'}and p.name!='audit_draft.json']
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in sorted(paths):z.write(p,p.relative_to(D).as_posix())
result['evidence_archive_sha256']=sha(archive)
(R/'Audit/performance-suffix-array-416522-2026-11-12.json').write_text(encode(result))
print('Retained',base,'evidence',archive.stat().st_size,'bytes',len(paths),'files')
