#!/usr/bin/env python3
# SPDX-License-Identifier: CC0-1.0
"""Run final suffix-array correctness checks; never edit repository sources."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys

ROOT = Path('/home/reinsirk/Atcoder_Env')
WORK = Path('/tmp/sirkit_suffix_416522')
TESTS = [
    'suffix_array_acl_api_test',
    'string_algorithms_reference_test',
    'suffix_ntt_large_reference_test',
    'string_math_allocation_test',
    'suffix_histogram_reference_test',
    'suffix_symbol_width_reference_test',
]
SAN_TESTS = [TESTS[0], TESTS[1], TESTS[4], TESTS[5]]
COMPILERS = {
    'gcc': ['/usr/bin/g++'],
    'clang': ['/usr/bin/clang++', '--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'],
}


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def capture(command, *, env=None, timeout=600):
    try:
        completed = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   env=env, timeout=timeout)
        return {'returncode': completed.returncode,
                'stdout': completed.stdout.decode('utf-8', errors='replace'),
                'stderr': completed.stderr.decode('utf-8', errors='replace')}
    except subprocess.TimeoutExpired as error:
        return {'returncode': None, 'timeout': timeout,
                'stdout': (error.stdout or b'').decode('utf-8', errors='replace'),
                'stderr': (error.stderr or b'').decode('utf-8', errors='replace')}
    except OSError as error:
        return {'returncode': None, 'stdout': '', 'stderr': str(error)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--header', type=Path, default=WORK / 'final.hpp')
    parser.add_argument('--output', type=Path, default=WORK / 'final_validation.json')
    parser.add_argument('--build-dir', type=Path, default=WORK / 'final_validation_build')
    parser.add_argument('--compilers', nargs='+', choices=list(COMPILERS), default=list(COMPILERS))
    parser.add_argument('--no-sanitizers', action='store_true')
    parser.add_argument('--plan-only', action='store_true', help='Print commands without compiling or running')
    parser.add_argument('--core', type=int, default=None, help='Optional logical CPU affinity')
    parser.add_argument('--timeout', type=int, default=600)
    args = parser.parse_args()
    header = args.header.resolve()
    build_dir = args.build_dir.resolve()
    rows = []
    for compiler in args.compilers:
        for mode in ['checked', 'skip']:
            for sanitizer in ([False] if args.no_sanitizers else [False, True]):
                for test in (SAN_TESTS if sanitizer else TESTS):
                    source = (WORK / (test + '.cpp')) if test == 'suffix_symbol_width_reference_test' else ROOT / 'Verify/current/tests' / (test + '.cpp')
                    executable = build_dir / ('_'.join([compiler, mode, 'asan_ubsan' if sanitizer else 'o2', test]))
                    command = COMPILERS[compiler] + ['-std=c++23', '-O2',
                        '-DSUFFIX_HEADER="' + str(header) + '"']
                    if mode == 'skip':
                        command += ['-DSKIP_RUNTIME_CHECKS']
                    if sanitizer:
                        command += ['-fsanitize=address,undefined', '-fno-sanitize-recover=all',
                                    '-fno-omit-frame-pointer']
                    command += [str(source), '-o', str(executable)]
                    run_command = [str(executable)]
                    if args.core is not None:
                        command = ['taskset', '-c', str(args.core)] + command
                        run_command = ['taskset', '-c', str(args.core)] + run_command
                    rows.append({'compiler': compiler, 'mode': mode, 'sanitizer': sanitizer,
                                 'test': test, 'source': str(source),
                                 'compile_command': command, 'run_command': run_command})
    if args.plan_only:
        print(json.dumps({'header': str(header), 'jobs': rows}, indent=2))
        return 0
    if not header.is_file():
        parser.error('final header does not exist: ' + str(header))
    build_dir.mkdir(parents=True, exist_ok=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    versions = {}
    for compiler in args.compilers:
        versions[compiler] = capture([COMPILERS[compiler][0], '--version'])
    document = {'header': str(header), 'header_sha256': sha256(header),
                'compiler_versions': versions,
                'note': 'Correctness only. Raw test output and exact emitted counters are retained. '
                        'LeakSanitizer cannot run under this host ptrace; detect_leaks=0. Allocation tests independently verify live_delta=0 and exception cleanup, and are not run with ASAN.',
                'jobs': rows}

    def save():
        args.output.write_text(json.dumps(document, indent=2, ensure_ascii=False) + '\n')

    save()
    all_pass = True
    for row in rows:
        row['source_sha256'] = sha256(Path(row['source']))
        row['compile'] = capture(row['compile_command'], timeout=args.timeout)
        if row['compile']['returncode'] == 0:
            env = os.environ.copy()
            if row['sanitizer']:
                env['ASAN_OPTIONS'] = 'detect_leaks=0:halt_on_error=1:abort_on_error=1'
                env['UBSAN_OPTIONS'] = 'halt_on_error=1:print_stacktrace=1'
            row['run'] = capture(row['run_command'], env=env, timeout=args.timeout)
            output = row['run']['stdout']
            row['counters'] = {key: int(value) for key, value in
                               re.findall(r'\b(checks|failures|live_delta)=(\d+)', output)}
            row['passed'] = (row['run']['returncode'] == 0 and not row['run']['stderr'] and
                             row['counters'].get('checks', 0) > 0 and
                             row['counters'].get('live_delta', 0) == 0)
        else:
            row['passed'] = False
        all_pass = all_pass and row['passed']
        save()
        # Retain the test's full output in JSON; print its exact counters here as well.
        print(row['compiler'], row['mode'], 'asan_ubsan' if row['sanitizer'] else 'o2',
              row['test'], 'PASS' if row['passed'] else 'FAIL',
              json.dumps(row.get('counters', {})), flush=True)
    document['all_passed'] = all_pass
    document['passed_jobs'] = sum(bool(row.get('passed')) for row in rows)
    document['total_jobs'] = len(rows)
    save()
    print('Saved:', args.output, flush=True)
    return 0 if all_pass else 1


if __name__ == '__main__':
    sys.exit(main())
