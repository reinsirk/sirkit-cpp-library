// SPDX-License-Identifier: CC0-1.0
#include HEADER
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <random>
std::vector<int> reference_sa(const std::string& s) {
 const int n=static_cast<int>(s.size()); std::vector<int> sa(n),rank(n),next(n);std::iota(sa.begin(),sa.end(),0);
 for(int i=0;i<n;++i)rank[i]=static_cast<unsigned char>(s[i]);
 for(int step=1;step<n;step*=2){auto key=[&](int i){return std::pair{rank[i],step<n-i?rank[i+step]:-1};};
  std::sort(sa.begin(),sa.end(),[&](int a,int b){return key(a)<key(b);});next[sa[0]]=0;
  for(int i=1;i<n;++i)next[sa[i]]=next[sa[i-1]]+(key(sa[i-1])!=key(sa[i]));rank.swap(next);
  if(rank[sa.back()]==n-1 || step>n/2)break;
 }return sa;
}
int main(int argc,char**argv){
 if(argc!=5)return 2;
 const int kind=std::atoi(argv[1]), n=std::atoi(argv[2]), shape=std::atoi(argv[3]), reps=std::atoi(argv[4]);
 std::mt19937_64 rng(416380); std::vector<int> a(n); std::vector<std::int64_t>b(n); std::vector<bool>bits(n); std::string s(n,'a');
 for(int i=0;i<n;++i){const int v=shape==0?0:shape==1?i%3:static_cast<int>(rng()%256); a[i]=v; b[i]=std::int64_t(v)*1000000007-2000000014;bits[i]=v%2;s[i]=static_cast<char>(v);}
 if(kind>=5){for(int i=0;i<n;++i)a[i]=shape==1?n-1-i:i;if(shape==2)std::shuffle(a.begin(),a.end(),rng);for(int i=0;i<n;++i)b[i]=std::int64_t(a[i])*1000000007-2000000014;}
 auto sa=(kind==3 || kind==4)?reference_sa(s):std::vector<int>{};std::uint64_t hash=0;
 const auto begin=std::clock();
 for(int rep=0;rep<reps;++rep){std::vector<int>r;
  if(kind==0)r=suffix_array(a,255);
  if(kind==1)r=suffix_array(b);
  if(kind==2)r=suffix_array(bits);
  if(kind==3)r=lcp_array(s,sa);
  if(kind==5)r=suffix_array(a,n-1);
  if(kind==6)r=suffix_array(b);
  if(kind==4){const auto range=SuffixArrayEqualRange(std::string_view(s),sa,std::string_view(s).substr(n/3,n/4));r={range.first,range.second};}
  for(int x:r)hash=(hash^static_cast<std::uint32_t>(x))*1099511628211ULL;
 }
 const auto ns=static_cast<std::int64_t>(std::clock()-begin)*1000000000/CLOCKS_PER_SEC;
 std::printf("%jd %ju\n",static_cast<std::intmax_t>(ns),static_cast<std::uintmax_t>(hash));
}
