# SPDX-License-Identifier: CC0-1.0
# 5配布ZIPの検査後に外側manifestだけを更新する。既定はdry-run。
from pathlib import Path
import argparse
import copy
import datetime
import hashlib
import json
import zipfile

R = Path('/home/reinsirk/Atcoder_Env')
PERFORMANCE = 'Audit/performance-suffix-array-416522-2026-11-12.json'
ONLINE = 'Audit/online-suffix-array-416522-416523-2026-11-12.json'
PREVIOUS = 'Audit/distribution-manifest-before-suffix-array-416522-2026-11-12.json'
LIBRARY = 'String/Suffix_Array.cpp'
MANIFESTS = ('Variants/manifest.json', 'Variants/verify_manifest.json',
             'Verify/current/manifest.json', 'Scripts/library_layout.json')
EDITIONS = ('full', 'gcc', 'clang', 'fast_gcc', 'fast_clang')
JOBS = (('suffix_array', 416522, 48), ('suffix_array_substrings', 416523, 44))

def load(path):
    return json.loads(path.read_text())

def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

def encode(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + '\n'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    outer = R / 'Distribution/manifest.json'
    old = load(outer)
    previous_path = R / PREVIOUS
    previous = load(previous_path)  # 親が事前に保存する不変の旧manifest。
    previous_hash = sha(previous_path)
    audit_path = R / PERFORMANCE
    audit = load(audit_path)
    decision = audit['decision']
    assert isinstance(decision, str), 'decisionは文字列を要求する'
    if decision.startswith('adopt'):
        adopted = True
    elif decision.startswith(('retain', 'reject', 'keep', 'no_adopt')):
        adopted = False
    else:
        raise ValueError('未知のdecision。adopt/retain/reject/keep/no_adoptで始まる値を使う: ' + decision)
    source_hash = sha(R / LIBRARY)
    assert audit['library'] == LIBRARY
    assert audit['source_sha256']['after'] == source_hash, 'Auditと正本の本体が不一致'
    if adopted:
        assert audit['source_sha256']['before'] != source_hash, '採用時は本体変更が必要'
    else:
        assert audit['source_sha256']['before'] == source_hash, '維持判断なのに本体が変わっている'
    pending_paths = [f'Verify/current/submissions/{identifier}.cpp' for identifier, _, _ in JOBS]
    required = audit['required_resubmission']
    assert required in ([], pending_paths), '対象2件以外の再提出指定を上書きしない'
    pending = bool(required)
    assert pending == adopted, '未提出の新本体はpending、既存本体の維持は再提出不要'

    journal = {record['id']: record for record in load(R / 'Verify/current/judgements.json')['entries']}
    normal_manifest = load(R / MANIFESTS[2])
    normal = {entry['id']: entry for entry in normal_manifest['entries']}
    for identifier, submission, milliseconds in JOBS:
        record = journal[identifier]
        assert record['status'] == 'AC' and record['time_ms'] == milliseconds
        assert record['url'] == f'https://judge.yosupo.jp/submission/{submission}'
        assert record['matched_current_generation'] is (not pending)
        assert record['needs_resubmission'] is pending
        assert record['current_source_hashes'][LIBRARY] == source_hash
        entry = normal[identifier]
        assert entry['source_hashes'][LIBRARY] == source_hash
        assert entry['judge_record']['matched_current_generation'] is (not pending)
        assert entry['submission_sha256'] == sha(R / entry['submission'])
        assert entry['judge_record']['url'] == record['url']
        assert entry['judge_record']['needs_resubmission'] is pending

    online = load(R / ONLINE)
    submitted = {record['id']: record for record in online['records']}
    for identifier, submission, milliseconds in JOBS:
        assert submitted[identifier]['url'] == f'https://judge.yosupo.jp/submission/{submission}'
        assert submitted[identifier]['status'] == 'AC' and submitted[identifier]['time_ms'] == milliseconds
    variant_manifest = load(R / MANIFESTS[0])
    variant_verify = load(R / MANIFESTS[1])
    target_variant_verifies = [entry for entry in variant_verify['entries'] if entry['id'] in submitted]
    assert len(target_variant_verifies) == 8
    for entry in target_variant_verifies:
        assert not entry['submission_urls'] and '未提出' in entry['online_status'], '通常版ACを派生版へ転記しない'

    manifests = {name: sha(R / name) for name in MANIFESTS}
    validation = load(R / 'Distribution/validation.json')
    assert validation['all_ok'] is True
    reports = validation['reports']
    assert len(reports) == 5 and {report['edition'] for report in reports} == set(EDITIONS)
    by_edition = {report['edition']: report for report in reports}
    archives = []
    for edition in EDITIONS:
        report = by_edition[edition]
        name = f'sirkit-cpp-library_{edition}.zip'
        archive_path = R / 'Distribution' / name
        assert Path(report['archive']).resolve() == archive_path.resolve()
        assert report['ok'] is True and not report['errors']
        assert report['current_manifest_hashes'] == manifests, (edition, '検査後にmanifestが変更された')
        assert report['validator_sha256'] == sha(R / 'Scripts/verify_distribution.py')
        archive_hash = sha(archive_path)
        assert report['archive_sha256'] == archive_hash, (edition, '検査後にZIPが変更された')
        with zipfile.ZipFile(archive_path) as archive:
            entries = len(archive.infolist())
        assert entries == report['stats']['entries'] == report['stats']['crc_entries_checked']
        archives.append(dict(edition=edition, file=name, bytes=archive_path.stat().st_size,
                             sha256=archive_hash, entries=entries, validation='PASS',
                             errors=len(report['errors']), warnings=len(report['warnings'])))

    result = copy.deepcopy(old)
    result.update(status='verified', prepared_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  scope='接尾辞配列の追加最適化の評価結果を記録。' + (
                      '新しい本体を採用し、' if adopted else '既存の本体を維持し、') +
                      '通常版・派生版・Verify・5配布ZIPを同期して検査。オンライン記録は提出時の通常版の範囲に限定する。',
                  counts=dict(compiler_and_fast_sources=len(variant_manifest['entries']),
                              normal_verify=len(normal_manifest['entries']),
                              compiler_and_fast_verify=len(variant_verify['entries'])),
                  archives=archives, current_manifest_sha256=manifests, validation='validation.json',
                  previous_release_manifest='../' + PREVIOUS,
                  performance_audit='../' + PERFORMANCE, online_confirmation_audit='../' + ONLINE,
                  required_resubmission_for_performance=required, next_normal_verify=required,
                  online_scope='416522のAC48msと416523のAC44msは提出時通常版の本文と一致。' + (
                      '新しく採用した本体の現行通常版は再提出待ち。' if pending else
                      '現行通常版は同じ本体/main/共通IOで本文一致し、再提出不要。') +
                      'main/共通IOは同一。派生版へオンラインACを転記しない。')
    if adopted:
        result['accepted_performance_audit'] = '../' + PERFORMANCE
    elif 'accepted_performance_audit' in previous:
        result['accepted_performance_audit'] = previous['accepted_performance_audit']
    else:
        result.pop('accepted_performance_audit', None)
    assert sha(previous_path) == previous_hash
    report = dict(mode='apply' if args.apply else 'dry-run', performance_decision=decision,
                  current_source_sha256=source_hash, previous_release_manifest_sha256=previous_hash,
                  required_resubmission=required, manifest=result)
    print(encode(report), end='')
    if args.apply:
        temporary = outer.with_name(outer.name + '.sirkit-update.tmp')
        temporary.write_text(encode(result))
        temporary.replace(outer)
        assert sha(previous_path) == previous_hash

if __name__ == '__main__':
    main()
