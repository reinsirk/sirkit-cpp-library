from pathlib import Path
import subprocess,json,random,statistics,shutil,os,time,hashlib,sys
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_segtree_third_20261102');P=Path('/tmp/sirkit_segtree_speed_20261102');O=Path('/tmp/sirkit_segtree_followup_20261102');s=(D/'carry_select_wide.hpp').read_text();a=s.index('    void update_ancestors(');b=s.index('public:',a)
s=s.replace('std::is_trivially_copyable_v<S> && sizeof(S) <= 16','std::is_trivially_copyable_v<S> && std::is_copy_constructible_v<S> && std::is_copy_assignable_v<S> && std::is_invocable_r_v<S, decltype(op), const S&, const S&> && sizeof(S) <= 16')
s=s.replace('S value = data_[p];','S value = std::as_const(data_)[p];').replace('const S sibling = data_[p ^ 1];','const S sibling = std::as_const(data_)[p ^ 1];').replace('data_[p] = value;','data_[p] = std::as_const(value);')
(D/'carry_select_guarded.hpp').write_text(s)
variants={'old':(D/'before.hpp').read_text(),'guarded':s,'narrow':s.replace('sizeof(S) <= 16','sizeof(S) <= 8')}
a=s.index('    void update_ancestors(');b=s.index('public:',a);fn=s[a:b];body=fn[fn.index('            if (p <= 1) return;'):fn.index('        } else {')]
head='''#if defined(__GNUC__) || defined(__clang__)
    [[gnu::noinline]]
#endif
    void update_carried_ancestors(std::size_t p) {
'''+body+'''    }
'''
wrapped=fn[:fn.index('            std::size_t p = node;')]+'            update_carried_ancestors(node);\n'+fn[fn.index('        } else {'):]
variants['noinline']=s[:a]+head+wrapped+s[b:]
entries=[e for e in prepare_verify.collect() if e['id'] in ['segment_tree','segment_tree_composite']]
for label,source in variants.items():
 (D/f'clang_{label}.hpp').write_text(source)
 for e in entries:
  data,_=prepare_verify.render(e,source_overrides={'DataStructure/Segment_Tree.cpp':source.encode()});src=D/f'clangscreen_{e["id"]}_{label}.cpp';src.write_bytes(data)
  subprocess.run(['taskset','-c','2','/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','-std=c++23','-O2',str(src),'-o',str(D/f'clangscreen_{e["id"]}_{label}')],check=True)
print('BUILT',flush=True);cases=[]
for family,seed in [('random',3),('random',4),('max_random',0)]:cases.append({'kind':'affine','name':f'official_affine_{family}_{seed}','path':str(O/f'official_affine_{family}_{seed}.in')})
for kind in ['sum','affine']:
 for n in [32,500000]:
  for mode in ['mixed','query','update','short']:cases.append({'kind':kind,'name':f'{kind}_{n}_{mode}','path':str(P/f'{kind}_{n}_{mode}.in')})
rng=random.Random(488567);rs=[]
for c in cases:
 for rep in range(7):
  labels=list(variants)+['control'];rng.shuffle(labels);checks=[]
  for label in labels:
   id='segment_tree' if c['kind']=='sum' else 'segment_tree_composite';exe=D/f'clangscreen_{id}_{"old" if label=="control" else label}';shutil.copyfile(exe,D/'active_clang');(D/'active_clang').chmod(0o700)
   with open(c['path'],'rb') as inp,open(D/'output','wb') as out:
    t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active_clang')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-t
   ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rs.append({'case':c['name'],'label':label,'rep':rep,'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
  assert len(set(checks))==1
 ms={l:statistics.median(x['cpu_ns'] for x in rs if x['case']==c['name'] and x['label']==l) for l in labels}
 print(c['name'],{l:round(v/ms['old'],3) for l,v in ms.items()},flush=True);(D/'clang_raw.json').write_text(json.dumps(rs))
