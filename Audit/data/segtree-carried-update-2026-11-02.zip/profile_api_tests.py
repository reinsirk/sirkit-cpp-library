from pathlib import Path
import subprocess,json
D=Path('/tmp/sirkit_segtree_third_20261102');root=Path.cwd();rs=[]
for profile,cmd0 in [('Variants/GCC',['/usr/bin/g++']),('Variants/Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']),('Fast/GCC',['/usr/bin/g++']),('Fast/Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 cmd=['taskset','-c','6',*cmd0,'-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS']
 for macro,name in [('FENWICK','Fenwick_Tree'),('SEGMENT','Segment_Tree'),('LAZY_SEGMENT','Lazy_Segment_Tree')]:
  cmd+=[f'-DSIRKIT_{macro}_TEST_SOURCE="{root/profile/"DataStructure"/(name+".cpp")}"']
 exe=D/(profile.replace('/','_')+'_api_test');cmd+=[str(root/'Verify/current/tests/acl_range_api_test.cpp'),'-o',str(exe)];subprocess.run(cmd,check=True,capture_output=True)
 run=subprocess.run(['taskset','-c','6',str(exe)],capture_output=True,text=True)
 rs.append({'profile':profile,'command':cmd,'returncode':run.returncode,'stdout':run.stdout,'stderr':run.stderr});print(profile,run.returncode,run.stdout.strip(),flush=True);assert run.returncode==0
(D/'profile_api_tests.json').write_text(json.dumps(rs,ensure_ascii=False,indent=2)+'\n')
