#include SOURCE
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <random>
#include <string>
#include <type_traits>
constexpr std::uint64_t m=1000000007;
struct Affine {
 std::uint64_t a,b;
 Affine()=delete;
 Affine(std::uint64_t x,std::uint64_t y):a(x),b(y){}
 bool operator==(const Affine&)const=default;
};
static_assert(std::is_trivially_copyable_v<Affine> && sizeof(Affine)<=16);
Affine op(Affine l,Affine r){return {(l.a*r.a)%m,(l.b*r.a+r.b)%m};}
Affine e(){return {1,0};}
std::string cat(const std::string&a,const std::string&b){return a+b;}
std::string es(){return {};}
bool eb(){return true;}
int main(){
 std::mt19937 rng(129001);
 unsigned checks=0;
 for(int n:{1,2,3,7,8,9,31,32,33,63,64,65,127,128,129,257}){
  std::vector<Affine> a(n,e());segtree<Affine,op,e> t(a);
  for(int rep=0;rep<200;++rep){
   int i=rng()%n;Affine v(rng()%m,rng()%m);a[i]=v;
   if(rep&1)t.set(i,v);else t.transform(i,[&](const auto&){return v;});
   int l=rng()%(n+1),r=rng()%(n+1);if(l>r)std::swap(l,r);
   Affine want=e();for(int j=l;j<r;++j)want=op(want,a[j]);
   if(t.prod(l,r)!=want)std::abort();++checks;
   want=e();for(const auto&v:a)want=op(want,v);
   if(t.all_prod()!=want)std::abort();++checks;
  }
 }
 segtree<bool,std::logical_and<bool>{},eb> b(std::vector<bool>{true,false,true});b.set(1,true);if(!b.all_prod())std::abort();b.transform(0,[](bool){return false;});if(b.all_prod())std::abort();
 segtree<std::string,cat,es> s(std::vector<std::string>{"a","b","c"});s.set(1,"DE");if(s.all_prod()!="aDEc")std::abort();s.transform(0,[](const auto&v){return v+v;});if(s.all_prod()!="aaDEc")std::abort();
 std::printf("PASS %u affine checks; bool; nontrivial string fallback\n",checks);
}
