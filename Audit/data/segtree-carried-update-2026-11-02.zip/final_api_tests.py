from pathlib import Path
import subprocess,os,json,hashlib
D=Path('/tmp/sirkit_segtree_third_20261102'); root=Path.cwd();rs=[]
for cc,command in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  for name in ['segment_tree_reference_test','acl_range_api_test','acl_range_reference_test','range_structures_allocation_test']:
   src=root/'Verify/current/tests'/(name+'.cpp');exe=D/f'{cc}_{name}_{skip}'
   cmd=['taskset','-c','4',*command,'-std=c++23','-O2','-I',str(root/'Verify/current/vendor')]
   if name!='range_structures_allocation_test':cmd+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
   if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
   cmd+=[str(src),'-o',str(exe)];subprocess.run(cmd,check=True,capture_output=True)
   run=subprocess.run(['taskset','-c','4',str(exe)],env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0'),capture_output=True,text=True)
   rs.append({'compiler':cc,'skip_runtime_checks':skip,'test':name,'command':cmd,'returncode':run.returncode,'stdout':run.stdout,'stderr':run.stderr,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest()})
   (D/'final_api_tests.json').write_text(json.dumps(rs,ensure_ascii=False,indent=2)+'\n');print(cc,skip,name,run.returncode,run.stdout.strip(),flush=True);assert run.returncode==0
