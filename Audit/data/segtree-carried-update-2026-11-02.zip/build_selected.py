from pathlib import Path
import sys,subprocess
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_segtree_third_20261102');s=(D/'carry_select_guarded.hpp').read_text();a=s.index('    void update_ancestors(');b=s.index('public:',a);fn=s[a:b]
body=fn[fn.index('            if (p <= 1) return;'):fn.index('        } else {')];body='\n'.join(line[8:] if line.startswith('        ') else line for line in body.splitlines())+'\n'
new='''    void update_carried_ancestors(std::size_t p) {
'''+body+'''    }
    void update_ancestors(std::size_t p) {
        if constexpr (std::is_trivially_copyable_v<S> && std::is_copy_constructible_v<S> &&
                      std::is_copy_assignable_v<S> && sizeof(S) <= 16 &&
                      std::is_invocable_r_v<S, decltype(op), const S&, const S&>) {
#if defined(__clang__)
            if constexpr (sizeof(S) > 8) {
                [[clang::noinline]] update_carried_ancestors(p);
                return;
            }
#endif
            update_carried_ancestors(p);
        } else {
            for (p >>= 1; p; p >>= 1) data_[p] = std::invoke(op, data_[2 * p], data_[2 * p + 1]);
        }
    }
'''
s=s[:a]+new+s[b:];(D/'selected.hpp').write_text(s)
entries=[e for e in prepare_verify.collect() if e['id'] in ['segment_tree','segment_tree_composite']]
for label,source in [('selected',s)]:
 for e in entries:
  data,_=prepare_verify.render(e,source_overrides={'DataStructure/Segment_Tree.cpp':source.encode()});src=D/f'{e["id"]}_{label}.cpp';src.write_bytes(data)
  for cc,cmd in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
   subprocess.run(['taskset','-c','2',*cmd,'-std=c++23','-O2',str(src),'-o',str(D/f'{"clang_" if cc=="clang" else ""}{e["id"]}_{label}')],check=True)
