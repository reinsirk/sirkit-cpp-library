from pathlib import Path
import sys,subprocess,json,random,statistics,shutil,os,time,hashlib
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_segtree_third_20261102');P=Path('/tmp/sirkit_segtree_speed_20261102');O=Path('/tmp/sirkit_segtree_followup_20261102');s=(D/'before.hpp').read_text();a=s.index('    void update_ancestors(');b=s.index('public:',a);old=s[a:b]
variants={'old':s}
branch='''            if (p <= 1) return;
            S value = data_[p];
            while (p > 1) {
                const S sibling = data_[p ^ 1];
                if (p & 1) value = std::invoke(op, sibling, value);
                else value = std::invoke(op, value, sibling);
                p >>= 1;
                data_[p] = value;
            }
'''
select='''            if (p <= 1) return;
            S value = data_[p];
            while (p > 1) {
                const S sibling = data_[p ^ 1];
                const S left = (p & 1) ? sibling : value;
                const S right = (p & 1) ? value : sibling;
                value = std::invoke(op, left, right);
                p >>= 1;
                data_[p] = value;
            }
'''
# Select operands from two registers. Bitwise selection only for trivial values whose exact bytes are available.
for label,body in [('carry_branch',branch),('carry_select',select)]:
 for idx in ['wide','narrow']:
  head='    void update_ancestors(std::size_t node) {\n        if constexpr (std::is_trivially_copyable_v<S> && sizeof(S) <= 16) {\n'
  head+=('            unsigned p = static_cast<unsigned>(node);\n' if idx=='narrow' else '            std::size_t p = node;\n')
  text=head+body+'        } else {\n            for (auto p = node >> 1; p; p >>= 1) data_[p] = std::invoke(op, data_[2 * p], data_[2 * p + 1]);\n        }\n    }\n'
  variants[label+'_'+idx]=s[:a]+text+s[b:]
entries=[e for e in prepare_verify.collect() if e['id'] in ['segment_tree','segment_tree_composite']]
for label,source in variants.items():
 (D/(label+'.hpp')).write_text(source)
 for e in entries:
  data,_=prepare_verify.render(e,source_overrides={'DataStructure/Segment_Tree.cpp':source.encode()});src=D/f'{e["id"]}_{label}.cpp';src.write_bytes(data)
  cmd=['taskset','-c','2','/usr/bin/g++','-std=c++23','-O2',str(src),'-o',str(D/f'{e["id"]}_{label}')];subprocess.run(cmd,check=True)
print('BUILT',flush=True)
cases=[]
for seed in [0,3,4]:cases.append({'kind':'affine','name':f'official_affine_random_{seed}','path':str(O/f'official_affine_random_{seed}.in')})
for seed in [0,1]:cases.append({'kind':'affine','name':f'official_affine_max_random_{seed}','path':str(O/f'official_affine_max_random_{seed}.in')})
for kind in ['sum','affine']:
 for n in [32,4096,500000]:
  for mode in ['mixed','query','update','short']:cases.append({'kind':kind,'name':f'{kind}_{n}_{mode}','path':str(P/f'{kind}_{n}_{mode}.in')})
rng=random.Random(490123);rs=[]
for c in cases:
 for rep in range(7):
  labels=list(variants)+['control'];rng.shuffle(labels);checks=[]
  for label in labels:
   id='segment_tree' if c['kind']=='sum' else 'segment_tree_composite';exe=D/f'{id}_{"old" if label=="control" else label}';shutil.copyfile(exe,D/'active');(D/'active').chmod(0o700)
   with open(c['path'],'rb') as inp,open(D/'output','wb') as out:
    t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-t
   ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rs.append({'case':c['name'],'label':label,'rep':rep,'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
  assert len(set(checks))==1
 ms={l:statistics.median(x['cpu_ns'] for x in rs if x['case']==c['name'] and x['label']==l) for l in labels}
 print(c['name'],{l:round(v/ms['old'],3) for l,v in ms.items()},flush=True);(D/'screen_raw.json').write_text(json.dumps(rs))
