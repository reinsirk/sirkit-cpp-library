from pathlib import Path
import subprocess,json,random,statistics,shutil,os,time,hashlib
D=Path('/tmp/sirkit_segtree_third_20261102');P=Path('/tmp/sirkit_segtree_speed_20261102');O=Path('/tmp/sirkit_segtree_followup_20261102')
print('FINAL SELECTED BUILT',flush=True);cases=[]
for family in ['random','max_random']:
 for seed in range(5):cases.append({'kind':'affine','name':f'official_affine_{family}_{seed}','path':str(O/f'official_affine_{family}_{seed}.in')})
for kind in ['sum','affine']:
 for n in [32,4096,500000]:
  for mode in ['mixed','query','update','short']:cases.append({'kind':kind,'name':f'{kind}_{n}_{mode}','path':str(P/f'{kind}_{n}_{mode}.in')})
rng=random.Random(785123);rs=[]
for compiler in ['gcc','clang']:
 for c in cases:
  for rep in range(11):
   labels=['old','control','selected'];rng.shuffle(labels);checks=[]
   for label in labels:
    id='segment_tree' if c['kind']=='sum' else 'segment_tree_composite';exe=D/f'{"clang_" if compiler=="clang" else ""}{id}_{"old" if label=="control" else label}';shutil.copyfile(exe,D/'active_selected');(D/'active_selected').chmod(0o700)
    with open(c['path'],'rb') as inp,open(D/'output','wb') as out:
     t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active_selected')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-t
    ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rs.append({'compiler':compiler,'case':c['name'],'label':label,'rep':rep,'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
   assert len(set(checks))==1
  ms={l:statistics.median(x['cpu_ns'] for x in rs if x['compiler']==compiler and x['case']==c['name'] and x['label']==l) for l in labels}
  print(compiler,c['name'],{l:round(v/ms['old'],3) for l,v in ms.items()},flush=True);(D/'selected_raw.json').write_text(json.dumps(rs))
