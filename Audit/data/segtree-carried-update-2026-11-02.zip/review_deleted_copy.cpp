#ifndef SOURCE
#define SOURCE "/home/reinsirk/Atcoder_Env/DataStructure/Segment_Tree.cpp"
#endif
#include SOURCE
#include <type_traits>
struct S {
 int x;
 explicit S(int v):x(v) {}
 S(const S&)=default;
 S(S&&)=default;
 S& operator=(const S&)=delete;
 S& operator=(S&&)=default;
};
static_assert(std::is_trivially_copyable_v<S>);
static_assert(!std::is_default_constructible_v<S>);
S op(S a,S b) { return S(a.x+b.x); }
S e() { return S(0); }
int main(){segtree<S,op,e> t(4);t.set(2,S(9));t.transform(1,[](const S&v){return S(v.x+3);});return t.all_prod().x!=12;}
