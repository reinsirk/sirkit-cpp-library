from pathlib import Path
import json,hashlib,zipfile,subprocess,statistics,re
R=Path.cwd();D=Path('/tmp/sirkit_segtree_third_20261102');O=Path('/tmp/sirkit_segtree_followup_20261102')
def load(name):return json.loads((D/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rs=load('selected_raw.json');assert len(rs)==2*34*11*3
summary=[]
for cc in ['gcc','clang']:
 for name in sorted({r['case'] for r in rs}):
  groups={l:[r for r in rs if r['compiler']==cc and r['case']==name and r['label']==l] for l in ['old','control','selected']}
  assert all(len(v)==11 for v in groups.values());assert len({x['sha256'] for v in groups.values() for x in v})==1
  med={l:statistics.median(x['cpu_ns'] for x in v)/1e6 for l,v in groups.items()}
  summary.append({'compiler':cc,'case':name,'repetitions':11,'median_cpu_ms':med,'selected_ratio':med['selected']/med['old'],'control_ratio':med['control']/med['old'],'min_max_cpu_ms':{l:[min(x['cpu_ns'] for x in v)/1e6,max(x['cpu_ns'] for x in v)/1e6] for l,v in groups.items()}})
(D/'selected_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
meta=[]
for id in ['segment_tree','segment_tree_composite']:
 driver=R/'Verify/current/drivers'/(id+'_main.cpp');assert driver.read_bytes()==(D/(id+'_main.cpp')).read_bytes()
 p=R/'Verify/current/submissions'/(id+'.cpp');meta.append({'id':id,'driver_sha256':sha(driver),'submission':p.relative_to(R).as_posix(),'submission_sha256':sha(p),'bytes':p.stat().st_size})
assert sha(R/'Verify/current/common/fast_io.hpp')==(D/'io_hash.txt').read_text().strip()
norm=lambda x:re.sub(r'\s+','',re.sub(r'//[^\n]*','',x));assert norm((D/'selected.hpp').read_text())==norm((R/'DataStructure/Segment_Tree.cpp').read_text())
report={
 'date_jst':'2026-11-02','scope':'通常版segtreeの点更新。main・共通I/O・公開API・所有権・区間積の走査は維持。',
 'baseline':{'source_sha256':sha(D/'before.hpp'),'online_evidence':'Audit/online-segtree-414719-414720-2026-11-02.json','segment_tree_ms':69,'segment_tree_composite_ms':109,'note':'このACは改修前の本体のみ。現在の2本は要再提出。'},
 'current':{'source':'DataStructure/Segment_Tree.cpp','source_sha256':sha(R/'DataStructure/Segment_Tree.cpp'),'measured_candidate_sha256':sha(D/'selected.hpp'),'same_implementation_except_comments_and_whitespace':True,'submissions':meta,'io_sha256':sha(R/'Verify/current/common/fast_io.hpp')},
 'implementation':{'changes':['16バイト以下のtrivially copyableでコピー構築/コピー代入が可能なSと、const参照同士でも呼べるopには、直前の積を保持して兄弟だけ読み次の親を計算する。','親の左右の位置に応じて値のオペランドを選ぶ。非可換演算の順序・親ごとの演算回数は同じ。','追加の型要件を満たさない場合は両方の子を読み直す旧ループを維持。','ローカル値の構築元・代入元をconst参照にする。mutable overloadがdeleteの型にも対応する。','Clangの8バイト超の値型に限り、更新の呼び出しに[[clang::noinline]]を付け、呼び出し側の肥大化による照会の退行を抑える。GCCでは標準C++23の経路。'],'complexity':'点更新O(log(n+1))、走査用追加領域O(1)。木の容量・構築・区間積・境界探索の計算量は同じ。','extensions':'Clang専用のインライン抑止属性のみ。プリプロセッサで他コンパイラから除外する。新しいSIMD/ISA要件はなし。','not_adopted':['親の左右でif分岐するcarryは、Affineで最大約15%遅れたため棄却。','全型へ単純に適用するとコピー代入delete等の既存対応型がコンパイル失敗するため棄却。','Clangで16バイト型の更新をインライン展開する案は、照会中心で約5〜8%遅れるため棄却。']},
 'measurement':{'CPU':'Intel Core i9-14900K, CPU12 / physical P-Core6。SMT sibling13で同時測定なし。E-Coreでは測定せず。','governor':'powersave、周波数は固定せず','compilers':{'gcc':subprocess.check_output(['/usr/bin/g++','--version'],text=True).splitlines()[0],'clang':subprocess.check_output(['/usr/bin/clang++','--version'],text=True).splitlines()[0]},'flags':['-std=c++23','-O2','SKIP_RUNTIME_CHECKSは提出コード先頭で定義'],'clang_extra':'--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','no_march_native':True,'metric':'同じmain・共通I/Oで実行したプロセスCPU時間(user+system)の中央値。構築と入出力を含む。','protocol':'各実行を同じファイル名へコピーし、old/control/selectedの実行順を固定seedでランダム化。controlはoldと同一バイナリ。出力SHA一致。CPU12でほかの性能試験を並行実行しない。','repetitions':11,'official_inputs':json.loads((O/'official_inputs_metadata.json').read_text()),'custom_inputs':json.loads((O/'custom_inputs_metadata.json').read_text()),'summary':summary,'limitations':['公式現行生成器とseedで生成した数値入力を使う。オンラインの保存入力・実行機との一致は断定しない。','構築・入出力を含む全体の比率であり、点更新関数単体の比率ではない。','小規模Affine混在ではGCC約1.1%、Clang約1.5%の遅れが残る。一部controlも約1〜2%動く。すべての値型・演算・条件での無退行は主張しない。']},
 'validation':{'normal_api_reference_allocation':load('final_api_tests.json'),'derived_api':load('profile_api_tests.json'),'profile_samples':json.loads((D/'profiles/checkpoint.json').read_text()),'deleted_overload_type_review':load('carry_type_review.json'),'new_regression_test':load('selected_type_tests.json'),'standard_fallback':load('standard_fallback_tests.json'),'source_placement':'106ソースのAPI配置・130件のDocumentリンク確認済み。','generators':'通常227件、派生802件の提出コード照合済み。'},
 'evidence_zip':'Audit/data/segtree-carried-update-2026-11-02.zip','license':'実装・独立テストは自作CC0。公式生成器のApache-2.0ソースは入力生成にのみ使用し、ここにはソースのURL/SHAと生成した数値入力のSHAを記録する。原典ソースを配布ZIP・証拠ZIPへ収録しない。',
 'resubmission_required':[x['submission'] for x in meta]}
path=R/'Audit/performance-segtree-carried-update-2026-11-02.json';path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
files=[p for p in D.iterdir() if p.is_file() and p.suffix in ['.py','.cpp','.hpp','.json','.md','.log']]
with zipfile.ZipFile(R/report['evidence_zip'],'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,p.name)
 for p in sorted((D/'profiles/runs').glob('*.json')):z.write(p,'profile_runs/'+p.name)
 z.write(R/'Verify/current/tests/segment_tree_carried_types_test.cpp','tests/segment_tree_carried_types_test.cpp')
print(path,'rows',len(rs),'evidence files',len(files))
