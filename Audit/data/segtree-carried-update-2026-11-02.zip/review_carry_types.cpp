#include SOURCE
#include <type_traits>
struct S {
 int x;
 explicit S(int v):x(v) {}
#if CASE == 3
 S(S&)=delete;
#endif
 S(const S&)=default;
 S(S&&)=default;
#if CASE == 1
 S& operator=(const S&)=delete;
#else
 S& operator=(const S&)=default;
#endif
#if CASE == 2
 S& operator=(S&)=delete;
#endif
 S& operator=(S&&)=default;
};
static_assert(std::is_trivially_copyable_v<S>);
static_assert(!std::is_default_constructible_v<S>);
#if CASE == 4
struct Op {
 S operator()(S&&a,S&&b)const{return S(a.x+b.x);}
 S operator()(S&a,S&b)const{return S(a.x+b.x);}
 S operator()(const S&,const S&)const=delete;
};
constexpr auto op=Op{};
#elif CASE == 3
S op(const S& a,const S& b) { return S(a.x+b.x); }
#else
S op(S a,S b) { return S(a.x+b.x); }
#endif
S e() { return S(0); }
int main(){segtree<S,op,e> t(4);t.set(2,S(9));t.transform(1,[](const S&v){return S(v.x+3);});return t.all_prod().x!=12;}
