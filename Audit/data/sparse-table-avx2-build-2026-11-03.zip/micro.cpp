#ifndef SIRKIT_SPARSE_TEST_SOURCE
#define SIRKIT_SPARSE_TEST_SOURCE "/home/reinsirk/Atcoder_Env/DataStructure/Sparse_Table.cpp"
#endif
#include SIRKIT_SPARSE_TEST_SOURCE
#include <cstdint>
#include <cinttypes>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <limits>
#include <numeric>
#include <random>
#include <string>
struct Min32 { std::int32_t operator()(std::int32_t a,std::int32_t b) const {return a<b?a:b;} };
struct Gcd32 { std::uint32_t operator()(std::uint32_t a,std::uint32_t b) const {return std::gcd(a,b);} };
struct First32 { std::uint32_t operator()(std::uint32_t a,std::uint32_t b) const {return a?a:b;} };
struct Gcd64 { std::uint64_t operator()(std::uint64_t a,std::uint64_t b) const {return std::gcd(a,b);} };
struct First64 { std::uint64_t operator()(std::uint64_t a,std::uint64_t b) const {return a?a:b;} };
template<class T,class Op> int run(std::size_t n,const std::string&mode,int repeats,T identity){
 std::mt19937_64 random(582783+n);std::vector<T>a(n);for(auto&v:a)v=T(random()%1000000+1);
 std::vector<std::pair<std::size_t,std::size_t>>queries;
 if(mode!="build") {queries.reserve(1000000);for(int i=0;i<1000000;++i){auto l=random()%n;auto r=mode=="short"?std::min(n,l+1+random()%100):l+1+random()%(n-l);queries.emplace_back(l,r);}}
 std::uint64_t checksum=0;auto start=std::clock();
 if(mode=="build"){
  for(int rep=0;rep<repeats;++rep){SparseTable<T,Op> tree(a,identity);checksum+=std::uint64_t(tree.prod(n/3,n));}
 }else{
  SparseTable<T,Op> tree(a,identity);auto built=std::clock();
  for(auto[l,r]:queries)checksum+=std::uint64_t(tree.prod(l,r));
  auto end=std::clock();std::printf("%" PRIu64 " %" PRId64 " %" PRId64 "\n",checksum,std::int64_t(built-start)*1000000000/CLOCKS_PER_SEC,std::int64_t(end-built)*1000000000/CLOCKS_PER_SEC);return 0;
 }
 auto end=std::clock();std::printf("%" PRIu64 " %" PRId64 " 0\n",checksum,std::int64_t(end-start)*1000000000/CLOCKS_PER_SEC);return 0;
}
int main(int argc,char**argv){if(argc!=5)return 1;auto n=std::strtoull(argv[1],nullptr,10);std::string mode=argv[2],type=argv[4];int reps=std::atoi(argv[3]);if(type=="min")return run<std::int32_t,Min32>(n,mode,reps,std::numeric_limits<std::int32_t>::max());if(type=="gcd32")return run<std::uint32_t,Gcd32>(n,mode,reps,0);if(type=="first32")return run<std::uint32_t,First32>(n,mode,reps,0);if(type=="gcd")return run<std::uint64_t,Gcd64>(n,mode,reps,0);return run<std::uint64_t,First64>(n,mode,reps,0);}
