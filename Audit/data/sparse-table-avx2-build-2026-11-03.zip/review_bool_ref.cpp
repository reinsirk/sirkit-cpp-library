// SPDX-License-Identifier: CC0-1.0
#ifndef SIRKIT_SPARSE_TEST_SOURCE
#define SIRKIT_SPARSE_TEST_SOURCE "/home/reinsirk/Atcoder_Env/DataStructure/Sparse_Table.cpp"
#endif
#include SIRKIT_SPARSE_TEST_SOURCE
#include <cstdio>
#include <cstdlib>
#include <type_traits>
struct RvalueAnd {
    bool operator()(bool&& a,bool&& b)const{return a&&b;}
    bool operator()(const bool&,const bool&)const=delete;
};
int main(){
    static_assert(!std::is_invocable_v<RvalueAnd&,const bool&,const bool&>);
    static_assert(std::is_invocable_v<RvalueAnd&,bool,bool>);
    std::vector<bool>a{true,false,true,true,false};SparseTable<bool,RvalueAnd> t(a,true);
    for(std::size_t l=0;l<=a.size();++l){bool expected=true;for(auto r=l;r<=a.size();++r){if(t.prod(l,r)!=expected)std::abort();if(r<a.size())expected=expected&&a[r];}}
    puts("bool proxy overload: PASS");
}
