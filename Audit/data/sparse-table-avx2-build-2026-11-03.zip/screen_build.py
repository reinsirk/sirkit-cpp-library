from pathlib import Path
import sys,subprocess,json,random,statistics,shutil,os,time,hashlib
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_sparse_speed_20261103');s=(D/'before.hpp').read_text();old='''            std::vector<T> row;
            row.reserve(count);
            const auto& previous = table_.back();
            for (std::size_t i = 0; i < count; ++i) row.emplace_back(op_(previous[i], previous[i + half]));''';assert old in s
head='''            std::vector<T> row;
            const auto& previous = table_.back();
            using Result = decltype(op_(previous[std::size_t{}], previous[std::size_t{}]));
            if constexpr (!std::is_same_v<T, bool> && std::is_trivially_copyable_v<T> &&
                          std::is_trivially_constructible_v<T, const T&> &&
                          std::is_trivially_constructible_v<T, Result> &&
                          std::is_trivially_assignable_v<T&, T> &&
                          std::is_same_v<std::remove_cvref_t<Result>, T>) {
'''
tail='''            } else {
                row.reserve(count);
                for (std::size_t i = 0; i < count; ++i) row.emplace_back(op_(previous[i], previous[i + half]));
            }'''
forms={
'filled':'''                row = std::vector<T>(count, identity_);
                for (std::size_t i = 0; i < count; ++i) row[i] = T(op_(previous[i], previous[i + half]));
''',
'pointers':'''                row = std::vector<T>(count, identity_);
                const T* left = previous.data();
                const T* right = left + half;
                T* target = row.data();
                for (std::size_t i = 0; i < count; ++i) target[i] = T(op_(left[i], right[i]));
''',
'unroll4':'''                row = std::vector<T>(count, identity_);
                const T* left = previous.data();
                const T* right = left + half;
                T* target = row.data();
                const auto bulk = count - count % 4;
                std::size_t i = 0;
                for (; i < bulk; i += 4) {
                    target[i] = T(op_(left[i], right[i]));
                    target[i + 1] = T(op_(left[i + 1], right[i + 1]));
                    target[i + 2] = T(op_(left[i + 2], right[i + 2]));
                    target[i + 3] = T(op_(left[i + 3], right[i + 3]));
                }
                for (; i < count; ++i) target[i] = T(op_(left[i], right[i]));
''',
'copied':'''                row = std::vector<T>(previous.begin(), previous.begin() + count);
                for (std::size_t i = 0; i < count; ++i) row[i] = T(op_(std::as_const(row)[i], previous[i + half]));
'''}
variants={'old':s}
for label,body in forms.items():variants[label]=s.replace(old,head+body+tail)
e=next(e for e in prepare_verify.collect() if e['id']=='sparse_table')
for label,source in variants.items():
 (D/f'{label}.hpp').write_text(source);data,_=prepare_verify.render(e,source_overrides={'DataStructure/Sparse_Table.cpp':source.encode()});src=D/f'{label}.cpp';src.write_bytes(data)
 for cc,cmd0 in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:subprocess.run(['taskset','-c','2',*cmd0,'-std=c++23','-O2',str(src),'-o',str(D/f'{cc}_{label}')],check=True)
G=D/'official_generator';cases=[]
for family,seeds in [('random',[0,2]),('max_random',[0,1]),('small_width_query',[0,3]),('small_values',[0])]:
 exe=G/('generator_'+family);subprocess.run(['taskset','-c','2','/usr/bin/g++','-std=c++23','-O2','-I',str(G),str(G/(family+'.cpp')),'-o',str(exe)],check=True)
 for seed in seeds:
  p=D/f'official_{family}_{seed}.in'
  with p.open('wb') as f:subprocess.run([str(exe),str(seed)],stdout=f,check=True)
  cases.append({'name':p.stem,'path':str(p)})
for n,q in [(32,200000),(4096,300000),(500000,500000)]:
 for mode in ['random','short','build']:
  query_count=1 if mode=='build' else q;p=D/f'input_{n}_{mode}.in';rng=random.Random(51732+n)
  with p.open('w') as f:
   f.write(f'{n} {query_count}\n');f.write(' '.join(str(rng.randrange(1000000001)) for _ in range(n))+'\n')
   for i in range(query_count):
    l=rng.randrange(n);r=min(n,l+rng.randrange(1,101)) if mode=='short' else rng.randrange(l+1,n+1);f.write(f'{l} {r}\n')
  cases.append({'name':f'{n}_{mode}','path':str(p)})
meta=json.loads((D/'official_metadata.json').read_text());meta['inputs']=[{'file':Path(c['path']).name,'header':Path(c['path']).open().readline().strip(),'sha256':hashlib.sha256(Path(c['path']).read_bytes()).hexdigest()} for c in cases];(D/'official_metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
print('BUILT AND INPUTS READY',flush=True);rs=[];rng=random.Random(861023)
for cc in ['gcc','clang']:
 for c in cases:
  for rep in range(7):
   labels=list(variants)+['control'];rng.shuffle(labels);checks=[]
   for label in labels:
    shutil.copyfile(D/f'{cc}_{"old" if label=="control" else label}',D/'active');(D/'active').chmod(0o700)
    with open(c['path'],'rb') as inp,open(D/'output','wb') as out:
     t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-t
    ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rs.append({'compiler':cc,'case':c['name'],'rep':rep,'label':label,'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
   assert len(set(checks))==1
  ms={l:statistics.median(x['cpu_ns'] for x in rs if x['compiler']==cc and x['case']==c['name'] and x['label']==l) for l in labels};print(cc,c['name'],{l:round(v/ms['old'],3) for l,v in ms.items()},flush=True);(D/'build_raw.json').write_text(json.dumps(rs))
