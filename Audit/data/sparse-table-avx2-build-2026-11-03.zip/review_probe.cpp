// SPDX-License-Identifier: CC0-1.0
#ifndef SIRKIT_SPARSE_TEST_SOURCE
#define SIRKIT_SPARSE_TEST_SOURCE "/home/reinsirk/Atcoder_Env/DataStructure/Sparse_Table.cpp"
#endif
#include SIRKIT_SPARSE_TEST_SOURCE
#include <cstdio>
#include <limits>
#include <string>
#include <type_traits>

#if CASE == 1
class Value {
    Value()=default;
public:
    int value;
    explicit Value(int x):value(x){}
    Value(const Value&)=default;
    Value& operator=(const Value&)=default;
    friend void swap(Value& a,Value& b)noexcept {std::swap(a.value,b.value);}
};
#elif CASE == 2
struct Value {
    int value;
    Value()=default;
    explicit Value(int x):value(x){}
    Value(const Value&)=default;
    Value& operator=(const Value&)=default;
    template<class U> requires std::is_same_v<std::remove_cvref_t<U>,Value>
    Value& operator=(U&& other){value=other.value+100000;return *this;}
    friend void swap(Value& a,Value& b)noexcept {std::swap(a.value,b.value);}
};
#elif CASE == 3
struct Value {
    int value;
    Value()=default;
    explicit Value(int x):value(x){}
    Value(const Value&)=default;
    Value(Value&&)=delete;
    Value& operator=(const Value&)=default;
    Value& operator=(Value&&)=default;
    friend void swap(Value& a,Value& b)noexcept {std::swap(a.value,b.value);}
};
#elif CASE == 4
struct Value {
    int value;
    Value()=delete;
    explicit Value(int x):value(x){}
    friend void swap(Value& a,Value& b)noexcept {std::swap(a.value,b.value);}
};
#elif CASE == 5
struct Value {
    static inline int forwarded=0;
    int value;
    Value()=default;
    explicit Value(int x):value(x){}
    Value(const Value&)=default;
    Value& operator=(const Value&)=default;
    template<class U> requires std::is_same_v<std::remove_cvref_t<U>,Value>
    Value(U&& other):value(other.value){++forwarded;}
    friend void swap(Value& a,Value& b)noexcept {std::swap(a.value,b.value);}
};
#elif CASE == 6
struct Result { int value; };
struct Value {
    int value;
    Value()=default;
    explicit Value(int x):value(x){}
    explicit Value(Result x):value(x.value){}
    friend void swap(Value& a,Value& b)noexcept {std::swap(a.value,b.value);}
};
#elif CASE == 7
struct Value {
    int value;
    std::string owned;
    Value()=delete;
    explicit Value(int x):value(x),owned(std::to_string(x)){}
    friend void swap(Value& a,Value& b)noexcept {std::swap(a.value,b.value);a.owned.swap(b.owned);}
};
#elif CASE == 8
struct Value {
    int value;
    Value()=default;
    explicit Value(int x):value(x){}
    Value(const Value&)=default;
    Value(Value&&)=default;
    Value& operator=(const Value&)=delete;
    Value& operator=(Value&&)=default;
    friend void swap(Value& a,Value& b)noexcept {std::swap(a.value,b.value);}
};
#elif CASE == 9
struct Value {
    int value;
    Value()=default;
    explicit Value(int x):value(x){}
    Value(Value&)=delete;
    Value(const Value&)=default;
    Value(Value&&)=default;
    Value& operator=(const Value&)=default;
    Value& operator=(Value&&)=default;
    friend void swap(Value& a,Value& b)noexcept {std::swap(a.value,b.value);}
};
#endif
struct Minimum {
#if CASE == 6
    Result operator()(const Value& a,const Value& b) {return {a.value<b.value?a.value:b.value};}
    Value operator()(const Value& a,const Value& b)const{return Value(a.value<b.value?a.value:b.value);}
#elif CASE == 3 || CASE == 9
    const Value& operator()(const Value& a,const Value& b)const{return a.value<b.value?a:b;}
#else
    Value operator()(const Value& a,const Value& b)const{return Value(a.value<b.value?a.value:b.value);}
#endif
};
int main(){
    std::printf("traits trivial=%d default=%d copy_assign=%d rvalue_assign_trivial=%d move_construct=%d\n",int(std::is_trivial_v<Value>),int(std::is_trivially_default_constructible_v<Value>),int(std::is_trivially_copy_assignable_v<Value>),int(std::is_trivially_assignable_v<Value&,Value>),int(std::is_move_constructible_v<Value>));
    std::vector<Value> a;a.reserve(5);for(int x:{4,2,7,1,8})a.emplace_back(x);
    SparseTable<Value,Minimum> table(a,Value(std::numeric_limits<int>::max()));
    for(std::size_t l=0;l<=a.size();++l){int expected=std::numeric_limits<int>::max();for(auto r=l;r<=a.size();++r){if(table.prod(l,r).value!=expected)return 3;if(r<a.size())expected=std::min(expected,a[r].value);}}
    if(table.values().size()!=5)return 4;
    SparseTable<Value,Minimum> copied=table;copied.assign(a);if(copied.prod(1,4).value!=1)return 5;
#if CASE == 5
    std::printf("forwarding_constructor_calls=%d\n",Value::forwarded);
#endif
    puts("PASS");
}
