from pathlib import Path
import subprocess,json,hashlib,os,resource,signal
D=Path('/tmp/sirkit_sparse_speed_20261103');R=Path.cwd();source=D/'review_final_snapshot.hpp';source.write_bytes((R/'DataStructure/Sparse_Table.cpp').read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[];checks=[]
report={'source_path':'DataStructure/Sparse_Table.cpp','source_sha256':sha(source),'snapshot':str(source),'performance_measurement':False,'affinity':2,'runs':rows,'preprocessor':checks}
def save():
 (D/'final_type_dispatch_tests.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for cc,cmd0 in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for disable in [False,True]:
  for case in list(range(1,10))+[None]:
   name='review_probe' if case is not None else 'review_bool_ref';src=D/(name+'.cpp');exe=D/f'finalreview_{cc}_{disable}_{case}';cmd=['taskset','-c','2',*cmd0,'-std=c++23','-O2','-fsanitize=address,undefined','-fno-omit-frame-pointer',f'-DSIRKIT_SPARSE_TEST_SOURCE="{source}"']
   if disable:cmd+=['-DSIRKIT_DISABLE_SIMD']
   if case is not None:cmd+=[f'-DCASE={case}']
   cmd+=[str(src),'-o',str(exe)];c=subprocess.run(cmd,capture_output=True,text=True);p=None
   if c.returncode==0:p=subprocess.run(['taskset','-c','2',str(exe)],capture_output=True,text=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0'))
   row={'compiler':cc,'disable_simd':disable,'case':case,'test':name,'command':cmd,'compile_returncode':c.returncode,'compile_stderr':c.stderr,'run_returncode':None if p is None else p.returncode,'stdout':None if p is None else p.stdout,'stderr':None if p is None else p.stderr,'test_sha256':sha(src)};rows.append(row);save();print(cc,disable,name,case,c.returncode,None if p is None else p.returncode,flush=True);assert c.returncode==0 and p.returncode==0,(c.stderr,None if p is None else p.stderr)
 cmd=['taskset','-c','2',*cmd0,'-std=c++23','-E','-P','-DSIRKIT_DISABLE_SIMD',f'-DSIRKIT_SPARSE_TEST_SOURCE="{source}"',str(R/'Verify/current/tests/sparse_table_simd_test.cpp')];p=subprocess.run(cmd,capture_output=True,text=True,check=True);tokens={s:p.stdout.count(s) for s in ['fill_row_avx2','supports_avx2','__builtin_cpu_init','__builtin_cpu_supports']};assert all(v==0 for v in tokens.values());checks.append({'compiler':cc,'command':cmd,'excluded_token_counts':tokens,'preprocessed_sha256':hashlib.sha256(p.stdout.encode()).hexdigest(),'status':'PASS'});save()
s=source.read_text().replace('#include <algorithm>','#include <algorithm>\n#include <cstdlib>');a=s.index('    static void fill_row_avx2(');b=s.index('    static bool supports_avx2()',a);s=s[:a]+'''    static void fill_row_avx2(T*, const T*, const T*, std::size_t, Op&) {
        std::abort();
    }
'''+s[b:];a=s.index('    static bool supports_avx2()');b=s.index('\n#endif',a);s=s[:a]+'''    static bool supports_avx2() noexcept {
        return std::getenv("SIRKIT_TEST_CPU_NO_AVX2") == nullptr;
    }
'''+s[b:];sim=D/'review_runtime_no_avx2.hpp';sim.write_text(s);report['runtime_unsupported_simulation']={'mock_source':str(sim),'mock_sha256':sha(sim),'actual_unsupported_hardware':False,'method':'getenv結果によるruntime分岐でCPU対応判定falseを強制し、専用kernelをabortへ置換。実CPU非対応機での試験ではない。','runs':[]};save()
def no_core():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
for cc,cmd0 in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  src=R/'Verify/current/tests/sparse_table_simd_test.cpp';exe=D/f'noavx_sim_{cc}_{skip}';cmd=['taskset','-c','2',*cmd0,'-std=c++23','-O2','-fsanitize=address,undefined','-fno-omit-frame-pointer',f'-DSIRKIT_SPARSE_TEST_SOURCE="{sim}"']
  if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
  cmd+=[str(src),'-o',str(exe)];c=subprocess.run(cmd,capture_output=True,text=True);assert c.returncode==0,c.stderr
  env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',SIRKIT_TEST_CPU_NO_AVX2='1');p=subprocess.run(['taskset','-c','2',str(exe)],capture_output=True,text=True,env=env,preexec_fn=no_core,cwd=D);assert p.returncode==0,p.stderr
  env.pop('SIRKIT_TEST_CPU_NO_AVX2');positive=subprocess.run(['taskset','-c','2',str(exe)],capture_output=True,text=True,env=env,preexec_fn=no_core,cwd=D);assert positive.returncode==-signal.SIGABRT,(positive.returncode,positive.stdout,positive.stderr)
  report['runtime_unsupported_simulation']['runs'].append({'compiler':cc,'skip':skip,'command':cmd,'compile_stderr':c.stderr,'mock_cpu_false_env':{'SIRKIT_TEST_CPU_NO_AVX2':'1'},'false_returncode':p.returncode,'false_stdout':p.stdout,'false_stderr':p.stderr,'positive_control_env':'SIRKIT_TEST_CPU_NO_AVX2 unset => supports true => kernel trap','positive_returncode':positive.returncode,'positive_stderr':positive.stderr,'test_sha256':sha(src),'status':'PASS'});save();print(cc,skip,'runtime false PASS; positive kernel trap SIGABRT',flush=True)
report['source_unchanged_at_end']=sha(R/'DataStructure/Sparse_Table.cpp')==report['source_sha256'];report['status']='PASS';save();print('final type/dispatch review completed',flush=True)
