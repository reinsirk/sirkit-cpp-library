from pathlib import Path
import sys,subprocess,json,random,statistics,shutil,os,time,hashlib
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_sparse_speed_20261103');e=next(e for e in prepare_verify.collect() if e['id']=='sparse_table');variants={'old':(D/'before.hpp').read_text(),'direct':(D/'direct.hpp').read_text()};variants['disabled']='#define SIRKIT_DISABLE_SIMD\n'+variants['direct']
for label,source in variants.items():
 data,_=prepare_verify.render(e,source_overrides={'DataStructure/Sparse_Table.cpp':source.encode()});src=D/f'final_{label}.cpp';src.write_bytes(data)
 for cc,cmd0 in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  subprocess.run(['taskset','-c','2',*cmd0,'-std=c++23','-O2',str(src),'-o',str(D/f'final_{cc}_{label}')],check=True)
  cmd=['taskset','-c','2',*cmd0,'-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_SPARSE_TEST_SOURCE="{D/("before.hpp" if label=="old" else "direct.hpp")}"']
  if label=='disabled':cmd+=['-DSIRKIT_DISABLE_SIMD']
  subprocess.run(cmd+[str(D/'micro.cpp'),'-o',str(D/f'final_micro_{cc}_{label}')],check=True,capture_output=True)
print('BUILT',flush=True);rng=random.Random(831702);mr=[]
for cc in ['gcc','clang']:
 for ty in ['min','gcd32','first32','gcd','first']:
  for n,repeats in [(32,20000),(4096,150),(500000,3)]:
   for rep in range(7):
    labels=['old','control','direct','disabled'];rng.shuffle(labels);checks=[]
    for label in labels:
     shutil.copyfile(D/f'final_micro_{cc}_{"old" if label=="control" else label}',D/'active_final_micro');(D/'active_final_micro').chmod(0o700);p=subprocess.run(['taskset','-c','12',str(D/'active_final_micro'),str(n),'build',str(repeats),ty],check=True,capture_output=True,text=True);c,b,q=map(int,p.stdout.split());checks.append(c);mr.append({'compiler':cc,'type':ty,'n':n,'rep':rep,'label':label,'checksum':c,'build_cpu_ns':b,'repeated_constructions':repeats})
    assert len(set(checks))==1
   m={l:statistics.median(x['build_cpu_ns'] for x in mr if x['compiler']==cc and x['type']==ty and x['n']==n and x['label']==l) for l in labels};print('MICRO',cc,ty,n,{l:round(v/m['old'],3) for l,v in m.items()},flush=True);(D/'final_micro_raw.json').write_text(json.dumps(mr))
cases=[];G=D/'official_generator'
for family,count in [('random',5),('max_random',5),('small_width_query',5),('small_values',1)]:
 for seed in range(count):
  p=D/f'official_{family}_{seed}.in'
  if not p.exists():
   with p.open('wb') as f:subprocess.run([str(G/('generator_'+family)),str(seed)],stdout=f,check=True)
  cases.append({'name':p.stem,'path':str(p)})
for n in [32,4096,500000]:
 for mode in ['random','short','build']:cases.append({'name':f'{n}_{mode}','path':str(D/f'input_{n}_{mode}.in')})
meta=json.loads((D/'official_metadata.json').read_text());meta['inputs']=[{'file':Path(c['path']).name,'sha256':hashlib.sha256(Path(c['path']).read_bytes()).hexdigest(),'header':Path(c['path']).open().readline().strip()} for c in cases];(D/'official_metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
print('FULL MAIN BENCH',flush=True);rs=[]
for cc in ['gcc','clang']:
 for c in cases:
  for rep in range(11):
   labels=['old','control','direct','disabled'];rng.shuffle(labels);checks=[]
   for label in labels:
    shutil.copyfile(D/f'final_{cc}_{"old" if label=="control" else label}',D/'active_final');(D/'active_final').chmod(0o700)
    with open(c['path'],'rb') as inp,open(D/'output','wb') as out:
     t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active_final')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-t
    ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rs.append({'compiler':cc,'case':c['name'],'rep':rep,'label':label,'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
   assert len(set(checks))==1
  m={l:statistics.median(x['cpu_ns'] for x in rs if x['compiler']==cc and x['case']==c['name'] and x['label']==l) for l in labels};print(cc,c['name'],{l:round(v/m['old'],3) for l,v in m.items()},flush=True);(D/'final_raw.json').write_text(json.dumps(rs))
