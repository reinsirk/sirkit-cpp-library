from pathlib import Path
import subprocess,json,os,hashlib
R=Path.cwd();D=Path('/tmp/sirkit_sparse_speed_20261103');rs=[]
for prefix,cmd0 in [('Variants/GCC',['/usr/bin/g++']),('Variants/Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']),('Fast/GCC',['/usr/bin/g++']),('Fast/Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for simd in [True,False]:
  src=R/prefix/'DataStructure/Sparse_Table.cpp';exe=D/(prefix.replace('/','_')+f'_simd_{simd}');cmd=['taskset','-c','6',*cmd0,'-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_SPARSE_TEST_SOURCE="{src}"']
  if not simd:cmd+=['-DSIRKIT_DISABLE_SIMD']
  cmd+=[str(R/'Verify/current/tests/sparse_table_simd_test.cpp'),'-o',str(exe)];subprocess.run(cmd,check=True,capture_output=True);p=subprocess.run(['taskset','-c','6',str(exe)],capture_output=True,text=True);assert p.returncode==0,(prefix,simd,p.stderr);rs.append({'profile':prefix,'simd_enabled':simd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'command':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr});print(prefix,simd,p.stdout.strip(),flush=True)
(D/'profile_simd_tests.json').write_text(json.dumps(rs,ensure_ascii=False,indent=2)+'\n')
