from pathlib import Path
import subprocess,json,os,hashlib
R=Path.cwd();D=Path('/tmp/sirkit_sparse_speed_20261103');rs=[]
for cc,cmd0 in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for simd in [True,False]:
  for skip in [False,True]:
   for name in ['static_tables_reference_test','sparse_table_simd_test','range_structures_allocation_test']:
    src=R/'Verify/current/tests'/(name+'.cpp');exe=D/f'final_test_{cc}_{name}_{simd}_{skip}';cmd=['taskset','-c','4',*cmd0,'-std=c++23','-O2']
    if name!='range_structures_allocation_test':cmd+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
    if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
    if not simd:cmd+=['-DSIRKIT_DISABLE_SIMD']
    cmd+=[str(src),'-o',str(exe)];subprocess.run(cmd,check=True,capture_output=True);p=subprocess.run(['taskset','-c','4',str(exe)],env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0'),capture_output=True,text=True);rs.append({'compiler':cc,'simd_enabled':simd,'skip':skip,'test':name,'test_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'command':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr});(D/'final_tests.json').write_text(json.dumps(rs,ensure_ascii=False,indent=2)+'\n');print(cc,simd,skip,name,p.returncode,p.stdout.strip(),flush=True);assert p.returncode==0
