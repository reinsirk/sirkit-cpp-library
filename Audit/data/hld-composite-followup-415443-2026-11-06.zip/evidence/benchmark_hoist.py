# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,os,json,fcntl,random,statistics,shutil,hashlib,sys
D=Path('/tmp/sirkit_hld_415443');F=Path('/tmp/sirkit_hld_opt_20261105/fixtures');fs={x['name']:x for x in json.loads((F/'fixtures.json').read_text())};raw=[];rng=random.Random(2026110603)
names=['official_vertex_set_path_composite_max_random_0','official_vertex_set_path_composite_worst_for_path_decomposition_0','official_vertex_set_path_composite_line_0','custom_vertex_set_path_composite_250000_random','custom_vertex_set_path_composite_32_random_queryheavy','custom_vertex_set_path_composite_4096_random_queryheavy']
if '--full' in sys.argv:names+=['official_vertex_set_path_composite_max_random_1','official_vertex_set_path_composite_almost_line_0','official_vertex_set_path_composite_long-path-decomposition_killer_0','custom_vertex_set_path_composite_250000_balanced','custom_vertex_set_path_composite_250000_star','custom_vertex_set_path_composite_32_chain_queryheavy']
reps=7 if '--full' in sys.argv else 3;stem='hoist_full' if '--full' in sys.argv else 'hoist_screen'
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc']:
  for case in names:
   Path(fs[case]['path']).read_bytes()
   for rep in range(reps):
    labels=['base','control','hoist'];rng.shuffle(labels)
    for label in labels:
     shutil.copyfile(D/f'{cc}_{"base"if label=="control"else label}',D/'active');(D/'active').chmod(0o700)
     cmd=['setarch','x86_64','-R','taskset','-c','12',str(D/'active')]
     with Path(fs[case]['path']).open('rb')as fi,(D/'output').open('wb')as fo:
      p=subprocess.Popen(cmd,stdin=fi,stdout=fo);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0
     h=hashlib.sha256((D/'output').read_bytes()).hexdigest()
     if fs[case].get('expected_sha256'):assert h==fs[case]['expected_sha256']
     raw.append(dict(compiler=cc,case=case,rep=rep,label=label,cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),rss_bytes=ru.ru_maxrss*1024,output_sha256=h))
   rr=[x for x in raw if x['compiler']==cc and x['case']==case];assert len({x['output_sha256']for x in rr})==1;m={l:statistics.median(x['cpu_ns']for x in rr if x['label']==l)for l in labels};print(cc,case,'ratio',round(m['hoist']/m['base'],4),'control',round(m['control']/m['base'],4),'ms',round(m['base']/1e6,2),round(m['hoist']/1e6,2),flush=True);(D/f'{stem}_raw.json').write_text(json.dumps(raw))
print(stem,'complete',len(raw),flush=True)
