# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,statistics,sys,datetime
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_415443');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for p in ['Graph/Heavy_Light_Decomposition.cpp','DataStructure/Segment_Tree.cpp','DataStructure/Fenwick_Tree.cpp','Verify/current/drivers/hld_path_composite_main.cpp','Verify/current/common/fast_io.hpp']:
 assert(R/p).read_bytes()==(D/'before'/p).read_bytes();rows.append(dict(path=p,sha256=sha(R/p),unchanged=True))
summary=[];rawcount=0
for file,label,scope in [('screen_raw.json','short','singleton exploratory GCC/Clang'),('full_raw.json','short','singleton Clang repeat'),('hoist_screen_raw.json','hoist','GCC parent-load exploratory')]:
 data=json.loads((D/file).read_text());rawcount+=len(data)
 for cc,case in sorted({(x['compiler'],x['case'])for x in data}):
  rr=[x for x in data if(x['compiler'],x['case'])==(cc,case)];assert len({x['output_sha256']for x in rr})==1;m={l:statistics.median(x['cpu_ns']for x in rr if x['label']==l)for l in ['base','control',label]};base=statistics.median(x['cpu_ns']for x in rr if x['label']!=label);summary.append(dict(scope=scope,compiler=cc,case=case,median_cpu_ns=m,baseline_pooled_ns=base,after_ratio=m[label]/base,control_ratio=m['control']/m['base'],samples_per_label=len(rr)//3))
(D/'review_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
for p in D.iterdir():
 if p.is_file()and p.suffix in ['.py','.hpp','.json','.cpp','.log','.stderr']and not p.name.startswith('415443'):files['evidence/'+p.name]=p.read_bytes()
for p in(D/'before').rglob('*'):
 if p.is_file():files['before/'+str(p.relative_to(D/'before'))]=p.read_bytes()
sys.path.insert(0,str(R/'Scripts'));from deterministic_zip import write_archive
z=R/'Audit/data/hld-composite-followup-415443-2026-11-06.zip';write_archive(z,files)
a=dict(date='2026-11-06',checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='HLD経路積の再提出415443を確認。追加の小改善を同じmain/IOで比較し、採用せず現行実装を維持。',online_confirmation='Audit/online-hld-composite-415443-2026-11-06.json',online=dict(url='https://judge.yosupo.jp/submission/415443',status='AC',time_ms=251,previous_url='https://judge.yosupo.jp/submission/415441',previous_ms=248,source_matches=True,observed='max_random_00/01/02は118/126/117→113/114/113ms。worst_00は239→251ms、worst_01は248→245ms。最大値は1.2%増で、オンライン計測には環境差/揺らぎを含む。'),decision='ライブラリ本体・main・共通IOは変更しない。追加の再提出は不要。',candidates=[dict(name='singleton direct read',change='所有する自作Segment Treeの長さ1区間を葉から直接コピーし、通常prodのブロック分割計算を省く。',result='GCC探索でworst約8%/line約11%の後退（旧コード対照は約-1%/+4%）。Clangはrandom系で改善する一方、他条件に一貫した改善を確認できず、候補を不採用。'),dict(name='parent load hoist',change='GCC Orderedのu/v側で、次の親を区間積より前に読み出す。',result='実行コードは変わったが、小規模以外は一貫した短縮がなく、max_randomでは旧コード対照にも約20%差があり追加の高速化と断定できない。不採用。')],measurement=dict(cpu='Intel Core i9-14900K CPU12 P-Core',compilers=['GCC 15.2','Clang 21.1.8'],flags=['-std=c++23','-O2','-Wall','-Wextra','-Werror'],skip_runtime_checks=True,fixture_reference='Audit/data/performance-hld-owned-2026-11-05.zip のfixturesと再現器。公式生成器commit73876f1cbcf082d2b22722924b924d3d65a2f00e。',scope='同じVerify main/共通IOでbase/control/candidateの順を混ぜ、同じ実行パスへコピー。setarch -Rでprocess単位のASLRを揃え、taskset CPU12。rusage(user+system)には構築・IO・破棄を含む。',timed_runs=rawcount,summary=summary,limits='ホスト負荷が高く旧コード対照にも数%〜20%程度の差がある。3回の探索値を採用根拠にせず、Clangの追加比較は各7回実施したが、全条件での改善を示さない。現行judgeの入力そのものやオンライン短縮率とは区別する。'),source_preservation=rows,validation='本体・main・IOが前回独立参照/ASan+UBSan/確保失敗試験/標準代替を通過した版とbyte一致。候補414実行は前後出力SHA一致。新たな本体変更を採用しないため同じ回帰試験を繰り返さない。',evidence=dict(path=str(z.relative_to(R)),sha256=sha(z),entries=len(files)),required_resubmission=[])
assert rawcount==414
(R/'Audit/hld-composite-followup-415443-2026-11-06.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');print('Library/main/IO unchanged; candidate review:',rawcount,'runs; no resubmission required')
