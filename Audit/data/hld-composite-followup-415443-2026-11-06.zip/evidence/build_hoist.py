# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,subprocess,json,hashlib
D=Path('/tmp/sirkit_hld_415443');R=Path('/home/reinsirk/Atcoder_Env');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as p
e=next(x for x in p.collect()if x['id']=='hld_path_composite');data,_=p.render(e,source_overrides={'Graph/Heavy_Light_Decomposition.cpp':(D/'hoist.hpp').read_bytes()});src=D/'hoist.cpp';src.write_bytes(data);exe=D/'gcc_hoist';cmd=['taskset','-c','4','/usr/bin/g++','-std=c++23','-O2','-Wall','-Wextra','-Werror',str(src),'-o',str(exe)];subprocess.run(cmd,check=True)
texts=[]
for x in [D/'gcc_base',exe]:
 f=x.with_suffix('.text');subprocess.run(['objcopy','--dump-section',f'.text={f}',str(x)],check=True);texts.append(f.read_bytes())
a=dict(command=cmd,text_identical=texts[0]==texts[1],base_text_sha256=hashlib.sha256(texts[0]).hexdigest(),after_text_sha256=hashlib.sha256(texts[1]).hexdigest());(D/'hoist_code.json').write_text(json.dumps(a,indent=2)+'\n');print(a)
