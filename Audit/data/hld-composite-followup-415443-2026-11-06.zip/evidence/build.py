# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,subprocess,json,hashlib
D=Path('/tmp/sirkit_hld_415443');R=Path('/home/reinsirk/Atcoder_Env');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as p
e=next(x for x in p.collect()if x['id']=='hld_path_composite');rows=[]
for label in ['base','short']:
 data,_=p.render(e,source_overrides={'Graph/Heavy_Light_Decomposition.cpp':(D/('before/Graph/Heavy_Light_Decomposition.cpp'if label=='base'else'short.hpp')).read_bytes()});src=D/f'{label}.cpp';src.write_bytes(data)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(src),'-o',str(D/f'{cc}_{label}')];subprocess.run(cmd,check=True);rows.append(dict(compiler=cc,label=label,command=cmd,source_sha256=hashlib.sha256(data).hexdigest()));print(cc,label,'ready',flush=True)
(D/'builds.json').write_text(json.dumps(rows,indent=2)+'\n')
