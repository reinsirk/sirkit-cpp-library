# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,datetime,sys
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_415443');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();norm=lambda t:'\n'.join(l.rstrip()for l in t.replace('\r\n','\n').splitlines()if l.strip()and not l.startswith('// Submission:'))
sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv;pv.preserve_submission_annotations()
group=R/'Verify/current/groups/expansion_20261031.json';g=json.loads(group.read_text());p=R/'Verify/current/judgements.json';j=json.loads(p.read_text());records=[];comparisons=[]
oldrecords={e['id']:e for e in json.loads((R/'Audit/online-hld-owned-2026-11-06.json').read_text())['records']}
for sid,vid in [(415443,'hld_path_composite')]:
 api=json.loads((D/f'{sid}.json').read_text());o=api['overview'];e=next(e for e in g['entries']if e['id']==vid);source=D/'before/Verify/current/submissions'/f'{vid}.cpp';assert norm(api['source'])==norm(source.read_text());assert o['status']=='AC'
 record=dict(id=vid,status='AC',url=f'https://judge.yosupo.jp/submission/{sid}',time_ms=round(o['time']*1000),memory_bytes=o['memory'],language=o['lang'],submission_time=o['submission_time'],checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),case_results=api['case_results'],submission_sha256=sha(source),uploaded_source_sha256=sha(D/f'{sid}.cpp'),source_hashes={f:sha(D/'before'/f)for f in e['libraries']},driver_sha256=sha(D/'before'/e['driver']),io_source_hashes={'Verify/current/common/fast_io.hpp':sha(D/'before/Verify/current/common/fast_io.hpp')},io_mode='shared_fast_io',matched_current_generation=True,needs_resubmission=False,source_match='改行・空行・行末空白・Submission注記を除き、現行本体・main・共通IOと一致。',evidence_file='Audit/online-hld-composite-415443-2026-11-06.json');records.append(record);e['submission_urls']=[record['url']];j['entries']=[x for x in j['entries']if x['id']!=vid]+[record]
 old=oldrecords[vid];oldcases={c['case']:c for c in old['case_results']};comparisons.append(dict(id=vid,before_url=old['url'],after_url=record['url'],before_ms=old['time_ms'],after_ms=record['time_ms'],reduction_percent=100*(1-record['time_ms']/old['time_ms']),cases=[dict(case=c['case'],before_ms=round(oldcases[c['case']]['time']*1000),after_ms=round(c['time']*1000))for c in api['case_results']if c['case']in oldcases]))
group.write_text(json.dumps(g,ensure_ascii=False,indent=2)+'\n');p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
a=dict(endpoints=[f'https://v3.api.judge.yosupo.jp/submissions/{i}'for i in [415443]],scope='ペア更新を含む所有HLD経路積の再提出。この後の改修はこのACに含めない。オンライン時間は測定揺らぎ・判定環境を含み、本体単体の速度比ではない。',records=records,comparisons=comparisons)
(R/'Audit/online-hld-composite-415443-2026-11-06.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
from deterministic_zip import write_archive
write_archive(R/'Audit/data/online-hld-composite-415443-2026-11-06.zip',{f:(D/f).read_bytes()for f in ['415443.json','415443.cpp','confirm.py']});print('415443 AC251ms/source/main/IO matches recorded')
