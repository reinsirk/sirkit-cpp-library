# DynamicUnionFind 自己要素ショートカット：不採用

未登録のself same/uniteでもindex_forを1回呼ぶため、自動登録・node_count・component_count・contains・callbackの意味を保つ。型はint固定なので新しいoperator==制約はなく、operator==削除済みのint変換型からの呼出しも通る。

既存所有/例外/容量テスト16構成と、Python成分ラベル1万操作の8構成は全成功した。全7性能入力も両実装・両compilerでPython参照と全文一致した。

しかしClang通常randomが8.37→9.08ms（+8.4%）、GCC自己1%混合が13.92→14.84ms（+6.6%）。繰返し自己列はGCCで2.68→2.39msだがClangでは3.14→3.19msで、一貫した利得がない。現実装を維持し、repoは変更していない。

[全測定・契約の検討・再現資料](final_report.json)。既定の時刻由来hash saltは両方維持しているため、小差を確定的な本体差とは主張しない。
