from pathlib import Path
import subprocess,json,hashlib
W=Path(__file__).parent;rows=[]
import sys,random
if '--trace-only' not in sys.argv:
 for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for mode,flags in [('checked',[]),('skip',['-DSKIP_RUNTIME_CHECKS']),('standard_checked',['-DSIRKIT_DISABLE_SIMD']),('standard_skip',['-DSKIP_RUNTIME_CHECKS','-DSIRKIT_DISABLE_SIMD'])]:
   for src in sorted((W/'frozen_tests').glob('*.cpp')):
    exe=W/f'{cc}-{mode}-{src.stem}';header=str(W/'candidate.hpp');cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',*flags,'-DDUF_SOURCE="'+header+'"','-DSIRKIT_DUF_SOURCE="'+header+'"',str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','11',str(exe)],capture_output=True,text=True);r={'compiler':cc,'mode':mode,'test':src.stem,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((W/'candidate.hpp').read_bytes()).hexdigest(),'passed':p.returncode==0,'stdout':p.stdout,'stderr':p.stderr};rows.append(r);(W/'test_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,mode,src.stem,p.stdout.strip()[:160],flush=True);assert p.returncode==0,p.stderr

if '--trace-only' in sys.argv:
 rng=random.Random(72118);keys=[-2147483648,2147483647,-1,0,1]+[rng.randrange(-2147483648,2147483648) for _ in range(251)];labels={};lines=[];answers=[]
 for i in range(10000):
  kind=rng.choices(range(6),[35,25,15,15,1,9])[0];x=rng.choice(keys);y=x if rng.randrange(100)<60 else rng.choice(keys);lines.append(f'{kind} {x} {y}\n');result=0;calls=0
  if kind in [0,1,3]:
   labels.setdefault(x,x);labels.setdefault(y,y)
   if kind==0:result=int(labels[x]==labels[y])
   elif labels[x]!=labels[y]:
    old,new=labels[y],labels[x]
    for k in labels:
     if labels[k]==old:labels[k]=new
    result=1;calls=int(kind==3)
  if kind==2:result=int(x in labels)
  if kind==4:labels.clear()
  answers.append(f'{result} {len(labels)} {len(set(labels.values()))} {int(x in labels)} {int(y in labels)} {calls}\n')
 data=(str(len(lines))+'\n'+''.join(lines)).encode();expected=''.join(answers).encode();(W/'trace.in').write_bytes(data);(W/'trace.expected').write_bytes(expected)
 for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for mode,flags in [('checked',[]),('skip',['-DSKIP_RUNTIME_CHECKS']),('standard_checked',['-DSIRKIT_DISABLE_SIMD']),('standard_skip',['-DSKIP_RUNTIME_CHECKS','-DSIRKIT_DISABLE_SIMD'])]:
   src=W/'trace.cpp';exe=W/f'{cc}-{mode}-trace';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',*flags,'-DDUF_SOURCE="'+str(W/'candidate.hpp')+'"',str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','11',str(exe)],input=data,capture_output=True);ok=p.returncode==0 and p.stdout==expected;rows.append({'compiler':cc,'mode':mode,'command':cmd,'passed':ok,'operations':10000,'model':'Python component labels replaced by full key scan, with node/component/contains/auto-registration/callback counts; int-convertible deleted operator== client compiles and works.','input_sha256':hashlib.sha256(data).hexdigest(),'output_sha256':hashlib.sha256(p.stdout).hexdigest()});(W/'trace_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,mode,'trace',ok,flush=True);assert ok,p.stderr
