// SPDX-License-Identifier: CC0-1.0
#include DUF_SOURCE
#include <cstdio>
#include <cstdlib>
struct IntLike { int value; operator int() const { return value; } bool operator==(const IntLike&) const = delete; };
int main() {
 DynamicUnionFind uf;
 if(!uf.same(IntLike{7},IntLike{7})||uf.unite(IntLike{7},IntLike{7})||uf.node_count()!=1||uf.component_count()!=1)std::abort();
 uf.clear();int q;if(std::scanf("%d",&q)!=1)return 1;
 while(q--) {int type,x,y;if(std::scanf("%d%d%d",&type,&x,&y)!=3)return 1;int result=0,calls=0;
  if(type==0)result=uf.same(x,y);
  if(type==1)result=uf.unite(x,y);
  if(type==2)result=uf.contains(x);
  if(type==3)result=uf.unite(x,y,[&](int root,int child){++calls;if(root==child||uf.find(child)!=root)std::abort();});
  if(type==4)uf.clear();
  if(type==5)uf.reserve(512);
  std::printf("%d %zu %zu %d %d %d\n",result,uf.node_count(),uf.component_count(),uf.contains(x),uf.contains(y),calls);
 }
}
