from pathlib import Path
import difflib,hashlib,heapq,itertools,json,random,sys
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/heap_push_pop_candidate');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
sha=lambda b:hashlib.sha256(b).hexdigest();entry=next(e for e in pv.collect()if e['id']=='heap_priority_queue');body=(R/'DataStructure/heap.cpp').read_bytes();(W/'library.cpp').write_bytes(body);old=(R/entry['driver']).read_text();new=old.replace('''        heap.push(value);
        if (heap.size() > static_cast<std::size_t>(k)) (void)heap.pop_value();''','''        if (heap.size() < static_cast<std::size_t>(k)) heap.push(value);
        else (void)heap.push_pop(value);''');assert new!=old
(W/'baseline_main.cpp').write_text(old);(W/'candidate_main.cpp').write_text(new);(W/'main.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=entry['driver'],tofile='push_pop candidate')))
meta={'entry':entry,'body_sha256':sha(body),'io_sha256':sha((R/'Verify/current/common/fast_io.hpp').read_bytes()),'main_sha256':{'baseline':sha(old.encode()),'candidate':sha(new.encode())},'programs':[],'coverage':{'online_before':['push','pop_value','top'],'online_after':['push','push_pop','top'],'pop_value_online_removed':True,'local_coverage_retained':['Verify/current/tests/heap_test.cpp','Verify/current/drivers/dynamic_hash_local_main.cpp'],'no_library_changes':True}}
for name,driver in [('baseline',old),('candidate',new)]:
 for skip in [False,True]:
  data,_=pv.render(entry,source_overrides={'DataStructure/heap.cpp':body},driver_override=driver,skip_runtime_checks=skip);suffix='_skip'if skip else'_checked';p=W/(name+suffix+'.cpp');p.write_bytes(data)
  # Only the correctness-only wrapper repeats the unchanged operation loop.
  batchdriver=driver.replace('int main() {','int solve_case() {');at=batchdriver.rfind('}');batchdriver=batchdriver[:at]+'    return 0;\n'+batchdriver[at:]+'\nint main(){int cases;verify_in>>cases;while(cases--)(void)solve_case();}\n';batch,_=pv.render(entry,source_overrides={'DataStructure/heap.cpp':body},driver_override=batchdriver,skip_runtime_checks=skip);p2=W/(name+suffix+'_batch.cpp');p2.write_bytes(batch);meta['programs'].append({'name':name,'skip':skip,'source':str(p),'source_sha256':sha(data),'batch_source':str(p2),'batch_source_sha256':sha(batch)})
(W/'sources.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
(W/'inputs').mkdir(exist_ok=True)
def answer(values,k):
 heap=[];out=[]
 for x in values:
  heapq.heappush(heap,x)
  if len(heap)>k:heapq.heappop(heap)
  if len(heap)==k:out.append(heap[0])
 return out
families={};count=0;outputs=0;input_path=W/'inputs/exhaustive_cases.txt';expected_path=W/'inputs/exhaustive.expected'
with (W/'inputs/exhaustive_payload.txt').open('w')as f,expected_path.open('w')as out:
 def emit(values,k,family):
  global count,outputs
  result=answer(values,k);f.write(f'{len(values)} {k}\n'+' '.join(map(str,values))+'\n');out.write(''.join(f'{v}\n'for v in result));count+=1;outputs+=len(result);families[family]=families.get(family,0)+1
 for n in range(1,8):
  for values in itertools.permutations(range(1,n+1)):
   for k in range(1,n+1):emit(values,k,'all_small_permutations_n1to7')
  for values in itertools.product([-1,0,1],repeat=n):
   for k in range(1,n+1):emit(values,k,'all_ternary_duplicate_sequences_n1to7')
 for n in range(1,5):
  for values in itertools.product([-2147483648,-1,0,1,2147483647],repeat=n):
   for k in range(1,n+1):emit(values,k,'all_int_boundaries_n1to4')
with input_path.open('wb')as f:f.write(f'{count}\n'.encode());f.write((W/'inputs/exhaustive_payload.txt').read_bytes())
large=[];n=100000;rng=random.Random(6188913);values=list(range(1,n+1));rng.shuffle(values)
for shape,array in [('random',values),('ascending',list(range(1,n+1))),('descending',list(range(n,0,-1))),('equal',[17]*n)]:
 for k in [1,n//3,n]:
  p=W/'inputs'/f'{shape}_k{k}.in';p.write_text(f'{n} {k}\n'+' '.join(map(str,array))+'\n');result=answer(array,k);out=p.with_suffix('.expected');out.write_text(''.join(f'{x}\n'for x in result));large.append({'shape':shape,'n':n,'k':k,'input':str(p),'input_sha256':sha(p.read_bytes()),'expected':str(out),'expected_sha256':sha(out.read_bytes()),'expected_values':len(result),'online_constraint':shape!='equal'})
manifest={'exhaustive':{'cases':count,'expected_outputs':outputs,'families':families,'input':str(input_path),'input_sha256':sha(input_path.read_bytes()),'expected':str(expected_path),'expected_sha256':sha(expected_path.read_bytes()),'oracle':'Python heapq heappush+heappop independent of Heap or push_pop'},'large':large};(W/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n');print('prepared',count,'exhaustive cases',outputs,'outputs',len(large),'large inputs',flush=True)
