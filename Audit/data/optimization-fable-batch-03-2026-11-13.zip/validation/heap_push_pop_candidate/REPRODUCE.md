# Heap prefix-kth mainのpush_pop融合

結論: 今回は現行main維持を推奨。repo/metadataは変更しない。Fable呼出しなし。
統合結果はreview.json、原案はcandidate_main.cpp/main.diff。

本体DataStructure/heap.cpp、共通I/O、実際のcompiler flagsを固定した。
現在AtCoder entryにGCC追加pragmaはなく、GCC15.2/Clang21のC++23 -O2 -Wall -Wextraを使う。
GCCは既存の4子Heap、Clangは既存の2子Heapを選ぶが、各比較内の本体は同一。

## 比較したmain

- 原案: サイズk未満はpush、以後push_pop。従来のpush→pop_valueを融合。
- index_guard/: i<kで初期充填を判定するだけの同値版。
- initial_fill/: 最初のk件をpushで初期化して1回出力し、以降はpush_pop→topを繰り返す版。

全て1<=k<=nを前提に、入力順・各prefixの結果を維持する。
heapは常にこれまでの大きい方k個を持つ。push_popはHと新値の和から最小値を除き、
新値<=topなら新値だけを返してHを保持するので、追加→最小値削除と多重集合として等価。
戻り値は使用しない。

## 正しさ

Python heapqのheappush+heappopを独立参照に使った。
64573小ケース、246595出力: n=1..7の順列と{-1,0,1}列、n=1..4のint両端を含む5値列を全列挙。
各列で全kを試し、k=1/k=n/同値/重複/負値を含む。
原案と各代案をGCC/Clang checked/skipで全照合し、すべて一致。
検査用だけ元mainのloopをsolve_caseへ移して複数入力を連続処理した。計時は元の1ケースmainを使う。

10万値のrandom/昇順/降順/同値をk=1,33333,100000で生成した12入力も、全modeで出力byte照合。
本体の既存heap_testはGCC/Clang checked/skipで4回PASS（450000 updates、所有権・境界・空・pop_value等）。
代案では既知のbaseline検証と同一hashのbinaryを再利用し、candidateだけを再ビルド・再照合した。

## 同条件の測定

CPU10、2 warmup+9回ずつ、順序を交互にして測定。全48組/案のrawはresults.jsonと各代案/results.json。

原案・k=N/3のskipは、GCC/Clangでrandom約11〜17%、降順約34〜41%短縮。
昇順はおおむね同等で、大きな入力置換を減らせない側でも大幅回帰は無かった。
ただし正しいk=N降順では、GCC skipで約10%、Clang skipで約4.5%回帰した。
index条件ではこの回帰が小さくなったものの、GCCの他境界やClang昇順に小さな回帰が残る。
初期k件loop分割も、k=N降順でGCC約9%/Clang約3%、Clang昇順k=N/3で約2%回帰。
AtCoder mainの変更優先度を考慮し、非回帰を満たしたとは判断しない。

k=Nではいずれもpushだけを行う。差はmainのコード生成の影響と推測するが、assembly上の原因までは確定していない。
速度はmain込みの値であり、本体改善として扱わない。

## coverage

採用した場合、onlineはpush/pop_value/topからpush/push_pop/topへ変わり、pop_valueの実行coverageが外れる。
heap_test.cppとdynamic_hash_local_main.cppの独立参照は変更せず保持した。
採用を見送るので現在のcoverage metadataも変更しない。候補に旧ACを引き継がない。

## 再現資料

sources.jsonに本体/main/IO/全文SHA、inputs.jsonに全入力/独立期待値のSHAとcase数を保存。
test_results.jsonに全build/check command・診断・照合結果、results.jsonに全時間sampleを保存。
index_guard/initial_fillは同じ構成。初回rawを残すには再実行前に別名へ保存する。

```sh
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/heap_push_pop_candidate/test.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/heap_push_pop_candidate/benchmark.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/heap_push_pop_candidate/index_guard/test.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/heap_push_pop_candidate/index_guard/benchmark.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/heap_push_pop_candidate/initial_fill/test.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/heap_push_pop_candidate/initial_fill/benchmark.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/heap_push_pop_candidate/finalize.py
```

CPU10で他の計時と同時実行しない。prepareは現行root entryを参照するため、再現時は凍結済みsourceを使用する。
