from pathlib import Path
import copy,difflib,hashlib,json,shutil,sys
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/heap_push_pop_candidate');C=W/'index_guard';C.mkdir(exist_ok=True);(C/'bin').mkdir(exist_ok=True);sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
meta=json.loads((W/'sources.json').read_text());body=(W/'library.cpp').read_bytes();old=(W/'baseline_main.cpp').read_text();new=(W/'candidate_main.cpp').read_text().replace('heap.size() < static_cast<std::size_t>(k)','i < k');(C/'baseline_main.cpp').write_text(old);(C/'candidate_main.cpp').write_text(new);(C/'library.cpp').write_bytes(body);(C/'main.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=meta['entry']['driver'],tofile='index-guard push_pop candidate')));meta['main_sha256']['candidate']=hashlib.sha256(new.encode()).hexdigest()
for p in meta['programs']:
 if p['name']=='baseline':continue
 skip=p['skip'];suffix='_skip'if skip else'_checked';data,_=pv.render(meta['entry'],source_overrides={'DataStructure/heap.cpp':body},driver_override=new,skip_runtime_checks=skip);path=C/('candidate'+suffix+'.cpp');path.write_bytes(data);p['source']=str(path);p['source_sha256']=hashlib.sha256(data).hexdigest();batchdriver=new.replace('int main() {','int solve_case() {');a=batchdriver.rfind('}');batchdriver=batchdriver[:a]+'    return 0;\n'+batchdriver[a:]+'\nint main(){int cases;verify_in>>cases;while(cases--)(void)solve_case();}\n';batch,_=pv.render(meta['entry'],source_overrides={'DataStructure/heap.cpp':body},driver_override=batchdriver,skip_runtime_checks=skip);path=C/('candidate'+suffix+'_batch.cpp');path.write_bytes(batch);p['batch_source']=str(path);p['batch_source_sha256']=hashlib.sha256(batch).hexdigest()
for compiler in ['GCC','Clang']:
 for skip in ['checked','skip']:
  for suffix in ['', '_batch']:shutil.copy2(W/'bin'/f'{compiler}_baseline_{skip}{suffix}',C/'bin'/f'{compiler}_baseline_{skip}{suffix}')
(C/'sources.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');(C/'inputs.json').write_bytes((W/'inputs.json').read_bytes());(C/'benchmark.py').write_text((W/'benchmark.py').read_text().replace(str(W),str(C)))
print('prepared index guard')
