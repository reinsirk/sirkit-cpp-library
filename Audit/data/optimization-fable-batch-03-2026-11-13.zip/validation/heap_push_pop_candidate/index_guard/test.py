from pathlib import Path
import hashlib,json,os,subprocess
W=Path('/tmp/sirkit_fastest_review_20261113/heap_push_pop_candidate');C=W/'index_guard';os.sched_setaffinity(0,{10});sha=lambda b:hashlib.sha256(b).hexdigest();meta=json.loads((C/'sources.json').read_text());inputs=json.loads((C/'inputs.json').read_text());old=json.loads((W/'test_results.json').read_text());report={'status':'running','builds':[b for b in old['builds']if b['variant']=='baseline'],'checks':[r for r in old['checks']if r['variant']=='baseline'],'local_api_tests':old['local_api_tests'],'baseline_and_local_results_reused_from':str(W/'test_results.json')}
for label,prefix in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for p in meta['programs']:
  if p['name']=='baseline':continue
  tag=f'{label}_candidate_{"skip"if p["skip"]else"checked"}'
  for batch in [False,True]:
   src=Path(p['batch_source']if batch else p['source']);assert sha(src.read_bytes())==(p['batch_source_sha256']if batch else p['source_sha256']);exe=C/'bin'/(tag+('_batch'if batch else''));cmd=[*prefix,'-std=c++23','-O2','-Wall','-Wextra',str(src),'-o',str(exe)];r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);assert r.returncode==0,r.stderr;report['builds'].append({'compiler':label,'variant':'candidate','skip':p['skip'],'batch_correctness_only':batch,'command':cmd,'source_sha256':sha(src.read_bytes()),'binary_sha256':sha(exe.read_bytes()),'diagnostics':r.stderr})
   for case in ([inputs['exhaustive']]if batch else inputs['large']):
    inp=Path(case['input']);expected=Path(case['expected']).read_bytes();assert sha(inp.read_bytes())==case['input_sha256']and sha(expected)==case['expected_sha256']
    with inp.open('rb')as f:r=subprocess.run([str(exe)],stdin=f,capture_output=True,timeout=90)
    row={'compiler':label,'variant':'candidate','skip':p['skip'],'batch_correctness_only':batch,'input':str(inp),'input_sha256':case['input_sha256'],'expected_sha256':case['expected_sha256'],'output_sha256':sha(r.stdout),'returncode':r.returncode,'stderr':r.stderr.decode(errors='replace'),'passed':r.returncode==0 and r.stdout==expected};report['checks'].append(row);assert row['passed'],row
   print(tag,'batch'if batch else'full main','PASS',flush=True);(C/'test_results.json').write_text(json.dumps(report,indent=2)+'\n')
report['status']='passed';report['exhaustive_cases_per_configuration']=inputs['exhaustive']['cases'];report['exhaustive_configurations']=8;report['local_files_unchanged']=old['local_files_unchanged'];(C/'test_results.json').write_text(json.dumps(report,indent=2)+'\n')
