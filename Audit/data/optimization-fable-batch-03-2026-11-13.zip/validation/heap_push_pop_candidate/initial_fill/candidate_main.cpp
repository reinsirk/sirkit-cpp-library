// SPDX-License-Identifier: CC0-1.0
#include "Verify/current/common/fast_io.hpp"

int main() {
    int n, k; verify_in >> n >> k;
    Heap heap;
    for (int i = 0; i < k; ++i) {
        int value; verify_in >> value;
        heap.push(value);
    }
    verify_out << heap.top() << '\n';
    for (int i = k; i < n; ++i) {
        int value; verify_in >> value;
        (void)heap.push_pop(value);
        verify_out << heap.top() << '\n';
    }
}
