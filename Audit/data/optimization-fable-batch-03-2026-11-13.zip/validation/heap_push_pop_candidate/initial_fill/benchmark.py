from pathlib import Path
import hashlib,json,os,statistics,subprocess,time
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/heap_push_pop_candidate/initial_fill');os.sched_setaffinity(0,{10});sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();meta=json.loads((W/'sources.json').read_text());validation=json.loads((W/'test_results.json').read_text());assert validation['status']=='passed';inputs=json.loads((W/'inputs.json').read_text())['large'];report={'status':'running','cpu':10,'scope':'main-only full-program effect; Heap and I/O bytes fixed, same C++23 O2 settings, actual checked/skip variants','source_metadata':meta,'method':'2 warmup+9 measured interleaved baseline/candidate reverse order; use the exact independently validated binaries','results':[]}
for compiler in ['GCC','Clang']:
 for skip in [False,True]:
  binaries={n:W/'bin'/f'{compiler}_{n}_{"skip"if skip else"checked"}'for n in ['baseline','candidate']};builds={}
  for name,exe in binaries.items():
   b=next(b for b in validation['builds']if b['compiler']==compiler and b['variant']==name and b['skip']==skip and not b['batch_correctness_only']);assert sha(exe)==b['binary_sha256'];builds[name]=b
  for case in inputs:
   path=Path(case['input']);assert sha(path)==case['input_sha256'];samples={n:[]for n in binaries}
   for iteration in range(11):
    for name in (['baseline','candidate']if iteration%2==0 else['candidate','baseline']):
     with path.open('rb')as f:
      begin=time.perf_counter_ns();subprocess.run([str(binaries[name])],stdin=f,stdout=subprocess.DEVNULL,check=True);elapsed=(time.perf_counter_ns()-begin)/1e6
     if iteration>=2:samples[name].append(elapsed)
   median={n:statistics.median(v)for n,v in samples.items()};pairs=[c/b for c,b in zip(samples['candidate'],samples['baseline'])];row={'compiler':compiler,'skip':skip,'input':case,'builds':builds,'samples_ms':samples,'median_ms':median,'ratio':median['candidate']/median['baseline'],'paired_median_ratio':statistics.median(pairs),'candidate_wins_out_of_9':sum(x<1 for x in pairs),'warmup':2,'measured':9,'all_outputs_prechecked_against_heapq':True};report['results'].append(row);(W/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(compiler,'skip'if skip else'checked',case['shape'],case['k'],round(row['ratio'],3),median,'wins',row['candidate_wins_out_of_9'],flush=True)
report['root_unchanged']={'library':sha(R/'DataStructure/heap.cpp')==meta['body_sha256'],'main':sha(R/meta['entry']['driver'])==meta['main_sha256']['baseline'],'io':sha(R/'Verify/current/common/fast_io.hpp')==meta['io_sha256']};assert all(report['root_unchanged'].values());report['status']='passed';(W/'results.json').write_text(json.dumps(report,indent=2)+'\n');print('FINAL PASS',len(report['results']),'compiler/check/input comparisons',flush=True)
