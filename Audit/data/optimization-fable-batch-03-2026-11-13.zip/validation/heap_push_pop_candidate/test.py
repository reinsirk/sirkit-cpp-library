from pathlib import Path
import hashlib,json,os,subprocess
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/heap_push_pop_candidate');os.sched_setaffinity(0,{10});meta=json.loads((W/'sources.json').read_text());inputs=json.loads((W/'inputs.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();(W/'bin').mkdir(exist_ok=True);report={'status':'running','builds':[],'checks':[],'local_api_tests':[]}
for label,prefix in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for p in meta['programs']:
  tag=f'{label}_{p["name"]}_{"skip"if p["skip"]else"checked"}'
  for batch in [False,True]:
   src=Path(p['batch_source']if batch else p['source']);assert sha(src.read_bytes())==(p['batch_source_sha256']if batch else p['source_sha256']);exe=W/'bin'/(tag+('_batch'if batch else''));cmd=[*prefix,'-std=c++23','-O2','-Wall','-Wextra',str(src),'-o',str(exe)];r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);assert r.returncode==0,r.stderr;report['builds'].append({'compiler':label,'variant':p['name'],'skip':p['skip'],'batch_correctness_only':batch,'command':cmd,'source_sha256':sha(src.read_bytes()),'binary_sha256':sha(exe.read_bytes()),'diagnostics':r.stderr})
   cases=[inputs['exhaustive']]if batch else inputs['large']
   for case in cases:
    inp=Path(case['input']);expected=Path(case['expected']).read_bytes();assert sha(inp.read_bytes())==case['input_sha256'];assert sha(expected)==case['expected_sha256']
    with inp.open('rb')as f:r=subprocess.run([str(exe)],stdin=f,capture_output=True,timeout=90)
    passed=r.returncode==0 and r.stdout==expected;row={'compiler':label,'variant':p['name'],'skip':p['skip'],'batch_correctness_only':batch,'input':str(inp),'input_sha256':case['input_sha256'],'expected_sha256':case['expected_sha256'],'output_sha256':sha(r.stdout),'returncode':r.returncode,'stderr':r.stderr.decode(errors='replace'),'passed':passed};report['checks'].append(row);assert passed,row
   print(tag,'batch'if batch else'full main','PASS',len(cases),'datasets',flush=True);(W/'test_results.json').write_text(json.dumps(report,indent=2)+'\n')
 for skip in [False,True]:
  exe=W/'bin'/f'local_{label}_{skip}';cmd=[*prefix,'-std=c++23','-O2','-Wall','-Wextra','-DHEADER="'+str(W/'library.cpp')+'"']
  if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
  cmd += [str(R/'Verify/current/tests/heap_test.cpp'),'-o',str(exe)];built=subprocess.run(cmd,capture_output=True,text=True,timeout=180);assert built.returncode==0,built.stderr;r=subprocess.run([str(exe)],capture_output=True,text=True,timeout=120);row={'compiler':label,'skip':skip,'command':cmd,'diagnostics':built.stderr,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'passed':r.returncode==0 and r.stdout.startswith('PASS heap API')};report['local_api_tests'].append(row);assert row['passed'],row;print('local Heap API',label,skip,'PASS',flush=True)
report['status']='passed';report['exhaustive_cases_per_configuration']=inputs['exhaustive']['cases'];report['exhaustive_configurations']=8;report['local_files_unchanged']={p:sha((R/p).read_bytes())for p in meta['coverage']['local_coverage_retained']};(W/'test_results.json').write_text(json.dumps(report,indent=2)+'\n');print('FINAL PASS',len(report['builds']),'full/batch builds',len(report['checks']),'dataset comparisons',len(report['local_api_tests']),'local API runs',flush=True)
