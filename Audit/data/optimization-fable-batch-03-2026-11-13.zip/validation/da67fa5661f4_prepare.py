from pathlib import Path
import json,sys,hashlib,shutil,random
R=Path('/home/reinsirk/Atcoder_Env');W=Path(__file__).parent;old=(R/'DataStructure/dynamic-union-find.cpp').read_text();s=old.replace('    std::pair<int, int> merge_roots(int x, int y) {\n','    std::pair<int, int> merge_roots(int x, int y) {\n        if (x == y) { (void)index_for(x); return {-1, -1}; }\n').replace('    int same(int x, int y) {\n','    int same(int x, int y) {\n        if (x == y) { (void)index_for(x); return true; }\n').replace('    int same(int x, int y) { return find(x) == find(y); }','    int same(int x, int y) {\n        if (x == y) { (void)index_for(x); return true; }\n        return find(x) == find(y);\n    }');assert s.count('if (x == y)')==3
(W/'baseline.hpp').write_text(old);(W/'candidate.hpp').write_text(s)
for name in ['dynamic_union_find_test','dynamic_union_groups_test']:shutil.copyfile(R/'Verify/current/tests'/f'{name}.cpp',W/'frozen_tests'/f'{name}.cpp')
sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
e=next(e for e in pv.collect() if e['id']=='dynamic_union_find');driver=(R/e['driver']).read_text();(W/'sources').mkdir(exist_ok=True);(W/'sources/driver.cpp').write_text(driver);hashes={}
for label in ['baseline','candidate']:
 data=pv.render(e,source_overrides={'DataStructure/dynamic-union-find.cpp':(W/f'{label}.hpp').read_bytes()},driver_override=driver)[0];p=W/'sources'/f'{label}.cpp';p.write_bytes(data);hashes[label]=hashlib.sha256(data).hexdigest()
(W/'sources/metadata.json').write_text(json.dumps({'entry':e,'driver_sha256':hashlib.sha256(driver.encode()).hexdigest(),'sources_sha256':hashes},indent=2)+'\n');(W/'inputs').mkdir(exist_ok=True)
for p in Path('/tmp/sirkit_remaining_20261113/data/inputs/dynamic_union_find').glob('*'):shutil.copyfile(p,W/'inputs'/p.name)
rng=random.Random(882193);n=100000;q=300000
for percent in [1,10,50]:
 with (W/'inputs'/f'mixed_{percent}.in').open('w') as f:
  f.write(f'{n} {q}\n')
  for i in range(q):
   x=rng.randrange(n);y=x if rng.randrange(100)<percent else rng.randrange(n);f.write(f'{i%2} {x} {y}\n')
# Unregistered self calls must register each unique full-int-domain key.
with (W/'inputs/self_fresh.in').open('w') as f:
 f.write(f'{q} {q}\n')
 for i in range(q):
  x=i;f.write(f'{i%2} {x} {x}\n')
(W/'provenance.json').write_text(json.dumps({'baseline_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(s.encode()).hexdigest(),'changes':'Only int-argument same and merge_roots gain x==y registration short-circuit. Automatic registration via existing index_for kept. No template Key operator== constraint because class is non-template with fixed int keys. Callback unchanged, no callback for self unite.','source':'Fable batch_03 candidate[1]'},indent=2)+'\n')
