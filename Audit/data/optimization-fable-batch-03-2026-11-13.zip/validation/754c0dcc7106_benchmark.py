from pathlib import Path
import subprocess,json,hashlib,statistics,random,time,shutil,gc
W=Path(__file__).parent;rows=[];(W/'bin').mkdir(exist_ok=True)
def save():(W/'benchmark_results.json').write_text(json.dumps({'cpu':11,'scope':'Only self int-key shortcuts in same/merge_roots changed; frozen current main/commonI/O/actual generated pragma/SKIP/NDEBUG identical. CLI C++23 O2.2warm+9 shuffled alternating fixed executable path. Existing time-based internal hash salt retained in full programs.','results':rows},indent=2)+'\n')
def model(inp):
 data=list(map(int,inp.read_text().split()));n,q=data[:2];assert len(data)==2+q*3;p=list(range(n));sizes=[1]*n;out=[]
 def root(x):
  while p[x]!=x:p[x]=p[p[x]];x=p[x]
  return x
 for i in range(q):
  t,x,y=data[2+3*i:5+3*i];assert 0<=x<n and 0<=y<n;a,b=root(x),root(y)
  if t:out.append(str(int(a==b))+'\n')
  elif a!=b:
   if sizes[a]<sizes[b]:a,b=b,a
   p[b]=a;sizes[a]+=sizes[b]
 return ''.join(out).encode()
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 bins={}
 for label in ['baseline','candidate']:
  src=W/'sources'/f'{label}.cpp';exe=W/'bin'/f'{cc}_{label}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',str(src),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr;bins[label]=exe;rows.append({'kind':'build','compiler':cc,'label':label,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'passed':True});save()
 for inp in sorted((W/'inputs').glob('*.in')):
  expected=model(inp);gc.collect()
  for label,exe in bins.items():
   p=subprocess.run(['taskset','-c','11',str(exe)],input=inp.read_bytes(),capture_output=True);assert p.returncode==0 and p.stdout==expected,(cc,label,inp,p.stderr)
  raw={k:[] for k in bins};rng=random.Random(382907)
  for rep in range(11):
   order=list(raw);rng.shuffle(order)
   for label in order:
    active=W/'bin/active';shutil.copyfile(bins[label],active);active.chmod(0o755)
    with inp.open('rb') as fi,open('/dev/null','wb') as fo:
     start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','11',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
    assert p.returncode==0,p.stderr
    if rep>=2:raw[label].append(elapsed)
  med={k:statistics.median(v) for k,v in raw.items()};rows.append({'kind':'timing','compiler':cc,'case':inp.stem,'python_reference_equal':True,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(expected).hexdigest(),'raw_ns':raw,'median_ns':med,'ratio':med['candidate']/med['baseline']});save();print(cc,inp.stem,{k:round(v/1e6,3) for k,v in med.items()},flush=True)
