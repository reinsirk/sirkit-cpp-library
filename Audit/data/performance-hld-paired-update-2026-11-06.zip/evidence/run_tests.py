# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,os
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_followup_20261106');rows=json.loads((D/'test_results.json').read_text())if(D/'test_results.json').exists()else[]
for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for test in ['owned','paired','allocation']:
  for skip in ([False,True]if test!='allocation'else[False]):
   if any(x['compiler']==cc and x['test']==test and x['skip_runtime_checks']==skip for x in rows):continue
   src=R/f'Verify/current/tests/hld_{"owned_test"if test=="owned"else"paired_update_test"if test=="paired"else"owned_allocation_test"}.cpp';exe=D/f'test_{cc}_{test}_{int(skip)}';cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror']+(['-fsanitize=address,undefined','-fno-omit-frame-pointer']if test!='allocation'else[])+['-I'+str(R/'Verify/current/vendor')]+(['-DSKIP_RUNTIME_CHECKS']if skip else[])+(['-DSIRKIT_HLD_OWNED_RANGES_FIRST','-DPAIRED_SEG_FIRST']if cc=='clang'else[])+[str(src),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','4',str(exe)],text=True,capture_output=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'});assert p.returncode==0 and not p.stderr,(p.returncode,p.stderr);rows.append(dict(compiler=cc,test=test,skip_runtime_checks=skip,command=cmd,stdout=p.stdout,returncode=p.returncode,stderr=p.stderr));(D/'test_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,test,skip,p.stdout.strip(),flush=True)
