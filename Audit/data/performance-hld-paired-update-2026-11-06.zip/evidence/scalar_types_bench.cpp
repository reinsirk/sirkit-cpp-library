// SPDX-License-Identifier: CC0-1.0
// 補足の型別kernel測定。生成・構築・破棄はloop_msに含めない。Verify main全体の測定とは別。
#ifndef HLD_SOURCE
#define HLD_SOURCE "/tmp/sirkit_hld_followup_20261106/paired_hld.hpp"
#endif
#ifndef SEG_SOURCE
#define SEG_SOURCE "/tmp/sirkit_hld_followup_20261106/paired_segment.hpp"
#endif
#include HLD_SOURCE
#include SEG_SOURCE
#include <algorithm>
#include <bit>
#include <chrono>
#include <cinttypes>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <limits>
#include <numeric>
#include <random>
#include <string_view>
#include <type_traits>
#include <vector>
namespace {
using I=std::int64_t;
[[maybe_unused]] I add(I a,I b){return a+b;}[[maybe_unused]] I zero(){return 0;}
[[maybe_unused]] I minimum(I a,I b){return std::min(a,b);}[[maybe_unused]] I infinity(){return std::numeric_limits<I>::max();}
constexpr std::uint64_t mod=998244353;
struct Affine{std::uint64_t a=1,b=0;};
[[maybe_unused]] Affine compose(Affine x,Affine y){return {x.a*y.a%mod,(x.b*y.a+y.b)%mod};}[[maybe_unused]] Affine identity(){return {};}
template<class S>S make(std::uint64_t a,std::uint64_t b){if constexpr(std::is_same_v<S,Affine>)return {a%mod,b%mod};else return static_cast<I>(a%1000001);}
template<class S>std::uint64_t code(S x){if constexpr(std::is_same_v<S,Affine>)return x.a^(x.b<<32);else return static_cast<std::uint64_t>(x);}
template<class S>struct Query{int u,v;S value;unsigned selector;};
template<class S,auto Op,auto E,bool UpdateHeavy>int run(int n,std::size_t count){
 std::mt19937_64 rng(0x18e77ca901ULL);std::vector<int> label(n);std::iota(label.begin(),label.end(),0);std::shuffle(label.begin(),label.end(),rng);
 Graph graph(n);for(int i=1;i<n;++i){int u=label[i],v=label[(i-1)/2];graph[u].push_back(v);graph[v].push_back(u);}
 const int root=static_cast<int>(rng()%static_cast<std::uint64_t>(n));std::vector<S> values(n);for(auto& x:values){const auto a=rng(),b=rng();x=make<S>(a,b);}
 std::vector<Query<S>> queries;queries.reserve(count);for(std::size_t i=0;i<count;++i){const int u=static_cast<int>(rng()%n),v=static_cast<int>(rng()%n);const auto a=rng(),b=rng();const auto selector=static_cast<unsigned>(rng());queries.push_back({u,v,make<S>(a,b),selector});}
 using Range=segtree<S,Op,E>;HeavyLightValues<Range,true> tree(graph,values,root);std::uint64_t digest=0;
 const auto begin=std::chrono::steady_clock::now(); const auto cpu_begin=std::clock();
 for(const auto& q:queries){
  if((q.selector&1023U)==0){digest=std::rotl(digest,1)^code(tree.path_prod(q.u,q.v));}
  else if constexpr(UpdateHeavy){if((q.selector&7U)!=0)tree.set(q.u,q.value);else digest+=code(tree.get(q.u));}
  else {if((q.selector&7U)==0)tree.set(q.u,q.value);else digest+=code(tree.get(q.u));}
 }
 const auto cpu_end=std::clock(); const auto end=std::chrono::steady_clock::now();
 // 全点の最終値も取り込み、点更新の結果が前後版で一致することを別途確認できる。
 for(int v=0;v<n;++v)digest=std::rotl(digest,1)^code(tree.get(v));
 const double ms=std::chrono::duration<double,std::milli>(end-begin).count();
 std::printf("n=%d q=%zu mode=%s loop_ms=%.6f cpu_ms=%.6f digest=%016" PRIx64 "\n",n,count,UpdateHeavy?"set":"get",ms,1000.0*static_cast<double>(cpu_end-cpu_begin)/CLOCKS_PER_SEC,digest);return 0;
}
template<class S,auto Op,auto E>int mode(int n,std::size_t q,std::string_view operation){return operation=="set"?run<S,Op,E,true>(n,q):run<S,Op,E,false>(n,q);}
}
int main(int argc,char** argv){
 if(argc<4){std::fprintf(stderr,"usage: bench N sum|min|affine set|get [Q=2000000]\n");return 2;}
 const int n=std::atoi(argv[1]);const std::string_view operation=argv[3];const std::size_t q=argc>4?std::strtoull(argv[4],nullptr,10):2000000;
 if(n<=0||(operation!="set"&&operation!="get")){std::fprintf(stderr,"invalid arguments\n");return 2;}
#ifdef BENCH_SUM
 return mode<I,add,zero>(n,q,operation);
#else
 return mode<I,minimum,infinity>(n,q,operation);
#endif
}
