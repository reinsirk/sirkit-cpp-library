# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,json,subprocess,hashlib
D=Path('/tmp/sirkit_hld_followup_20261106');R=Path('/home/reinsirk/Atcoder_Env');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as p
entries={e['id']:e for e in p.collect()};rows=[]
for label in ['base','paired']:
 over={'Graph/Heavy_Light_Decomposition.cpp':(D/'before/Graph/Heavy_Light_Decomposition.cpp').read_bytes(),'DataStructure/Segment_Tree.cpp':(D/'before/DataStructure/Segment_Tree.cpp').read_bytes()}
 if label=='paired':
  over['Graph/Heavy_Light_Decomposition.cpp']=(D/'paired_hld.hpp').read_bytes();over['DataStructure/Segment_Tree.cpp']=(D/'paired_segment.hpp').read_bytes()
 data,_=p.render(entries['hld_path_composite'],source_overrides=over);src=D/f'hld_path_composite_{label}.cpp';src.write_bytes(data)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(src),'-o',str(D/f'{cc}_{label}')];subprocess.run(cmd,check=True);rows.append(dict(label=label,compiler=cc,command=cmd,source_sha256=hashlib.sha256(data).hexdigest()));print('built',cc,label,flush=True)
(D/'probe_builds.json').write_text(json.dumps(rows,indent=2)+'\n')
