# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,fcntl,random,statistics,json,shutil,re
D=Path('/tmp/sirkit_hld_followup_20261106');raw=[];rng=random.Random(2026110607)
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for n in [32,4096,200000]:
   for typ in ['sum','min','affine']:
    for mode in ['set','get']:
     for rep in range(5):
      labels=['base','control','paired'];rng.shuffle(labels)
      for label in labels:
       shutil.copyfile(D/f'types_{cc}_{"base"if label=="control"else label}',D/'active_types');(D/'active_types').chmod(0o700)
       cmd=['setarch','x86_64','-R','taskset','-c','12',str(D/'active_types'),str(n),typ,mode,'1000000'];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0 and not p.stderr,p.stderr;values=dict(re.findall(r'(\w+)=([\w.]+)',p.stdout));assert 'cpu_ms'in values,p.stdout;raw.append(dict(compiler=cc,n=n,type=typ,mode=mode,rep=rep,label=label,cpu_ms=float(values['cpu_ms']),loop_ms=float(values['loop_ms']),digest=values['digest']))
     rr=[x for x in raw if (x['compiler'],x['n'],x['type'],x['mode'])==(cc,n,typ,mode)];assert len({x['digest']for x in rr})==1;m={l:statistics.median(x['cpu_ms']for x in rr if x['label']==l)for l in labels};print(cc,n,typ,mode,'ratio',round(m['paired']/m['base'],4),'control',round(m['control']/m['base'],4),'ms',round(m['base'],2),round(m['paired'],2),flush=True);(D/'types_raw.json').write_text(json.dumps(raw))
print('Types supplement complete',len(raw),flush=True)
