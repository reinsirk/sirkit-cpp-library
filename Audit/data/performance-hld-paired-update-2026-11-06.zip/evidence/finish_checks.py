# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,subprocess,sys,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_followup_20261106');O=Path('/tmp/sirkit_hld_opt_20261105');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
es={x['id']:x for x in pv.collect()};rows=[];ccs={'gcc':['/usr/bin/g++'],'clang':['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']}
for vid in ['hld_path_prod','hld_path_composite','hld_jump','hld_vertex_add_path_sum','segment_tree','segment_tree_composite']:
 for cc,args in ccs.items():
  binaries={}
  for label in ['base','final']:
   if vid=='hld_path_composite' and label=='base':binaries[label]=D/f'{cc}_base';continue
   over={p:(D/'before'/p).read_bytes()for p in ['Graph/Heavy_Light_Decomposition.cpp','DataStructure/Segment_Tree.cpp']}if label=='base'else{}
   data,_=pv.render(es[vid],source_overrides=over);src=D/f'{vid}_{label}.cpp';src.write_bytes(data);exe=D/f'{cc}_{vid}_{label}';cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(src),'-o',str(exe)];subprocess.run(cmd,check=True);binaries[label]=exe
   for sample in es[vid]['samples']:
    r=subprocess.run(['taskset','-c','4',str(exe)],input=sample['input'],text=True,capture_output=True);assert r.returncode==0 and pv.matches(es[vid],sample,r.stdout) and not r.stderr,(vid,r.stdout,r.stderr)
  txt=[]
  for exe in binaries.values():
   p=exe.with_suffix('.check.text');subprocess.run(['objcopy','--dump-section',f'.text={p}',str(exe)],check=True);txt.append(p.read_bytes())
  if vid=='hld_path_composite':
   measured=(D/f'{cc}_paired').with_suffix('.check.text');subprocess.run(['objcopy','--dump-section',f'.text={measured}',str(D/f'{cc}_paired')],check=True);assert txt[1]==measured.read_bytes();unchanged=False
  else:assert txt[0]==txt[1],(cc,vid);unchanged=True
  rows.append(dict(compiler=cc,id=vid,unchanged=unchanged,final_text_sha256=hashlib.sha256(txt[1]).hexdigest(),samples_pass=True));print(cc,vid,'unchanged'if unchanged else'measured-code-matched',flush=True)
(D/'code_mapping.json').write_text(json.dumps(rows,indent=2)+'\n')
expected={(x['compiler'],x['id'],x['case']):x['output_sha256']for x in json.loads((O/'final_output_checks.json').read_text())};fixtures=json.loads((O/'fixtures/fixtures.json').read_text());checks=[]
for cc in ccs:
 for f in fixtures:
  if f['problem']!='vertex_set_path_composite':continue
  exe=D/f'{cc}_hld_path_composite_final'
  with Path(f['path']).open('rb')as fi,(D/'check_output').open('wb')as fo:r=subprocess.run(['taskset','-c','4',str(exe)],stdin=fi,stdout=fo)
  assert r.returncode==0;h=sha(D/'check_output');assert h==expected[cc,'hld_path_composite',f['name']];checks.append(dict(compiler=cc,case=f['name'],output_sha256=h,independent_expected=bool(f.get('expected_sha256'))));print(cc,f['name'],'PASS',flush=True)
(D/'output_checks.json').write_text(json.dumps(checks,indent=2)+'\n')
