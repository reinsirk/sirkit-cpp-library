# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_followup_20261106');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for f,candidate in [('Graph/Heavy_Light_Decomposition.cpp','class_only_hld.hpp'),('DataStructure/Segment_Tree.cpp','paired_segment.hpp')]:
 assert(R/f).read_bytes()==(D/candidate).read_bytes();rows.append(dict(scope=f,canonical_sha256=sha(R/f),candidate_sha256=sha(D/candidate),result='canonical exactly matches timed candidate'))
f='DataStructure/Segment_Tree.cpp';body=lambda p:p.read_text().split('class segtree {',1)[1];b=body(R/f).replace('    using HldSegmentTag = void;\n','').replace('    template<class> friend struct reinsirk::detail::HldSegmentAccess;\n','');assert b==body(D/'before'/f);rows.append(dict(scope='ordinary segtree',result='All original fields and function bodies byte-identical; private alias/friend only'))
f='Graph/Heavy_Light_Decomposition.cpp';body=lambda p:p.read_text().split('class HeavyLightDecomposition {',1)[1].split('#ifndef SIRKIT_HLD_OWNED_RANGE_TRAITS_DEFINED',1)[0];assert body(R/f)==body(D/'before'/f);rows.append(dict(scope='HeavyLightDecomposition',result='Core fields and bodies byte-identical'))
for f in ['DataStructure/Fenwick_Tree.cpp','Verify/current/drivers/hld_path_prod_main.cpp','Verify/current/drivers/hld_path_composite_main.cpp','Verify/current/common/fast_io.hpp']:
 assert(R/f).read_bytes()==(D/'before'/f).read_bytes();rows.append(dict(scope=f,sha256=sha(R/f),result='byte-identical'))
(D/'source_proofs.json').write_text(json.dumps(rows,indent=2)+'\n');print('Source/body/main/IO proofs passed')
