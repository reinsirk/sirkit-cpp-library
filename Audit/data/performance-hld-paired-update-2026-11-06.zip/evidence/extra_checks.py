# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,sys,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_followup_20261106');rows=[];sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
entry=next(e for e in pv.collect()if e['id']=='hld_path_composite')
for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for typ in ['sum','min']:
  texts=[]
  for label in ['base','final']:
   h=D/'before/Graph/Heavy_Light_Decomposition.cpp'if label=='base'else R/'Graph/Heavy_Light_Decomposition.cpp';s=D/'before/DataStructure/Segment_Tree.cpp'if label=='base'else R/'DataStructure/Segment_Tree.cpp';exe=D/f'scalar_{cc}_{typ}_{label}';cmd=['taskset','-c','6',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror','-DSKIP_RUNTIME_CHECKS',f'-DHLD_SOURCE="{h}"',f'-DSEG_SOURCE="{s}"',*(['-DBENCH_SUM']if typ=='sum'else[]),str(D/'scalar_types_bench.cpp'),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr;t=exe.with_suffix('.text');subprocess.run(['objcopy','--dump-section',f'.text={t}',str(exe)],check=True);texts.append(t.read_bytes())
  assert texts[0]==texts[1],(cc,typ);rows.append(dict(compiler=cc,scope=f'owned Ordered {typ} scalar',text_identical=True,text_sha256=hashlib.sha256(texts[0]).hexdigest()));print(cc,typ,'scalar text identical',flush=True)
 for which in ['old_hld','old_segment']:
  key='Graph/Heavy_Light_Decomposition.cpp'if which=='old_hld'else'DataStructure/Segment_Tree.cpp';data,_=pv.render(entry,source_overrides={key:(D/'before'/key).read_bytes()});src=D/f'mixed_{which}.cpp';src.write_bytes(data);exe=D/f'mixed_{cc}_{which}';cmd=['taskset','-c','6',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(src),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr
  for sample in entry['samples']:
   p=subprocess.run([str(exe)],input=sample['input'],text=True,capture_output=True);assert p.returncode==0 and p.stdout.split()==sample['output'].split()
  t=exe.with_suffix('.text');subprocess.run(['objcopy','--dump-section',f'.text={t}',str(exe)],check=True);base=(D/f'{cc}_base').with_suffix('.check.text');assert t.read_bytes()==base.read_bytes();rows.append(dict(compiler=cc,scope=which,text_identical=True,sample_pass=True));print(cc,which,'old-route text identical',flush=True)
 src=R/'Verify/current/tests/hld_paired_update_test.cpp';exe=D/f'fallback_{cc}';cmd=['taskset','-c','6',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror','-U__SIZEOF_INT128__',str(src),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr;p=subprocess.run([str(exe)],text=True,capture_output=True);assert p.returncode==0 and not p.stderr,p.stderr;rows.append(dict(compiler=cc,scope='standard fallback',command=cmd,stdout=p.stdout,returncode=p.returncode));print(cc,'standard fallback',p.stdout.strip(),flush=True)
 (D/'extra_checks.json').write_text(json.dumps(rows,indent=2)+'\n')
