from pathlib import Path
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_followup_20261106')
h=(R/'Graph/Heavy_Light_Decomposition.cpp').read_text();s=(R/'DataStructure/Segment_Tree.cpp').read_text()
fwd='''#ifndef SIRKIT_HLD_SEGMENT_ACCESS_FORWARD_DEFINED
#define SIRKIT_HLD_SEGMENT_ACCESS_FORWARD_DEFINED
namespace reinsirk::detail { template<class Range> struct HldSegmentAccess; }
#endif

'''
s=s.replace('#ifndef SIRKIT_SEGMENT_TREE_DEFINED',fwd+'#ifndef SIRKIT_SEGMENT_TREE_DEFINED',1)
s=s.replace('    S identity_;','    using HldSegmentTag = void;\n    template<class> friend struct reinsirk::detail::HldSegmentAccess;\n    S identity_;',1)
h=h.replace('#ifndef SIRKIT_HLD_FENWICK_ACCESS_FORWARD_DEFINED',fwd+'#ifndef SIRKIT_HLD_FENWICK_ACCESS_FORWARD_DEFINED',1)
helper='''#ifndef SIRKIT_HLD_SEGMENT_ACCESS_DEFINED
#define SIRKIT_HLD_SEGMENT_ACCESS_DEFINED
namespace reinsirk::detail {
template<class Range>
struct HldSegmentAccess {
    using Value = typename HldOwnedRangeTraits<Range>::Value;
    static constexpr bool enabled = [] {
        if constexpr (requires { typename Range::HldSegmentTag; })
            return std::is_trivially_copyable_v<Value> && sizeof(Value) <= 16
                && std::is_nothrow_copy_constructible_v<Value>
                && std::is_nothrow_copy_assignable_v<Value>;
        else return false;
    }();
    static void set_pair(Range& forward, Range& reversed, int index, const Value& value) {
        auto p = forward.base_ + static_cast<std::size_t>(index);
        auto q = reversed.base_ + forward.n_ - 1 - static_cast<std::size_t>(index);
        Value a = value, b = value;
        forward.data_[p] = a; reversed.data_[q] = b;
        // 独立な2本の祖先を交互に更新し、片方の演算結果を待つ間にもう片方を進める。
        while (p > 1) {
            const Value sibling_a = std::as_const(forward.data_)[p ^ 1];
            const Value sibling_b = std::as_const(reversed.data_)[q ^ 1];
            const Value left_a = (p & 1) ? sibling_a : a;
            const Value right_a = (p & 1) ? a : sibling_a;
            const Value left_b = (q & 1) ? sibling_b : b;
            const Value right_b = (q & 1) ? b : sibling_b;
            a = HldOwnedRangeTraits<Range>::combine(left_a, right_a);
            b = HldOwnedRangeTraits<Range>::combine(left_b, right_b);
            p >>= 1; q >>= 1;
            forward.data_[p] = a; reversed.data_[q] = b;
        }
    }
};
}
#endif

'''
h=h.replace('#ifndef SIRKIT_HLD_FENWICK_ACCESS_DEFINED',helper+'#ifndef SIRKIT_HLD_FENWICK_ACCESS_DEFINED',1)
old='''        const int p = layout().index(v); set_point(range(), p, value);
        if constexpr (Ordered) set_point(*state_->reversed, size() - 1 - p, value);'''
new='''        const int p = layout().index(v);
        using Access = reinsirk::detail::HldSegmentAccess<Range>;
        if constexpr (Ordered && Access::enabled) {
            Access::set_pair(range(), *state_->reversed, p, value);
        } else {
            set_point(range(), p, value);
            if constexpr (Ordered) set_point(*state_->reversed, size() - 1 - p, value);
        }'''
assert old in h;h=h.replace(old,new,1)
(D/'paired_hld.hpp').write_text(h);(D/'paired_segment.hpp').write_text(s)
print(D/'paired_hld.hpp');print(D/'paired_segment.hpp')
