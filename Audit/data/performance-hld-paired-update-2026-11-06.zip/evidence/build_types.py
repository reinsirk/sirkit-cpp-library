# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json
D=Path('/tmp/sirkit_hld_followup_20261106');rows=[]
for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for label in ['base','paired']:
  h=D/('before/Graph/Heavy_Light_Decomposition.cpp'if label=='base'else'paired_hld.hpp');s=D/('before/DataStructure/Segment_Tree.cpp'if label=='base'else'paired_segment.hpp');cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror','-DSKIP_RUNTIME_CHECKS',f'-DHLD_SOURCE="{h}"',f'-DSEG_SOURCE="{s}"',str(D/'paired_types_bench.cpp'),'-o',str(D/f'types_{cc}_{label}')];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr;rows.append(cmd);print(cc,label,'ready',flush=True)
(D/'types_builds.json').write_text(json.dumps(rows,indent=2)+'\n')
