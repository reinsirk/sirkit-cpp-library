# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,subprocess,json,statistics,random,shutil,fcntl,os,time,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_disjoint_followup_20261103');P=Path('/tmp/sirkit_sparse_speed_20261103');sys.path.insert(0,str(R/'Scripts'));import prepare_verify
s=(D/'identity.hpp').read_text();beg=s.index('        for (std::size_t half = 2;;) {');end=s.index('\n    }\n    DisjointSparseTable(const',beg);loop=s[beg:end]
loop=loop.replace('if constexpr (std::is_integral_v<T> && !std::is_same_v<T, bool>)','if constexpr (Initialize)')
helper='''    template<bool Initialize>
    void build_rows(const std::vector<T>& values) {
        const auto n = values.size();
'''+loop+'''\n    }\n'''
new='''        if constexpr (std::is_integral_v<T> && !std::is_same_v<T, bool> && sizeof(T) >= 4) {
            if (n >= 32768 / sizeof(T)) { build_rows<true>(values); return; }
        }
        build_rows<false>(values);'''
h=s[:beg]+new+s[end:];h=h.replace('    void check_range(',helper+'    void check_range(',1)
v={'base':(D/'base.hpp').read_text(),'identity':s,'threshold':h};e=next(e for e in prepare_verify.collect() if e['id']=='disjoint_sparse_table');comps=[('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]
for label,src in v.items():
 (D/f'{label}.hpp').write_text(src);data,_=prepare_verify.render(e,source_overrides={'DataStructure/Disjoint_Sparse_Table.cpp':src.encode()});(D/f'{label}.cpp').write_bytes(data)
 for cc,args in comps:
  for kind,inp,defs in [('main',D/f'{label}.cpp',[]),('micro',D/'micro.cpp',['-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_DISJOINT_TEST_SOURCE="{D/(label+".hpp")}"'])]:
   cmd=['taskset','-c','2',*args,'-std=c++23','-O2',*defs,str(inp),'-o',str(D/f'th_{kind}_{cc}_{label}')];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr
print('BUILT',flush=True);rng=random.Random(975531);raw=[]
with open('/tmp/sirkit_performance_cpu12.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for kind in ['main','micro']:
  for cc,_ in comps:
   tasks=['official_random_2','official_max_random_0','official_small_width_query_0','official_small_width_query_3','32_random','4096_random','500000_build'] if kind=='main' else [(ty,n,reps) for ty in ['min','sum32','gcd32','first32','sum'] for n,reps in [(32,20000),(4096,150),(500000,3)]]
   for case in tasks:
    for rep in range(11):
     labels=list(v)+['control'];rng.shuffle(labels)
     for label in labels:
      shutil.copyfile(D/f'th_{kind}_{cc}_{"base" if label=="control" else label}',D/'active_th');(D/'active_th').chmod(0o700)
      if kind=='main':
       inp=P/((case if case.startswith('official') else 'input_'+case)+'.in')
       with inp.open('rb') as fi,(D/'output').open('wb') as fo:
        start=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active_th')],stdin=fi,stdout=fo);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;ns=round((ru.ru_utime+ru.ru_stime)*1e9);wall=time.perf_counter_ns()-start
       check=hashlib.sha256((D/'output').read_bytes()).hexdigest()
      else:
       ty,n,reps=case;p=subprocess.run(['taskset','-c','12',str(D/'active_th'),str(n),'build',str(reps),ty],capture_output=True,text=True,check=True);check,ns=map(int,p.stdout.split());wall=None
      raw.append(dict(kind=kind,compiler=cc,case=case,rep=rep,label=label,cpu_ns=ns,wall_ns=wall,checksum=check))
    rs=[r for r in raw if r['kind']==kind and r['compiler']==cc and r['case']==case];assert len({r['checksum'] for r in rs})==1
    m={l:statistics.median(r['cpu_ns'] for r in rs if r['label']==l) for l in labels};print(kind,cc,case,{k:round(x/m['base'],4) for k,x in m.items()},flush=True);(D/'threshold_raw.json').write_text(json.dumps(raw))
