# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import random,statistics,json,shutil,fcntl,os,subprocess,time,hashlib
D=Path('/tmp/sirkit_disjoint_followup_20261103');P=Path('/tmp/sirkit_sparse_speed_20261103');raw=[];rng=random.Random(927517)
cases=[f'official_{f}_{i}'for f,c in [('random',5),('max_random',5),('small_width_query',5),('small_values',1)]for i in range(c)]
with open('/tmp/sirkit_performance_cpu14.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for case in cases:
   inp=P/(case+'.in')
   for rep in range(21):
    labels=['base','control','identity','threshold'];rng.shuffle(labels)
    for label in labels:
     shutil.copyfile(D/f'th_main_{cc}_{"base" if label=="control" else label}',D/'active_confirm');(D/'active_confirm').chmod(0o700)
     with inp.open('rb') as fi,(D/'output').open('wb') as fo:
      t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','14',str(D/'active_confirm')],stdin=fi,stdout=fo);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-t
     raw.append(dict(compiler=cc,case=case,rep=rep,label=label,cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),user_ns=round(ru.ru_utime*1e9),system_ns=round(ru.ru_stime*1e9),wall_ns=wall,sha256=hashlib.sha256((D/'output').read_bytes()).hexdigest()))
   rs=[r for r in raw if r['compiler']==cc and r['case']==case];assert len({r['sha256']for r in rs})==1
   m={l:statistics.median(r['cpu_ns']for r in rs if r['label']==l) for l in labels};print(cc,case,{k:round(v/m['base'],4)for k,v in m.items()},flush=True);(D/'confirm_raw.json').write_text(json.dumps(raw))
print('DONE',flush=True)
