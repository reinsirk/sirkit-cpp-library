# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_disjoint_followup_20261103');rows=[]
for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 exe=D/('pedantic_'+cc);cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-pedantic-errors','-Wall','-Wextra','-Werror','-DSIRKIT_DISABLE_SIMD',str(R/'Verify/current/tests/disjoint_sparse_table_integer_init_test.cpp'),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','4',str(exe)],capture_output=True,text=True,check=True);print(cc,p.stdout.strip(),flush=True);rows.append(dict(compiler=cc,command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
(D/'standard_tests.json').write_text(json.dumps(rows,indent=2)+'\n')
