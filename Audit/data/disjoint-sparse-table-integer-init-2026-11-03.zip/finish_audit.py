# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,datetime,statistics,zipfile,struct,subprocess
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_disjoint_followup_20261103');P=Path('/tmp/sirkit_sparse_speed_20261103');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda n:json.loads((D/n).read_text())
source=R/'DataStructure/Disjoint_Sparse_Table.cpp';driver=R/'Verify/current/drivers/disjoint_sparse_table_main.cpp';io=R/'Verify/current/common/fast_io.hpp';assert source.read_bytes()==(D/'selected.hpp').read_bytes();assert driver.read_bytes()==(D/'driver.cpp').read_bytes();assert sha(io)=='291bf8dbc56a1d691f6256fe95b4714183c2cf5d9e55e4bef240e31d1eb178c1'
def text_section(p):
 b=p.read_bytes();off=struct.unpack_from('<Q',b,40)[0];ent,num,idx=struct.unpack_from('<HHH',b,58);hh=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*ent) for i in range(num)];h=hh[idx];ss=b[h[4]:h[4]+h[5]]
 return next(b[h[4]:h[4]+h[5]] for h in hh if ss[h[0]:].split(b'\0',1)[0]==b'.text')
text_proof=load('text_match.json');assert all(r['text_equal'] for r in text_proof)
for cc in ['gcc','clang']:
 a,b=text_section(D/f'actual_micro_{cc}'),text_section(D/f'micro_{cc}_identity');assert a==b;text_proof.append({'compiler':cc,'kind':'original_construction_micro','text_equal':True,'reference':f'micro_{cc}_identity','text_sha256':hashlib.sha256(a).hexdigest()})
(D/'final_text_proof.json').write_text(json.dumps(text_proof,indent=2)+'\n')
host={}
for label,cmd in [('cpu',['lscpu','-J']),('topology',['lscpu','-e=CPU,CORE,MAXMHZ,MINMHZ,ONLINE']),('gcc',['/usr/bin/g++','--version']),('clang',['/usr/bin/clang++','--version'])]:host[label]={'command':cmd,'stdout':subprocess.run(cmd,capture_output=True,text=True,check=True).stdout}
for cpu in [12,14]:host['cpu'+str(cpu)]={n:Path(f'/sys/devices/system/cpu/cpu{cpu}/{file}').read_text().strip() for n,file in [('governor','cpufreq/scaling_governor'),('kernel_core_id','topology/core_id'),('siblings','topology/thread_siblings_list')]}
(D/'host.json').write_text(json.dumps(host,indent=2)+'\n')
main=[];a=load('confirm_raw.json');assert len(a)==2688
for cc in ['gcc','clang']:
 for case in sorted({r['case'] for r in a}):
  rr=[r for r in a if r['compiler']==cc and r['case']==case];assert len({r['sha256'] for r in rr})==1
  m={v:statistics.median(r['cpu_ns'] for r in rr if r['label']==v) for v in ['base','control','identity','threshold']}
  main.append({'compiler':cc,'case':case,'median_cpu_ms':{k:v/1e6 for k,v in m.items()},'over_base':{k:v/m['base'] for k,v in m.items()},'median_user_ms':{v:statistics.median(r['user_ns'] for r in rr if r['label']==v)/1e6 for v in m},'median_system_ms':{v:statistics.median(r['system_ns'] for r in rr if r['label']==v)/1e6 for v in m},'output_sha256':rr[0]['sha256']})
mi=[];a=load('micro_raw.json');assert len(a)==1890
for cc in ['gcc','clang']:
 for ty,n in sorted({(r['type'],r['n']) for r in a}):
  rr=[r for r in a if (r['compiler'],r['type'],r['n'])==(cc,ty,n)];assert len({r['checksum'] for r in rr})==1;m={v:statistics.median(r['cpu_ns'] for r in rr if r['label']==v) for v in ['base','control','zero','identity','identity32']};count=rr[0]['repeated_operations']
  mi.append({'compiler':cc,'type':ty,'n':n,'repeated_constructions':count,'ns_per_construction_and_destruction':{k:v/count for k,v in m.items()},'over_base':{k:v/m['base'] for k,v in m.items()},'checksum':rr[0]['checksum']})
tests=load('final_tests.json');profiles=load('profile_tests.json');standard=load('standard_tests.json');assert len(tests)==16 and len(profiles)==12 and len(standard)==2;assert all(r['returncode']==0 and not r.get('stderr') for r in tests+profiles+standard)
for r in tests:assert r['test_sha256']==sha(R/f'Verify/current/tests/{r["test"]}.cpp')
ps=next((D/'profiles/runs').glob('*.json'));assert json.loads(ps.read_text())['counts']=={'LOCAL_SAMPLE_PASS':10}
evidence=R/'Audit/data/disjoint-sparse-table-integer-init-2026-11-03.zip'
with zipfile.ZipFile(evidence,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(D.iterdir()):
  if p.is_file() and p.suffix in {'.py','.cpp','.hpp','.json','.log','.stderr'}:z.write(p,p.name)
 z.write(P/'official_metadata.json','inputs_metadata.json');z.write(P/'screen_build.py','original_fixture_generation.py');z.write(ps,'profile_runs/'+ps.name)
 for name in ['DataStructure/Disjoint_Sparse_Table.cpp','Verify/current/tests/disjoint_sparse_table_integer_init_test.cpp','Verify/current/tests/range_structures_allocation_test.cpp','Document/disjoint_sparse_table.md']:z.write(R/name,'current/'+name)
report={
 'date_jst':'2026-11-03','checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'adopted_for_large_integer_construction_needs_online_resubmission',
 'library':'DataStructure/Disjoint_Sparse_Table.cpp','before_source_sha256':sha(D/'before.hpp'),'current_source_sha256':sha(source),
 'online':{'url':'https://judge.yosupo.jp/submission/414937','status':'AC','time_ms':79,'previous_url':'https://judge.yosupo.jp/submission/414929','previous_time_ms':83,'reduction_percent':100*(1-79/83),'scope':'79msは今回の行初期化変更前の本体。今回版のACではない。','evidence':'online-disjoint-sparse-table-414937-2026-11-03.json'},
 'unchanged':{'public_api':True,'driver_sha256':sha(driver),'common_io_sha256':sha(io),'main':True,'common_io':True,'query_and_boundary_search_implementation':True,'storage_layout_and_row_sizes':True,'copy_move_clear_swap':True,'construction_op_order_and_count':True,'ownership':'vectorの所有と例外時の後片付けを維持。直接のnew/deleteは追加しない。'},
 'adopted':{'condition':'std::is_integral_v<T> && !std::is_same_v<T,bool> && sizeof(T)>=4','description':'元列の全コピーで各行を作る代わりに、単位元で初期化する。各blockのsuffix起点middle-1とprefix起点middleを元列から設定し、残りを元と同じ順序で集約する。','fallback':'bool・8/16bit整数・独自型は元のコピー行を維持。原列を保持する第0行は全型で従来どおりコピー。','bounds':'begin<nかつhalf>=2なのでmiddle>beginでmiddle-1有効。middle<endのときだけright種とmiddle+1を使用。各blockの全セルを設定してから次へ進む。既存の倍化上限を維持。','type_requirements':'追加要件は整数型の経路だけに限定。非既定構築型・コピー専用型・bool proxyを従来経路で維持。'},
 'measurement_environment':{'cpu':'Intel Core i9-14900K','performance_cpus':[12,14],'core_kind':'どちらもP-Core、lscpuのcore index 6/7','governor':'powersave','fixed_frequency':False,'compilers':{'gcc':'15.2.0','clang':'21'},'flags':['-std=c++23','-O2'],'clang_extra':'--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','march_native':False,'checks':'SKIP_RUNTIME_CHECKS','concurrent_compilation_or_performance_runs':False,'scope':'CPU12で初回比較と構築単体、同一版の揺らぎが見られたためCPU14でも全16公式相当ケースを再測定。E-Coreは測定しない。'},
 'construction_protocol':{'source':'micro.cpp','raw':'micro_raw.json','cpu':12,'repetitions':9,'sizes_and_constructions_per_process':{'32':20000,'4096':150,'500000':3},'timer':'std::clockで反復構築・破棄と結果観測のall_prodを計時。入力生成と入出力を除く。','types':{'min':'int32最小値','sum32':'int32和','gcd32':'uint32 GCD','first32':'uint32最初の非0（非可換）','sum':'int64和','affine':'uint64の2要素配列の写像合成（非整数T、旧経路）','bool':'bool AND（旧経路）'},'control':'baseと同一バイナリを別ラベルで実行。固定seedで順序を混ぜ、実行ファイル名・CPU・コンパイラ設定を統一。'},
 'construction_results':mi,
 'whole_main_protocol':{'raw':'confirm_raw.json','cpu':14,'cases':16,'repetitions':21,'labels':['base','control','identity','threshold'],'timer':'wait4のuser+system CPU時間。user/system/wallを併記。main・共通IO・問題・flags・チェック設定を固定。','output_check':'全版・反復の出力SHAが一致。'},
 'whole_main_results':main,
 'machine_code_proof':{'actual_source_condition':'候補の全整数分岐を4byte以上へ絞った。測定対象の32/64bit整数・affine・boolに対するコードが同じことを確認。','section':'.text','results':text_proof,'scope':'GCC/Clangの提出用mainと混合型microで命令列が完全一致。8/16bit整数は性能の対象にせず、旧コピー経路を維持する。'},
 'assessment':{'large_construction':'n500000のmin/和32/和64/GCD32/非可換first32を総合し、GCC約2〜9%、Clang約8〜13%短縮（各条件の中央値）。','whole_main':'CPU14で各caseのidentity/base比の中央値はGCC約0.984、Clang約0.974。ただし同一版controlにも数%の揺らぎがあり、全体の追加短縮を確立したとは扱わない。','small_cost':'GCCの32/4096要素等で一部約5〜15%遅延。単位元初期化＋端点設定の負担がある。大規模構築の明確な改善を優先する既存方針に基づき採用。全条件で無退行とは主張しない。','interpretation':'構築単体は反復・確保器の再利用を含む。オンライン1回の全体時間と直接換算しない。','online_next':'同じmainで再提出してオンラインの結果を確認する。'},
 'rejected':['ゼロ初期化は単位元での初期化ほど安定した構築短縮が出ない。','元列読取を所有する第0行へ替える案は一部性能が揺れ、非整数Tの観測も変え得るので不採用。','32bit以下だけに絞る案は64bit和にも構築改善があるため不採用。8/16bitは旧経路に残す。','n*sizeof(T)相当の閾値でbuilderを分ける案はコードが増え、小規模の退行を完全には解消しないため不採用。','unroll pragmaは安定した改善がなく不採用。'],
 'correctness':{'normal_runs':tests,'profile_and_baseline_runs':profiles,'standard_cpp23':standard,'profile_samples':{'status':'LOCAL_SAMPLE_PASS','count':10,'evidence':'profile_runs/'+ps.name},'coverage':'正値min・負値max・非0単位元・8/16/32/64bit・型限界・n0/1/2・2冪±1と端数（16385まで）を独立参照で照合。新規整数テスト5192100項目、従来の静的表・非可換・bool・コピー/移動・演算順テストも通る。','allocation_failures':'整数のconstruction/assignを追加。4022項目、2541回の確保失敗、live_delta0。','sanitizers':'参照・型テストはASan+UBSan。独自new/delete置換の失敗試験は独立実行。LSanは環境制約によりdetect_leaks=0。','review':'別エージェントが行の全セル初期化、端数、Op順、bool/非既定構築型、所有権、添字と倍化上限を読み取り確認。'},
 'portability':'追加コードは標準C++23の範囲。専用CPU命令・新たなCPU判定や最適化pragmaは追加しない。SIRKIT_DISABLE_SIMD付きのpedanticビルドでも整数テストを実行。コンパイラや標準ライブラリの自動SIMDは除外対象とはしない。',
 'documentation':{'file':'Document/disjoint_sparse_table.md','changed':False,'reason':'公開API・重要な前提・所有権・計算量は不変。内部実装の注釈だけをソースへ、性能・検証記録はAuditへ配置。READMEに履歴を追加しない。'},
 'license':{'implementation':'CC0-1.0。今回の変更は自作の初期化・集約処理。外部実装のコードは追加しない。','input_generators':'既存のLibrary Checker公式生成器による入力を再利用。Apache-2.0生成器原ソースを本体・証跡ZIPへ同梱せず、URL/原ソースSHA/入力SHAをinputs_metadata.jsonへ保存。'},
 'evidence':{'file':'data/'+evidence.name,'sha256':sha(evidence),'bytes':evidence.stat().st_size,'scope':'自作ソース、比較プログラム、生測定、テスト結果を保存。実行バイナリ・巨大入力・公式生成器の原ソースは含めない。'},
 'resubmit':['Verify/current/submissions/disjoint_sparse_table.cpp']}
p=R/'Audit/performance-disjoint-sparse-table-integer-init-2026-11-03.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(p.name,'evidence_bytes',evidence.stat().st_size,'main_cases',len(main),'micro_cases',len(mi))
