# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,statistics,random,shutil,fcntl
D=Path('/tmp/sirkit_disjoint_followup_20261103');P=Path('/tmp/sirkit_disjoint_speed_20261103')
s=(P/'micro.cpp').read_text().replace('#include <limits>','#include <limits>\n#include <numeric>')
s=s.replace('struct Minimum {','struct Gcd32 { std::uint32_t operator()(std::uint32_t a,std::uint32_t b) const{return std::gcd(a,b);} };\nstruct First32 { std::uint32_t operator()(std::uint32_t a,std::uint32_t b) const{return a?a:b;} };\nstruct Minimum {')
s=s.replace('if(type=="sum")','if(type=="sum32")return run<std::int32_t,std::plus<std::int32_t>>(n,mode,reps,0);if(type=="gcd32")return run<std::uint32_t,Gcd32>(n,mode,reps,0);if(type=="first32")return run<std::uint32_t,First32>(n,mode,reps,0);if(type=="sum")')
(D/'micro.cpp').write_text(s)
s=(D/'identity.hpp').read_text();(D/'identity32.hpp').write_text(s.replace('std::is_integral_v<T> && !std::is_same_v<T, bool>','std::is_integral_v<T> && !std::is_same_v<T, bool> && sizeof(T) <= 4'))
v=['base','zero','identity','identity32'];raw=[];rng=random.Random(922780)
comps=[('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]
for cc,args in comps:
 for label in v:
  cmd=['taskset','-c','2',*args,'-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_DISJOINT_TEST_SOURCE="{D/(label+".hpp")}"',str(D/'micro.cpp'),'-o',str(D/f'micro_{cc}_{label}')];q=subprocess.run(cmd,capture_output=True,text=True);assert q.returncode==0,q.stderr
print('BUILT',flush=True)
with open('/tmp/sirkit_performance_cpu12.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc,_ in comps:
  for ty in ['min','sum32','gcd32','first32','sum','affine','bool']:
   for n,reps in [(32,20000),(4096,150),(500000,3)]:
    for rep in range(9):
     labels=v+['control'];rng.shuffle(labels);checks=[]
     for label in labels:
      shutil.copyfile(D/f'micro_{cc}_{"base" if label=="control" else label}',D/'active_micro');(D/'active_micro').chmod(0o700);p=subprocess.run(['taskset','-c','12',str(D/'active_micro'),str(n),'build',str(reps),ty],capture_output=True,text=True,check=True);check,ns=map(int,p.stdout.split());checks.append(check);raw.append(dict(compiler=cc,type=ty,n=n,rep=rep,repeated_operations=reps,label=label,cpu_ns=ns,checksum=check))
     assert len(set(checks))==1
    rs=[r for r in raw if (r['compiler'],r['type'],r['n'])==(cc,ty,n)];m={l:statistics.median(r['cpu_ns'] for r in rs if r['label']==l) for l in labels};print(cc,ty,n,{k:round(x/m['base'],4) for k,x in m.items()},flush=True);(D/'micro_raw.json').write_text(json.dumps(raw))
