# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,sys,json,struct,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_disjoint_followup_20261103');sys.path.insert(0,str(R/'Scripts'));import prepare_verify
src=(R/'DataStructure/Disjoint_Sparse_Table.cpp').read_bytes();(D/'selected.hpp').write_bytes(src);e=next(e for e in prepare_verify.collect() if e['id']=='disjoint_sparse_table');data,_=prepare_verify.render(e,source_overrides={'DataStructure/Disjoint_Sparse_Table.cpp':src});(D/'selected.cpp').write_bytes(data)
def text_bytes(p):
 b=p.read_bytes();assert b[:6]==b'\x7fELF\x02\x01';off=struct.unpack_from('<Q',b,40)[0];ent,count,idx=struct.unpack_from('<HHH',b,58);headers=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*ent) for i in range(count)];sh=headers[idx];strings=b[sh[4]:sh[4]+sh[5]]
 for sh in headers:
  name=strings[sh[0]:].split(b'\0',1)[0]
  if name==b'.text':return b[sh[4]:sh[4]+sh[5]]
 raise ValueError('text not found')
rows=[]
for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for kind,inp,flags,reference in [('main',D/'selected.cpp',[],D/f'th_main_{cc}_identity'),('micro',D/'micro.cpp',['-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_DISJOINT_TEST_SOURCE="{D/"selected.hpp"}"'],D/f'th_micro_{cc}_identity')]:
  exe=D/f'actual_{kind}_{cc}';cmd=['taskset','-c','4',*args,'-std=c++23','-O2',*flags,str(inp),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr
  a,b=text_bytes(exe),text_bytes(reference);match=a==b;print(cc,kind,'text_match',match,'bytes',len(a),len(b),flush=True);rows.append(dict(compiler=cc,kind=kind,command=cmd,source_sha256=hashlib.sha256(src).hexdigest(),reference=str(reference),text_equal=match,actual_text_sha256=hashlib.sha256(a).hexdigest(),reference_text_sha256=hashlib.sha256(b).hexdigest()))
(D/'text_match.json').write_text(json.dumps(rows,indent=2)+'\n')
