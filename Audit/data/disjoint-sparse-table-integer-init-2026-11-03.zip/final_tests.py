# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,os,hashlib
D=Path('/tmp/sirkit_disjoint_followup_20261103');R=Path('/home/reinsirk/Atcoder_Env');rows=json.loads((D/'final_tests.json').read_text()) if (D/'final_tests.json').exists() else [];env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'}
for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  for test in ['static_tables_reference_test','disjoint_sparse_table_storage_test','disjoint_sparse_table_integer_init_test','range_structures_allocation_test']:
   src=R/f'Verify/current/tests/{test}.cpp'
   old=[r for r in rows if (r['compiler'],r['skip_runtime_checks'],r['test'])==(cc,skip,test)]
   if old and old[0]['test_sha256']==hashlib.sha256(src.read_bytes()).hexdigest() and old[0]['returncode']==0:continue
   rows=[r for r in rows if (r['compiler'],r['skip_runtime_checks'],r['test'])!=(cc,skip,test)]
   exe=D/f'test_{cc}_{skip}_{test}';cmd=['taskset','-c','4',*args,'-std=c++23','-O2']
   if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
   if test!='range_structures_allocation_test':cmd+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
   if test in ['disjoint_sparse_table_storage_test','disjoint_sparse_table_integer_init_test']:cmd+=['-Wall','-Wextra','-Werror']
   cmd +=[str(src),'-o',str(exe)]
   p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,(cmd,p.stderr)
   p=subprocess.run(['taskset','-c','4',str(exe)],capture_output=True,text=True,env=env);rows.append(dict(compiler=cc,skip_runtime_checks=skip,test=test,command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,test_sha256=hashlib.sha256(src.read_bytes()).hexdigest()));print(cc,skip,test,p.returncode,p.stdout.strip(),flush=True);(D/'final_tests.json').write_text(json.dumps(rows,indent=2)+'\n');assert p.returncode==0 and not p.stderr,p.stderr
print('ALL PASS',flush=True)
