# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys,subprocess,json,random,statistics,shutil,os,time,fcntl,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_disjoint_followup_20261103');P=Path('/tmp/sirkit_sparse_speed_20261103');sys.path.insert(0,str(R/'Scripts'));import prepare_verify
s=(D/'before.hpp').read_text();old='''            table_.push_back(values);
            auto& row = table_.back();''';assert old in s
cond='std::is_integral_v<T> && !std::is_same_v<T, bool>'
seeds='''                if constexpr (''' +cond+''') row[middle - 1] = values[middle - 1];
'''
right='''                if (middle < end) {
                    if constexpr ('''+cond+''') row[middle] = values[middle];
                    for (auto i = middle + 1; i < end; ++i) row[i] = op_(row[i - 1], values[i]);
                }'''
rold='''                if (middle < end)
                    for (auto i = middle + 1; i < end; ++i) row[i] = op_(row[i - 1], values[i]);'''
v={'base':s}
for label,form in [('zero','table_.emplace_back(n);'),('identity','table_.emplace_back(n, identity_);')]:
 h=s.replace(old,'            if constexpr ('+cond+') '+form+'\n            else table_.push_back(values);\n            auto& row = table_.back();')
 h=h.replace('                for (auto i = middle; i > begin + 1;',seeds+'                for (auto i = middle; i > begin + 1;').replace(rold,right)
 v[label]=h
for label in ['zero','identity']:
 h=v[label].replace('            auto& row = table_.back();','            auto& row = table_.back();\n            const auto& input = table_.front();')
 beg=h.index('            for (std::size_t begin = 0;');end=h.index('            if (half > ',beg)
 h=h[:beg]+h[beg:end].replace('values[','input[')+h[end:];v[label+'_owned']=h
h=s.replace('            auto& row = table_.back();','            auto& row = table_.back();\n            const auto& input = table_.front();');beg=h.index('            for (std::size_t begin = 0;');end=h.index('            if (half > ',beg);v['owned']=h[:beg]+h[beg:end].replace('values[','input[')+h[end:]
v['unroll4']=s.replace('                    for (auto i = middle + 1;','''#pragma GCC unroll 4
                    for (auto i = middle + 1;''')
e=next(e for e in prepare_verify.collect() if e['id']=='disjoint_sparse_table')
for label,src in v.items():
 (D/f'{label}.hpp').write_text(src);data,_=prepare_verify.render(e,source_overrides={'DataStructure/Disjoint_Sparse_Table.cpp':src.encode()});(D/f'{label}.cpp').write_bytes(data)
 for cc,cmd in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  q=subprocess.run(['taskset','-c','2',*cmd,'-std=c++23','-O2',str(D/f'{label}.cpp'),'-o',str(D/f'{cc}_{label}')],capture_output=True,text=True);assert q.returncode==0,q.stderr
print('BUILT',flush=True)
cases=['official_random_0','official_random_2','official_max_random_0','official_small_width_query_0','official_small_width_query_3','32_random','4096_random','4096_build','500000_build'];raw=[];rng=random.Random(774310)
with open('/tmp/sirkit_performance_cpu12.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for case in cases:
   inp=P/((case if case.startswith('official') else 'input_'+case)+'.in')
   for rep in range(9):
    labels=list(v)+['control'];rng.shuffle(labels)
    for label in labels:
     shutil.copyfile(D/f'{cc}_{"base" if label=="control" else label}',D/'active');(D/'active').chmod(0o700)
     with inp.open('rb') as fi,(D/'output').open('wb') as fo:
      st=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,status,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status);assert p.returncode==0
      cpu=round((ru.ru_utime+ru.ru_stime)*1e9);wall=time.perf_counter_ns()-st
     raw.append(dict(compiler=cc,case=case,rep=rep,label=label,cpu_ns=cpu,wall_ns=wall,sha256=hashlib.sha256((D/'output').read_bytes()).hexdigest()))
   rows=[r for r in raw if r['compiler']==cc and r['case']==case];assert len({r['sha256'] for r in rows})==1
   m={l:statistics.median(r['cpu_ns'] for r in rows if r['label']==l) for l in labels};print(cc,case,{k:round(x/m['base'],4) for k,x in m.items()},flush=True);(D/'screen_raw.json').write_text(json.dumps(raw))
