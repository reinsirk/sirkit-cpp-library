# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_disjoint_followup_20261103');rows=[]
profiles=[('baseline_gcc','gcc',D/'before.hpp'),('baseline_clang','clang',D/'before.hpp')]+[(profile.replace('/','_'),cc,R/profile/'DataStructure/Disjoint_Sparse_Table.cpp') for profile,cc in [('Variants/GCC','gcc'),('Variants/Clang','clang'),('Fast/GCC','gcc'),('Fast/Clang','clang')]]
profiles=[(label+'_'+test,cc,src,test) for label,cc,src in profiles for test in ['disjoint_sparse_table_storage_test','disjoint_sparse_table_integer_init_test']]
for label,cc,src,test_name in profiles:
 args=['/usr/bin/g++'] if cc=='gcc' else ['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'];exe=D/('profile_'+label);test=R/('Verify/current/tests/'+test_name+'.cpp');cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror','-DSKIP_RUNTIME_CHECKS',f'-DSIRKIT_DISJOINT_TEST_SOURCE="{src}"',str(test),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','4',str(exe)],capture_output=True,text=True);assert p.returncode==0 and not p.stderr,(label,p.stdout,p.stderr);rows.append(dict(profile=label,compiler=cc,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),test_sha256=hashlib.sha256(test.read_bytes()).hexdigest(),command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));print(label,p.stdout.strip(),flush=True);(D/'profile_tests.json').write_text(json.dumps(rows,indent=2)+'\n')
