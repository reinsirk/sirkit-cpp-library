# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,datetime,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_disjoint_followup_20261103');a=json.loads((D/'414937.json').read_text());s=a['source'];p=R/'Verify/current/submissions/disjoint_sparse_table.cpp'
def norm(x):return '\n'.join(l.rstrip() for l in x.splitlines() if l.strip() and not l.startswith('// Submission:'))
assert norm(s)==norm(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();o=a['overview'];assert o['status']=='AC'
record={'id':'disjoint_sparse_table','status':'AC','url':'https://judge.yosupo.jp/submission/414937','time_ms':round(o['time']*1000),'memory_bytes':o['memory'],'language':o['lang'],'submission_time':o['submission_time'],'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'case_results':a['case_results'],'submission_sha256':sha(p),'uploaded_source_sha256':hashlib.sha256(s.encode()).hexdigest(),'source_hashes':{'DataStructure/Disjoint_Sparse_Table.cpp':sha(R/'DataStructure/Disjoint_Sparse_Table.cpp')},'driver_sha256':sha(R/'Verify/current/drivers/disjoint_sparse_table_main.cpp'),'io_source_hashes':{'Verify/current/common/fast_io.hpp':sha(R/'Verify/current/common/fast_io.hpp')},'io_mode':'shared_fast_io','matched_current_generation':True,'needs_resubmission':False,'source_match':'改行・空行・行末空白・Submission注記を除いて現行の本体・main・共通I/Oと一致。','evidence_file':'Audit/online-disjoint-sparse-table-414937-2026-11-03.json'}
(R/record['evidence_file']).write_text(json.dumps({'scope':'ACは提出時の本体のみ。後続の候補へ転記しない。','endpoint':'https://v3.api.judge.yosupo.jp/submissions/414937','record':record},ensure_ascii=False,indent=2)+'\n')
jp=R/'Verify/current/judgements.json';j=json.loads(jp.read_text());old=[x for x in j['entries'] if x.get('id')==record['id']];assert len(old)<=1
j['entries']=[x for x in j['entries'] if x.get('id')!=record['id']]+[record];jp.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(R/'Audit/data/disjoint-sparse-table-online-414937-2026-11-03.zip','w',zipfile.ZIP_DEFLATED) as z:z.write(D/'414937.json','public_api_response.json');z.write(D/'uploaded.cpp','uploaded.cpp')
print('AC',record['time_ms'],'matches_current',True)
