# SPDX-License-Identifier: CC0-1.0
# 完了済みの測定・検証だけから監査案と証跡ZIPを/tmpへ作る。正本へは書かない。
from pathlib import Path
import hashlib
import json
import math
import shutil
import statistics
import zipfile

R = Path('/home/reinsirk/Atcoder_Env')
D = Path('/tmp/sirkit_ntt_416559')
P = Path('/tmp/sirkit_ntt_416532')
CHOSEN = 'padded_quarter'
PERFORMANCE = 'Audit/performance-ntt-416559-2026-11-12.json'
EVIDENCE = 'Audit/data/performance-ntt-416559-2026-11-12.zip'
ONLINE = 'Audit/online-ntt-416559-2026-11-12.json'
PREVIOUS = 'Audit/distribution-manifest-before-ntt-416559-2026-11-12.json'
LIBRARY = 'Math/NTT.cpp'


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def encode(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + '\n'


def qualified(row, candidate=CHOSEN, control_minimum=2):
    return (row['valid_counts'][candidate] >= 5 and
            row['valid_counts']['control'] >= control_minimum and
            row['ratios'][candidate] is not None and row['ratios']['control'] is not None)


def stats(rows, fields, candidate=CHOSEN, control_minimum=2):
    result = []
    for key in sorted({tuple(row[k] for k in fields) for row in rows}):
        matching = [row for row in rows if tuple(row[k] for k in fields) == key]
        selected = [row for row in matching if qualified(row, candidate, control_minimum)]
        if selected:
            result.append(dict(zip(fields, key)) | dict(
                total_cells=len(matching), qualified_cells=len(selected),
                candidate_ratio=math.exp(statistics.mean(math.log(row['ratios'][candidate]) for row in selected)),
                identical_control_ratio=math.exp(statistics.mean(math.log(row['ratios']['control']) for row in selected)),
                minimum_ratio=min(row['ratios'][candidate] for row in selected),
                maximum_ratio=max(row['ratios'][candidate] for row in selected)))
    return result


def main():
    before = sha(D / 'before' / LIBRARY)
    after = sha(R / LIBRARY)
    assert before == sha(D / 'base.hpp') and before != after
    assert after == sha(D / 'final.hpp'), '正本と検証用final.hppが不一致'
    candidate_hash = sha(D / (CHOSEN + '.hpp'))
    frozen = ['Verify/current/drivers/ntt_convolution_main.cpp',
              'Verify/current/common/fast_io.hpp', 'Examples/ntt_example.cpp', 'Document/ntt.md']
    for relative in frozen:
        assert (R / relative).read_bytes() == (D / 'before' / relative).read_bytes(), relative
    assert (R / 'Verify/current/submissions/ntt_convolution.cpp').read_bytes() == (D / 'final_main.cpp').read_bytes()

    validation = load(D / 'final_validation.json')
    assert validation['header_sha256'] == after
    assert validation['all_passed'] and validation['passed_jobs'] == validation['total_jobs'] == len(validation['jobs']) == 44
    assert all(row.get('passed') and row['compile_returncode'] == row['returncode'] == 0 and not row['stderr'] for row in validation['jobs'])
    test_names = ['ntt_montgomery_reference_test.cpp', 'formal_power_series_reference_test.cpp',
                  'string_math_allocation_test.cpp']
    test_hashes = {name: sha(R / 'Verify/current/tests' / name) for name in test_names}
    for row in validation['jobs']:
        assert row['test_sha256'] == test_hashes[row['test'] + '.cpp'], '検査後にテストが変更された'
    assert sha(D / 'reference_test_before.cpp') != test_hashes[test_names[0]], 'padding境界検査を含む更新済み参照テストが必要'
    allocation = [row['counters'] for row in validation['jobs'] if row['test'] == 'string_math_allocation_test']
    assert len(allocation) == 12 and all(row['live_delta'] == 0 for row in allocation)
    profile = load(D / 'profiles/checkpoint.json')
    assert profile['counts'] == {'LOCAL_SAMPLE_PASS': 10}
    assert profile['status'] == 'local_samples_passed_for_snapshot' and profile['completed_at_utc'] and profile['active'] is None, '派生版・使用例の検証が未完了'

    bridge = load(D / 'text_correspondence.json')
    assert isinstance(bridge, list) and bridge
    assert all(row.get('final_matches_measured', row.get('final_matches_baseline')) is True for row in bridge)
    assert {(cc, 'main') for cc in ('gcc', 'clang')} <= {(row['compiler'], row['kind']) for row in bridge}
    assert {(cc, setting) for cc in ('gcc', 'clang') for setting in ('checked', 'skip')} <= {
        (row['compiler'], row['setting']) for row in bridge if row['kind'] == 'core'}

    standard = load(D / 'standard_builds.json')
    assert len(standard) == 8
    standard_by_key = {(row['compiler'], row['setting'], row['label']): row for row in standard}
    standard_matches = []
    for cc in ('gcc', 'clang'):
        for setting in ('checked', 'skip'):
            pair = [standard_by_key[cc, setting, label] for label in ('base', 'final')]
            for label, row in zip(('base', 'final'), pair):
                assert row['text_sha256'] == sha(D / f'{cc}_{setting}_standard_{label}_core.text')
            standard_matches.append(dict(compiler=cc, setting=setting,
                base_text_sha256=pair[0]['text_sha256'], final_text_sha256=pair[1]['text_sha256'],
                identical=pair[0]['text_sha256'] == pair[1]['text_sha256']))
    standard_performance = None
    if not all(row['identical'] for row in standard_matches):
        standard_performance = load(D / 'standard_summary.json')
        assert standard_performance and all(qualified(row, 'final', 5) and row['sufficient'] for row in standard_performance)
        assert {(row['compiler'], row['setting']) for row in standard_performance} == {
            (cc, setting) for cc in ('gcc', 'clang') for setting in ('checked', 'skip')}

    whole = load(D / 'paired_whole_summary.json')
    core = load(D / 'paired_core_summary.json')
    focused = load(D / 'focused_summary.json')
    assert len(whole) == 68 and all(qualified(row) and row['sufficient'] for row in whole)
    assert len(core) == 164
    insufficient = [row for row in core if not qualified(row)]
    assert len(insufficient) == 2 and {(row['compiler'], row['setting'], row['op'], row['n'], row['m']) for row in insufficient} == {
        ('gcc', 'checked', 6, 1024, 1024), ('clang', 'skip', 6, 1024, 1024)}
    assert all(row['valid_counts'][CHOSEN] == 4 for row in insufficient)
    assert len(focused) == 40 and all(qualified(row, 'final', 5) and row['sufficient'] for row in focused)
    focused_cases = {(6, 128), (6, 1024), (4, 128), (4, 1024), (5, 1024),
                     (4, 65536), (4, 524288), (5, 524288), (0, 524288), (3, 524288)}
    assert {(row['compiler'], row['setting'], row['op'], row['n']) for row in focused} == {
        (cc, setting, op, n) for cc in ('gcc', 'clang') for setting in ('checked', 'skip') for op, n in focused_cases}

    fixtures = load(D / 'fixtures.json')
    assert len(fixtures) == 73 and (D / 'fixtures.json').read_bytes() == (Path('/tmp/sirkit_ntt_416541') / 'fixtures.json').read_bytes()
    outputs = load(D / 'whole_output_validation.json')
    assert len(outputs) == 146 and {(row['compiler'], row['case']) for row in outputs} == {
        (cc, fixture['name']) for cc in ('gcc', 'clang') for fixture in fixtures}
    online = load(D / 'online_records.json')
    record = next(row for row in online['records'] if row['id'] == 'ntt_convolution')
    assert record['url'] == 'https://judge.yosupo.jp/submission/416559' and record['time_ms'] == 53 and record['status'] == 'AC'
    assert record['source_hashes'] == {LIBRARY: before}, '今回のACを新しい本体へ転記しない'
    journal = next(row for row in load(R / 'Verify/current/judgements.json')['entries'] if row['id'] == 'ntt_convolution')
    assert journal['url'] == record['url'] and journal['time_ms'] == 53 and journal['needs_resubmission'] and not journal['matched_current_generation']
    assert journal['current_source_hashes'] == {LIBRARY: after}

    dependent = []
    for relative in ['Math/Formal_Power_Series.cpp', 'Math/Linear_Recurrence.cpp', 'Math/Convolution.cpp', 'Math/Polynomial.cpp']:
        dependent.append(dict(path=relative, before_sha256=sha(D / 'before' / relative), after_sha256=sha(R / relative)))
    for name in test_names:
        target = D / 'evidence_tests' / name
        target.parent.mkdir(exist_ok=True)
        shutil.copyfile(R / 'Verify/current/tests' / name, target)
    metadata = D / 'fixtures_metadata'
    metadata.mkdir(exist_ok=True)
    for name in ['source_audit.json', 'commands.json', 'summary.json']:
        shutil.copyfile(P / 'fixtures' / name, metadata / name)

    audit = dict(
        date='2026-11-12', library=LIBRARY,
        decision='adopt_zero_padded_first_stage_and_simd_blend_quarter_root',
        required_resubmission=['Verify/current/submissions/ntt_convolution.cpp'],
        online_evidence=ONLINE,
        online_scope='416559は変更前の83d672本体で全53ケースAC・53ms。提出本文とその本体/main/共通IOを照合済み。今回採用した本体は未提出で、このACを現行版や派生版へ転記しない。',
        source_sha256=dict(before=before, after=after), measured_candidate_sha256=candidate_hash,
        comment_bridge='測定済みpadded_quarterと最終版はコメント・maybe_unused・標準経路の直接呼び出しを区別して保存。GCC/Clangの既定経路の実行コード一致はtext_correspondence.jsonで確認し、標準経路は別に比較する。',
        frozen_main_IO_example={relative: sha(R / relative) for relative in frozen},
        API_change='公開API・型引数・前提・戻り値・所有権は不変。新しい別名や公開操作は追加しない。Documentと使用例も変更しない。',
        changes=[
            'compute/squareで所有する変換バッファの元の長さを保ち、元長さが変換長の半分以下なら後半が追加ゼロであることを利用する。初段radix4でゼロの読み込み・符号化・積を省き、その後は通常と同じ段を進める。公開transformにはこの前提を適用しない。',
            'SIMD Montgomery積の偶数・奇数64bit積からの結果の詰め直しをblendにする。採用される全32bitレーンは従来のshift/ORと同じで、積とqは変えない。',
            '末尾4点段の根[1,i]の反復では、偶数レーンへの1の積を省き、奇数レーンだけ従来と同じMontgomery積を行う。lazy表現はModだけ異なる場合があるが値域[0,2Mod)と合同関係を保ち、後続演算と最終正規化結果が一致する。',
            '対応Mod・CPU・コンパイラ・長さの条件を満たさない場合は標準経路へ戻す。係数チェック・SKIP除外・容量保護・確保/解放・既存のconstexpr根と逆元計算を維持。入力値分布や問題固有条件を使わず、初段の代数式と実際の追加ゼロだけを利用する。'],
        proof_files=['review/review.md', 'review/padded_review.md', 'review/metadata.json'],
        dependent_generated_sources=dependent,
        candidates=[dict(name=name, sha256=sha(D / (name + '.hpp')), adopted=name == CHOSEN)
                    for name in ['padded', 'blend', 'padded_blend', 'quarter', CHOSEN]],
        measurement=dict(
            topology=load(D / 'topology.json'), cpu='i9-14900KのCPU12（P-Core、sibling13）。E-Coreは対象外。',
            compilers=dict(GCC='15.2.0', Clang='21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'),
            flags=['-std=c++23', '-O2'], march_native=False, extra_pragmas=False,
            compilation_during_timing=False, lock='/tmp/sirkit_performance_cpu12.lock',
            ASLR='子だけsetarch x86_64 -R。同じactiveパスへ実行体を置く。',
            protocol='旧版→候補→旧版の組で候補を両端の中央値で割る。両端が10%以内の組のみ有効、候補自身の時間では除外しない。基本は候補9組・同一実行体対照3組を決定的shuffleし、不足種だけ最大3回各3組補充。候補5組・対照2組を基準とする。長時間再確認は候補9組・対照9組、両方5組以上を要求する。',
            inputs='固定revision73876f1cbcf082d2b22722924b924d3d65a2f00eの公式53入力と補足20入力。73件。制約外1048576×1048576も含む。オンラインの非公開入力と同一とは主張しない。',
            fixtures_sha256=sha(D / 'fixtures.json'),
            independent_outputs='38件の独立な全出力SHA、全入力の端点と多項式評価0/1/−1。GCC/Clangで全73入力の前後出力SHAも一致。',
            whole_time='固定main/共通IO/SKIP/コンパイラ/入力で子のuser+system CPU時間。L>=65536またはmax(n,m)>=200000の34入力×2compiler。',
            whole_rows=len(whole), whole_triplets=len(load(D / 'paired_whole_raw.json')),
            whole_comparisons_sufficient=True, whole_statistics=stats(whole, ['compiler']),
            official_whole_statistics=stats([row for row in whole if row['case'].startswith('official_')], ['compiler']),
            core_time='std::clockのプロセスCPU時間。入力準備は外、API計算・全結果checksum・返却結果破棄は内。coldでは毎回NTTを作成/解放。prepareは計測外transformで根を観測する。基本反復max(1,32768/max(n,m))。',
            core_operations={0: 'normalized cold move', 1: 'normalized cached move', 2: 'generic int64 cached',
                             3: 'square cached', 4: 'forward', 5: 'inverse', 6: 'prepare cold'},
            core_rows=len(core), core_triplets=len(load(D / 'paired_core_raw.json')),
            qualified_core_cells=len(core) - len(insufficient), insufficient_core_cells=insufficient,
            core_limit='164条件中162条件が基本基準を満たす。GCC checkedとClang skipのprepare1024は候補4組に留まるため、164条件すべてで基準達成とは扱わない。この2条件を含む長時間40条件で再確認する。',
            core_statistics=stats(core, ['compiler', 'setting', 'op']),
            large_core_statistics=stats([row for row in core if max(row['n'], row['m']) >= 200000], ['compiler', 'setting', 'op']),
            cold_524288=stats([row for row in core if row['op'] == 0 and row['n'] == row['m'] == 524288], ['compiler', 'setting']),
            focused_long_repetitions=dict(cells=len(focused), triplets=len(load(D / 'focused_raw.json')),
                all_qualified=True, statistics=stats(focused, ['compiler', 'setting', 'op'], 'final', 5), rows=focused),
            standard_path=dict(machine_code=standard_matches, performance=standard_performance,
                scope='標準経路は既定SIMD経路の測定とは区別する。同一.textなら追加高速化を主張しない。異なる場合は別のstandard_summary.jsonを必須とする。'),
            comparison_outputs_equal=True, no_claim_every_condition_faster=True,
            outcome='大規模固定main全体の幾何平均でGCC約3.8%、Clang約1.5%短縮。524288要素どうしの畳み込み本体は基本/長時間確認でGCC約8〜11%、Clang約4〜5%短縮。前回のconstexpr根・直接逆元・直接積の改善を維持。',
            small_case_tradeoff='長時間確認でもClang checked inverse1024は約5.35%後退（同一実行体対照約-0.45%）。小規模の多少の後退を大規模の明確な改善で許容する既存の方針に沿い採用する。全条件で高速とは主張しない。Clang skip forward65536の初回約9.1%後退は8回反復では約0.77%短縮となり、大きな差が安定して再現しない。基本rawと長時間rawの両方を保存。'),
        validation=dict(jobs=44, all_passed=True, tests_sha256=test_hashes,
            previous_reference_test_sha256=sha(D / 'reference_test_before.cpp'),
            added_reference_cases='ゼロpaddingの半分以下/半分超の境界、奇偶log2長と複数法を、全1列の重なり個数という独立な閉形式で照合する検査を追加。各7刻みと末尾の正規化違反も検査。既存の独立DFT/直接積・所有権・境界検査を維持。',
            conditions='GCC/Clang×検査有効/無効×default/SIRKIT_DISABLE_SIMD/CPU判定falseの検査用ヘッダー。ASAN+UBSANは両compiler・両検査設定・default/SIMD無効。',
            allocation=allocation, sanitizers='host ptraceのためdetect_leaks=0。解放は別のlive counterでも全12条件live_delta=0を確認。',
            machine_code_evidence=bridge, profiles=dict(status=profile['status'], counts=profile['counts'], run_id=profile['run_id']),
            current_submission_exactly_matches_compiled_final=True,
            current_submission_bytes=(R / 'Verify/current/submissions/ntt_convolution.cpp').stat().st_size,
            dependency_regeneration='4つの単独貼り付け用依存本体・compiler/Fast派生版・Verifyを同期する。最終配布検査はDistribution/validation.jsonへ別途保存。'),
        license='既存CC0の独自NTTに独自実装を追加。外部実装コードは取り込まない。公式生成器はURL・固定SHAのメタデータのみ記録し、証跡ZIPへ本体を含めない。',
        evidence_archive=EVIDENCE,
        evidence_scope='候補・生成手順・独立参照テスト・代数レビュー・API原本・測定raw・検証コマンド。巨大入力/出力、実行体、外部生成器コードを除外。')

    draft = D / Path(PERFORMANCE).name
    evidence = D / Path(EVIDENCE).name
    previous = D / Path(PREVIOUS).name
    previous.write_bytes((D / 'before/Distribution/manifest.json').read_bytes())
    (D / 'audit_draft.json').write_text(encode(audit))
    excluded = {'audit_draft.json', draft.name, 'distribution_update.log'}
    paths = []
    for path in D.rglob('*'):
        if not path.is_file() or path.name in excluded or path.suffix not in {'.py', '.hpp', '.cpp', '.json', '.diff', '.md', '.log'}:
            continue
        relative = path.relative_to(D)
        if relative.parts[0] == 'profiles' and (path.suffix != '.json' or
                (len(relative.parts) > 1 and relative.parts[1] in {'snapshots', 'artifacts', 'sources'})):
            continue
        paths.append(path)
    with zipfile.ZipFile(evidence, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(paths):
            archive.write(path, path.relative_to(D).as_posix())
    audit['evidence_archive_sha256'] = sha(evidence)
    draft.write_text(encode(audit))
    print(encode(dict(audit=str(draft), audit_target=PERFORMANCE, evidence=str(evidence), evidence_target=EVIDENCE,
        previous_manifest=str(previous), previous_manifest_target=PREVIOUS,
        evidence_bytes=evidence.stat().st_size, evidence_files=len(paths), repository_written=False)), end='')


if __name__ == '__main__':
    main()
