# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import difflib,json,hashlib
D=Path('/tmp/sirkit_ntt_416559');base=(D/'base.hpp').read_text();s=base
s=s.replace('template<bool Check>\n    [[gnu::target("avx2")]]\n    void forward_avx2','template<bool Check, bool SkipFirst = false>\n    [[gnu::target("avx2")]]\n    void forward_avx2',1)
a=s.index('    void forward_avx2');b=s.index('    template<bool Check>\n    [[gnu::target("avx2")]]\n    void backward_avx2',a)
part=s[a:b].replace('std::size_t length=n;','std::size_t length=SkipFirst ? n/4 : n;').replace('if(length==n) {','if constexpr (!SkipFirst) if(length==n) {').replace('if(length==n){u=encode(u);v=encode(v);}','if constexpr (!SkipFirst) if(length==n){u=encode(u);v=encode(v);}')
s=s[:a]+part+s[b:]
helper='''    template<bool Check>
    [[gnu::target("avx2")]]
    void forward_zero_padded_avx2(std::vector<std::uint32_t>& a) const {
        const auto n=a.size(), quarter=n/4;
        const auto r2=_mm256_set1_epi32(static_cast<int>(r_squared_));
        // 後半はresizeが補ったゼロ。初段のゼロの符号化と積を省く。
        for(std::size_t j=0;j<quarter;j+=8) {
            auto x0=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+j));
            auto x1=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+quarter+j));
#ifndef SKIP_RUNTIME_CHECKS
            if constexpr(Check){vector_check(x0);vector_check(x1);}
#endif
            x0=vector_multiply(x0,r2);x1=vector_multiply(x1,r2);
            const auto first=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data()+2*quarter+j));
            const auto second=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data()+3*quarter+j));
            const auto third=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data()+quarter+j));
            const auto v2=vector_multiply(x0,first),v3=vector_multiply(x1,second);
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+j),vector_add(x0,x1));
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+quarter+j),vector_multiply(vector_subtract(x0,x1),third));
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+2*quarter+j),vector_add(v2,v3));
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+3*quarter+j),vector_multiply(vector_subtract(v2,v3),third));
        }
        forward_avx2<false,true>(a);
    }
'''
pos=s.index('    template<bool Check>\n    [[gnu::target("avx2")]]\n    void backward_avx2');s=s[:pos]+helper+s[pos:]
helper2='''    template<bool Check>
    void forward_padded(std::vector<std::uint32_t>& a, std::size_t input_size) const {
#if !defined(SIRKIT_DISABLE_SIMD) && (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__i386__))
        if constexpr(montgomery_) if(a.size()>=32 && input_size<=a.size()/2 && use_avx2(a.size())) {
            forward_zero_padded_avx2<Check>(a);return;
        }
#endif
        forward<Check>(a);
    }
'''
pos=s.index('    template <bool Check>\n    void backward(');s=s[:pos]+helper2+s[pos:]
s=s.replace('a.resize(length); b.resize(length);\n        forward<Check>(a); forward<Check>(b);','const auto input_a=a.size(), input_b=b.size();\n        a.resize(length); b.resize(length);\n        forward_padded<Check>(a,input_a); forward_padded<Check>(b,input_b);')
s=s.replace('forward<false>(x);','forward_padded<false>(x,a.size());')
(D/'padded.hpp').write_text(s)
(D/'padded.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='base.hpp',tofile='padded.hpp')))
print('candidate bytes',len(s.encode()))
