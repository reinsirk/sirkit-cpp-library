import pathlib,subprocess,json,hashlib
r=pathlib.Path('/home/reinsirk/Atcoder_Env');d=pathlib.Path('/tmp/sirkit_ntt_416559/review')
records=[]
for name in ['blend_pack','quarter_root']:
 for cc,args in [('gcc',['g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for setting,flags in [('checked',[]),('skip',['-DSKIP_RUNTIME_CHECKS'])]:
   binary=d/f'{cc}_{setting}_{name}_reference';h=d/f'{name}.hpp'
   cmd=['taskset','-c','6',*args,'-std=c++23','-O2',*flags,'-include',str(h),f'-DNTT_HEADER="{h}"',str(r/'Verify/current/tests/ntt_montgomery_reference_test.cpp'),'-o',str(binary)]
   p=subprocess.run(cmd,capture_output=True,text=True);v={'name':name,'compiler':cc,'setting':setting,'header_sha256':hashlib.sha256(h.read_bytes()).hexdigest(),'compile_command':cmd,'compile_returncode':p.returncode,'compile_stderr':p.stderr}
   if p.returncode==0:
    q=subprocess.run(['taskset','-c','6',str(binary)],capture_output=True,text=True);v.update(returncode=q.returncode,stdout=q.stdout,stderr=q.stderr)
   records.append(v);(d/'validation.json').write_text(json.dumps(records,ensure_ascii=False,indent=2));print(name,cc,setting,v.get('returncode',p.returncode),v.get('stdout',''),flush=True)
   if p.returncode or v.get('returncode',1):raise RuntimeError(v)
