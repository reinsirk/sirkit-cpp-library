# Padding-aware first-stage review

Reviewed only; no builds or timings were run during root's CPU12 screen.

- padded.hpp SHA256 `56270ecf82ac929e4ce86029757caf401518a7e665b545d800d5aee3cc44b5ac`
- padded_quarter.hpp SHA256 `64620159ce60f260351d05bb3a95394d56b73d0698adad02eb71082be3ad5add`

No correctness defect found in either candidate.

## Zero-padding precondition

`compute` records both original vector lengths before `resize(length)`. For the transformed input, original length <= length/2 establishes that indices [length/2,length) were appended and value-initialized to zero. In square, the whole vector is value-initialized before copying/normalizing the original prefix, so the same implication holds. The new entry is private and is called only from those two sites. Public `transform` does not supply or assume padding information.

## First stage

With q=n/4, ordinary first-stage radix4 has x2=x3=0, hence v0=x0, v1=x1, v2=x0*roots[2q+j], v3=x1*roots[3q+j]. The new four stores are exactly the corresponding butterfly outputs. The two nonzero input vectors are still encoded once. The zero vectors may be omitted because encode(0)=0, and all arithmetic remains inside [0,2Mod) using the existing lazy Montgomery operators.

The initial loop covers [0,n/2) once, including every original input coefficient. Under Check=true, vector_check therefore checks every original value and may also check appended zeros. No original coefficient's check is lost; only values known to be appended zeros are not read. SKIP removes the same check code as before. Invalid coefficients may produce exceptions after earlier private chunks were modified; convolution owns its by-value buffers, and square owns its private buffer. Original caller vectors remain unchanged.

## Remaining stages and boundaries

The eligibility gate requires n>=32, power-of-two length already established by transform_size/prepare. Thus q>=8 and q is a multiple of8. Every vector load/store fits its [q] quarter, and roots accesses stay below n. After completing length=n stage, `forward_avx2<false,true>` starts at n/4, matching the existing radix4 progression exactly. If this leaves length16 it uses the existing radix2 stage before the final8 kernel; if it leaves length8 the suffix kernel is already the next stage. This holds for both even and odd log2(n), including hypothetical private n32 and n64 uses. Checks/encoding in the remaining stages are correctly suppressed: all coefficients were checked/encoded in the omitted first stage.

The API's actual NTT convolution path has both lengths>32, so n>=128. Small/empty/naive paths are unchanged. Length/result/capacity overflow checks remain before allocation/transform; n<=2^rank<=2^30 and q/j arithmetic cannot overflow a supported size_t. No changes to root indexing or preparation.

## Dispatch and generality

Mod<2^30, CPU AVX2, supported compiler/x86, n>=32 and original_length<=n/2 are all required. Mod>=2^30, unsupported CPU/compiler/architecture or SIRKIT_DISABLE_SIMD takes the unchanged `forward<Check>`. Modulus/root templates remain generic. The optimization follows exact vector lengths, without examining coefficient distributions or relying on a judge-specific property.

By-value vectors `a,b` own independent storage, even if callers supplied the same source twice. The optimization operates on one vector at a time, and roots storage is independent. Square uses the same private vector in the existing pointwise square only after forward completes. Allocation/ownership/copy/move/cache behavior is unchanged; no pointer is retained and no alias assumption is added.

## quarter-root and blend combination

The padded_quarter candidate differs from padded only by the independently reviewed two result-packing changes and odd-only fourth-root products. Those changes preserve exact bits (packing) or residue plus [0,2Mod) bounds (identity twiddle omission); they apply after the first padded stage exactly as in the ordinary forward/backward paths. Roots[2] is always Montgomery one because preparation copies roots[1] into it. No additional padding-specific interaction exists. The prior independent test results for these arithmetic changes do not substitute for root's whole combined-candidate validation.
