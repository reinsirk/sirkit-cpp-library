# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json
D=Path('/tmp/sirkit_ntt_416559');a={'cpu':12,'cpu_info':subprocess.check_output(['lscpu'],text=True)}
for f in ['topology/core_id','topology/thread_siblings_list','cpufreq/cpuinfo_max_freq']:
 a[f]=Path('/sys/devices/system/cpu/cpu12',f).read_text().strip()
(D/'topology.json').write_text(json.dumps(a,indent=2)+'\n')
