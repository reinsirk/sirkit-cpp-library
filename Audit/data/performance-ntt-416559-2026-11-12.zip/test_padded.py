from pathlib import Path
import subprocess,json
D=Path('/tmp/sirkit_ntt_416559');R=Path('/home/reinsirk/Atcoder_Env');rows=[]
for cc,args in [('gcc',['g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for st in ['checked','skip']:
  exe=D/f'{cc}_{st}_padded_test';cmd=['taskset','-c','4',*args,'-std=c++23','-O2',*(['-DSKIP_RUNTIME_CHECKS']if st=='skip'else[]),f'-DNTT_HEADER="{D}/padded.hpp"',str(R/'Verify/current/tests/ntt_montgomery_reference_test.cpp'),'-o',str(exe)]
  a=subprocess.run(cmd,capture_output=True,text=True);assert a.returncode==0,a.stderr
  p=subprocess.run(['taskset','-c','4',str(exe)],capture_output=True,text=True);rows.append(dict(compiler=cc,setting=st,command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));assert p.returncode==0,rows[-1]
  print(cc,st,p.stdout.strip(),flush=True)
(D/'padded_tests.json').write_text(json.dumps(rows,indent=2)+'\n')
