// SPDX-License-Identifier: CC0-1.0
#include HEADER
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <random>
#include <vector>
#include <utility>
std::uint64_t digest=1469598103934665603ULL;
void consume(const std::vector<std::uint32_t>& x){for(auto v:x)digest=(digest^v)*1099511628211ULL;}
int main(int argc,char**argv){
 if(argc!=5)return 2;
 const int op=std::atoi(argv[1]);const std::size_t n=std::strtoull(argv[2],nullptr,10),m=std::strtoull(argv[3],nullptr,10);const int reps=std::atoi(argv[4]);
 std::mt19937_64 rng(416532);std::vector<std::uint32_t>a(n),b(m);for(auto&v:a)v=static_cast<std::uint32_t>(rng()%998244353);for(auto&v:b)v=static_cast<std::uint32_t>(rng()%998244353);
 std::vector<std::int64_t>wide_a(a.begin(),a.end()),wide_b(b.begin(),b.end());for(auto&v:wide_a)v-=998244353;for(auto&v:wide_b)v-=998244353;
 std::vector<std::vector<std::uint32_t>>aa,bb;for(int r=0;r<reps;++r){aa.push_back(a);bb.push_back(b);}
 NTT<>engine;const auto length=(op==4||op==5||op==6)?n:std::bit_ceil(n+m-1);if(op!=0&&op!=6)engine.prepare(length);
 std::vector<NTT<>>prepared(op==6?reps:0);
 const auto start=std::clock();
 for(int r=0;r<reps;++r){
  if(op==0){NTT<>fresh;auto out=fresh.convolution_normalized(std::move(aa[r]),std::move(bb[r]));consume(out);}
  else if(op==1){auto out=engine.convolution_normalized(std::move(aa[r]),std::move(bb[r]));consume(out);}
  else if(op==2){auto out=engine.convolution(wide_a,wide_b);consume(out);}
  else if(op==3){auto out=engine.square(a);consume(out);}
  else if(op==4||op==5){engine.transform(aa[r],op==5);consume(aa[r]);}
  else if(op==6){prepared[r].prepare(n);}
 }
 const auto ticks=std::clock()-start;
 if(op==6)for(auto&one:prepared){auto x=a;one.transform(x);consume(x);}
 std::printf("%jd %ju\n",static_cast<std::intmax_t>(ticks)*1000000000/CLOCKS_PER_SEC,static_cast<std::uintmax_t>(digest));
}
