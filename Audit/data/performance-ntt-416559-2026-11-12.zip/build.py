# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,sys,subprocess,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_ntt_416559');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as p
entry=next(e for e in p.collect()if e['id']=='ntt_convolution');entry['submission_urls']=['https://judge.yosupo.jp/submission/416559'];rows=[]
for label in sys.argv[1:]:
 header=D/(label+'.hpp');assert header.is_file()
 data,_=p.render(entry,source_overrides={'Math/NTT.cpp':header.read_bytes()});src=D/(label+'_main.cpp');src.write_bytes(data)
 for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  cmd=['taskset','-c','4',*args,'-std=c++23','-O2',str(src),'-o',str(D/f'{cc}_{label}_main')];subprocess.run(cmd,check=True,capture_output=True)
  for sample in entry['samples']:
   x=subprocess.run([str(D/f'{cc}_{label}_main')],input=sample['input'],capture_output=True,text=True,check=True);assert p.matches(entry,sample,x.stdout) and not x.stderr
  rows.append(dict(label=label,compiler=cc,kind='main',command=cmd,source_sha256=hashlib.sha256(data).hexdigest()))
  for setting in ['checked','skip']:
   cmd=['taskset','-c','4',*args,'-std=c++23','-O2',*(['-DSKIP_RUNTIME_CHECKS']if setting=='skip'else[]),f'-DHEADER="{header}"',str(D/'core.cpp'),'-o',str(D/f'{cc}_{setting}_{label}_core')];subprocess.run(cmd,check=True,capture_output=True);rows.append(dict(label=label,compiler=cc,setting=setting,kind='core',command=cmd))
  print(cc,label,'build+sample PASS',flush=True)
 path=D/'builds.json';old=json.loads(path.read_text())if path.exists()else[];path.write_text(json.dumps(old+rows,indent=2)+'\n');rows=[]
