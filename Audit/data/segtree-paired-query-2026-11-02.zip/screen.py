from pathlib import Path
import sys,json,subprocess,random,statistics,shutil,os,time,hashlib
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_segtree_followup_20261102');P=Path('/tmp/sirkit_segtree_speed_20261102');s=(D/'before.hpp').read_text()
node='''    static unsigned aligned_node(unsigned value) {
        if (value == 0) std::unreachable();
        return value >> std::countr_zero(value);
    }
'''
nonzero=s.replace('    void rebuild() {',node+'    void rebuild() {').replace('first >> std::countr_zero(first)','aligned_node(first)').replace('last >> std::countr_zero(last)','aligned_node(last)')
a=s.index('        while (first < last && (step = first & (~first + 1)) <= last - first) {');b=s.index('        if (first == last) return left;',a)
fixed=s[:a]+'''        if (first == last) return left;
        const unsigned stop = last & (0U - std::bit_floor((first - 1) ^ (last - 1)));
        while (first < stop) {
            left = std::invoke(op, left, data_[first >> std::countr_zero(first)]);
            first += first & (~first + 1);
        }
'''+s[b:]
start=s.index('        while (first < last && (step = first & (~first + 1)) <= last - first) {');end=s.index('        return std::invoke(op, left, right);',start)
inter=s[:start]+'''        if (first == last) return left;
        const unsigned stop = last & (0U - std::bit_floor((first - 1) ^ (last - 1)));
        if (stop == last) {
            while (first < stop) {
                left = std::invoke(op, left, data_[first >> std::countr_zero(first)]);
                first += first & (~first + 1);
            }
            return left;
        }
        S right = data_[(last >> std::countr_zero(last)) - 1];
        last -= last & (~last + 1);
        while (first < stop && last > stop) {
            left = std::invoke(op, left, data_[first >> std::countr_zero(first)]);
            first += first & (~first + 1);
            right = std::invoke(op, data_[(last >> std::countr_zero(last)) - 1], right);
            last -= last & (~last + 1);
        }
        while (first < stop) {
            left = std::invoke(op, left, data_[first >> std::countr_zero(first)]);
            first += first & (~first + 1);
        }
        while (last > stop) {
            right = std::invoke(op, data_[(last >> std::countr_zero(last)) - 1], right);
            last -= last & (~last + 1);
        }
'''+s[end:]
variants={'old':s,'nonzero':nonzero,'fixed':fixed,'interleave':inter}
variants['fixed_nz']=fixed.replace('    void rebuild() {',node+'    void rebuild() {').replace('first >> std::countr_zero(first)','aligned_node(first)').replace('last >> std::countr_zero(last)','aligned_node(last)')
for k,v in variants.items():
 (D/(k+'.hpp')).write_text(v)
 for id in ['segment_tree','segment_tree_composite']:
  e=next(x for x in prepare_verify.collect() if x['id']==id);data,_=prepare_verify.render(e,source_overrides={'DataStructure/Segment_Tree.cpp':v.encode()});src=D/f'{id}_{k}.cpp';src.write_bytes(data)
  cmd=['taskset','-c','2','/usr/bin/g++','-std=c++23','-O2',str(src),'-o',str(D/f'{id}_{k}')];subprocess.run(cmd,check=True)
print('BUILT',flush=True);cases=[]
for path in sorted(D.glob('official_affine_*.in')):cases.append({'name':path.stem,'kind':'affine','path':str(path)})
for kind in ['sum','affine']:
 for n in [32,4096,500000]:
  for mode in ['mixed','query','update','short']:cases.append({'name':f'custom_{kind}_{n}_{mode}','kind':kind,'path':str(P/f'{kind}_{n}_{mode}.in')})
rs=[];rng=random.Random(551068)
for c in cases:
 for rep in range(7):
  labels=list(variants)+['control'];rng.shuffle(labels);checks=[]
  for label in labels:
   id='segment_tree' if c['kind']=='sum' else 'segment_tree_composite';exe=D/f'{id}_{"old" if label=="control" else label}';shutil.copyfile(exe,D/'active');(D/'active').chmod(0o700)
   with open(c['path'],'rb') as inp,open(D/'output','wb') as out:
    t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0,(c,label);wall=time.perf_counter_ns()-t
   ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rs.append({'name':c['name'],'kind':c['kind'],'label':label,'rep':rep,'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
  assert len(set(checks))==1,(c,checks)
 med={l:statistics.median(r['cpu_ns'] for r in rs if r['name']==c['name'] and r['label']==l) for l in labels};print(c['name'],{l:round(v/med['old'],3) for l,v in med.items()},flush=True);(D/'screen_raw.json').write_text(json.dumps(rs))
