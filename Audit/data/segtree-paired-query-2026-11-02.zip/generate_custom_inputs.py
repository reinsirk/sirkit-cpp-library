from pathlib import Path
import random,sys
D=Path(sys.argv[1]);D.mkdir(parents=True,exist_ok=True)
cases=[]
for kind in ['sum','affine']:
 for n,q in [(32,200000),(4096,300000),(500000,500000)]:
  for mode in ['mixed','query','update','short']:
   p=D/f'{kind}_{n}_{mode}.in';rng=random.Random(8751+n)
   with p.open('w') as f:
    f.write(f'{n} {q}\n')
    if kind=='sum':f.write(' '.join(str(rng.randrange(1000)) for _ in range(n))+'\n')
    else:
     for _ in range(n):f.write(f'{rng.randrange(998244353)} {rng.randrange(998244353)}\n')
    for i in range(q):
     if mode=='update' or(mode=='mixed' and rng.randrange(2)==0):
      if kind=='sum':f.write(f'0 {rng.randrange(n)} {rng.randrange(1000)}\n')
      else:f.write(f'0 {rng.randrange(n)} {rng.randrange(998244353)} {rng.randrange(998244353)}\n')
     else:
      if mode=='short':l=rng.randrange(n);r=min(n,l+rng.randrange(17))
      else:l=rng.randrange(n+1);r=rng.randrange(n+1);l,r=min(l,r),max(l,r)
      if kind=='sum':f.write(f'1 {l} {r}\n')
      else:f.write(f'1 {l} {r} {rng.randrange(998244353)}\n')
   cases.append({'kind':kind,'n':n,'q':q,'mode':mode,'path':str(p)})
