from pathlib import Path
import json,hashlib,zipfile,platform,subprocess,statistics,datetime
D=Path('/tmp/sirkit_segtree_followup_20261102');R=Path.cwd();P=Path('/tmp/sirkit_segtree_speed_20261102')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(name):return json.loads((D/name).read_text())
script=(P/'screen.py').read_text();a=script.index('cases=[]\nfor kind');b=script.index("print('INPUTS READY'",a)
(D/'generate_custom_inputs.py').write_text('from pathlib import Path\nimport random,sys\nD=Path(sys.argv[1]);D.mkdir(parents=True,exist_ok=True)\n'+script[a:b])
meta=[]
for id in ['segment_tree','segment_tree_composite']:
 driver=R/'Verify/current/drivers'/(id+'_main.cpp');assert driver.read_bytes()==(D/(id+'_main.cpp')).read_bytes()
 entry=next(x for x in json.loads((R/'Verify/current/manifest.json').read_text())['entries'] if x['id']==id)
 meta.append({'id':id,'driver_sha256':sha(driver),'submission':entry['submission'],'submission_sha256':sha(R/entry['submission']),'bytes':(R/entry['submission']).stat().st_size})
assert sha(R/'Verify/current/common/fast_io.hpp')==(D/'io_hash.txt').read_text().strip()
report={
 'date_jst':'2026-11-02','scope':'通常版segtreeの区間積。本体を改修し、main・共通I/O・公開API・所有権は維持。',
 'baseline':{'source_sha256':sha(D/'before.hpp'),'online_evidence':'Audit/online-segtree-414717-414716-2026-11-02.json','segment_tree_ms':71,'segment_tree_composite_ms':117,'note':'このACは改修前の本体のみ。現行の2本は要再提出。'},
 'current':{'source':'DataStructure/Segment_Tree.cpp','source_sha256':sha(R/'DataStructure/Segment_Tree.cpp'),'submissions':meta,'io_sha256':sha(R/'Verify/current/common/fast_io.hpp')},
 'implementation':{'adopted':'hybrid32','changes':['正の葉番号から整列節点を求めるprivate helper。0を渡さない不変条件を標準C++23のstd::unreachableで表す。','最初の左ブロックの後、残り幅が32以下なら従来の走査を維持。','広い残区間の分割点をbit_floorで計算し、独立な左右の累積演算を交互に進める。','元と同じ整列ブロックを使い、非可換演算の左右の順序と演算回数を維持。'],'complexity':'prod O(log(n+1))、追加領域O(1)。木の領域、構築、点更新、境界探索は同じ。','standard':'標準C++23のみ。新しいSIMD/コンパイラ拡張なし。','measured_candidate_equivalence':'hybrid32.hppと現行本体は、コメント・空白・不要な括弧以外が一致。'},
 'measurement':{'CPU':'Intel Core i9-14900K, logical CPU12 / physical P-Core6、SMT sibling13で同時測定なし','governor':'powersave、周波数は固定せず','compilers':{'gcc':subprocess.check_output(['/usr/bin/g++','--version'],text=True).splitlines()[0],'clang':subprocess.check_output(['/usr/bin/clang++','--version'],text=True).splitlines()[0]},'flags':['-std=c++23','-O2','SKIP_RUNTIME_CHECKSは提出コード先頭で定義'],'clang_extra':'--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15','no_march_native':True,'metric':'同じmain・共通I/OでプロセスCPU時間(user+system)を測り、中央値を比較。構築・入出力も含む。','protocol':'各実行前に同じ実行ファイル名へコピー。候補とold/controlの順を固定seedでランダム化。controlはoldと同じバイナリ。出力SHA256が候補間で同一。測定中CPU12上で別の性能試験を並行実行せず。','adopted_repetitions':9,'official_inputs':load('official_inputs_metadata.json'),'custom_inputs':load('custom_inputs_metadata.json'),'limitations':['公式の現行生成器とseedから作った数値入力。オンライン判定時の保存入力・実行機と同一とは断定しない。','入出力・構築を含む値であり、照会関数だけの短縮率ではない。','短区間のGCC和で約0.8%、Clang和で約1.0%の遅れが残る。小規模にも1〜2%前後の差があり、一部はcontrolの揺れと重なる。すべての入力・演算型での無退行は主張しない。'],'summary':load('hybrid_summary.json')},
 'validation':{'normal_api_reference_and_allocation':load('final_api_tests.json'),'derived_api':load('profile_api_tests.json'),'profile_samples':json.loads((D/'profiles/checkpoint.json').read_text()),'candidate_sanitizers':load('review_hybrid32_results.json'),'source_placement':'106ソースのAPI配置・130件のDocumentリンク確認済み。','generators':'通常227件・派生802件の提出コード照合済み。','extra_geometry_test':'candidate_sanitizersの追試記録を参照。独立な親半減式と節点列・被覆・左右順・分割点を照合し、INT_MAX近傍および残り幅31/32/33を含める。'},
 'evidence_zip':'Audit/data/segtree-paired-query-2026-11-02.zip',
 'license':'実装と独立テストは自作CC0。公式生成器のApache-2.0ソースは/tmp内で入力生成にのみ使用し、配布・証拠ZIPへ収録しない。数値入力のハッシュ・先頭行・原典URLを記録する。',
 'resubmission_required':['Verify/current/submissions/segment_tree.cpp','Verify/current/submissions/segment_tree_composite.cpp']}
extra=D/'review_hybrid_geometry_results.json'
if extra.exists():report['validation']['extra_geometry_test']=json.loads(extra.read_text())
path=R/'Audit/performance-segtree-paired-query-2026-11-02.json';path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
files=[p for p in D.iterdir() if p.is_file() and p.suffix in ['.py','.cpp','.hpp','.json','.md','.log']]
with zipfile.ZipFile(R/report['evidence_zip'],'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,p.name)
 for p in sorted((D/'profiles/runs').glob('*.json')):z.write(p,'profile_runs/'+p.name)
 z.write(R/'Verify/current/tests/segment_tree_partition_test.cpp','tests/segment_tree_partition_test.cpp')
print(path,'evidence files',len(files))
