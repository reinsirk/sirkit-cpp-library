from pathlib import Path
import sys,subprocess,json,random,statistics,shutil,os,time,hashlib
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_segtree_followup_20261102');P=Path('/tmp/sirkit_segtree_speed_20261102');old=(D/'before.hpp').read_text();inter=(D/'interleave.hpp').read_text()
a=old.index('        while (first < last && (step = first & (~first + 1)) <= last - first) {');b=old.index('        return std::invoke(op, left, right);',a);tail=old[a:b]
node='''    static unsigned aligned_node(unsigned value) {
        if (value == 0) std::unreachable();
        return value >> std::countr_zero(value);
    }
'''
variants={'old':old}
for limit in [16,32,64]:
 s=inter.replace('''        if (first == last) return left;
        const unsigned stop''',f'''        if (first == last) return left;
        if (last - first <= {limit}) {{
'''+tail+'''            return std::invoke(op, left, right);
        }
        const unsigned stop''')
 s=s.replace('    void rebuild() {',node+'    void rebuild() {').replace('first >> std::countr_zero(first)','aligned_node(first)').replace('last >> std::countr_zero(last)','aligned_node(last)')
 variants['hybrid'+str(limit)]=s;(D/('hybrid'+str(limit)+'.hpp')).write_text(s)
for compiler in ['gcc','clang']:
 for label,source in variants.items():
  for id in ['segment_tree','segment_tree_composite']:
   e=next(x for x in prepare_verify.collect() if x['id']==id);data,_=prepare_verify.render(e,source_overrides={'DataStructure/Segment_Tree.cpp':source.encode()});src=D/f'hybrid_{id}_{label}.cpp';src.write_bytes(data)
   cmd=['/usr/bin/g++'] if compiler=='gcc' else ['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'];cmd+=['-std=c++23','-O2',str(src),'-o',str(D/f'hybrid_{compiler}_{id}_{label}')];subprocess.run(['taskset','-c','2',*cmd],check=True)
print('BUILT',flush=True);cases=[]
for seed in [0,3,4]:
 p=D/f'official_affine_random_{seed}.in';cases.append({'name':p.stem,'kind':'affine','path':str(p)})
for seed in [0,1,2]:
 p=D/f'official_affine_max_random_{seed}.in';cases.append({'name':p.stem,'kind':'affine','path':str(p)})
for kind in ['sum','affine']:
 for n in [32,4096,500000]:
  for mode in ['mixed','query','update','short']:cases.append({'name':f'custom_{kind}_{n}_{mode}','kind':kind,'path':str(P/f'{kind}_{n}_{mode}.in')})
rng=random.Random(62903);rs=[]
for compiler in ['gcc','clang']:
 for c in cases:
  for rep in range(9):
   labels=list(variants)+['control'];rng.shuffle(labels);checks=[]
   for label in labels:
    id='segment_tree' if c['kind']=='sum' else 'segment_tree_composite';exe=D/f'hybrid_{compiler}_{id}_{"old" if label=="control" else label}';shutil.copyfile(exe,D/'active_hybrid');(D/'active_hybrid').chmod(0o700)
    with open(c['path'],'rb') as inp,open(D/'output','wb') as out:
     t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active_hybrid')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-t
    ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rs.append({'compiler':compiler,'name':c['name'],'kind':c['kind'],'rep':rep,'label':label,'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
   assert len(set(checks))==1
  ms={l:statistics.median(r['cpu_ns'] for r in rs if r['compiler']==compiler and r['name']==c['name'] and r['label']==l) for l in labels};print(compiler,c['name'],{l:round(v/ms['old'],3) for l,v in ms.items()},flush=True);(D/'hybrid_raw.json').write_text(json.dumps(rs))
