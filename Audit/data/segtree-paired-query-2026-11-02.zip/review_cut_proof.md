# Greedy left endpoint cutoff

For positive unsigned F < R, let H = bit_floor((F-1) xor (R-1)). Let P be the common high prefix, a multiple of 2H. The highest differing bit implies F in (P,P+H] and R in (P+H,P+2H].

If R < P+2H, forward F += lowbit(F) stays inside the aligned first half and reaches P+H. Its next step is H > R-(P+H), so it stops there. If R = P+2H, it reaches P+H and then R. Thus the exact terminal endpoint is R & ~(H-1). All accepted left steps end <=cut<=R, so no overflow; the old right-side invariant guarantees clearing right low bits reaches cut without overshoot. F<R makes xor nonzero, H>=1, H-1 safe, and endpoints stay positive.

In the candidates, the existing initial right-only branch remains unchanged. Once the first left block is seeded, F==R returns immediately; otherwise the same formula applies to the remaining interval. Left folds append and right folds prepend, preserving the noncommutative node sequence and contiguous intermediate products. Pairing the two independent folds changes their interleaving only, not either sequence or operator count.

Endpoint formula checked independently over every 1<=F<R<=513 and 100,000 random pairs up to UINT32_MAX: 231,328 cases. Both candidates pass the existing segtree reference test (248,744 assertions) with GCC15.2 C++23/O2 on CPU2. No production sources edited and no performance measurements performed.
