from pathlib import Path
import sys,subprocess,json,random,statistics,shutil,os,time,hashlib
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_segtree_followup_20261102');P=Path('/tmp/sirkit_segtree_speed_20261102')
s=(D/'interleave.hpp').read_text();node='''    static unsigned aligned_node(unsigned value) {
        if (value == 0) std::unreachable();
        return value >> std::countr_zero(value);
    }
''';s=s.replace('    void rebuild() {',node+'    void rebuild() {').replace('first >> std::countr_zero(first)','aligned_node(first)').replace('last >> std::countr_zero(last)','aligned_node(last)');(D/'interleave_nz.hpp').write_text(s)
for compiler in ['gcc','clang']:
 for label in ['old','nonzero','interleave','interleave_nz']:
  for id in ['segment_tree','segment_tree_composite']:
   e=next(x for x in prepare_verify.collect() if x['id']==id);data,_=prepare_verify.render(e,source_overrides={'DataStructure/Segment_Tree.cpp':(D/(label+'.hpp')).read_bytes()});src=D/f'final_{id}_{label}.cpp';src.write_bytes(data)
   cmd=['/usr/bin/g++'] if compiler=='gcc' else ['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
   cmd+=['-std=c++23','-O2',str(src),'-o',str(D/f'final_{compiler}_{id}_{label}')];subprocess.run(['taskset','-c','2',*cmd],check=True)
print('BUILT',flush=True);cases=[]
for path in sorted(D.glob('official_affine_*.in')):cases.append({'name':path.stem,'kind':'affine','path':str(path)})
for kind in ['sum','affine']:
 for n in [32,4096,500000]:
  for mode in ['mixed','query','update','short']:cases.append({'name':f'custom_{kind}_{n}_{mode}','kind':kind,'path':str(P/f'{kind}_{n}_{mode}.in')})
rng=random.Random(275190);rs=[]
for compiler in ['gcc','clang']:
 for c in cases:
  for rep in range(11):
   labels=['old','control','nonzero','interleave','interleave_nz'];rng.shuffle(labels);checks=[]
   for label in labels:
    id='segment_tree' if c['kind']=='sum' else 'segment_tree_composite';exe=D/f'final_{compiler}_{id}_{"old" if label=="control" else label}';shutil.copyfile(exe,D/'active_final');(D/'active_final').chmod(0o700)
    with open(c['path'],'rb') as inp,open(D/'output','wb') as out:
     t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active_final')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0,(c,label);wall=time.perf_counter_ns()-t
    ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rs.append({'compiler':compiler,'name':c['name'],'kind':c['kind'],'label':label,'rep':rep,'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
   assert len(set(checks))==1,(c,checks)
  ms={l:statistics.median(r['cpu_ns'] for r in rs if r['compiler']==compiler and r['name']==c['name'] and r['label']==l) for l in labels};print(compiler,c['name'],{l:round(v/ms['old'],3) for l,v in ms.items()},flush=True);(D/'final_raw.json').write_text(json.dumps(rs))
