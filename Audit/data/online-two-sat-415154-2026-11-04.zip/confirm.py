# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,datetime,zipfile,re
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_two_sat_415154_20261104');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();j=json.loads((D/'415154.json').read_text());o=j['overview'];assert o['status']=='AC'
normalize=lambda t:'\n'.join(l.rstrip()for l in t.replace('\r\n','\n').splitlines()if l.strip()and not l.startswith('// Submission:'))
assert normalize(j['source'])==normalize((R/'Verify/current/submissions/two_sat.cpp').read_text())
p=R/'Distribution/manifest.json';backup=R/'Audit/distribution-manifest-before-two-sat-415154-2026-11-04.json';backup.write_bytes(p.read_bytes())
record=dict(id='two_sat',status=o['status'],url='https://judge.yosupo.jp/submission/415154',time_ms=round(o['time']*1000),memory_bytes=o['memory'],language=o['lang'],submission_time=o['submission_time'],checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),case_results=j['case_results'],submission_sha256=sha(R/'Verify/current/submissions/two_sat.cpp'),uploaded_source_sha256=sha(D/'uploaded.cpp'),source_hashes={'Graph/Two_SAT.cpp':sha(R/'Graph/Two_SAT.cpp')},driver_sha256=sha(R/'Verify/current/drivers/two_sat_main.cpp'),io_source_hashes={'Verify/current/common/fast_io.hpp':sha(R/'Verify/current/common/fast_io.hpp')},io_mode='shared_fast_io',matched_current_generation=True,needs_resubmission=False,source_match='改行・空行・行末空白・Submission注記を除き現行本体・main・共通I/Oと一致。',evidence_file='Audit/online-two-sat-415154-2026-11-04.json')
audit={'endpoint':'https://v3.api.judge.yosupo.jp/submissions/415154','scope':'415154の通常版AC92ms。現行本体と照合。旧415142のAC100msと区別し、以降の試作へACを転記しない。','record':record,'comparison':[]}
old=json.loads((D.parent/'sirkit_two_sat_speed_20261104/415142.json').read_text());before={r['case']:r for r in old['case_results']}
for r in j['case_results']:audit['comparison'].append({'case':r['case'],'before_ms':round(before[r['case']]['time']*1000),'current_ms':round(r['time']*1000),'status':r['status']})
with zipfile.ZipFile(R/'Audit/data/online-two-sat-415154-2026-11-04.zip','w',zipfile.ZIP_DEFLATED)as z:
 for f in ['415154.json','uploaded.cpp','confirm.py']:z.write(D/f,f)
(R/'Audit/online-two-sat-415154-2026-11-04.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
p=R/'Verify/current/judgements.json';a=json.loads(p.read_text());a['entries']=[r for r in a['entries'] if r['id']!='two_sat']+[record];p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
p=R/'Verify/current/groups/expansion_20261031.json';a=json.loads(p.read_text());next(r for r in a['entries'] if r['id']=='two_sat')['submission_urls']=[record['url']];p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
print('415154 AC92ms source match; latest record updated')
