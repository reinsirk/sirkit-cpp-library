from pathlib import Path
from collections import Counter
import json,random,itertools
w=Path(__file__).resolve().parent;rng=random.Random(0xA116E10)
def encode_points(points):return str(len(points))+'\n'+''.join(f'{x} {y}\n'for x,y in points)
def phase(p):
 x,y=p
 return 0 if y<0 else 1 if x==0 and y==0 else 2 if y==0 and x>0 else 3 if y>0 else 4
def compare(a,b):
 ah,bh=phase(a),phase(b)
 if ah!=bh:return -1 if ah<bh else 1
 cross=a[0]*b[1]-a[1]*b[0]
 return -1 if cross>0 else 1 if cross<0 else 0
def check_angle(data,output):
 tokens=list(map(int,data.split()));points=list(zip(tokens[1::2],tokens[2::2]));values=list(map(int,output.split()));actual=list(zip(values[::2],values[1::2]))
 assert len(values)==2*tokens[0]and Counter(points)==Counter(actual)
 assert all(compare(a,b)<=0 for a,b in zip(actual,actual[1:]))
def naive_z(text):
 out=[]
 for i in range(len(text)):
  count=0
  while i+count<len(text)and text[count]==text[i+count]:count+=1
  out.append(count)
 return out
def linear_z(text):
 n=len(text);out=[0]*n
 if n:out[0]=n
 left=right=0
 for i in range(1,n):
  if i<right:out[i]=min(right-i,out[i-left])
  while i+out[i]<n and text[out[i]]==text[i+out[i]]:out[i]+=1
  if i+out[i]>right:left,right=i,i+out[i]
 return out
def z_output(text,large=False):return ' '.join(map(str,linear_z(text)if large else naive_z(text)))+'\n'

def generate():
 minimum=-(1<<63);maximum=(1<<63)-1
 extreme=[(x,y)for x in [minimum,-1,0,1,maximum]for y in [minimum,-1,0,1,maximum]]
 cases={'angle_sort_std':[encode_points([]),encode_points([(0,0)]),encode_points([(1,0),(0,0),(-1,0),(0,1),(0,-1),(2,2),(1,1)]),encode_points(extreme)],'rolling_hash':[]}
 for _ in range(64):
  n=rng.randrange(1,100);points=[(rng.randrange(-100,101),rng.randrange(-100,101))for _ in range(n)]
  if _%3==0:points += rng.sample(extreme,8)
  if _%3==1:points += [(i,2*i)for i in range(-10,11)]
  cases['angle_sort_std'].append(encode_points(points))
 for n in range(7):
  for text in itertools.product('ab',repeat=n):cases['rolling_hash'].append(''.join(text)+'\n')
 for n in [7,8,15,16,31,32,63,64,127,128,255,256]:
  for text in ['a'*n,('abac'*(n//4+1))[:n],''.join(rng.choices('abcdef',k=n)),('a'*(n-1)+'b')]:cases['rolling_hash'].append(text+'\n')
 (w/'small_cases.json').write_text(json.dumps(cases,indent=2)+'\n')
 inputs=w/'inputs';inputs.mkdir(exist_ok=True)
 geometry=Path('/tmp/sirkit_remaining_20261113/geometry')
 manifest=[]
 for kind in ['random','axis','sorted']:
  path=geometry/f'input_angle_sort_std_200000_{kind}.txt';manifest.append({'id':'angle_sort_std','case':kind,'path':str(path),'n':200000,'contract':'judge-range integer coordinates'})
 for kind in ['same_direction','wide_int64']:
  n=200000
  if kind=='same_direction':points=[(i+1,2*(i+1))for i in range(n)];rng.shuffle(points)
  else:points=[(rng.randrange(minimum,maximum+1),rng.randrange(minimum,maximum+1))for _ in range(n)];points[:len(extreme)]=extreme
  path=inputs/(kind+'.in');path.write_text(encode_points(points));manifest.append({'id':'angle_sort_std','case':kind,'path':str(path),'n':n,'contract':'int64 API supplement'if kind=='wide_int64'else'judge-range integer coordinates'})
 old=Path('/tmp/sirkit_remaining_20261113/compiler_settings_math_string/inputs')
 for kind in ['random','equal','periodic']:
  path=old/f'rolling_hash-{kind}_100000.in';manifest.append({'id':'rolling_hash','case':'existing_'+kind,'path':str(path),'n':100000,'contract':'nonempty text'})
 n=500000
 for kind,text in [('max_random',''.join(rng.choices('abcdefghijklmnopqrstuvwxyz',k=n))),('max_equal','a'*n),('max_tail_difference','a'*(n-1)+'b')]:
  path=inputs/(kind+'.in');path.write_text(text+'\n');manifest.append({'id':'rolling_hash','case':kind,'path':str(path),'n':n,'contract':'nonempty text'})
 (w/'input_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('small',{k:len(v)for k,v in cases.items()},'large',len(manifest),flush=True)
if __name__=='__main__':generate()
