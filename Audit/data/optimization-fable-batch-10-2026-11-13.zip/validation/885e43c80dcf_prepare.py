from pathlib import Path
import sys,json,hashlib,difflib
r=Path('/home/reinsirk/Atcoder_Env');w=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'Scripts'));import prepare_verify as pv
entries={e['id']:e for e in pv.collect()};report={'scope':'main_only','entries':{},'bodies':{},'drivers':{},'io_sha256':hashlib.sha256((r/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest()}
for identity in ['angle_sort_std','rolling_hash']:
 entry=entries[identity];base=(r/entry['driver']).read_text()
 if identity=='angle_sort_std':
  selected=base.replace('std::sort(points.begin(), points.end(), arccmp_less);','std::sort(points.begin(), points.end(), AngleLess{});')
 else:
  old='''    for (std::size_t i = 0; i < text.size(); ++i) {
        if (i) verify_out << ' ';
        verify_out << hash.lcp(0, hash, i);
    }'''
  new='''    if (!text.empty()) verify_out << hash.lcp(0, hash, 0);
    for (std::size_t i = 1; i < text.size(); ++i) verify_out << ' ' << hash.lcp(0, hash, i);'''
  assert old in base;selected=base.replace(old,new)
 assert selected!=base
 bodies={name:(r/name).read_bytes()for name in entry['libraries']}
 for name,data in bodies.items():
  report['bodies'][name]=hashlib.sha256(data).hexdigest();dest=w/'bodies'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 report['entries'][identity]=entry;report['drivers'][entry['driver']]={'baseline_sha256':hashlib.sha256(base.encode()).hexdigest(),'selected_sha256':hashlib.sha256(selected.encode()).hexdigest()}
 (w/(identity+'_baseline_main.cpp')).write_text(base);(w/(identity+'_selected_main.cpp')).write_text(selected)
 (w/(identity+'.patch')).write_text(''.join(difflib.unified_diff(base.splitlines(True),selected.splitlines(True),fromfile=entry['driver'],tofile=entry['driver'])))
 for variant,driver in [('baseline',base),('selected',selected)]:
  for mode,skip in [('checked',False),('skip',True)]:
   source,_=pv.render(entry,source_overrides=bodies,driver_override=driver,skip_runtime_checks=skip)
   (w/f'{identity}_{variant}_{mode}.cpp').write_bytes(source)
(w/'provenance.json').write_text(json.dumps(report,indent=2)+'\n')
