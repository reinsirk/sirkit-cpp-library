from pathlib import Path
import json,subprocess,hashlib,time,statistics,shutil,os
from models import check_angle,z_output
w=Path(__file__).resolve().parent;os.sched_setaffinity(0,{12})
manifest=json.loads((w/'input_manifest.json').read_text());p=json.loads((w/'provenance.json').read_text());records=[]
report={'cpu':12,'scope':'main_only with frozen core/common IO/compiler flags; no alternative core algorithm. Python Z is correctness oracle only.','protocol':'2warm+9 strictly alternating measured pairs; common executable pathname.','compilers':{cc:subprocess.check_output([path,'--version'],text=True).splitlines()[0]for cc,path in [('gcc','/usr/bin/g++'),('clang','/usr/bin/clang++')]},'results':records}
def save():(w/'benchmark_results.json').write_text(json.dumps(report,indent=2)+'\n')
for identity in ['angle_sort_std','rolling_hash']:
 for cc in ['gcc','clang']:
  bins={v:w/f'{identity}_{v}_skip_{cc}_default'for v in ['baseline','selected']}
  for item in [row for row in manifest if row['id']==identity]:
   inp=Path(item['path']);data=inp.read_text();outputs={}
   for v,exe in bins.items():
    run=subprocess.run([str(exe)],input=data,capture_output=True,text=True,timeout=60);assert run.returncode==0,run.stderr;outputs[v]=run.stdout
   assert outputs['baseline']==outputs['selected'],(identity,cc,item['case'],'byte mismatch')
   if identity=='angle_sort_std':check_angle(data,outputs['baseline'])
   else:assert outputs['baseline']==z_output(data.rstrip('\n'),large=True)
   raw={v:[]for v in bins}
   for rep in range(11):
    for v in (list(bins)if rep%2==0 else list(reversed(bins))):
     active=w/'active';shutil.copyfile(bins[v],active);active.chmod(0o755)
     with inp.open('rb')as fi,open('/dev/null','wb')as fo:
      start=time.perf_counter_ns();run=subprocess.run([str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
     assert run.returncode==0,run.stderr
     if rep>=2:raw[v].append(elapsed)
   med={v:statistics.median(values)for v,values in raw.items()}
   row={'id':identity,'compiler':cc,'case':item['case'],'n':item['n'],'contract':item['contract'],'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(outputs['baseline'].encode()).hexdigest(),'output_byte_identical':True,'independent_model_passed':True,'raw_ns':raw,'median_ns':med,'candidate_ratio':med['selected']/med['baseline'],'candidate_pair_wins':sum(c<b for b,c in zip(raw['baseline'],raw['selected']))}
   records.append(row);save();print(identity,cc,item['case'],'ratio',round(row['candidate_ratio'],4),'wins',row['candidate_pair_wins'],'ms',{k:round(v/1e6,3)for k,v in med.items()},flush=True)
