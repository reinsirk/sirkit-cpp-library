from pathlib import Path
import sys,re,json,subprocess,hashlib,time,statistics,shutil,os
w=Path(__file__).resolve().parent;r=Path('/home/reinsirk/Atcoder_Env');parent=w.parent;os.sched_setaffinity(0,{12})
sys.path.insert(0,str(r/'Scripts'));import prepare_verify as pv
p=json.loads((parent/'provenance.json').read_text());entry=p['entries']['angle_sort_std'];driver=(parent/'angle_sort_std_selected_main.cpp').read_text();bodies={name:(parent/'bodies'/name).read_bytes()for name in entry['libraries']};sources={};records=[]
pattern=rb'#if defined\(__GNUC__\) && !defined\(__clang__\)\n#pragma GCC optimize\([^\n]*\)\n#endif\n'
for name,option in [('none',None),('O3','O3'),('O3_unroll','O3,unroll-loops')]:
 e=dict(entry);e.pop('gcc_optimization',None)
 if option:e['gcc_optimization']=option
 sources[name]=pv.render(e,source_overrides=bodies,driver_override=driver,skip_runtime_checks=True)[0]
assert len({hashlib.sha256(re.sub(pattern,b'',s)).hexdigest()for s in sources.values()})==1
assert len({b'#define NDEBUG'in s for s in sources.values()})==1
report={'compiler':subprocess.check_output(['/usr/bin/g++','--version'],text=True).splitlines()[0],'cpu':12,'scope':'Proposed AngleLess main, frozen core/IO, actual GCC pragma only; CLI C++23 O2 in all.','protocol':'2warm+9 cyclic triplets, same executable pathname.','current_setting':entry.get('gcc_optimization'),'nonpragma_bytes_identical':True,'source_sha256':{name:hashlib.sha256(s).hexdigest()for name,s in sources.items()},'results':records}
def save():(w/'results.json').write_text(json.dumps(report,indent=2)+'\n')
bins={}
for name,source in sources.items():
 src=w/(name+'.cpp');src.write_bytes(source);exe=w/name;cmd=['/usr/bin/g++','-std=c++23','-O2',str(src),'-o',str(exe)]
 built=subprocess.run(cmd,capture_output=True,text=True);assert built.returncode==0,built.stderr;bins[name]=exe
 records.append({'kind':'build','variant':name,'command':cmd,'passed':True,'diagnostics':built.stderr});save()
for item in json.loads((parent/'input_manifest.json').read_text()):
 if item['id']!='angle_sort_std':continue
 inp=Path(item['path']);outputs={}
 for name,exe in bins.items():
  with inp.open('rb')as fi:run=subprocess.run([str(exe)],stdin=fi,capture_output=True)
  assert run.returncode==0,run.stderr;outputs[name]=run.stdout
 assert len(set(outputs.values()))==1
 raw={name:[]for name in bins};names=list(bins)
 for rep in range(11):
  offset=rep%3;order=names[offset:]+names[:offset]
  for name in order:
   active=w/'active';shutil.copyfile(bins[name],active);active.chmod(0o755)
   with inp.open('rb')as fi,open('/dev/null','wb')as fo:
    start=time.perf_counter_ns();run=subprocess.run([str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
   assert run.returncode==0,run.stderr
   if rep>=2:raw[name].append(elapsed)
 med={name:statistics.median(values)for name,values in raw.items()};row={'kind':'timing','case':item['case'],'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'output_byte_identical':True,'output_sha256':hashlib.sha256(outputs['none']).hexdigest(),'raw_ns':raw,'median_ns':med,'ratio_to_none':{name:value/med['none']for name,value in med.items()}}
 records.append(row);save();print(item['case'],'ratios',{k:round(v,4)for k,v in row['ratio_to_none'].items()},'ms',{k:round(v/1e6,3)for k,v in med.items()},flush=True)
