from pathlib import Path
import json,os,subprocess,hashlib,time
from models import check_angle,z_output
w=Path(__file__).resolve().parent;os.sched_setaffinity(0,{12});p=json.loads((w/'provenance.json').read_text());cases=json.loads((w/'small_cases.json').read_text())
install=Path(subprocess.check_output(['/usr/bin/g++','-print-libgcc-file-name'],text=True).strip()).parent
records=[];baseline={}
for identity in ['angle_sort_std','rolling_hash']:
 for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir='+str(install)])]:
  for mode in ['checked','skip']:
   for fallback in [False,True]:
    for variant in ['baseline','selected']:
     src=w/f'{identity}_{variant}_{mode}.cpp';exe=w/f'{identity}_{variant}_{mode}_{cc}_{"fallback"if fallback else"default"}'
     cmd=[*compiler,'-std=c++23','-O2','-Wall','-Wextra']
     if fallback:cmd += ['-U__SIZEOF_INT128__','-DSIRKIT_FORCE_STANDARD_ARITHMETIC','-DSIRKIT_DISABLE_SIMD']
     cmd += [str(src),'-o',str(exe)];built=subprocess.run(cmd,capture_output=True,text=True);assert built.returncode==0,built.stderr
     for index,data in enumerate(cases[identity]):
      run=subprocess.run([str(exe)],input=data,capture_output=True,text=True,timeout=10);assert run.returncode==0,run.stderr
      if identity=='angle_sort_std':check_angle(data,run.stdout)
      else:assert run.stdout==z_output(data.rstrip('\n')),(identity,index,data,run.stdout)
      key=(identity,cc,mode,fallback,index)
      if variant=='baseline':baseline[key]=run.stdout
      else:assert run.stdout==baseline[key],(identity,cc,mode,fallback,index,'byte mismatch')
     records.append({'id':identity,'compiler':cc,'mode':mode,'fallback':fallback,'variant':variant,'command':cmd,'passed':True,'small_cases':len(cases[identity]),'diagnostics':built.stderr})
     (w/'validation_results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(identity,cc,mode,'fallback'if fallback else'default','PASS',flush=True)
