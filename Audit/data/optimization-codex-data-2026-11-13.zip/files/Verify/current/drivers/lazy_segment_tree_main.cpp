// SPDX-License-Identifier: CC0-1.0
#include "Verify/current/common/fast_io.hpp"
#include <cstdint>
#include <vector>
struct RangeAffineValue { std::uint64_t sum = 0; int length = 0; };
struct RangeAffineUpdate { std::uint64_t a = 1, b = 0; };
RangeAffineValue range_affine_op(RangeAffineValue a, RangeAffineValue b) {
    return {(a.sum + b.sum) % 998244353, a.length + b.length};
}
RangeAffineValue range_affine_identity() { return {}; }
RangeAffineValue range_affine_mapping(RangeAffineUpdate f, RangeAffineValue value) {
    return {(f.a * value.sum + f.b * static_cast<std::uint64_t>(value.length)) % 998244353, value.length};
}
RangeAffineUpdate range_affine_composition(RangeAffineUpdate newer, RangeAffineUpdate older) {
    return {newer.a * older.a % 998244353, (newer.a * older.b + newer.b) % 998244353};
}
RangeAffineUpdate range_affine_id() { return {}; }
int main() {
    int n{}, q{}; verify_in >> n >> q;
    std::vector<RangeAffineValue> a(n);
    for (auto& x : a) { verify_in >> x.sum; x.length = 1; }
    lazy_segtree<RangeAffineValue, range_affine_op, range_affine_identity, RangeAffineUpdate,
                 range_affine_mapping, range_affine_composition, range_affine_id> tree(a);
    while (q--) {
        int type{}, l{}, r{}; verify_in >> type >> l >> r;
        if (type == 0) {
            RangeAffineUpdate f; verify_in >> f.a >> f.b;
            tree.apply(l, r, f);
        } else verify_out << tree.prod(l, r).sum << '\n';
    }
}
