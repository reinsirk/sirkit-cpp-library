# 親辺番号と辺スタックの型をIdへ統一する候補

対象: `narrow_parent_pending.hpp`。SHA256 `8eaec13842a310029052389426a32483c75d3ae3fad17382af47840e3b7eb648`。基準 `final.hpp` (b6136a009ad424b9e15f1d7efd59987be2f8d3f95de9adb51fdb7a137221ed3f) から2行だけ変更した。no_edgeを `static_cast<Id>(m)`、parent_edgeとpendingを `vector<Id>` とし、他は無変更。未コンパイル・未測定の静的候補。

## 番号と番兵の範囲

既存のbuild分岐は、size_tがuint32_tより広く、m<=UINT32_MAXのときだけId=uint32_tを使う。従って番兵mはUINT32_MAX自身まで正確に表せる。有効な辺番号は0<=e<mなので、mと衝突しない。m=0では番兵0、実際の辺はない。m=UINT32_MAXの理論上の境界でも、有効な辺番号の最大値はUINT32_MAX-1である。

それ以外はId=size_tなので、番兵・辺番号とも基準と同じ範囲を持つ。32ビットsize_t環境では狭める分岐自体がなく、Id=size_tとなる。その他のsize_t幅でも既存のsizeof条件に従い、size_tより広い型へ変更することはない。

2m要素の隣接配列に対するmax_size/2のガード、size_tによる度数・CSR添字・mの計算はすべて維持される。親辺番号を配列添字に使うときはsize_tへ正確に変換され、辺数m以内を参照する。根の番兵をbridgeへ添字として使うことはなく、p==-1で先に終了する。

## 型混合・出力順序

incidentの辺番号もIdなので、親辺との比較・pendingへの追加・pendingと親辺の比較は同じ型になる。parent_edgeには番兵以外はincidentから来る有効番号だけが入る。pendingに番兵を追加する処理はない。

公開blocksの型は `vector<vector<size_t>>` のまま。単独辺と自己辺のinitializer_list構築ではIdの番号がsize_tへ正確に拡張される。複数辺の範囲構築はvector<Id>のreverse_iteratorを受けるvector<size_t>の範囲コンストラクタとなり、各辺番号を拡張してコピーする。整数の要素数コンストラクタとの曖昧さはなく、入力の順序も変えない。pendingの取り出し位置とresize量も同じであり、ブロック・辺・頂点の公開順序を維持する。

vectorの要素を別型としてreinterpretしたり、同じ領域をsize_tとして参照したりしないため、aliasやアラインメントの問題はない。parent/componentの再利用はvector<int>のままで、この変更とは独立している。

## 所有権・例外・計算量

parent_edgeとpendingはいずれもbuild内のvectorで独立所有される。公開blocksへは変換コピーし、要素へのポインタや参照を返さない。確保・構築・コピーが例外を投げても、最後の結果swap群に達する前なので既存の公開結果と成分数キャッシュを維持する。pendingの削除は出力vectorの構築成功後であり、確保失敗で公開状態を部分更新しない。直接のnew式はない。

配列要素数、辺の追加回数、範囲探索・コピー回数は変わらず、時間O(N+M)・領域O(N+M)。SKIPによる検査省略や数学的な分岐・容量ガードもそのまま。

## 速度とメモリの見込み

64ビットsize_tでId32となる経路では、parent_edgeのペイロードが8Nから4Nバイトへ減る。Blocks=trueでm要素を予約するpendingは8mから4mバイトへ減る。Blocks=falseではpendingは予約されないので、その部分の節約はない。公開blocksのsize_t領域は減らない。

親辺初期化とDFS中の親辺読書き、ブロック収集時のpendingの読書きの転送量が減る可能性がある。一方、公開blocksへの変換コピーでは32→size_tの拡張が加わり、以前の同型コピー最適化が使えなくなる可能性があるため、特に大きいブロックの出力で採否の測定が必要。Id=size_tの経路は基準と同じ要素型なので性能・メモリ上の利益は想定しない。静的確認では修正を要する問題は見つからなかったが、境界・例外・各コンパイラ経路の実行検証は別途必要である。
