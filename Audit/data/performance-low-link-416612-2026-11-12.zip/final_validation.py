# SPDX-License-Identifier: CC0-1.0
# 選定後のfinal.hppだけを検証する。実行全体を共通lockで性能測定と分離する。
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import datetime
import fcntl
import hashlib
import json
import os
import re
import subprocess
import threading

R = Path('/home/reinsirk/Atcoder_Env')
D = Path('/tmp/sirkit_lowlink_416612')
COMPILERS = {
    'gcc': (['/usr/bin/g++'], 4),
    'clang': (['/usr/bin/clang++', '--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'], 6),
}
TESTS = {
    'reference': R / 'Verify/current/tests/new_low_link_reference_test.cpp',
    'allocation': R / 'Verify/current/tests/new_graph2_allocation_test.cpp',
    'components_allocation': R / 'Verify/current/tests/low_link_components_allocation_test.cpp',
}
SUPPORT_SOURCES = ['Graph/Eulerian_Trail.cpp', 'Graph/Min_Cost_Flow.cpp']
WIDE_CONDITIONS = {
    'edge_ids': 'edges_.size() <= std::numeric_limits<std::uint32_t>::max()',
    'block_stamps': 'blocks_.size() <= std::numeric_limits<std::uint32_t>::max()',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def encode(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + '\n'


def counters(name, stdout):
    if name == 'reference':
        match = re.search(r'LowLink checks=(\d+)', stdout)
        if not match:
            raise ValueError('LowLinkの参照照合数がない')
        result = {'checks': int(match.group(1))}
        if result['checks'] <= 0:
            raise ValueError('参照照合数が0')
        return result
    if name in ('allocation', 'components_allocation'):
        match = re.search(r'(?:graph2|low-link components) allocation failures=(\d+) successes=(\d+) live_delta=(-?\d+)', stdout)
        if not match:
            raise ValueError('graph2の確保・解放照合数がない')
        result = dict(zip(['failures', 'successes', 'live_delta'], map(int, match.groups())))
        if result['failures'] <= 0 or result['successes'] <= 0 or result['live_delta'] != 0:
            raise ValueError('確保失敗・成功・解放の照合が不成立')
        return result
    raise ValueError(name)


def main():
    with open('/tmp/sirkit_performance_cpu12.lock', 'a') as global_lock:
        fcntl.flock(global_lock, fcntl.LOCK_EX)
        header = D / 'final.hpp'
        assert header.is_file(), '選定した本体を先にfinal.hppへ保存する'
        header_hash = sha(header)
        original = header.read_text()
        assert '#define SIRKIT_UNDIRECTED_LOW_LINK_DEFINED' in original
        assert '#define SIRKIT_UNWEIGHTED_GRAPH_DEFINED' in original
        assert 'template<class Id> struct Adjacent' in original, '型付きCSR候補を対象とする'
        forced = original
        substitutions = {}
        for name, expression in WIDE_CONDITIONS.items():
            count = original.count(expression)
            expected_count = count == 1 if name == 'edge_ids' else count in (0, 1)
            assert expected_count, (name, count)
            substitutions[name] = dict(expression=expression, count=count, replacement='false')
            forced = forced.replace(expression, 'false')
        assert forced != original
        wide_header = D / 'validation_forced_wide.hpp'
        temporary = wide_header.with_name(wide_header.name + '.tmp')
        temporary.write_text(forced)
        temporary.replace(wide_header)
        wide_hash = sha(wide_header)
        support_hashes = {name: sha(R / name) for name in SUPPORT_SOURCES}
        jobs = []
        for cc in COMPILERS:
            for setting in ['checked', 'skip']:
                for mode in ['default', 'forced_wide']:
                    for name, source in TESTS.items():
                        jobs.append(dict(compiler=cc, setting=setting, mode=mode,
                                         short_test=name, test=source.stem, source=str(source),
                                         sanitizer=False, pedantic=name == 'reference'))
                    source = TESTS['reference']
                    jobs.append(dict(compiler=cc, setting=setting, mode=mode,
                                     short_test='reference', test=source.stem, source=str(source),
                                     sanitizer=True, pedantic=False))
        assert len(jobs) == 32
        for index, row in enumerate(jobs):
            row.update(index=index, status='pending', source_sha256=sha(Path(row['source'])),
                       test_sha256=sha(Path(row['source'])))
        output = D / 'validation'
        output.mkdir(exist_ok=True)
        result = dict(
            header=str(header), header_sha256=header_hash,
            forced_wide_header=str(wide_header), forced_wide_header_sha256=wide_hash,
            forced_wide_conditions=substitutions, support_source_hashes=support_hashes,
            started_at_utc=now(), completed_at_utc=None, total_jobs=len(jobs),
            passed_jobs=0, completed_jobs=0, all_passed=False, jobs=jobs,
            scope='24件のGCC/Clang×checked/SKIP×default/forced-wide×独立参照/構築と照会の確保失敗、8件の同設定ASAN+UBSAN参照。巨大Mを物理的に構築した試験ではなく、通常サイズでsize_t経路を強制する。',
            settings=dict(standard='C++23', optimization='-O2', march_native=False,
                          compilers={key: dict(arguments=value[0], cpu=value[1]) for key, value in COMPILERS.items()},
                          pedantic_scope='非sanitizerのLowLink参照試験だけ-pedantic-errors。確保試験は他ライブラリも含むため通常の-O2。',
                          ASAN_OPTIONS='detect_leaks=0:halt_on_error=1', UBSAN_OPTIONS='halt_on_error=1',
                          leak_scope='host ptraceのためLeakSanitizerは無効。確保試験の独立live allocation counterでdelta=0を確認。',
                          lock='/tmp/sirkit_performance_cpu12.lock', compilation_during_timing=False))
        write_lock = threading.Lock()
        stop = threading.Event()

        def save():
            result['passed_jobs'] = sum(row.get('passed', False) for row in jobs)
            result['completed_jobs'] = sum(row['status'] in ['passed', 'failed'] for row in jobs)
            result['all_passed'] = result['passed_jobs'] == len(jobs)
            destination = D / 'final_validation.json'
            temporary = destination.with_name(destination.name + '.tmp')
            temporary.write_text(encode(result))
            temporary.replace(destination)

        def update(row, **data):
            with write_lock:
                row.update(**data)
                save()

        def unchanged(source, row):
            assert sha(header) == header_hash and sha(wide_header) == wide_hash, '選定本体が途中で変更された'
            assert sha(source) == row['test_sha256'], '試験本体が途中で変更された'
            assert all(sha(R / name) == digest for name, digest in support_hashes.items()), '補助ライブラリが途中で変更された'

        def run_one(row):
            if stop.is_set():
                return
            compiler, cpu = COMPILERS[row['compiler']]
            selected = wide_header if row['mode'] == 'forced_wide' else header
            source = Path(row['source'])
            executable = output / (f"{row['compiler']}_{row['setting']}_{row['mode']}_"
                                   f"{row['short_test']}_{'san' if row['sanitizer'] else 'plain'}")
            command = ['taskset', '-c', str(cpu), *compiler, '-std=c++23', '-O2',
                       f'-DLOW_LINK_SOURCE="{selected}"']
            if row['setting'] == 'skip':
                command.append('-DSKIP_RUNTIME_CHECKS')
            if row['pedantic']:
                command.append('-pedantic-errors')
            if row['sanitizer']:
                command += ['-fsanitize=address,undefined', '-fno-sanitize-recover=all', '-fno-omit-frame-pointer']
            command += [str(source), '-o', str(executable)]
            update(row, status='compiling', started_at_utc=now(), command=command,
                   header=str(selected), header_sha256=sha(selected), executable=str(executable),
                   support_source_hashes=support_hashes)
            try:
                unchanged(source, row)
                compiled = subprocess.run(command, capture_output=True, text=True, timeout=240)
                update(row, compile_returncode=compiled.returncode,
                       compile_stdout=compiled.stdout, compile_stderr=compiled.stderr)
                if compiled.returncode != 0:
                    raise RuntimeError('compiler failed')
                env = os.environ.copy()
                env['ASAN_OPTIONS'] = 'detect_leaks=0:halt_on_error=1'
                env['UBSAN_OPTIONS'] = 'halt_on_error=1'
                run_command = ['taskset', '-c', str(cpu), str(executable)]
                update(row, status='running', run_command=run_command,
                       executable_sha256=sha(executable))
                completed = subprocess.run(run_command, capture_output=True, text=True, timeout=180, env=env)
                update(row, returncode=completed.returncode, stdout=completed.stdout, stderr=completed.stderr)
                observed = counters(row['short_test'], completed.stdout) if completed.returncode == 0 else {}
                passed = completed.returncode == 0 and not completed.stderr and bool(observed)
                unchanged(source, row)
                update(row, status='passed' if passed else 'failed', returncode=completed.returncode,
                       stdout=completed.stdout, stderr=completed.stderr, counters=observed,
                       passed=passed, completed_at_utc=now())
                print(row['index'], row['compiler'], row['setting'], row['mode'],
                      row['short_test'], 'san' if row['sanitizer'] else 'plain',
                      passed, completed.stdout.strip(), flush=True)
                if not passed:
                    stop.set()
            except Exception as error:
                update(row, status='failed', passed=False, error=type(error).__name__ + ': ' + str(error),
                       completed_at_utc=now())
                stop.set()
                print(row['index'], row['compiler'], 'FAILED', str(error), flush=True)

        with write_lock:
            save()

        def compiler_worker(cc):
            for row in jobs:
                if row['compiler'] == cc:
                    run_one(row)

        with ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(compiler_worker, COMPILERS))
        result['completed_at_utc'] = now()
        with write_lock:
            save()
        assert result['all_passed'], f"{result['passed_jobs']}/{result['total_jobs']} jobs passed; see final_validation.json"
        print('Final validation PASS', result['passed_jobs'], 'jobs, header', header_hash, flush=True)


if __name__ == '__main__':
    main()
