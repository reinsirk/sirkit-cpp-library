# SPDX-License-Identifier: CC0-1.0
import subprocess,sys
from pathlib import Path
p=Path('/tmp/sirkit_lowlink_416612')
for args in [['validate_narrow.py'],['build.py','narrow_parent_pending'],['stage4.py']]:
 with(p/(args[0]+'.narrow.log')).open('w')as out:subprocess.run([sys.executable,str(p/args[0]),*args[1:]],stdout=out,stderr=subprocess.STDOUT,check=True)
