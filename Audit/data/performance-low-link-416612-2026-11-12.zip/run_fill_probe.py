# SPDX-License-Identifier: CC0-1.0
import subprocess,sys
from pathlib import Path
p=Path('/tmp/sirkit_lowlink_416612')
for script in ['validate_fill.py','build_fill_core.py','stage3.py']:
 with(p/(script+'.log')).open('w')as out:subprocess.run([sys.executable,str(p/script)],stdout=out,stderr=subprocess.STDOUT,check=True)
