# SPDX-License-Identifier: CC0-1.0
import subprocess,sys
from pathlib import Path
p=Path('/tmp/sirkit_lowlink_416612')
for kind in ['whole','core']:
 with (p/f'measure_final_{kind}.log').open('w')as out:subprocess.run([sys.executable,str(p/'measure_final.py'),kind],stdout=out,stderr=subprocess.STDOUT,check=True)
with (p/'check_final_fixtures.log').open('w')as out:subprocess.run([sys.executable,str(p/'check_final_fixtures.py')],stdout=out,stderr=subprocess.STDOUT,check=True)
