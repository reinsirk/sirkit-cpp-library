# SPDX-License-Identifier: CC0-1.0
# --applyなしでは正本を書き換えない。本体一致なら通常版のACを確認し、変更時は未提出扱い。
from pathlib import Path
import argparse
import copy
import hashlib
import json
import sys

R = Path('/home/reinsirk/Atcoder_Env')
D = Path('/tmp/sirkit_lowlink_416612')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(path.read_text())

def encode(data):
    return json.dumps(data, ensure_ascii=False, indent=2) + '\n'

def atomic_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.sirkit-online.tmp')
    temporary.write_text(encode(data))
    temporary.replace(path)

parser = argparse.ArgumentParser()
parser.add_argument('--apply', action='store_true')
parser.add_argument('--audit-file', default='Audit/online-low-link-416612-2026-11-12.json')
parser.add_argument('--performance-audit')
parser.add_argument('--library-override', help='dry-runのみ。別の本体を仮定して再提出判定を確認する')
args = parser.parse_args()
assert not (args.apply and args.library_override), '本体差替えはdry-run専用'
relative = Path(args.audit_file)
assert not relative.is_absolute() and '..' not in relative.parts and relative.parts[0] == 'Audit'
audit = copy.deepcopy(load(D / 'online_records.json'))
groups = load(R / 'Verify/current/groups/expansion_20261031.json')
journal = load(R / 'Verify/current/judgements.json')
sys.path.insert(0, str(R / 'Scripts'))
sys.dont_write_bytecode = True
import prepare_verify

entries = {entry['id']: entry for entry in prepare_verify.collect()}
records = {record['id']: record for record in audit['records']}
updated, report = {}, []
overrides = {'Graph/Low_Link.cpp': Path(args.library_override).read_bytes()} if args.library_override else None
for identifier, snapshot in records.items():
    snapshot['evidence_file'] = relative.as_posix()
    entry = copy.deepcopy(entries[identifier])
    entry['submission_urls'] = [snapshot['url']]
    assert sha(R / entry['driver']) == snapshot['driver_sha256'], (identifier, 'driver changed')
    for name, expected in snapshot['io_source_hashes'].items():
        assert sha(R / name) == expected, (identifier, name, 'IO changed')
    data, hashes = prepare_verify.render(entry, source_overrides=overrides)
    matches = digest(data) == snapshot['submission_sha256']
    current = copy.deepcopy(snapshot)
    current.update(matched_current_generation=matches, needs_resubmission=not matches,
                   current_source_hashes=hashes, current_submission_sha256=digest(data))
    if not matches:
        current['pending_reason'] = f"{snapshot['url'].rsplit('/', 1)[1]}は提出時のAC{snapshot['time_ms']}ms。現行の本体改修は未提出。main/共通IOは同一。"
    if args.performance_audit:
        current['performance_audit'] = args.performance_audit
    updated[identifier] = current
    group = next(entry for entry in groups['entries'] if entry['id'] == identifier)
    group['submission_urls'] = [snapshot['url']]
    label = '現行通常版の' if matches else '提出時の'
    group['limitations'] = f"{snapshot['url'].rsplit('/', 1)[1]}は{label}AC{snapshot['time_ms']}ms。提出時の本体/main/共通IOは本文と照合済み。" + (
        '通常版は再提出不要。派生版のオンライン判定へ転記しない。' if matches else
        '現行の本体改修は未提出で、このACに含めない。派生版のオンライン判定へ転記しない。')
    report.append(dict(id=identifier, online_status=snapshot['status'], online_time_ms=snapshot['time_ms'],
                       online_memory_bytes=snapshot['memory_bytes'], matched_current_generation=matches,
                       needs_resubmission=not matches, submitted_source_hashes=snapshot['source_hashes'],
                       current_source_hashes=hashes, current_submission_sha256=digest(data),
                       group_limitations=group['limitations']))

ids, present = set(updated), set()
for index, old in enumerate(journal['entries']):
    if old['id'] in ids:
        journal['entries'][index] = updated[old['id']]
        present.add(old['id'])
for identifier in updated:
    if identifier not in present:
        journal['entries'].append(updated[identifier])
auditpath = R / relative
if auditpath.exists():
    assert auditpath.read_text() == encode(audit), ('既存の監査記録を上書きしない', str(auditpath))
result = dict(mode='apply' if args.apply else 'dry-run', audit_file=str(auditpath),
              library_override=args.library_override, records=report,
              metadata_ready=True, variants_online_ac_claimed=False)
print(encode(result), end='')
if args.apply:
    atomic_json(auditpath, audit)
    atomic_json(R / 'Verify/current/groups/expansion_20261031.json', groups)
    atomic_json(R / 'Verify/current/judgements.json', journal)
    print('metadata updated; run prepare_verify.py and prepare_variant_verify.py next')
