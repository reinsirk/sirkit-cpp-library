# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import bench,json,random,statistics,subprocess,fcntl
D=Path('/tmp/sirkit_lowlink_416612');rng=random.Random(41661212);labels=['block_vertex_lazy_stamp','two_edge_single_reserve'];raw=[];summary=[]
names=['custom_cycle100k','custom_star100k','custom_random100k_500k','custom_random64'];fixtures=[f for f in bench.fixtures if f['name']in names and f['problem']=='biconnected_components']
def run(cc,label,case):
 bench.activate(D/f'{cc}_native_skip_{label}_core');p=subprocess.run(['setarch','x86_64','-R','taskset','-c','12',str(D/'active'),str(case['operation']),case['path'],str(case['repetitions'])],capture_output=True,text=True,check=True);assert not p.stderr;ns,digest=map(int,p.stdout.split());assert ns>0;return dict(cpu_ns=ns,digest=digest)
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for f in fixtures:
   for op in [4,5,6]:
    case={k:f[k]for k in ['name','n','m','path']};case.update(operation=op,repetitions=1024 if f['n']<1000 else 1);local=[];order=[l for l in labels for _ in range(3)]+['control']*3;rng.shuffle(order)
    for rep,label in enumerate(order):
     v=[run(cc,k,case)for k in ['base',label if label!='control'else'base','base']];assert len({r['digest']for r in v})==1;b,t,a=[r['cpu_ns']for r in v];drift=max(b,a)/min(b,a);r=dict(compiler=cc,flag='native',setting='skip',kind='core',case=case,label=label,rep=rep,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(r);local.append(r)
    ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in labels+['control']};row=dict(compiler=cc,flag='native',setting='skip',kind='core',case=case,ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},valid_counts={l:len(v)for l,v in ratios.items()});summary.append(row);print(row,flush=True);(D/'stage2_raw.json').write_text(json.dumps(raw));(D/'stage2_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
