# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,fcntl,json,hashlib
D=Path('/tmp/sirkit_lowlink_416612');rows=[]
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 def worker(cc):
  out=[]
  for label in ['base','block_vertex_lazy_stamp','two_edge_single_reserve']:
   exe=D/f'{cc}_native_skip_{label}_core';cmd=['taskset','-c','4'if cc=='gcc'else'6',*(['g++']if cc=='gcc'else['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']),'-std=c++23','-O2','-march=native','-DSKIP_RUNTIME_CHECKS','-DHEADER="'+str(D/(label+'.hpp'))+'"',str(D/'core.cpp'),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;out.append(dict(compiler=cc,label=label,command=cmd,header_sha256=hashlib.sha256((D/(label+'.hpp')).read_bytes()).hexdigest(),executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),passed=True))
  print(cc,'output core builds PASS',flush=True);return out
 with ThreadPoolExecutor(max_workers=2)as pool:
  for out in pool.map(worker,['gcc','clang']):rows+=out
(D/'output_builds.json').write_text(json.dumps(rows,indent=2)+'\n')
