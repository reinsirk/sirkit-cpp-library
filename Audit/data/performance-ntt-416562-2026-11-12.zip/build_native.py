# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,sys
D=Path('/tmp/sirkit_ntt_416562');rows=[]
for cc,args in [('gcc',['g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for label in sys.argv[1:]:
  cmd=['taskset','-c','4',*args,'-std=c++23','-O2','-march=native',str(D/(label+'_main.cpp')),'-o',str(D/f'{cc}_native_{label}_main')];subprocess.run(cmd,check=True,capture_output=True);rows.append(dict(compiler=cc,label=label,command=cmd));print(cc,'native',label,'build PASS',flush=True)
(D/'native_builds.json').write_text(json.dumps(rows,indent=2)+'\n')
