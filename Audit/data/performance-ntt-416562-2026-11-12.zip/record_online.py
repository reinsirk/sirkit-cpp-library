# SPDX-License-Identifier: CC0-1.0
# 保存済みAPIと提出時の本体/main/IOを照合する。正本・ネット・コンパイラには触れない。
from pathlib import Path
import copy
import datetime
import hashlib
import json
import sys

R = Path('/home/reinsirk/Atcoder_Env')
D = Path('/tmp/sirkit_ntt_416562')
AUDIT = 'Audit/online-ntt-416562-2026-11-12.json'
PREVIOUS = 'Audit/online-ntt-416560-2026-11-12.json'
IDENTIFIER, LIBRARY, SUBMISSION = 'ntt_convolution', 'Math/NTT.cpp', 416562

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def norm(source):
    return '\n'.join(line.rstrip() for line in source.replace('\r\n', '\n').splitlines()
                     if line.strip() and not line.startswith('// Submission:'))

sys.path.insert(0, str(R / 'Scripts'))
sys.dont_write_bytecode = True
import prepare_verify
retrieval_path = D / 'retrieval.json'
retrieval = json.loads(retrieval_path.read_text())
response, saved = D / '416562.json', D / '416562.cpp'
endpoint = 'https://v3.api.judge.yosupo.jp/submissions/416562'
assert retrieval['url'] == endpoint and retrieval['response_sha256'] == sha(response)
data = json.loads(response.read_text())
overview = data['overview']
assert overview['id'] == SUBMISSION and overview['problem_name'] == 'convolution_mod'
assert overview['status'] == 'AC'
assert len(data['case_results']) == 53 and all(row['status'] == 'AC' for row in data['case_results'])
assert saved.read_bytes() == data['source'].encode()
snapshot = D / f'before/Verify/current/submissions/{IDENTIFIER}.cpp'
snapshot_bytes = snapshot.read_bytes()
assert norm(data['source']) == norm(snapshot.read_text()), '提出本文と変更前スナップショットが不一致'
driver, io = f'Verify/current/drivers/{IDENTIFIER}_main.cpp', 'Verify/current/common/fast_io.hpp'
assert sha(R / driver) == sha(D / 'before' / driver), 'mainの変更があるため手動確認が必要'
assert sha(R / io) == sha(D / 'before' / io), '共通IOの変更があるため手動確認が必要'
entry = copy.deepcopy(next(e for e in prepare_verify.collect() if e['id'] == IDENTIFIER))
assert entry['libraries'] == [LIBRARY] and entry['driver'] == driver
entry['submission_urls'] = ['https://judge.yosupo.jp/submission/416562']
generation, source_hashes = prepare_verify.render(entry,
    source_overrides={LIBRARY: (D / 'before' / LIBRARY).read_bytes()},
    driver_override=(D / 'before' / driver).read_text())
assert source_hashes == {LIBRARY: sha(D / 'before' / LIBRARY)}
assert norm(generation.decode()) == norm(data['source']) == norm(snapshot.read_text())
# 元のスナップショットを保ち、フレームワーク用の新しいSubmission注記だけを別ファイルへ生成する。
lines = snapshot_bytes.splitlines(keepends=True)
annotation_changes = 0
for index, line in enumerate(lines):
    if line.startswith(b'// Submission:'):
        ending = b'\r\n' if line.endswith(b'\r\n') else b'\n' if line.endswith(b'\n') else b''
        lines[index] = b'// Submission: https://judge.yosupo.jp/submission/416562' + ending
        annotation_changes += 1
assert annotation_changes == 1
annotation_only_bytes = b''.join(lines)
assert annotation_only_bytes == generation, '再生成差分がSubmission注記以外にもある'
rebased = D / 'submitted_generation.cpp'
rebased.write_bytes(generation)
assert snapshot.read_bytes() == snapshot_bytes
checked = datetime.datetime.now(datetime.timezone.utc).isoformat()
record = dict(id=IDENTIFIER, status=overview['status'], url='https://judge.yosupo.jp/submission/416562',
              time_ms=round(overview['time'] * 1000), memory_bytes=overview['memory'], language=overview['lang'],
              submission_time=overview['submission_time'], fetched_at_utc=retrieval['fetched_at_utc'],
              checked_at_utc=checked, case_results=data['case_results'], submission_sha256=sha(rebased),
              uploaded_source_sha256=sha(saved), original_submission_snapshot_sha256=sha(snapshot),
              rebased_submitted_generation_sha256=sha(rebased),
              submission_sha256_scope='フレームワーク照合用。最新Submission注記で再生成した提出用コードの値で、今回は原スナップショットとbyte単位で一致。実際のアップロード本文はuploaded_source_sha256、原スナップショットはoriginal_submission_snapshot_sha256で別に保持する。',
              source_hashes={LIBRARY: sha(D / 'before' / LIBRARY)},
              driver_sha256=sha(D / 'before' / driver), io_source_hashes={io: sha(D / 'before' / io)},
              io_mode='shared_fast_io', matched_prescreen_snapshot=True, matched_rebased_submitted_generation=True,
              source_match='空行・改行・行末空白・Submission注記のみ除いて、提出本文・原スナップショット・最新注記で再生成した本体/main/共通IOが一致。今回は再生成と原スナップショットがbyte単位で一致する。',
              evidence_file=AUDIT)
source = dict(id=IDENTIFIER, endpoint=endpoint, response_file=str(response), response_sha256=sha(response),
              fetched_at_utc=retrieval['fetched_at_utc'], saved_source_file=str(saved), saved_source_sha256=sha(saved),
              submitted_snapshot=str(snapshot), original_submission_snapshot_sha256=sha(snapshot),
              rebased_submitted_generation=str(rebased), rebased_submitted_generation_sha256=sha(rebased),
              original_snapshot_submission_annotations=[line.decode().rstrip() for line in snapshot_bytes.splitlines() if line.startswith(b'// Submission:')],
              rebased_submission_annotation='// Submission: https://judge.yosupo.jp/submission/416562',
              only_submission_annotation_rebased=(generation != snapshot_bytes), original_snapshot_matches_generated_bytes=(generation == snapshot_bytes), is_latest_at_saved_API_snapshot=overview.get('is_latest'))
previous_path = R / PREVIOUS
previous_bytes = previous_path.read_bytes()
old = next(r for r in json.loads(previous_bytes)['records'] if r['id'] == IDENTIFIER)
comparison = dict(id=IDENTIFIER, previous_url=old['url'], current_url=record['url'],
    previous_evidence_file=PREVIOUS, previous_evidence_sha256=sha(previous_path),
    previous_time_ms=old['time_ms'], current_time_ms=record['time_ms'], time_delta_ms=record['time_ms'] - old['time_ms'],
    time_change_percent=(record['time_ms'] / old['time_ms'] - 1) * 100,
    previous_memory_bytes=old['memory_bytes'], current_memory_bytes=record['memory_bytes'],
    memory_delta_bytes=record['memory_bytes'] - old['memory_bytes'],
    memory_change_percent=(record['memory_bytes'] / old['memory_bytes'] - 1) * 100,
    same_driver=old['driver_sha256'] == record['driver_sha256'], same_shared_io=old['io_source_hashes'] == record['io_source_hashes'],
    previous_source_hashes=old['source_hashes'], submitted_source_hashes=record['source_hashes'])
output = dict(records=[record], endpoints=[endpoint], checked_at_utc=checked,
              normalization='CRLFをLFにし、空行・行末空白・先頭が // Submission: の注記のみ除く。他のコード/pragmaは除外しない。',
              source_snapshots=[source], retrieval=retrieval, retrieval_file_sha256=sha(retrieval_path),
              comparisons=[comparison],
              comparison_scope='保存済みオンライン判定間の比較。main/共通IOは同一だが、サーバー負荷・コンパイラ設定は統制できず、本体だけの厳密な速度比較とは扱わない。',
              scope='416562のAC52msと提出時の本体/main/共通IOを照合。原スナップショットを保存し、フレームワーク用のsubmission_sha256は最新注記で再生成した値を記録する。今回は再生成と原スナップショットがbyte単位で一致する。fetched_atはAPI取得時刻、checked_atはローカル照合時刻。後の改修や派生版へオンラインACを転記しない。')
old_cases={row['case']:row for row in old['case_results']}
assert set(old_cases)=={row['case'] for row in record['case_results']}
output['case_comparisons']=[dict(case=row['case'],previous_time_ms=round(old_cases[row['case']]['time']*1000), current_time_ms=round(row['time']*1000), time_delta_ms=round((row['time']-old_cases[row['case']]['time'])*1000),previous_memory_bytes=old_cases[row['case']]['memory'],current_memory_bytes=row['memory']) for row in record['case_results']]
assert previous_path.read_bytes() == previous_bytes
(D / 'online_records.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(record={key: record[key] for key in ('id', 'status', 'time_ms', 'memory_bytes', 'source_hashes', 'submission_sha256', 'original_submission_snapshot_sha256', 'uploaded_source_sha256')}, comparison=comparison), ensure_ascii=False, indent=2))
