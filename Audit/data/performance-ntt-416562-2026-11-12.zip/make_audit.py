# SPDX-License-Identifier: CC0-1.0
# 現行版を維持した場合だけ、完了した候補比較から/tmpへ証跡を作る。
from pathlib import Path
import hashlib,json,math,statistics,shutil,zipfile
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_ntt_416562');P=Path('/tmp/sirkit_ntt_416532')
LIBRARY='Math/NTT.cpp';PERFORMANCE='Audit/performance-ntt-416562-2026-11-12.json';ONLINE='Audit/online-ntt-416562-2026-11-12.json';EVIDENCE='Audit/data/performance-ntt-416562-2026-11-12.zip';PREVIOUS='Audit/distribution-manifest-before-ntt-416562-2026-11-12.json';LABELS=['tail','half','tail_half'];CHOSEN='tail_half'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def encode(x):return json.dumps(x,ensure_ascii=False,indent=2)+'\n'
def qualified(row,label):return row['valid_counts'].get(label,0)>=5 and row['valid_counts'].get('control',0)>=2 and row['ratios'].get(label) is not None and row['ratios'].get('control') is not None

def stats(rows,fields,label):
 out=[]
 for key in sorted({tuple(r[k]for k in fields)for r in rows}):
  group=[r for r in rows if tuple(r[k]for k in fields)==key];valid=[r for r in group if qualified(r,label)]
  if valid:out.append(dict(zip(fields,key))|dict(total_cells=len(group),qualified_cells=len(valid),candidate_ratio=math.exp(statistics.mean(math.log(r['ratios'][label])for r in valid)),identical_control_ratio=math.exp(statistics.mean(math.log(r['ratios']['control'])for r in valid)),minimum_ratio=min(r['ratios'][label]for r in valid),maximum_ratio=max(r['ratios'][label]for r in valid)))
 return out

def main():
 before=sha(D/'before'/LIBRARY);after=sha(R/LIBRARY);assert before==after==sha(D/'base.hpp'),'この監査器は維持判断専用。新しい本体を採用した場合は実行しない'
 frozen=['Verify/current/drivers/ntt_convolution_main.cpp','Verify/current/common/fast_io.hpp','Document/ntt.md','Examples/ntt_example.cpp','Math/Formal_Power_Series.cpp','Math/Linear_Recurrence.cpp','Math/Convolution.cpp','Math/Polynomial.cpp']
 for p in frozen:assert (R/p).read_bytes()==(D/'before'/p).read_bytes(),p
 submission='Verify/current/submissions/ntt_convolution.cpp';assert (R/submission).read_bytes()==(D/'submitted_generation.cpp').read_bytes()==(D/'before'/submission).read_bytes()==(D/'base_main.cpp').read_bytes()
 record=next(x for x in load(D/'online_records.json')['records']if x['id']=='ntt_convolution');assert record['url']=='https://judge.yosupo.jp/submission/416562'and record['status']=='AC'and record['time_ms']==52 and record['source_hashes']=={LIBRARY:before}
 assert len(record['case_results'])==53 and all(x['status']=='AC'for x in record['case_results'])
 journal=next(x for x in load(R/'Verify/current/judgements.json')['entries']if x['id']=='ntt_convolution');assert journal['url']==record['url']and journal['time_ms']==52 and journal['matched_current_generation']and not journal['needs_resubmission']and journal['current_source_hashes']=={LIBRARY:after}
 canonical_test=R/'Verify/current/tests/ntt_montgomery_reference_test.cpp';prior=load(R/'Audit/performance-ntt-416560-2026-11-12.json');assert prior['source_sha256']['after']==after and prior['validation']['tests_sha256'][canonical_test.name]==sha(canonical_test)
 refs=load(D/'half_validation.json');terminal=load(D/'review/terminal_half_validation.json');assert len(refs)==8 and len(terminal)==4
 assert {(x['label'],x['compiler'],x['setting'])for x in refs}=={(k,cc,st)for k in ['half','tail_half']for cc in ['gcc','clang']for st in ['checked','skip']}
 for x in refs:
  assert x['source_sha256']==sha(D/(x['label']+'.hpp')) and x['returncode']==0 and not x['stderr']and 'NTT reference checks='in x['stdout']
  assert str(canonical_test)in x['command']and '-std=c++23'in x['command']and '-O2'in x['command']
 terminal_test=D/'review/terminal_half_reference.cpp';assert (D/'tail.hpp').read_bytes()==(D/'review/terminal_half.hpp').read_bytes()
 assert {(x['compiler'],x['setting'])for x in terminal}=={(cc,st)for cc in ['gcc','clang']for st in ['checked','skip']}
 for x in terminal:assert x['header_sha256']==sha(D/'tail.hpp')and x['source_sha256']==sha(terminal_test)and x['passed']and x['compile_returncode']==x['returncode']==0 and not x['stderr']
 whole=load(D/'paired_whole_summary.json');core=load(D/'paired_core_summary.json');native=load(D/'native_summary.json');screen=load(D/'screen_summary.json')
 assert len(whole)==68 and len(core)==164 and len(native)==14 and len(screen)==26
 assert all(qualified(x,k)for x in native for k in LABELS),'native比較が未完了'
 fixtures=load(D/'fixtures.json');assert len(fixtures)==73 and(D/'fixtures.json').read_bytes()==(Path('/tmp/sirkit_ntt_416560')/'fixtures.json').read_bytes()
 outputs=load(D/'whole_output_validation.json');assert len(outputs)==146 and {(x['compiler'],x['case'],x['label'])for x in outputs}=={(cc,f['name'],CHOSEN)for cc in ['gcc','clang']for f in fixtures}
 for name in ['paired_whole_raw.json','paired_core_raw.json','native_raw.json','screen_raw.json']:assert load(D/name)
 holdout=None
 if(D/'holdout.json').exists():holdout=dict(path='holdout.json',sha256=sha(D/'holdout.json'),result=load(D/'holdout.json'))
 for p in [canonical_test,terminal_test]:
  target=D/'evidence_tests'/p.name;target.parent.mkdir(exist_ok=True);shutil.copyfile(p,target)
 meta=D/'fixtures_metadata';meta.mkdir(exist_ok=True)
 for n in ['source_audit.json','commands.json','summary.json']:shutil.copyfile(P/'fixtures'/n,meta/n)
 audit=dict(date='2026-11-12',library=LIBRARY,decision='retain_current_after_terminal_tail_and_half_product_comparison',required_resubmission=[],source_sha256=dict(before=before,after=after),accepted_source_performance_audit='Audit/performance-ntt-416560-2026-11-12.json',online_evidence=ONLINE,
  online_scope='416562は現行4430c578本体で全53ケースAC・52ms。原スナップショット・提出本文・現在の本体/main/共通IOが一致。今回の未採用候補や派生版へこのACを転記しない。',retention_scope='main・共通IO・公開API・所有権・根キャッシュ・係数検査・SKIP除外・標準代替経路を含む既存本体をそのまま維持し、今回の候補は正本へ採用しない。以前の採用済み最適化の根拠は416560監査を維持する。',
  frozen_main_IO_Document_example_dependencies={p:sha(R/p)for p in frozen},candidates=[dict(name=k,sha256=sha(D/(k+'.hpp')),adopted=False)for k in LABELS],
  candidate_scope=dict(tail='再帰的ゼロ補完の終了時に残る半分ゼロの段を追加で省略する候補。',half='8点段で前後半が複製される4係数のMontgomery積を重複計算しない候補。',tail_half='上記2候補の組合せ。'),
  decision_scope='小さい速度差と同一実行体対照の変動、既存操作との兼ね合いを含めて現行版を維持する。すべての条件で候補が遅い、または数学的にこれ以上の改善が不可能とまでは主張しない。',
  measurement=dict(topology=load(D/'topology.json'),cpu='i9-14900K CPU12のP-Core。E-Coreは性能評価しない。',compilers=dict(GCC='15.2.0',Clang='21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'),flags=['-std=c++23','-O2'],extra_pragmas=False,compilation_during_timing=False,lock='/tmp/sirkit_performance_cpu12.lock',ASLR='子だけsetarch x86_64 -R、同じactiveパス。',
   protocol='旧版→候補→旧版で1組。候補を両端中央値で割る。旧版両端が10%以内の組だけ有効とし、候補自身の時間では除外しない。基本は候補9組・同一実行体対照3組、候補5組と対照2組が基準。探索screenは各候補5組。補充の実施範囲はraw/スクリプトへ保持。',
   inputs='固定revision73876f1cbcf082d2b22722924b924d3d65a2f00eの公式53入力と補足20入力、計73件。オンライン非公開入力との同一性を主張しない。',fixtures_sha256=sha(D/'fixtures.json'),independent_outputs='38件の独立な全出力SHA、全入力の端点と多項式評価0/1/−1、組合せ候補と現行版のGCC/Clang各73件の出力SHA一致。',
   whole_time='固定main/共通IO/SKIP/コンパイラ/入力の子user+system CPU時間。大規模34入力×2compiler。',whole_rows=len(whole),whole_triplets=len(load(D/'paired_whole_raw.json')),qualified_whole_cells=sum(qualified(x,CHOSEN)for x in whole),insufficient_whole_cells=[x for x in whole if not qualified(x,CHOSEN)],whole_statistics=stats(whole,['compiler'],CHOSEN),official_whole_statistics=stats([x for x in whole if x['case'].startswith('official_')],['compiler'],CHOSEN),
   core_time='std::clock。入力準備は外、API計算・全結果checksum・返却結果破棄は内。coldでは毎回NTT作成/解放。prepareは計測外transformで根を観測する。基本反復max(1,32768/max(n,m))。',core_rows=len(core),core_triplets=len(load(D/'paired_core_raw.json')),qualified_core_cells=sum(qualified(x,CHOSEN)for x in core),insufficient_core_cells=[x for x in core if not qualified(x,CHOSEN)],core_statistics=stats(core,['compiler','setting','op'],CHOSEN),large_core_statistics=stats([x for x in core if max(x['n'],x['m'])>=200000],['compiler','setting','op'],CHOSEN),
   screen=dict(cells=len(screen),triplets=len(load(D/'screen_raw.json')),statistics={k:stats(screen,['compiler'],k)for k in LABELS},qualified_cells={k:sum(qualified(x,k)for x in screen)for k in LABELS},insufficient_cells={k:[x for x in screen if not qualified(x,k)]for k in LABELS},scope='探索26条件には基準未達のセルがあり、全26条件が確定済みとは扱わない。'),
   native_comparison=dict(flags=['-std=c++23','-O2','-march=native'],cpu='同じP-Core。Library CheckerのMilan実機ではない。',cells=len(native),triplets=len(load(D/'native_raw.json')),all_candidates_qualified=True,statistics={k:stats(native,['compiler'],k)for k in LABELS},rows=native),holdout=holdout,no_claim_every_condition_slower_or_faster=True),
  validation=dict(canonical_source_unchanged=True,current_online=dict(status='AC',cases=53,time_ms=52),candidate_reference_jobs=12,all_candidate_reference_jobs_passed=True,canonical_reference_source_sha256=sha(canonical_test),canonical_test_scope='half/組合せの8条件は現在の独立参照テストをGCC/Clang・検査有効/SKIPで実行。端末半ゼロ候補の4条件は別の追加境界参照テストを実行。',terminal_reference_source_sha256=sha(terminal_test),candidate_validation_files=['half_validation.json','review/terminal_half_validation.json'],normal_tests_and_profiles_scope='今回の正本は変更しないため、新規の44条件検査や派生版10件の再実施とは主張しない。既存本体の44条件・派生版の記録は416560監査に残し、今回の候補12条件と現行通常版のオンライン本文一致を別に扱う。'),
  license='未採用候補は既存CC0実装への独自変更。今回の証跡へ外部ライブラリや公式生成器の本体は含めない。',evidence_archive=EVIDENCE,evidence_scope='候補・独立参照試験・証明・比較raw・ビルド/検証コマンド・公開提出API原本。巨大入力/出力・実行体・外部frontend/HTML/TOMLを除外。')
 draft=D/Path(PERFORMANCE).name;evidence=D/Path(EVIDENCE).name;previous=D/Path(PREVIOUS).name;previous.write_bytes((D/'before/Distribution/manifest.json').read_bytes());(D/'audit_draft.json').write_text(encode(audit));excluded={'audit_draft.json',draft.name,'distribution_update.log'};paths=[]
 for p in D.rglob('*'):
  if not p.is_file()or p.name in excluded or p.suffix not in {'.py','.hpp','.cpp','.json','.diff','.md','.log'}:continue
  rel=p.relative_to(D)
  if rel.parts[0]=='platform_evidence':continue
  if rel.parts[0]=='profiles'and(p.suffix!='.json'or(len(rel.parts)>1 and rel.parts[1]in{'snapshots','artifacts','sources'})):continue
  paths.append(p)
 with zipfile.ZipFile(evidence,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in sorted(paths):z.write(p,p.relative_to(D).as_posix())
 audit['evidence_archive_sha256']=sha(evidence);draft.write_text(encode(audit));print(encode(dict(audit=str(draft),audit_target=PERFORMANCE,evidence=str(evidence),evidence_target=EVIDENCE,previous_manifest=str(previous),previous_manifest_target=PREVIOUS,evidence_bytes=evidence.stat().st_size,evidence_files=len(paths),repository_written=False)),end='')
if __name__=='__main__':main()
