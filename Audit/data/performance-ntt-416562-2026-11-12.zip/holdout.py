# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import bench,json,random,statistics,fcntl,subprocess
D=Path('/tmp/sirkit_ntt_416562');rng=random.Random(5620562);raw=[];rows=[]
def core(cc,st,label,op,n,reps):
 bench.activate(D/f'{cc}_{st}_{label}_core');p=subprocess.run(['setarch','x86_64','-R','taskset','-c','12',str(D/'active'),str(op),str(n),str(n),str(reps)],capture_output=True,text=True,check=True);assert not p.stderr;ns,digest=map(int,p.stdout.split());return dict(cpu_ns=ns,digest=digest)
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 cases=[dict(mode='whole',compiler=cc,flags=fl,case=name)for cc in ['gcc','clang']for fl in ['','_native']for name in ['official_max_random_00','official_fft_killer_00','official_small_and_large_00','official_small_and_large_01']]+[dict(mode='core',compiler=cc,setting=st,op=op,n=n,reps=reps)for cc in ['gcc','clang']for st in ['checked','skip']for op,n,reps in [(4,65536,16),(5,524288,2)]]
 for case in cases:
  if case['mode']=='whole':
   fixture=next(f for f in bench.fixtures if f['name']==case['case'])
   def run(label):return bench.run_whole(case['compiler']+case['flags'],label,fixture)
   key='output_sha256'
  else:
   def run(label):return core(case['compiler'],case['setting'],label,case['op'],case['n'],case['reps'])
   key='digest'
  local=[];order=['tail_half']*9+['control']*9;rng.shuffle(order)
  for rep,label in enumerate(order):
   v=[run(l)for l in ['base',label if label!='control'else'base','base']];assert len({r[key]for r in v})==1
   b,t,a=[r['cpu_ns']for r in v];drift=max(b,a)/min(b,a);r=case|dict(label=label,rep=rep,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(r);local.append(r)
  ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in ['tail_half','control']};r=case|dict(valid_counts={l:len(v)for l,v in ratios.items()},ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},sufficient=all(len(v)>=5 for v in ratios.values()));rows.append(r);print(r,flush=True);(D/'holdout_raw.json').write_text(json.dumps(raw));(D/'holdout_summary.json').write_text(json.dumps(rows,indent=2)+'\n')
