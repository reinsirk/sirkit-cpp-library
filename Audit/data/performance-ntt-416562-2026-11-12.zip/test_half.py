# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib
D=Path('/tmp/sirkit_ntt_416562');R=Path('/home/reinsirk/Atcoder_Env');rows=[]
for label in ['half','tail_half']:
 for cc,args in [('gcc',['g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  for st in ['checked','skip']:
   h=D/(label+'.hpp');exe=D/f'{cc}_{st}_{label}_ref';cmd=['taskset','-c','8',*args,'-std=c++23','-O2',*(['-DSKIP_RUNTIME_CHECKS']if st=='skip'else[]),f'-DNTT_HEADER="{h}"',str(R/'Verify/current/tests/ntt_montgomery_reference_test.cpp'),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr
   p=subprocess.run(['taskset','-c','8',str(exe)],text=True,capture_output=True);r=dict(label=label,compiler=cc,setting=st,command=cmd,source_sha256=hashlib.sha256(h.read_bytes()).hexdigest(),returncode=p.returncode,stdout=p.stdout,stderr=p.stderr);rows.append(r);assert p.returncode==0 and not p.stderr,r;print(label,cc,st,p.stdout.strip(),flush=True)
(D/'half_validation.json').write_text(json.dumps(rows,indent=2)+'\n')
