# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_ntt_416562/review');header=D/'terminal_half.hpp'
s=(R/'Verify/current/tests/ntt_montgomery_reference_test.cpp').read_text()
extra='''template<std::uint32_t Mod,std::uint32_t Root>void terminal_half_cases(){
 NTT<Mod,Root>engine;
 for(auto [n,m]:{std::pair{63,1024},std::pair{64,1024},std::pair{65,1024},std::pair{95,512},std::pair{96,512},std::pair{129,4096}}){
  if(std::bit_ceil(static_cast<std::size_t>(n+m-1))>engine.max_length())continue;
  for(bool swapped:{false,true}){
   std::vector<std::uint32_t>a(n,Mod-1),b(m,Mod-1);if(swapped)a.swap(b);
   const auto c=engine.convolution_normalized(a,b);
   for(std::size_t i=0;i<c.size();++i)check(c[i]==std::min({i+1,a.size(),b.size(),c.size()-i})%Mod);
#ifndef SKIP_RUNTIME_CHECKS
   for(bool right:{false,true})for(auto bad:{Mod,UINT32_MAX}){
    auto&target=right?b:a;
    for(auto position:{std::size_t{0},target.size()/2,target.size()-1}){
     target[position]=bad;rejects<std::invalid_argument>([&]{engine.convolution_normalized(a,b);});target[position]=Mod-1;
    }
   }
#endif
  }
 }
}
'''
prefix='terminal_half_cases<998244353,3>();terminal_half_cases<167772161,3>();terminal_half_cases<1053818881,7>();terminal_half_cases<1224736769,3>();terminal_half_cases<2013265921,31>();'
assert s.count('int main(){')==1;s=s.replace('int main(){',extra+'int main(){'+prefix);src=D/'terminal_half_reference.cpp';src.write_text(s)
rows=[]
for cc,args in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for st in ['checked','skip']:
  exe=D/f'{cc}_{st}_terminal_reference';cmd=['taskset','-c','6',*args,'-std=c++23','-O2',*(['-DSKIP_RUNTIME_CHECKS']if st=='skip'else[]),f'-DNTT_HEADER="{header}"',str(src),'-o',str(exe)];a=subprocess.run(cmd,capture_output=True,text=True);row=dict(compiler=cc,setting=st,command=cmd,header_sha256=hashlib.sha256(header.read_bytes()).hexdigest(),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),compile_returncode=a.returncode,compile_stderr=a.stderr);assert a.returncode==0,row
  p=subprocess.run(['taskset','-c','6',str(exe)],capture_output=True,text=True);row.update(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,passed=p.returncode==0 and not p.stderr);rows.append(row);(D/'terminal_half_validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,st,row['passed'],p.stdout.strip(),flush=True);assert row['passed'],row
