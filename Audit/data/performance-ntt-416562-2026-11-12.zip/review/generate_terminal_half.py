# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json,difflib
D=Path('/tmp/sirkit_ntt_416562/review');R=Path('/home/reinsirk/Atcoder_Env');base=(R/'Math/NTT.cpp').read_text();assert hashlib.sha256(base.encode()).hexdigest()=='4430c578d353c87744681884b1288a51fc193e77d40edba4b9daff9f4dbee88b'
a=base.index('    template<bool Check>\n    [[gnu::target("avx2")]]\n    void forward_zero_padded_avx2');b=base.index('    template<bool Check, bool Encode>\n',a);old=base[a:b]
new='''    template<bool Check, bool Encode = true>
    [[gnu::target("avx2")]]
    void forward_zero_padded_avx2(std::vector<std::uint32_t>& a,
                                  [[maybe_unused]] std::size_t length=0) const {
        if constexpr(Encode)length=a.size();
        const auto quarter=length/4;
        // 各区間の後半は追加ゼロ。先頭段以外の入力は符号化・検査済み。
        for(std::size_t block=0;block<a.size();block+=length)for(std::size_t j=0;j<quarter;j+=8) {
            auto x0=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+block+j));
            auto x1=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a.data()+block+quarter+j));
            if constexpr(Encode) {
#ifndef SKIP_RUNTIME_CHECKS
                if constexpr(Check){vector_check(x0);vector_check(x1);}
#endif
                const auto r2=_mm256_set1_epi32(static_cast<int>(r_squared_));
                x0=vector_multiply(x0,r2);x1=vector_multiply(x1,r2);
            }
            const auto first=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data()+2*quarter+j));
            const auto second=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data()+3*quarter+j));
            const auto third=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(roots_.data()+quarter+j));
            const auto v2=vector_multiply(x0,first),v3=vector_multiply(x1,second);
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+block+j),vector_add(x0,x1));
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+block+quarter+j),vector_multiply(vector_subtract(x0,x1),third));
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+block+2*quarter+j),vector_add(v2,v3));
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(a.data()+block+3*quarter+j),vector_multiply(vector_subtract(v2,v3),third));
        }
        forward_avx2<false,true>(a,length/4);
    }
'''
s=base[:a]+new+base[b:]
oldtail='''                forward_avx2<false,true>(a,length);return;
'''
newtail='''                if(length>=32 && active<=length/2)forward_zero_padded_avx2<false,false>(a,length);
                else forward_avx2<false,true>(a,length);
                return;
'''
assert s.count(oldtail)==1;s=s.replace(oldtail,newtail)
(D/'terminal_half.hpp').write_text(s);(D/'terminal_half.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='Math/NTT.cpp',tofile='terminal_half.hpp')))
(D/'terminal_half_metadata.json').write_text(json.dumps(dict(base_sha256=hashlib.sha256(base.encode()).hexdigest(),candidate_sha256=hashlib.sha256(s.encode()).hexdigest(),change='Terminal half-zero radix4 stage in each block after recursive zero-quarter stages; first-stage-only encoding/checks; same publicAPI/ownership/standardpath.'),ensure_ascii=False,indent=2)+'\n')
