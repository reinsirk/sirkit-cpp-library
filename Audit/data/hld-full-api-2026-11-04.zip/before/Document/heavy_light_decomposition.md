# 重軽分解

`with_values<Range>(values)`は、木の分解と選んだBIT／Segtreeを所有する`HeavyLightValues`を返します。初期値は**values[v]が頂点vの値**になる順で渡し、操作も頂点番号を使います。並べ替え・添字変換は内部で行います。[本体](../Graph/Heavy_Light_Decomposition.cpp)・[完全な使用例](../Examples/heavy_light_decomposition_example.cpp)。

```cpp
Graph tree{{1}, {0,2}, {1}}; // 0―1―2、根は既定で0。
std::vector<std::int64_t> value{10,20,30};
auto hld = HeavyLightDecomposition(tree)
    .with_values<fenwick_tree<std::int64_t>>(value);
hld.add(1, 5);                       // 頂点1を20→25にする。
auto sum = hld.path_prod(0, 2);       // 0→1→2の和、65。
auto subtree = hld.subtree_prod(1);  // 頂点1とその子孫の和、55。
auto x = hld.get(1);                 // 25。value[1]自体は20のまま。
```

## 集計器と演算の選び方

| Rangeに指定する型 | 向いている操作 |
| --- | --- |
| `fenwick_tree<T>` | 頂点への加算と経路・部分木の和。`get/set/add`が使える。 |
| `segtree<S,op,e>` | 頂点の代入と経路・部分木の最小値・最大値・積など。`get/set`が使える。 |
| `lazy_segtree<S,op,e,F,mapping,composition,id>` | 点・経路・部分木の一括更新も必要な場合。`get/set/apply`が使える。 |

Tは値、Sは各頂点に置く値と集計結果の型で、初期値はそれぞれvector<T>／vector<S>です。op(a,b)は2つの結果を結合し、e()は空区間の結果（左右の単位元）を返します。opには結合則が必要です。Fは更新内容の型、mapping(f,x)は更新後の集計値、composition(newer,older)は古い更新の後に新しい更新を行う合成、id()は何もしない更新を返します。[型引数の詳細](lazy_segment_tree.md)と完全例に範囲加算の定義があります。使う集計器も貼り付けます。実ACLも使用でき、Mintは利用側で用意します。

## 操作と経路の向き

| API | 引数・戻り値 |
| --- | --- |
| `layout.with_values<Range,Ordered=false>(values)` | 長さNのvectorから、分解と値を独立所有するHLDを作る。既存layoutはコピー、一時layoutは移動。 |
| `get(v)` / `set(v,x)` / `add(v,x)` | 頂点vの値／xへの代入／xの加算。addはBIT用。 |
| `apply(v,f)` / `path_apply(u,v,f,edges=false)` / `subtree_apply(v,f,edges=false)` | 点／u→vの経路／vを根とする部分木への更新。対応するapplyを持つ集計器で使う。 |
| `path_prod(u,v,edges=false)` / `subtree_prod(v,edges=false)` | 両端を含む経路／vを含む部分木の結果。prodはRangeで決めた和・最小値などを返す。 |
| `values()` | 全値を頂点番号順のvectorで返す。 |
| `build(g,values,root=0)` / `clear()` / `swap(other)` | 分解と値を一緒に再構築／空にする／交換する。値なしのbuildは使わない。 |

**既定のOrdered=falseは、順序を入れ替えても結果が同じ演算用**です。和・最小値・最大値はこのまま使えます。文字列連結・関数合成などはtrueにし、u→vの順に集計します。trueでは集計器2本分の領域・更新を使います。値の順を反転し、個々の辺の値を逆元にする機能ではありません。concatを文字列連結、empty_wordを空文字列を返す関数とすると、上の木で次のように使えます。

```cpp
using Words = segtree<std::string, concat, empty_word>;
std::vector<std::string> token{"a","b","c"};
auto words = HeavyLightDecomposition(tree).with_values<Words,true>(token);
auto forward = words.path_prod(0,2); // "abc"。
auto backward = words.path_prod(2,0); // "cba"。
```

**辺を扱うときは、親辺の値を子頂点の位置へ渡し、edges=trueにします。** 初期値はN個必要で、各根には0やe()を置きます。根0の0―1―2では、辺(0,1)をvalues[1]、辺(1,2)をvalues[2]へ置きます。`path_prod(0,2,true)`はこの2辺を集計し、`subtree_prod(1,true)`は部分木の内部の辺(1,2)だけを集計します。`set(2,x)`は親辺(1,2)の更新です。経路ではLCA、部分木では指定頂点の位置を除きます。`path_prod(v,v)`は頂点vの値、`path_prod(v,v,true)`は空経路の単位元です。葉の辺部分木も空で、空区間の更新は何もしません。非可換な部分木積はDFS添字順です。

## 分解だけを使うAPI

`HeavyLightDecomposition(g,root=0)`は分解だけを用意します。`index(v)`／`vertex_at(i)`は頂点とDFS添字の相互変換、`reorder/restore`はDFS順／頂点順へのコピーです。`for_each_path(u,v,fn,edges)`は通行順にfn(l,r,reversed)を呼びます。区間は[l,r)、reversed=trueはr-1からlへ読み、別の木はfalseです。

LCA・距離・祖先・jump・親・深さ・部分木サイズの取得は、値を持つHLDからも同名で使えます。外部集計器を渡す`path_prod(u,v,range)`なども残し、DFS順・長さは利用側で合わせます。[全APIと戻り値](../Graph/Heavy_Light_Decomposition.cpp)は本体先頭にまとめています。

## 前提・所有権・計算量

入力は頂点0..N-1の対称な隣接リストで表す無向森です。指定根の木から構築し、残りは最小未訪問頂点を根にします。空の入力にはroot=0。経路集計・更新の両端は同じ木が前提で、検査時は別の木を例外にします。頂点範囲・自己辺・閉路・多重辺は探索中に検査し、対称性確認だけの全辺走査はしません。`SKIP_RUNTIME_CHECKS`で入力検査と検査専用状態を除きます。BITの整数和は型幅で周回します。

コピーは独立、move元は空です。元のlayout・値配列とも更新を共有しません。木の形や根を変えるときはbuildへ値も渡し、辺の値は新しい親子対応で配置し直します。build・コピー代入の失敗時は元を保持しますが、移動を指定した分解からの構築失敗では移動元が空になる場合があります。更新中の例外では巻き戻さず、Ordered=trueはclear/buildで再構築してください。order参照は再構築・代入・破棄で無効になります。get・集計・valuesも非constのHLDから呼びます（Lazyは照会時も内部を変更します）。

分解・並べ替えはO(N+M)／O(N)。値の構築は集計器のvector構築費用、vector構築のないACL FenwickはN回のaddでO(N log N)。通常のBIT／Segtreeでは点・部分木操作O(log N)、経路操作O(log²N)。valuesは集計器のvalues費用にO(N)の並べ直しを加え、valuesがなければN回点照会です。所有状態を固定1回確保します。LCA・距離・祖先・jumpはO(log N)、その他の情報取得はO(1)。経路分解はO(log N)、for_each_path／path_prodはHLD側の照会ごとのヒープ確保なし、pathはO(log N)領域を使います。演算・コピーはO(1)と仮定し、文字列などは長さに応じた費用が加わります。

[理論参考](https://info.atcoder.jp/entry/algorithm_lectures/heavy_light_decomposition)・[分解の参照試験](../Verify/current/tests/new_hld_reference_test.cpp)・[所有版の参照試験](../Verify/current/tests/hld_owned_test.cpp)
