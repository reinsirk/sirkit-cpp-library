# Affine main型幅候補：2案とも採用推奨

repoへは未適用。本体ソース・共通I/O・設定を固定し、mainの値型/演算とI/O型選択を含む全体効果を測定した。

| main | compiler | random比 | 退化比 | random RSS KiB baseline→candidate |
| --- | --- | ---: | ---: | ---: |
| lazy_segment_tree | gcc | 0.9098 | 0.8137 | 11756→6380 |
| lazy_segment_tree | clang | 0.9054 | 0.9125 | 11756→6380 |
| segment_tree_composite | gcc | 0.9222 | 0.9360 | 9696→6636 |
| segment_tree_composite | clang | 0.9565 | 0.9786 | 9708→6636 |

CPU12、GCC15.2/Clang21、CLI C++23 O2。Lazyは現行GCC O3,unroll-loops pragmaを保持し、Pointには追加pragmaなし。2warm+9交互、出力は全件bytes一致。

独立C++モデルは両compiler×checked/skipで各534475照合。実葉数Witnessで3引数mapping全135864回のlength一致を検査し、paddingに作用しないことを確認。n0/1、非2冪/2冪境界、mod-1、空/全域、非可換順序、all_prod/valuesも照合済み。main16構成はPython愚直69/129小入力と既存random/退化列の出力比較を通過。

候補driver・patch・全測定rawは同ディレクトリ。演算の範囲とpaddingの根拠はcorrectness_notes.md。
