from pathlib import Path
import subprocess,json,time
w=Path(__file__).resolve().parent
install=Path(subprocess.check_output(['/usr/bin/g++','-print-libgcc-file-name'],text=True).strip()).parent
records=[]
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir='+str(install)])]:
 for mode,flags in [('checked',[]),('skip',['-DSKIP_RUNTIME_CHECKS'])]:
  exe=w/('reference_'+cc+'_'+mode);cmd=['taskset','-c','12',*compiler,'-std=c++23','-O2','-Wall','-Wextra',*flags,str(w/'reference.cpp'),'-o',str(exe)]
  built=subprocess.run(cmd,capture_output=True,text=True);assert built.returncode==0,built.stderr
  start=time.perf_counter();result=subprocess.run(['taskset','-c','12',str(exe)],capture_output=True,text=True,timeout=30)
  row={'compiler':cc,'mode':mode,'command':cmd,'passed':result.returncode==0,'diagnostics':built.stderr,'stdout':result.stdout,'stderr':result.stderr,'runtime_seconds':time.perf_counter()-start}
  records.append(row);(w/'reference_results.json').write_text(json.dumps(records,indent=2)+'\n');print(cc,mode,result.stdout.strip(),flush=True);assert result.returncode==0,result.stderr
