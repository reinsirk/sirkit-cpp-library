from pathlib import Path
import json,re,sys,shutil,hashlib
W=Path(__file__).parent;R=Path('/home/reinsirk/Atcoder_Env');old=(R/'DataStructure/Wavelet_Matrix.cpp').read_text();s=old
s=s.replace('    std::vector<std::uint64_t> words_;\n    std::vector<std::uint32_t> prefix_;','    struct Block { std::uint64_t word; std::uint32_t prefix; };\n    std::vector<Block> blocks_;')
s=s.replace('explicit WaveletRankBits(std::size_t count) : words_(count / 64 + (count % 64 != 0)) {}','explicit WaveletRankBits(std::size_t count) : blocks_(count / 64 + (count % 64 != 0) + 1) {}')
s=s.replace('        prefix_.resize(words_.size() + 1);\n','')
s=s.replace('prefix_.back()','blocks_.back().prefix').replace('words_.size()','(blocks_.size() - 1)')
s=re.sub(r'words_\[([^\]]+)\]',r'blocks_[\1].word',s);s=re.sub(r'prefix_\[([^\]]+)\]',r'blocks_[\1].prefix',s)
s=s.replace('// endが64の倍数ならwords_[end/64]を読まない。end==nも含む。','// endが64の倍数ならwordを読まない。end==n用にも番兵を確保する。')
assert 'words_' not in s and 'prefix_' not in s
(W/'baseline.hpp').write_text(old);(W/'candidate.hpp').write_text(s)
for name in ['wavelet_matrix_reference_test','wavelet_matrix_all_widths_test','wavelet_matrix_second_reference_test','wavelet_matrix_allocation_test']:shutil.copyfile(R/'Verify/current/tests'/f'{name}.cpp',W/'frozen_tests'/f'{name}.cpp')
sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
(W/'sources').mkdir(exist_ok=True);meta=[]
for ident in ['wavelet_kth','wavelet_frequency']:
 e=next(e for e in pv.collect() if e['id']==ident);driver=(R/e['driver']).read_text();(W/'sources'/f'{ident}_driver.cpp').write_text(driver);hashes={}
 for label in ['baseline','candidate']:
  data=pv.render(e,source_overrides={'DataStructure/Wavelet_Matrix.cpp':(W/f'{label}.hpp').read_bytes()},driver_override=driver)[0];p=W/'sources'/f'{ident}_{label}.cpp';p.write_bytes(data);hashes[label]=hashlib.sha256(data).hexdigest()
 meta.append({'entry':e,'driver_sha256':hashlib.sha256(driver.encode()).hexdigest(),'sources_sha256':hashes})
 (W/'inputs'/ident).mkdir(parents=True,exist_ok=True)
 for p in (Path('/tmp/sirkit_remaining_20261113/data/inputs')/ident).glob('*'):shutil.copyfile(p,W/'inputs'/ident/p.name)
(W/'sources/metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
(W/'provenance.json').write_text(json.dumps({'baseline_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(s.encode()).hexdigest(),'changes':'Only WaveletRankBits storage changes to vector<Block{uint64 word,uint32 prefix}> including1sentinel. Original prefix32 preserved; ABI Block16B due8-byte alignment vs old12B/word plus4B sentinel. Both rank paths/build/AVX2 partition updated. No dispatch added.','source':'Fable batch_02 candidate[2]'},indent=2)+'\n')

def extra_inputs():
    import random
    rng=random.Random(822513)
    n=500000;q=150000
    values=[rng.randrange(1000000000) for _ in range(n)];values[:2]=[0,999999999]
    for ident in ['wavelet_kth','wavelet_frequency']:
        d=W/'inputs'/ident
        for kind in ['large_random','large_build_heavy']:
            count=q if kind=='large_random' else 1
            with (d/(kind+'.in')).open('w') as f:
                f.write(f'{n} {count}\n'+' '.join(map(str,values))+'\n')
                for i in range(count):
                    l=rng.randrange(n);r=rng.randrange(l+1,n+1)
                    x=(r-l)//2 if ident=='wavelet_kth' else values[rng.randrange(n)] if i%2 else rng.randrange(1000000000)
                    f.write(f'{l} {r} {x}\n')
extra_inputs()
