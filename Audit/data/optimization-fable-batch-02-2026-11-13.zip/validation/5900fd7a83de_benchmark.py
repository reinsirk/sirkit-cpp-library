from pathlib import Path
import json,subprocess,hashlib,random,time,statistics,shutil,gc
W=Path(__file__).parent;meta=json.loads((W/'sources/metadata.json').read_text());rows=[];(W/'bin').mkdir(exist_ok=True)
def save():(W/'benchmark_results.json').write_text(json.dumps({'cpu':11,'scope':'Only rank bit storage changed; frozen current drivers/commonI/O/actual generated per-ID pragma/SKIP/NDEBUG. CLI C++23 O2 all.2warm+9 shuffled alternating copies at same executable path.','results':rows},indent=2)+'\n')
def model(ident,inp):
 data=list(map(int,inp.read_text().split()));n,q=data[:2]
 if inp.stem in {'random','large_random'}:return None
 values=data[2:2+n];queries=data[2+n:];out=[]
 for i in range(q):
  l,r,x=queries[i*3:i*3+3]
  if inp.stem=='degenerate':
   assert values[0]==values[-1]==7
   out.append(7 if ident=='wavelet_kth' else (r-l if x==7 else 0))
  else:out.append(sorted(values[l:r])[x] if ident=='wavelet_kth' else values[l:r].count(x))
 return ''.join(str(x)+'\n' for x in out).encode()
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 bins={}
 for m in meta:
  ident=m['entry']['id'];bins[ident]={}
  for label in ['baseline','candidate']:
   src=W/'sources'/f'{ident}_{label}.cpp';exe=W/'bin'/f'{cc}_{ident}_{label}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',str(src),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr;bins[ident][label]=exe;rows.append({'kind':'build','compiler':cc,'id':ident,'label':label,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'passed':True});save()
 for m in meta:
  ident=m['entry']['id']
  for inp in sorted((W/'inputs'/ident).glob('*.in')):
   expected=model(ident,inp);independent=expected is not None;gc.collect()
   for label,exe in bins[ident].items():
    p=subprocess.run(['taskset','-c','11',str(exe)],input=inp.read_bytes(),capture_output=True);assert p.returncode==0,p.stderr
    if expected is None:expected=p.stdout
    assert p.stdout==expected,(cc,ident,inp,label,p.stderr)
   raw={k:[] for k in bins[ident]};rng=random.Random(283749)
   for rep in range(11):
    order=list(raw);rng.shuffle(order)
    for label in order:
     active=W/'bin/active';shutil.copyfile(bins[ident][label],active);active.chmod(0o755)
     with inp.open('rb') as fi,open('/dev/null','wb') as fo:
      start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','11',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
     assert p.returncode==0,p.stderr
     if rep>=2:raw[label].append(elapsed)
   med={k:statistics.median(v) for k,v in raw.items()};rows.append({'kind':'timing','compiler':cc,'id':ident,'case':inp.stem,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'baseline_candidate_output_equal':True,'independent_python_reference':independent,'output_sha256':hashlib.sha256(expected).hexdigest(),'raw_ns':raw,'median_ns':med,'ratio':med['candidate']/med['baseline']});save();print(cc,ident,inp.stem,{k:round(v/1e6,3) for k,v in med.items()},flush=True)
