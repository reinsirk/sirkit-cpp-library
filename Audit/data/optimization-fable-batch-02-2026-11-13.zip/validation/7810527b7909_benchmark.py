from pathlib import Path
import hashlib,json,statistics,subprocess,time,shutil
w=Path(__file__).resolve().parent;d=Path('/tmp/sirkit_remaining_20261113/data/inputs')
provenance=json.loads((w/'provenance.json').read_text())
records=[]
report={'scope':'whole_program_main_type_width_only_fixed_library_IO_flags','cpu':12,'flags':'CLI C++23 O2, actual generated per-ID GCC optimization pragma, SKIP_RUNTIME_CHECKS; body/main IO fixed except the individual tested main change.','protocol':'2warm+9 alternating measured pairs, reverse order each pair; common executable pathname. RSS separately by /usr/bin/time.','compilers':{cc:subprocess.check_output([path,'--version'],text=True).splitlines()[0]for cc,path in [('gcc','/usr/bin/g++'),('clang','/usr/bin/clang++')]},'provenance':provenance,'results':records}
def save():(w/'benchmark_results.json').write_text(json.dumps(report,indent=2)+'\n')
for identity in ['lazy_segment_tree','segment_tree_composite']:
 cases=[(kind,d/identity/(kind+'.in'))for kind in ['random','degenerate']]

 for cc in ['gcc','clang']:
  bins={v:w/f'{identity}_{v}_skip_{cc}'for v in ['baseline','candidate']}
  for case,path in cases:
   outputs={}
   for v,exe in bins.items():
    with path.open('rb')as fi:result=subprocess.run(['taskset','-c','12',str(exe)],stdin=fi,capture_output=True)
    assert result.returncode==0,result.stderr;outputs[v]=result.stdout
   assert outputs['baseline']==outputs['candidate']
   raw={v:[]for v in bins}
   for rep in range(11):
    for v in (list(bins)if rep%2==0 else list(reversed(bins))):
     active=w/'active';shutil.copyfile(bins[v],active);active.chmod(0o755)
     with path.open('rb')as fi,open('/dev/null','wb')as fo:
      start=time.perf_counter_ns();result=subprocess.run(['taskset','-c','12',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
     assert result.returncode==0,result.stderr
     if rep>=2:raw[v].append(elapsed)
   rss={}
   for v,exe in bins.items():
    measurements=[]
    for _ in range(3):
     with path.open('rb')as fi:
      result=subprocess.run(['/usr/bin/time','-f','%M','taskset','-c','12',str(exe)],stdin=fi,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
     assert result.returncode==0,result.stderr;measurements.append(int(result.stderr.strip()))
    rss[v]=measurements
   med={v:statistics.median(ns)for v,ns in raw.items()}
   row={'id':identity,'compiler':cc,'case':case,'input':str(path),'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(outputs['baseline']).hexdigest(),'output_byte_identical':True,'raw_ns':raw,'median_ns':med,'candidate_ratio':med['candidate']/med['baseline'],'paired_median_ratio':statistics.median(b/a for a,b in zip(raw['baseline'],raw['candidate'])),'candidate_pair_wins':sum(b<a for a,b in zip(raw['baseline'],raw['candidate'])),'peak_rss_kib':rss,'median_peak_rss_kib':{v:statistics.median(values)for v,values in rss.items()}}
   records.append(row);save();print(identity,cc,case,'ratio',round(row['candidate_ratio'],4),'wins',row['candidate_pair_wins'],'ms',{k:round(v/1e6,3)for k,v in med.items()},'RSS',row['median_peak_rss_kib'],flush=True)
