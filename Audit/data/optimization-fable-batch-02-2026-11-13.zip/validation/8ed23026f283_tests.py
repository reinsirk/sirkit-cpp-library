from pathlib import Path
import json,subprocess,hashlib
W=Path(__file__).parent;rows=[]
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for mode,flags in [('dispatch',[]),('software',['-DSIRKIT_WAVELET_FORCE_SOFTWARE']),('standard',['-DSIRKIT_DISABLE_SIMD']),('native',['-mpopcnt','-mavx2'])]:
  for skip in [False,True]:
   for src in sorted((W/'frozen_tests').glob('*.cpp')):
    exe=W/f'{cc}-{mode}-{skip}-{src.stem}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',*flags,*(['-DSKIP_RUNTIME_CHECKS'] if skip else []),'-DWAVELET_SOURCE="'+str(W/'candidate.hpp')+'"',str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;p=subprocess.run(['taskset','-c','11',str(exe)],capture_output=True,text=True);row={'compiler':cc,'mode':mode,'skip':skip,'test':src.stem,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((W/'candidate.hpp').read_bytes()).hexdigest(),'passed':p.returncode==0,'stdout':p.stdout,'stderr':p.stderr};rows.append(row);(W/'test_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,mode,skip,src.stem,p.stdout.strip()[:160],flush=True);assert p.returncode==0,p.stderr
