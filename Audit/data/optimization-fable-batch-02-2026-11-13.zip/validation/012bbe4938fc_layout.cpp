#include HEADER
#include <cstdio>
#include <cinttypes>
struct BlockLayout { std::uint64_t word; std::uint32_t prefix; };
int main() {
 std::printf("{\"rank_object_bytes\":%zu,\"word_bytes\":%zu,\"count_bytes\":%zu,\"block_bytes\":%zu,\"block_alignment\":%zu}\n",sizeof(reinsirk::detail::WaveletRankBits),sizeof(std::uint64_t),sizeof(std::uint32_t),sizeof(BlockLayout),alignof(BlockLayout));
}
