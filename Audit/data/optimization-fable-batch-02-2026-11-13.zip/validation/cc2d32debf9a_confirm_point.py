from pathlib import Path
import json,hashlib,sys,re,subprocess,statistics,time,shutil
w=Path(__file__).resolve().parent;r=Path('/home/reinsirk/Atcoder_Env');d=Path('/tmp/sirkit_remaining_20261113/data/inputs')
sys.path.insert(0,str(r/'Scripts'));import prepare_verify as pv
entries={e['id']:e for e in pv.collect()}
records=[];report={'compiler':subprocess.check_output(['/usr/bin/g++','--version'],text=True).splitlines()[0],'cpu':12,'protocol':'CLI C++23 O2 identical in all. Actual generated GCC optimization pragma only. Confirmation, reversed rotation: 2warm+9 rotating order triplets per input, same executable pathname.','scope':'Current adopted main/body/IO frozen, same SKIP_RUNTIME_CHECKS and NDEBUG. No repository config writes.','programs':{},'results':records}
def save():(w/'point_confirmation.json').write_text(json.dumps(report,indent=2)+'\n')
pattern=rb'#if defined\(__GNUC__\) && !defined\(__clang__\)\n#pragma GCC optimize\([^\n]*\)\n#endif\n'
for identity in ['segment_tree_composite']:
 entry=entries[identity]
 actual=(r/entry['driver']).read_bytes();assert actual==(w.parent/(identity+'_candidate_main.cpp')).read_bytes()
 sources={}
 for name,option in [('none',None),('O3','O3'),('O3_unroll','O3,unroll-loops')]:
  e=dict(entry);e.pop('gcc_optimization',None)
  if option:e['gcc_optimization']=option
  sources[name]=pv.render(e,skip_runtime_checks=True)[0]
 strip=lambda source:re.sub(pattern,b'',source)
 assert len({hashlib.sha256(strip(s)).hexdigest()for s in sources.values()})==1
 assert len({b'#define NDEBUG' in s for s in sources.values()})==1
 report['programs'][identity]={'current_setting':entry.get('gcc_optimization'),'driver_sha256':hashlib.sha256(actual).hexdigest(),'library_sha256':{name:hashlib.sha256((r/name).read_bytes()).hexdigest()for name in entry['libraries']},'shared_io_sha256':hashlib.sha256((r/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest(),'nonpragma_bytes_identical':True,'source_sha256':{name:hashlib.sha256(s).hexdigest()for name,s in sources.items()}}
 bins={}
 bins={name:w/(identity+'_'+name)for name in sources}
 for case in ['random','degenerate']:
  inp=d/identity/(case+'.in');outputs={}
  for name,exe in bins.items():
   with inp.open('rb')as fi:p=subprocess.run(['taskset','-c','12',str(exe)],stdin=fi,capture_output=True)
   assert p.returncode==0,p.stderr;outputs[name]=p.stdout
  assert len(set(outputs.values()))==1
  raw={name:[]for name in bins};names=list(bins)
  for rep in range(11):
   offset=(2-rep)%3;order=names[offset:]+names[:offset]
   if rep%2==0:order.reverse()
   for name in order:
    active=w/'active';shutil.copyfile(bins[name],active);active.chmod(0o755)
    with inp.open('rb')as fi,open('/dev/null','wb')as fo:
     start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','12',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
    assert p.returncode==0,p.stderr
    if rep>=2:raw[name].append(elapsed)
  med={name:statistics.median(values)for name,values in raw.items()};current='O3_unroll'if identity=='lazy_segment_tree'else'none'
  row={'kind':'timing','id':identity,'case':case,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(outputs['none']).hexdigest(),'output_byte_identical':True,'raw_ns':raw,'median_ns':med,'ratio_to_current':{name:value/med[current]for name,value in med.items()}}
  records.append(row);save();print(identity,case,'ms',{k:round(v/1e6,3)for k,v in med.items()},'ratios',{k:round(v,4)for k,v in row['ratio_to_current'].items()},flush=True)
