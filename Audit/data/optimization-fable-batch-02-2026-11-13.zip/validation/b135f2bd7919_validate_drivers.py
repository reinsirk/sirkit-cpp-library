from pathlib import Path
import itertools,json,random,subprocess,time,hashlib
w=Path(__file__).resolve().parent;d=Path('/tmp/sirkit_remaining_20261113/data/inputs');mod=998244353
rng=random.Random(0xAFF1E32)
install=Path(subprocess.check_output(['/usr/bin/g++','-print-libgcc-file-name'],text=True).strip()).parent
identities=['lazy_segment_tree','segment_tree_composite'];cases={identity:[]for identity in identities}
def lazy_case(a,ops):return (f'{len(a)} {len(ops)}\n'+' '.join(map(str,a))+'\n'+'\n'.join(' '.join(map(str,op))for op in ops)+'\n').encode()
def point_case(a,ops):return (f'{len(a)} {len(ops)}\n'+'\n'.join(' '.join(map(str,f))for f in a)+'\n'+'\n'.join(' '.join(map(str,op))for op in ops)+'\n').encode()
for n in range(1,5):
 for a in itertools.product((0,mod-1),repeat=n):
  ops=[]
  for f in [(2,3),(5,7),(mod-1,mod-1),(0,mod-1),(1,0)]:
   ops.append((0,0,n,*f));ops.append((0,n,n,*f))
   ops.extend((1,l,r)for l in range(n+1)for r in range(l,n+1))
  cases['lazy_segment_tree'].append(lazy_case(a,ops))
for n in (1,2):
 for a in itertools.product(list(itertools.product((0,1,mod-1),repeat=2)),repeat=n):
  ops=[]
  for f in [(2,3),(5,7),(mod-1,mod-1),(0,mod-1)]:
   ops.extend((0,p,*f)for p in range(n));ops.extend((1,l,r,mod-1)for l in range(n+1)for r in range(l,n+1))
  cases['segment_tree_composite'].append(point_case(a,ops))
for n in [1,2,3,5,7,8,9,15,16,17,31,32,33,63,65,127,129,255,257]:
 for repetition in range(2):
  a=[rng.randrange(mod)for _ in range(n)];functions=[(rng.randrange(mod),rng.randrange(mod))for _ in range(n)];lazy=[];point=[]
  for step in range(120):
   l,r=sorted([rng.randrange(n+1),rng.randrange(n+1)])
   if step%9==0:l,r=0,n
   if step%9==1:r=l
   if step%3:
    lazy.append((1,l,r));point.append((1,l,r,mod-1 if step%5==0 else rng.randrange(mod)))
   else:
    f=(mod-1,mod-1)if step%6==0 else(rng.randrange(mod),rng.randrange(mod))
    lazy.append((0,l,r,*f));point.append((0,rng.randrange(n),*f))
  cases['lazy_segment_tree'].append(lazy_case(a,lazy));cases['segment_tree_composite'].append(point_case(functions,point))
cases['lazy_segment_tree'].append(lazy_case([],[(0,0,0,mod-1,mod-1),(1,0,0)]))
cases['segment_tree_composite'].append(point_case([],[(1,0,0,mod-1)]))
(w/'small_cases.json').write_text(json.dumps({k:[x.decode()for x in v]for k,v in cases.items()},indent=2)+'\n')
def model(identity,data):
 it=iter(map(int,data.split()));n,q=next(it),next(it);out=[]
 if identity=='lazy_segment_tree':
  a=[next(it)for _ in range(n)]
  for _ in range(q):
   typ,l,r=next(it),next(it),next(it)
   if typ==0:
    b,c=next(it),next(it);a[l:r]=[(b*x+c)%mod for x in a[l:r]]
   else:out.append(sum(a[l:r])%mod)
 else:
  a=[(next(it),next(it))for _ in range(n)]
  for _ in range(q):
   typ=next(it)
   if typ==0:
    p,b,c=next(it),next(it),next(it);a[p]=(b,c)
   else:
    l,r,x=next(it),next(it),next(it)
    for b,c in a[l:r]:x=(b*x+c)%mod
    out.append(x)
 return ''.join(str(x)+'\n'for x in out).encode()
expected={identity:[model(identity,x)for x in inputs]for identity,inputs in cases.items()}
results=[];large_outputs={}
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir='+str(install)])]:
 for mode in ['checked','skip']:
  for identity in identities:
   for variant in ['baseline','candidate']:
    src=w/f'{identity}_{variant}_{mode}.cpp';exe=w/f'{identity}_{variant}_{mode}_{cc}'
    cmd=['taskset','-c','12',*compiler,'-std=c++23','-O2','-Wall','-Wextra',str(src),'-o',str(exe)]
    built=subprocess.run(cmd,capture_output=True,text=True);assert built.returncode==0,built.stderr
    for index,data in enumerate(cases[identity]):
     result=subprocess.run(['taskset','-c','12',str(exe)],input=data,capture_output=True,timeout=10)
     assert result.returncode==0 and result.stdout==expected[identity][index],(identity,cc,mode,variant,index,result.stdout,result.stderr)
    hashes={}
    for case in ['small','random','degenerate']:
     inp=d/identity/(case+'.in')
     with inp.open('rb')as fi:result=subprocess.run(['taskset','-c','12',str(exe)],stdin=fi,capture_output=True,timeout=30)
     assert result.returncode==0,result.stderr
     if case=='small':assert result.stdout==model(identity,inp.read_bytes())
     key=(identity,case)
     if key not in large_outputs:large_outputs[key]=result.stdout
     assert result.stdout==large_outputs[key],(identity,cc,mode,variant,case)
     hashes[case]={'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(result.stdout).hexdigest(),'independent_python_model':case=='small'}
    results.append({'id':identity,'compiler':cc,'mode':mode,'variant':variant,'command':cmd,'small_independent_cases':len(cases[identity]),'existing_workloads':hashes,'passed':True,'diagnostics':built.stderr})
    (w/'driver_validation_results.json').write_text(json.dumps(results,indent=2)+'\n');print(identity,cc,mode,variant,'PASS',len(cases[identity]),flush=True)
