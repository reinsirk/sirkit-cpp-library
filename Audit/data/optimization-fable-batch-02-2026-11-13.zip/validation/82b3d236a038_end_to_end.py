from pathlib import Path
import json,sys,subprocess,time,statistics,hashlib,shutil
r=Path('/home/reinsirk/Atcoder_Env');w=Path(__file__).resolve().parent/'end_to_end';w.mkdir(exist_ok=True)
a=w.parents[2]/'affine_main_candidates';d=Path('/tmp/sirkit_remaining_20261113/data/inputs')
sys.path.insert(0,str(r/'Scripts'));import prepare_verify as pv
entries={e['id']:e for e in pv.collect()};records=[]
report={'compiler':subprocess.check_output(['/usr/bin/g++','--version'],text=True).splitlines()[0],'cpu':12,'scope':'GCC direct full-program measurement: frozen pre-change 64bit main + no optimization pragma vs adopted uint32 main + actual O3,unroll-loops pragma. Same current unchanged library and shared IO. This is a controlled old-width/no-pragma baseline, not a claim about an old online submission compiler setting.','protocol':'CLI C++23 O2 for both; SKIP_RUNTIME_CHECKS; 2warm+7 strictly alternating measured pairs; same executable pathname; no sum/product of separately measured ratios.','results':records}
def sha(data):return hashlib.sha256(data).hexdigest()
def save():(w/'results.json').write_text(json.dumps(report,indent=2)+'\n')
for identity in ['lazy_segment_tree','segment_tree_composite']:
 entry=entries[identity];body={name:(r/name).read_bytes()for name in entry['libraries']};old_driver=(a/(identity+'_baseline_main.cpp')).read_text();old_entry=dict(entry);old_entry.pop('gcc_optimization',None)
 baseline,_=pv.render(old_entry,source_overrides=body,driver_override=old_driver,skip_runtime_checks=True)
 final,_=pv.render(entry,source_overrides=body,skip_runtime_checks=True)
 assert entry.get('gcc_optimization')=='O3,unroll-loops'
 assert final==(r/'Verify/current/submissions'/(identity+'.cpp')).read_bytes()
 bins={}
 for name,data in [('64bit_no_pragma',baseline),('final_32bit_unroll',final)]:
  src=w/(identity+'_'+name+'.cpp');src.write_bytes(data);exe=w/(identity+'_'+name);cmd=['taskset','-c','12','/usr/bin/g++','-std=c++23','-O2',str(src),'-o',str(exe)]
  built=subprocess.run(cmd,capture_output=True,text=True);assert built.returncode==0,built.stderr;bins[name]=exe
  records.append({'kind':'build','id':identity,'variant':name,'source_sha256':sha(data),'command':cmd,'diagnostics':built.stderr,'passed':True});save()
 for case in ['random','degenerate']:
  inp=d/identity/(case+'.in');outputs={}
  for name,exe in bins.items():
   with inp.open('rb')as fi:p=subprocess.run(['taskset','-c','12',str(exe)],stdin=fi,capture_output=True)
   assert p.returncode==0,p.stderr;outputs[name]=p.stdout
  assert len(set(outputs.values()))==1
  raw={name:[]for name in bins}
  for rep in range(9):
   for name in (list(bins)if rep%2==0 else list(reversed(bins))):
    active=w/'active';shutil.copyfile(bins[name],active);active.chmod(0o755)
    with inp.open('rb')as fi,open('/dev/null','wb')as fo:
     start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','12',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
    assert p.returncode==0,p.stderr
    if rep>=2:raw[name].append(elapsed)
  med={name:statistics.median(values)for name,values in raw.items()}
  row={'kind':'timing','id':identity,'case':case,'input_sha256':sha(inp.read_bytes()),'output_sha256':sha(outputs['64bit_no_pragma']),'output_byte_identical':True,'raw_ns':raw,'median_ns':med,'final_over_old_width_no_pragma':med['final_32bit_unroll']/med['64bit_no_pragma']}
  records.append(row);save();print(identity,case,'ms',{k:round(v/1e6,3)for k,v in med.items()},'direct_ratio',round(row['final_over_old_width_no_pragma'],4),flush=True)
