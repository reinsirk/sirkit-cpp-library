# Wavelet rank Block同居化：不採用

既存prefixはuint32。word8Bとprefix4Bを同居しても、8B整列でBlockは16Bになる。末尾番兵込みのpayloadは12M+4→16(M+1)B/段（M=ceil(n/64)）となり、vector管理領域が48→24Bへ減っても大規模では約33%増える。格納量の漸近評価は変わらない。

64構成の独立参照・境界・所有・確保失敗検査は全成功した。しかしGCCでrandom kth +5.9%、frequency +5.8%、50万要素/B30のfrequency +7.2%。Clangもrandom kth +3.1%、frequency +4.0%、大frequency +5.7%。q1に一貫した利益もないため、現行の別配列を維持する。

[全測定・ABIサイズ・再現資料](final_report.json)。本体とmain/IOは区別し、repoは変更していない。
