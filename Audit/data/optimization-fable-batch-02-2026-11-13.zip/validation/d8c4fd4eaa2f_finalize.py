from pathlib import Path
import json,hashlib
w=Path(__file__).resolve().parent;r=Path('/home/reinsirk/Atcoder_Env')
p=json.loads((w/'provenance.json').read_text());refs=json.loads((w/'reference_results.json').read_text());drivers=json.loads((w/'driver_validation_results.json').read_text());bench=json.loads((w/'benchmark_results.json').read_text())
report={
 'scope':'whole_program_main_type_width_and_arithmetic_selection','recommendation':'accept_both','repository_files_modified':False,'fable_invoked':False,'cpu':12,
 'library_bodies':{name:{'sha256':digest,'still_current':hashlib.sha256((r/name).read_bytes()).hexdigest()==digest}for name,digest in p['bodies'].items()},
 'common_io':{'sha256':p['io_sha256'],'still_current':hashlib.sha256((r/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest()==p['io_sha256']},
 'compilers':bench['compilers'],'flags':'CLI C++23 O2. lazy retains actual GCC O3,unroll-loops generated pragma; point composite has no extra pragma. Checked/skip generation preserved; benchmark uses skip source for both variants.',
 'scope_note':'本体ソースと共通I/Oソースは同じ。mainでのS/Fの型、演算、I/Oテンプレートの型選択による全体効果であり、本体のみの改善とは扱わない。',
 'decisions':[],
 'independent_validation':{'cpp_reference_configurations':4,'all_cpp_passed':all(x['passed']for x in refs),'checks_per_configuration':534475,'padding_witness_mapping_calls_per_configuration':135864,'cases':'n=0/1と非2冪/2冪境界26サイズ、mod-1、非可換合成、空区間/全域、点作用/代入、values/all_prod、逐次配列と全小区間・サンプル区間照合。Pointは非可換順・空区間も逐次適用で照合。','dispatch':'2引数mapping不可・3引数可をstatic_assert。S=4/F=8/Point=8 bytesをstatic_assert。','driver_configurations':len(drivers),'all_driver_passed':all(x['passed']for x in drivers),'driver_python_models':{'lazy_segment_tree':69,'segment_tree_composite':129},'driver_workloads':'GCC15.2/Clang21×checked/skip×baseline/candidateの16構成。smallはPython任意精度の愚直配列モデル。large random/degenerateはbaselineと出力bytes比較（大規模をPython愚直照合したとは扱わない）。','cpp_results':str(w/'reference_results.json'),'driver_results':str(w/'driver_validation_results.json')},
 'correctness_notes':str(w/'correctness_notes.md'),
 'measurement_protocol':bench['protocol'],
 'artifacts':{name:str(w/name)for name in ('prepare.py','reference.cpp','test_reference.py','validate_drivers.py','benchmark.py','benchmark_results.json','provenance.json','small_cases.json')},
}
for identity in ['lazy_segment_tree','segment_tree_composite']:
 rows=[row for row in bench['results']if row['id']==identity]
 assert all(row['candidate_ratio']<1 for row in rows)
 changes='Sをuint32、Fをuint32係数2つへ縮小。3引数mappingで長さを受け、opは条件減算へ置換。積の前にuint64へ拡張する。'if identity=='lazy_segment_tree'else'係数2つをuint32へ縮小。係数合成と評価の積の前にuint64へ拡張する。'
 report['decisions'].append({'id':identity,'decision':'accept','applied_to_repository':False,'changes':changes,'candidate_driver':str(w/(identity+'_candidate_main.cpp')),'patch':str(w/(identity+'.patch')),'reason':'GCCとClangのrandom/degenerateがすべて短縮し、ピークRSSも低下。独立モデルとchecked/skipの照合はすべてPASS。','measurements':rows})
(w/'final_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
lines=['# Affine main型幅候補：2案とも採用推奨','','repoへは未適用。本体ソース・共通I/O・設定を固定し、mainの値型/演算とI/O型選択を含む全体効果を測定した。','', '| main | compiler | random比 | 退化比 | random RSS KiB baseline→candidate |','| --- | --- | ---: | ---: | ---: |']
for identity in ['lazy_segment_tree','segment_tree_composite']:
 for cc in ('gcc','clang'):
  a=next(row for row in bench['results']if row['id']==identity and row['compiler']==cc and row['case']=='random');b=next(row for row in bench['results']if row['id']==identity and row['compiler']==cc and row['case']=='degenerate')
  lines.append(f"| {identity} | {cc} | {a['candidate_ratio']:.4f} | {b['candidate_ratio']:.4f} | {a['median_peak_rss_kib']['baseline']}→{a['median_peak_rss_kib']['candidate']} |")
lines += ['', 'CPU12、GCC15.2/Clang21、CLI C++23 O2。Lazyは現行GCC O3,unroll-loops pragmaを保持し、Pointには追加pragmaなし。2warm+9交互、出力は全件bytes一致。','', '独立C++モデルは両compiler×checked/skipで各534475照合。実葉数Witnessで3引数mapping全135864回のlength一致を検査し、paddingに作用しないことを確認。n0/1、非2冪/2冪境界、mod-1、空/全域、非可換順序、all_prod/valuesも照合済み。main16構成はPython愚直69/129小入力と既存random/退化列の出力比較を通過。','', '候補driver・patch・全測定rawは同ディレクトリ。演算の範囲とpaddingの根拠はcorrectness_notes.md。','']
(w/'summary.md').write_text('\n'.join(lines));print(json.dumps({'recommendation':'accept_both','applied':False,'validation_configurations':len(refs)+len(drivers),'report':str(w/'final_report.json')},indent=2))
