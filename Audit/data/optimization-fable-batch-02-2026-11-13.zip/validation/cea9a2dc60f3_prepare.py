from pathlib import Path
import json,sys,hashlib,difflib
r=Path('/home/reinsirk/Atcoder_Env');w=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'Scripts'));import prepare_verify as pv
entries={e['id']:e for e in pv.collect()}
report={'scope':'whole_program_driver_types_only','entries':{},'bodies':{},'sources':{},'io_sha256':hashlib.sha256((r/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest()}
lazy='''// SPDX-License-Identifier: CC0-1.0
#include "Verify/current/common/fast_io.hpp"
#include <cstddef>
#include <cstdint>
#include <vector>
using RangeAffineValue = std::uint32_t;
struct RangeAffineUpdate { std::uint32_t a = 1, b = 0; };
RangeAffineValue range_affine_op(RangeAffineValue a, RangeAffineValue b) {
    const std::uint32_t sum = a + b;
    return sum >= 998244353u ? sum - 998244353u : sum;
}
RangeAffineValue range_affine_identity() { return 0; }
RangeAffineValue range_affine_mapping(RangeAffineUpdate f, RangeAffineValue value, std::size_t length) {
    return static_cast<std::uint32_t>((std::uint64_t{f.a} * value + std::uint64_t{f.b} * length) % 998244353);
}
RangeAffineUpdate range_affine_composition(RangeAffineUpdate newer, RangeAffineUpdate older) {
    return {static_cast<std::uint32_t>(std::uint64_t{newer.a} * older.a % 998244353),
            static_cast<std::uint32_t>((std::uint64_t{newer.a} * older.b + newer.b) % 998244353)};
}
RangeAffineUpdate range_affine_id() { return {}; }
int main() {
    int n{}, q{}; verify_in >> n >> q;
    std::vector<RangeAffineValue> a(n);
    for (auto& x : a) verify_in >> x;
    lazy_segtree<RangeAffineValue, range_affine_op, range_affine_identity, RangeAffineUpdate,
                 range_affine_mapping, range_affine_composition, range_affine_id> tree(a);
    while (q--) {
        int type{}, l{}, r{}; verify_in >> type >> l >> r;
        if (type == 0) {
            RangeAffineUpdate f; verify_in >> f.a >> f.b;
            tree.apply(l, r, f);
        } else verify_out << tree.prod(l, r) << '\\n';
    }
}
'''
for identity in ['lazy_segment_tree','segment_tree_composite']:
 entry=entries[identity];base=(r/entry['driver']).read_text()
 if identity=='lazy_segment_tree':candidate=lazy
 else:
  candidate=base.replace('struct PointAffineFunction { std::uint64_t a = 1, b = 0; };','struct PointAffineFunction { std::uint32_t a = 1, b = 0; };')
  candidate=candidate.replace('return {left.a * right.a % 998244353, (left.b * right.a + right.b) % 998244353};','return {static_cast<std::uint32_t>(std::uint64_t{left.a} * right.a % 998244353),\n                static_cast<std::uint32_t>((std::uint64_t{left.b} * right.a + right.b) % 998244353)};')
  candidate=candidate.replace('(f.a * x + f.b)', '(std::uint64_t{f.a} * x + f.b)')
 (w/(identity+'_baseline_main.cpp')).write_text(base);(w/(identity+'_candidate_main.cpp')).write_text(candidate)
 (w/(identity+'_functions.inc')).write_text(candidate[:candidate.index('int main()')].replace('#include "Verify/current/common/fast_io.hpp"',''))
 (w/(identity+'.patch')).write_text(''.join(difflib.unified_diff(base.splitlines(True),candidate.splitlines(True),fromfile=entry['driver'],tofile=entry['driver'])))
 bodies={name:(r/name).read_bytes()for name in entry['libraries']}
 for name,body in bodies.items():(w/Path(name).name).write_bytes(body);report['bodies'][name]=hashlib.sha256(body).hexdigest()
 report['entries'][identity]=entry
 for label,driver in [('baseline',base),('candidate',candidate)]:
  for mode,skip in [('checked',False),('skip',True)]:
   source,hashes=pv.render(entry,skip_runtime_checks=skip,source_overrides=bodies,driver_override=driver)
   name=identity+'_'+label+'_'+mode+'.cpp';(w/name).write_bytes(source);report['sources'][name]=hashlib.sha256(source).hexdigest()
(w/'provenance.json').write_text(json.dumps(report,indent=2)+'\n')
