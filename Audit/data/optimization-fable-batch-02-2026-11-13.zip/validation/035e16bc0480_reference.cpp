// SPDX-License-Identifier: CC0-1.0
#include "Lazy_Segment_Tree.cpp"
#include "Segment_Tree.cpp"
#include "lazy_segment_tree_functions.inc"
#include "segment_tree_composite_functions.inc"
#include <cstdio>
#include <cstdlib>
#include <random>
#include <type_traits>
#include <numeric>
constexpr std::uint64_t mod = 998244353;
static std::uint64_t checks = 0, mapped = 0;
void check(bool ok) { ++checks; if (!ok) { std::fprintf(stderr,"failed checks=%llu mapped=%llu\n",static_cast<unsigned long long>(checks),static_cast<unsigned long long>(mapped));std::abort(); } }
static_assert(sizeof(RangeAffineValue)==4 && sizeof(RangeAffineUpdate)==8 && sizeof(PointAffineFunction)==8);
static_assert(!std::is_invocable_r_v<RangeAffineValue,decltype(range_affine_mapping),const RangeAffineUpdate&,const RangeAffineValue&>);
static_assert(std::is_invocable_r_v<RangeAffineValue,decltype(range_affine_mapping),const RangeAffineUpdate&,const RangeAffineValue&,std::size_t>);
using Lazy = lazy_segtree<RangeAffineValue,range_affine_op,range_affine_identity,RangeAffineUpdate,range_affine_mapping,range_affine_composition,range_affine_id>;
// A separate segment-length witness detects even a mapping call on padded leaves/nodes.
struct Witness { std::uint32_t sum=0;std::size_t real=0; };
Witness witness_op(Witness a,Witness b){return {range_affine_op(a.sum,b.sum),a.real+b.real};}
Witness witness_e(){return {};}
Witness witness_map(RangeAffineUpdate f,Witness s,std::size_t length){++mapped;check(s.real==length);return {range_affine_mapping(f,s.sum,length),s.real};}
using Tracked = lazy_segtree<Witness,witness_op,witness_e,RangeAffineUpdate,witness_map,range_affine_composition,range_affine_id>;
using Point = segtree<PointAffineFunction,PointAffineComposition{},point_affine_identity>;
int main(){
 std::mt19937_64 rng(0xAFF1E20261113ULL);
 for(int n:{0,1,2,3,4,5,7,8,9,15,16,17,31,32,33,63,64,65,127,128,129,255,256,257,511,513}){
  std::vector<std::uint64_t> model(n);std::vector<RangeAffineValue> values(n);std::vector<Witness>witness(n);
  for(int i=0;i<n;++i){model[i]=i%3==0?mod-1:i%3==1?0:rng()%mod;values[i]=static_cast<std::uint32_t>(model[i]);witness[i]={values[i],1};}
  Lazy lazy(values);Tracked tracked(witness);
  for(int step=0;step<96;++step){
   int l=static_cast<int>(rng()%(n+1)),r=static_cast<int>(rng()%(n+1));if(l>r)std::swap(l,r);
   if(step%8==0){l=0;r=n;}if(step%8==1)r=l;
   RangeAffineUpdate f{static_cast<std::uint32_t>(rng()%mod),static_cast<std::uint32_t>(rng()%mod)};
   if(step%6==0)f={mod-1,mod-1};if(step%6==1)f={2,3};if(step%6==2)f={5,7};if(step%6==3)f={0,mod-1};
   lazy.apply(l,r,f);tracked.apply(l,r,f);for(int i=l;i<r;++i)model[i]=(std::uint64_t{f.a}*model[i]+f.b)%mod;
   if(n && step%5==0){int at=static_cast<int>(rng()%n);lazy.apply(at,f);tracked.apply(at,f);model[at]=(std::uint64_t{f.a}*model[at]+f.b)%mod;}
   if(n && step%7==0){int at=static_cast<int>(rng()%n);auto v=static_cast<std::uint32_t>(rng()%mod);lazy.set(at,v);tracked.set(at,{v,1});model[at]=v;}
   std::vector<std::uint64_t> prefix(n+1);for(int i=0;i<n;++i)prefix[i+1]=(prefix[i]+model[i])%mod;
   check(lazy.all_prod()==prefix[n]);check(tracked.all_prod().sum==prefix[n]);
   auto query=[&](int a,int b){auto expected=(prefix[b]+mod-prefix[a])%mod;check(lazy.prod(a,b)==expected);check(tracked.prod(a,b).sum==expected);};
   if(n<=17){for(int a=0;a<=n;++a)for(int b=a;b<=n;++b)query(a,b);}
   else {query(0,n);query(0,0);query(n,n);for(int i=0;i<48;++i){int a=rng()%(n+1),b=rng()%(n+1);if(a>b)std::swap(a,b);query(a,b);}}
   if(step%12==0){auto got=lazy.values();auto seen=tracked.values();for(int i=0;i<n;++i){check(got[i]==model[i]);check(seen[i].sum==model[i]&&seen[i].real==1);}}
  }
 }
 check(mapped>0);
 for(int n:{0,1,2,3,5,7,8,9,15,16,17,31,33,63,65,129,257}){
  std::vector<PointAffineFunction> model(n);for(int i=0;i<n;++i)model[i]={static_cast<std::uint32_t>(i%3==0?mod-1:2+i),static_cast<std::uint32_t>(i%3==1?mod-1:3+i)};
  Point tree(model);
  for(int step=0;step<96;++step){
   if(n){int p=rng()%n;PointAffineFunction f{static_cast<std::uint32_t>(rng()%mod),static_cast<std::uint32_t>(rng()%mod)};if(step%3==0)f={mod-1,mod-1};tree.set(p,f);model[p]=f;}
   auto query=[&](int l,int r){std::uint64_t x=step%3==0?mod-1:rng()%mod,expected=x;for(int i=l;i<r;++i)expected=(std::uint64_t{model[i].a}*expected+model[i].b)%mod;auto f=tree.prod(l,r);check((std::uint64_t{f.a}*x+f.b)%mod==expected);};
   if(n<=17){for(int a=0;a<=n;++a)for(int b=a;b<=n;++b)query(a,b);}
   else {query(0,n);query(0,0);query(n,n);for(int i=0;i<48;++i){int a=rng()%(n+1),b=rng()%(n+1);if(a>b)std::swap(a,b);query(a,b);}}
  }
 }
 auto f=PointAffineComposition{}({2,3},{5,7});check(f.a==10 && f.b==22);
 auto c=range_affine_composition({5,7},{2,3});check(c.a==10 && c.b==22);
 std::printf("PASS affine models checks=%llu padding_mapping_calls=%llu\n",static_cast<unsigned long long>(checks),static_cast<unsigned long long>(mapped));
}
