# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import bench,json,fcntl
D=Path('/tmp/sirkit_lowlink_416583');rows=[]
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for flag in ['native','default']:
   for label in ['base','final']:
    for f in bench.fixtures:
     r=bench.run_whole(cc,label,f,flag);rows.append(dict(compiler=cc,flag=flag,label=label,fixture=f['id'],canonical_sha256=r['canonical_sha256'],output_sha256=r['output_sha256'],passed=True))
   print(cc,flag,'52 independent outputsPASS',flush=True)
(D/'final_fixture_validation.json').write_text(json.dumps(dict(all_passed=True,count=len(rows),rows=rows),indent=2)+'\n')
