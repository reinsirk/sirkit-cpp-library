// SPDX-License-Identifier: CC0-1.0
// 参考（low-linkの分類）: https://nyaannyaan.github.io/library/graph/lowlink.hpp
// ドキュメント: https://github.com/reinsirk/sirkit-cpp-library/blob/main/Document/low_link.md
//
// API一覧
// UndirectedLowLink(n=0): n頂点、空の無向多重グラフ。頂点番号[0,n)。準備O(1)。
// add_edge(u,v): 無向辺を追加しsize_tの辺番号を返す。自己辺可。償却O(1)。reserve_edges(m): m辺予約。
// build(collect_blocks=false): 連結成分数を返す。反復DFSでO(n+m)時間・領域。追加後は再build。
// collect_blocks=trueなら点二重連結ブロックも求める。既定ではその領域確保・辺スタック処理を省く。
// size()/edge_count()/edge(id): 頂点数/辺数/端点pair。O(1)。component_count(): 連結成分数。build後O(1)。
// bridges()/articulation_points(): 橋の辺番号/関節点番号の昇順配列へのconst参照。build後O(1)。
// is_bridge(id)/is_articulation(v): 橋/関節点か。build後O(1)。平行辺は異なるIDとして扱う。
// two_edge_component(v)/two_edge_components(): 橋を除いた成分番号/頂点群コピー。O(1)/O(n+m)。
// bridge_forest(): 2辺連結成分を頂点とした橋の森Graph。O(n+m)時間・領域。
// biconnected_edge_components(): 点二重連結ブロックの辺ID群へのconst参照。build(true)後O(1)。
// 自己辺は1辺だけの独立ブロックとする。孤立頂点は辺ブロックに含めない。
// biconnected_vertex_components(include_isolated=true): build(true)後、辺ブロックの頂点群と孤立点のコピー。O(n+m)。
// reset(n=0)/swap(other): 空のn頂点へ戻す/O(1)交換。コピーは独立所有、ムーブ元は空の未分解状態。
// 入力検査と結果有効性だけの状態はSKIP_RUNTIME_CHECKSで除く。結果参照は再build等で無効になる。

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <utility>
#include <vector>

#ifndef SIRKIT_UNWEIGHTED_GRAPH_DEFINED
#define SIRKIT_UNWEIGHTED_GRAPH_DEFINED
using Graph = std::vector<std::vector<int>>;
#endif

#ifndef SIRKIT_UNDIRECTED_LOW_LINK_DEFINED
#define SIRKIT_UNDIRECTED_LOW_LINK_DEFINED
class UndirectedLowLink {
    int n_ = 0, components_ = 0;
    std::vector<std::pair<int, int>> edges_;
    std::vector<std::size_t> bridges_;
    std::vector<int> articulation_, two_edge_id_;
    std::vector<unsigned char> bridge_flag_, cut_flag_;
    std::vector<std::vector<std::size_t>> blocks_;
#ifndef SKIP_RUNTIME_CHECKS
    bool built_ = false, blocks_built_ = false;
    void vertex(int v) const { if (v < 0 || v >= n_) throw std::out_of_range("LowLink: vertex out of range"); }
    void edge_id(std::size_t e) const { if (e >= edges_.size()) throw std::out_of_range("LowLink: edge out of range"); }
    void require_build() const { if (!built_) throw std::logic_error("LowLink: call build first"); }
#endif
public:
    explicit UndirectedLowLink(int n = 0) : n_(n) {
        if (n < 0) throw std::length_error("LowLink: negative vertex count");
    }
    UndirectedLowLink(const UndirectedLowLink&) = default;
    UndirectedLowLink(UndirectedLowLink&& other) noexcept { swap(other); }
    UndirectedLowLink& operator=(UndirectedLowLink other) noexcept { swap(other); return *this; }
    void swap(UndirectedLowLink& other) noexcept {
        std::swap(n_, other.n_); std::swap(components_, other.components_); edges_.swap(other.edges_);
        bridges_.swap(other.bridges_); articulation_.swap(other.articulation_); two_edge_id_.swap(other.two_edge_id_);
        bridge_flag_.swap(other.bridge_flag_); cut_flag_.swap(other.cut_flag_); blocks_.swap(other.blocks_);
#ifndef SKIP_RUNTIME_CHECKS
        std::swap(built_, other.built_); std::swap(blocks_built_, other.blocks_built_);
#endif
    }
    void reset(int n = 0) { UndirectedLowLink replacement(n); swap(replacement); }
    int size() const noexcept { return n_; }
    std::size_t edge_count() const noexcept { return edges_.size(); }
    void reserve_edges(std::size_t m) { edges_.reserve(m); }
    std::size_t add_edge(int u, int v) {
#ifndef SKIP_RUNTIME_CHECKS
        vertex(u); vertex(v);
#endif
        edges_.emplace_back(u, v);
#ifndef SKIP_RUNTIME_CHECKS
        built_ = blocks_built_ = false;
#endif
        return edges_.size() - 1;
    }
    std::pair<int, int> edge(std::size_t id) const {
#ifndef SKIP_RUNTIME_CHECKS
        edge_id(id);
#endif
        return edges_[id];
    }
private:
    template<class Id> struct Adjacent { int to; Id id; };
    template<bool Blocks, class Id>
    int build_impl() {
        const auto m = edges_.size();
        if (m > std::vector<Adjacent<Id>>().max_size() / 2) throw std::length_error("LowLink: too many edges");
        std::vector<std::size_t> begin(static_cast<std::size_t>(n_) + 1);
        for (auto [u, v] : edges_) { ++begin[u + 1]; ++begin[v + 1]; }
        for (int v = 0; v < n_; ++v) begin[v + 1] += begin[v];
        std::vector<std::size_t> next(begin.begin(), begin.end() - 1);
        std::vector<Adjacent<Id>> incident(m * 2);
        for (std::size_t e = 0; e < m; ++e) { auto [u, v] = edges_[e]; incident[next[u]++] = {v, static_cast<Id>(e)}; incident[next[v]++] = {u, static_cast<Id>(e)}; }
        std::copy_n(begin.begin(), n_, next.begin());
        const auto no_edge = m;
        std::vector<int> entered(n_, -1), low(n_), parent(n_, -1), children(n_), dfs, component(n_, -1), pending_vertices;
        std::vector<std::size_t> parent_edge(n_, no_edge), pending;
        std::vector<unsigned char> bridge(m), cut(n_);
        std::vector<std::vector<std::size_t>> blocks;
        dfs.reserve(n_); pending_vertices.reserve(n_); if constexpr (Blocks) pending.reserve(m);
        int clock = 0, count = 0, two_count = 0;
        for (int root = 0; root < n_; ++root) {
            if (entered[root] != -1) continue;
            ++count; entered[root] = low[root] = clock++; dfs.push_back(root); pending_vertices.push_back(root);
            while (!dfs.empty()) {
                const int v = dfs.back();
                if (next[v] != begin[v + 1]) {
                    const auto [u, edge_id] = incident[next[v]++];
                    if (edge_id == parent_edge[v]) continue;
                    if (u == v) {
                        // 自己辺の2つの接続を、先に現れた側だけで処理する。
                        if constexpr (Blocks) if (next[v] == begin[v] + 1 || incident[next[v] - 2].id != edge_id) blocks.push_back({edge_id});
                        continue;
                    }
                    if (entered[u] == -1) {
                        parent[u] = v; parent_edge[u] = edge_id; ++children[v]; if constexpr (Blocks) pending.push_back(edge_id);
                        entered[u] = low[u] = clock++; dfs.push_back(u); pending_vertices.push_back(u);
                    } else if (entered[u] < entered[v]) { low[v] = std::min(low[v], entered[u]); if constexpr (Blocks) pending.push_back(edge_id); }
                    continue;
                }
                dfs.pop_back();
                // 親への木辺が橋になる根で、未確定の頂点を同じ2辺連結成分にする。
                if (low[v] == entered[v]) {
                    for (;;) {
                        const int u = pending_vertices.back(); pending_vertices.pop_back();
                        component[u] = two_count;
                        if (u == v) break;
                    }
                    ++two_count;
                }
                const int p = parent[v];
                if (p == -1) { cut[v] = children[v] > 1; continue; }
                low[p] = std::min(low[p], low[v]);
                if (low[v] > entered[p]) bridge[parent_edge[v]] = 1;
                if (low[v] >= entered[p]) {
                    if (parent[p] != -1) cut[p] = 1;
                    if constexpr (Blocks) {
                        blocks.emplace_back(); auto& block = blocks.back();
                        for (;;) { const auto id = pending.back(); pending.pop_back(); block.push_back(id); if (id == parent_edge[v]) break; }
                    }
                }
            }
        }
        std::vector<std::size_t> bridges; std::vector<int> points;
        for (std::size_t e = 0; e < m; ++e) if (bridge[e]) bridges.push_back(e);
        for (int v = 0; v < n_; ++v) if (cut[v]) points.push_back(v);
        bridges_.swap(bridges); articulation_.swap(points); two_edge_id_.swap(component);
        bridge_flag_.swap(bridge); cut_flag_.swap(cut); blocks_.swap(blocks); components_ = count;
#ifndef SKIP_RUNTIME_CHECKS
        built_ = true; blocks_built_ = Blocks;
#endif
        return count;
    }
public:
    int build(bool collect_blocks = false) {
        if constexpr (sizeof(std::size_t) > sizeof(std::uint32_t)) {
            if (edges_.size() <= std::numeric_limits<std::uint32_t>::max())
                return collect_blocks ? build_impl<true, std::uint32_t>() : build_impl<false, std::uint32_t>();
        }
        return collect_blocks ? build_impl<true, std::size_t>() : build_impl<false, std::size_t>();
    }
    int component_count() const {
#ifndef SKIP_RUNTIME_CHECKS
        require_build();
#endif
        return components_;
    }
    const std::vector<std::size_t>& bridges() const {
#ifndef SKIP_RUNTIME_CHECKS
        require_build();
#endif
        return bridges_;
    }
    const std::vector<int>& articulation_points() const {
#ifndef SKIP_RUNTIME_CHECKS
        require_build();
#endif
        return articulation_;
    }
    bool is_bridge(std::size_t e) const {
#ifndef SKIP_RUNTIME_CHECKS
        require_build(); edge_id(e);
#endif
        return bridge_flag_[e] != 0;
    }
    bool is_articulation(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        require_build(); vertex(v);
#endif
        return cut_flag_[v] != 0;
    }
    int two_edge_component(int v) const {
#ifndef SKIP_RUNTIME_CHECKS
        require_build(); vertex(v);
#endif
        return two_edge_id_[v];
    }
    std::vector<std::vector<int>> two_edge_components() const {
#ifndef SKIP_RUNTIME_CHECKS
        require_build();
#endif
        const int count = two_edge_id_.empty() ? 0 : *std::max_element(two_edge_id_.begin(), two_edge_id_.end()) + 1;
        std::vector<std::vector<int>> result(count);
        for (int v = 0; v < n_; ++v) result[two_edge_id_[v]].push_back(v);
        return result;
    }
    Graph bridge_forest() const {
#ifndef SKIP_RUNTIME_CHECKS
        require_build();
#endif
        const int count = two_edge_id_.empty() ? 0 : *std::max_element(two_edge_id_.begin(), two_edge_id_.end()) + 1;
        Graph result(count);
        for (auto id : bridges_) { auto [u, v] = edges_[id]; const int a = two_edge_id_[u], b = two_edge_id_[v]; result[a].push_back(b); result[b].push_back(a); }
        return result;
    }
    const std::vector<std::vector<std::size_t>>& biconnected_edge_components() const {
#ifndef SKIP_RUNTIME_CHECKS
        require_build(); if (!blocks_built_) throw std::logic_error("LowLink: call build(true) for biconnected blocks");
#endif
        return blocks_;
    }
    std::vector<std::vector<int>> biconnected_vertex_components(bool include_isolated = true) const {
#ifndef SKIP_RUNTIME_CHECKS
        require_build(); if (!blocks_built_) throw std::logic_error("LowLink: call build(true) for biconnected blocks");
#endif
        auto collect = [&]<class Stamp>() {
            std::vector<std::vector<int>> result; result.reserve(blocks_.size());
            std::vector<Stamp> last(n_, static_cast<Stamp>(blocks_.size()));
            for (std::size_t i = 0; i < blocks_.size(); ++i) {
                result.emplace_back();
                result.back().reserve(std::min(static_cast<std::size_t>(n_), blocks_[i].size() + 1));
                for (auto e : blocks_[i]) { const auto [u, v] = edges_[e]; for (int vertex : {u, v}) {
                    if (last[vertex] != i) { last[vertex] = static_cast<Stamp>(i); result.back().push_back(vertex); }
                } }
            }
            if (include_isolated) for (int v = 0; v < n_; ++v) if (last[v] == blocks_.size()) result.push_back({v});
            return result;
        };
        if constexpr (sizeof(std::size_t) > sizeof(std::uint32_t)) {
            if (blocks_.size() <= std::numeric_limits<std::uint32_t>::max())
                return collect.template operator()<std::uint32_t>();
        }
        return collect.template operator()<std::size_t>();
    }
};
#endif
