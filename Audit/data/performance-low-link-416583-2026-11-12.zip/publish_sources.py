# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import fcntl,subprocess,json,hashlib,shutil
D=Path('/tmp/sirkit_lowlink_416583');R=Path('/home/reinsirk/Atcoder_Env');rows=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for kind in ['whole','core']:
  jobs=json.loads((D/f'final_{kind}_jobs.json').read_text());summary=json.loads((D/f'final_{kind}_summary.json').read_text());assert len(jobs)==len(summary)and all(r['sufficient']for r in summary)
 val=json.loads((D/'final_validation.json').read_text());assert val['all_passed']and val['header_sha256']==sha(D/'final.hpp')
 assert json.loads((D/'final_fixture_validation.json').read_text())['all_passed']
 assert(R/'Graph/Low_Link.cpp').read_bytes()==(D/'base.hpp').read_bytes()
 for rel in ['Verify/current/drivers/low_link_two_edge_main.cpp','Verify/current/drivers/low_link_biconnected_main.cpp','Verify/current/common/fast_io.hpp','Examples/low_link_example.cpp','Document/low_link.md']:assert(R/rel).read_bytes()==(D/'before'/rel).read_bytes(),rel
 for source,target in [(D/'final.hpp',R/'Graph/Low_Link.cpp'),(D/'Document_low_link.md',R/'Document/low_link.md')]:
  tmp=target.with_suffix(target.suffix+'.tmp');tmp.write_bytes(source.read_bytes());tmp.replace(target)
 commands=[['python3',str(D/'apply_online_metadata.py'),'--apply','--performance-audit','Audit/performance-low-link-416583-2026-11-12.json'],['python3','Scripts/prepare_verify.py','--id','low_link_two_edge','--id','low_link_biconnected'],['python3','Scripts/generate_fast_sources.py'],['python3','Scripts/generate_variants.py'],['python3','Scripts/prepare_variant_verify.py'],['python3','Scripts/check_source_api_docs.py','--check']]
 for command in commands:
  p=subprocess.run(command,cwd=R,capture_output=True,text=True);rows.append(dict(command=command,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));assert p.returncode==0,p.stdout+p.stderr;print(command[1],'PASS',flush=True)
 for name in ['low_link_two_edge','low_link_biconnected']:assert(R/f'Verify/current/submissions/{name}.cpp').read_bytes()==(D/f'final_{name}.cpp').read_bytes()
 (D/'publication.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print('source/doc/variants/two fixedmain programs synchronized')
