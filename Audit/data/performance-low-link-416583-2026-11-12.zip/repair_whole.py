# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import bench,json,statistics,fcntl
D=Path('/tmp/sirkit_lowlink_416583');records=[]
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 raw=json.loads((D/'final_whole_raw.json').read_text());summary=json.loads((D/'final_whole_summary.json').read_text())
 for row in summary:
  if row['sufficient']:continue
  f=next(f for f in bench.fixtures if f['id']==row['case']);key=lambda r:all(r[k]==row[k]for k in ['compiler','flag','setting','case']);added=0
  for label,minimum in [('final',5),('control',2)]:
   for attempt in range(24):
    local=[r for r in raw if key(r)and r['label']==label and r['calibration_valid']]
    if len(local)>=minimum:break
    v=[bench.run_whole(row['compiler'],k,f,row['flag'])for k in ['base',label if label!='control'else'base','base']];assert len({r['canonical_sha256']for r in v})==1;b,t,a=[r['cpu_ns']for r in v];drift=max(b,a)/min(b,a);rep=1+max((r['rep']for r in raw if key(r)and r['label']==label),default=0);r={k:row[k]for k in ['compiler','flag','setting','case']};r.update(label=label,rep=rep,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]),calibration_repair=True);raw.append(r);added+=1
  ratios={l:[r['ratio']for r in raw if key(r)and r['label']==l and r['calibration_valid']]for l in ['final','control']};row.update(ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},valid_counts={l:len(v)for l,v in ratios.items()},sufficient=len(ratios['final'])>=5 and len(ratios['control'])>=2,calibration_repaired=True);records.append(dict(row=row,added=added));print(row,flush=True)
 (D/'final_whole_raw.json').write_text(json.dumps(raw));(D/'final_whole_summary.json').write_text(json.dumps(summary,indent=2)+'\n');(D/'calibration_repair.json').write_text(json.dumps(records,indent=2)+'\n')
