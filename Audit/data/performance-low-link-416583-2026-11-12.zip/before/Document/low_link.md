# Low-linkと二重連結成分

`Graph/Low_Link.cpp`の`UndirectedLowLink`は、無向多重グラフを辺IDで管理する。`add_edge`で追加し、`build()`後に橋・関節点・2辺連結成分を照会する。橋は取り除くと連結成分が増える辺、関節点は取り除くと連結成分が増える頂点を指す。親頂点だけを見て逆辺を除く方法と違い、同じ端点を持つ別IDの平行辺を誤って無視しない。

DFSの帰りがけを明示スタックで扱い、発見順と祖先へ戻れる最小の順序を計算する。深い鎖でも再帰しない。橋を除いたグラフの成分を追加の反復走査で求める。計算量はO(N+M)時間・領域。`bridge_forest()`はその成分を頂点、橋を辺とした無向森を返す。

`build(true)`では点二重連結ブロックも計算する。DFS木の辺と祖先への戻り辺をスタックへ置き、子の部分木がそれより上へ戻れないときに1ブロックずつ取り出す。既定の`build(false)`では、この辺スタックとブロックの確保を省く。

`biconnected_edge_components()`は各ブロックの辺ID群、`biconnected_vertex_components()`は端点を重複除去した頂点群を返す。これらは最後に`build(true)`していることが前提。自己辺はそれぞれ独立した1辺ブロックとする。孤立頂点は辺ブロックへ入れず、頂点版では既定で単独ブロックとして加える。自己辺を持つ場合のこの約束は、自己辺を許さないLibrary Checkerの点二重連結成分問題と区別する。

橋のIDと関節点の配列は昇順。成分やブロックの順序は規定しない。コピーは独立所有、ムーブ元は空の未分解グラフ。入力検査と結果の有効性だけの状態は`SKIP_RUNTIME_CHECKS`で除く。内部の容量計算と、橋・関節点を決める数学的な比較は維持する。`build`中に例外が出ても直前の結果を保持する。

[使用例](../Examples/low_link_example.cpp) · [独立参照](../Verify/current/tests/new_low_link_reference_test.cpp) · [2辺連結成分](https://judge.yosupo.jp/problem/two_edge_connected_components) · [点二重連結成分](https://judge.yosupo.jp/problem/biconnected_components)
