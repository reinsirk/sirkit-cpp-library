# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import shutil
D=Path('/tmp/sirkit_lowlink_416583');base=(D/'base.hpp').read_text();typed=(D/'typed_adjacency.hpp').read_text();reserve=(D/'reserve_vertices.hpp').read_text();pending=(D/'review/pending_vertices.hpp').read_text();shutil.copyfile(D/'review/pending_vertices.hpp',D/'pending_vertices.hpp')
# Diff contexts crossing the removed second walk are not applied automatically.
# Instead retain the typed adjacency setup/DFS, replace the post-DFS second walk with pending's discovery/finalization logic.
t=typed
for old,new in [
 ('dfs, component(n_, -1);','dfs, component(n_, -1), pending_vertices;'),
 ('dfs.reserve(n_); if constexpr (Blocks)', 'dfs.reserve(n_); pending_vertices.reserve(n_); if constexpr (Blocks)'),
 ('int clock = 0, count = 0;', 'int clock = 0, count = 0, two_count = 0;'),
 ('dfs.push_back(root);','dfs.push_back(root); pending_vertices.push_back(root);'),
 ('dfs.push_back(u);','dfs.push_back(u); pending_vertices.push_back(u);')]:
 # Only discovery occurrences before the second walk.
 a=t.index('        int two_count = 0;');head=t[:a].replace(old,new);t=head+t[a:]
a=pending.index('                // 親への木辺');b=pending.index('                const int p = parent[v];',a)
t=t.replace('                dfs.pop_back();\n                const int p', '                dfs.pop_back();\n'+pending[a:b]+'                const int p',1)
a=t.index('        int two_count = 0;');b=t.index('        std::vector<std::size_t> bridges;',a);t=t[:a]+t[b:]
(D/'typed_pending.hpp').write_text(t)
# Replace only the final vertex-components method with the independently tested reserve version.
a=base.index('    std::vector<std::vector<int>> biconnected_vertex_components(')
for name,source in [('pending_reserved',pending),('typed_reserved',typed),('combined',t)]:
 start=source.index('    std::vector<std::vector<int>> biconnected_vertex_components(');(D/(name+'.hpp')).write_text(source[:start]+reserve[a:])
print('pending/typed/reserved combinations prepared')
