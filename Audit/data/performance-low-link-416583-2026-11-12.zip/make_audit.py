# SPDX-License-Identifier: CC0-1.0
# 完了済みの最終版の証跡を/tmpへ作る。リポジトリへの公開は呼出し側が行う。
from pathlib import Path
from collections import defaultdict
import difflib, hashlib, json, math, statistics, zipfile

R = Path('/home/reinsirk/Atcoder_Env')
D = Path('/tmp/sirkit_lowlink_416583')
LIBRARY = 'Graph/Low_Link.cpp'
PERFORMANCE = 'Audit/performance-low-link-416583-2026-11-12.json'
ONLINE = 'Audit/online-low-link-416583-2026-11-12.json'
EVIDENCE = 'Audit/data/performance-low-link-416583-2026-11-12.zip'
PREVIOUS = 'Audit/distribution-manifest-before-low-link-416583-2026-11-12.json'
JOBS = {'low_link_two_edge': (416583, 55), 'low_link_biconnected': (416582, 262)}
OP_NAMES = {0: 'build(false)', 1: 'build(true)', 2: 'rebuild(false)', 3: 'rebuild(true)',
            4: 'two_edge_components', 5: 'biconnected_vertex_components(true)',
            6: 'biconnected_vertex_components(false)', 7: 'bridge_forest'}



def load(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def encode(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + '\n'


def qualified(row):
    return (row['valid_counts']['final'] >= 5 and row['valid_counts']['control'] >= 2
            and row['ratios']['final'] is not None and row['ratios']['control'] is not None)


def signature(row):
    return (row['compiler'], row['flag'], row['setting'],
            json.dumps(row['case'], sort_keys=True, separators=(',', ':')))


def compact_stats(rows, fields):
    result = []
    for key in sorted({tuple(row[k] for k in fields) for row in rows}):
        group = [row for row in rows if tuple(row[k] for k in fields) == key]
        valid = [row for row in group if qualified(row)]
        row = dict(zip(fields, key)) | dict(cells=len(group), qualified_cells=len(valid))
        if valid:
            row.update(candidate_ratio=math.exp(statistics.mean(math.log(x['ratios']['final']) for x in valid)),
                       identical_control_ratio=math.exp(statistics.mean(math.log(x['ratios']['control']) for x in valid)),
                       minimum_ratio=min(x['ratios']['final'] for x in valid),
                       maximum_ratio=max(x['ratios']['final'] for x in valid))
        result.append(row)
    return result


def measurements(kind, fixtures):
    jobs = load(D / f'final_{kind}_jobs.json')
    summary = load(D / f'final_{kind}_summary.json')
    raw = load(D / f'final_{kind}_raw.json')
    assert jobs and len(jobs) == len(summary) and raw, (kind, '未完了')
    expected = set()
    for job in jobs:
        copy = dict(job)
        if kind == 'whole': copy['case'] = job['case']['id']
        key = signature(copy)
        assert key not in expected, (kind, '重複job', key)
        expected.add(key)
    assert {signature(x) for x in summary} == expected
    assert len({signature(x) for x in summary}) == len(summary)
    grouped = defaultdict(list)
    for row in raw:
        key = signature(row)
        assert key in expected and row['label'] in {'final', 'control'}
        values = [row[k] for k in ['before', 'target', 'after']]
        times = [x['cpu_ns'] for x in values]
        assert all(t > 0 for t in times)
        drift = max(times[0], times[2]) / min(times[0], times[2])
        assert row['calibration_valid'] == (drift <= 1.10)
        assert math.isclose(row['reference_drift'], drift, rel_tol=1e-12)
        assert math.isclose(row['ratio'], times[1] / statistics.median([times[0], times[2]]), rel_tol=1e-12)
        if kind == 'whole':
            correct = fixtures[row['case']]['expected_canonical_sha256']
            assert all(x['canonical_sha256'] == correct for x in values)
        else:
            assert len({x['digest'] for x in values}) == 1
        grouped[key].append(row)
    for row in summary:
        samples = grouped[signature(row)]
        for label in ['final', 'control']:
            ratios = [x['ratio'] for x in samples if x['label'] == label and x['calibration_valid']]
            assert row['valid_counts'][label] == len(ratios)
            assert (row['ratios'][label] is None) == (not ratios)
            if ratios: assert math.isclose(row['ratios'][label], statistics.median(ratios), rel_tol=1e-12)
        assert row['sufficient'] == qualified(row)
    assert {x['compiler'] for x in summary} == {'gcc', 'clang'}
    # 基準未達の条件も削除せず記録する。採用根拠が全て未達なら処理を止める。
    assert all(any(qualified(x) and x['compiler'] == cc for x in summary) for cc in ['gcc', 'clang'])
    return jobs, summary, raw


FROZEN_PUBLIC = ['Verify/current/drivers/low_link_two_edge_main.cpp',
                 'Verify/current/drivers/low_link_biconnected_main.cpp',
                 'Verify/current/common/fast_io.hpp', 'Examples/low_link_example.cpp']
DOCUMENT = 'Document/low_link.md'
FIXTURE_METADATA = {'fixtures.json', 'summary.json', 'source_audit.json', 'commands.json', 'validation.json'}
FIXTURE_OWN_SOURCES = {'canonical.py', 'oracle.cpp', 'prepare.py'}


def validate_final(after):
    value = load(D / 'final_validation.json')
    assert value['header_sha256'] == after and value['all_passed'] and value['completed_at_utc']
    rows = value['jobs']
    assert value['total_jobs'] == value['completed_jobs'] == value['passed_jobs'] == len(rows)
    tests = {'new_low_link_reference_test', 'new_graph2_allocation_test', 'low_link_components_allocation_test'}
    expected = {(cc, setting, mode, test) for cc in ['gcc', 'clang']
                for setting in ['checked', 'skip'] for mode in ['default', 'forced_wide'] for test in tests}
    plain = [row for row in rows if not row['sanitizer']]
    sanitized = [row for row in rows if row['sanitizer']]
    assert len(plain) == len(expected) and {(row['compiler'], row['setting'], row['mode'], row['test']) for row in plain} == expected
    expected_san = {(cc, setting, mode, 'new_low_link_reference_test') for cc in ['gcc', 'clang']
                    for setting in ['checked', 'skip'] for mode in ['default', 'forced_wide']}
    assert len(sanitized) == len(expected_san) and {(row['compiler'], row['setting'], row['mode'], row['test']) for row in sanitized} == expected_san
    assert value['forced_wide_conditions']['edge_ids']['count'] == 1
    assert value['forced_wide_conditions']['block_stamps']['count'] == 1
    wide = D / 'validation_forced_wide.hpp'
    assert sha(wide) == value['forced_wide_header_sha256']
    text = (D / 'final.hpp').read_text()
    for condition in value['forced_wide_conditions'].values():
        assert text.count(condition['expression']) == condition['count'] and condition['replacement'] == 'false'
        text = text.replace(condition['expression'], condition['replacement'])
    assert text == wide.read_text()
    for name, expected_hash in value['support_source_hashes'].items():
        assert sha(R / name) == expected_hash
    allocation = []
    for row in rows:
        assert row['status'] == 'passed' and row['passed'] and row['compile_returncode'] == row['returncode'] == 0 and not row['stderr']
        assert sha(Path(row['source'])) == row['test_sha256']
        expected_hash = after if row['mode'] == 'default' else value['forced_wide_header_sha256']
        assert row['header_sha256'] == expected_hash
        assert sha(Path(row['executable'])) == row['executable_sha256']
        assert f'-DLOW_LINK_SOURCE="{row["header"]}"' in row['command']
        assert ('-DSKIP_RUNTIME_CHECKS' in row['command']) == (row['setting'] == 'skip')
        if row['test'] == 'new_low_link_reference_test':
            assert row['counters']['checks'] > 0
            if not row['sanitizer']:
                assert '-pedantic-errors' in row['command']
        else:
            assert row['counters']['failures'] > 0 and row['counters']['successes'] > 0 and row['counters']['live_delta'] == 0
            allocation.append(dict(test=row['test'], compiler=row['compiler'], setting=row['setting'], mode=row['mode'], **row['counters']))
    return value, allocation


def validate_builds(before, after):
    rows = load(D / 'final_builds.json')
    expected = {(cc, flag, label, 'core', setting) for cc in ['gcc', 'clang']
                for flag in ['native', 'default'] for label in ['base', 'final'] for setting in ['checked', 'skip']}
    expected |= {(cc, flag, label, name, 'skip') for cc in ['gcc', 'clang']
                 for flag in ['native', 'default'] for label in ['base', 'final'] for name in JOBS}
    actual = {(row['compiler'], row['flag'], row['label'], row['kind'], row['setting']) for row in rows}
    assert actual == expected and len(rows) == len(expected)
    for row in rows:
        assert row['returncode'] == 0 and sha(Path(row['executable'])) == row['executable_sha256']
        assert row['header_sha256'] == (before if row['label'] == 'base' else after)
    return rows


def validate_fixtures():
    rows = load(D / 'fixtures/fixtures.json')
    fixtures = {row['id']: row for row in rows}
    summary = load(D / 'fixtures/summary.json')
    validation = load(D / 'fixtures/validation.json')
    assert len(rows) == len(fixtures) == summary['cases'] == validation['fixture_rows']
    assert summary['physical_graphs'] == validation['unique_inputs'] == len({row['path'] for row in rows})
    assert validation['all_passed'] and validation['canonical_outputs'] == len(fixtures)
    assert {row['problem'] for row in rows} == {'two_edge_connected_components', 'biconnected_components'}
    assert sha(D / 'fixtures/oracle.cpp') == summary['oracle_source_sha256']
    assert sha(D / 'fixtures/canonical.py') == summary['canonical_source_sha256']
    return fixtures, summary, validation


def validate_fixture_outputs(fixtures):
    value = load(D / 'final_fixture_validation.json')
    rows = value['rows']
    expected = {(cc, flag, label, case) for cc in ['gcc', 'clang'] for flag in ['native', 'default']
                for label in ['base', 'final'] for case in fixtures}
    actual = {(row['compiler'], row['flag'], row['label'], row['fixture']) for row in rows}
    assert value['all_passed'] and value['count'] == len(rows) == len(expected) and actual == expected
    for row in rows:
        assert row['passed'] and row['canonical_sha256'] == fixtures[row['fixture']]['expected_canonical_sha256']
    return value


def final_coverage(whole_jobs, core_jobs, fixtures):
    whole_cases = {row['case']['id'] for row in whole_jobs}
    assert whole_cases <= fixtures.keys()
    assert {fixtures[name]['problem'] for name in whole_cases} == {'two_edge_connected_components', 'biconnected_components'}
    assert len(whole_jobs) == len(whole_cases) * 2 * 2
    assert {(row['compiler'], row['flag'], row['setting'], row['case']['id']) for row in whole_jobs} == {
        (cc, flag, 'skip', case) for cc in ['gcc', 'clang'] for flag in ['native', 'default'] for case in whole_cases}
    core_cases = {json.dumps(row['case'], sort_keys=True) for row in core_jobs}
    primary_names = {'custom_random64', 'custom_star100k', 'custom_random100k_500k'}
    native_cases = {json.dumps(row['case'], sort_keys=True) for row in core_jobs
                    if row['flag'] == 'native' and row['case']['name'] in primary_names}
    for name in primary_names:
        assert {json.loads(case)['operation'] for case in native_cases if json.loads(case)['name'] == name} == set(OP_NAMES)
    default_cases = {case for case in native_cases if json.loads(case)['name'] == 'custom_random100k_500k'}
    extra_cases = {json.dumps(row['case'], sort_keys=True) for row in core_jobs
                   if row['case']['name'] == 'official_two_edge_connected_components_max_random_00'}
    assert {json.loads(case)['operation'] for case in extra_cases} == {4, 7}
    expected = {(cc, 'native', setting, case) for cc in ['gcc', 'clang']
                for setting in ['checked', 'skip'] for case in native_cases}
    expected |= {(cc, 'default', 'skip', case) for cc in ['gcc', 'clang'] for case in default_cases}
    expected |= {(cc, 'native', 'skip', case) for cc in ['gcc', 'clang'] for case in extra_cases}
    actual = {(row['compiler'], row['flag'], row['setting'], json.dumps(row['case'], sort_keys=True)) for row in core_jobs}
    assert actual == expected and len(actual) == len(core_jobs)
    assert {row['case']['operation'] for row in core_jobs} == set(OP_NAMES)
    for row in core_jobs:
        case = row['case']
        matches = [fixture for fixture in fixtures.values() if fixture['path'] == case['path']]
        assert matches and all(fixture['n'] == case['n'] and fixture['m'] == case['m'] for fixture in matches)
        assert case['repetitions'] > 0
    return whole_cases, core_cases


def exploratory(fixtures):
    result = []
    for stem in ['screen', 'stage2', 'stage3']:
        summary_path = D / (stem + '_summary.json')
        raw_path = D / (stem + '_raw.json')
        if not summary_path.exists() and not raw_path.exists():
            continue
        summary, raw = load(summary_path), load(raw_path)
        assert summary and raw
        labels = {row['label'] for row in raw} - {'control'}
        sources = {label: dict(file=label + '.hpp', sha256=sha(D / (label + '.hpp'))) for label in sorted(labels)}
        def key(row):
            return (row['compiler'], json.dumps(row['case'], sort_keys=True))
        assert len({key(row) for row in summary}) == len(summary)
        assert {key(row) for row in summary} == {key(row) for row in raw}
        for row in raw:
            values = [row[name] for name in ['before', 'target', 'after']]
            times = [value['cpu_ns'] for value in values]
            assert all(value > 0 for value in times)
            drift = max(times[0], times[2]) / min(times[0], times[2])
            assert row['calibration_valid'] == (drift <= 1.10)
            assert math.isclose(row['reference_drift'], drift, rel_tol=1e-12)
            assert math.isclose(row['ratio'], times[1] / statistics.median([times[0], times[2]]), rel_tol=1e-12)
            assert all(value['canonical_sha256'] == fixtures[row['case']]['expected_canonical_sha256'] for value in values)
        for row in summary:
            samples = [sample for sample in raw if key(sample) == key(row)]
            assert set(row['ratios']) == labels | {'control'}
            for label in labels | {'control'}:
                ratios = [sample['ratio'] for sample in samples if sample['label'] == label and sample['calibration_valid']]
                assert row['valid_counts'][label] == len(ratios)
                assert (row['ratios'][label] is None) == (not ratios)
                if ratios:
                    assert math.isclose(row['ratios'][label], statistics.median(ratios), rel_tol=1e-12)
        result.append(dict(stage=stem, labels=sources, cells=len(summary), triplets=len(raw),
                           summary=summary_path.name, summary_sha256=sha(summary_path),
                           raw=raw_path.name, raw_sha256=sha(raw_path),
                           scope='探索の少数反復を保存。最終測定と区別する。'))
    return result


def evidence_files():
    import os
    excluded_names = {'audit_draft.json', Path(PERFORMANCE).name, 'distribution_update.log',
                      'compiler_official_langs.toml'}
    excluded_parts = {'__pycache__', 'generator_bins', 'inputs', 'outputs', 'sources', 'validation',
                      'output', 'active', 'platform_evidence', 'artifacts', 'snapshots',
                      'third_party', 'third-party', 'external', 'frontend'}
    allowed_suffixes = {'.py', '.hpp', '.cpp', '.json', '.diff', '.md', '.log'}
    for parent, directories, names in os.walk(D, followlinks=False):
        parent = Path(parent)
        directories[:] = [name for name in directories if name not in excluded_parts and not (parent / name).is_symlink()]
        for name in names:
            path = parent / name
            if path.is_symlink() or name in excluded_names or path.suffix not in allowed_suffixes:
                continue
            relative = path.relative_to(D)
            assert path.resolve().is_relative_to(D.resolve())
            if relative.parts[0] == 'fixtures' and (len(relative.parts) != 2 or name not in FIXTURE_METADATA | FIXTURE_OWN_SOURCES):
                continue
            if relative.parts[0] == 'profiles' and path.suffix != '.json':
                continue
            if name.startswith('compiler_evidence_'):
                continue
            yield path


def main():
    selection = load(D / 'final_selection.json')
    assert selection['decision'].startswith('adopt') and selection['changes']
    before = sha(D / 'before' / LIBRARY)
    after = sha(R / LIBRARY)
    assert before == sha(D / 'base.hpp') == '447197bca51ca51690281375230e99abb6c8462e804b1aa6922921d35560d4c4'
    assert after != before and after == sha(D / 'final.hpp') == sha(D / (selection['label'] + '.hpp')) == selection['measured_candidate_sha256']
    implementation = D / (selection['implementation_candidate'] + '.hpp')
    assert sha(implementation) == selection['implementation_candidate_sha256']
    # 選定候補と配布する本体のコード部分を照合する。
    def implementation_text(path):
        return '\n'.join(line for line in path.read_text().splitlines() if line.strip() and not line.lstrip().startswith('//'))
    assert implementation_text(implementation) == implementation_text(D / 'final.hpp')
    frozen = load(D / 'frozen.json')
    assert len(frozen['files']) == 15
    for name, expected in frozen['files'].items():
        assert sha(D / 'before' / name) == expected
    for name in FROZEN_PUBLIC:
        assert (R / name).read_bytes() == (D / 'before' / name).read_bytes(), name
    online = {row['id']: row for row in load(D / 'online_records.json')['records']}
    journal = {row['id']: row for row in load(R / 'Verify/current/judgements.json')['entries']}
    for identifier, (submission, milliseconds) in JOBS.items():
        old, current = online[identifier], journal[identifier]
        assert old['url'] == f'https://judge.yosupo.jp/submission/{submission}' and old['status'] == 'AC' and old['time_ms'] == milliseconds
        assert old['source_hashes'] == {LIBRARY: before}
        assert len(old['case_results']) == {'low_link_two_edge': 21, 'low_link_biconnected': 22}[identifier]
        assert all(row['status'] == 'AC' for row in old['case_results'])
        assert old['driver_sha256'] == sha(R / f'Verify/current/drivers/{identifier}_main.cpp')
        assert old['io_source_hashes'] == {'Verify/current/common/fast_io.hpp': sha(R / 'Verify/current/common/fast_io.hpp')}
        assert current['url'] == old['url'] and current['time_ms'] == milliseconds and current['status'] == 'AC'
        assert current['source_hashes'] == {LIBRARY: before} and current['current_source_hashes'] == {LIBRARY: after}
        assert current['needs_resubmission'] and not current['matched_current_generation']
        actual = R / f'Verify/current/submissions/{identifier}.cpp'
        assert current['current_submission_sha256'] == sha(actual)
        assert actual.read_bytes() == (D / f'final_{identifier}.cpp').read_bytes()
        assert actual.read_bytes().startswith(b'#define SKIP_RUNTIME_CHECKS\n') and actual.stat().st_size <= 512 * 1024
    validation, allocation = validate_final(after)
    builds = validate_builds(before, after)
    fixtures, fixture_info, fixture_proof = validate_fixtures()
    whole_jobs, whole, whole_raw = measurements('whole', fixtures)
    core_jobs, core, core_raw = measurements('core', fixtures)
    whole_cases, core_cases = final_coverage(whole_jobs, core_jobs, fixtures)
    fixture_results = validate_fixture_outputs(fixtures)
    screens = exploratory(fixtures)
    checkpoint = D / 'profiles/checkpoint.json'
    profile = load(checkpoint)
    assert profile['status'] == 'local_samples_passed_for_snapshot' and profile['completed_at_utc'] and profile['active'] is None
    assert profile['counts'] == {'LOCAL_SAMPLE_PASS': 14}
    for name, expected_hash in profile['manifest_hashes'].items():
        assert sha(R / name) == expected_hash, ('profileのsnapshot後にmanifest/scriptが変わった', name)
    for row in whole:
        row['problem'] = fixtures[row['case']]['problem']
    invalid_whole = [row for row in whole if not qualified(row)]
    invalid_core = [row for row in core if not qualified(row)]
    for row in validation['jobs']:
        path = Path(row['source'])
        destination = D / 'evidence_tests' / path.name
        destination.parent.mkdir(exist_ok=True)
        if destination.exists():
            assert destination.read_bytes() == path.read_bytes()
        else:
            destination.write_bytes(path.read_bytes())
    before_text = (D / 'before' / LIBRARY).read_text()
    final_text = (D / 'final.hpp').read_text()
    (D / 'final.diff').write_text(''.join(difflib.unified_diff(before_text.splitlines(True), final_text.splitlines(True),
                                                          fromfile='before/Low_Link.cpp', tofile='selected/Low_Link.cpp')))
    online_data = load(D / 'online_records.json')
    audit = dict(
        date='2026-11-12', library=LIBRARY, decision=selection['decision'], source_sha256=dict(before=before, after=after),
        selection=selection, required_resubmission=[f'Verify/current/submissions/{identifier}.cpp' for identifier in JOBS],
        online_evidence=ONLINE,
        online_scope='416583のtwo_edge AC55ms・416582のbiconnected AC262msは旧本体447197の本文/main/共通IOと一致。今回の新本体は未提出であり、そのACを現行版や派生版へ転記しない。',
        online_compiler_context=online_data['compiler_context'],
        frozen_public_files={name: sha(R / name) for name in FROZEN_PUBLIC},
        before_snapshot=dict(file='frozen.json', sha256=sha(D / 'frozen.json'), files=frozen['files']),
        document=dict(path=DOCUMENT, before_sha256=sha(D / 'before' / DOCUMENT), after_sha256=sha(R / DOCUMENT),
                      scope='main/IO/使用例と分離して、アルゴリズムと従来どおり未規定の成分順を説明する。本文の変更前後SHAを記録し、同一であるとは要求しない。'),
        API_scope='公開型・引数・戻り値・多重辺/自己辺・所有権・例外保証を維持。成分番号と外側の順は未規定。各成分の構成と森の対応を正規化して独立参照へ照合する。',
        proof_files=sorted(str(path.relative_to(D)) for path in (D / 'review').glob('*review.md')), source_diff='final.diff',
        measurement=dict(
            cpu='Intel Core i9-14900K CPU12（P-Core、sibling13）。E-Coreは性能評価しない。',
            compilers=dict(GCC='15.2.0', Clang='21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'),
            flags_scope='C++23 -O2。native/defaultを区別し、全て同じmain/共通IOを使用。引数・実行体SHAはfinal_builds.jsonへ保存。',
            CPU_scope='Library CheckerのAMD実機の速度比とは断定しない。', lock='/tmp/sirkit_performance_cpu12.lock', compilation_during_timing=False,
            ASLR='子だけsetarch x86_64 -R、同じactiveパス。',
            protocol='旧版→候補→旧版。候補を両端中央値で割る。両端差10%以内を有効とし、候補自体の遅さで除外しない。候補7組・同一対照3組で開始。不足時のみ15組/9組まで補い、候補5組/対照2組を基準とする。',
            fixtures=dict(cases=len(fixtures), physical_graphs=fixture_info['physical_graphs'],
                          input_bytes_unique=fixture_info['input_bytes_unique'], input_bytes_with_reused_rows=fixture_info['input_bytes_with_reused_rows'],
                          metadata_sha256={name: sha(D / 'fixtures' / name) for name in sorted(FIXTURE_METADATA)},
                          independent_oracle_scope=fixture_info['scope'], structural_cross_checks=fixture_info['closed_form_cross_checks'],
                          tiny_bruteforce_cross_checks=fixture_info['brute_force_cross_checks'],
                          result_scope='各群・群集合をソートして正規化した出力SHAで照合。未規定の成分番号や出力順の差を誤検出せず、群内の要素の欠落/重複は検出する。自己辺は明示したローカルの独立ブロック仕様で補足。'),
            whole=dict(cells=len(whole_jobs), cases=len(whole_cases), qualified_cells=len(whole)-len(invalid_whole), triplets=len(whole_raw),
                       statistics=compact_stats(whole, ['compiler', 'flag', 'problem']), insufficient_cells=invalid_whole,
                       jobs='final_whole_jobs.json', summary='final_whole_summary.json', raw='final_whole_raw.json',
                       time='固定main全体の子user+system CPU時間。SKIP設定。出力正規化・独立参照SHA照合は計測後。'),
            core=dict(cells=len(core_jobs), scenarios=len(core_cases), qualified_cells=len(core)-len(invalid_core), triplets=len(core_raw),
                      statistics=compact_stats(core, ['compiler', 'flag', 'setting']), operations=OP_NAMES,
                      insufficient_cells=invalid_core, jobs='final_core_jobs.json', summary='final_core_summary.json', raw='final_core_raw.json',
                      time='std::clock。入力読込とグラフ準備は計測外、指定操作と返り値の生成は内、checksumの正規化と照合は後。'),
            exploratory=screens,
            observed_tradeoffs=dict(whole_above_three_percent=[row for row in whole if qualified(row) and row['ratios']['final'] > 1.03],
                                    large_core_above_three_percent=[row for row in core if qualified(row) and row['case']['n'] >= 100000 and row['ratios']['final'] > 1.03],
                                    scope='最終測定の基準達成セルから導出。未達セルを隠さず記録する。'),
            scope='件数は実際のjobファイルと全署名一致で算出する。P-Core上の条件固定比較であり、全条件・全CPUで一律改善とは主張しない。'),
        validation=dict(jobs=validation['total_jobs'], all_passed=True, details='final_validation.json', sha256=sha(D / 'final_validation.json'),
                        matrix='GCC/Clang×checked/SKIP×default/forced-wide×参照/構築確保失敗/照会確保失敗の24件、同8設定のASAN+UBSAN参照。',
                        allocation_counters=allocation, forced_wide_conditions=validation['forced_wide_conditions'],
                        wide_scope='通常サイズで辺IDと頂点群stampのsize_t経路を強制。UINT32_MAX超の物理入力を試したとは扱わない。',
                        leak_scope='host ptraceのためLeakSanitizerは無効。独立live allocation counterは全確保試験でdelta=0。',
                        builds=len(builds), fixture_comparisons=fixture_results['count'], fixture_details='final_fixture_validation.json',
                        fixture_sha256=sha(D / 'final_fixture_validation.json'),
                        profiles=dict(jobs=14, file='profiles/checkpoint.json', sha256=sha(checkpoint), run_id=profile['run_id'],
                                      scope='派生版8件と使用例6件のローカルサンプル。オンライン判定ではない。')),
        license='既存CC0実装への独自変更。参考ライブラリの実装コードを新規に取り込まない。', evidence_archive=EVIDENCE,
        evidence_scope='自身の候補・生成スクリプト・独立参照・レビュー・最終測定raw・自分の提出API原本・入力provenanceを保存。外部実装ソース・コンパイラ原典・入力/出力本体・実行体・symlink参照先を除外。')
    audit['measurement']['calibration_repair'] = dict(file='calibration_repair.json', rows=load(D/'calibration_repair.json'), scope='両端差10%で基準未達だった1セルだけ、候補最大24組を追加可能として補充。実際は2組で5有効組に到達。候補自身の時間で選別せず以前のrawもすべて保持。')
    audit['superseded_scope'] = 'superseded_deferred/は560e1a候補の最終という名前の記録。bridge_forestが小さい結果でもNを走査していたため、成分数キャッシュとO(1)の個数APIを追加し、dc390aの最終版ですべて検証・測定を取り直した。'
    for field in ['outcome', 'tradeoff_notes', 'limitations']:
        if field in selection:
            audit[field] = selection[field]
    draft, archive, previous = (D / Path(name).name for name in [PERFORMANCE, EVIDENCE, PREVIOUS])
    previous.write_bytes((D / 'before/Distribution/manifest.json').read_bytes())
    (D / 'audit_draft.json').write_text(encode(audit))
    paths = sorted(evidence_files())
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in paths:
            z.write(path, path.relative_to(D).as_posix())
    audit['evidence_archive_sha256'] = sha(archive)
    draft.write_text(encode(audit))
    print(encode(dict(audit=str(draft), audit_target=PERFORMANCE, evidence=str(archive), evidence_target=EVIDENCE,
                      previous_manifest=str(previous), previous_manifest_target=PREVIOUS,
                      evidence_bytes=archive.stat().st_size, evidence_files=len(paths), repository_written=False)), end='')


if __name__ == '__main__':
    main()
