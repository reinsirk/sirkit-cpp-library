# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,difflib,json
D=Path('/tmp/sirkit_lowlink_416583/review');base=(D.parent/'typed_adjacency.hpp').read_text();(D/'typed_marked_base.hpp').write_text(base);s=base
old='        int clock = 0, count = 0;';new='        int clock = 0, count = 0, two_count = 0;';assert s.count(old)==1;s=s.replace(old,new)
old='''                dfs.pop_back();
                const int p = parent[v];'''
new='''                dfs.pop_back();
                // 橋で区切られる根は負の印、その他は同じ成分の親への参照を置く。
                component[v] = low[v] == entered[v] ? -(++two_count) : parent[v];
                const int p = parent[v];''';assert s.count(old)==1;s=s.replace(old,new)
a=s.index('        int two_count = 0;\n');b=s.index('        std::vector<std::size_t> bridges;',a);oldwalk=s[a:b];assert 'if (bridge[id]) continue;'in oldwalk
new='''        // 全頂点の終了後、親参照を負の印へ圧縮する。ここでは正のIDへ変換しない。
        for (int v = 0; v < n_; ++v) {
            if (component[v] < 0) continue;
            int root = v;
            while (component[root] >= 0) root = component[root];
            const int mark = component[root];
            int u = v;
            while (component[u] >= 0) {
                const int next_vertex = component[u];
                component[u] = mark;
                u = next_vertex;
            }
        }
        for (auto& id : component) id = -1 - id;
'''
s=s[:a]+new+s[b:]
p=D/'typed_marked.hpp';p.write_text(s);(D/'typed_marked.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='typed_adjacency.hpp',tofile='typed_marked.hpp')));(D/'typed_marked_metadata.json').write_text(json.dumps(dict(base_sha256=hashlib.sha256(base.encode()).hexdigest(),candidate_sha256=hashlib.sha256(s.encode()).hexdigest(),extra_peak_memory_bytes=0,public_API_changed=False,component_id_order_changed=True),indent=2)+'\n');print(hashlib.sha256(s.encode()).hexdigest())
