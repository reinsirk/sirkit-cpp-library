# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json,difflib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_lowlink_416583/review');base=(R/'Graph/Low_Link.cpp').read_text();(D/'base.hpp').write_text(base);s=base
old='std::vector<int> entered(n_, -1), low(n_), parent(n_, -1), children(n_), dfs, component(n_, -1);'
new='std::vector<int> entered(n_, -1), low(n_), parent(n_, -1), children(n_), dfs, component(n_, -1), pending_vertices;'
assert s.count(old)==1;s=s.replace(old,new)
old='''        dfs.reserve(n_); if constexpr (Blocks) pending.reserve(m);
        int clock = 0, count = 0;'''
new='''        dfs.reserve(n_); pending_vertices.reserve(n_); if constexpr (Blocks) pending.reserve(m);
        int clock = 0, count = 0, two_count = 0;'''
assert s.count(old)==1;s=s.replace(old,new)
old='++count; entered[root] = low[root] = clock++; dfs.push_back(root);'
new='++count; entered[root] = low[root] = clock++; dfs.push_back(root); pending_vertices.push_back(root);'
assert s.count(old)==1;s=s.replace(old,new)
old='entered[u] = low[u] = clock++; dfs.push_back(u);'
new='entered[u] = low[u] = clock++; dfs.push_back(u); pending_vertices.push_back(u);'
assert s.count(old)==1;s=s.replace(old,new)
old='''                dfs.pop_back();
                const int p = parent[v];'''
new='''                dfs.pop_back();
                // 親への木辺が橋になる根で、未確定の頂点を同じ2辺連結成分にする。
                if (low[v] == entered[v]) {
                    for (;;) {
                        const int u = pending_vertices.back(); pending_vertices.pop_back();
                        component[u] = two_count;
                        if (u == v) break;
                    }
                    ++two_count;
                }
                const int p = parent[v];'''
assert s.count(old)==1;s=s.replace(old,new)
a=s.index('        int two_count = 0;\n');b=s.index('        std::vector<std::size_t> bridges;',a)
old_second_walk=s[a:b];assert 'if (bridge[id]) continue;'in old_second_walk;s=s[:a]+s[b:]
(D/'pending_vertices.hpp').write_text(s);(D/'pending_vertices.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='Low_Link.cpp',tofile='pending_vertices.hpp')))
(D/'pending_vertices_metadata.json').write_text(json.dumps(dict(base_sha256=hashlib.sha256(base.encode()).hexdigest(),candidate_sha256=hashlib.sha256(s.encode()).hexdigest(),extra_peak_payload_bytes='4*N for pending_vertices capacity, implementation capacity overhead excluded',permanent_memory_changed=False,component_id_order_changed=True,public_API_changed=False),indent=2)+'\n');print(hashlib.sha256(s.encode()).hexdigest())
