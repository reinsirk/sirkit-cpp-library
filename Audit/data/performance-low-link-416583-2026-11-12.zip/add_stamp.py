# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import sys
D=Path('/tmp/sirkit_lowlink_416583')
def add_stamp(source):
 start=source.index('    std::vector<std::vector<int>> biconnected_vertex_components(')
 a=source.index('        std::vector<std::vector<int>> result;',start);b=source.index('\n    }\n};\n#endif',a);body=source[a:b]
 assert 'std::vector<std::size_t> last(n_, blocks_.size());'in body
 body=body.replace('std::vector<std::size_t> last(n_, blocks_.size());','std::vector<Stamp> last(n_, static_cast<Stamp>(blocks_.size()));').replace('last[vertex] = i;', 'last[vertex] = static_cast<Stamp>(i);')
 code='''        auto collect = [&]<class Stamp>() {
'''+''.join('    '+line+'\n'for line in body.splitlines())+'''        };
        if constexpr (sizeof(std::size_t) > sizeof(std::uint32_t)) {
            if (blocks_.size() <= std::numeric_limits<std::uint32_t>::max())
                return collect.template operator()<std::uint32_t>();
        }
        return collect.template operator()<std::size_t>();'''
 return source[:a]+code+source[b:]
if __name__=='__main__':
 for name in sys.argv[1:]:
  p=D/(name+'.hpp');(D/(name+'_stamp.hpp')).write_text(add_stamp(p.read_text()))
