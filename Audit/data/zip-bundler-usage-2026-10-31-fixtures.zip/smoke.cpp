#include <cstdint>
#include <iostream>
#include <vector>
#include BUNDLE
int main() {
    std::vector<int> ones(65,1);
    NTT<> ntt;
    auto product=ntt.convolution(ones,ones);
    if(product.size()!=129)return 1;
    for(std::size_t i=0;i<product.size();++i)
        if(product[i]!=(i<65?i+1:129-i))return 2;
    FormalPowerSeries denominator(std::vector<int>{1,-1});
    auto inverse=denominator.inverse(65);
    for(std::size_t i=0;i<65;++i)if(inverse.get(i)!=1)return 3;
    auto identity=(denominator*inverse).prefix(65);
    for(std::size_t i=0;i<65;++i)if(identity.get(i)!=(i==0?1U:0U))return 4;
    FormalPowerSeries polynomial(std::vector<int>{3,-2,1});
    ProductTree points(std::vector<int>{-2,0,3});
    const std::vector<std::uint32_t> values{11,3,6};
    if(points.evaluate(polynomial)!=values)return 5;
    if(points.interpolate(values).coefficients()!=polynomial.coefficients())return 6;
    CRTConvolution crt;
    const std::vector<std::int64_t> small_a{-2,3},small_b{4,5},small_expected{-8,2,15};
    for(std::uint32_t modulus:{1U,2U,7U,12U,4294967295U}){
        auto result=crt.modular(small_a,small_b,modulus);
        if(result.size()!=small_expected.size())return 10;
        for(std::size_t i=0;i<result.size();++i){
            auto expected=small_expected[i]%static_cast<std::int64_t>(modulus);
            if(expected<0)expected+=modulus;
            if(result[i]!=static_cast<std::uint32_t>(expected))return 7;
        }
    }
    if(crt.integer(small_a,small_b)!=small_expected)return 11;
    std::vector<std::int64_t>a(65),b(65,1000000000),expected(129);
    for(std::size_t i=0;i<a.size();++i)a[i]=(i%2==0?4000000000:-4000000000);
    // 各部分和も-4e18..4e18なので、この直接参照はint64_t内に収まる。
    for(std::size_t i=0;i<a.size();++i)
        for(std::size_t j=0;j<b.size();++j)expected[i+j]+=a[i]*b[j];
    if(crt.integer(a,b)!=expected)return 8;
    auto modulo=crt.modular(a,b,12);
    if(modulo.size()!=expected.size())return 12;
    for(std::size_t i=0;i<modulo.size();++i){
        auto value=expected[i]%12;if(value<0)value+=12;
        if(modulo[i]!=static_cast<std::uint32_t>(value))return 9;
    }
    std::cout<<"ZIP CLI math smoke OK\n";
}
