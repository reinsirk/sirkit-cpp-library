# SPDX-License-Identifier: CC0-1.0
import hashlib,json,os,pathlib,subprocess,sys,time
P=pathlib.Path(__file__).parent
ROOT=pathlib.Path('/tmp/cold_distribution_gate/extracted')
os.sched_setaffinity(0,{0})
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
report=dict(scope='Actual full-ZIP extracted bundle_libraries CLI with --root omitted, followed by generated-text API smoke only. This does not recount existing72PP/36runtime validation.',root=str(ROOT),cpu=0,tool_sha256=sha(ROOT/'Scripts/bundle_libraries.py'),document_sha256=sha(ROOT/'Document/bundling.md'),manifest_sha256=sha(ROOT/'Variants/manifest.json'),cli=[],conditions=[])
def save():(P/'checkpoint.json').write_text(json.dumps(report,indent=2)+'\n')
def execute(name,command,cwd,timeout=120):
    while(P/'pause').exists():(P/'pause_ack').write_text('idle\n');time.sleep(.25)
    (P/'pause_ack').unlink(missing_ok=True)
    env=dict(os.environ,LC_ALL='C',LANG='C',PYTHONDONTWRITEBYTECODE='1')
    for key in('PYTHONPATH','CPATH','CPLUS_INCLUDE_PATH','C_INCLUDE_PATH','OBJC_INCLUDE_PATH','INCLUDE'):env.pop(key,None)
    result=subprocess.run(command,cwd=cwd,env=env,capture_output=True,text=True,timeout=timeout)
    (P/(name+'.stdout')).write_text(result.stdout);(P/(name+'.stderr')).write_text(result.stderr)
    assert result.returncode==0,(name,result.returncode,result.stdout,result.stderr)
    return dict(command=command,cwd=str(cwd),returncode=result.returncode,stdout=result.stdout,stderr=result.stderr)
libraries=['Math/NTT.cpp','Math/Formal_Power_Series.cpp','Math/Polynomial.cpp','Math/Convolution.cpp']
for profile in ('normal','gcc','clang','fast-gcc','fast-clang'):
    output=P/(profile+'.cpp');metadata=P/(profile+'.json')
    command=[sys.executable,'Scripts/bundle_libraries.py','--profile',profile]
    for library in libraries:command+=['--library',library]
    command+=['--output',str(output),'--report',str(metadata)]
    assert '--root'not in command
    record=execute('cli_'+profile,command,ROOT)
    data=json.loads(metadata.read_text());assert data['accepted']and data['limit']==512*1024 and output.stat().st_size<=512*1024 and sha(output)==data['sha256_after']and data['code_bytes_after']==output.stat().st_size
    assert [x['library']for x in data['libraries']]==libraries
    record.update(profile=profile,output=str(output),output_bytes=output.stat().st_size,output_sha256=sha(output),metadata_sha256=sha(metadata),metadata=data)
    report['cli'].append(record);save()
    compilers=('gcc','clang')if profile=='normal'else('gcc'if profile.endswith('gcc')else'clang',)
    for compiler in compilers:
        cc=['/usr/bin/g++']if compiler=='gcc'else['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15']
        version=execute('version_'+compiler,cc+['--version'],P)['stdout']
        for standard in(False,True):
            for skip in ((True,)if profile.startswith('fast')else(False,True)):
                name=profile+'_'+compiler+('_standard'if standard else'_default')+('_skip'if skip else'_checked')
                flags=['-std=c++23','-O2','-Wall','-Wextra']+(['-DSIRKIT_DISABLE_SIMD','-DSIRKIT_FORCE_STANDARD_ARITHMETIC']if standard else[])+(['-DSKIP_RUNTIME_CHECKS']if skip else[])
                binary=P/name
                command=cc+flags+['-DBUNDLE="'+str(output)+'"',str(P/'smoke.cpp'),'-o',str(binary)]
                compiled=execute('build_'+name,command,P)
                ran=execute('run_'+name,[str(binary)],P)
                assert ran['stdout']=='ZIP CLI math smoke OK\n'
                report['conditions'].append(dict(profile=profile,compiler=compiler,compiler_version=version,standard_fallback=standard,skip=skip,flags=flags,compile=compiled,run=ran,binary_sha256=sha(binary),bundle_sha256=sha(output),status='PASS'));save()
    print(profile,'CLI+smoke PASS',flush=True)
assert len(report['cli'])==5 and len(report['conditions'])==20
report['status']='passed';report['smoke_sha256']=sha(P/'smoke.cpp');save();print('all5CLI +20smoke PASS',flush=True)
