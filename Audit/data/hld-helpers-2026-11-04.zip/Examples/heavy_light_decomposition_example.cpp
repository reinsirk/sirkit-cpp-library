// SPDX-License-Identifier: CC0-1.0
#include "../Graph/Heavy_Light_Decomposition.cpp"
#include "../DataStructure/Fenwick_Tree.cpp"
#include "../DataStructure/Segment_Tree.cpp"
#include "../DataStructure/Lazy_Segment_Tree.cpp"
#include <cassert>
#include <cstdint>
#include <iostream>
#include <string>
#include <utility>
#include <vector>
namespace {
std::string concat(std::string a,const std::string& b){a+=b;return a;}
std::string concat_reverse(const std::string& a,const std::string& b){return b+a;}
std::string empty_word(){return {};}
struct Total{std::int64_t sum;int length;};
Total combine(Total a,Total b){return {a.sum+b.sum,a.length+b.length};}
Total empty_total(){return {0,0};}
Total add_total(std::int64_t f,Total x){return {x.sum+f*x.length,x.length};}
std::int64_t compose_add(std::int64_t newer,std::int64_t older){return newer+older;}
std::int64_t zero_add(){return 0;}
}
int main(){
 Graph tree{{1,2},{0,3,4},{0},{1},{1}};HeavyLightDecomposition hld(tree);
 assert(hld.lca(3,4)==1);assert(hld.jump(3,2,2)==0);assert(hld.kth_ancestor(4,2)==0);
 std::vector<std::int64_t> value{1,2,3,4,5};
 fenwick_tree<std::int64_t> bit(hld.reorder(value));
 assert(hld.path_prod(3,2,bit)==10);
 bit.add(hld.index(3),10);value[3]+=10;
 assert(hld.path_prod(3,2,bit)==20);assert(hld.subtree_prod(1,bit)==21);
 assert(hld.restore(bit.values())==value);
 std::vector<std::string> token{"a","b","c","d","e"};
 segtree<std::string,concat,empty_word> forward(hld.reorder(token));
 segtree<std::string,concat_reverse,empty_word> backward(hld.reorder(token));
 auto path=hld.path_prod(3,2,empty_word(),[&](int l,int r,bool reversed){
  return reversed?backward.prod(l,r):forward.prod(l,r);
 },concat);
 assert(path=="dbac");std::cout<<path<<'\n';
 std::vector<Total> initial;for(auto x:value)initial.push_back({x,1});
 lazy_segtree<Total,combine,empty_total,std::int64_t,add_total,compose_add,zero_add> seg(hld.reorder(initial));
 hld.path_apply(3,2,seg,std::int64_t{2});assert(hld.path_prod(3,2,seg).sum==28);
 hld.subtree_apply(1,seg,std::int64_t{-1});assert(hld.path_prod(3,2,seg).sum==26);
 auto[l,r]=hld.subtree_range(1);assert(r-l==3);assert(!hld.path(3,2,true).empty());
}
