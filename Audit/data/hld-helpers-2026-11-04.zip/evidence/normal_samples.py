# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,subprocess,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_415174_20261104');m=json.loads((R/'Verify/current/manifest.json').read_text());rows=[]
for e in m['entries']:
 if e['id'] not in ['hld_jump','hld_vertex_add_path_sum','hld_path_prod','hld_path_composite']:continue
 src=R/'Verify/current/submissions'/f'{e["id"]}.cpp'
 for cc,prefix in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
  exe=D/f'normal_{cc}_{e["id"]}';cmd=['taskset','-c','6',*prefix,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(src),'-o',str(exe)];subprocess.run(cmd,check=True);checks=[]
  for sample in e['samples']:
   p=subprocess.run(['taskset','-c','6',str(exe)],input=sample['input'],text=True,capture_output=True);assert p.returncode==0 and p.stdout.split()==sample['output'].split() and not p.stderr,(e['id'],p.stdout,p.stderr);checks.append(dict(returncode=p.returncode,stdout=p.stdout))
  rows.append(dict(id=e['id'],compiler=cc,compile_command=cmd,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),samples=checks));(D/'normal_samples.json').write_text(json.dumps(rows,indent=2)+'\n');print(e['id'],cc,'PASS',flush=True)
