# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,hashlib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_415174_20261104');rows=[]
for label in ['base','helpers']:
 code=(D/'base.hpp').read_text()if label=='base'else(R/'Graph/Heavy_Light_Decomposition.cpp').read_text()
 for problem in ['jump','sum']:
  source='#define SKIP_RUNTIME_CHECKS\n'+code+'\n'+((D/'fenwick_frozen.cpp').read_text()+'\n'if problem=='sum'else'')+(D/'io.hpp').read_text()+'\n'+(D/f'{problem}_driver.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"','');src=D/f'{problem}_{label}.cpp';src.write_text(source)
  for cc,prefix in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
   exe=D/f'{cc}_{problem}_{label}';cmd=['taskset','-c','4']+prefix+['-std=c++23','-O2','-Wall','-Wextra','-Werror',str(src),'-o',str(exe)];subprocess.run(cmd,check=True);obj=D/f'{cc}_{problem}_{label}.text';subprocess.run(['objcopy','--dump-section',f'.text={obj}',str(exe)],check=True);rows.append(dict(label=label,compiler=cc,problem=problem,command=cmd,code_sha256=hashlib.sha256(code.encode()).hexdigest(),text_sha256=hashlib.sha256(obj.read_bytes()).hexdigest()))
for cc in ['gcc','clang']:
 for problem in ['jump','sum']:
  assert (D/f'{cc}_{problem}_base.text').read_bytes()==(D/f'{cc}_{problem}_helpers.text').read_bytes(),(cc,problem)
(D/'code_equivalence.json').write_text(json.dumps(rows,indent=2)+'\n');print('Old main/IO: GCC/Clang text code identical before/after helper addition')
