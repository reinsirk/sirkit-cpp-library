# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_415174_20261104');rows=[]
s=(R/'Graph/Heavy_Light_Decomposition.cpp').read_text();body='#define SKIP_RUNTIME_CHECKS\n'+s+'\n'+(D/'fenwick_frozen.cpp').read_text()+'\n'+(D/'io.hpp').read_text()+'\n'+(R/'Verify/current/drivers/hld_path_prod_main.cpp').read_text().replace('#include "Verify/current/common/fast_io.hpp"','');src=D/'helper_final.cpp';src.write_text(body)
for cc,prefix,baseline in [('gcc',['/usr/bin/g++'],'ordered'),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'],'selected')]:
 exe=D/f'{cc}_final';cmd=['taskset','-c','4',*prefix,'-std=c++23','-O2','-Wall','-Wextra','-Werror',str(src),'-o',str(exe)];subprocess.run(cmd,check=True)
 blobs=[]
 for label in ['final',baseline]:
  f=D/f'{cc}_{label}.text';subprocess.run(['objcopy','--dump-section',f'.text={f}',str(D/f'{cc}_{label}')],check=True);blobs.append(f.read_bytes())
 assert blobs[0]==blobs[1],cc
 rows.append(dict(compiler=cc,benchmark_label=baseline,command=cmd,source_sha256=hashlib.sha256(s.encode()).hexdigest(),text_sha256=hashlib.sha256(blobs[0]).hexdigest(),exact_text_match=True))
(D/'final_mapping.json').write_text(json.dumps(rows,indent=2)+'\n');print('Final helper code matches measured GCC ordered / Clang selected')
