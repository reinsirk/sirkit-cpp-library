# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,os
D=Path('/tmp/sirkit_hld_415174_20261104');rows=[]
for old in json.loads((D/'final_tests.json').read_text()):
 if old['ranges_first']:continue
 row=dict(old);cmd=list(old['compile_command']);cmd.insert(cmd.index('-std=c++23'),'-U__SIZEOF_INT128__');cmd[-1]+='_standard';subprocess.run(cmd,check=True);run=['taskset','-c','6',cmd[-1]];p=subprocess.run(run,text=True,capture_output=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'});assert p.returncode==0 and not p.stderr,p.stderr;row.update(compile_command=cmd,run_command=run,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr);rows.append(row);(D/'fallback_tests.json').write_text(json.dumps(rows,indent=2)+'\n');print(row['compiler'],row['skip_runtime_checks'],p.stdout.strip(),flush=True)
