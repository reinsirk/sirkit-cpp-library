// SPDX-License-Identifier: CC0-1.0
#include "Verify/current/common/fast_io.hpp"
#include <cstdint>
int main(){
 int n{},q{};verify_in>>n>>q;Graph graph(n);
 for(int i=1;i<n;++i){int u{},v{};verify_in>>u>>v;graph[u].push_back(v);graph[v].push_back(u);}
 HeavyLightDecomposition hld(graph);
 while(q--){int u{},v{};std::int64_t k{};verify_in>>u>>v>>k;verify_out<<hld.jump(u,v,k)<<'\n';}
}
