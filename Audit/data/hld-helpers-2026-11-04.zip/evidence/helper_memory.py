# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,os,json,hashlib
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_415174_20261104');rows=[]
for cc,args in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for skip in [False,True]:
  for kind in (['allocation','msan']if cc=='Clang'else['allocation']):
   test='new_graph_allocation_test'if kind=='allocation'else'hld_helpers_test';src=R/f'Verify/current/tests/{test}.cpp';exe=D/f'{cc}_{kind}_{int(skip)}';cmd=['taskset','-c','6',*args,'-std=c++23','-O1'if kind=='msan'else'-O2']
   if skip:cmd+=['-DSKIP_RUNTIME_CHECKS']
   if kind=='msan':cmd+=['-I'+str(R/'Verify/current/vendor'),'-fsanitize=memory','-fsanitize-memory-track-origins=2','-fno-omit-frame-pointer','-fPIE','-pie']
   cmd+=[str(src),'-o',str(exe)];subprocess.run(cmd,check=True);attempts=[]
   for attempt in range(8):
    run=['taskset','-c','6',str(exe)];p=subprocess.run(run,text=True,capture_output=True,env={**os.environ,'MSAN_OPTIONS':'halt_on_error=1'});attempts.append(dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
    if p.returncode==0:break
    assert kind=='msan'and('out of application range'in p.stderr or 'can not mmap the shadow memory'in p.stderr),p.stderr
   assert p.returncode==0 and not p.stderr,p.stderr
   rows.append(dict(compiler=cc,kind=kind,skip_runtime_checks=skip,compile_command=cmd,run_command=run,attempts=attempts,test_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),source_sha256=hashlib.sha256((R/'Graph/Heavy_Light_Decomposition.cpp').read_bytes()).hexdigest()));(D/'helper_memory.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,kind,skip,p.stdout.strip(),flush=True)
