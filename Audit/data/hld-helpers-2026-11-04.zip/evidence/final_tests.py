# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,subprocess,os
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_hld_415174_20261104');A=Path('/tmp/sirkit_hld_usability_review');rows=[]
for old in json.loads((A/'results.json').read_text()):
 cc=old['compiler'];skip=old['skip_runtime_checks'];order=old['ranges_first'];exe=D/f'final_{cc}_{int(skip)}_{int(order)}';cmd=list(old['compile_command']);cmd=[f'-DHLD_SOURCE="{R}/Graph/Heavy_Light_Decomposition.cpp"'if x.startswith('-DHLD_SOURCE=')else x for x in cmd];cmd[-1]=str(exe)
 p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr
 run=['taskset','-c','6',str(exe)];p=subprocess.run(run,text=True,capture_output=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'});row=dict(compiler=cc,skip_runtime_checks=skip,ranges_first=order,compile_command=cmd,run_command=run,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,source_sha256=hashlib.sha256((R/'Graph/Heavy_Light_Decomposition.cpp').read_bytes()).hexdigest(),test_sha256=hashlib.sha256((R/'Verify/current/tests/hld_helpers_test.cpp').read_bytes()).hexdigest());rows.append(row);(D/'final_tests.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,skip,order,p.returncode,p.stdout.strip(),flush=True);assert p.returncode==0 and not p.stderr,p.stderr
