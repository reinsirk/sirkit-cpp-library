// SPDX-License-Identifier: CC0-1.0
#include "Verify/current/common/fast_io.hpp"
#include <cstdint>
#include <vector>
int main(){
 int n{},q{};verify_in>>n>>q;std::vector<std::int64_t> value(n);for(auto& x:value)verify_in>>x;Graph graph(n);
 for(int i=1;i<n;++i){int u{},v{};verify_in>>u>>v;graph[u].push_back(v);graph[v].push_back(u);}
 HeavyLightDecomposition hld(graph);fenwick_tree<std::int64_t> bit(hld.reorder(value));
 while(q--){int type{};verify_in>>type;if(type==0){int v{};std::int64_t delta{};verify_in>>v>>delta;bit.add(hld.index(v),delta);}else{int u{},v{};verify_in>>u>>v;verify_out<<hld.path_prod(u,v,bit)<<'\n';}}
}
