// SPDX-License-Identifier: CC0-1.0
#include "Verify/current/common/fast_io.hpp"
#include <cstdint>
#include <utility>
#include <vector>
namespace {
constexpr std::uint64_t modulus=998244353;
struct Affine{std::uint32_t a,b;};
struct Product{Affine forward,backward;};
Affine append_affine(Affine first,Affine second){return {
 static_cast<std::uint32_t>(std::uint64_t(second.a)*first.a%modulus),
 static_cast<std::uint32_t>((std::uint64_t(second.a)*first.b+second.b)%modulus)};}
Product combine_product(Product a,Product b){return {append_affine(a.forward,b.forward),append_affine(b.backward,a.backward)};}
Product empty_product(){return {{1,0},{1,0}};}
Product reverse_product(Product x){std::swap(x.forward,x.backward);return x;}
}
int main(){
 int n{},q{};verify_in>>n>>q;std::vector<Product> value(n);for(auto& x:value){Affine f{};verify_in>>f.a>>f.b;x={f,f};}Graph graph(n);
 for(int i=1;i<n;++i){int u{},v{};verify_in>>u>>v;graph[u].push_back(v);graph[v].push_back(u);}
 HeavyLightDecomposition hld(graph);segtree<Product,combine_product,empty_product> seg(hld.reorder(value));
 while(q--){int type{};verify_in>>type;if(type==0){int p{};Affine f{};verify_in>>p>>f.a>>f.b;seg.set(hld.index(p),{f,f});}else{int u{},v{};std::uint32_t x{};verify_in>>u>>v>>x;const auto f=hld.path_prod(u,v,seg,reverse_product).forward;verify_out<<(std::uint64_t(f.a)*x+f.b)%modulus<<'\n';}}
}
