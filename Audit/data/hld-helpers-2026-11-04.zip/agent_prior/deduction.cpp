// SPDX-License-Identifier: CC0-1.0
#include "/home/reinsirk/Atcoder_Env/DataStructure/Segment_Tree.cpp"
#include "/home/reinsirk/Atcoder_Env/DataStructure/Lazy_Segment_Tree.cpp"
#include "/home/reinsirk/Atcoder_Env/DataStructure/Fenwick_Tree.cpp"
#include <atcoder/segtree.hpp>
#include <atcoder/lazysegtree.hpp>
#include <atcoder/fenwicktree.hpp>
#include <cassert>
#include <concepts>
#include <cstdint>
#include <functional>
#include <type_traits>
#include <utility>
#include <vector>

template<template<class,auto,auto> class Range,class S,auto Op,auto E>
    requires requires(const Range<S,Op,E>& range) { {range.prod(0,1)} -> std::same_as<S>; }
S inferred(const Range<S,Op,E>& range) {return std::invoke(Op,range.prod(0,1),std::invoke(E));}

template<template<class,auto,auto,class,auto,auto,auto> class Range,class S,auto Op,auto E,class F,auto Mapping,auto Composition,auto Id>
    requires requires(Range<S,Op,E,F,Mapping,Composition,Id>& range) { {range.prod(0,1)} -> std::same_as<S>; }
S inferred(Range<S,Op,E,F,Mapping,Composition,Id>& range) {return std::invoke(Op,range.prod(0,1),std::invoke(E));}

template<template<class> class Range,class T>
    requires requires(Range<T>& range) { {range.sum(0,1)} -> std::same_as<T>; }
T inferred(Range<T>& range) {return range.sum(0,1);}

template<class T> concept CanInfer = requires(T& value) { inferred(value); };
std::int64_t add(std::int64_t a,std::int64_t b){return a+b;}
std::int64_t zero(){return 0;}
struct Value{std::int64_t sum;int len;};
Value combine(Value a,Value b){return {a.sum+b.sum,a.len+b.len};}
Value empty(){return {0,0};}
Value mapping(std::int64_t f,Value x){return {x.sum+f*x.len,x.len};}
std::int64_t compose(std::int64_t f,std::int64_t g){return f+g;}
constexpr auto add_object=[](std::int64_t a,std::int64_t b){return a+b;};
constexpr auto zero_object=[](){return std::int64_t{0};};
using OwnSeg=segtree<std::int64_t,add,zero>;
using AclSeg=atcoder::segtree<std::int64_t,add,zero>;
using OwnLazy=lazy_segtree<Value,combine,empty,std::int64_t,mapping,compose,zero>;
using AclLazy=atcoder::lazy_segtree<Value,combine,empty,std::int64_t,mapping,compose,zero>;
static_assert(CanInfer<OwnSeg> && CanInfer<const OwnSeg> && CanInfer<AclSeg> && CanInfer<const AclSeg>);
static_assert(CanInfer<OwnLazy> && !CanInfer<const OwnLazy> && CanInfer<AclLazy> && !CanInfer<const AclLazy>);
static_assert(CanInfer<fenwick_tree<std::int64_t>> && !CanInfer<const fenwick_tree<std::int64_t>>);
static_assert(CanInfer<atcoder::fenwick_tree<std::int64_t>> && !CanInfer<const atcoder::fenwick_tree<std::int64_t>>);
static_assert(!CanInfer<std::vector<std::int64_t>>);
static_assert(std::is_same_v<decltype(inferred(std::declval<const OwnSeg&>())),std::int64_t>);
int main(){
    const OwnSeg own(std::vector<std::int64_t>{1,2});const AclSeg acl(std::vector<std::int64_t>{1,2});
    assert(inferred(own)==1&&inferred(acl)==1);
    const segtree<std::int64_t,add_object,zero_object> own_obj(std::vector<std::int64_t>{4,5});
    const atcoder::segtree<std::int64_t,add_object,zero_object> acl_obj(std::vector<std::int64_t>{4,5});
    assert(inferred(own_obj)==4&&inferred(acl_obj)==4);
    OwnLazy own_lazy(std::vector<Value>{{1,1},{2,1}});AclLazy acl_lazy(std::vector<Value>{{1,1},{2,1}});
    own_lazy.apply(0,2,3);acl_lazy.apply(0,2,3);assert(inferred(own_lazy).sum==4&&inferred(acl_lazy).sum==4);
    fenwick_tree<std::int64_t> own_bit(std::vector<std::int64_t>{1,2});atcoder::fenwick_tree<std::int64_t> acl_bit(2);acl_bit.add(0,1);acl_bit.add(1,2);
    assert(inferred(own_bit)==1&&inferred(acl_bit)==1);
}
