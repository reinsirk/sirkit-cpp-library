# 重軽分解

`HeavyLightDecomposition`は木の経路・部分木を配列区間へ変換します。値は自分で選んだBIT／Segtreeに保持します。集計器は呼出時に渡し、HLDはその参照を保持しません。[本体](../Graph/Heavy_Light_Decomposition.cpp)・[使用例](../Examples/heavy_light_decomposition_example.cpp)。

## API

| API | 引数・戻り値 |
| --- | --- |
| `HeavyLightDecomposition(g,root=0)` / `build(g,root=0)` | 対称な隣接リストの無向森を構築／再構築。頂点は0..N-1。 |
| `reorder(values)` / `restore(ordered)` | 長さNのvectorをDFS添字順／元の頂点順にコピーする。要素はコピー可能、既定構築は不要。 |
| `index(v)` / `vertex_at(i)` / `order()` | 頂点→添字／添字→頂点／並びのconst参照。 |
| `path_prod(u,v,bit,edges=false)` | BITの経路和。T{}が単位元で、整数は型幅で周回する。bitは非const。 |
| `path_prod(u,v,seg,edges=false)` | ACL形式のsegtree／lazy_segtreeからop/eを推論した**可換**な経路積。Segtreeはconst可、Lazyは非const。 |
| `path_prod(u,v,identity,query,op,edges=false)` | 任意の集計器で経路積。queryはprod/sumを持つオブジェクト、または区間を受けて値を返す関数。結果型はqueryから決まる。 |
| `path_prod(u,v,seg,reverse,edges=false)` / 汎用版のop直後にreverse | 非可換な積用。reverseは集計値を逆順の集計値に変換する関数。 |
| `subtree_prod(v,query,edges=false)` | 部分木のDFS添字昇順の積。非可換も可。 |
| `path_apply(u,v,range,f,edges=false)` / `subtree_apply(v,range,f,edges=false)` | 作用fを値で受け取り、各区間へ`range.apply(l,r,f)`で適用する。 |
| `for_each_path(u,v,fn,edges=false)` / `path(u,v,edges=false)` | 通行順にfn(l,r,reversed)を呼ぶ／同じInterval配列を返す。別の木はfalse／空。 |
| `subtree_range(v,edges=false)` / `subtree_size(v)` | 部分木の半開区間／頂点数。 |
| `lca(u,v)` / `distance(u,v)` | 最近共通祖先／辺数距離。別の木なら-1。 |
| `kth_ancestor(v,k)` / `jump(u,v,k)` | k個上／u→vの0始まりk番目。範囲外・別の木は-1。 |
| `parent(v)` / `depth(v)` / `component(v)` / `root_of(v)` | 親（根は-1）／深さ／木の番号／木の根。 |
| `same_component(u,v)` / `is_ancestor(u,v)` | 同じ木か／祖先か（自身を含む）。 |
| `size()` / `empty()` / `root()` / `component_count()` / `clear()` / `swap(other)` | 頂点数／空か／指定根（空なら-1）／木の数／空に戻す／交換。 |

```cpp
Graph tree{{1}, {0,2}, {1}};
HeavyLightDecomposition hld(tree);
std::vector<std::int64_t> value{10,20,30};
fenwick_tree<std::int64_t> bit(hld.reorder(value));
bit.add(hld.index(1), 5);
auto sum = hld.path_prod(0,2,bit);     // 65。
auto subtree = hld.subtree_prod(1,bit); // 55。
```

## 演算・向き・辺

集計器には`reorder`した並びを渡します。演算opは結合則を満たし、identityはその単位元とします。自動推論と2引数query(l,r)は可換専用です。型から可換性は判定できません。

非可換ではquery(l,r,reversed)で逆順用の木を選ぶか、正しいreverseを指定します。単一の通常の集計値から逆順積を復元できるとは限りません。reverse指定と3引数queryは併用しません（単なるstd::identityは除く）。完全例には順方向／逆方向のSegtreeを組み合わせた文字列の経路積があります。

区間は[l,r)です。reversed=trueならr-1からlへ読みます。辺を扱う場合は親辺の値を子の位置に格納し、edges=trueにします。経路ではLCA、部分木では指定した根の位置を除きます。

## 前提と計算量

`path_prod`／`path_apply`の両端は同じ木に属することが前提です。検査時は別の木をinvalid_argumentにします。集計器が対応する並び・長さを持つことは利用側の責任です。途中で作用や集計器が例外を出した場合、外部の集計器の変更は巻き戻しません。

構築・並べ替えはO(N+M)／O(N)、経路の分解と照会回数はO(log N)、部分木は照会1回です。通常のBIT／Segtreeとの経路操作はO(log²N)、部分木操作はO(log N)。祖先・LCA・距離・jumpはO(log N)、その他の取得はO(1)です。for_each_path／path_prodはHLD側のヒープ確保をせず、pathはO(log N)領域を使います。

指定根の木から、残りは最小未訪問頂点から構築します。空の入力にはroot=0。探索中に頂点範囲・自己辺・閉路・多重辺を検査しますが、対称性の確認だけの全辺走査はしません。`SKIP_RUNTIME_CHECKS`で入力検査と検査専用状態を除きます。

構築失敗時は旧状態を保持。コピーは独立所有、move元は空です。order参照は再構築・代入・破棄で無効になります。木の形を変える場合は再構築し、集計器も新しい添字順で用意します。

[理論参考](https://info.atcoder.jp/entry/algorithm_lectures/heavy_light_decomposition)・[基本API参照試験](../Verify/current/tests/new_hld_reference_test.cpp)・[集計補助の参照試験](../Verify/current/tests/hld_helpers_test.cpp)・[Jump on Tree](https://judge.yosupo.jp/problem/jump_on_tree)
