# SPDX-License-Identifier: CC0-1.0
"""HLD用入力の再現器。外部生成器はofficial/へ分け、実装本体には使わない。"""
from pathlib import Path
import argparse, hashlib, json, random, resource, subprocess, tomllib, urllib.request
# 公式生成器の再帰DFS用。ライブラリの試験・性能計測のstack設定は変更しない。
resource.setrlimit(resource.RLIMIT_STACK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
D=Path(__file__).resolve().parent
REV=json.loads((D/'official_revision.json').read_text())['sha']
BASE=f'https://raw.githubusercontent.com/yosupo06/library-checker-problems/{REV}/'
O=D/'official'; INPUT=D/'inputs'; BIN=D/'generators';INPUT.mkdir(exist_ok=True);BIN.mkdir(exist_ok=True)
parser=argparse.ArgumentParser();parser.add_argument('--download',action='store_true');args=parser.parse_args()
def fetch(path):
 target=O/path
 if args.download or not target.exists():
  target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(urllib.request.urlopen(BASE+path,timeout=30).read())
 return target
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source_paths=['LICENSE','common/random.h'];specs={}
for problem in ['jump_on_tree','vertex_add_path_sum']:
 path=f'tree/{problem}/info.toml';fetch(path);source_paths.append(path);spec=tomllib.loads((O/path).read_text());specs[problem]=spec
 for item in spec['tests']:
  path=f'tree/{problem}/gen/'+(item['name']if item['name'].endswith('.cpp')else'example_00.in');fetch(path);source_paths.append(path)
for path in ['LICENSE','common/random.h']:fetch(path)
metadata={'repository':'https://github.com/yosupo06/library-checker-problems','revision':REV,'license':'Apache-2.0','generator_stack_limit':'unlimited for official recursive generation only','usage':'外部生成器は性能・正しさ試験の入力作成だけに使用。ライブラリ実装への取り込みなし。','files':[dict(path=p,url=BASE+p,sha256=sha(O/p))for p in source_paths]}
(D/'official_sources.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
rows=[];commands=[]
def register(name,path,problem,origin,**extra):
 row=dict(name=name,path=str(path),problem=problem,origin=origin,header=path.open().readline().strip(),bytes=path.stat().st_size,sha256=sha(path),**extra);rows.append(row);(D/'fixtures.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(name,row['header'],row['bytes'],flush=True)
for problem,spec in specs.items():
 root=O/f'tree/{problem}';(root/'params.h').write_text(''.join(f'constexpr int {k} = {v};\n'for k,v in spec['params'].items()))
 for item in spec['tests']:
  source=root/'gen'/item['name']
  if item['name'].endswith('.cpp'):
   exe=BIN/f'{problem}_{source.stem}';cmd=['taskset','-c','4','g++','-std=c++23','-O2','-I',str(O/'common'),str(source),'-o',str(exe)];subprocess.run(cmd,check=True);commands.append(cmd)
   for seed in range(item['number']):
    name=f'official_{problem}_{source.stem}_{seed}';path=INPUT/f'{name}.in'
    with path.open('wb')as out:subprocess.run(['taskset','-c','4',str(exe),str(seed)],stdout=out,check=True)
    register(name,path,problem,'official_generator',source=BASE+source.relative_to(O).as_posix(),seed=seed)
  else:
   name=f'official_{problem}_example_0';path=INPUT/f'{name}.in';path.write_bytes((root/'gen/example_00.in').read_bytes());register(name,path,problem,'official_example',source=BASE+f'tree/{problem}/gen/example_00.in')
(D/'generator_commands.json').write_text(json.dumps(commands,indent=2)+'\n')
for n in [32,4096,250000]:
 q=n
 for kind in ['chain','star','balanced','random']:
  seed=20261104+n*11+['chain','star','balanced','random'].index(kind);rng=random.Random(seed)
  parent=[-1]+[v-1 if kind=='chain'else 0 if kind=='star'else(v-1)//2 if kind=='balanced'else rng.randrange(v)for v in range(1,n)];depth=[0]*n
  for v in range(1,n):depth[v]=depth[parent[v]]+1
  perm=list(range(n));rng.shuffle(perm);edges=[(perm[v],perm[parent[v]])for v in range(1,n)];rng.shuffle(edges);edges=[(v,u)if rng.randrange(2)else(u,v)for u,v in edges]
  def distance(u,v):
   if kind=='chain':return abs(u-v)
   total=0
   while depth[u]>depth[v]:u=parent[u];total+=1
   while depth[v]>depth[u]:v=parent[v];total+=1
   while u!=v:u=parent[u];v=parent[v];total+=2
   return total
  name=f'custom_jump_on_tree_{n}_{kind}';path=INPUT/f'{name}.in'
  with path.open('w')as out:
   out.write(f'{n} {q}\n');out.writelines(f'{u} {v}\n'for u,v in edges)
   for i in range(q):
    u=rng.randrange(n);v=rng.randrange(n);mode=i%8
    if mode in [4,5]:v=u
    d=distance(u,v);k=[0,d,min(n-1,d+1),rng.randrange(n),0,1,rng.randrange(d+1),n-1][mode]
    out.write(f'{perm[u]} {perm[v]} {k}\n')
  register(name,path,'jump_on_tree','independent_custom',seed=seed,n=n,q=q,shape=kind,labels='arbitrarily permuted',k_range='0..n-1; valid and beyond-path queries')
  name=f'custom_vertex_add_path_sum_{n}_{kind}';path=INPUT/f'{name}.in'
  with path.open('w')as out:
   out.write(f'{n} {q}\n');out.write(' '.join(str(rng.randrange(1000000001))for _ in range(n))+'\n');out.writelines(f'{u} {v}\n'for u,v in edges)
   for i in range(q):
    if i%2==0:out.write(f'0 {rng.randrange(n)} {rng.randrange(1000000001)}\n')
    else:
     u=rng.randrange(n);v=u if i%8==1 else rng.randrange(n);out.write(f'1 {u} {v}\n')
  register(name,path,'vertex_add_path_sum','independent_custom',seed=seed,n=n,q=q,shape=kind,labels='same arbitrary permutation as paired jump fixture',operations='50% additions, 50% path sums incl single vertex')
# Public API-only supplement, not claimed as official online input constraints.
api={'scope':'HLD public API boundary supplement; not online input','n':6,'edges':[[4,1],[1,5],[0,3]],'roots':[0,1,4,5],'queries':[]}
g=[[]for _ in range(6)]
for u,v in api['edges']:g[u].append(v);g[v].append(u)
for u in range(6):
 for v in range(6):
  pred={u:None};todo=[u]
  for x in todo:
   for y in g[x]:
    if y not in pred:pred[y]=x;todo.append(y)
  path=[]
  if v in pred:
   x=v
   while x is not None:path.append(x);x=pred[x]
   path.reverse()
  for k in [-9223372036854775808,-1,0,1,2,3,6,9223372036854775807]:api['queries'].append(dict(u=u,v=v,k=k,expected=path[k]if 0<=k<len(path)else-1))
(D/'custom_api_cases.json').write_text(json.dumps(api,indent=2)+'\n')
print(f'Fixture preparation complete: {len(rows)} fixtures, {len(api["queries"])} API boundary queries',flush=True)
