from pathlib import Path
import sys,subprocess,json,random,statistics,shutil,os,time,hashlib
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_segtree_fourth_20261102');P=Path('/tmp/sirkit_segtree_speed_20261102');O=Path('/tmp/sirkit_segtree_followup_20261102');s=(D/'before.hpp').read_text()
old='''            const S left = (p & 1) ? sibling : value;
            const S right = (p & 1) ? value : sibling;
            value = std::invoke(op, left, right);'''
assert old in s
variants={'old':s,
'conditional':s.replace(old,'''            value = (p & 1) ? std::invoke(op, sibling, value) : std::invoke(op, value, sibling);'''),
'next':s.replace(old,'''            const S next = (p & 1) ? std::invoke(op, sibling, value) : std::invoke(op, value, sibling);
            value = next;'''),
'swap':s.replace(old,'''            S left = std::as_const(value), right = sibling;
            if (p & 1) std::swap(left, right);
            value = std::invoke(op, std::as_const(left), std::as_const(right));'''),
'indexed':s.replace(old,'''            const S children[2] = {value, sibling};
            const auto side = p & 1;
            value = std::invoke(op, children[side], children[side ^ 1]);''')}
entries=[e for e in prepare_verify.collect() if e['id'] in ['segment_tree','segment_tree_composite']]
for label,source in variants.items():
 (D/f'{label}.hpp').write_text(source)
 for e in entries:
  data,_=prepare_verify.render(e,source_overrides={'DataStructure/Segment_Tree.cpp':source.encode()});src=D/f'{e["id"]}_{label}.cpp';src.write_bytes(data)
  for cc,cmd in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
   subprocess.run(['taskset','-c','2',*cmd,'-std=c++23','-O2',str(src),'-o',str(D/f'{cc}_{e["id"]}_{label}')],check=True)
print('BUILT',flush=True);cases=[]
for family,seed in [('random',3),('max_random',0),('max_random',1)]:cases.append({'kind':'affine','name':f'official_affine_{family}_{seed}','path':str(O/f'official_affine_{family}_{seed}.in')})
for kind in ['sum','affine']:
 for n in [32,500000]:
  for mode in ['mixed','query','update','short']:cases.append({'kind':kind,'name':f'{kind}_{n}_{mode}','path':str(P/f'{kind}_{n}_{mode}.in')})
rng=random.Random(93720);rs=[]
for cc in ['gcc','clang']:
 for c in cases:
  for rep in range(7):
   labels=list(variants)+['control'];rng.shuffle(labels);checks=[]
   for label in labels:
    id='segment_tree' if c['kind']=='sum' else 'segment_tree_composite';exe=D/f'{cc}_{id}_{"old" if label=="control" else label}';shutil.copyfile(exe,D/'active');(D/'active').chmod(0o700)
    with open(c['path'],'rb') as inp,open(D/'output','wb') as out:
     t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-t
    ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rs.append({'compiler':cc,'case':c['name'],'label':label,'rep':rep,'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
   assert len(set(checks))==1
  ms={l:statistics.median(x['cpu_ns'] for x in rs if x['compiler']==cc and x['case']==c['name'] and x['label']==l) for l in labels}
  print(cc,c['name'],{l:round(v/ms['old'],3) for l,v in ms.items()},flush=True);(D/'screen_raw.json').write_text(json.dumps(rs))
