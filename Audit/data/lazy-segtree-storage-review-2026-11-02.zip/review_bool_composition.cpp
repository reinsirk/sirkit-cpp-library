// SPDX-License-Identifier: CC0-1.0
#include SOURCE
int op(const int&a,const int&b){return a+b;}
int e(){return 0;}
int mapping(const bool&f,const int&v,std::size_t n){return f?static_cast<int>(n):v;}
struct Composition {
 bool operator()(const bool&a,const bool&b)const{return a||b;}
 bool operator()(const bool&,bool&)const=delete;
};
bool id(){return false;}
static_assert(std::is_invocable_r_v<bool,Composition,const bool&,const bool&>);
int main(){lazy_segtree<int,op,e,bool,mapping,Composition{},id> t(8);t.apply(0,4,true);t.apply(0,8,true);return t.get(0)!=1;}
