from pathlib import Path
import sys,subprocess,json,random,statistics,shutil,os,time,hashlib
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_lazy_followup_20261102');P=Path('/tmp/sirkit_lazy_speed_20261102');s=(D/'before.hpp').read_text();variants={'old':s}
for bits in [8,32,64]:
 U=f'std::uint{bits}_t';t=s.replace('std::vector<std::uint8_t> pending_;',f'std::vector<{U}> pending_;');oldlimit='''        const auto limit = std::min({std::vector<S>{}.max_size() / 2,
                                     std::vector<F>{}.max_size(), std::vector<std::uint8_t>{}.max_size()});'''
 newlimit=f'''        const auto word_limit = std::vector<{U}>{{}}.max_size();
        const auto flag_limit = word_limit > std::numeric_limits<std::size_t>::max() / {bits}
                              ? std::numeric_limits<std::size_t>::max() : word_limit * {bits};
        const auto limit = std::min({{std::vector<S>{{}}.max_size() / 2,
                                     std::vector<F>{{}}.max_size(), flag_limit}});''';assert oldlimit in t;t=t.replace(oldlimit,newlimit)
 t=t.replace('pending_(n_ ? base_ : 0, 0)',f'pending_(n_ ? base_ / {bits} + (base_ % {bits} != 0) : 0, 0)')
 t=t.replace('if (pending_[p])',f'if (pending_[p / {bits}] & ({U}{{1}} << (p % {bits})))').replace('if (!pending_[p])',f'if (!(pending_[p / {bits}] & ({U}{{1}} << (p % {bits}))))')
 t=t.replace('pending_[p] = 1;',f'pending_[p / {bits}] |= {U}{{1}} << (p % {bits});').replace('pending_[p] = 0;',f'pending_[p / {bits}] &= ~({U}{{1}} << (p % {bits}));')
 variants[f'bits{bits}']=t
variants['vector_bool']=s.replace('std::vector<std::uint8_t>','std::vector<bool>')
t=s.replace('    S value_identity_;','''    struct PendingUpdate {
        F value;
        bool pending;
        explicit PendingUpdate(const F& f) : value(f), pending(false) {}
    };
    S value_identity_;''').replace('    std::vector<F> lazy_;\n    std::vector<std::uint8_t> pending_;','    std::vector<PendingUpdate> tags_;')
t=t.replace('std::vector<F>{}.max_size(), std::vector<std::uint8_t>{}.max_size()','std::vector<PendingUpdate>{}.max_size()')
t=t.replace('lazy_[p]','tags_[p].value').replace('pending_[p]','tags_[p].pending')
t=t.replace('lazy_(n_ ? base_ : 0, update_identity_), pending_(n_ ? base_ : 0, 0)','tags_(n_ ? base_ : 0, PendingUpdate(update_identity_))')
t=t.replace('lazy_(std::move(other.lazy_)), pending_(std::move(other.pending_))','tags_(std::move(other.tags_))')
t=t.replace('std::fill(lazy_.begin(), lazy_.end(), update_identity_);','std::fill(tags_.begin(), tags_.end(), PendingUpdate(update_identity_));').replace('        std::fill(pending_.begin(), pending_.end(), 0);\n','')
t=t.replace('lazy_.clear(); pending_.clear();','tags_.clear();').replace('lazy_.swap(other.lazy_); pending_.swap(other.pending_);','tags_.swap(other.tags_);')
assert 'pending_' not in t and 'lazy_[' not in t and 'lazy_(' not in t;variants['tag_node']=t
e=next(e for e in prepare_verify.collect() if e['id']=='lazy_segment_tree')
for label,source in variants.items():
 (D/f'{label}.hpp').write_text(source);data,_=prepare_verify.render(e,source_overrides={'DataStructure/Lazy_Segment_Tree.cpp':source.encode()});src=D/f'{label}.cpp';src.write_bytes(data);subprocess.run(['taskset','-c','2','/usr/bin/g++','-std=c++23','-O2',str(src),'-o',str(D/f'gcc_{label}')],check=True)
cases=[]
for family,seed in [('random',0),('random',2),('max_random',0),('max_random',1)]:cases.append({'name':f'official_{family}_{seed}','path':str(P/f'official_{family}_{seed}.in')})
for n in [32,500000]:
 for mode in ['mixed','query','update','short']:cases.append({'name':f'{n}_{mode}','path':str(P/f'input_{n}_{mode}.in')})
print('BUILT',flush=True);rs=[];rng=random.Random(20479)
for c in cases:
 for rep in range(5):
  labels=list(variants)+['control'];rng.shuffle(labels);checks=[]
  for label in labels:
   shutil.copyfile(D/f'gcc_{"old" if label=="control" else label}',D/'active');(D/'active').chmod(0o700)
   with open(c['path'],'rb') as inp,open(D/'output','wb') as out:
    t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-t
   ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rs.append({'case':c['name'],'rep':rep,'label':label,'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
  assert len(set(checks))==1
 ms={l:statistics.median(x['cpu_ns'] for x in rs if x['case']==c['name'] and x['label']==l) for l in labels};print(c['name'],{l:round(v/ms['old'],3) for l,v in ms.items()},flush=True);(D/'screen_raw.json').write_text(json.dumps(rs))
