from pathlib import Path
import sys,subprocess,json,random,statistics,shutil,os,time,hashlib
sys.path.insert(0,'Scripts');import prepare_verify
D=Path('/tmp/sirkit_lazy_followup_20261102');P=Path('/tmp/sirkit_lazy_speed_20261102');s=(D/'before.hpp').read_text();attr='''#if defined(__GNUC__) || defined(__clang__)
    [[gnu::noinline]]
#endif
''';a=s.index('    void push(std::size_t p, std::size_t length)');b=s.index('    void push_path(',a);oldpush=s[a:b];assert '        if (!pending_[p]) return;' in oldpush
active=oldpush.replace('    void push(',attr+'    void push_active(').replace('        if (!pending_[p]) return;\n','')+'''    void push(std::size_t p, std::size_t length) {
        if (pending_[p]) push_active(p, length);
    }
'''
variants={'old':s,'outline_active':s[:a]+active+s[b:],'outline_act':s.replace('    void act(std::size_t p',attr+'    void act(std::size_t p')}
ca=s.index('    void act(');cb=s.index('    void push_path(',ca)
special='''    void map_value(std::size_t p, const F& f, std::size_t length) {
        if constexpr (std::is_invocable_r_v<S, decltype(mapping), const F&, const S&>)
            data_[p] = std::invoke(mapping, f, data_[p]);
        else data_[p] = std::invoke(mapping, f, data_[p], length);
    }
    void store_update(std::size_t p, const F& f) {
        if (pending_[p]) lazy_[p] = std::invoke(composition, f, lazy_[p]);
        else { lazy_[p] = f; pending_[p] = 1; }
    }
    void act(std::size_t p, const F& f, std::size_t length) {
        map_value(p, f, length);
        if (p < base_) store_update(p, f);
    }
    void push(std::size_t p, std::size_t length) {
        if (!pending_[p]) return;
        const auto child = 2 * p;
        map_value(child, lazy_[p], length / 2);
        if (p < base_ / 2) {
            store_update(child, lazy_[p]);
            map_value(child + 1, lazy_[p], length / 2);
            store_update(child + 1, lazy_[p]);
        } else map_value(child + 1, lazy_[p], length / 2);
        pending_[p] = 0;
    }
'''
variants['special']=s[:ca]+special+s[cb:];oa=special.index('    void push(');op=special[oa:];spact=op.replace('    void push(',attr+'    void push_active(').replace('        if (!pending_[p]) return;\n','')+'''    void push(std::size_t p, std::size_t length) {
        if (pending_[p]) push_active(p, length);
    }
''';variants['special_outline']=s[:ca]+special[:oa]+spact+s[cb:]
e=next(e for e in prepare_verify.collect() if e['id']=='lazy_segment_tree')
for label,source in variants.items():
 (D/f'{label}.hpp').write_text(source);data,_=prepare_verify.render(e,source_overrides={'DataStructure/Lazy_Segment_Tree.cpp':source.encode()});src=D/f'{label}.cpp';src.write_bytes(data)
 for cc,cmd0 in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:subprocess.run(['taskset','-c','2',*cmd0,'-std=c++23','-O2',str(src),'-o',str(D/f'{cc}_{label}')],check=True)
cases=[]
for family in ['random','max_random']:
 for seed in range(3):cases.append({'name':f'official_{family}_{seed}','path':str(P/f'official_{family}_{seed}.in')})
for n in [32,4096,500000]:
 for mode in ['mixed','query','update','short']:cases.append({'name':f'{n}_{mode}','path':str(P/f'input_{n}_{mode}.in')})
print('BUILT',flush=True);rs=[];rng=random.Random(590122)
for cc in ['gcc','clang']:
 for c in cases:
  for rep in range(7):
   labels=list(variants)+['control'];rng.shuffle(labels);checks=[]
   for label in labels:
    shutil.copyfile(D/f'{cc}_{"old" if label=="control" else label}',D/'active_push');(D/'active_push').chmod(0o700)
    with open(c['path'],'rb') as inp,open(D/'output','wb') as out:
     t=time.perf_counter_ns();p=subprocess.Popen(['taskset','-c','12',str(D/'active_push')],stdin=inp,stdout=out);_,st,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st);assert p.returncode==0;wall=time.perf_counter_ns()-t
    ck=hashlib.sha256((D/'output').read_bytes()).hexdigest();checks.append(ck);rs.append({'compiler':cc,'case':c['name'],'rep':rep,'label':label,'cpu_ns':round((ru.ru_utime+ru.ru_stime)*1e9),'wall_ns':wall,'sha256':ck})
   assert len(set(checks))==1
  ms={l:statistics.median(x['cpu_ns'] for x in rs if x['compiler']==cc and x['case']==c['name'] and x['label']==l) for l in labels};print(cc,c['name'],{l:round(v/ms['old'],3) for l,v in ms.items()},flush=True);(D/'push_raw.json').write_text(json.dumps(rs))
