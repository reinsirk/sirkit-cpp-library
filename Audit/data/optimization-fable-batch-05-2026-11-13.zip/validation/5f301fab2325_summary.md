# 重み付きrollback persistent main：分岐順を保つ別案を採用推奨

本体・I/O・設定固定、全重み0のconnectivity mainのみ。葉uniteを省き、get_stateとexit/rollbackを非葉uniteだけへ移す。元mainと同じunion-firstの分岐順を保つ。repo未適用。

| compiler | input | 初回比 | 確認比 |
| --- | --- | ---: | ---: |
| gcc | random | 0.9437 | 0.9402 |
| gcc | degenerate | 0.9695 | 0.9756 |
| gcc | line | 0.9916 | 0.9778 |
| gcc | star | 0.9018 | 0.9090 |
| gcc | query_parent_deep | 0.9200 | 0.9137 |
| gcc | root_only_unites | 0.8808 | 0.8354 |
| gcc | root_only_queries | 0.9206 | 0.9344 |
| clang | random | 0.9494 | 0.9610 |
| clang | degenerate | 0.9963 | 0.9788 |
| clang | line | 0.9954 | 0.9997 |
| clang | star | 0.9217 | 0.9401 |
| clang | query_parent_deep | 0.9280 | 0.9463 |
| clang | root_only_unites | 0.8403 | 0.8546 |
| clang | root_only_queries | 0.9577 | 0.9847 |

比は選択案/現行。CPU12、GCC15.2/Clang21、CLI O2と現行GCC O3 pragma。同IOで初回2warm+9交互、確認は逆順2warm+15交互。query_parent_deepは通常契約より強いローカル補足。

初案query-firstはGCC lineで約0.6〜1.5%悪化したため未選択。分岐順を戻した別案はGCC lineも両回で短縮し、Clangでは初案/別案の.textが同一。

初案baseline/candidate8構成、選択案4構成、履歴API probe4構成すべてPASS。各main構成で295小入力と8 workloadを確認。query親・自己/重複union・深鎖/分岐/root-onlyを独立Python永続ラベルモデルへ照合した。probeはunite(false)の1履歴とquery状態不変・保存位置への復帰を各73検査で確認。

採用用selected_main.cpp / selected.patch、証明correctness_notes.md、全rawと再現scriptを同ディレクトリに保存。
