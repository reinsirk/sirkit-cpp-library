from pathlib import Path
import hashlib,json,os,subprocess
W=Path('/tmp/sirkit_fastest_review_20261113/fraction_cmp_candidate');os.sched_setaffinity(0,{10});sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();meta=json.loads((W/'sources.json').read_text());inputs=json.loads((W/'inputs.json').read_text());(W/'bin').mkdir(exist_ok=True);report={'status':'running','cpu':10,'builds':[],'checks':[],'compiler_versions':{n:subprocess.check_output([p,'--version'],text=True).splitlines()[0]for n,p in [('GCC','/usr/bin/g++'),('Clang','/usr/bin/clang++')]}}
for compiler,prefix in [('GCC',['/usr/bin/g++']),('Clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 for fallback in [False,True]:
  for info in meta['programs']:
   tag=f'{compiler}_{info["name"]}_{"skip"if info["skip"]else"checked"}_{"standard"if fallback else"native"}'
   for batch in [False,True]:
    src=Path(info['batch_source']if batch else info['source']);assert sha(src)==(info['batch_source_sha256']if batch else info['source_sha256']);exe=W/'bin'/(tag+('_batch'if batch else''));cmd=[*prefix,'-std=c++23','-O2','-Wall','-Wextra']
    if fallback:cmd+=['-U__SIZEOF_INT128__','-DSIRKIT_FRACTION_DISABLE_INT128','-DSIRKIT_DISABLE_SIMD','-DSIRKIT_FORCE_STANDARD_ARITHMETIC']
    cmd += [str(src),'-o',str(exe)];r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);assert r.returncode==0,r.stderr;report['builds'].append({'compiler':compiler,'variant':info['name'],'skip':info['skip'],'standard_fallback':fallback,'batch_correctness_only':batch,'command':cmd,'source_sha256':sha(src),'binary_sha256':sha(exe),'diagnostics':r.stderr})
    for case in ([inputs['small']]if batch else inputs['large']):
     path=Path(case['input']);expected=Path(case['expected']).read_bytes();assert sha(path)==case['input_sha256']and hashlib.sha256(expected).hexdigest()==case['expected_sha256']
     with path.open('rb')as f:r=subprocess.run([str(exe)],stdin=f,capture_output=True,timeout=90)
     passed=r.returncode==0 and r.stdout==expected;row={'compiler':compiler,'variant':info['name'],'skip':info['skip'],'standard_fallback':fallback,'batch_correctness_only':batch,'input':str(path),'expected_sha256':case['expected_sha256'],'output_sha256':hashlib.sha256(r.stdout).hexdigest(),'returncode':r.returncode,'stderr':r.stderr.decode(errors='replace'),'passed':passed};report['checks'].append(row);assert passed,row
    (W/'test_results.json').write_text(json.dumps(report,indent=2)+'\n');print(tag,'batch'if batch else'full','PASS',flush=True)
report['status']='passed';(W/'test_results.json').write_text(json.dumps(report,indent=2)+'\n');print('FINAL PASS',len(report['builds']),'builds',len(report['checks']),'dataset comparisons',flush=True)
