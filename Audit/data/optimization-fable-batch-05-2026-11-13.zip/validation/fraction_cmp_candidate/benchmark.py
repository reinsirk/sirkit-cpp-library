from pathlib import Path
import hashlib,json,os,statistics,subprocess,time
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/fraction_cmp_candidate');os.sched_setaffinity(0,{10});sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();meta=json.loads((W/'sources.json').read_text());test=json.loads((W/'test_results.json').read_text());assert test['status']=='passed';cases=[x for x in json.loads((W/'inputs.json').read_text())['large']if x['measure']];report={'status':'running','cpu':10,'scope':'main-only full-program comparator effect; body/common I/O/flags fixed within each pair','method':'Exact independently validated binaries; default-target GCC15.2/Clang21 C++23 O2, checked/skip and standard fallback; 2 warmup+9 measured reverse-interleaved; output DEVNULL in timings, exact bytes independently prechecked','source_metadata':meta,'results':[]}
for compiler in ['GCC','Clang']:
 for skip in [False,True]:
  for fallback in [False,True]:
   binaries={n:W/'bin'/f'{compiler}_{n}_{"skip"if skip else"checked"}_{"standard"if fallback else"native"}'for n in ['baseline','candidate']};builds={}
   for n,p in binaries.items():
    row=next(b for b in test['builds']if b['compiler']==compiler and b['variant']==n and b['skip']==skip and b['standard_fallback']==fallback and not b['batch_correctness_only']);assert sha(p)==row['binary_sha256'];builds[n]=row
   for case in cases:
    path=Path(case['input']);assert sha(path)==case['input_sha256'];samples={n:[]for n in binaries}
    for iteration in range(11):
     for n in (['baseline','candidate']if iteration%2==0 else['candidate','baseline']):
      with path.open('rb')as f:
       t=time.perf_counter_ns();subprocess.run([str(binaries[n])],stdin=f,stdout=subprocess.DEVNULL,check=True);elapsed=(time.perf_counter_ns()-t)/1e6
      if iteration>=2:samples[n].append(elapsed)
    med={n:statistics.median(v)for n,v in samples.items()};pairs=[c/b for c,b in zip(samples['candidate'],samples['baseline'])];row={'compiler':compiler,'skip':skip,'standard_fallback':fallback,'input':case,'builds':builds,'samples_ms':samples,'median_ms':med,'ratio':med['candidate']/med['baseline'],'paired_median_ratio':statistics.median(pairs),'wins_out_of_9':sum(x<1 for x in pairs),'warmup':2,'measured':9,'all_outputs_prechecked':True};report['results'].append(row);(W/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(compiler,'skip'if skip else'checked','standard'if fallback else'default',case['name'],round(row['ratio'],3),med,'wins',row['wins_out_of_9'],flush=True)
report['root_unchanged']={'body':sha(R/'Math/Fraction.cpp')==meta['body_sha256'],'main':sha(R/meta['entry']['driver'])==meta['main_sha256']['baseline'],'io':sha(R/'Verify/current/common/fast_io.hpp')==meta['io_sha256']};assert all(report['root_unchanged'].values());report['status']='passed';(W/'results.json').write_text(json.dumps(report,indent=2)+'\n');print('FINAL PASS',len(report['results']),'compiler/mode/case comparisons',flush=True)
