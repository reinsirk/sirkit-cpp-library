# fraction_sort比較器の単一<=>案

結論: reject、現行mainを維持。repo/core/IO/flagsの変更なし、Fable呼出しなし。
候補はcandidate_main.cpp、差分main.diff、統合結果review.json。

変更は、Fractionの==→>という分岐から、<=>1回の結果に基づく分岐への置換だけ。
bodyと入出力を固定し、元の構築・gcd・sort・番号出力を保った。
Fractionは正規化済みなので、大小比較の等価と==が一致し、同率なら元の番号順となる。

## 条件と正しさ

[公式問題](https://atcoder.jp/contests/abc308/tasks/abc308_c)のN=2..200000、a,b=0..1e9、a+b>=1を保持。
Python fractions.Fraction(a,a+b)の負値と1-based indexをkeyに独立sortする。
浮動小数点・C++ Fraction比較の流用は行わない。

11371小ケース: 0..3の係数組（0,0除外）の列挙、最大係数の組合せ列挙、
random/同値倍率違い/a0/b0/同率番号順を含む。
20万件のrandom、全同値、倍率の異なる同率、複数既約比の重複、a0のみ、b0のみ、最大係数を含む7入力も用意。
GCC15.2/Clang21×checked/skip×通常/標準fallback×baseline/candidateの16構成ですべてbyte一致した。
通常mainと検査専用batch wrapperを計32ビルド、128 datasetを照合。
wrapperは正しさ確認だけ。計時は元の1ケースmainを使用する。

標準fallbackは `-U__SIZEOF_INT128__ -DSIRKIT_FRACTION_DISABLE_INT128 -DSIRKIT_DISABLE_SIMD -DSIRKIT_FORCE_STANDARD_ARITHMETIC`。
通常経路のbin名nativeは拡張有効という意味で、march=nativeは指定していない。

## 全体時間の測定

CPU10、C++23 -O2 -Wall -Wextra、現在entryの設定をそのまま使用。
各compiler/check/fallbackについてrandom/全同値/倍率同率/既約比重複を2 warmup+9回ずつ交互実行した。
出力は未計時実行で独立参照へ全照合し、計時時だけDEVNULLへ書いた。

|skip版|random|全同値|倍率同率|既約比重複|
|---|---:|---:|---:|---:|
|GCC通常|1.004|1.039|1.045|1.043|
|GCC標準fallback|.958|.891|.886|.985|
|Clang通常|1.106|1.164|1.147|1.120|
|Clang標準fallback|1.040|1.390|1.287|1.122|

値は候補/現行。checkedも同じ傾向で、GCC通常はrandom同等、同率側約4〜5%回帰。
Clang通常では約11〜17%回帰し、両compilerでの有意利益という条件を満たさない。
GCC標準fallbackだけの改善を一般化せず、現行を維持する。
これはmain込みの結果で、Fraction本体の性能改善とはしない。

## coverageと資料

採用した場合、オンラインの明示的operator==呼出しがなくなる。
<=>の等価結果による同率判定は残り、fraction_test.cppの等値判定補足も残る。
今回は採用しないためcoverage metadataや旧ACの扱いは変更しない。

sources.jsonにsource/body/main/IO SHA、inputs.jsonに入力/独立期待値hash、
test_results.jsonにbuild/check commandと診断、results.jsonに全32比較組の全sampleを保存。
原データを残す場合は再実行前に結果を別名へ保存する。

```sh
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/fraction_cmp_candidate/test.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/fraction_cmp_candidate/benchmark.py
PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sirkit_fastest_review_20261113/fraction_cmp_candidate/finalize.py
```

CPU10に他の計時を同時実行しない。再現には凍結済みsourceを使い、prepareで将来のrepo版へ置き換えない。
