from pathlib import Path
from fractions import Fraction
import difflib,hashlib,itertools,json,random,sys
R=Path('/home/reinsirk/Atcoder_Env');W=Path('/tmp/sirkit_fastest_review_20261113/fraction_cmp_candidate');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
sha=lambda b:hashlib.sha256(b).hexdigest();entry=next(e for e in pv.collect()if e['id']=='fraction_sort');body=(R/'Math/Fraction.cpp').read_bytes();(W/'library.cpp').write_bytes(body);old=(R/entry['driver']).read_text();new=old.replace('''        if (a.first == b.first) return a.second < b.second;
        return a.first > b.first;''','''        const auto order = a.first <=> b.first;
        return order != 0 ? order > 0 : a.second < b.second;''');assert new!=old;(W/'baseline_main.cpp').write_text(old);(W/'candidate_main.cpp').write_text(new);(W/'main.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=entry['driver'],tofile='single-spaceship comparator')))
meta={'entry':entry,'body_sha256':sha(body),'io_sha256':sha((R/'Verify/current/common/fast_io.hpp').read_bytes()),'main_sha256':{'baseline':sha(old.encode()),'candidate':sha(new.encode())},'programs':[],'official_constraints':{'url':'https://atcoder.jp/contests/abc308/tasks/abc308_c','n':[2,200000],'a_b':[0,1000000000],'a_plus_b_min':1},'scope':'Comparator only, no Fraction/I/O/compiler setting changes'}
for name,driver in [('baseline',old),('candidate',new)]:
 for skip in [False,True]:
  data,_=pv.render(entry,source_overrides={'Math/Fraction.cpp':body},driver_override=driver,skip_runtime_checks=skip);suffix='_skip'if skip else'_checked';p=W/(name+suffix+'.cpp');p.write_bytes(data);batchdriver=driver.replace('int main() {','int solve_case() {');a=batchdriver.rfind('}');batchdriver=batchdriver[:a]+'    return 0;\n'+batchdriver[a:]+'\nint main(){int cases;verify_in>>cases;while(cases--)(void)solve_case();}\n';batch,_=pv.render(entry,source_overrides={'Math/Fraction.cpp':body},driver_override=batchdriver,skip_runtime_checks=skip);p2=W/(name+suffix+'_batch.cpp');p2.write_bytes(batch);meta['programs'].append({'name':name,'skip':skip,'source':str(p),'source_sha256':sha(data),'batch_source':str(p2),'batch_source_sha256':sha(batch)})
(W/'sources.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');(W/'inputs').mkdir(exist_ok=True)
def answer(values):
 rates=[Fraction(a,a+b)for a,b in values]
 return sorted(range(1,len(values)+1),key=lambda i:(-rates[i-1],i))
def text_output(order):return ' '.join(map(str,order))+'\n'
small=[];families={}
def add(values,family):
 values=list(values);assert len(values)>=2 and all(0<=a<=10**9 and 0<=b<=10**9 and a+b>0 for a,b in values);small.append(values);families[family]=families.get(family,0)+1
pool=[(a,b)for a in range(4)for b in range(4)if a+b]
for n in [2,3]:
 for values in itertools.product(pool,repeat=n):add(values,'exhaustive_grid0to3')
boundaries=[(0,10**9),(10**9,0),(10**9,10**9),(10**9,10**9-1),(10**9-1,10**9),(1,10**9),(10**9,1),(0,1),(1,0)]
for n in [2,3,4]:
 for values in itertools.product(boundaries,repeat=n):add(values,'exhaustive_max_boundaries')
rng=random.Random(93211837)
for trial in range(400):
 n=2+rng.randrange(63);values=[]
 for i in range(n):
  a,b=rng.randrange(10**9+1),rng.randrange(10**9+1)
  if trial%5==0:a=0
  elif trial%5==1:b=0
  elif trial%5==2:
   scale=rng.randrange(1,333333333);a,b=scale,2*scale
  if a+b==0:b=1
  values.append((a,b))
 add(values,'random_zero_equal_scaled_tie_index')
small_path=W/'inputs/small_batch.in';expected=W/'inputs/small_batch.expected'
with small_path.open('w')as f,expected.open('w')as out:
 f.write(str(len(small))+'\n')
 for values in small:f.write(str(len(values))+'\n'+''.join(f'{a} {b}\n'for a,b in values));out.write(text_output(answer(values)))
n=200000;rng=random.Random(912779);random_values=[]
for _ in range(n):
 a,b=rng.randrange(10**9+1),rng.randrange(10**9+1)
 if not a+b:b=1
 random_values.append((a,b))
primitives=[(j+1,65-j)for j in range(32)];duplicate=[]
for _ in range(n):
 a,b=primitives[rng.randrange(len(primitives))];scale=rng.randrange(1,10**9//max(a,b)+1);duplicate.append((a*scale,b*scale))
large=[]
for name,values,measure in [('random',random_values,True),('all_equal',[(17,34)]*n,True),('scaled_equal',[(scale,2*scale)for scale in [rng.randrange(1,333333334)for _ in range(n)]],True),('ratio_duplicates',duplicate,True),('a_zero',[(0,rng.randrange(1,10**9+1))for _ in range(n)],False),('b_zero',[(rng.randrange(1,10**9+1),0)for _ in range(n)],False),('max_coefficients',[boundaries[rng.randrange(len(boundaries))]for _ in range(n)],False)]:
 p=W/'inputs'/(name+'.in');p.write_text(str(n)+'\n'+''.join(f'{a} {b}\n'for a,b in values));out=p.with_suffix('.expected');out.write_text(text_output(answer(values)));large.append({'name':name,'n':n,'input':str(p),'input_sha256':sha(p.read_bytes()),'expected':str(out),'expected_sha256':sha(out.read_bytes()),'measure':measure})
manifest={'small':{'cases':len(small),'families':families,'input':str(small_path),'input_sha256':sha(small_path.read_bytes()),'expected':str(expected),'expected_sha256':sha(expected.read_bytes()),'oracle':'Python fractions.Fraction(a,a+b), descending exact rational then ascending 1-based index'},'large':large};(W/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n');print('prepared',len(small),'small cases',len(large),'large datasets',flush=True)
