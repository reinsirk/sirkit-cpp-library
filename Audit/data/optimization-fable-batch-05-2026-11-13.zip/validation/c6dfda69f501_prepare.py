from pathlib import Path
import sys,json,hashlib,difflib
r=Path('/home/reinsirk/Atcoder_Env');w=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'Scripts'));import prepare_verify as pv
entry=next(e for e in pv.collect()if e['id']=='rollback_weighted_union_find_rollback')
base=(r/entry['driver']).read_text();body={name:(r/name).read_bytes()for name in entry['libraries']}
old='''        const int state = uf.get_state();
        if (frame.vertex != 0) {
            const auto& query = queries[frame.vertex];
            if (query[0] == 0) uf.unite(query[1], query[2], std::int64_t{0});
            else answers[frame.vertex] = uf.same(query[1], query[2]);
        }
        stack.push_back({frame.vertex, state, true});
        for (int child = head[frame.vertex]; child != -1; child = next[child]) stack.push_back({child, 0, false});'''
new='''        const int first = head[frame.vertex];
        if (frame.vertex != 0) {
            const auto& query = queries[frame.vertex];
            if (query[0] != 0) answers[frame.vertex] = uf.same(query[1], query[2]);
            else {
                if (first == -1) continue;
                const int state = uf.get_state();
                uf.unite(query[1], query[2], std::int64_t{0});
                stack.push_back({frame.vertex, state, true});
            }
        }
        for (int child = first; child != -1; child = next[child]) stack.push_back({child, 0, false});'''
assert old in base;candidate=base.replace(old,new)
for name,data in [('baseline_main.cpp',base),('candidate_main.cpp',candidate)]: (w/name).write_text(data)
for name,data in body.items():(w/Path(name).name).write_bytes(data)
(w/'candidate.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),candidate.splitlines(True),fromfile=entry['driver'],tofile=entry['driver'])))
report={'scope':'main_only_zero_weight_connectivity','entry':entry,'body_sha256':{name:hashlib.sha256(data).hexdigest()for name,data in body.items()},'driver_sha256':hashlib.sha256(base.encode()).hexdigest(),'candidate_driver_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'io_sha256':hashlib.sha256((r/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest(),'sources':{}}
for variant,driver in [('baseline',base),('candidate',candidate)]:
 for mode,skip in [('checked',False),('skip',True)]:
  data,_=pv.render(entry,source_overrides=body,driver_override=driver,skip_runtime_checks=skip)
  name=variant+'_'+mode+'.cpp';(w/name).write_bytes(data);report['sources'][name]=hashlib.sha256(data).hexdigest()
(w/'provenance.json').write_text(json.dumps(report,indent=2)+'\n')
