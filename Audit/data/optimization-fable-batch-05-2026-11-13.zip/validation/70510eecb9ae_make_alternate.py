from pathlib import Path
import sys,json,hashlib,difflib
r=Path('/home/reinsirk/Atcoder_Env');w=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'Scripts'));import prepare_verify as pv
entry=next(e for e in pv.collect()if e['id']=='rollback_weighted_union_find_rollback');body={name:(w/Path(name).name).read_bytes()for name in entry['libraries']}
s=(w/'candidate_main.cpp').read_text()
old='''            if (query[0] != 0) answers[frame.vertex] = uf.same(query[1], query[2]);
            else {
                if (first == -1) continue;
                const int state = uf.get_state();
                uf.unite(query[1], query[2], std::int64_t{0});
                stack.push_back({frame.vertex, state, true});
            }'''
new='''            if (query[0] == 0) {
                if (first == -1) continue;
                const int state = uf.get_state();
                uf.unite(query[1], query[2], std::int64_t{0});
                stack.push_back({frame.vertex, state, true});
            } else answers[frame.vertex] = uf.same(query[1], query[2]);'''
assert old in s;s=s.replace(old,new);(w/'alternate_main.cpp').write_text(s)
base=(w/'baseline_main.cpp').read_text();(w/'alternate.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile=entry['driver'],tofile=entry['driver'])))
for mode,skip in [('checked',False),('skip',True)]:
 data,_=pv.render(entry,source_overrides=body,driver_override=s,skip_runtime_checks=skip);(w/('alternate_'+mode+'.cpp')).write_bytes(data)
