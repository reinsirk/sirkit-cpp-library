from pathlib import Path
import subprocess,json
w=Path(__file__).resolve().parent
install=Path(subprocess.check_output(['/usr/bin/g++','-print-libgcc-file-name'],text=True).strip()).parent
rows=[]
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir='+str(install)])]:
 for mode,flags in [('checked',[]),('skip',['-DSKIP_RUNTIME_CHECKS'])]:
  exe=w/f'probe_{cc}_{mode}';cmd=['taskset','-c','12',*compiler,'-std=c++23','-O2','-Wall','-Wextra',*flags,str(w/'history_probe.cpp'),'-o',str(exe)]
  built=subprocess.run(cmd,capture_output=True,text=True);assert built.returncode==0,built.stderr
  result=subprocess.run(['taskset','-c','12',str(exe)],capture_output=True,text=True);assert result.returncode==0,result.stderr
  rows.append({'compiler':cc,'mode':mode,'command':cmd,'stdout':result.stdout,'stderr':result.stderr,'passed':True});(w/'history_probe_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(cc,mode,result.stdout.strip(),flush=True)
