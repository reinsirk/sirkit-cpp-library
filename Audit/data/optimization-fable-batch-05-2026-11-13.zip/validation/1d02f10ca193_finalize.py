from pathlib import Path
import json,hashlib,shutil
w=Path(__file__).resolve().parent;r=Path('/home/reinsirk/Atcoder_Env')
p=json.loads((w/'provenance.json').read_text());initial_tests=json.loads((w/'validation_results.json').read_text());selected_tests=json.loads((w/'alternate_validation_results.json').read_text());probes=json.loads((w/'history_probe_results.json').read_text());a=json.loads((w/'alternate_benchmark_results.json').read_text());b=json.loads((w/'alternate_confirmation_results.json').read_text())
shutil.copyfile(w/'alternate_main.cpp',w/'selected_main.cpp');shutil.copyfile(w/'alternate.patch',w/'selected.patch')
stats=[]
for workload in selected_tests[0]['workloads']:
 path=Path(workload['input']);it=iter(map(int,path.read_bytes().split()));n,q=next(it),next(it);ops=[tuple(next(it)for _ in range(4))for _ in range(q)];children=[False]*(q+1)
 for t,k,u,v in ops:children[k+1]=True
 unions=sum(t==0 for t,k,u,v in ops);nonleaf=sum(t==0 and children[i+1]for i,(t,k,u,v)in enumerate(ops))
 stats.append({'input':str(path),'n':n,'q':q,'baseline_unite':unions,'selected_unite':nonleaf,'baseline_get_state_and_rollback':q+1,'selected_get_state_and_rollback':nonleaf,'query_parent_refs':sum(k>=0 and ops[k][0]==1 for t,k,u,v in ops)})
report={'decision':'accept','selected_variant':'alternate_preserve_union_branch_order','recommendation_only':True,'repository_modified':False,'fable_invoked':False,'scope':'main_only_zero_weight_connectivity','cpu':12,'compilers':a['compilers'],'flags':a['flags'],
 'reason':'元mainと同じunion-firstの分岐順を保つ別案を選択。GCC random/退化/line/starは両回で短縮。Clang random/starは短縮、退化は同等〜短縮、lineはほぼ同等。14条件すべて両回で非回帰。',
 'initial_variant':{'decision':'not_selected','reason':'Fable patchのquery-first順はGCC純line比1.0064/1.0146と小さな回帰。論理は保ち分岐順だけ元mainへ戻した。','measurements':str(w/'benchmark_results.json'),'confirmation':str(w/'confirmation_results.json')},
 'branch_order_text_comparison':json.loads((w/'branch_order_binary_comparison.json').read_text()),
 'validation':{'all_passed':all(row['passed']for row in initial_tests+selected_tests+probes),'initial_baseline_candidate_configurations':len(initial_tests),'selected_configurations':len(selected_tests),'history_probe_configurations':len(probes),'small_cases_per_configuration':295,'root_union_parent_cases':187,'stronger_query_parent_cases':108,'large_workloads_per_configuration':8,'model':'連結成分ラベルの不変tupleを版ごとに保存するPythonモデル。unionは全ラベル置換、queryは親tuple継承。rollback・history・UF木を使わない。','large_oracles':'6万query親深鎖、6万root-only葉unite、6万root-only queryとsmallは永続ラベルモデル。line/starは閉形式。既存random/退化はbaseline出力比較として区別。','selected_results':str(w/'alternate_validation_results.json'),'initial_results':str(w/'validation_results.json'),'history_probe_results':str(w/'history_probe_results.json')},
 'history_contract':'自己/重複unite(false)もhistoryへ1件（{-1,0}）追加。非葉unite直前stateへrollbackするので成否に依存しない。sameはconstで非圧縮、snapshotはmainで未使用かつ初期0。API probe4構成各73検査PASS。重みは全0、非零重みの追加検証とはしない。',
 'proof':str(w/'correctness_notes.md'),'workload_stats':stats,'measurements':a['results'],'confirmation_measurements':b['results'],'protocol':{'initial_selected':a['protocol'],'confirmation_selected':b['protocol']},
 'source':p,'selected_driver_sha256':hashlib.sha256((w/'selected_main.cpp').read_bytes()).hexdigest(),'body_still_current':all(hashlib.sha256((r/name).read_bytes()).hexdigest()==digest for name,digest in p['body_sha256'].items()),'baseline_driver_still_current':hashlib.sha256((r/p['entry']['driver']).read_bytes()).hexdigest()==p['driver_sha256'],
 'selected_main':str(w/'selected_main.cpp'),'selected_patch':str(w/'selected.patch'),'online_submission_performed':False,
 'reproduction':{name:str(w/name)for name in ['prepare.py','make_alternate.py','validate.py','validate_alternate.py','probe.py','benchmark.py','confirm.py','benchmark_alternate.py','confirm_alternate.py']},
}
(w/'final_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
lines=['# 重み付きrollback persistent main：分岐順を保つ別案を採用推奨','','本体・I/O・設定固定、全重み0のconnectivity mainのみ。葉uniteを省き、get_stateとexit/rollbackを非葉uniteだけへ移す。元mainと同じunion-firstの分岐順を保つ。repo未適用。','', '| compiler | input | 初回比 | 確認比 |','| --- | --- | ---: | ---: |']
for row in a['results']:
 c=next(x for x in b['results']if(x['compiler'],x['case'])==(row['compiler'],row['case']))
 lines.append(f"| {row['compiler']} | {row['case']} | {row['candidate_ratio']:.4f} | {c['candidate_ratio']:.4f} |")
lines+=['','比は選択案/現行。CPU12、GCC15.2/Clang21、CLI O2と現行GCC O3 pragma。同IOで初回2warm+9交互、確認は逆順2warm+15交互。query_parent_deepは通常契約より強いローカル補足。','', '初案query-firstはGCC lineで約0.6〜1.5%悪化したため未選択。分岐順を戻した別案はGCC lineも両回で短縮し、Clangでは初案/別案の.textが同一。','', '初案baseline/candidate8構成、選択案4構成、履歴API probe4構成すべてPASS。各main構成で295小入力と8 workloadを確認。query親・自己/重複union・深鎖/分岐/root-onlyを独立Python永続ラベルモデルへ照合した。probeはunite(false)の1履歴とquery状態不変・保存位置への復帰を各73検査で確認。','', '採用用selected_main.cpp / selected.patch、証明correctness_notes.md、全rawと再現scriptを同ディレクトリに保存。','']
(w/'summary.md').write_text('\n'.join(lines));print(json.dumps({'decision':report['decision'],'selected':report['selected_variant'],'all_validation_passed':report['validation']['all_passed'],'body_still_current':report['body_still_current'],'report':str(w/'final_report.json')},indent=2))
