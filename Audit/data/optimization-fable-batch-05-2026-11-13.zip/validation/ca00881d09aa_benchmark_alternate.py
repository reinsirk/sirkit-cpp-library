from pathlib import Path
import hashlib,json,statistics,subprocess,time,shutil
w=Path(__file__).resolve().parent;d=Path('/tmp/sirkit_remaining_20261113/data/inputs/rollback_weighted_union_find_rollback')
records=[];report={'cpu':12,'scope':'main_only zero-weight connectivity; head/next baseline, weighted core/shared IO/current compiler settings held identical.','flags':'CLI C++23 O2; actual generated GCC O3 pragma retained; SKIP_RUNTIME_CHECKS; Clang ignores GCC-only pragma.','protocol':'2warm+9 strictly alternating measured pairs; common executable path.','compilers':{cc:subprocess.check_output([path,'--version'],text=True).splitlines()[0]for cc,path in [('gcc','/usr/bin/g++'),('clang','/usr/bin/clang++')]},'results':records}
def save():(w/'alternate_benchmark_results.json').write_text(json.dumps(report,indent=2)+'\n')
for cc in ['gcc','clang']:
 bins={variant:w/f'{variant}_skip_{cc}'for variant in ['baseline','alternate']}
 for case,inp,contract in [('random',d/'random.in','root/union parent'),('degenerate',d/'degenerate.in','root/union parent'),('line',w/'line.in','root/union parent'),('star',w/'star.in','root/union parent'),('query_parent_deep',w/'query_parent_deep.in','stronger local query-parent extension'),('root_only_unites',w/'root_only_unites.in','root only'),('root_only_queries',w/'root_only_queries.in','root only')]:
  outputs={}
  for name,exe in bins.items():
   with inp.open('rb')as fi:p=subprocess.run(['taskset','-c','12',str(exe)],stdin=fi,capture_output=True)
   assert p.returncode==0,p.stderr;outputs[name]=p.stdout
  assert outputs['baseline']==outputs['alternate']
  raw={name:[]for name in bins}
  for rep in range(11):
   for name in (list(bins)if rep%2==0 else list(reversed(bins))):
    active=w/'active';shutil.copyfile(bins[name],active);active.chmod(0o755)
    with inp.open('rb')as fi,open('/dev/null','wb')as fo:
     start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','12',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
    assert p.returncode==0,p.stderr
    if rep>=2:raw[name].append(elapsed)
  med={name:statistics.median(values)for name,values in raw.items()}
  row={'compiler':cc,'case':case,'contract':contract,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(outputs['baseline']).hexdigest(),'output_byte_identical':True,'raw_ns':raw,'median_ns':med,'candidate_ratio':med['alternate']/med['baseline'],'candidate_pair_wins':sum(b<a for a,b in zip(raw['baseline'],raw['alternate']))}
  records.append(row);save();print(cc,case,'ratio',round(row['candidate_ratio'],4),'wins',row['candidate_pair_wins'],'ms',{name:round(value/1e6,3)for name,value in med.items()},flush=True)
