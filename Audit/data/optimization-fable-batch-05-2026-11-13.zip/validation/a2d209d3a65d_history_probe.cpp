// SPDX-License-Identifier: CC0-1.0
#include "rollback-union-findw.cpp"
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <type_traits>
using UF = RollbackWeightedUnionFind<std::int64_t>;
static unsigned checks=0;
void check(bool ok){++checks;if(!ok)std::abort();}
static_assert(std::is_invocable_r_v<bool,decltype(&UF::same),const UF&,int,int>);
int main(){
 UF uf(4);const int root=uf.get_state();check(root==0);
 check(!uf.unite(0,0,0));check(uf.get_state()==root+1);check(uf.component_count()==4);
 uf.rollback(root);check(uf.get_state()==root);check(!uf.same(0,1));
 check(uf.unite(0,1,0));const int merged=uf.get_state();check(merged==1);
 check(!uf.unite(1,0,0));check(uf.get_state()==merged+1);check(uf.same(0,1));
 uf.rollback(merged);check(uf.get_state()==merged);check(uf.same(0,1));
 check(uf.unite(1,2,0));check(uf.get_state()==merged+1);check(uf.same(0,2));
 const int before=uf.get_state(),components=uf.component_count();
 for(int a=0;a<4;++a)for(int b=0;b<4;++b){check(uf.same(a,b)==(a==b||(a<3&&b<3)));check(uf.get_state()==before);check(uf.component_count()==components);}
 uf.rollback(merged);check(!uf.same(0,2));check(uf.same(0,1));check(uf.component_count()==3);
 uf.rollback(root);check(uf.get_state()==root);check(uf.component_count()==4);
 for(int i=0;i<4;++i)check(uf.find(i)==i && uf.get_weight(i)==0);
 std::printf("PASS weighted zero-history contract checks=%u\n",checks);
}
