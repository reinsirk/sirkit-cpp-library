from pathlib import Path
import itertools,json,random,subprocess,hashlib,time
w=Path(__file__).resolve().parent;root=Path('/home/reinsirk/Atcoder_Env');d=Path('/tmp/sirkit_remaining_20261113/data/inputs/rollback_weighted_union_find_rollback')
rng=random.Random(0xBACC0FF)
install=Path(subprocess.check_output(['/usr/bin/g++','-print-libgcc-file-name'],text=True).strip()).parent

def serialize(n,ops):return (f'{n} {len(ops)}\n'+'\n'.join(' '.join(map(str,x))for x in ops)+'\n').encode()
def persistent_model(n,ops):
 versions=[tuple(range(n))];out=[]
 for i,(t,k,u,v)in enumerate(ops):
  assert -1<=k<i
  before=versions[k+1]
  if t==0:
   old=before[v];new=before[u]
   after=tuple(new if label==old else label for label in before)
  else:
   out.append(int(before[u]==before[v]));after=before
  versions.append(after)
 return ''.join(str(x)+'\n'for x in out).encode()
def parse(data):
 it=iter(map(int,data.split()));n,q=next(it),next(it);ops=[tuple(next(it)for _ in range(4))for _ in range(q)];return n,ops
small=[]
def add(n,ops,label):
 small.append({'label':label,'n':n,'ops':ops,'input':serialize(n,ops).decode(),'expected':persistent_model(n,ops).decode(),'official_parent_contract':all(k==-1 or ops[k][0]==0 for _,k,_,_ in ops),'query_parent_count':sum(k>=0 and ops[k][0]==1 for _,k,_,_ in ops)})
# All t,parent,endpoints for n=2 and q<=2; stronger model includes query-parent references.
for length in (1,2):
 def enumerate_ops(ops):
  if len(ops)==length:add(2,ops,'exhaustive_n2_q'+str(length));return
  for t,k,u,v in itertools.product((0,1),range(-1,len(ops)),range(2),range(2)):
   enumerate_ops(ops+[(t,k,u,v)])
 enumerate_ops([])
# All self-union/query and parent choices up to depth3 for n=1.
for length in (1,2,3):
 def enum_self(ops):
  if len(ops)==length:add(1,ops,'self_exhaustive');return
  for t,k in itertools.product((0,1),range(-1,len(ops))):enum_self(ops+[(t,k,0,0)])
 enum_self([])
for rep in range(96):
 n=rng.randrange(1,26);ops=[];available=[-1]
 for i in range(rng.randrange(1,181)):
  t=rng.randrange(2);k=rng.choice(available)if rep%2==0 else rng.randrange(-1,i)
  u=rng.randrange(n);v=u if i%7==0 else rng.randrange(n)
  ops.append((t,k,u,v))
  if t==0:available.append(i)
 add(n,ops,'random_official'if rep%2==0 else'random_query_parent')
add(4,[(0,-1,0,1),(1,0,0,1),(0,1,1,2),(1,2,0,2),(1,0,0,2),(0,3,2,3),(1,5,0,3),(1,4,0,2),(0,5,0,3),(1,8,1,3)],'query_parent_branch_restore')
for n in (1,2,5,17):
 ops=[]
 for i in range(120):
  t=0 if i%3==0 else 1;k=-1 if i%4==0 else i-1
  ops.append((t,k,i%n,(i//3)%n))
 add(n,ops,'mixed_chain_self_duplicate')
(w/'small_cases.json').write_text(json.dumps(small,indent=2)+'\n')
# Fully independent deep query-parent inheritance test remains small in n, long in q.
q=60000;ops=[(i%2,i-1,i%16,(i//3)%16)for i in range(q)]
deep=w/'query_parent_deep.in';deep.write_bytes(serialize(16,ops));deep_expected=persistent_model(16,ops);deep.with_suffix('.expected').write_bytes(deep_expected)
# Official-style pure update chain and root-star, with independently known answers.
n=30000;ops=[(0,i-1,i%n,(i+1)%n)for i in range(q-1)]+[(1,q-2,0,n-1)]
line=w/'line.in';line.write_bytes(serialize(n,ops));line_expected=b'1\n';line.with_suffix('.expected').write_bytes(line_expected)
ops=[(int(i%3!=0),-1,i%n,i%n if i%5==0 else(i*31+1)%n)for i in range(q)]
star=w/'star.in';star.write_bytes(serialize(n,ops));star_expected=''.join(str(int(u==v))+'\n'for t,k,u,v in ops if t).encode();star.with_suffix('.expected').write_bytes(star_expected)
large=[(d/'small.in',persistent_model(*parse((d/'small.in').read_bytes())),'persistent_partition_model'),(d/'random.in',None,'baseline_bytes'),(d/'degenerate.in',None,'baseline_bytes'),(deep,deep_expected,'persistent_partition_model'),(line,line_expected,'closed_form_chain'),(star,star_expected,'closed_form_root_versions')]
# Root-only cases preserve the problem parent contract and make all unions leaves.
root_cases=[]
for name,t in [('root_only_unites',0),('root_only_queries',1)]:
 ops=[(t,-1,i%16,(i//3)%16) for i in range(60000)]
 path=w/(name+'.in');path.write_bytes(serialize(16,ops));expected=persistent_model(16,ops)
 path.with_suffix('.expected').write_bytes(expected);root_cases.append((path,expected,'persistent_partition_model'))
large += root_cases
results=[];baseline={}
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir='+str(install)])]:
 for mode in ['checked','skip']:
  for variant in ['baseline','candidate']:
   src=w/f'{variant}_{mode}.cpp';exe=w/f'{variant}_{mode}_{cc}';cmd=['taskset','-c','12',*compiler,'-std=c++23','-O2','-Wall','-Wextra',str(src),'-o',str(exe)]
   built=subprocess.run(cmd,capture_output=True,text=True);assert built.returncode==0,built.stderr
   for i,test in enumerate(small):
    result=subprocess.run(['taskset','-c','12',str(exe)],input=test['input'],capture_output=True,text=True,timeout=10)
    assert result.returncode==0 and result.stdout==test['expected'],(cc,mode,variant,i,test,result.stdout,result.stderr)
   workloads=[]
   for path,expected,oracle in large:
    with path.open('rb')as fi:result=subprocess.run(['taskset','-c','12',str(exe)],stdin=fi,capture_output=True,timeout=30)
    assert result.returncode==0,result.stderr
    if expected is not None:assert result.stdout==expected,(cc,mode,variant,path,result.stdout)
    if str(path)not in baseline:baseline[str(path)]=result.stdout
    assert result.stdout==baseline[str(path)],(cc,mode,variant,path)
    workloads.append({'input':str(path),'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(result.stdout).hexdigest(),'oracle':oracle})
   row={'compiler':cc,'mode':mode,'variant':variant,'command':cmd,'diagnostics':built.stderr,'small_cases':len(small),'small_official_parent_contract':sum(t['official_parent_contract']for t in small),'small_with_query_parents':sum(t['query_parent_count']>0 for t in small),'workloads':workloads,'passed':True}
   results.append(row);(w/'validation_results.json').write_text(json.dumps(results,indent=2)+'\n');print(cc,mode,variant,'PASS',len(small),'small',len(large),'large',flush=True)
