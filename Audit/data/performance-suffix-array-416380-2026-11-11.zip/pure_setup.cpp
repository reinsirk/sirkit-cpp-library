// SPDX-License-Identifier: CC0-1.0
#include HEADER
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <random>
int main(int argc,char**argv){
 if(argc!=5)return 2;
 const int kind=std::atoi(argv[1]), n=std::atoi(argv[2]), shape=std::atoi(argv[3]), reps=std::atoi(argv[4]);
 std::mt19937_64 rng(416380); std::vector<int> a(n); std::vector<std::int64_t>b(n); std::vector<bool>bits(n); std::string s(n,'a');
 for(int i=0;i<n;++i){const int v=shape==0?0:shape==1?i%3:static_cast<int>(rng()%256); a[i]=v; b[i]=std::int64_t(v)*1000000007-2000000014;bits[i]=v%2;s[i]=static_cast<char>(v);}
 auto sa=suffix_array(s);const auto path="/tmp/sirkit_suffix_416380/pure_sa_"+std::to_string(n)+"_"+std::to_string(shape);auto*f=std::fopen(path.c_str(),"wb");if(!f)return 3;std::fwrite(sa.data(),sizeof(int),n,f);std::fclose(f);}
