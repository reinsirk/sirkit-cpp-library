# SPDX-License-Identifier: CC0-1.0
# 親が本体改修後に実行する補助。--applyなしでは書き込まない。
from pathlib import Path
import argparse,copy,hashlib,json,sys
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_suffix_416380')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(data):return hashlib.sha256(data).hexdigest()
def load(p):return json.loads(p.read_text())
def encode(a):return json.dumps(a,ensure_ascii=False,indent=2)+'\n'
def atomic_json(p,a):
    p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_name(p.name+'.sirkit-online.tmp');temp.write_text(encode(a));temp.replace(p)
parser=argparse.ArgumentParser();parser.add_argument('--apply',action='store_true');parser.add_argument('--audit-file',default='Audit/online-suffix-array-416380-416379-2026-11-11.json');parser.add_argument('--performance-audit');args=parser.parse_args()
relative=Path(args.audit_file);assert not relative.is_absolute() and '..'not in relative.parts and relative.parts[0]=='Audit'
audit=copy.deepcopy(load(D/'online_records.json'));groups=load(R/'Verify/current/groups/expansion_20261031.json');journal=load(R/'Verify/current/judgements.json')
sys.path.insert(0,str(R/'Scripts'));import prepare_verify
entries={e['id']:e for e in prepare_verify.collect()};records={r['id']:r for r in audit['records']};updated={};report=[]
for identifier,snapshot in records.items():
    snapshot['evidence_file']=relative.as_posix()
    entry=copy.deepcopy(entries[identifier]);entry['submission_urls']=[snapshot['url']]
    # main/IOは固定条件。変更している場合は書込み前に停止する。
    assert sha(R/entry['driver'])==snapshot['driver_sha256'],(identifier,'driver changed')
    for name,expected in snapshot['io_source_hashes'].items():assert sha(R/name)==expected,(identifier,name,'IO changed')
    data,hashes=prepare_verify.render(entry)
    matches=digest(data)==snapshot['submission_sha256']
    current=copy.deepcopy(snapshot);current.update(matched_current_generation=matches,needs_resubmission=not matches,current_source_hashes=hashes,current_submission_sha256=digest(data))
    if not matches:current['pending_reason']=f"{snapshot['url'].rsplit('/',1)[1]}は変更前のAC{snapshot['time_ms']}ms。今回の本体改修は未提出。main/共通IOは同一。"
    if args.performance_audit:current['performance_audit']=args.performance_audit
    updated[identifier]=current
    group=next(e for e in groups['entries']if e['id']==identifier);group['submission_urls']=[snapshot['url']]
    group['limitations']=f"{snapshot['url'].rsplit('/',1)[1]}は{'変更前の'if not matches else '現行通常版の'}AC{snapshot['time_ms']}ms。提出時の本体/main/共通IOは本文と照合済み。"+('現行の本体改修は未提出で、このACに含めない。'if not matches else '派生版のオンライン判定へ転記しない。')
    report.append(dict(id=identifier,online_status=snapshot['status'],online_time_ms=snapshot['time_ms'],needs_resubmission=not matches,before_source_hashes=snapshot['source_hashes'],current_source_hashes=hashes,current_submission_sha256=digest(data)))
ids=set(updated);present=set()
for i,old in enumerate(journal['entries']):
    if old['id']in ids:journal['entries'][i]=updated[old['id']];present.add(old['id'])
for identifier in updated:
    if identifier not in present:journal['entries'].append(updated[identifier])
audit['scope']='初回提出のACと変更前スナップショットの本文一致を記録。本体改修後の現行版や派生版のオンラインACではない。'
auditpath=R/relative
if auditpath.exists():assert auditpath.read_text()==encode(audit),('既存の監査記録を上書きしない',str(auditpath))
print(json.dumps(dict(mode='apply'if args.apply else 'dry-run',audit_file=str(auditpath),records=report),ensure_ascii=False,indent=2))
if args.apply:
    atomic_json(auditpath,audit)
    atomic_json(R/'Verify/current/groups/expansion_20261031.json',groups)
    atomic_json(R/'Verify/current/judgements.json',journal)
    print('metadata updated; run prepare_verify.py and prepare_variant_verify.py next')
