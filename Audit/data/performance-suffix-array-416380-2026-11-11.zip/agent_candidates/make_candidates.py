# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_suffix_416380/agent_candidates');B=D.parent/'before/String/Suffix_Array.cpp';base=(B if B.exists()else R/'String/Suffix_Array.cpp').read_text()
old='''    int previous = -1, name = -1;
    for (int position : suffixes) {
        if (!boundary[position]) continue;
        bool different = previous < 0;
        if (!different) {
            int offset = 0;
            for (;;) {
                if (symbols[position + offset] != symbols[previous + offset] ||
                    small[position + offset] != small[previous + offset]) {
                    different = true; break;
                }
                if (offset > 0 && (boundary[position + offset] || boundary[previous + offset])) {
                    different = boundary[position + offset] != boundary[previous + offset]; break;
                }
                ++offset;
            }
        }
        if (different) ++name;
        reduced[selected_id[position]] = name;
        previous = position;
    }'''
new='''    int previous = -1, previous_end = -1, name = -1;
    for (int position : suffixes) {
        if (!boundary[position]) continue;
        const int id = selected_id[position];
        const int end = id + 1 < count ? selected[id + 1] : position;
        bool different = previous < 0;
        if (!different) {
            const int span = end - position;
            different = span != previous_end - previous || symbols[position] != symbols[previous];
            // 終点もLMS。等しい文字列と終点のS型から、区間内のL/S型も一意に決まる。
            if (!different)
                different = !std::equal(symbols.begin() + position + 1, symbols.begin() + end + 1,
                                        symbols.begin() + previous + 1);
        }
        if (different) ++name;
        reduced[id] = name;
        previous = position;
        previous_end = end;
    }'''
assert old in base
naming=base.replace(old,new);(D/'lms_endpoint_equal.hpp').write_text(naming)
old='''    std::vector<int> starts(static_cast<std::size_t>(alphabet) + 1), ends(starts.size());
    for (int symbol : symbols) ++ends[symbol];
    int total = 0;
    for (int symbol = 0; symbol <= alphabet; ++symbol) {
        starts[symbol] = total; total += ends[symbol]; ends[symbol] = total;
    }
    std::vector<int> suffixes(n), cursor(ends.size());'''
new='''    // bucket[x]/bucket[x+1]が値xの区間。開始/終端を重複保持しない。
    std::vector<int> bucket;
    if (bucket.max_size() < 2 ||
        static_cast<std::uintmax_t>(alphabet) > static_cast<std::uintmax_t>(bucket.max_size() - 2))
        throw std::length_error("suffix_array: alphabet too large");
    bucket.resize(static_cast<std::size_t>(alphabet) + 2);
    for (int symbol : symbols) ++bucket[static_cast<std::size_t>(symbol) + 1];
    for (int symbol = 0; symbol <= alphabet; ++symbol)
        bucket[static_cast<std::size_t>(symbol) + 1] += bucket[symbol];
    std::vector<int> suffixes(n), cursor(bucket.size() - 1);'''
assert old in base
buckets=base.replace(old,new).replace('        cursor = ends;','        std::copy(bucket.begin() + 1, bucket.end(), cursor.begin());').replace('        cursor = starts;','        std::copy(bucket.begin(), bucket.end() - 1, cursor.begin());')
assert 'cursor = ends' not in buckets and 'cursor = starts' not in buckets
(D/'single_bucket.hpp').write_text(buckets)
meta={
 'license':'CC0-1.0','base_sha256':hashlib.sha256(base.encode()).hexdigest(),'canonical_modified':False,'compiled':False,'benchmarked':False,
 'candidates':[
  {'file':'lms_endpoint_equal.hpp','change':'LMS命名で次のLMS位置から終点/長さを取得し、先頭要素・長さが同じ場合だけstd::equalで終点込みの残りを比較する。逐次比較内のsmall/boundary読出しを省く。','invariant':'両終点はS型。終点込みの記号列が一致すればL/S型列も右からの定義で一致する。終点までの距離が同じでなければ異なる。最後の一意終端0の区間は長さ1。','bounds':'end<=n-1、position>=1、end+1<=nで、std::equalの範囲は合法。比較前に両区間のspanが同じなので比較先も合法。id+1<=count<=n/2。前のendはcarryし追加のselected_id読出しを1回にする。','complexity':'各LMS区間は隣接する2比較までなので比較総量O(n)。追加vectorなし、配列/所有は維持。','tradeoff':'長さ/端点参照とstd::equal呼出しが短いランダム区間で不利な可能性あり。親が測定して判断。','integration':'親がLMS mapを半分へ詰める場合はselected_id[position]をselected_id[position/2]へ合わせる。'},
  {'file':'single_bucket.hpp','change':'starts/endsをbucket[x]/bucket[x+1]の1配列へ統合する。cursorへのstart/endコピーはstd::copyのずらした範囲を使う。','invariant':'bucket[x]=sum count(value<x)、bucket[x+1]=sum count(value<=x)。したがって既存の開始/終端と同一。sentinel0の区間は[0,1)。','bounds':'alphabet+2はsize_tで計算しmax_sizeを先に検査。histogram symbol+1はsize_t。prefix累積値はn以下でint安全。cursorはalphabet+1個、コピー両範囲もalphabet+1個。','complexity':'O(n+alphabet)を維持し、永続するint領域をalphabet+1個減らす。バケットの確保は2配列から1配列、cursorは従来通り。','tradeoff':'文字列のalphabet=256では節約小、再帰段/上限付き整数列/圧縮整数列の大きいalphabetで効果を期待。速度は未測定。','integration':'親のLMS map圧縮/boundary統合/count1早期returnと独立に合成できる。'}]
}
for row in meta['candidates']:row['sha256']=hashlib.sha256((D/row['file']).read_bytes()).hexdigest()
(D/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
