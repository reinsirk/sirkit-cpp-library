from pathlib import Path
import hashlib
import json

source = Path('/home/reinsirk/Atcoder_Env/String/Suffix_Array.cpp')
target = Path(__file__).resolve().parent
base = source.read_text()
old = '''    reinsirk::detail::suffix_length_check(s.size());
#ifndef SKIP_RUNTIME_CHECKS
    if (sa.size() != s.size()) throw std::invalid_argument("lcp_array: size");
    std::vector<int> rank(s.size(), -1);
#else
    std::vector<int> rank(s.size());
#endif
    const int n = static_cast<int>(s.size());
'''
new = '''    reinsirk::detail::suffix_length_check(s.size());
#ifndef SKIP_RUNTIME_CHECKS
    if (sa.size() != s.size()) throw std::invalid_argument("lcp_array: size");
#endif
    const int n = static_cast<int>(s.size());
    if (n == 0) return {};
#ifndef SKIP_RUNTIME_CHECKS
    std::vector<int> rank(s.size(), -1);
#else
    // 妥当なsaの順列から全要素を設定してから参照する。
    auto rank = std::make_unique_for_overwrite<int[]>(s.size());
#endif
'''
assert base.count(old) == 1
rank = base.replace('#include <limits>\n', '#include <limits>\n#include <memory>\n', 1).replace(old, new, 1)
old_bound = '        while (length < n - i && length < n - j && s[i + length] == s[j + length]) ++length;'
new_bound = '''        const int limit = n - std::max(i, j);
        while (length < limit && s[i + length] == s[j + length]) ++length;'''
assert rank.count(old_bound) == 1
candidates = {
    'lcp_rank_uninit.hpp': rank,
    'lcp_rank_limit.hpp': rank.replace(old_bound, new_bound, 1),
}
start = base.index('#ifndef SIRKIT_LCP_ARRAY_IMPL_DEFINED')
end = base.index('#ifndef SIRKIT_LCP_ARRAY_DEFINED', start)
for name, code in candidates.items():
    # LCP本体とmemory include以外は元ファイルと一致する。
    candidate_start = code.index('#ifndef SIRKIT_LCP_ARRAY_IMPL_DEFINED')
    candidate_end = code.index('#ifndef SIRKIT_LCP_ARRAY_DEFINED', candidate_start)
    assert code[:candidate_start].replace('#include <memory>\n', '', 1) == base[:start]
    assert code[candidate_end:] == base[end:]
    (target / name).write_text(code)
metadata = {
    'source': str(source),
    'source_sha256': hashlib.sha256(base.encode()).hexdigest(),
    'canonical_modified': False,
    'compiled_or_benchmarked': False,
    'candidates': {
        name: {'sha256': hashlib.sha256(code.encode()).hexdigest()}
        for name, code in candidates.items()
    },
}
(target / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata, indent=2))
