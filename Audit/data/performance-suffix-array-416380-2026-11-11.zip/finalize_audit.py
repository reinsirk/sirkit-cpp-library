# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,statistics,zipfile,datetime
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_suffix_416380')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,a):p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
v=load(D/'final_validation.json');assert v['all_passed'] and v['passed_jobs']==24
s=load(D/'final_summary.json');raw=load(D/'final_raw.json');assert len(s)==300 and len(raw)==6300
fixtures=load(D/'agent_fixtures/fixtures.json');stats=[]
for cc in ['gcc','clang']:
 for identifier in ['suffix_array','suffix_array_substrings']:
  a=[r for r in s if r['compiler']==cc and r['id']==identifier and next(f['n']for f in fixtures if f['name']==r['case'])>=200000]
  stats.append(dict(compiler=cc,id=identifier,large_cases=len(a),geometric_mean_ratio=statistics.geometric_mean(r['ratios']['final']for r in a),worst_ratio=max(r['ratios']['final']for r in a),cases_above_1_02=[dict(case=r['case'],ratio=r['ratios']['final'])for r in a if r['ratios']['final']>1.02]))
assert (R/'String/Suffix_Array.cpp').read_bytes()==(D/'final.hpp').read_bytes()
frozen={}
for p in ['Verify/current/drivers/suffix_array_main.cpp','Verify/current/drivers/suffix_array_substrings_main.cpp','Verify/current/common/fast_io.hpp']:
 assert (R/p).read_bytes()==(D/'before'/p).read_bytes();frozen[p]=sha(R/p)
profile_path=next((D/'profiles/runs').glob('*.json'));profiles=load(profile_path)
audit=dict(date='2026-11-11',library='String/Suffix_Array.cpp',decision='adopt_smaller_SA_IS_state_and_uninitialized_fully_written_rank',online_evidence='Audit/online-suffix-array-416380-416379-2026-11-11.json',required_resubmission=['Verify/current/submissions/suffix_array.cpp','Verify/current/submissions/suffix_array_substrings.cpp'],online_scope='416380 AC49msと416379 AC48msは変更前の通常版の記録。今回の改修と派生版は未提出。',source_sha256=dict(before=sha(D/'base.hpp'),after=sha(D/'final.hpp')),frozen_main_and_IO=frozen,public_API_and_document_and_examples_unchanged=True,changes=[
 'S/LとLMS境界を1バイトへ統合する。L/S分類後にLMS印を重ねる。',
 'LMSが隣接しない性質により位置/2の対応表を使用。表の要素は書込み済みLMSだけ参照し、make_unique_for_overwriteで初期化を省く。',
 'LMSが一意な終端だけなら再誘導を省く。最初と最後の種の順序が同じなので同じ結果になる。',
 'suffixesを最初から-1で確保し、初回だけ重複する全要素初期化を省く。2回目の誘導は再初期化する。',
 '対応表を再帰前に解放。LCPはSKIP時だけrankを未初期化確保し、妥当なsa順列から全要素を設定する。検査有効時の-1と重複検査を維持。',
 'LCP空入力はサイズ検査の後に確保せず返す。1要素は従来の検査を維持。'
 ],ownership='通常版はvector/unique_ptrで所有し、直接new式・解放省略はない。確保失敗時の独立注入試験でlive_delta=0。',measurement=dict(cpu='Intel Core i9-14900K CPU12/core6 P-Core; sibling13',E_core_measured=False,compilers=dict(gcc='15.2.0',clang='21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'),flags=['-std=c++23','-O2'],march_native=False,extra_pragmas=False,setting='SKIP_RUNTIME_CHECKS; submitted main/IO frozen',whole='user+system child CPU time; same active path, setarch x86_64 -R, taskset12; deterministic shuffled base/control/final; control is the identical base executable',lock='/tmp/sirkit_performance_cpu12.lock',compilation_during_timing=False,fixture_rows=len(fixtures),byte_unique_inputs=len({f['sha256']for f in fixtures}),official_revision='73876f1cbcf082d2b22722924b924d3d65a2f00e',fixture_scope='固定公開生成器と独立作成の入力。オンライン入力との同一性は主張しない。制約外100万要素を含む。',whole_repetitions=7,whole_runs=len(raw),all_variant_outputs_equal=True,large_selection='入力長20万以上。小さい入力の起動費を平均改善率へ混ぜない。',summary=stats),rejected_candidates=[
 dict(name='LCP_limit_n_minus_max',reason='全体が改善しても、独立に同じSAを読んだLCP単体でGCC検査有効の同値/周期列が約2〜4%増えるため不採用。SA直後の測定では確保状態の影響も含み約5〜10%の増加。境界条件は旧方式を維持。'),
 dict(name='rank_bitset_popcount',reason='LMS表の省メモリ化はできるが、選択した単純な半分表を上回る安定した速度改善がない。'),
 dict(name='endpoint_naming_and_single_bucket',reason='候補ごとに増減があり、より簡潔な採用案を安定して上回らない。'),
 dict(name='unique_first_symbols_probe',reason='重複までの追加検査を含み、採用案を安定して上回らない。')
 ],generic_measurement=dict(operations=['bounded vector<int> SA','compressed vector<int64_t> SA','vector<bool> SA','LCP reuse','equal range search'],sizes=[32,4096,500000],shapes=['all same','periodic3','random byte'],settings=['checked','SKIP_RUNTIME_CHECKS'],repetitions=5,scope='generic_raw/summaryはlimit候補の切分け測定。最終rank-only版のLCP単体はpure_raw/summaryのfirst_fill_lcp_rank_uninit列。pureでは共通の事前作成SAを読み、SA構築後の異なる確保状態を切り離す。比較値の大規模SA構築部分は最終版と同じSA演算。',LCP_followup_repetitions=11),validation=dict(jobs=24,all_passed=True,details='evidence ZIP: final_validation.json',initial_environment_failure='初回のLeakSanitizerがhostのptraceで起動失敗。ASAN/UBSANの検査をdetect_leaks=0で全設定再実行し、所有権は別の確保失敗/解放カウンタで検証。初回失敗の出力も保存。'),source_license='CC0-1.0独自実装。新しい外部実装のコードは転記していない。固定問題生成器はApache-2.0原典を一時領域だけで使い、配布ライブラリ/証拠ZIPへ原典本文を入れない。',evidence='Audit/data/performance-suffix-array-416380-2026-11-11.zip')
audit['validation']['profiles']=profiles
audit['validation']['current_submission_correspondence']=load(D/'current_correspondence.json')
put(R/'Audit/performance-suffix-array-416380-2026-11-11.json',audit)
files=[p for p in D.iterdir()if p.is_file() and p.suffix in ['.py','.json','.hpp']]
files += [p for p in D.iterdir()if p.is_file() and p.name in ['generic.cpp','pure.cpp','pure_setup.cpp','416380.cpp','416379.cpp']]
for sub in ['agent_fixtures','agent_lcp','agent_candidates']:
 files += [p for p in (D/sub).iterdir()if p.is_file()and p.suffix in ['.py','.json','.txt','.hpp']]
files += [p for p in (D/'profiles').rglob('*.json')]
files += [p for p in (D/'before').rglob('*')if p.is_file() and p.suffix in ['.cpp','.hpp','.json']]
target=R/audit['evidence']
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(set(files)):z.write(p,str(p.relative_to(D)))
print('audit/evidence',stats,sha(target),target.stat().st_size)
