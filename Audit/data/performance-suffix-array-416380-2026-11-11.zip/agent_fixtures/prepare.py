# SPDX-License-Identifier: CC0-1.0
# 独立入力生成と公式再生成計画。外部生成器本文はtempのみ。
from pathlib import Path
import argparse,hashlib,json,posixpath,random,re,tomllib,urllib.request
D=Path('/tmp/sirkit_suffix_416380/agent_fixtures')
REV='73876f1cbcf082d2b22722924b924d3d65a2f00e'
BASE=f'https://raw.githubusercontent.com/yosupo06/library-checker-problems/{REV}/'
ROOTS=['string/suffixarray','string/number_of_substrings']
LIMIT=500000

def sha(b):return hashlib.sha256(b).hexdigest()
def dump(n,x):(D/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def read(n):return json.loads((D/n).read_text())
def fetch():
 official=D/'official';official.mkdir(exist_ok=True);queue=['LICENSE'];infos={};records=[];seen=set()
 for root in ROOTS:
  info=tomllib.loads((D/(root.rsplit('/',1)[1]+'_info.toml')).read_text());infos[root]=info;queue.append(root+'/info.toml')
  for t in info['tests']:
   name=t['name']
   if name.endswith('.cpp'):queue.append(root+'/gen/'+name)
   else:queue += [root+'/gen/'+name[:-3]+f'_{i:02d}.in'for i in range(t['number'])]
 while queue:
  path=queue.pop(0)
  if path in seen:continue
  seen.add(path);p=official/path;p.parent.mkdir(parents=True,exist_ok=True);url=BASE+path
  if p.exists():data=p.read_bytes()
  else:data=urllib.request.urlopen(url,timeout=30).read();p.write_bytes(data)
  records.append(dict(path=path,url=url,sha256=sha(data)))
  for name in re.findall(r'^\s*#\s*include\s*"([^"]+)"',data.decode(errors='replace'),re.M):
   if posixpath.basename(name)=='params.h':continue
   queue.append(posixpath.normpath(posixpath.join(posixpath.dirname(path),name)) if name.startswith('.') else 'common/'+name)
 plan=dict(revision=REV,compile=[],runs=[],examples=[])
 build=D/'official_build';build.mkdir(exist_ok=True);inputs=D/'fixtures/inputs';inputs.mkdir(parents=True,exist_ok=True)
 for root,info in infos.items():
  short=root.rsplit('/',1)[1];params=''.join(f'constexpr auto {k} = {v};\n' for k,v in info.get('params',{}).items());(official/root/'params.h').write_text(params)
  for t in info['tests']:
   name=t['name'];stem=name.rsplit('.',1)[0]
   if name.endswith('.cpp'):
    exe=build/(short+'_'+stem);plan['compile'].append(['/usr/bin/g++','-std=c++23','-O2','-I'+str(official/'common'),'-I'+str(official/root),str(official/root/'gen'/name),'-o',str(exe)])
    for seed in range(t['number']):plan['runs'].append(dict(name=f'official_{short}_{stem}_{seed:02d}',command=[str(exe),str(seed)],output=str(inputs/f'official_{short}_{stem}_{seed:02d}.in'),generator=root+'/gen/'+name,seed=seed,problem=short,shape='all_same'if stem in ['all_same','near_power_of_2_max_same']else None))
   else:
    for seed in range(t['number']):plan['examples'].append(dict(name=f'official_{short}_{stem}_{seed:02d}',path=str(official/root/'gen'/f'{stem}_{seed:02d}.in'),problem=short))
 dump('official_generation_plan.json',plan)
 dump('official_sources.json',dict(repository='https://github.com/yosupo06/library-checker-problems',revision=REV,license='Apache-2.0',files=records,constraints={r:i.get('params',{})for r,i in infos.items()},effective_maximum_length=LIMIT,limit_note='suffixarray info.tomlのN_MAX=500000。number_of_substringsの生成器も500000上限を直接使用。',usage='外部コードはtempのみ。配布/証跡ZIPへ本文を収録しない。'))

def naive(s):
 n=len(s);sa=sorted(range(n),key=lambda i:s[i:]);lcp=[]
 for a,b in zip(sa,sa[1:]):
  k=0
  while a+k<n and b+k<n and s[a+k]==s[b+k]:k+=1
  lcp.append(k)
 return sa,n*(n+1)//2-sum(lcp)

def formula_sa(n,shape):
 if shape=='all_same':return list(range(n-1,-1,-1))
 if shape in ['alternating','periodic3']:
  p=2 if shape=='alternating'else 3
  return [i for residue in range(p) for i in range(n-1-((n-1-residue)%p),-1,-p)if i%p==residue]
 return None

def formula_substrings(n,shape):
 if shape=='all_same':return n
 if shape in ['alternating','periodic3']:
  p=2 if shape=='alternating'else 3
  return sum(min(p,n-length+1)for length in range(1,n+1))
 return None

def make(n,shape,seed):
 rng=random.Random(seed)
 if shape=='all_same':return b'a'*n
 if shape=='alternating':return (b'ab'*(n//2+1))[:n]
 if shape=='periodic3':return (b'abc'*(n//3+1))[:n]
 if shape=='random26':return bytes(97+rng.randrange(26)for _ in range(n))
 if shape=='binary':return bytes(97+rng.randrange(2)for _ in range(n))
 if shape in ['last_different','middle_different','first_different']:
  s=bytearray(b'a'*n);s[{'last_different':n-1,'middle_different':n//2,'first_different':0}[shape]]=98;return bytes(s)
 if shape=='long_palindrome':
  a=make((n+1)//2,'random26',seed);return a+a[:n//2][::-1]
 if shape=='long_runs':return ((b'a'*8191+b'b'*4097+b'c'*16383)*(n//28671+1))[:n]
 if shape=='fibonacci':
  a,b=b'a',b'ab'
  while len(b)<n:a,b=b,b+a
  return b[:n]
 if shape=='binary_carry':return bytes(97+(i.bit_count()&1)for i in range(n))
 if shape=='prefix_then_random':return b'a'*(n//2)+make(n-n//2,'random26',seed)
 raise ValueError(shape)

def row(name,path,data,source,seed=None,shape=None,problem=None):
 s=data.rstrip(b'\r\n');assert s and all(97<=c<=122 for c in s);n=len(s)
 result=dict(name=name,path=str(path),n=n,bytes=len(data),sha256=sha(data),seed=seed,source=source,shape=shape,problem=problem,within_problem_limit=n<=LIMIT,oracles={})
 if n<=128:sa,distinct=naive(s);method='independent_naive'
 else:sa=formula_sa(n,shape);distinct=formula_substrings(n,shape);method='independent_formula'
 for prog,answer in [('suffix_array',sa),('suffix_array_substrings',distinct)]:
  oracle=dict(method=method if answer is not None else 'before_after_output_comparison_only')
  if answer is not None:
   output=((' '.join(map(str,answer))if prog=='suffix_array'else str(answer))+'\n').encode();p=D/'fixtures/expected'/f'{name}.{prog}.out';p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(output);oracle.update(expected_path=str(p),expected_sha256=sha(output))
  result['oracles'][prog]=oracle
 return result

def custom():
 inputs=D/'fixtures/inputs';inputs.mkdir(parents=True,exist_ok=True);rows=[];cases=[]
 for n in [1,32,4096]:
  for shape in ['all_same','binary','periodic3']:cases.append((n,shape))
 for shape in ['all_same','random26','binary','periodic3','alternating','long_runs','last_different','middle_different','prefix_then_random','long_palindrome','fibonacci','binary_carry']:cases.append((LIMIT,shape))
 for shape in ['all_same','random26','binary','alternating','long_runs']:cases.append((1000000,shape))
 for i,(n,shape) in enumerate(cases):
  name=f'custom_{n}_{shape}';seed=416380+i;data=make(n,shape,seed)+b'\n';p=inputs/(name+'.in');p.write_bytes(data);rows.append(row(name,p,data,'self-generated',seed,shape))
 dump('custom_fixtures.json',rows);checks=0
 for n in range(1,129):
  for shape in ['all_same','alternating','periodic3']:
   sa,distinct=naive(make(n,shape,0));assert sa==formula_sa(n,shape),(n,shape,sa,formula_sa(n,shape));assert distinct==formula_substrings(n,shape);checks+=1
 dump('formula_validation.json',dict(cases=checks,status='PASS',description='SA辞書順と隣接LCPからのdistinct数を独立naiveで確認。same/periodicのSA式とdistinct式を照合。'))

def register():
 rows=read('custom_fixtures.json');plan=read('official_generation_plan.json');seen={r['sha256']:r for r in rows};aliases=[]
 raw=[]
 for e in plan['examples']:
  p=Path(e['path']);raw.append((e,p,'official-fixed-example'))
 for e in plan['runs']:
  p=Path(e['output'])
  if p.exists():raw.append((e,p,'official-fixed-generator'))
 for e,p,origin in raw:
  data=p.read_bytes();h=sha(data)
  if h in seen:
   match=seen[h];aliases.append(dict(alias=e['name'],problem=e['problem'],canonical_name=match['name'],sha256=h,path=str(p)));match.setdefault('official_aliases',[]).append(dict(name=e['name'],problem=e['problem']))
  else:
   r=row(e['name'],p,data,origin,e.get('seed'),e.get('shape'),e['problem']);rows.append(r);seen[h]=r
 # Both Verify programs accept any valid string. Deduplication is byte-exact, never inferred from code resemblance.
 assert len(rows)<=80,(len(rows),'exceeds requested cap; choose explicit subset before measurement')
 dump('fixtures.json',rows);dump('official_aliases.json',aliases)
 dump('fixture_selection.json',dict(fixture_rows=len(rows),unique_inputs=len({r['sha256']for r in rows}),custom=len(read('custom_fixtures.json')),official_raw_inputs=len(raw),deduplicated_official_inputs=len(aliases),all_inputs_used_for=['suffix_array','suffix_array_substrings'],note='同一入力の別問題・別seedはsha256でバイト同一を確認して共通化。公式ソースの類似だけでは入力一致と扱わない。自作の小入力で形状名だけ異なる同一バイト列はラベルを保ち、fixture_rowsとunique_inputsを区別する。'))
 print('fixture rows',len(rows),'unique byte inputs',len({r['sha256']for r in rows}),'official inputs registered',len(raw),'exact aliases',len(aliases))

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--fetch',action='store_true');parser.add_argument('--register-official',action='store_true');args=parser.parse_args();D.mkdir(parents=True,exist_ok=True)
 if args.fetch:fetch()
 if args.register_official:register()
 else:
  custom()
  if (D/'official_generation_plan.json').exists():register()
