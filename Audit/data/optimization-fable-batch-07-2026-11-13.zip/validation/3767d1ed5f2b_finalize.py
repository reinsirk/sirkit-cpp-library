from pathlib import Path
import json,hashlib,shutil
w=Path(__file__).resolve().parent;r=Path('/home/reinsirk/Atcoder_Env')
p=json.loads((w/'provenance.json').read_text());tests=json.loads((w/'validation_results.json').read_text());b=json.loads((w/'benchmark_results.json').read_text());timings=[row for row in b['results']if row['kind']=='timing']
assert len(tests)==128 and all(row['passed']for row in tests)
assert len(timings)==48 and all(row['output_byte_identical']for row in timings)
assert all(row['ratio_to_baseline']['selected']<1 for row in timings if row['case']!='small')
# Shared fixtures make cross-compiler/full/split result equality explicit.
outputs={}
for row in timings:
 family='gcd'if'gcd_conv'in row['id']else'lcm'if'lcm_conv'in row['id']else'and'
 outputs.setdefault((family,row['case']),set()).add(row['output_sha256'])
assert all(len(values)==1 for values in outputs.values())
selected_drivers=[]
for driver,meta in p['drivers'].items():
 identity=next(identity for identity,e in p['entries'].items()if e['driver']==driver)
 src=w/(identity+'_selected_main.cpp');dest=w/'selected_drivers'/driver;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
 assert hashlib.sha256(src.read_bytes()).hexdigest()==meta['selected_sha256']
 selected_drivers.append({'repository_path':driver,'candidate_path':str(dest),'baseline_sha256':meta['baseline_sha256'],'selected_sha256':meta['selected_sha256'],'still_current_baseline':hashlib.sha256((r/driver).read_bytes()).hexdigest()==meta['baseline_sha256']})
report={'decision':'accept_all_eight_ids','repository_files_modified':False,'fable_invoked':False,'scope':'main_only','cpu':12,'compilers':b['compilers'],'flags':'CLI C++23 O2, no extra GCC pragma for these8 current IDs. All generated mode flags held unchanged.','validation':{'all_passed':True,'primary_configurations':128,'matrix':'8ID x baseline/selected x GCC15.2/Clang21 x checked/skip x default/standard fallback','independent_bit_cases':56,'independent_gcd_lcm_cases_each':86,'independent_models':'Python arbitrary-precision naive double loops: i&j, gcd(i,j), lcm(i,j) truncated to1..n; GCD/LCM implicit input index0 remains0. Includes exponent0, asymmetric values, mod-1, zeros, nonpower integer sizes.','or_move_only_intermediate_default_skip_builds':4,'max_random_oracle':'Baseline byte match plus cross-compiler and full/split equality; no O(n^2) oracle claim for maximum random.','max_zero_and_small_oracle':'Closed form zero output and single product874787564, respectively.','results':str(w/'validation_results.json')},'decisions':[],'selected_drivers':selected_drivers,'source':p,'body_still_current':{name:hashlib.sha256((r/name).read_bytes()).hexdigest()==sha for name,sha in p['bodies'].items()},'io_still_current':hashlib.sha256((r/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest()==p['io_sha256'],'measurement_protocol':b['protocol'],'maximum_inputs':{'bitwise_elements':1<<20,'gcd_lcm_n':1000000},'correctness_notes':str(w/'correctness_notes.md'),'benchmark_results':str(w/'benchmark_results.json'),'reproduction':{name:str(w/name)for name in ['prepare.py','cases.py','large_cases.py','validate.py','benchmark.py']}}
for identity in p['ids']:
 rows=[row for row in timings if row['id']==identity];maximum=[row for row in rows if row['case']!='small'];tiny=[row for row in rows if row['case']=='small']
 report['decisions'].append({'id':identity,'decision':'accept','change':'reverse indexed read/write removes3reverse loops + move inputs'if'or_as_and'in identity else'move both by-value vector inputs','reason':'Both compilers improve maximum random/zero full-program medians and reduce peakRSS. Tiny n1 is startup dominated and retained separately.','max_selected_ratio_range':[min(row['ratio_to_baseline']['selected']for row in maximum),max(row['ratio_to_baseline']['selected']for row in maximum)],'peak_rss_saving_kib_range':[min(row['median_peak_rss_kib']['baseline']-row['median_peak_rss_kib']['selected']for row in maximum),max(row['median_peak_rss_kib']['baseline']-row['median_peak_rss_kib']['selected']for row in maximum)],'small_absolute_delta_microseconds':[{'compiler':row['compiler'],'candidate_minus_baseline_us':(row['median_ns']['selected']-row['median_ns']['baseline'])/1000,'baseline_ms':row['median_ns']['baseline']/1e6,'ratio':row['ratio_to_baseline']['selected']}for row in tiny],'measurements':rows})
reverse_rows=[row for row in timings if'or_as_and'in row['id']and row['case']!='small']
report['or_incremental_reverse_effect']={'description':'selected(reverse+move) / move_only. Extra reverse removal is not uniformly faster for maximum random: Clang split is +0.07%, otherwise about0.7..1.8% faster. Maximum zero gains about1.8..6.2%. Combined selected is faster than original baseline in every maximum row.','ratios':[{'id':row['id'],'compiler':row['compiler'],'case':row['case'],'ratio':row['reverse_move_over_move_only']}for row in reverse_rows]}
report['small_note']='Small n1 absolute changes are a few microseconds around process startup and allocation; the sole ~3.9% ratio is about30us. Maximum-case acceptance is based on directly measured full-program ratios, not sums of separate effects.'
(w/'final_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(w/'selected_drivers.json').write_text(json.dumps(selected_drivers,indent=2)+'\n')
lines=['# Zeta main候補：8IDとも採用推奨','','本体・共通I/O・設定固定。move渡し6IDとOR-as-AND reverse削除+move2IDを別に測定。root未適用。','', '| ID | compiler | 最大random比 | 最大zero比 | peak RSS random KiB baseline→selected |','| --- | --- | ---: | ---: | ---: |']
for identity in p['ids']:
 for cc in ('gcc','clang'):
  a=next(row for row in timings if(row['id'],row['compiler'],row['case'])==(identity,cc,'max_random'));z=next(row for row in timings if(row['id'],row['compiler'],row['case'])==(identity,cc,'max_zero'))
  lines.append(f"| {identity} | {cc} | {a['ratio_to_baseline']['selected']:.4f} | {z['ratio_to_baseline']['selected']:.4f} | {a['median_peak_rss_kib']['baseline']}→{a['median_peak_rss_kib']['selected']} |")
lines+=['','比は候補/現行、CPU12・GCC15.2/Clang21・C++23 O2、2warm+9交互循環。最大はbitwise2^20、GCD/LCMn=1e6。最大32測定行すべて短縮。RSS差は約7.5〜8MiB。n1 smallは起動支配の数µs〜数十µsの揺れとして別記。','', 'ORのmove-only中間も測定。reverse除去の追加分は最大randomでほぼ同等〜約1.8%短縮、最大zeroで約1.8〜6.2%短縮。コピー削減と合算した仮の短縮率は使わない。','', '8IDの128構成が独立Python愚直モデルとサンプルにPASS。移動後のa/b参照なし、全driverでutility明示、GCD/LCMのindex0=0維持。ORはexponent0・非対称値をAND愚直解へ照合。max randomはbaseline/cross-compiler/full-splitのbytes一致、zero/smallは閉形式一致。','', '採用用4driverはselected_drivers/へ保存し、対応とSHAはselected_drivers.jsonに記録。全raw・128構成コマンド・独立入力は同ディレクトリ。','']
(w/'summary.md').write_text('\n'.join(lines));print(json.dumps({'decision':report['decision'],'validation_configurations':len(tests),'maximum_timing_rows':sum(row['case']!='small'for row in timings),'selected_driver_files':len(selected_drivers),'bodies_still_current':report['body_still_current'],'report':str(w/'final_report.json')},indent=2))
