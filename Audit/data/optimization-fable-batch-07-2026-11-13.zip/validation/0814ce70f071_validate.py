from pathlib import Path
import json,subprocess,time,os
w=Path(__file__).resolve().parent;os.sched_setaffinity(0,{12})
p=json.loads((w/'provenance.json').read_text());cases=json.loads((w/'small_cases.json').read_text())
install=Path(subprocess.check_output(['/usr/bin/g++','-print-libgcc-file-name'],text=True).strip()).parent
records=[]
for identity in p['ids']:
 family='gcd'if'gcd'in identity else'lcm'if'lcm'in identity else'bit'
 for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir='+str(install)])]:
  for mode in ['checked','skip']:
   for fallback in [False,True]:
    for variant in ['baseline','selected']:
     src=w/f'{identity}_{variant}_{mode}.cpp';exe=w/f'{identity}_{variant}_{mode}_{cc}_{"fallback"if fallback else"default"}'
     cmd=[*compiler,'-std=c++23','-O2','-Wall','-Wextra']
     if fallback:cmd+=['-U__SIZEOF_INT128__','-DSIRKIT_FORCE_STANDARD_ARITHMETIC','-DSIRKIT_DISABLE_SIMD']
     cmd += [str(src),'-o',str(exe)];start=time.perf_counter();built=subprocess.run(cmd,capture_output=True,text=True);assert built.returncode==0,built.stderr
     for index,case in enumerate(cases[family]):
      run=subprocess.run([str(exe)],input=case['input'],capture_output=True,text=True,timeout=10)
      assert run.returncode==0 and run.stdout==case['expected'],(identity,cc,mode,fallback,variant,index,run.stdout,case['expected'],run.stderr)
     for sample in p['entries'][identity]['samples']:
      run=subprocess.run([str(exe)],input=sample['input'],capture_output=True,text=True,timeout=10)
      assert run.returncode==0 and run.stdout.split()==sample['output'].split(),(identity,sample,run.stdout)
     row={'id':identity,'compiler':cc,'mode':mode,'fallback':fallback,'variant':variant,'command':cmd,'passed':True,'independent_naive_cases':len(cases[family]),'samples':len(p['entries'][identity]['samples']),'diagnostics':built.stderr,'elapsed_seconds':time.perf_counter()-start}
     records.append(row);(w/'validation_results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(identity,cc,mode,'fallback'if fallback else'default','2variants PASS',flush=True)
