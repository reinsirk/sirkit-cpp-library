from pathlib import Path
import subprocess,json,hashlib
p=Path(__file__).resolve().parent
sha=lambda x:hashlib.sha256(x).hexdigest()
r={'tests':[],'codegen':[],'generation':[]}
for f in (p/'baseline/generated').rglob('*.cpp'):
 rel=f.relative_to(p/'baseline/generated');b=(p/'candidate/generated'/rel).read_bytes();r['generation'].append({'path':str(rel),'baseline_sha':sha(f.read_bytes()),'candidate_sha':sha(b),'identical':f.read_bytes()==b})
ccs=[('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]
for cc,cmd in ccs:
 for skip in [False,True]:
  for std in [False,True]:
   for v in ['baseline','candidate']:
    name=f'{cc}_{skip}_{std}_{v}';exe=p/name;header=p/v/'generated/Math/Zeta/Bitwise_Convolution.cpp'
    c=['taskset','-c','10']+cmd+['-std=c++23','-O2','-Wall','-Wextra']+(['-DSKIP_RUNTIME_CHECKS']if skip else [])+(['-DSIRKIT_DISABLE_SIMD','-U__SIZEOF_INT128__']if std else [])+[f'-DHEADER="{header}"',str(p/'check.cpp'),'-o',str(exe)]
    build=subprocess.run(c,capture_output=True,text=True,timeout=120);(p/(name+'.build.log')).write_text(build.stdout+build.stderr);assert build.returncode==0,(name,build.stderr)
    run=subprocess.run(['taskset','-c','10',str(exe)],capture_output=True,text=True,timeout=60);assert run.returncode==0,(name,run.stderr);r['tests'].append({'name':name,'command':c,'stdout':run.stdout,'returncode':run.returncode})
 for subset in [False,True]:
  for v in ['baseline','candidate','historical_compact']:
   if v=='historical_compact':header=p/'historical_compact_scalar.hpp'
   else:header=p/v/'generated/Math/Zeta/Bitwise_Convolution.cpp'
   obj=p/f'{cc}_{subset}_{v}.o';cmdline=cmd+['-std=c++23','-O2']+(['-DSUBSET_ONLY']if subset else [])+[f'-DHEADER="{header}"','-c',str(p/'proof.cpp'),'-o',str(obj)]
   subprocess.run(cmdline,capture_output=True,check=True,timeout=120);textfile=obj.with_suffix('.text');subprocess.run(['objcopy','-O','binary','-j','.text',str(obj),str(textfile)],check=True)
   r['codegen'].append({'compiler':cc,'subset':subset,'variant':v,'text_sha':sha(textfile.read_bytes()),'text_bytes':textfile.stat().st_size,'command':cmdline})
for row in r['codegen']:
 o=p/f"{row['compiler']}_{row['subset']}_{row['variant']}.o"
 asm=subprocess.check_output(['objdump','-dr',str(o)],text=True)
 asm=asm[asm.index('Disassembly of section'):]
 o.with_suffix('.asm').write_text(asm)
 row['all_code_sections_disassembly_sha']=sha(asm.encode())
(p/'checks.json').write_text(json.dumps(r,indent=2))
print(json.dumps({'tests':len(r['tests']),'status':'PASS'}))
