# Superset scalar fusion: reject

This temporary experiment changes only `Math/Zeta/components/set_transform.inc`, broadening the existing GCC-only small-type Subset fusion to Superset. The exact Superset order is `a += b; c += d; a += c; b += d`, with `-=` in the inverse. No repository file was edited.

The canonical generator is `Scripts/generate_zeta.py`. `set_transform.inc` feeds the full `Math/Zeta_Mebius.cpp`, standalone `Math/Zeta/Set_Transform.cpp`, and `Math/Zeta/Bitwise_Convolution.cpp`. The other four generated targets do not depend on it and are byte-identical. Both full component snapshots and all seven generated outputs are retained under `baseline/` and `candidate/`.

`Audit/performance-zeta-and-412847-2026-10-24.json` already rejected the same two-stage helper structure with GCC15.2 at 2^20: Superset roundtrip +26.6%, AND square +20.2%. The OR audit explicitly adopted only Subset based on these measurements. Historical sources, benchmark and scripts have been extracted as `historical_*`; the original Audit JSON retains all raw measurements. The old residual stage used an always-inline helper instead of explicit eight assignments. This is semantically equivalent but changes current GCC code generation, so old timings are not asserted to measure the exact present candidate.

To confirm applicability without repeating a previously rejected full study, the exact current candidate was checked with independent reference stages and exact interned expression trees for all powers of two 1..4096. GCC/Clang checked/skip and normal/standard fallback all passed. Subset executable-section disassembly is unchanged in both compilers. Clang Superset is also unchanged; GCC Superset differs as expected.

From this directory:

```sh
python3 check.py
python3 recheck.py
```

`check.py` needs GCC15.2 `/usr/bin/g++`, Clang21 `/usr/bin/clang++`, GCC15 standard headers, CPU10, and GNU objcopy. It compiles/runs the 16 functional configurations and creates scalar code-generation objects. `checks.json` contains those compile commands and results. The `*.asm` files and their `all_code_sections_disassembly_sha` values in the saved JSON include every executable section, not just wrapper `.text`.

`recheck.py` measures the exact current baseline/candidate with the same API harness, flags and inputs: 2 warmups plus 7 alternating repetitions pinned to CPU10. Input generation is outside timing. `recheck.json` contains raw samples and medians. Op 0 = Superset roundtrip; 2 = AND convolution; 4 = AND square. Small32, medium4096, and maximum2^20 lengths were used. Checksums agree in all comparisons. GCC medium roundtrip/square regress about10%/9%, maximum roundtrip/square about4%/5%. Maximum AND is approximately equal (ratio0.990). These are API measurements; no whole-program performance conclusion is drawn from them.

The newly saved exact-candidate measurements corroborate rejecting scalar Superset fusion. The requested broad repeated main/IO/degenerate timings were stopped at this regression gate. Existing Subset fusion and all repository sources remain unchanged. No production documentation, generation/status stage, or online submission is needed for this rejected candidate.
