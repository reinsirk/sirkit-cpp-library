from pathlib import Path
p=Path(__file__).parent;r=Path('/home/reinsirk/Atcoder_Env');s=(p/'current.hpp').read_text()
marker='template <bool Subset, bool Subtract, class T>\ninline void set_transform_scalar'
helper='''#if defined(__GNUC__) && !defined(__clang__)
template <bool Subtract, class T>
[[gnu::always_inline]] inline void set_transform_eight(T* out, T* in) {
'''
for k in range(8):helper+=f'    if constexpr (Subtract) out[{k}] -= in[{k}]; else out[{k}] += in[{k}];\n'
helper+='}\n#endif\n'
assert marker in s;s=s.replace(marker,helper+marker,1)
old='    for (std::size_t half = n >= 8 ? 8 : 1; half < n; half *= 2) {'
new='''    std::size_t half = n >= 8 ? 8 : 1;
#if defined(__GNUC__) && !defined(__clang__)
    if constexpr (std::is_trivially_copyable_v<T> && sizeof(T) <= 8) {
        // 依存する段の順序を保って2段をまとめる。
        for (; half >= 8 && half < n / 2; half *= 4) {
            for (std::size_t base = 0; base < n; base += half * 4) {
                auto* a = f.data() + base;
                auto* b = a + half;
                auto* c = b + half;
                auto* d = c + half;
                for (std::size_t j = 0; j < half; j += 8) {
                    if constexpr (Subset) {
                        set_transform_eight<Subtract>(b+j,a+j);
                        set_transform_eight<Subtract>(d+j,c+j);
                        set_transform_eight<Subtract>(c+j,a+j);
                        set_transform_eight<Subtract>(d+j,b+j);
                    } else {
                        set_transform_eight<Subtract>(a+j,b+j);
                        set_transform_eight<Subtract>(c+j,d+j);
                        set_transform_eight<Subtract>(a+j,c+j);
                        set_transform_eight<Subtract>(b+j,d+j);
                    }
                }
            }
        }
    }
#endif
    for (; half < n; half *= 2) {'''
assert s.count(old)==1;s=s.replace(old,new,1)
start=s.index('                    if constexpr (Subtract) out[j] -= in[j];');end=s.index('\n                }',start)
s=s[:start]+'                    set_transform_eight<Subtract>(out+j,in+j);'+s[end:]
(p/'compact.hpp').write_text(s);sub=(r/'Verify/current/submissions/zeta_and_split.cpp').read_text();assert (p/'current.hpp').read_text()in sub;(p/'compact_main.cpp').write_text(sub.replace((p/'current.hpp').read_text(),s,1))
# Benchmarkを小規模・他の演算・汎用型へ広げて最終採否を判断する。
scr=Path('/tmp/sirkit_zeta_and_412842/final_measure.py').read_text().replace("vs=['current','control','final']","vs=['current','control','compact']").replace("['final']","['compact']").replace("'final_measure.json'","'compact_measure.json'")
# 表示/辞書はvariant名を元に動的作成。共通benchmarkは前回と同じ。
(p/'compact_measure.py').write_text(scr)
