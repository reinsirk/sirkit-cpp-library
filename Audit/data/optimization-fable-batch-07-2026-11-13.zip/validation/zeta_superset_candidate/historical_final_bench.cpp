#include <chrono>
#include <cstdint>
#include <iostream>
#include <string>
#include <algorithm>
#include <random>
#include HEADER
struct Mod {
    std::uint32_t value = 0;
    Mod() = default;
    Mod(std::int64_t x) {
        x %= 998244353;
        if (x < 0) x += 998244353;
        value = static_cast<std::uint32_t>(x);
    }
    Mod& operator+=(Mod b) { value += b.value; if (value >= 998244353) value -= 998244353; return *this; }
    Mod& operator-=(Mod b) { if (value < b.value) value += 998244353; value -= b.value; return *this; }
    Mod& operator*=(Mod b) { value = static_cast<std::uint32_t>(std::uint64_t(value) * b.value % 998244353); return *this; }
    friend Mod operator+(Mod a, Mod b) { return a += b; }
    friend Mod operator-(Mod a, Mod b) { return a -= b; }
    friend Mod operator*(Mod a, Mod b) { return a *= b; }
    friend bool operator==(Mod, Mod) = default;
};

struct Generic64 {
    std::int64_t value=0;
    Generic64()=default; Generic64(std::int64_t v):value(v){}
    Generic64& operator+=(const Generic64& b){value+=b.value;return *this;}
    Generic64& operator-=(const Generic64& b){value-=b.value;return *this;}
    Generic64& operator*=(const Generic64& b){value*=b.value;return *this;}
    friend bool operator==(const Generic64&,const Generic64&)=default;
};
struct Big {
    std::int64_t value=0,pad[3]{};
    Big()=default; Big(std::int64_t v):value(v){}
    Big& operator+=(const Big& b){value+=b.value;return *this;}
    Big& operator-=(const Big& b){value-=b.value;return *this;}
    Big& operator*=(const Big& b){value*=b.value;return *this;}
    friend bool operator==(const Big&,const Big&)=default;
};
template<class T> std::uint64_t val(T x){if constexpr(!std::is_integral_v<T>)return x.value;else return x;}
template<class T> void run(std::size_t n,int rep,int op){
 std::vector<T> a(n),b(n);std::mt19937 rng(412842);for(std::size_t i=0;i<n;++i){if constexpr(std::is_same_v<T,Mod>){a[i]=T(rng()%998244353);b[i]=T(rng()%998244353);}else{a[i]=T((i*17+3)%7);b[i]=T((i*11+2)%7);}}
 auto old=a;
 std::uint64_t sum=0;
 auto start=std::chrono::steady_clock::now();
 for(int r=0;r<rep;++r){
  if(op==0){superset_zeta_transform(a);superset_mobius_transform(a);sum+=val(a[r%n]);}
  if(op==1){subset_zeta_transform(a);subset_mobius_transform(a);sum+=val(a[r%n]);}
  if(op==2){auto c=bitwise_and_convolution(a,b);sum+=val(c[r%n]);}
  if(op==3){auto c=bitwise_or_convolution(a,b);sum+=val(c[r%n]);}
  if(op==4){auto c=bitwise_and_square(a);sum+=val(c[r%n]);}
  if(op==5){auto c=bitwise_or_square(a);sum+=val(c[r%n]);}
 }
 auto end=std::chrono::steady_clock::now();
 if(op<2 && old!=a)std::abort();
 std::cout<<std::chrono::duration<double,std::nano>(end-start).count()/rep<<' '<<sum<<'\n';
}
int main(int argc,char**argv){(void)argc;std::string t=argv[1];auto n=std::stoull(argv[2]);auto rep=std::stoi(argv[3]);int op=std::stoi(argv[4]);if(t=="mod")run<Mod>(n,rep,op);else if(t=="generic")run<Generic64>(n,rep,op);else if(t=="big")run<Big>(n,rep,op);else if(t=="u32")run<std::uint32_t>(n,rep,op);else if(t=="i64")run<std::int64_t>(n,rep,op);}
