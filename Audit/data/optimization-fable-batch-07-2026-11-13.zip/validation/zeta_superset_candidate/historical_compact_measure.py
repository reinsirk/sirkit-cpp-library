from pathlib import Path
import subprocess,json,statistics,fcntl,resource,time,hashlib
p=Path(__file__).parent;r=Path('/home/reinsirk/Atcoder_Env');vs=['current','control','compact'];d={'status':'INCOMPLETE','builds':[],'api':{},'main':{}};sha=lambda b:hashlib.sha256(b).hexdigest();old=Path('/tmp/sirkit_zeta_and_20261022')
with open('/tmp/sirkit_performance_cpu14.lock','a')as a,open('/tmp/atcoder_full_performance_20261018/benchmark.lock','a')as b:
 fcntl.flock(a,fcntl.LOCK_EX);fcntl.flock(b,fcntl.LOCK_EX)
 for cc,args,defs in [('gcc',['/usr/bin/g++'],[]),('gcc_native',['/usr/bin/g++','-march=native'],[]),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'],[]),('gcc_standard',['/usr/bin/g++'],['-DSIRKIT_DISABLE_SIMD'])]:
  for v in vs:
   for kind in ['api','main']:
    exe=p/(cc+'_'+v+'_'+kind);cmd=['taskset','-c','6',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror',*defs,*(['-DSKIP_RUNTIME_CHECKS','-DHEADER="'+str(p/(v+'.hpp'))+'"']if kind=='api'else[]),str(p/('final_bench.cpp'if kind=='api'else v+'_main.cpp')),'-o',str(exe)];q=subprocess.run(cmd,capture_output=True,text=True);assert q.returncode==0 and not q.stderr,(cmd,q.stderr);d['builds'].append(cmd)
  for typ in ['mod','generic','big','u32','i64']:
   for n in ([1,2,8,32,256,4096,65536,1048576]if typ=='mod'else[8,256,4096,1048576]):
    for op in (range(6)if typ=='mod'else[0,1,2,3]):
     key=f'{cc}_{typ}_{n}_{op}';reps=max(2,min(100000,4000000//(n*max(1,n.bit_length()-1))));raw={v:[]for v in vs}
     for rep in range(7):
      checks=[]
      for v in vs[rep%3:]+vs[:rep%3]:
       q=subprocess.run(['taskset','-c','14',str(p/(cc+'_'+v+'_api')),typ,str(n),str(reps),str(op)],capture_output=True,text=True);assert q.returncode==0 and not q.stderr,(key,v,q.stderr);t,s=q.stdout.split();raw[v].append(float(t));checks.append(s)
      assert len(set(checks))==1,(key,checks)
     med={v:statistics.median(a)for v,a in raw.items()};d['api'][key]={'ns':raw,'medians':med};print(key,{v:round(t/med['current'],3)for v,t in med.items()},flush=True)
  if cc!='gcc_standard':
   fixtures=json.load(open(r/'Audit/verify-zeta-and-ready-2026-10-23.json'))['fixtures']
   for f in fixtures:
    case=f['name'];raw={v:[]for v in vs}
    for rep in range(9):
     for v in vs[rep%3:]+vs[:rep%3]:
      with open(f['input'],'rb')as inp,(p/'answer.out').open('wb')as out:
       before=resource.getrusage(resource.RUSAGE_CHILDREN);t=time.perf_counter_ns();q=subprocess.run(['taskset','-c','14',str(p/(cc+'_'+v+'_main'))],stdin=inp,stdout=out,stderr=subprocess.PIPE);after=resource.getrusage(resource.RUSAGE_CHILDREN);wall=(time.perf_counter_ns()-t)/1e6
      assert q.returncode==0 and not q.stderr and sha((p/'answer.out').read_bytes())==f['output_sha256'],(cc,v,case,q.stderr);raw[v].append({'cpu_ms':1000*(after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime),'wall_ms':wall})
    med={v:statistics.median(x['cpu_ms']for x in a)for v,a in raw.items()};d['main'][cc+'_'+case]={'raw':raw,'medians':med};print('main',cc,case,{v:round(t/med['current'],3)for v,t in med.items()},flush=True)
 d['status']='PASS';(p/'compact_measure.json').write_text(json.dumps(d,indent=2));print('ALL PASS',flush=True)
