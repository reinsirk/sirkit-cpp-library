#include <cstdint>
#include <iostream>
#include <map>
#include <tuple>
#include <vector>
#include <stdexcept>
#include HEADER
struct Mod { std::uint32_t value=0; Mod()=default;Mod(std::int64_t x){x%=998244353;if(x<0)x+=998244353;value=static_cast<std::uint32_t>(x);} Mod&operator+=(Mod b){value+=b.value;if(value>=998244353)value-=998244353;return *this;}Mod&operator-=(Mod b){if(value<b.value)value+=998244353;value-=b.value;return *this;}friend bool operator==(Mod,Mod)=default;};
std::map<std::tuple<bool,std::uint32_t,std::uint32_t>,std::uint32_t> nodes;
struct Trace {std::uint32_t id=0;Trace()=default;Trace(std::int64_t x):id(static_cast<std::uint32_t>(x)){} Trace& op(Trace b,bool sub){auto key=std::tuple(sub,id,b.id);auto[it,ok]=nodes.try_emplace(key,static_cast<std::uint32_t>(nodes.size()+10000));(void)ok;id=it->second;return *this;}Trace&operator+=(Trace b){return op(b,false);}Trace&operator-=(Trace b){return op(b,true);}friend bool operator==(Trace,Trace)=default;};
static_assert(std::is_trivially_copyable_v<Trace> && sizeof(Trace)<=8);
std::uint64_t seed=917;std::uint64_t rng(){seed^=seed<<13;seed^=seed>>7;return seed^=seed<<17;}
std::uint64_t checks=0;
template<bool Subset,bool Subtract,class T>void run(std::size_t n){
 std::vector<T> ref(n);for(std::size_t i=0;i<n;++i){if constexpr(std::is_same_v<T,Trace>)ref[i]=T(i+1);else if constexpr(std::is_unsigned_v<T>)ref[i]=static_cast<T>(rng());else ref[i]=T(static_cast<std::int64_t>(rng()%5)-2);}auto got=ref;
 for(std::size_t h=1;h<n;h*=2)for(std::size_t b=0;b<n;b+=h*2)for(std::size_t j=0;j<h;++j){auto&o=ref[b+j+(Subset?h:0)];auto&i=ref[b+j+(Subset?0:h)];if constexpr(Subtract)o-=i;else o+=i;}
 if constexpr(Subset && Subtract)subset_mobius_transform(got);else if constexpr(Subset)subset_zeta_transform(got);else if constexpr(Subtract)superset_mobius_transform(got);else superset_zeta_transform(got);
 if(ref!=got)throw std::runtime_error("reference mismatch");checks+=n;
}
template<class T>void types(){for(std::size_t n=1;n<=4096;n*=2){nodes.clear();run<false,false,T>(n);nodes.clear();run<false,true,T>(n);nodes.clear();run<true,false,T>(n);nodes.clear();run<true,true,T>(n);}}
int main(){types<Mod>();types<std::uint64_t>();types<std::uint32_t>();types<std::uint16_t>();types<std::uint8_t>();types<std::int64_t>();types<double>();types<Trace>();std::cout<<checks<<" PASS\n";}
