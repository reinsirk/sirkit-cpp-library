from pathlib import Path
p=Path(__file__).parent;r=Path('/home/reinsirk/Atcoder_Env');s=(r/'Math/Zeta/Bitwise_Convolution.cpp').read_text();(p/'current.hpp').write_text(s);(p/'control.hpp').write_text(s)
for count in [16,32]:
 marker='                for (; half - j >= 8; j += 8) {';assert s.count(marker)==1;new=f'                for (; half - j >= {count}; j += {count}) {{\n'
 for k in range(count):
  index='j'if k==0 else'j+'+str(k);new+=f'                    if constexpr (Subtract) out[{index}] -= in[{index}];\n                    else out[{index}] += in[{index}];\n'
 new+='                }\n'+marker;(p/f'unroll{count}.hpp').write_text(s.replace(marker,new,1))
start=s.index('    for (std::size_t half = n >= 8 ? 8 : 1; half < n; half *= 2) {');end=s.index('\n}\n}\n#endif',start);tail=s[start:end]
for block in [256,4096,16384]:
 run=tail.replace('std::size_t half = n >= 8 ? 8 : 1; half < n','std::size_t half = first; half < last',1).replace('std::size_t base = 0; base < n','std::size_t base = begin; base < limit',1)
 new='''#if defined(__GNUC__) && !defined(__clang__)
    if constexpr (std::is_trivially_copyable_v<T> && sizeof(T) <= 8) {
        if (n >= 1048576) {
            const auto run = [&](std::size_t first,std::size_t last,std::size_t begin,std::size_t limit) {
'''+run+f'''
            }};
            for (std::size_t base=0;base<n;base+={block}) run(8,{block},base,base+{block});
            run({block},n,0,n);
            return;
        }}
    }}
#endif
'''+tail;(p/f'tile{block}.hpp').write_text(s[:start]+new+s[end:])
# 最終の単独段には元の8展開ループを使う。
single=tail.replace('std::size_t half = n >= 8 ? 8 : 1; half < n; half *= 2','; half < n; half *= 2',1)
new='''#if defined(__GNUC__) && !defined(__clang__)
    if constexpr (std::is_trivially_copyable_v<T> && sizeof(T) <= 8) {
        if (n >= 32) {
            std::size_t half=8;
            for (;half<n/2;half*=4) {
                for (std::size_t base=0;base<n;base+=half*4) {
                    auto* a=f.data()+base;auto* b=a+half;auto* c=b+half;auto* d=c+half;
                    for (std::size_t j=0;j<half;j+=8) {
                        if constexpr (Subset) {
'''
for subset in [True,False]:
 if not subset:new+='                        } else {\n'
 pairs=[('b','a'),('d','c'),('c','a'),('d','b')]if subset else[('a','b'),('c','d'),('a','c'),('b','d')]
 for a,b in pairs:
  for k in range(8):
   idx='j'if k==0 else'j+'+str(k);new+=f'                            if constexpr(Subtract) {a}[{idx}]-={b}[{idx}];else {a}[{idx}]+={b}[{idx}];\n'
new+='''                        }
                    }
                }
            }
'''+single+'''
            return;
        }
    }
#endif
'''+tail
(p/'paired.hpp').write_text(s[:start]+new+s[end:])
for name in ['bench_real.cpp','final_bench.cpp']:(p/name).write_bytes((Path('/tmp/sirkit_zeta_and_412842')/name).read_bytes())
sub=(r/'Verify/current/submissions/zeta_and_split.cpp').read_text();assert s in sub
for name in ['current','control','unroll16','unroll32','tile256','tile4096','tile16384','paired']:(p/(name+'_main.cpp')).write_text(sub.replace(s,(p/(name+'.hpp')).read_text(),1))
