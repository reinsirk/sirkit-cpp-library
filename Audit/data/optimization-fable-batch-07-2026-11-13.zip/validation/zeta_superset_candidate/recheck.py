from pathlib import Path
import subprocess,json,statistics,hashlib
p=Path(__file__).resolve().parent;r={'builds':[],'cases':{}}
for v in ['baseline','candidate']:
 cmd=['/usr/bin/g++','-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS',f'-DHEADER="{p/v/"generated/Math/Zeta/Bitwise_Convolution.cpp"}"',str(p/'historical_final_bench.cpp'),'-o',str(p/(v+'_bench'))]
 subprocess.run(cmd,capture_output=True,check=True,timeout=120);r['builds'].append(cmd)
for n,ops in [(32,[0,2,4]),(4096,[0,2,4]),(1048576,[0,2,4])]:
 for op in ops:
  rep=10000 if n==32 else 100 if n==4096 else 3
  raw={v:[]for v in ['baseline','candidate']};sums=set()
  for turn in range(9):
   order=['baseline','candidate']if turn%2 else ['candidate','baseline']
   for v in order:
    cmd=['taskset','-c','10',str(p/(v+'_bench')),'mod',str(n),str(rep),str(op)]
    q=subprocess.run(cmd,capture_output=True,text=True,check=True,timeout=90);time,checksum=q.stdout.split();sums.add(checksum)
    if turn>=2:raw[v].append(float(time))
  assert len(sums)==1
  med={v:statistics.median(x)for v,x in raw.items()};r['cases'][f'mod_{n}_{op}']={'raw_ns_per_call':raw,'medians_ns_per_call':med,'ratio':med['candidate']/med['baseline'],'checksum':list(sums)}
  (p/'recheck.json').write_text(json.dumps(r,indent=2));print(n,op,r['cases'][f'mod_{n}_{op}']['ratio'],flush=True)
