#include <cstdint>
#include HEADER
struct Mod {std::uint32_t value;Mod&operator+=(Mod b){value+=b.value;if(value>=998244353)value-=998244353;return *this;}Mod&operator-=(Mod b){if(value<b.value)value+=998244353;value-=b.value;return *this;}};
#ifndef SUBSET_ONLY
extern "C" void modz(std::vector<Mod>&v){reinsirk::detail::set_transform_scalar<false,false>(v);}
extern "C" void modm(std::vector<Mod>&v){reinsirk::detail::set_transform_scalar<false,true>(v);}
extern "C" void uz(std::vector<std::uint64_t>&v){reinsirk::detail::set_transform_scalar<false,false>(v);}
extern "C" void um(std::vector<std::uint64_t>&v){reinsirk::detail::set_transform_scalar<false,true>(v);}
#else
extern "C" void modz(std::vector<Mod>&v){reinsirk::detail::set_transform_scalar<true,false>(v);}
extern "C" void modm(std::vector<Mod>&v){reinsirk::detail::set_transform_scalar<true,true>(v);}
extern "C" void uz(std::vector<std::uint64_t>&v){reinsirk::detail::set_transform_scalar<true,false>(v);}
extern "C" void um(std::vector<std::uint64_t>&v){reinsirk::detail::set_transform_scalar<true,true>(v);}
#endif
