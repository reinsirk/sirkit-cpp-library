from pathlib import Path
import subprocess,json,statistics,fcntl,resource,time,hashlib
p=Path(__file__).parent;vs=['current','control','unroll16','unroll32','tile256','tile4096','tile16384','paired'];d={'status':'INCOMPLETE','builds':[],'api':{},'main':{}};sha=lambda b:hashlib.sha256(b).hexdigest();old=Path('/tmp/sirkit_zeta_and_20261022')
with open('/tmp/sirkit_performance_cpu14.lock','a')as a,open('/tmp/atcoder_full_performance_20261018/benchmark.lock','a')as b:
 fcntl.flock(a,fcntl.LOCK_EX);fcntl.flock(b,fcntl.LOCK_EX)
 for cc,args in [('gcc',['/usr/bin/g++'])]:
  for v in vs:
   for kind in ['api','main']:
    exe=p/(cc+'_'+v+'_'+kind);cmd=['taskset','-c','6',*args,'-std=c++23','-O2','-Wall','-Wextra','-Werror','-DSKIP_RUNTIME_CHECKS',*(['-DHEADER="'+str(p/(v+'.hpp'))+'"']if kind=='api'else ['-Wno-error']),str(p/('bench_real.cpp'if kind=='api'else v+'_main.cpp')),'-o',str(exe)];q=subprocess.run(cmd,capture_output=True,text=True);assert q.returncode==0,(cmd,q.stderr);assert not q.stderr or kind=='main',q.stderr;d['builds'].append(cmd)
  for n in [8,32,256,4096,65536,262144,1048576]:
   for op in [0,2]:
    key=f'{cc}_mod_{n}_{op}';reps=max(2,min(100000,4000000//(n*max(1,n.bit_length()-1))));raw={v:[]for v in vs};checks=[]
    for rep in range(7):
     checks=[]
     for v in vs[rep%len(vs):]+vs[:rep%len(vs)]:
      q=subprocess.run(['taskset','-c','14',str(p/(cc+'_'+v+'_api')),'mod',str(n),str(reps),str(op)],capture_output=True,text=True);assert q.returncode==0 and not q.stderr,(key,v,q.stderr);t,s=q.stdout.split();raw[v].append(float(t));checks.append(s)
     assert len(set(checks))==1,(key,checks)
    med={v:statistics.median(x)for v,x in raw.items()};d['api'][key]={'ns':raw,'medians':med};print(key,{v:round(t/med['current'],3)for v,t in med.items()},flush=True)
  for case in ['random_02.in','max_random_00.in','one_hot.in','all_max.in']:
   scope='custom'if case in ['one_hot.in','all_max.in']else'official';f=old/scope/case;ref=sha((old/'reference_outputs'/(case+'.out')).read_bytes());raw={v:[]for v in vs}
   for rep in range(7):
    for v in vs[rep%len(vs):]+vs[:rep%len(vs)]:
     with f.open('rb')as inp,(p/'answer.out').open('wb')as out:
      before=resource.getrusage(resource.RUSAGE_CHILDREN);t=time.perf_counter_ns();q=subprocess.run(['taskset','-c','14',str(p/(cc+'_'+v+'_main'))],stdin=inp,stdout=out,stderr=subprocess.PIPE);after=resource.getrusage(resource.RUSAGE_CHILDREN);wall=(time.perf_counter_ns()-t)/1e6
     assert q.returncode==0 and not q.stderr and sha((p/'answer.out').read_bytes())==ref,(cc,v,case,q.stderr)
     raw[v].append({'cpu_ms':1000*(after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime),'wall_ms':wall})
   med={v:statistics.median(x['cpu_ms']for x in a)for v,a in raw.items()};d['main'][cc+'_'+case]={'raw':raw,'medians':med};print('main',cc,case,{v:round(t/med['current'],3)for v,t in med.items()},flush=True)
 d['status']='PASS';(p/'screen.json').write_text(json.dumps(d,indent=2));print('ALL PASS',flush=True)
