# Zeta main候補：8IDとも採用推奨

本体・共通I/O・設定固定。move渡し6IDとOR-as-AND reverse削除+move2IDを別に測定。root未適用。

| ID | compiler | 最大random比 | 最大zero比 | peak RSS random KiB baseline→selected |
| --- | --- | ---: | ---: | ---: |
| zeta_and_full | gcc | 0.9137 | 0.8689 | 20204→12012 |
| zeta_and_full | clang | 0.9469 | 0.8449 | 20204→12012 |
| zeta_and_split | gcc | 0.9090 | 0.8661 | 20204→12012 |
| zeta_and_split | clang | 0.9373 | 0.8592 | 20204→12012 |
| zeta_or_as_and_full | gcc | 0.8887 | 0.8121 | 20204→12012 |
| zeta_or_as_and_full | clang | 0.8951 | 0.8282 | 20204→12012 |
| zeta_or_as_and_split | gcc | 0.9062 | 0.8053 | 20204→12012 |
| zeta_or_as_and_split | clang | 0.8958 | 0.8318 | 20204→12012 |
| zeta_gcd_conv_full | gcc | 0.9292 | 0.8840 | 23776→16076 |
| zeta_gcd_conv_full | clang | 0.9082 | 0.8919 | 23788→16108 |
| zeta_gcd_conv_split | gcc | 0.9212 | 0.8687 | 23788→16108 |
| zeta_gcd_conv_split | clang | 0.9079 | 0.8764 | 23788→16108 |
| zeta_lcm_conv_full | gcc | 0.9287 | 0.8767 | 23788→16108 |
| zeta_lcm_conv_full | clang | 0.9054 | 0.8994 | 23788→16108 |
| zeta_lcm_conv_split | gcc | 0.9240 | 0.8798 | 23788→16108 |
| zeta_lcm_conv_split | clang | 0.9030 | 0.9002 | 23788→16096 |

比は候補/現行、CPU12・GCC15.2/Clang21・C++23 O2、2warm+9交互循環。最大はbitwise2^20、GCD/LCMn=1e6。最大32測定行すべて短縮。RSS差は約7.5〜8MiB。n1 smallは起動支配の数µs〜数十µsの揺れとして別記。

ORのmove-only中間も測定。reverse除去の追加分は最大randomでほぼ同等〜約1.8%短縮、最大zeroで約1.8〜6.2%短縮。コピー削減と合算した仮の短縮率は使わない。

8IDの128構成が独立Python愚直モデルとサンプルにPASS。移動後のa/b参照なし、全driverでutility明示、GCD/LCMのindex0=0維持。ORはexponent0・非対称値をAND愚直解へ照合。max randomはbaseline/cross-compiler/full-splitのbytes一致、zero/smallは閉形式一致。

採用用4driverはselected_drivers/へ保存し、対応とSHAはselected_drivers.jsonに記録。全raw・128構成コマンド・独立入力は同ディレクトリ。
