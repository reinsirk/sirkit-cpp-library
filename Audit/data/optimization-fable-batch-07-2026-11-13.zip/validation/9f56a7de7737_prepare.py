from pathlib import Path
import sys,json,hashlib,difflib
r=Path('/home/reinsirk/Atcoder_Env');w=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'Scripts'));import prepare_verify as pv
ids=[family+'_'+form for family in ['zeta_and','zeta_or_as_and','zeta_gcd_conv','zeta_lcm_conv']for form in ['full','split']]
entries={e['id']:e for e in pv.collect()};report={'scope':'main_only','ids':ids,'entries':{},'bodies':{},'drivers':{},'sources':{},'io_sha256':hashlib.sha256((r/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest()}
for identity in ids:
 entry=entries[identity];base=(r/entry['driver']).read_text();family=identity.rsplit('_',1)[0]
 if '#include <utility>'not in base:base=base.replace('#include <vector>','#include <utility>\n#include <vector>')
 if family=='zeta_or_as_and':api='bitwise_or_convolution'
 elif family=='zeta_and':api='bitwise_and_convolution'
 elif family=='zeta_gcd_conv':api='gcd_convolution'
 else:api='lcm_convolution'
 move=base.replace(api+'(a, b',api+'(std::move(a), std::move(b)');assert move!=base
 selected=move
 if family=='zeta_or_as_and':
  selected=selected.replace('for (auto& x : a) verify_in >> x.value;', 'for (std::size_t i = n; i-- > 0;) verify_in >> a[i].value;')
  selected=selected.replace('for (auto& x : b) verify_in >> x.value;', 'for (std::size_t i = n; i-- > 0;) verify_in >> b[i].value;')
  selected=selected.replace('    std::reverse(a.begin(), a.end()); std::reverse(b.begin(), b.end());\n','')
  selected=selected.replace('    std::reverse(c.begin(), c.end());\n','')
  selected=selected.replace("for (std::size_t i = 0; i < n; ++i) verify_out << c[i].value << ' ';", "for (std::size_t i = n; i-- > 0;) verify_out << c[i].value << ' ';")
  assert 'std::reverse'not in selected
 body={name:(r/name).read_bytes()for name in entry['libraries']}
 for name,data in body.items():
  report['bodies'][name]=hashlib.sha256(data).hexdigest();dest=w/'bodies'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 report['entries'][identity]=entry;report['drivers'][entry['driver']]={'baseline_sha256':hashlib.sha256(base.encode()).hexdigest(),'selected_sha256':hashlib.sha256(selected.encode()).hexdigest()}
 (w/(identity+'_baseline_main.cpp')).write_text(base);(w/(identity+'_selected_main.cpp')).write_text(selected)
 (w/(identity+'.patch')).write_text(''.join(difflib.unified_diff(base.splitlines(True),selected.splitlines(True),fromfile=entry['driver'],tofile=entry['driver'])))
 variants={'baseline':base,'selected':selected}
 if family=='zeta_or_as_and':variants['move_only']=move;(w/(identity+'_move_only_main.cpp')).write_text(move)
 for variant,driver in variants.items():
  for mode,skip in [('checked',False),('skip',True)]:
   data,_=pv.render(entry,source_overrides=body,driver_override=driver,skip_runtime_checks=skip)
   name=identity+'_'+variant+'_'+mode+'.cpp';(w/name).write_bytes(data);report['sources'][name]=hashlib.sha256(data).hexdigest()
(w/'provenance.json').write_text(json.dumps(report,indent=2)+'\n')
