from pathlib import Path
import json,subprocess,time,statistics,hashlib,shutil,os
w=Path(__file__).resolve().parent;os.sched_setaffinity(0,{12})
p=json.loads((w/'provenance.json').read_text());inputs=json.loads((w/'inputs/manifest.json').read_text());small=json.loads((w/'small_cases.json').read_text())
install=Path(subprocess.check_output(['/usr/bin/g++','-print-libgcc-file-name'],text=True).strip()).parent
records=[];report={'cpu':12,'scope':'main_only; frozen library bodies, same shared IO and actual generated compiler settings. OR has intermediate move_only to separate reverse-loop removal from ownership transfer.','protocol':'2warm+9 cyclic interleaved samples, same executable pathname; RSS3 separate invocations/variant/case. End-to-end includes startup/input/output.','compilers':{cc:subprocess.check_output([path,'--version'],text=True).splitlines()[0]for cc,path in [('gcc','/usr/bin/g++'),('clang','/usr/bin/clang++')]},'results':records}
def sha(data):return hashlib.sha256(data).hexdigest()
def save():(w/'benchmark_results.json').write_text(json.dumps(report,indent=2)+'\n')
for identity in p['ids']:
 is_or='or_as_and'in identity;family='integer'if'gcd_conv'in identity or'lcm_conv'in identity else'bit'
 variants=['baseline','selected']+(['move_only']if is_or else[])
 for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir='+str(install)])]:
  bins={name:w/f'{identity}_{name}_skip_{cc}_default'for name in variants}
  if is_or:
   src=w/f'{identity}_move_only_skip.cpp';cmd=[*compiler,'-std=c++23','-O2','-Wall','-Wextra',str(src),'-o',str(bins['move_only'])]
   built=subprocess.run(cmd,capture_output=True,text=True);assert built.returncode==0,built.stderr
   for case in small['bit']:
    run=subprocess.run([str(bins['move_only'])],input=case['input'],capture_output=True,text=True);assert run.returncode==0 and run.stdout==case['expected']
   records.append({'kind':'intermediate_build','id':identity,'compiler':cc,'command':cmd,'source_sha256':sha(src.read_bytes()),'independent_cases':len(small['bit']),'passed':True})
  for item in [x for x in inputs if x['family']==family]:
   inp=Path(item['path']);outputs={}
   for name,exe in bins.items():
    with inp.open('rb')as fi:run=subprocess.run([str(exe)],stdin=fi,capture_output=True,timeout=30)
    assert run.returncode==0,run.stderr;outputs[name]=run.stdout
   assert len(set(outputs.values()))==1,(identity,cc,inp,'output mismatch')
   if item['kind']=='max_zero':assert outputs['baseline']==b'0 '*item['n']+b'\n'
   if item['kind']=='small':assert outputs['baseline']==b'874787564 \n'
   raw={name:[]for name in bins};names=list(bins)
   for rep in range(11):
    offset=rep%len(names);order=names[offset:]+names[:offset]
    for name in order:
     active=w/'active';shutil.copyfile(bins[name],active);active.chmod(0o755)
     with inp.open('rb')as fi,open('/dev/null','wb')as fo:
      start=time.perf_counter_ns();run=subprocess.run([str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
     assert run.returncode==0,run.stderr
     if rep>=2:raw[name].append(elapsed)
   rss={}
   for name,exe in bins.items():
    values=[]
    for _ in range(3):
     with inp.open('rb')as fi:run=subprocess.run(['/usr/bin/time','-f','%M',str(exe)],stdin=fi,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
     assert run.returncode==0,run.stderr;values.append(int(run.stderr.strip()))
    rss[name]=values
   med={name:statistics.median(values)for name,values in raw.items()}
   row={'kind':'timing','id':identity,'compiler':cc,'case':item['kind'],'n':item['n'],'input_sha256':item['sha256'],'output_sha256':sha(outputs['baseline']),'output_byte_identical':True,'raw_ns':raw,'median_ns':med,'ratio_to_baseline':{name:value/med['baseline']for name,value in med.items()},'peak_rss_kib':rss,'median_peak_rss_kib':{name:statistics.median(values)for name,values in rss.items()}}
   if is_or:row['reverse_move_over_move_only']=med['selected']/med['move_only']
   records.append(row);save();print(identity,cc,item['kind'],'ratios',{k:round(v,4)for k,v in row['ratio_to_baseline'].items()},'RSS',row['median_peak_rss_kib'],flush=True)
