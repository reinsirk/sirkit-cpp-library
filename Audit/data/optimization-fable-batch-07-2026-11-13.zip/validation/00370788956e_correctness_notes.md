# main限定の変更

AND/GCD/LCMの各APIはvector<T>を値で受ける。std::move(a),std::move(b)は別々の入力vectorの領域をそれぞれ引き渡すだけで、入力値と計算順は変えない。mainは呼出し後にa/bを参照せず、保存済みnと結果cだけを使う。移動元の破棄は有効で、非所有参照を残さない。全driverの<utility>は既に明示済み。

GCD/LCMはvector(n+1)のVerifyMod998がvalue=0で初期化され、読み込む添字は1..nのまま。a[0]=b[0]=0も領域移譲でそのまま保持する。IntegerSieveはnから独立に構築し、移動元配列を参照しない。

OR-as-ANDでn=2^e、M=n-1とするとreverseの添字変換はR(i)=M xor i=n-1-i。入力を逆順添字へ直接読み込めばA'[u]=A[R(u)]となる。OR結果DについてD[R(i)]を順に出力すると、R(p)|R(q)=R(p&q)によりAND結果C[i]となる。元のreverse(A),reverse(B),reverse(D)と同じ対応で、非対称値を含む愚直ANDモデルへ照合する。

e=0ではn=1でR(0)=0。size_tのfor(i=n;i-->0;)はi=0の本体を1回だけ実行し、終了判定時の符号なしwrapは定義済みで、その値では本体を実行しない。入力/出力順以外のバッチ化や計算の並べ替えは加えない。

正しさは8IDすべてでbaseline/selected×GCC15.2/Clang21×checked/skip×default/標準fallbackの128構成を実行。AND/OR-as-ANDは指数0..7とrandom、非対称、mod-1、zeroの56例を愚直二重ループへ照合する。GCD/LCMは正の添字1..nとindex0=0を使う愚直gcd/lcm二重ループ86例（n1と境界31/32/33/63/64/65、切り捨てを含む）へ照合する。

最大2^20 / n=1e6のrandom、zero、n1 smallで全main比較とRSSを測定。ORのmove-only中間を別に測り、reverse除去による追加効果を区別する。全体時間には入力・出力・起動を含み、ライブラリ本体の効果とは数えない。
