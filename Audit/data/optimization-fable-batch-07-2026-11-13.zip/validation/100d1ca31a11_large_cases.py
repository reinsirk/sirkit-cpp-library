from pathlib import Path
import random,json,hashlib
w=Path(__file__).resolve().parent/'inputs';w.mkdir(exist_ok=True)
rng=random.Random(0xC07A)
records=[]
for family,header,n in [('bit',20,1<<20),('integer',1000000,1000000)]:
 for kind in ['random','zero']:
  path=w/(family+'_max_'+kind+'.in')
  with path.open('w')as f:
   f.write(str(header)+'\n')
   for _ in range(2):
    if kind=='zero':f.write('0 '*n+'\n')
    else:
     for begin in range(0,n,8192):f.write(' '.join(str(rng.randrange(998244353))for _ in range(min(8192,n-begin)))+' ')
     f.write('\n')
  records.append({'family':family,'kind':'max_'+kind,'path':str(path),'n':n,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
for family,header,n in [('bit',0,1),('integer',1,1)]:
 path=w/(family+'_small.in');path.write_text(str(header)+'\n998244352\n123456789\n')
 records.append({'family':family,'kind':'small','path':str(path),'n':n,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(w/'manifest.json').write_text(json.dumps(records,indent=2)+'\n');print('inputs',len(records),flush=True)
