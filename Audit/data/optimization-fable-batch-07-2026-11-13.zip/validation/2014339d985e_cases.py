from pathlib import Path
import json,math,random
w=Path(__file__).resolve().parent;mod=998244353;rng=random.Random(0x2E7A07)
def text(a,b,size):return (str(size)+'\n'+' '.join(map(str,a))+'\n'+' '.join(map(str,b))+'\n').encode()
def expected(family,a,b):
 if family=='bit':
  out=[0]*len(a)
  for i,x in enumerate(a):
   for j,y in enumerate(b):out[i&j]=(out[i&j]+x*y)%mod
 else:
  n=len(a);out=[0]*(n+1)
  for i,x in enumerate(a,1):
   for j,y in enumerate(b,1):
    k=math.gcd(i,j)if family=='gcd'else math.lcm(i,j)
    if k<=n:out[k]=(out[k]+x*y)%mod
  out=out[1:]
 return (''.join(str(x)+' 'for x in out)+'\n').encode()
small={family:[]for family in ['bit','gcd','lcm']}
for exponent in range(8):
 n=1<<exponent
 patterns=[([rng.randrange(mod)for _ in range(n)],[rng.randrange(mod)for _ in range(n)]),([(i*i+3*i+1)%mod for i in range(n)],[(5*i*i+7)%mod for i in range(n)]),([0]*n,[mod-1]*n),([mod-1]*n,[mod-1]*n)]
 for a,b in patterns:small['bit'].append({'input':text(a,b,exponent).decode(),'expected':expected('bit',a,b).decode()})
for _ in range(24):
 exponent=rng.randrange(7);n=1<<exponent;a=[rng.randrange(mod)for _ in range(n)];b=[rng.randrange(mod)for _ in range(n)]
 small['bit'].append({'input':text(a,b,exponent).decode(),'expected':expected('bit',a,b).decode()})
for n in list(range(1,17))+[31,32,33,63,64,65]:
 for a,b in [([(i*i+1)%mod for i in range(n)],[(7*i+3)%mod for i in range(n)]),([mod-1]*n,[mod-1]*n),([0]*n,[mod-1]*n)]:
  for family in ['gcd','lcm']:small[family].append({'input':text(a,b,n).decode(),'expected':expected(family,a,b).decode()})
for _ in range(20):
 n=rng.randrange(1,65);a=[rng.randrange(mod)for _ in range(n)];b=[rng.randrange(mod)for _ in range(n)]
 for family in ['gcd','lcm']:small[family].append({'input':text(a,b,n).decode(),'expected':expected(family,a,b).decode()})
(w/'small_cases.json').write_text(json.dumps(small,indent=2)+'\n')
print('small cases',{k:len(v)for k,v in small.items()},flush=True)
