# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,subprocess,shutil,os,sys
D=Path('/tmp/sirkit_lowlink_416596');sys.path.insert(0,str(D/'fixtures'));from canonical import canonical_sha256
fixtures=json.loads((D/'fixtures/fixtures.json').read_text());cache={}
def activate(path):shutil.copyfile(path,D/'active');(D/'active').chmod(0o700)
def run_whole(cc,label,f,flag='native'):
 identifier='low_link_two_edge'if f['problem']=='two_edge_connected_components'else'low_link_biconnected';activate(D/f'{cc}_{flag}_{label}_{identifier}')
 with Path(f['path']).open('rb')as fi,(D/'output').open('wb')as fo:
  p=subprocess.Popen(['setarch','x86_64','-R','taskset','-c','12',str(D/'active')],stdin=fi,stdout=fo);_,status,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status);assert p.returncode==0
 data=(D/'output').read_bytes();raw=hashlib.sha256(data).hexdigest();key=(f['id'],raw)
 if key not in cache:
  actual=canonical_sha256(data,f['n'],f['problem']);assert actual==f['expected_canonical_sha256'],(cc,label,f['id'],actual);cache[key]=actual
 return dict(cpu_ns=round((ru.ru_utime+ru.ru_stime)*1e9),output_sha256=raw,canonical_sha256=cache[key],peak_rss_kib=ru.ru_maxrss)
