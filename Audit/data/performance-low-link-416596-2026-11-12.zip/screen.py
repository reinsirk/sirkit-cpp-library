# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import bench,random,json,statistics,fcntl
D=Path('/tmp/sirkit_lowlink_416596');rng=random.Random(416583582);labels=['overwrite_incident','block_suffix','block_suffix_single'];raw=[];summary=[]
names=['official_two_edge_connected_components_max_random_00','official_biconnected_components_max_random_00','official_biconnected_components_max_tree_00','custom_star100k','custom_cycle100k','custom_disjoint_cliques100k'];fixtures=[f for f in bench.fixtures if f['name']in names]
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for cc in ['gcc','clang']:
  for f in fixtures:
   local=[];order=[l for l in labels for _ in range(3)]+['control']*3;rng.shuffle(order)
   for rep,label in enumerate(order):
    v=[bench.run_whole(cc,k,f)for k in ['base',label if label!='control'else'base','base']];assert len({r['canonical_sha256']for r in v})==1;b,t,a=[r['cpu_ns']for r in v];drift=max(b,a)/min(b,a);r=dict(compiler=cc,case=f['id'],label=label,rep=rep,before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]));raw.append(r);local.append(r)
   ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in labels+['control']};row=dict(compiler=cc,case=f['id'],ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},valid_counts={l:len(v)for l,v in ratios.items()});summary.append(row);print(row,flush=True);(D/'screen_raw.json').write_text(json.dumps(raw));(D/'screen_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
