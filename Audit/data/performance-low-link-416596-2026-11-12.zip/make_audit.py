# SPDX-License-Identifier: CC0-1.0
# 完了済みの最終版の証跡を/tmpへ作る。リポジトリへの公開は呼出し側が行う。
from pathlib import Path
from collections import defaultdict
import difflib, hashlib, json, math, statistics, zipfile

R = Path('/home/reinsirk/Atcoder_Env')
D = Path('/tmp/sirkit_lowlink_416596')
LIBRARY = 'Graph/Low_Link.cpp'
PERFORMANCE = 'Audit/performance-low-link-416596-2026-11-12.json'
ONLINE = 'Audit/online-low-link-416596-2026-11-12.json'
EVIDENCE = 'Audit/data/performance-low-link-416596-2026-11-12.zip'
PREVIOUS = 'Audit/distribution-manifest-before-low-link-416596-2026-11-12.json'
JOBS = {'low_link_two_edge': (416596, 42), 'low_link_biconnected': (416595, 210)}
OP_NAMES = {0: 'build(false)', 1: 'build(true)', 2: 'rebuild(false)', 3: 'rebuild(true)',
            4: 'two_edge_components', 5: 'biconnected_vertex_components(true)',
            6: 'biconnected_vertex_components(false)', 7: 'bridge_forest'}



def load(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def encode(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + '\n'


def qualified(row):
    return (row['valid_counts']['final'] >= 5 and row['valid_counts']['control'] >= 2
            and row['ratios']['final'] is not None and row['ratios']['control'] is not None)


def signature(row):
    return (row['compiler'], row['flag'], row['setting'],
            json.dumps(row['case'], sort_keys=True, separators=(',', ':')))


def compact_stats(rows, fields):
    result = []
    for key in sorted({tuple(row[k] for k in fields) for row in rows}):
        group = [row for row in rows if tuple(row[k] for k in fields) == key]
        valid = [row for row in group if qualified(row)]
        row = dict(zip(fields, key)) | dict(cells=len(group), qualified_cells=len(valid))
        if valid:
            row.update(candidate_ratio=math.exp(statistics.mean(math.log(x['ratios']['final']) for x in valid)),
                       identical_control_ratio=math.exp(statistics.mean(math.log(x['ratios']['control']) for x in valid)),
                       minimum_ratio=min(x['ratios']['final'] for x in valid),
                       maximum_ratio=max(x['ratios']['final'] for x in valid))
        result.append(row)
    return result


def measurements(kind, fixtures, prefix="final"):
    jobs = load(D / f'final_{kind}_jobs.json')
    summary = load(D / f'{prefix}_{kind}_summary.json')
    raw = load(D / f'{prefix}_{kind}_raw.json')
    assert jobs and len(jobs) == len(summary) and raw, (kind, '未完了')
    expected = set()
    for job in jobs:
        copy = dict(job)
        if kind == 'whole': copy['case'] = job['case']['id']
        key = signature(copy)
        assert key not in expected, (kind, '重複job', key)
        expected.add(key)
    assert {signature(x) for x in summary} == expected
    assert len({signature(x) for x in summary}) == len(summary)
    grouped = defaultdict(list)
    for row in raw:
        key = signature(row)
        assert key in expected and row['label'] in {'final', 'control'}
        values = [row[k] for k in ['before', 'target', 'after']]
        times = [x['cpu_ns'] for x in values]
        assert all(t > 0 for t in times)
        drift = max(times[0], times[2]) / min(times[0], times[2])
        assert row['calibration_valid'] == (drift <= 1.10)
        assert math.isclose(row['reference_drift'], drift, rel_tol=1e-12)
        assert math.isclose(row['ratio'], times[1] / statistics.median([times[0], times[2]]), rel_tol=1e-12)
        if kind == 'whole':
            correct = fixtures[row['case']]['expected_canonical_sha256']
            assert all(x['canonical_sha256'] == correct for x in values)
        else:
            assert len({x['digest'] for x in values}) == 1
        grouped[key].append(row)
    for row in summary:
        samples = grouped[signature(row)]
        for label in ['final', 'control']:
            ratios = [x['ratio'] for x in samples if x['label'] == label and x['calibration_valid']]
            assert row['valid_counts'][label] == len(ratios)
            assert (row['ratios'][label] is None) == (not ratios)
            if ratios: assert math.isclose(row['ratios'][label], statistics.median(ratios), rel_tol=1e-12)
        assert row['sufficient'] == qualified(row)
    assert {x['compiler'] for x in summary} == {'gcc', 'clang'}
    # 基準未達の条件も削除せず記録する。採用根拠が全て未達なら処理を止める。
    assert all(any(qualified(x) and x['compiler'] == cc for x in summary) for cc in ['gcc', 'clang'])
    return jobs, summary, raw


def validate_repair(fixtures):
    def reasons(row):
        # 実行producerと同じ条件を、凍結した初期中央値だけに適用する。
        control, candidate = row['ratios']['control'], row['ratios']['final']
        assert control is not None and candidate is not None, 'repair producerの中央値比較には数値が必要'
        result = []
        if abs(control - 1) > .03:
            result.append('identical-control median outside +/-3%')
        if candidate > 1.03:
            result.append('possible regression above 3%')
        if not row['sufficient']:
            result.append('insufficient valid samples')
        return result

    def saved_key(row):
        fields = row['signature']
        assert len(fields) == 4
        case = json.loads(fields[3])
        return row['kind'], (fields[0], fields[1], fields[2], json.dumps(case, sort_keys=True, separators=(',', ':')))

    kinds, expected_order, expected_initial = {}, [], {}
    for kind in ['whole', 'core']:
        jobs, initial_summary, initial_raw = measurements(kind, fixtures, prefix='initial_final')
        assert all('phase' not in row for row in initial_raw), '初期rawへ追加phaseが混在している'
        initial_by_key = {signature(row): row for row in initial_summary}
        selected_keys = set()
        for job in jobs:
            copied = dict(job)
            if kind == 'whole':
                copied['case'] = job['case']['id']
            key = signature(copied)
            initial = initial_by_key[key]
            selected_reasons = reasons(initial)
            if selected_reasons:
                full_key = kind, key
                expected_order.append(full_key)
                expected_initial[full_key] = dict(row=initial, reasons=selected_reasons)
                selected_keys.add(key)
        current_raw = load(D / f'final_{kind}_raw.json')
        current_summary = load(D / f'final_{kind}_summary.json')
        assert current_raw[:len(initial_raw)] == initial_raw, '初期tripletを削除・変更・並べ替えしない'
        extra = current_raw[len(initial_raw):]
        assert len(extra) == len(selected_keys) * 10, '対象セルごとに7候補+3対照を一度だけ追加する'
        assert all(row.get('phase') == 'supplemental_all_samples_retained' for row in extra)
        grouped = defaultdict(list)
        for row in extra:
            key = signature(row)
            assert key in selected_keys, '選択条件に該当しないセルへの追加'
            grouped[key].append(row)
        assert set(grouped) == selected_keys
        initial_groups = defaultdict(list)
        for row in initial_raw:
            initial_groups[signature(row)].append(row)
        for key in selected_keys:
            added = grouped[key]
            for label, count in [('final', 7), ('control', 3)]:
                added_label = [row for row in added if row['label'] == label]
                assert len(added_label) == count
                old_reps = [row['rep'] for row in initial_groups[key] if row['label'] == label]
                first = max(old_reps, default=0) + 1
                assert [row['rep'] for row in added_label] == list(range(first, first + count))
        # 最終中央値はmeasurements('whole'/'core')が初期+追加全rawから再計算して照合する。
        current_by_key = {signature(row): row for row in current_summary}
        for key, initial in initial_by_key.items():
            if key not in selected_keys:
                assert current_by_key[key] == initial, '未選択セルのsummaryを書き換えない'
        kinds[kind] = dict(selected_cells=len(selected_keys), initial_triplets=len(initial_raw),
                           added_triplets=len(extra), combined_triplets=len(current_raw),
                           initial_raw=f'initial_final_{kind}_raw.json', initial_raw_sha256=sha(D / f'initial_final_{kind}_raw.json'),
                           initial_summary=f'initial_final_{kind}_summary.json', initial_summary_sha256=sha(D / f'initial_final_{kind}_summary.json'))
    selection_path = D / 'repair_selection.json'
    selected = load(selection_path) if selection_path.exists() else []
    assert [saved_key(row) for row in selected] == expected_order, '初期条件から機械的に得た全対象とrepair_selectionが不一致'
    for row in selected:
        expected = expected_initial[saved_key(row)]
        assert row['reason'] == expected['reasons']
        assert row['initial'] == expected['row'], 'selection.initialはimmutable初期snapshotと一致させる'
    correction = None
    before_fix = D / 'repair_selection_before_snapshot_fix.json'
    if before_fix.exists():
        original = load(before_fix)
        assert len(original) == len(selected)
        restored = 0
        for old, current in zip(original, selected):
            assert {key: value for key, value in old.items() if key != 'initial'} == {
                key: value for key, value in current.items() if key != 'initial'}, '修正はinitial参照の凍結だけに限る'
            restored += old['initial'] != current['initial']
        correction = dict(before_file=before_fix.name, before_sha256=sha(before_fix), restored_initial_rows=restored,
                          scope='producerのsummary行参照により後から変わったinitial記録を、immutable初期snapshotから復元。試行・時刻・raw・選択条件・理由は変更しない。',
                          fix_records={path.name: sha(path) for path in D.glob('repair*fix*.json') if path != before_fix})
    remaining = [dict(kind=kind, **row) for kind in ['whole', 'core']
                 for row in load(D / f'final_{kind}_summary.json')]
    return dict(script='repair_measurements.py', script_sha256=sha(D / 'repair_measurements.py'),
                selection='repair_selection.json' if selection_path.exists() else None,
                selection_sha256=sha(selection_path) if selection_path.exists() else None,
                selected_cells=len(selected), by_kind=kinds, snapshot_record_correction=correction,
                remaining_control_outside_three_percent=[row for row in remaining if row['ratios']['control'] is not None and abs(row['ratios']['control'] - 1) > .03],
                remaining_candidate_above_three_percent=[row for row in remaining if row['ratios']['final'] is not None and row['ratios']['final'] > 1.03],
                remaining_insufficient_cells=[row for row in remaining if not qualified(row)],
                selection_rule='初期control中央値が1±3%の外、または初期final中央値>1.03、または有効候補5組/対照2組未達の全セル。初期値だけで一度決める。',
                supplemental_protocol='各選択セルへ候補7組+同一対照3組を一度だけ追加。全初期行と全追加行を保持し、両端差10%以内という同じ基準で統合中央値を計算。候補の時間を理由に個別trialを除外せず、選び直し・追加phaseの反復をしない。',
                scope='機械的な再確認対象と全raw保持の検証。再確認の実施や有効数充足は採用を意味しない。採否は統合結果とfinal_selectionで別に判断する。')


FROZEN_PUBLIC = ['Verify/current/drivers/low_link_two_edge_main.cpp',
                 'Verify/current/drivers/low_link_biconnected_main.cpp',
                 'Verify/current/common/fast_io.hpp', 'Examples/low_link_example.cpp', 'Document/low_link.md']
DOCUMENT = 'Document/low_link.md'
FIXTURE_METADATA = {'fixtures.json', 'summary.json', 'source_audit.json', 'commands.json', 'validation.json'}
FIXTURE_OWN_SOURCES = {'canonical.py', 'oracle.cpp'}


def validate_final(after):
    value = load(D / 'final_validation.json')
    assert value['header_sha256'] == after and value['all_passed'] and value['completed_at_utc']
    rows = value['jobs']
    assert value['total_jobs'] == value['completed_jobs'] == value['passed_jobs'] == len(rows)
    tests = {'new_low_link_reference_test', 'new_graph2_allocation_test', 'low_link_components_allocation_test'}
    expected = {(cc, setting, mode, test) for cc in ['gcc', 'clang']
                for setting in ['checked', 'skip'] for mode in ['default', 'forced_wide'] for test in tests}
    plain = [row for row in rows if not row['sanitizer']]
    sanitized = [row for row in rows if row['sanitizer']]
    assert len(plain) == len(expected) and {(row['compiler'], row['setting'], row['mode'], row['test']) for row in plain} == expected
    expected_san = {(cc, setting, mode, 'new_low_link_reference_test') for cc in ['gcc', 'clang']
                    for setting in ['checked', 'skip'] for mode in ['default', 'forced_wide']}
    assert len(sanitized) == len(expected_san) and {(row['compiler'], row['setting'], row['mode'], row['test']) for row in sanitized} == expected_san
    assert value['forced_wide_conditions']['edge_ids']['count'] == 1
    assert value['forced_wide_conditions']['block_stamps']['count'] == 1
    wide = D / 'validation_forced_wide.hpp'
    assert sha(wide) == value['forced_wide_header_sha256']
    text = (D / 'final.hpp').read_text()
    for condition in value['forced_wide_conditions'].values():
        assert text.count(condition['expression']) == condition['count'] and condition['replacement'] == 'false'
        text = text.replace(condition['expression'], condition['replacement'])
    assert text == wide.read_text()
    for name, expected_hash in value['support_source_hashes'].items():
        assert sha(R / name) == expected_hash
    allocation = []
    for row in rows:
        assert row['status'] == 'passed' and row['passed'] and row['compile_returncode'] == row['returncode'] == 0 and not row['stderr']
        assert sha(Path(row['source'])) == row['test_sha256']
        expected_hash = after if row['mode'] == 'default' else value['forced_wide_header_sha256']
        assert row['header_sha256'] == expected_hash
        assert sha(Path(row['executable'])) == row['executable_sha256']
        assert f'-DLOW_LINK_SOURCE="{row["header"]}"' in row['command']
        assert ('-DSKIP_RUNTIME_CHECKS' in row['command']) == (row['setting'] == 'skip')
        if row['test'] == 'new_low_link_reference_test':
            assert row['counters']['checks'] > 0
            if not row['sanitizer']:
                assert '-pedantic-errors' in row['command']
        else:
            assert row['counters']['failures'] > 0 and row['counters']['successes'] > 0 and row['counters']['live_delta'] == 0
            allocation.append(dict(test=row['test'], compiler=row['compiler'], setting=row['setting'], mode=row['mode'], **row['counters']))
    return value, allocation


def validate_builds(before, after):
    rows = load(D / 'final_builds.json')
    expected = {(cc, flag, label, 'core', setting) for cc in ['gcc', 'clang']
                for flag in ['native', 'default'] for label in ['base', 'final'] for setting in ['checked', 'skip']}
    expected |= {(cc, flag, label, name, 'skip') for cc in ['gcc', 'clang']
                 for flag in ['native', 'default'] for label in ['base', 'final'] for name in JOBS}
    actual = {(row['compiler'], row['flag'], row['label'], row['kind'], row['setting']) for row in rows}
    assert actual == expected and len(rows) == len(expected)
    for row in rows:
        assert row['returncode'] == 0 and sha(Path(row['executable'])) == row['executable_sha256']
        assert row['header_sha256'] == (before if row['label'] == 'base' else after)
    return rows


PRIOR_AUDIT = 'Audit/performance-low-link-416583-2026-11-12.json'
PRIOR_EVIDENCE = 'Audit/data/performance-low-link-416583-2026-11-12.zip'


def validate_prior_archive():
    prior = load(R / PRIOR_AUDIT)
    assert prior['library'] == LIBRARY
    assert prior['source_sha256']['after'] == sha(D / 'before' / LIBRARY)
    assert prior['evidence_archive'] == PRIOR_EVIDENCE
    assert sha(R / PRIOR_EVIDENCE) == prior['evidence_archive_sha256']
    return prior


def validate_fixtures():
    prior = validate_prior_archive()
    with zipfile.ZipFile(R / PRIOR_EVIDENCE) as archive:
        for name in FIXTURE_METADATA:
            assert archive.read('fixtures/' + name) == (D / 'fixtures' / name).read_bytes(), name
        # 一時フォルダにコピーされた自作ソースだけ収録。旧パスは実体へ辿らない。
        for name in FIXTURE_OWN_SOURCES:
            if (D / 'fixtures' / name).is_file():
                assert not (D / 'fixtures' / name).is_symlink()
                assert archive.read('fixtures/' + name) == (D / 'fixtures' / name).read_bytes(), name
    rows = load(D / 'fixtures/fixtures.json')
    fixtures = {row['id']: row for row in rows}
    summary = load(D / 'fixtures/summary.json')
    validation = load(D / 'fixtures/validation.json')
    assert len(rows) == len(fixtures) == summary['cases'] == validation['fixture_rows'] == 26
    assert summary['physical_graphs'] == validation['unique_inputs'] == len({row['path'] for row in rows})
    assert validation['all_passed'] and validation['canonical_outputs'] == len(fixtures)
    assert {row['problem'] for row in rows} == {'two_edge_connected_components', 'biconnected_components'}
    return fixtures, summary, validation


def prior_validation_same_source(after):
    prior = validate_prior_archive()
    assert prior['source_sha256']['after'] == after
    with zipfile.ZipFile(R / PRIOR_EVIDENCE) as archive:
        data = archive.read(prior['validation']['details'])
    assert hashlib.sha256(data).hexdigest() == prior['validation']['sha256']
    value = json.loads(data)
    assert value['header_sha256'] == after and value['all_passed'] and value['completed_at_utc']
    assert value['total_jobs'] == value['passed_jobs'] == value['completed_jobs'] == len(value['jobs']) == 32
    assert all(row['passed'] and row['status'] == 'passed' for row in value['jobs'])
    return dict(mode='previous_same_source', jobs=32, all_passed=True, source_sha256=after,
                prior_audit=PRIOR_AUDIT, prior_audit_sha256=sha(R / PRIOR_AUDIT),
                prior_evidence=PRIOR_EVIDENCE, prior_evidence_sha256=sha(R / PRIOR_EVIDENCE),
                details_inside_previous_archive=prior['validation']['details'],
                validation_sha256=hashlib.sha256(data).hexdigest(), completed_at_utc=value['completed_at_utc'],
                scope='同一dc390a本体の以前の32検証を引用。今回の再実行や却下候補の検証結果とは扱わない。')


def validate_fixture_outputs(fixtures):
    value = load(D / 'final_fixture_validation.json')
    rows = value['rows']
    expected = {(cc, flag, label, case) for cc in ['gcc', 'clang'] for flag in ['native', 'default']
                for label in ['base', 'final'] for case in fixtures}
    actual = {(row['compiler'], row['flag'], row['label'], row['fixture']) for row in rows}
    assert value['all_passed'] and value['count'] == len(rows) == len(expected) and actual == expected
    for row in rows:
        assert row['passed'] and row['canonical_sha256'] == fixtures[row['fixture']]['expected_canonical_sha256']
    return value


def final_coverage(whole_jobs, core_jobs, fixtures):
    declared = {}
    for kind, jobs in [('whole', whole_jobs), ('core', core_jobs)]:
        profiles = {(row['flag'], row['setting']) for row in jobs}
        profile_cases = {}
        for flag, setting in sorted(profiles):
            cases_by_cc = {}
            for cc in ['gcc', 'clang']:
                cases_by_cc[cc] = {json.dumps(row['case']['id'] if kind == 'whole' else row['case'], sort_keys=True)
                                   for row in jobs if row['compiler'] == cc and row['flag'] == flag and row['setting'] == setting}
            assert cases_by_cc['gcc'] and cases_by_cc['gcc'] == cases_by_cc['clang'], (kind, flag, setting)
            profile_cases[flag + '/' + setting] = [json.loads(case) for case in sorted(cases_by_cc['gcc'])]
        declared[kind] = profile_cases
    whole_cases = {row['case']['id'] for row in whole_jobs}
    assert whole_cases <= fixtures.keys()
    assert {fixtures[name]['problem'] for name in whole_cases} == {'two_edge_connected_components', 'biconnected_components'}
    assert all(row['setting'] == 'skip' for row in whole_jobs)
    core_cases = {json.dumps(row['case'], sort_keys=True) for row in core_jobs}
    assert {row['case']['operation'] for row in core_jobs} == set(OP_NAMES)
    for row in core_jobs:
        case = row['case']
        matches = [fixture for fixture in fixtures.values() if fixture['path'] == case['path']]
        assert matches and all(fixture['n'] == case['n'] and fixture['m'] == case['m'] for fixture in matches)
        assert case['repetitions'] > 0
    declaration = D / 'final_measurement_coverage.json'
    if declaration.is_file():
        assert load(declaration) == declared, '明示した測定範囲とjobの実際の範囲が異なる'
    return whole_cases, core_cases, declared



def confirmation(fixtures):
    import ast
    script = D / 'confirm.py'
    if not script.exists():
        assert not (D / 'confirm_summary.json').exists() and not (D / 'confirm_raw.json').exists()
        return None
    # 宣言された候補・入力集合を読み取るだけで、測定scriptは実行しない。
    tree = ast.parse(script.read_text())
    declarations = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in {'labels', 'names'}:
                    declarations[target.id] = ast.literal_eval(node.value)
    labels = declarations['labels']
    names = declarations['names']
    assert labels and names and len(labels) == len(set(labels)) and len(names) == len(set(names))
    expected_cases = {name for name, fixture in fixtures.items() if fixture['name'] in names}
    assert {fixtures[name]['name'] for name in expected_cases} == set(names)
    expected = {(cc, case) for cc in ['gcc', 'clang'] for case in expected_cases}
    summary_path, raw_path = D / 'confirm_summary.json', D / 'confirm_raw.json'
    summary, raw = load(summary_path), load(raw_path)
    def key(row):
        return row['compiler'], row['case']
    assert len(summary) == len(expected) and {key(row) for row in summary} == expected
    assert {key(row) for row in raw} == expected
    attempts = {label: 9 for label in labels} | {'control': 3}
    grouped = defaultdict(list)
    for row in raw:
        assert row['label'] in attempts
        values = [row[name] for name in ['before', 'target', 'after']]
        times = [value['cpu_ns'] for value in values]
        assert all(value > 0 for value in times)
        drift = max(times[0], times[2]) / min(times[0], times[2])
        assert row['calibration_valid'] == (drift <= 1.10)
        assert math.isclose(row['reference_drift'], drift, rel_tol=1e-12)
        assert math.isclose(row['ratio'], times[1] / statistics.median([times[0], times[2]]), rel_tol=1e-12)
        assert all(value['canonical_sha256'] == fixtures[row['case']]['expected_canonical_sha256'] for value in values)
        grouped[key(row)].append(row)
    cells, insufficient = [], []
    for row in summary:
        samples = grouped[key(row)]
        assert len(samples) == sum(attempts.values())
        assert {sample['rep'] for sample in samples} == set(range(sum(attempts.values())))
        assert set(row['ratios']) == set(attempts) and set(row['valid_counts']) == set(attempts)
        actual_attempts = {label: sum(sample['label'] == label for sample in samples) for label in attempts}
        assert actual_attempts == attempts, ('9候補/3対照の試行数不一致', key(row), actual_attempts)
        for label in attempts:
            ratios = [sample['ratio'] for sample in samples if sample['label'] == label and sample['calibration_valid']]
            assert row['valid_counts'][label] == len(ratios)
            assert (row['ratios'][label] is None) == (not ratios)
            if ratios:
                assert math.isclose(row['ratios'][label], statistics.median(ratios), rel_tol=1e-12)
        enough = row['valid_counts']['control'] >= 2 and all(row['valid_counts'][label] >= 5 for label in labels)
        cell = dict(row, attempts=actual_attempts, sufficient=enough,
                    qualification='候補ごとに有効5組以上、同一対照2組以上。未達も除かず表示。')
        cells.append(cell)
        if not enough:
            insufficient.append(cell)
    sources = {label: dict(file=label + '.hpp', sha256=sha(D / (label + '.hpp'))) for label in labels}
    return dict(stage='confirm', category='additional_confirmation', labels=sources,
                script='confirm.py', script_sha256=sha(script), cases=len(expected_cases), cells=len(cells),
                triplets=len(raw), declared_attempts_per_cell=attempts,
                qualified_cells=len(cells)-len(insufficient), insufficient_cells=insufficient,
                cell_results=cells, summary=summary_path.name, summary_sha256=sha(summary_path),
                raw=raw_path.name, raw_sha256=sha(raw_path),
                flag_scope='confirm.pyはbench.run_wholeへflag引数を渡さず、既定nativeを使う。defaultを測定した結果とは扱わない。',
                scope='9候補/3同一対照の追加確認。rawの計算・出力の正しさ・全宣言セル完了を検算し、有効組不足セルを明示する。十分な組数は採用を意味せず、結果の採否はfinal_selectionで別に決める。')


def exploratory(fixtures):
    result = []
    for stem in ['screen', 'stage2', 'stage3']:
        summary_path = D / (stem + '_summary.json')
        raw_path = D / (stem + '_raw.json')
        if not summary_path.exists() and not raw_path.exists():
            continue
        summary, raw = load(summary_path), load(raw_path)
        assert summary and raw
        labels = {row['label'] for row in raw} - {'control'}
        sources = {label: dict(file=label + '.hpp', sha256=sha(D / (label + '.hpp'))) for label in sorted(labels)}
        def key(row):
            return (row['compiler'], json.dumps(row['case'], sort_keys=True))
        assert len({key(row) for row in summary}) == len(summary)
        assert {key(row) for row in summary} == {key(row) for row in raw}
        for row in raw:
            values = [row[name] for name in ['before', 'target', 'after']]
            times = [value['cpu_ns'] for value in values]
            assert all(value > 0 for value in times)
            drift = max(times[0], times[2]) / min(times[0], times[2])
            assert row['calibration_valid'] == (drift <= 1.10)
            assert math.isclose(row['reference_drift'], drift, rel_tol=1e-12)
            assert math.isclose(row['ratio'], times[1] / statistics.median([times[0], times[2]]), rel_tol=1e-12)
            assert all(value['canonical_sha256'] == fixtures[row['case']]['expected_canonical_sha256'] for value in values)
        for row in summary:
            samples = [sample for sample in raw if key(sample) == key(row)]
            assert set(row['ratios']) == labels | {'control'}
            for label in labels | {'control'}:
                ratios = [sample['ratio'] for sample in samples if sample['label'] == label and sample['calibration_valid']]
                assert row['valid_counts'][label] == len(ratios)
                assert (row['ratios'][label] is None) == (not ratios)
                if ratios:
                    assert math.isclose(row['ratios'][label], statistics.median(ratios), rel_tol=1e-12)
        result.append(dict(stage=stem, labels=sources, cells=len(summary), triplets=len(raw),
                           summary=summary_path.name, summary_sha256=sha(summary_path),
                           raw=raw_path.name, raw_sha256=sha(raw_path),
                           scope='探索の少数反復を保存。最終測定と区別する。'))
    confirm = confirmation(fixtures)
    if confirm is not None:
        result.append(confirm)
    return result


def evidence_files():
    import os
    excluded_names = {'audit_draft.json', Path(PERFORMANCE).name, 'distribution_update.log',
                      'compiler_official_langs.toml'}
    excluded_parts = {'__pycache__', 'generator_bins', 'inputs', 'outputs', 'sources', 'validation',
                      'output', 'active', 'platform_evidence', 'artifacts', 'snapshots',
                      'third_party', 'third-party', 'external', 'frontend'}
    allowed_suffixes = {'.py', '.hpp', '.cpp', '.json', '.diff', '.md', '.log'}
    for parent, directories, names in os.walk(D, followlinks=False):
        parent = Path(parent)
        directories[:] = [name for name in directories if name not in excluded_parts and not (parent / name).is_symlink()]
        for name in names:
            path = parent / name
            if path.is_symlink() or name in excluded_names or path.suffix not in allowed_suffixes:
                continue
            relative = path.relative_to(D)
            assert path.resolve().is_relative_to(D.resolve())
            if relative.parts[0] == 'fixtures' and (len(relative.parts) != 2 or name not in FIXTURE_METADATA | FIXTURE_OWN_SOURCES):
                continue
            if relative.parts[0] == 'profiles' and path.suffix != '.json':
                continue
            if name.startswith('compiler_evidence_'):
                continue
            yield path


def main():
    selection = load(D / 'final_selection.json')
    decision = selection['decision']
    if decision.startswith('adopt'):
        adopted = True
    elif decision.startswith(('retain', 'reject', 'keep', 'no_adopt')):
        adopted = False
    else:
        raise ValueError('decisionはadopt/retain/reject/keep/no_adoptで始める')
    before = sha(D / 'before' / LIBRARY)
    after = sha(R / LIBRARY)
    assert before == sha(D / 'base.hpp') == 'dc390a4e4bdd41ce51aab618b8a55947de96c863663522d59319b2e2c897597e'
    if adopted:
        assert selection['changes'] and after != before
        assert after == sha(D / 'final.hpp') == sha(D / (selection['label'] + '.hpp')) == selection['measured_candidate_sha256']
        if 'implementation_candidate' in selection:
            implementation = D / (selection['implementation_candidate'] + '.hpp')
            assert sha(implementation) == selection['implementation_candidate_sha256']
            def implementation_text(path):
                return '\n'.join(line for line in path.read_text().splitlines() if line.strip() and not line.lstrip().startswith('//'))
            assert implementation_text(implementation) == implementation_text(D / 'final.hpp')
    else:
        assert before == after, '現行維持で本体を変更しない'
        if 'measured_candidate_sha256' in selection:
            assert selection['measured_candidate_sha256'] == before, '維持対象のSHAは現行本体を指す'
        if (D / 'final.hpp').exists():
            assert sha(D / 'final.hpp') == before
    frozen = load(D / 'frozen.json')
    assert len(frozen['files']) == 15
    for name, expected in frozen['files'].items():
        assert sha(D / 'before' / name) == expected
    for name in FROZEN_PUBLIC:
        assert (R / name).read_bytes() == (D / 'before' / name).read_bytes(), name
    online_data = load(D / 'online_records.json')
    online = {row['id']: row for row in online_data['records']}
    journal = {row['id']: row for row in load(R / 'Verify/current/judgements.json')['entries']}
    for identifier, (submission, milliseconds) in JOBS.items():
        old, current = online[identifier], journal[identifier]
        assert old['url'] == f'https://judge.yosupo.jp/submission/{submission}' and old['status'] == 'AC' and old['time_ms'] == milliseconds
        assert old['source_hashes'] == {LIBRARY: before}
        assert len(old['case_results']) == {'low_link_two_edge': 21, 'low_link_biconnected': 22}[identifier]
        assert all(row['status'] == 'AC' for row in old['case_results'])
        assert old['driver_sha256'] == sha(R / f'Verify/current/drivers/{identifier}_main.cpp')
        assert old['io_source_hashes'] == {'Verify/current/common/fast_io.hpp': sha(R / 'Verify/current/common/fast_io.hpp')}
        assert current['url'] == old['url'] and current['time_ms'] == milliseconds and current['status'] == 'AC'
        assert current['source_hashes'] == {LIBRARY: before} and current['current_source_hashes'] == {LIBRARY: after}
        assert current['needs_resubmission'] is adopted and current['matched_current_generation'] is (not adopted)
        actual = R / f'Verify/current/submissions/{identifier}.cpp'
        assert current['current_submission_sha256'] == sha(actual)
        expected = D / (f'final_{identifier}.cpp' if adopted else f'{identifier}_submitted_generation.cpp')
        assert actual.read_bytes() == expected.read_bytes()
        assert actual.read_bytes().startswith(b'#define SKIP_RUNTIME_CHECKS\n') and actual.stat().st_size <= 512 * 1024
    fixtures, fixture_info, fixture_proof = validate_fixtures()
    screens = exploratory(fixtures)
    if adopted:
        matrix, allocation = validate_final(after)
        builds = validate_builds(before, after)
        whole_jobs, whole, whole_raw = measurements('whole', fixtures)
        core_jobs, core, core_raw = measurements('core', fixtures)
        whole_cases, core_cases, coverage = final_coverage(whole_jobs, core_jobs, fixtures)
        repair = validate_repair(fixtures)
        fixture_results = validate_fixture_outputs(fixtures)
        checkpoint = D / 'profiles/checkpoint.json'
        profile = load(checkpoint)
        assert profile['status'] == 'local_samples_passed_for_snapshot' and profile['completed_at_utc'] and profile['active'] is None
        assert profile['counts'] == {'LOCAL_SAMPLE_PASS': 14}
        for name, expected_hash in profile['manifest_hashes'].items():
            assert sha(R / name) == expected_hash, ('profileのsnapshot後にmanifest/scriptが変わった', name)
        for row in whole:
            row['problem'] = fixtures[row['case']]['problem']
        invalid_whole = [row for row in whole if not qualified(row)]
        invalid_core = [row for row in core if not qualified(row)]
        measured = dict(
            repair=repair, coverage=coverage, coverage_scope='実際の各profileで宣言したjob集合を記録し、両コンパイラで同じ条件集合か照合。対象を特定の入力名や過去の件数に固定しない。',
            whole=dict(cells=len(whole_jobs), cases=len(whole_cases), qualified_cells=len(whole)-len(invalid_whole), triplets=len(whole_raw),
                       statistics=compact_stats(whole, ['compiler', 'flag', 'problem']), insufficient_cells=invalid_whole,
                       jobs='final_whole_jobs.json', summary='final_whole_summary.json', raw='final_whole_raw.json',
                       time='固定main全体の子user+system CPU時間。SKIP設定。正規化と独立参照SHA照合は計測後。'),
            core=dict(cells=len(core_jobs), scenarios=len(core_cases), qualified_cells=len(core)-len(invalid_core), triplets=len(core_raw),
                      statistics=compact_stats(core, ['compiler', 'flag', 'setting']), operations=OP_NAMES,
                      insufficient_cells=invalid_core, jobs='final_core_jobs.json', summary='final_core_summary.json', raw='final_core_raw.json',
                      time='std::clock。入力読込と準備は計測外、指定操作と返り値生成は内、checksumの正規化と照合は後。'),
            observed_tradeoffs=dict(whole_above_three_percent=[row for row in whole if qualified(row) and row['ratios']['final'] > 1.03],
                                    large_core_above_three_percent=[row for row in core if qualified(row) and row['case']['n'] >= 100000 and row['ratios']['final'] > 1.03],
                                    scope='基準達成セルから導出。未達セルも隠さず記録。'))
        validation = dict(mode='fresh_final_candidate', jobs=matrix['total_jobs'], all_passed=True,
                          source_sha256=after, completed_at_utc=matrix['completed_at_utc'],
                          details='final_validation.json', sha256=sha(D / 'final_validation.json'),
                          matrix='GCC/Clang×checked/SKIP×default/forced-wide×参照/構築確保失敗/照会確保失敗の24件、同8設定のASAN+UBSAN参照。',
                          allocation_counters=allocation, forced_wide_conditions=matrix['forced_wide_conditions'],
                          wide_scope='通常サイズで辺IDとstampのsize_t経路を強制。巨大Mそのものの物理試験とは扱わない。',
                          leak_scope='LeakSanitizerはhost ptraceのため無効。独立live allocation counterは全確保試験delta=0。',
                          builds=len(builds), fixture_comparisons=fixture_results['count'], fixture_details='final_fixture_validation.json',
                          fixture_sha256=sha(D / 'final_fixture_validation.json'),
                          profiles=dict(jobs=14, file='profiles/checkpoint.json', sha256=sha(checkpoint), run_id=profile['run_id'],
                                        scope='派生版8件と使用例6件のローカルサンプル。オンライン判定ではない。'))
        for row in matrix['jobs']:
            path = Path(row['source'])
            destination = D / 'evidence_tests' / path.name
            destination.parent.mkdir(exist_ok=True)
            if destination.exists():
                assert destination.read_bytes() == path.read_bytes()
            else:
                destination.write_bytes(path.read_bytes())
    else:
        validation = prior_validation_same_source(after)
        measured = dict(scope='今回の候補は採用せず現行本体を維持。今回の候補探索・追加確認と、過去の同一SHA検証を区別する。新本体の最終検証を行ったとは扱わない。')
    before_text = (D / 'before' / LIBRARY).read_text()
    final_text = (R / LIBRARY).read_text()
    (D / 'final.diff').write_text(''.join(difflib.unified_diff(before_text.splitlines(True), final_text.splitlines(True),
                                                          fromfile='before/Low_Link.cpp', tofile='selected/Low_Link.cpp')))
    additional = {path.name: sha(path) for pattern in ['confirm*summary.json', 'confirm*raw.json', '*validation.json']
                  for path in D.glob(pattern) if path.name != 'final_validation.json'}
    audit = dict(
        date='2026-11-12', library=LIBRARY, decision=decision, source_sha256=dict(before=before, after=after), selection=selection,
        required_resubmission=[f'Verify/current/submissions/{identifier}.cpp' for identifier in JOBS] if adopted else [],
        online_evidence=ONLINE,
        online_scope='416596のtwo_edge AC42ms・416595のbiconnected AC210msは提出時dc390a本体/main/共通IOと本文照合済み。' + (
            '今回採用の新本体は未提出で、このACを現行版へ転記しない。' if adopted else
            '同じ本体を維持し、現在の通常版とも本文一致。再提出不要。') + '派生版へオンラインACを転記しない。',
        public_online_comparison=online_data['public_case_comparison'], online_compiler_context=online_data['compiler_context'],
        frozen_public_files={name: sha(R / name) for name in FROZEN_PUBLIC},
        before_snapshot=dict(file='frozen.json', sha256=sha(D / 'frozen.json'), files=frozen['files']),
        API_scope='公開API・全範囲・多重辺/自己辺・所有権・例外保証・件数上限を維持。main/共通IO/Document/使用例は不変。成分構成と森の対応を正規化して参照照合する。',
        proof_files=sorted(str(path.relative_to(D)) for path in (D / 'review').glob('*review.md')), source_diff='final.diff',
        measurement=dict(
            cpu='Intel Core i9-14900K CPU12（P-Core、sibling13）。E-Coreを性能評価しない。',
            compilers=dict(GCC='15.2.0', Clang='21.1.8 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'),
            flags_scope='C++23 -O2。native/defaultは各rowで区別。引数と実行体SHAは各builds JSONに保存。',
            CPU_scope='Library CheckerのAMD実機の速度比とは断定しない。オンライン別提出時間と条件固定のローカル比較を区別。',
            lock='/tmp/sirkit_performance_cpu12.lock', compilation_during_timing=False, ASLR='子だけsetarch x86_64 -R、同じactiveパス。',
            protocol='旧版→候補→旧版。候補を両端中央値で割り、両端差10%以内だけ有効。初回は候補7組/同一対照3組、有効5/2未達時のみ15/9組まで補う。初期matrix完了後、control中央値が1±3%外・final>1.03・有効数不足の全セルを一度だけ選び、候補7組/対照3組を追加。初期/追加の全rawを保持して統合中央値を使う。候補自身の時間で個別trialを除外しない。探索と9/3追加確認は別記録。',
            fixtures=dict(cases=len(fixtures), physical_graphs=fixture_info['physical_graphs'],
                          reused_previous_evidence=PRIOR_EVIDENCE, prior_evidence_sha256=sha(R / PRIOR_EVIDENCE),
                          metadata_sha256={name: sha(D / 'fixtures' / name) for name in sorted(FIXTURE_METADATA)},
                          scope='旧証跡ZIP内の固定26ケース・5JSONとbyte一致。JSONの旧/tmpパスは計測入力の参照であり収録対象として辿らない。',
                          independent_oracle_scope=fixture_info['scope'],
                          result_scope='群内・群集合をソートしたcanonical SHAで照合。要素の欠落・重複を隠さず、未規定の成分番号と出力順の差を許容。'),
            exploratory=screens, additional_records=additional, **measured),
        validation=validation, license='既存CC0実装への独自変更。参考ライブラリの実装コードを新規に取り込まない。', evidence_archive=EVIDENCE,
        evidence_scope='今回の独自候補・試験・レビュー・測定raw・自分の提出API原本・入力provenanceを保存。外部実装・コンパイラ原典・入力/出力本体・実行体・symlink参照先を除外。')
    for field in ['outcome', 'tradeoff_notes', 'limitations', 'risks']:
        if field in selection:
            audit[field] = selection[field]
    draft, archive, previous = (D / Path(name).name for name in [PERFORMANCE, EVIDENCE, PREVIOUS])
    previous.write_bytes((D / 'before/Distribution/manifest.json').read_bytes())
    (D / 'audit_draft.json').write_text(encode(audit))
    paths = sorted(evidence_files())
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in paths:
            z.write(path, path.relative_to(D).as_posix())
    audit['evidence_archive_sha256'] = sha(archive)
    draft.write_text(encode(audit))
    print(encode(dict(audit=str(draft), audit_target=PERFORMANCE, evidence=str(archive), evidence_target=EVIDENCE,
                      previous_manifest=str(previous), previous_manifest_target=PREVIOUS,
                      evidence_bytes=archive.stat().st_size, evidence_files=len(paths), repository_written=False)), end='')


if __name__ == '__main__':
    main()
