# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib,fcntl
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_lowlink_416596/review');rows=[]
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for name in ['block_suffix','block_suffix_single']:
  for cc,args in [('gcc',['g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
   for st,flags in [('checked',[]),('skip',['-DSKIP_RUNTIME_CHECKS'])]:
    h=D/(name+'.hpp');src=R/'Verify/current/tests/new_low_link_reference_test.cpp';exe=D/f'{cc}_{st}_{name}_reference';cmd=['taskset','-c','6',*args,'-std=c++23','-O2',*flags,f'-DLOW_LINK_SOURCE="{h}"',str(src),'-o',str(exe)]
    p=subprocess.run(cmd,text=True,capture_output=True);r=dict(candidate=name,compiler=cc,setting=st,command=cmd,header_sha256=hashlib.sha256(h.read_bytes()).hexdigest(),test_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),compile_returncode=p.returncode,compile_stderr=p.stderr);assert p.returncode==0,r
    p=subprocess.run(['taskset','-c','6',str(exe)],text=True,capture_output=True);r.update(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,passed=p.returncode==0 and not p.stderr);rows.append(r);(D/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,cc,st,p.stdout.strip(),flush=True);assert r['passed'],r
print('All8 block extraction reference conditions PASS',flush=True)
