# 点二重連結ブロックの接尾辞抽出

基準: `base.hpp` (canonical SHA256 dc390a4e4bdd41ce51aab618b8a55947de96c863663522d59319b2e2c897597e)。候補は `block_suffix.hpp` と、単独辺を先に処理する `block_suffix_single.hpp` の2本だけ。変更箇所はbuild(true)のブロック取り出しのみで、公開API・componentの印とキャッシュ・橋と関節点・CSR・辺番号型切替・自己辺の処理は無変更。

## 範囲と順序

非根vを発見する際に、parent_edge[v]は必ずpendingへ積まれる。親辺は重複のない辺番号を持つ。vの処理が終わるまで、子孫のブロック取り出しはその子孫の木辺までの接尾辞だけを除去し、vの親辺を除去しない。自己辺は専用処理なのでpendingを変更しない。従って `low[v] >= entered[parent[v]]` でvのブロックを閉じる時点では、parent_edge[v]がpendingに一つ存在する。

rbeginからその辺まで探す処理は、rendを参照することなく必ず終了する。見つけた位置を一つ進めたstopは最大でrendであり、`[pending.rbegin(), stop)` は有効な非空範囲。stop-rbeginは取り出す辺数で、1以上pending.size()以下。従ってresizeの引き算が下回ることはない。reverse_iteratorの差は基になるvectorの有効範囲内の距離である。

範囲の先頭はpendingの末尾で、parent_edge[v]を最後に含む。この順序は旧版のpop_backとpush_backの列に完全一致する。ブロックの出現順も不変で、公開辺群・それから作る頂点群の順序も変わらない。

単独辺の候補は `pending.back() == parent_edge[v]` のときだけ1辺のvectorを作ってpopする。上記の存在保証からback参照は有効で、この分岐はちょうど逆向き範囲長が1の場合に対応する。他のブロックは一般候補と同じである。

## 確保・例外・計算量

reverse_iteratorはランダムアクセスなので、範囲コンストラクタは要素数を事前に求められる。現在のGCC/Clang環境のvectorは必要数の領域を一度確保し、旧版のpush_backによるブロック内の段階的な拡張を避けられる。代わりに範囲を一度探し、一度コピーする。自己辺を除く各辺は一つのブロックで一度探索・コピーされるため、全体のO(N+M)は維持される。Blocks=falseではif constexprで変更部分自体が除かれる。

blocksの確保や範囲構築が失敗した場合、pendingはまだ縮められていない。仮にローカルblocksの再配置中に例外が起きても全配列はローカル所有であり、buildの最後のswap群に到達しないため、公開済みの旧結果は変更されない。成功後のresizeはsize_t要素の削除だけで確保を行わず、blocksの増加は別vectorなのでpendingのiteratorを無効にしない。単独辺分岐もblocksへの格納が成功した後にpendingをpopする。

新たな作業配列や所有権はない。入力検査・SKIPによる除去・内部の容量ガードは基準と同じ。ライブラリ本体にnew式は追加していない。

## 検証

`validation.json` と `validation.log` にヘッダーSHA付きで記録。両候補それぞれGCC/Clang・検査あり/SKIPの4条件で、既存の独立参照を全178177チェック通過。ランダムな多重グラフ・自己辺・独立な橋/関節点/2辺連結/辺ブロック参照・300000頂点の経路などを含む。合計8条件で成功。速度測定は行っていない。
