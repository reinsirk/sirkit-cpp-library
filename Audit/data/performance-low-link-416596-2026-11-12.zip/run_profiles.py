# SPDX-License-Identifier: CC0-1.0
import subprocess,sys,fcntl
with open('/tmp/sirkit_performance_cpu12.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 subprocess.run([sys.executable,'Scripts/verify_variant_programs.py','--output-dir','/tmp/sirkit_lowlink_416596/profiles','--id','low_link_two_edge','--id','low_link_biconnected','--id','example:low_link_example','--setting','default','--cpu','6'],cwd='/home/reinsirk/Atcoder_Env',check=True)
