# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import bench,json,random,statistics,subprocess,fcntl
D=Path('/tmp/sirkit_lowlink_416596');rng=random.Random(41659603)
def encode(x):return json.dumps(x,indent=2)+'\n'
def sig(row):return (row['compiler'],row['flag'],row['setting'],json.dumps(row['case'],sort_keys=True))
def core(job,label):
 c=job['case'];bench.activate(D/f"{job['compiler']}_{job['flag']}_{job['setting']}_{label}_core")
 p=subprocess.run(['setarch','x86_64','-R','taskset','-c','12',str(D/'active'),str(c['operation']),c['path'],str(c['repetitions'])],capture_output=True,text=True,check=True);ns,digest=map(int,p.stdout.split());assert ns>0 and not p.stderr;return dict(cpu_ns=ns,digest=digest)
with open('/tmp/sirkit_performance_cpu12.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 selections=[]
 for kind in ['whole','core']:
  jobs=json.loads((D/f'final_{kind}_jobs.json').read_text());raw=json.loads((D/f'final_{kind}_raw.json').read_text());summ=json.loads((D/f'final_{kind}_summary.json').read_text());bykey={sig(r):r for r in summ}
  for f in ['raw','summary']:(D/f'initial_final_{kind}_{f}.json').write_bytes((D/f'final_{kind}_{f}.json').read_bytes())
  for job in jobs:
   key=(job['compiler'],job['flag'],job['setting'],json.dumps(job['case']['id']if kind=='whole'else job['case'],sort_keys=True));row=bykey[key]
   reasons=[]
   if abs(row['ratios']['control']-1)>.03:reasons.append('identical-control median outside +/-3%')
   if row['ratios']['final']>1.03:reasons.append('possible regression above 3%')
   if not row['sufficient']:reasons.append('insufficient valid samples')
   if not reasons:continue
   selections.append(dict(kind=kind,signature=list(key),reason=reasons,initial=json.loads(json.dumps(row))));(D/'repair_selection.json').write_text(encode(selections))
   local=[r for r in raw if sig(r)==key];attempts={l:max([r['rep']for r in local if r['label']==l],default=0)for l in ['final','control']};order=['final']*7+['control']*3;rng.shuffle(order)
   for label in order:
    attempts[label]+=1
    def run(k):return bench.run_whole(job['compiler'],k,job['case'],job['flag'])if kind=='whole'else core(job,k)
    v=[run(k)for k in ['base',label if label!='control'else'base','base']];check='canonical_sha256'if kind=='whole'else'digest';assert len({x[check]for x in v})==1;b,t,a=[x['cpu_ns']for x in v];drift=max(b,a)/min(b,a)
    r=dict(compiler=job['compiler'],flag=job['flag'],setting=job['setting'],case=job['case']['id']if kind=='whole'else job['case'],label=label,rep=attempts[label],before=v[0],target=v[1],after=v[2],reference_drift=drift,calibration_valid=drift<=1.10,ratio=t/statistics.median([b,a]),phase='supplemental_all_samples_retained');raw.append(r);local.append(r)
   ratios={l:[r['ratio']for r in local if r['label']==l and r['calibration_valid']]for l in ['final','control']};row.update(ratios={l:statistics.median(v)if v else None for l,v in ratios.items()},valid_counts={l:len(v)for l,v in ratios.items()},sufficient=len(ratios['final'])>=5 and len(ratios['control'])>=2)
   (D/f'final_{kind}_raw.json').write_text(encode(raw));(D/f'final_{kind}_summary.json').write_text(encode(summ));print(kind,row,flush=True)
