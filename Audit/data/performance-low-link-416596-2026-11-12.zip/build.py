# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import subprocess,json,hashlib,sys
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_lowlink_416596');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as p
entries={e['id']:e for e in p.collect()};urls={'low_link_two_edge':'https://judge.yosupo.jp/submission/416596','low_link_biconnected':'https://judge.yosupo.jp/submission/416595'};rows=[]
for label in sys.argv[1:]:
 header=D/(label+'.hpp');assert header.is_file()
 for identifier,url in urls.items():
  e=entries[identifier].copy();e['submission_urls']=[url];data,_=p.render(e,source_overrides={'Graph/Low_Link.cpp':header.read_bytes()});src=D/f'{label}_{identifier}.cpp';src.write_bytes(data)
  for cc,args,cpu in [('gcc',['g++'],4),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'],6)]:
   exe=D/f'{cc}_native_{label}_{identifier}';cmd=['taskset','-c',str(cpu),*args,'-std=c++23','-O2','-march=native',str(src),'-o',str(exe)];r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,r.stderr
   for sample in e['samples']:
    r=subprocess.run([str(exe)],input=sample['input'],capture_output=True,text=True,check=True);assert p.matches(e,sample,r.stdout)and not r.stderr
   rows.append(dict(label=label,id=identifier,compiler=cc,flags='native',command=cmd,source_sha256=hashlib.sha256(data).hexdigest(),header_sha256=hashlib.sha256(header.read_bytes()).hexdigest(),passed=True))
 print(label,'2 mains x2compilers samplesPASS',flush=True)
 path=D/'builds.json';old=json.loads(path.read_text())if path.exists()else[];path.write_text(json.dumps(old+rows,indent=2)+'\n');rows=[]
