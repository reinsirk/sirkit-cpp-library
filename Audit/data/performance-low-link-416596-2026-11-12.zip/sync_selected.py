# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json,subprocess,sys
R=Path('/home/reinsirk/Atcoder_Env');D=Path('/tmp/sirkit_lowlink_416596')
def run(*args):subprocess.run([sys.executable,*map(str,args)],cwd=R,check=True)
sel=json.loads((D/'final_selection.json').read_text());assert sel['decision'].startswith('adopt')
assert (R/'Graph/Low_Link.cpp').read_bytes()==(D/'base.hpp').read_bytes()
source=(D/'final.hpp').read_bytes();assert hashlib.sha256(source).hexdigest()==sel['measured_candidate_sha256']
(R/'Graph/Low_Link.cpp').write_bytes(source)
run(D/'apply_online_metadata.py','--apply','--performance-audit','Audit/performance-low-link-416596-2026-11-12.json')
run('Scripts/prepare_verify.py','--id','low_link_two_edge','--id','low_link_biconnected')
run('Scripts/generate_fast_sources.py')
run('Scripts/generate_variants.py')
run('Scripts/prepare_variant_verify.py')
run('Scripts/source_api_docs.py','--check')
for identifier in ['low_link_two_edge','low_link_biconnected']:
 assert(R/f'Verify/current/submissions/{identifier}.cpp').read_bytes()==(D/f'final_{identifier}.cpp').read_bytes()
for f in ['Verify/current/drivers/low_link_two_edge_main.cpp','Verify/current/drivers/low_link_biconnected_main.cpp','Verify/current/common/fast_io.hpp','Examples/low_link_example.cpp','Document/low_link.md']:
 assert(R/f).read_bytes()==(D/'before'/f).read_bytes()
print('canonical + metadata + normal/variant sources and submissions synchronized; fixed main/IO/example/Document unchanged',flush=True)
