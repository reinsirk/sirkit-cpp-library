// SPDX-License-Identifier: CC0-1.0
#ifndef HEADER
#define HEADER "baseline.hpp"
#endif
#include HEADER
#include <chrono>
#include <cstdio>
#include <cinttypes>
#include <string>
#include <random>
#include <vector>
#include <algorithm>

template<class Key>Key make_key(std::uint64_t value) {
 if constexpr(std::is_integral_v<Key>)return value;
 else return std::to_string(value)+"#shared-middle-abcdefghijklmnop";
}
template<class Key,bool Find>void run(int shape) {
 constexpr std::size_t n=65536,q=1048576;
 std::mt19937_64 rng(20261113);std::vector<Key> keys;keys.reserve(n);
 for(std::size_t i=0;i<n;++i)keys.push_back(make_key<Key>(rng()&~std::uint64_t{1}));
 HashSet<Key> table(0,GenericHash(291103));table.reserve(n);
 for(const auto& k:keys)table.insert(k);
 const bool tombstone=shape>=2,hit=(shape%2)==0;
 if(tombstone)for(std::size_t i=0;i<n*3/4;++i)table.erase(keys[i],false);
 std::vector<Key> queries;queries.reserve(q);
 for(std::size_t i=0;i<q;++i) {
  if(hit)queries.push_back(keys[tombstone?n*3/4+rng()%(n/4):rng()%n]);
  else if(tombstone)queries.push_back(keys[rng()%(n*3/4)]);
  else queries.push_back(make_key<Key>(rng()|std::uint64_t{1}));
 }
 const auto& values=table;std::size_t answer=0;
 const auto start=std::chrono::steady_clock::now();
 for(const auto& key:queries) {
  if constexpr(Find)answer+=values.find(key)!=values.end();
  else answer+=values.contains(key);
 }
 const auto elapsed=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count();
 if(answer!=(hit?q:0))std::abort();
 std::printf("%zu %" PRId64 "\n",answer,static_cast<std::int64_t>(elapsed));
}
int main(int argc,char**argv) {
 if(argc!=4)return 1;const std::string type=argv[1],api=argv[2];const int shape=std::atoi(argv[3]);
 if(type=="integer") {if(api=="find")run<std::uint64_t,true>(shape);else run<std::uint64_t,false>(shape);}
 else {if(api=="find")run<std::string,true>(shape);else run<std::string,false>(shape);}
}
