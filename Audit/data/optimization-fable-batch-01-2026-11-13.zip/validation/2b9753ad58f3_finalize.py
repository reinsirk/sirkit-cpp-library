from pathlib import Path
import json,hashlib
w=Path(__file__).resolve().parent;root=Path('/home/reinsirk/Atcoder_Env')
p=json.loads((w/'provenance.json').read_text());v=json.loads((w/'validation_results.json').read_text());bench=json.loads((w/'benchmark_results.json').read_text());confirm=json.loads((w/'toggle_confirmation.json').read_text())
report={
 'scope':'main_only','adopted':False,'repository_files_modified':False,'fable_invoked':False,
 'body_frozen':{'path':'DataStructure/Hash_set.cpp','sha256':p['body_sha256'],'still_current':hashlib.sha256((root/'DataStructure/Hash_set.cpp').read_bytes()).hexdigest()==p['body_sha256']},
 'io_frozen':{'path':'Verify/current/common/fast_io.hpp','sha256':p['io_sha256'],'still_current':hashlib.sha256((root/'Verify/current/common/fast_io.hpp').read_bytes()).hexdigest()==p['io_sha256']},
 'compiler_versions':bench['compilers'],'cpu':12,'flags':'-std=c++23 -O2; actual generated current checked/skip sources. These three IDs have no GCC optimization pragma.',
 'validation':{'all_passed':all(r['passed']for r in v),'configurations':len(v),'driver_configurations':sum(r['kind']=='driver_model'for r in v),'string_api_configurations':sum(r['kind']=='string_api'for r in v),'models':'独立Python set。toggleは3値の長さ1〜5全列挙363列＋random32列、membershipは1/2要素の2値配列3本の全216通り＋random32例、文字列32例。各GCC15.2/Clang21×checked/skipでbaseline/candidateを照合。','large':'既存small/random/同値の全出力をPython setと照合。toggleは交互・全miss・削除再挿入各10万件も追加。文字列mainは無変更のcontrolとしてrandom/同値と既存NUL/所有/例外テストを実行。','results':str(w/'validation_results.json')},
 'api_and_lifetime':{'insert_checked_return':'std::pair<iterator,bool>','added_true':'挿入後のiteratorを使用せず、次の入力へ進む。','added_false':'戻ったiteratorは呼出し完了時点の有効なスロットを指す。直後にerase(it,false)へ値渡しし、その前後でiteratorを保存しない。','checked_test':'すべてchecked/skip構成でPASS。stale/foreign iterator検査に抵触しない。','reserve_bound':'ABC344 CのN,M,L<=100の有効入力ではsize_tへ変換後の積は最大10^6で、整数積の溢れなし。reserve自身の容量検査も維持。'},
 'decisions':[
 {'id':'hash_set_toggle','decision':'reject','patch':str(w/'hash_set_toggle.patch'),'reason':'randomはGCC約1%、Clang約2.5%短縮するが、同値反復が両compilerで初回約4%、確認回約5〜7%悪化。指定の採用条件（同値退化列を悪化させない）を満たさない。',
  'measurements':[r for r in bench['results']if r['id']=='hash_set_toggle'],'confirmation':confirm['results']},
 {'id':'hash_set_membership','decision':'reject','patch':str(w/'hash_set_membership.patch'),'reason':'randomではGCC約27%、Clang約36%短縮しピークRSSも低下するが、同値の退化列でGCC2.154倍、Clang1.132倍と悪化。ピークRSSも約4MiBからGCC約22MiB/Clang約5.9MiBへ増加。指定条件に従い不採用。','measurements':[r for r in bench['results']if r['id']=='hash_set_membership']}
 ],
 'hash_seed_note':'GenericHash既定種はsteady_clock由来。実提出mainを保つため時計由来の種を固定せず、交互反復の分布を測定。toggle確認は開始順を逆転して2warm+15組。単一キー反復の退行が両回両compilerで一致したため、追加の明示seed main改変は不要と判断。',
 'measurement_scope_note':'本体locate候補と組み合わせていない。本体改善の成果として数えない。文字列driverは未変更で速度候補なし。AtCoderの非公開公式入力やオンライン再提出は実行していない。',
 'artifacts':{name:str(w/name)for name in ('prepare.py','validate.py','benchmark.py','confirm_toggle.py','benchmark_results.json','toggle_confirmation.json','provenance.json','small_cases.json')},
}
(w/'final_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
lines=['# HashSet main候補：両案不採用','','現HashSet本体と共通I/Oを固定。変更はtoggleのinsert_checked単発化、membershipのN*M*L reserveを別々に測定した。repo変更なし。','', '| 候補 | compiler | random比 | 同値比 | 同値時RSS baseline→candidate KiB |','| --- | --- | ---: | ---: | ---: |']
for identity in ('hash_set_toggle','hash_set_membership'):
 for cc in ('gcc','clang'):
  a=next(r for r in bench['results']if r['id']==identity and r['compiler']==cc and r['case']=='random');b=next(r for r in bench['results']if r['id']==identity and r['compiler']==cc and r['case']=='degenerate')
  lines.append(f"| {identity} | {cc} | {a['candidate_ratio']:.4f} | {b['candidate_ratio']:.4f} | {b['median_peak_rss_kib']['baseline']}→{b['median_peak_rss_kib']['candidate']} |")
lines+=['','比は候補/現行。CPU12、GCC15.2/Clang21、C++23 O2、同main/I/O/本体で2warm+9交互。toggleは開始順逆転2warm+15組でも同値列がGCC1.050/Clang1.067に悪化し、不採用条件を再確認した。','', '独立Python set照合は全20driver構成PASS（各checked/skip×両compiler、文字列control含む）。文字列/NUL/所有/例外の既存APIテスト4構成もPASS。toggleは395小列＋6 workload、membershipは248小例＋3 workload、文字列は32小例＋3 workloadを各構成で確認。','', 'insert_checkedはpair<iterator,bool>を返し、未挿入なら戻ったiteratorをそのままerase(it,false)へ渡す。間に変更操作はなくiteratorを保持しないため寿命上の追加問題はない。reserveの積は有効問題制約で最大10^6。正しさの問題は見つからなかった。','']
(w/'summary.md').write_text('\n'.join(lines));print(json.dumps({'decisions':[{k:r[k]for k in ('id','decision')}for r in report['decisions']],'all_validation_passed':report['validation']['all_passed'],'configurations':len(v),'body_still_current':report['body_frozen']['still_current'],'report':str(w/'final_report.json')},indent=2))
