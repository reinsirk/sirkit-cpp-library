from pathlib import Path
import subprocess,json,hashlib,random,time,statistics,shutil,sys,gc
W=Path(__file__).parent;R=Path('/home/reinsirk/Atcoder_Env');sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
meta=json.loads((W/'sources/metadata.json').read_text());rows=[];(W/'bin').mkdir(exist_ok=True)
def save():(W/'benchmark_results.json').write_text(json.dumps({'cpu':11,'scope':'Only locate body differs. Frozen current3drivers and same expanded commonI/O/settings in full programs; microbench same O2/SKIP and explicit GenericHash seed.2warm+9 shuffled alternating executable copies to one path. Full programs retain default time-based GenericHash seed; microbench uses fixed seed for paired probe-pattern control.','results':rows},indent=2)+'\n')
def model(ident,p):
 tokens=p.read_text().split();a=iter(tokens)
 if ident=='hash_set_membership':
  arrays=[[int(next(a)) for _ in range(int(next(a)))] for _ in range(3)];sums={x+y+z for x in arrays[0] for y in arrays[1] for z in arrays[2]};q=int(next(a));return ''.join('Yes\n' if int(next(a)) in sums else 'No\n' for _ in range(q)).encode()
 if ident=='hash_set_strings':return (str(len(set(tokens[1:])))+'\n').encode()
 live=set()
 for x in tokens[1:]:
  value=int(x)
  if value in live:live.remove(value)
  else:live.add(value)
 return (str(len(live))+'\n').encode()
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['clang++','--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15'])]:
 bins={}
 for m in meta:
  ident=m['entry']['id'];bins[ident]={}
  for label in ['baseline','candidate']:
   src=W/'sources'/f'{ident}_{label}.cpp';exe=W/'bin'/f'{cc}_{ident}_{label}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2',str(src),'-o',str(exe)];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr;bins[ident][label]=exe;rows.append({'kind':'build','compiler':cc,'id':ident,'label':label,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'passed':True});save()
 for m in meta:
  ident=m['entry']['id']
  for inp in sorted((W/'inputs'/ident).glob('*.in')):
   expected=model(ident,inp);outputhash=hashlib.sha256(expected).hexdigest();gc.collect()
   for label,exe in bins[ident].items():
    p=subprocess.run(['taskset','-c','11',str(exe)],input=inp.read_bytes(),capture_output=True);assert p.returncode==0 and p.stdout==expected,(cc,ident,inp,label,p.stderr)
   raw={k:[] for k in bins[ident]};rng=random.Random(454117)
   for rep in range(11):
    order=list(raw);rng.shuffle(order)
    for label in order:
     active=W/'bin/active';shutil.copyfile(bins[ident][label],active);active.chmod(0o755)
     with inp.open('rb') as fi,open('/dev/null','wb') as fo:
      start=time.perf_counter_ns();p=subprocess.run(['taskset','-c','11',str(active)],stdin=fi,stdout=fo,stderr=subprocess.PIPE);elapsed=time.perf_counter_ns()-start
     assert p.returncode==0,p.stderr
     if rep>=2:raw[label].append(elapsed)
   med={k:statistics.median(v) for k,v in raw.items()};rows.append({'kind':'full_timing','compiler':cc,'id':ident,'case':inp.stem,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'python_set_equal':True,'expected_sha256':outputhash,'raw_ns':raw,'median_ns':med,'ratio':med['candidate']/med['baseline']});save();print(cc,ident,inp.stem,{k:round(v/1e6,3) for k,v in med.items()},flush=True)
 # Compile only after all whole-program timed runs finish.
 microbins={}
 for label in ['baseline','candidate']:
  src=W/'micro.cpp';exe=W/'bin'/f'{cc}_micro_{label}';cmd=['taskset','-c','11',*compiler,'-std=c++23','-O2','-DSKIP_RUNTIME_CHECKS','-DHEADER="'+str(W/f'{label}.hpp')+'"',str(src),'-o',str(exe)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;microbins[label]=exe;rows.append({'kind':'micro_build','compiler':cc,'label':label,'command':cmd,'passed':True});save()
 for keytype in ['integer','string']:
  for api in ['find','contains']:
   for shape,shape_name in enumerate(['alive_hit','alive_miss','tombstone_hit','tombstone_miss']):
    raw={k:[] for k in microbins};rng=random.Random(372147);expected=None
    for rep in range(11):
     order=list(raw);rng.shuffle(order)
     for label in order:
      active=W/'bin/micro_active';shutil.copyfile(microbins[label],active);active.chmod(0o755);p=subprocess.run(['taskset','-c','11',str(active),keytype,api,str(shape)],capture_output=True,text=True);assert p.returncode==0,p.stderr;answer,elapsed=map(int,p.stdout.split());expected=answer if expected is None else expected;assert answer==expected
      if rep>=2:raw[label].append(elapsed)
    med={k:statistics.median(v) for k,v in raw.items()};rows.append({'kind':'micro_timing','compiler':cc,'keytype':keytype,'api':api,'case':shape_name,'query_count':1048576,'answer':expected,'raw_core_ns':raw,'median_core_ns':med,'ratio':med['candidate']/med['baseline']});save();print(cc,keytype,api,shape_name,{k:round(v/1e6,3) for k,v in med.items()},flush=True)
