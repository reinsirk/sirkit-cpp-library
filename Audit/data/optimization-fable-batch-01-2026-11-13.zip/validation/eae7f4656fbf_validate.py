from pathlib import Path
import itertools,json,random,subprocess,hashlib,time
w=Path(__file__).resolve().parent;root=Path('/home/reinsirk/Atcoder_Env');d=Path('/tmp/sirkit_remaining_20261113/data/inputs')
install=Path(subprocess.check_output(['/usr/bin/g++','-print-libgcc-file-name'],text=True).strip()).parent
rng=random.Random(0x5E712)
def encode_values(values):return (str(len(values))+'\n'+'\n'.join(map(str,values))+'\n').encode()
def membership(arrays,queries):return ('\n'.join(str(len(a))+'\n'+' '.join(map(str,a))for a in arrays)+'\n'+str(len(queries))+'\n'+' '.join(map(str,queries))+'\n').encode()
def model(identity,data):
 tokens=iter(data.split())
 if identity=='hash_set_membership':
  arrays=[[int(next(tokens))for _ in range(int(next(tokens)))]for _ in range(3)]
  sums={a+b+c for a in arrays[0]for b in arrays[1]for c in arrays[2]}
  n=int(next(tokens));return ''.join('Yes\n'if int(next(tokens))in sums else'No\n'for _ in range(n)).encode()
 n=int(next(tokens));seen=set()
 for _ in range(n):
  value=next(tokens)
  if identity=='hash_set_toggle':value=int(value)
  if identity=='hash_set_toggle'and value in seen:seen.remove(value)
  else:seen.add(value)
 return (str(len(seen))+'\n').encode()
small={i:[]for i in ['hash_set_toggle','hash_set_membership','hash_set_strings']}
for n in range(1,6):
 for values in itertools.product((1,2,3),repeat=n):small['hash_set_toggle'].append(encode_values(values))
arrays=[list(a)for n in (1,2)for a in itertools.product((1,2),repeat=n)]
for values in itertools.product(arrays,repeat=3):small['hash_set_membership'].append(membership(values,list(range(1,9))))
for _ in range(32):
 small['hash_set_toggle'].append(encode_values([rng.randrange(1,1001)for _ in range(rng.randrange(1,150))]))
 values=[[rng.randrange(1,1000)for _ in range(rng.randrange(1,8))]for _ in range(3)]
 queries=[rng.randrange(1,3000)for _ in range(20)]+[sum(a[0]for a in values)]
 small['hash_set_membership'].append(membership(values,queries))
 texts=[''.join(rng.choices('abcxyz',k=rng.randrange(1,20)))for _ in range(rng.randrange(1,50))]
 small['hash_set_strings'].append((str(len(texts))+'\n'+'\n'.join(texts)+'\n').encode())
(w/'small_cases.json').write_text(json.dumps({k:[x.decode()for x in v]for k,v in small.items()},indent=2)+'\n')
large={i:[d/i/(kind+'.in')for kind in ['small','random','degenerate']]for i in small}
large['hash_set_toggle'] += [w/(case+'.in')for case in ['alternating','all_misses','reinsert']]
expected={str(p):model(i,p.read_bytes())for i,paths in large.items()for p in paths}
results=[]
def save():(w/'validation_results.json').write_text(json.dumps(results,indent=2)+'\n')
for cc,compiler in [('gcc',['/usr/bin/g++']),('clang',['/usr/bin/clang++','--gcc-install-dir='+str(install)])]:
 for mode in ['checked','skip']:
  for identity in small:
   for variant in ['baseline']+(['candidate']if identity!='hash_set_strings'else[]):
    src=w/f'{identity}_{variant}_{mode}.cpp';exe=w/f'{identity}_{variant}_{mode}_{cc}'
    command=['taskset','-c','12',*compiler,'-std=c++23','-O2','-Wall','-Wextra',str(src),'-o',str(exe)]
    started=time.perf_counter();built=subprocess.run(command,capture_output=True,text=True);assert built.returncode==0,built.stderr
    for index,data in enumerate(small[identity]):
     result=subprocess.run(['taskset','-c','12',str(exe)],input=data,capture_output=True,timeout=10)
     assert result.returncode==0 and result.stdout==model(identity,data),(identity,variant,cc,mode,index,data,result.stdout,result.stderr)
    for p in large[identity]:
     with p.open('rb')as fi:result=subprocess.run(['taskset','-c','12',str(exe)],stdin=fi,capture_output=True,timeout=30)
     assert result.returncode==0 and result.stdout==expected[str(p)],(identity,variant,cc,mode,p,result.stdout,result.stderr)
    row={'kind':'driver_model','id':identity,'variant':variant,'compiler':cc,'mode':mode,'command':command,'small_python_set_cases':len(small[identity]),'large_python_set_cases':[{'path':str(p),'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(expected[str(p)]).hexdigest()}for p in large[identity]],'passed':True,'diagnostics':built.stderr,'elapsed_seconds':time.perf_counter()-started}
    results.append(row);save();print(identity,variant,cc,mode,'PASS',len(small[identity]),'small',len(large[identity]),'workloads',flush=True)
  # unchanged string/NUL/ownership/exception checks against the frozen same body
  src=root/'Verify/current/tests/hash_set_string_test.cpp';exe=w/f'string_api_{cc}_{mode}'
  command=['taskset','-c','12',*compiler,'-std=c++23','-O2','-Wall','-Wextra','-DHEADER="'+str(w/'Hash_set.cpp')+'"']
  if mode=='skip':command.append('-DSKIP_RUNTIME_CHECKS')
  command += [str(src),'-o',str(exe)]
  built=subprocess.run(command,capture_output=True,text=True);assert built.returncode==0,built.stderr
  result=subprocess.run(['taskset','-c','12',str(exe)],capture_output=True,text=True,timeout=30)
  assert result.returncode==0,result.stderr
  results.append({'kind':'string_api','compiler':cc,'mode':mode,'command':command,'stdout':result.stdout,'stderr':result.stderr,'passed':True});save();print('string_api',cc,mode,'PASS',flush=True)
