from pathlib import Path
import json,sys,hashlib,difflib,random
r=Path('/home/reinsirk/Atcoder_Env');w=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'Scripts'));import prepare_verify as pv
body=(r/'DataStructure/Hash_set.cpp').read_bytes();(w/'Hash_set.cpp').write_bytes(body)
io=(r/'Verify/current/common/fast_io.hpp').read_bytes();(w/'fast_io.hpp').write_bytes(io)
entries={e['id']:e for e in pv.collect()}
report={'scope':'driver_only','body_sha256':hashlib.sha256(body).hexdigest(),'io_sha256':hashlib.sha256(io).hexdigest(),'entries':{},'sources':{}}
for identity in ['hash_set_toggle','hash_set_membership','hash_set_strings']:
 entry=entries[identity];base=(r/entry['driver']).read_text();candidate=base
 if identity=='hash_set_toggle':
  old='''        auto it = values.find(key);
        if (it == values.end()) values.insert(key);
        else values.erase(it, false);'''
  new='''        const auto [it, added] = values.insert_checked(key);
        if (!added) values.erase(it, false);'''
  assert old in base;candidate=base.replace(old,new)
 elif identity=='hash_set_membership':
  candidate=base.replace('#include <cstdint>','#include <cstddef>\n#include <cstdint>').replace('    HashSet<std::int64_t> sums;','    HashSet<std::int64_t> sums;\n    sums.reserve(static_cast<std::size_t>(n) * m * l);')
 (w/(identity+'_baseline_main.cpp')).write_text(base)
 if identity!='hash_set_strings':
  (w/(identity+'_candidate_main.cpp')).write_text(candidate)
  (w/(identity+'.patch')).write_text(''.join(difflib.unified_diff(base.splitlines(True),candidate.splitlines(True),fromfile=entry['driver'],tofile=entry['driver'])))
 report['entries'][identity]=entry
 for label,driver in [('baseline',base)]+([('candidate',candidate)]if identity!='hash_set_strings'else[]):
  for mode,skip in [('checked',False),('skip',True)]:
   source,hashes=pv.render(entry,skip_runtime_checks=skip,source_overrides={'DataStructure/Hash_set.cpp':body},driver_override=driver)
   assert hashes=={'DataStructure/Hash_set.cpp':report['body_sha256']}
   name=identity+'_'+label+'_'+mode+'.cpp';(w/name).write_bytes(source);report['sources'][name]=hashlib.sha256(source).hexdigest()
(w/'provenance.json').write_text(json.dumps(report,indent=2)+'\n')
# Large toggle controls beyond frozen random/equal cases; valid 1..1e9 keys.
for label,values in [('alternating',[1,2]*50000),('all_misses',list(range(1,100001))),('reinsert',list(range(1,33001))*2+list(range(1,34001)))]:
 path=w/(label+'.in');path.write_text(str(len(values))+'\n'+'\n'.join(map(str,values))+'\n')
