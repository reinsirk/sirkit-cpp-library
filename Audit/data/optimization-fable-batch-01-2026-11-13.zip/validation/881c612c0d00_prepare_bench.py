from pathlib import Path
import json,sys,hashlib,shutil
R=Path('/home/reinsirk/Atcoder_Env');W=Path(__file__).parent;sys.path.insert(0,str(R/'Scripts'));import prepare_verify as pv
metadata=[]
for ident in ['hash_set_membership','hash_set_toggle','hash_set_strings']:
 e=next(e for e in pv.collect() if e['id']==ident); driver=(R/e['driver']).read_text();(W/'sources').mkdir(exist_ok=True);(W/'sources'/f'{ident}_driver.cpp').write_text(driver)
 hashes={}
 for label in ['baseline','candidate']:
  source=pv.render(e,source_overrides={'DataStructure/Hash_set.cpp':(W/f'{label}.hpp').read_bytes()},driver_override=driver)[0];p=W/'sources'/f'{ident}_{label}.cpp';p.write_bytes(source);hashes[label]=hashlib.sha256(source).hexdigest()
 (W/'inputs'/ident).mkdir(parents=True,exist_ok=True)
 for src in (Path('/tmp/sirkit_remaining_20261113/data/inputs')/ident).glob('*'):shutil.copyfile(src,W/'inputs'/ident/src.name)
 metadata.append({'entry':e,'driver_sha256':hashlib.sha256(driver.encode()).hexdigest(),'sources_sha256':hashes})
(W/'sources/metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
