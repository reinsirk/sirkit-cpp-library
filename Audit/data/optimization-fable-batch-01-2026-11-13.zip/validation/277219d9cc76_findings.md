# HashSet 二段probe候補：不採用

本体locateだけを変更した候補は全32テスト構成とPython set36出力照合に成功した。所有・例外・NUL文字列・解放済み借用キーにも異常はなかった。

一方、同じ固定seedと1048576回検索で、GCCの墓石あり命中がfind +9.8%、contains +8.1%となった。Clangの整数検索には最大約11%の利得があるが、文字列containsの命中は+9.1%、非命中も+3.3%で、一貫した高速化ではない。現実装を維持する。

3driverも同じmain/IO/設定で比較し全出力一致した。strings driverはinsertのみでlocateを呼ばず、両compilerでtext等の全対象sectionがbyte一致したため、その時間変動を本体差と扱わない。

[全条件・raw・再現手順](final_report.json)。候補と入力は/tmpに固定し、repoは変更していない。
